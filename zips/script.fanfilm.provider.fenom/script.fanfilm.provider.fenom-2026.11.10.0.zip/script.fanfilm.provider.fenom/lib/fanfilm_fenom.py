"""
The provider add-on of the Fenom family scrapers (CocoScrapers, POV, Fenom, Classy): the Fenom handler of the FanFilm
SDK; every installed add-on of the Fenom structure is served.
"""

from ffsdk.xprovider import FenomXProvider


class FenomScrapers(FenomXProvider):
    """The Fenom family scrapers."""
