"""
The candidates a provider skipped (a found item it did not give: another title, another year, too small, no link...) - only while the
host debugs (it asks: the context `skipped` of a request; FanFilm: the mode of the debug of the sources), never a result (not cached).

A provider tells a skip by `skip(reason, owner=self, **item)`: the fields of the item (as of a source item: `url`, `filename`, `size`,
`quality`, ...) and its reason; it is kept by the collection of its owner (the provider object, its threads too) or of the thread
(`collect_skips()` without an owner: the search of a provider of the SDK runner). No collection: nothing kept.

MIT License, Copyright (c) 2023-2026 FanFilm (see `lib/sdk/log.py`).
"""

from __future__ import annotations
import threading
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional

#: A skipped candidate: its fields (as of a source item) and `reason`.
Skip = Dict[str, Any]

#: The collections of the skips by the `id()` of their owners.
_owners: Dict[int, List[Skip]] = {}
#: The collection of the thread (no owner).
_local = threading.local()
#: Guards the collections of the owners.
_lock = threading.Lock()


@contextmanager
def collect_skips(owner: Optional[object] = None) -> Generator[List[Skip], None, None]:
    """Collect the skips of the block: of the `owner` (any thread), else of this thread; the collection is the value."""
    skips: List[Skip] = []
    if owner is None:
        outer, _local.skips = getattr(_local, 'skips', None), skips
        try:
            yield skips
        finally:
            _local.skips = outer
        return
    with _lock:
        _owners[id(owner)] = skips
    try:
        yield skips
    finally:
        with _lock:
            _owners.pop(id(owner), None)


def collecting(owner: Optional[object] = None) -> bool:
    """Return True if the skips of the owner (else of this thread) are collected now (a provider can skip making the fields of an item then)."""
    return (owner is not None and id(owner) in _owners) or getattr(_local, 'skips', None) is not None


def record_skip(reason: str, owner: Optional[object] = None, **item: Any) -> bool:
    """Keep a skipped candidate in the collection of its owner (else of this thread). Return True if kept (something collects)."""
    skips = _owners.get(id(owner)) if owner is not None else None
    if skips is None:
        skips = getattr(_local, 'skips', None)
    if skips is None:
        return False
    skips.append({**{key: value for key, value in item.items() if value not in (None, '')}, 'reason': reason})
    return True


def skip(reason: str, *, owner: Optional[object] = None, **item: Any) -> None:
    """
    A provider skipped a candidate (`item`: its fields as of a source item) for the reason: its debug line (the logger of the owner, else of the
    caller) and, while the host collects them, the skip kept.
    """
    from .log import fflog
    name = item.get('filename') or item.get('title') or item.get('url') or ''
    module = type(owner).__module__ if owner is not None else None
    fflog.debug(f'skip ({reason}): {name}', module=module, stack_depth=2)
    record_skip(reason, owner, **item)
