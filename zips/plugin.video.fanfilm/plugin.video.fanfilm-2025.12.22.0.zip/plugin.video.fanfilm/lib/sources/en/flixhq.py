# -*- coding: utf-8 -*-

"""
    FanFilm Project - FlixHQ Scraper
"""

import re
import json
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

from lib.ff import client, cleantitle, control, dom_parser
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.log_utils import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["en"]
        self.domains = ["flixhq.to"]
        self.base_link = "https://flixhq.to"
        self.search_link = "/search/%s"
        self.ajax_seasons_link = "/ajax/v2/tv/seasons/%s"
        self.ajax_episodes_link = "/ajax/v2/season/episodes/%s"
        self.ajax_servers_link = "/ajax/v2/episode/servers/%s"
        self.ajax_movie_episodes_link = "/ajax/movie/episodes/%s"
        self.ajax_episode_sources_link = "/ajax/episode/sources/%s"
        self.headers = {"User-Agent": DEFAULT_UA, "Referer": self.base_link}
        self.provider = "Vidcloud"

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {"imdb": imdb, "title": title, "year": year}
            url = urlencode(url)
            return url
        except Exception as e:
            fflog(f'Movie Exception: {str(e)}')
            fflog_exc()
            return

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {"imdb": imdb, "tmdb": tmdb, "tvshowtitle": tvshowtitle, "year": year}
            url = urlencode(url)
            return url
        except Exception as e:
            fflog(f'Tvshow Exception: {str(e)}')
            fflog_exc()
            return

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, "") for i in url])
            url["title"], url["premiered"], url["season"], url["episode"] = (title, premiered, season, episode,)
            url = urlencode(url)
            return url
        except Exception as e:
            fflog(f'Episode Exception: {str(e)}')
            fflog_exc()
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, "") for i in data])

            title = data.get("title", "")
            year = data.get("year", "")

            # Extract year from title when provided as part of the search string
            search_title = title
            if not year and title:
                year_match = re.search(r'\b(19|20)\d{2}\b', title)
                if year_match:
                    year = year_match.group(0)
                    search_title = (title[:year_match.start()] + title[year_match.end():]).strip()
                    search_title = re.sub(r'\s{2,}', ' ', search_title)
            if not search_title:
                search_title = title

            # Search for the movie/show
            query = title.replace(" ", "-")
            clean_search_title = cleantitle.get(search_title or title)
            search_url = urljoin(self.base_link, self.search_link % quote_plus(query))

            r = client.request(search_url, headers=self.headers)
            if not r:
                return sources

            # Parse search results
            # 1. Remove all newlines
            r_cleaned = re.sub(r'\n', '', r)

            # 2. Split by class="flw-item"
            items = r_cleaned.split('class="flw-item"')[1:]  # Skip first empty part

            media_id = None
            media_type = None

            for i, item in enumerate(items):

                # Extract media information from search results
                lobster_match = re.search(r'.*img data-src="([^"]*)".*<a href=".*/(tv|movie)/watch-.*-([0-9]*)".*title="([^"]*)".*class="fdi-item">([^<]*)</span>.*', item)

                if lobster_match:
                    # Groups: 1=img_url, 2=type, 3=id, 4=title, 5=year
                    img_url = lobster_match.group(1)
                    item_type = lobster_match.group(2)
                    item_id = lobster_match.group(3)
                    item_title = lobster_match.group(4)
                    item_year = lobster_match.group(5)

                    clean_item_title = cleantitle.get(item_title)

                    # Match title and year
                    if clean_item_title == clean_search_title:

                        # Priority 1: Exact year match (for both movies and TV shows)
                        if year and item_year and year in item_year:
                            media_id = item_id
                            media_type = item_type
                            break

                        # Priority 2: For movie searches when the year is unknown, prefer movie entries
                        elif not year and "tvshowtitle" not in data and item_type == "movie":
                            media_id = item_id
                            media_type = item_type
                            break

                        # Priority 3: For TV show searches when the year is unknown, accept TV shows with episode info
                        elif not year and "tvshowtitle" in data and item_type == "tv" and ("EPS" in item_year.upper() or "EPISODE" in item_year.upper()):
                            media_id = item_id
                            media_type = item_type
                            break

                        # Priority 4: Fallback - any type match but continue searching for better matches
                        elif not media_id:  # Only set if we haven't found anything yet
                            media_id = item_id
                            media_type = item_type
                            # Don't break - continue searching for better matches
                else:

                    # Try alternative patterns
                    img_match = re.search(r'img[^>]+data-src="([^"]*)"', item)
                    link_match = re.search(r'<a[^>]+href="[^"]*/(tv|movie)/watch-[^"]*-([0-9]+)"[^>]*title="([^"]*)"', item)
                    year_match = re.search(r'class="fdi-item">([^<]*)</span>', item)

                    if img_match and link_match:
                        item_type = link_match.group(1)
                        item_id = link_match.group(2)
                        item_title = link_match.group(3)
                        item_year = year_match.group(1) if year_match else ""

                        # Try matching with fallback data
                        if cleantitle.get(item_title) == clean_search_title:

                            if year and item_year and year in item_year:
                                media_id = item_id
                                media_type = item_type
                                break
                            elif not year:
                                if item_type == "tv" and item_year and ("EPS" in item_year.upper() or "EPISODE" in item_year.upper()):
                                    media_id = item_id
                                    media_type = item_type
                                    break
                                else:
                                    media_id = item_id
                                    media_type = item_type
                                    break
                            elif not media_id:
                                media_id = item_id
                                media_type = item_type

            if not media_id:
                return sources

            # Handle TV shows
            if "tvshowtitle" in data and media_type == "tv":
                season = data.get("season", "1")
                episode = data.get("episode", "1")

                # Get seasons
                seasons_url = urljoin(self.base_link, self.ajax_seasons_link % media_id)
                seasons_r = client.request(seasons_url, headers=self.headers)

                if not seasons_r:
                    return sources

                # Find season ID
                season_pattern = r'href=".*-([0-9]*)">' + re.escape(f'Season {season}') + r'</a>'
                season_match = re.search(season_pattern, seasons_r)
                if not season_match:
                    return sources

                season_id = season_match.group(1)

                # Get episodes
                episodes_url = urljoin(self.base_link, self.ajax_episodes_link % season_id)
                episodes_r = client.request(episodes_url, headers=self.headers)

                if not episodes_r:
                    return sources

                # Process episodes data

                # Step 1: Remove all newlines, then split by class="nav-item"
                episodes_clean = re.sub(r'\n', '', episodes_r)
                episode_items = episodes_clean.split('class="nav-item"')

                # Step 2: Parse each episode
                data_id = None
                target_episode_num = int(episode) if episode.isdigit() else episode

                for i, ep_item in enumerate(episode_items):
                    # Extract episode data
                    ep_match = re.search(r'.*data-id="([0-9]*)".*title="([^"]*)">', ep_item)
                    if ep_match:
                        ep_data_id = ep_match.group(1)
                        ep_title = ep_match.group(2)

                        # Check if this matches our target episode
                        # Look for episode number in title (Episode 1, Ep 1, E1, etc.)
                        ep_num_match = re.search(r'(?:Episode|Ep|E)\s*(\d+)', ep_title, re.IGNORECASE)
                        if ep_num_match:
                            found_ep_num = int(ep_num_match.group(1))
                            if found_ep_num == target_episode_num:
                                data_id = ep_data_id
                                break
                        # Also try direct string match as fallback
                        elif str(target_episode_num) in ep_title:
                            data_id = ep_data_id
                            break

                if not data_id and episode_items:
                    # Fallback: try to get episode by position
                    try:
                        ep_index = int(episode) - 1
                        if 0 <= ep_index < len(episode_items):
                            data_id_match = re.search(r'data-id="([0-9]*)"', episode_items[ep_index])
                            if data_id_match:
                                data_id = data_id_match.group(1)
                    except Exception:
                        pass

                if not data_id:
                    return sources

                # Get episode servers
                servers_url = urljoin(self.base_link, self.ajax_servers_link % data_id)
                servers_r = client.request(servers_url, headers=self.headers)

                if not servers_r:
                    return sources

                # Process server data

                # Step 1: Remove newlines, split by nav-item
                servers_clean = re.sub(r'\n', '', servers_r)
                server_items = servers_clean.split('class="nav-item"')

                # Step 2: Filter servers - prioritize Vidcloud, avoid unreliable ones
                server_ids = []
                preferred_servers = ["Vidcloud"]  # Only reliable servers
                all_servers = []

                for j, server_item in enumerate(server_items):
                    # Extract server data
                    server_match = re.search(r'.*data-id="([0-9]*)".*title="([^"]*)"', server_item)
                    if server_match:
                        server_data_id = server_match.group(1)
                        server_title = server_match.group(2)

                        all_servers.append((server_data_id, server_title))

                        # Prioritize preferred servers (check if server name contains our preferred name)
                        for preferred in preferred_servers:
                            if preferred in server_title:
                                server_ids.append((server_data_id, server_title))
                                break

                # If no preferred servers found, don't use any fallback for TV shows
                # Only use exact Vidcloud match to avoid unreliable servers

                if not server_ids:
                    return sources

            else:
                # Handle movies - collect all servers
                movie_episodes_url = urljoin(self.base_link, self.ajax_movie_episodes_link % media_id)
                movie_r = client.request(movie_episodes_url, headers=self.headers)

                if not movie_r:
                    return sources

                # Find all movie server links and filter
                movie_links = re.findall(r'href="([^"]*)"[^>]*title="([^"]*)"', movie_r)
                server_ids = []
                preferred_servers = ["Vidcloud"]  # Only reliable servers
                all_movie_servers = []

                for movie_link, server_title in movie_links:

                    # Extract episode_id from movie link
                    episode_id_match = re.search(r'-([0-9]*)\.([0-9]*)$', movie_link)
                    if episode_id_match:
                        episode_id = episode_id_match.group(2)
                        all_movie_servers.append((episode_id, server_title))

                        # Prioritize preferred servers (check if server name contains our preferred name)
                        for preferred in preferred_servers:
                            if preferred in server_title:
                                server_ids.append((episode_id, server_title))
                                break

                # If no preferred servers found, don't use any fallback for movies
                # Only use exact Vidcloud match to avoid unreliable servers

                if not server_ids:
                    return sources

            # Get video sources from all servers (same logic for both movies and TV shows)
            for server_id, server_name in server_ids:

                sources_url = urljoin(self.base_link, self.ajax_episode_sources_link % server_id)
                sources_r = client.request(sources_url, headers=self.headers)

                if not sources_r:
                    continue

                try:
                    sources_data = json.loads(sources_r)
                    embed_link = sources_data.get("link", "")

                    if not embed_link:
                        continue

                    # Check if we have subtitle tracks in the initial response
                    initial_tracks = sources_data.get("tracks", [])

                    # Extract quality info from server name or use default
                    quality = "1080p"
                    if "4K" in server_name.upper():
                        quality = "4K"
                    elif "720" in server_name:
                        quality = "720p"

                    # Add the source with server name in source field
                    source_entry = {
                        "source": f"flixhq-{server_name.lower().replace(' ', '')}",
                        "quality": quality,
                        "language": "en",
                        "url": embed_link,
                        "info": '',
                        "direct": False,
                        "debridonly": False,
                    }

                    # Add subtitles if available
                    if initial_tracks:
                        subtitle_urls = []
                        for track in initial_tracks:
                            if track.get("kind") == "captions" and track.get("file"):
                                # Create subtitle entry
                                sub_label = track.get("label", "Unknown")
                                sub_url = track.get("file")
                                is_default = track.get("default", False)

                                # Extract language from label (same logic as resolve function)
                                if " - " in sub_label:
                                    # Format: "English - English (SDH)" -> "english"
                                    sub_language = sub_label.split(" - ")[0].lower()
                                else:
                                    # Format: "English 1" -> "english"
                                    lang_match = re.search(r'^([a-zA-Z]+)', sub_label)
                                    sub_language = lang_match.group(1).lower() if lang_match else "unknown"

                                subtitle_urls.append({
                                    "url": sub_url,
                                    "label": sub_label,
                                    "language": sub_language,
                                    "default": is_default
                                })

                        if subtitle_urls:
                            source_entry["subtitles"] = subtitle_urls
                        else:
                            fflog('No valid subtitle tracks found in initial_tracks')

                    sources.append(source_entry)

                except json.JSONDecodeError:
                    continue
            return sources

        except Exception as e:
            fflog(f'Exception: {str(e)}')
            fflog_exc()
            return sources

    def resolve(self, url):
        try:

            # Use the decryption service
            decrypt_url = f"https://dec.eatmynerds.live/?url={url}"

            data = client.request(decrypt_url, headers=self.headers)
            if not data:
                return url

            try:
                json_data = json.loads(data)

                # Check for subtitle tracks
                tracks = json_data.get("tracks", [])

                # Look for m3u8 file in sources array
                sources_array = json_data.get("sources", [])
                file_url = ""
                if sources_array and len(sources_array) > 0:
                    file_url = sources_array[0].get("file", "")

                if file_url and file_url.endswith(".m3u8"):
                    # Add referer header for access
                    final_url = f"{file_url}|Referer=https://flixhq.to"

                    # Process and download subtitles directly
                    if tracks:
                        subtitle_files = self._download_subtitles(tracks)
                        if subtitle_files:
                            # Store downloaded subtitle files in window property
                            try:
                                import json as json_module
                                control.window().setProperty('flixhq.subtitles', json_module.dumps(subtitle_files))
                                fflog(f'Resolve: Downloaded and saved {len(subtitle_files)} subtitle files')
                            except Exception as e:
                                fflog(f'Resolve: Failed to save subtitle files: {str(e)}')
                                fflog_exc()

                    return final_url

            except json.JSONDecodeError:
                pass

            # Fallback: try to extract file URL with regex
            file_match = re.search(r'"file":\s*"([^"]*\.m3u8)"', data)
            if file_match:
                file_url = file_match.group(1)
                final_url = f"{file_url}|Referer=https://flixhq.to"

                # Try to also extract subtitles with regex as fallback
                try:
                    # Use a more robust regex to extract the full tracks array
                    tracks_match = re.search(r'"tracks":\s*(\[(?:[^\[\]]|\[[^\]]*\])*\])', data, re.DOTALL)
                    if tracks_match:
                        import json as json_module
                        tracks_json = tracks_match.group(1)
                        # Fix any escaped quotes in the JSON
                        tracks_json = tracks_json.replace('\\"', '"')
                        tracks_data = json_module.loads(tracks_json)
                        if tracks_data:
                            subtitle_files = self._download_subtitles(tracks_data)
                            if subtitle_files:
                                try:
                                    control.window().setProperty('flixhq.subtitles', json_module.dumps(subtitle_files))
                                    fflog(f'Resolve fallback: Downloaded and saved {len(subtitle_files)} subtitle files')
                                except Exception as e:
                                    fflog(f'Resolve fallback: Failed to save fallback subtitle files: {str(e)}')
                                    fflog_exc()
                except Exception:
                    pass

                return final_url
            return url

        except Exception as e:
            fflog(f'Resolve Exception: {str(e)}')
            fflog_exc()
            return url

    def _download_subtitles(self, tracks):
        """Download subtitle files and return local paths"""
        import os
        import tempfile
        from concurrent.futures import ThreadPoolExecutor, as_completed

        subtitle_files = []

        if not tracks:
            return subtitle_files

        try:
            # Create temp directory for subtitles
            temp_dir = tempfile.mkdtemp(prefix='flixhq_subs_')

            def download_subtitle(i, track):
                if not isinstance(track, dict) or track.get("kind") != "captions" or not track.get("file"):
                    return None

                original_url = track.get("file")
                track_label = track.get("label", "Unknown")

                # Skip subtitle variants that should not be shown
                if isinstance(track_label, str) and ('northern' in track_label.lower() or 'slovene' in track_label.lower()):
                    return None

                # Extract language
                if " - " in track_label:
                    track_language = track_label.split(" - ")[0].lower()
                else:
                    lang_match = re.search(r'^([a-zA-Z]+)', track_label)
                    track_language = lang_match.group(1).lower() if lang_match else "unknown"

                try:
                    # Convert language to ISO code
                    language_codes = {
                        'arabic': 'ar', 'danish': 'da', 'dutch': 'nl', 'english': 'en',
                        'french': 'fr', 'italian': 'it', 'russian': 'ru', 'spanish': 'es'
                    }
                    lang_code = language_codes.get(track_language, track_language)

                    # Create filename with language and proper extension
                    filename = f"{lang_code}.vtt"
                    local_path = os.path.join(temp_dir, filename)

                    # Download subtitle file
                    headers = {
                        'User-Agent': DEFAULT_UA,
                        'Referer': 'https://flixhq.to/',
                    }

                    # Use client.request for consistency with the rest of the code
                    content = client.request(original_url, headers=headers)
                    if content:
                        # Save to local file
                        with open(local_path, 'w', encoding='utf-8') as f:
                            f.write(content)
                        return local_path
                except Exception:
                    pass
                return None

            # Download all subtitles in parallel (max 10 concurrent)
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {executor.submit(download_subtitle, i, track): i for i, track in enumerate(tracks)}
                for future in as_completed(futures):
                    result = future.result()
                    if result:
                        subtitle_files.append(result)

        except Exception as e:
            fflog(f'_download_subtitles Exception: {str(e)}')
            fflog_exc()

        return subtitle_files
