# -*- coding: utf-8 -*-
"""
FanFilm – source: netmirror (net52.cc / net22.cc)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Premium cookies (t_hash_t + user_token) come from settings, populated by
the Tampermonkey script (web/mod/fanfilm.user.js) → /cookies web_server
endpoint. No cookies → no sources. Without `_p` flag the CDN serves an
"Only Valid Users Allowed" placeholder.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from html import unescape
from typing import TYPE_CHECKING, ClassVar, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urljoin

from const import const
from lib.ff import cleantitle, control, requests
from lib.ff.item import FFItem
from lib.ff.resolve_utils import build_isa_url
from lib.ff.settings import settings
from lib.ff.source_utils import CHROME_UA
from lib.ff.log_utils import fflog, fflog_exc
from lib.service.client import service_client

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias


_BASE = 'https://net52.cc'

_RES_QUALITY = [
    ('1920x1080', '1080p'),
    ('1280x720',  '720p'),
    ('854x480',   'SD'),
]
_QUALITY_TO_RES = {quality: resolution for resolution, quality in _RES_QUALITY}

_master_cache: 'Dict[str, Tuple[float, str, str, List[dict]]]' = {}
_MASTER_TTL = 300

_AUDIO_NOISE = frozenset({'', 'und'})

# Subtitle CDN file pattern: //subscdn.top/files/<id>/<id>-<lang>.[CC].srt
_CAPTION_LANG_RE = re.compile(r'-([a-zA-Z]{2,3})(?:-[a-zA-Z]+)?(?:\(\d+\))?(?:\.\[[^]]+\])?\.(?:srt|vtt)$')


class source:
    ffitem: FFItem
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl', 'en']

    def __init__(self):
        self.domains = ['net52.cc', 'net22.cc']

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        try:
            content_id = self._search(title)
            return f'nm:{content_id}' if content_id else None
        except Exception:
            fflog_exc()
            return None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        try:
            content_id = self._search(tvshowtitle)
            return f'nm:{content_id}' if content_id else None
        except Exception:
            fflog_exc()
            return None

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        try:
            if not url or not url.startswith('nm:'):
                return url
            show_id = url.split(':', 1)[1]
            cookies = self._premium_cookies()
            ua = self._user_agent()
            episode_id = self._find_episode(show_id, season, episode, cookies, ua)
            if episode_id:
                fflog(f'netmirror episode: S{season}E{episode} → id={episode_id}')
                return f'nm:{episode_id}'
        except Exception:
            fflog_exc()
        return url

    def _find_episode(self, show_id: str, season: str, episode: str, cookies: Optional[dict], ua: str) -> Optional[str]:
        """Find episode ID for S{season}E{episode} of show {show_id}."""
        # Try both 'mobile' and 'pv' paths; mobile seems more reliable for metadata.
        for path in ('mobile', 'pv'):
            try:
                resp = requests.get(
                    f'{_BASE}/{path}/post.php',
                    params={'id': show_id, 'tm': int(time.time() * 1000)},
                    cookies=cookies,
                    headers={'User-Agent': ua, 'X-Requested-With': 'XMLHttpRequest', 'Referer': f'{_BASE}/{path}/'},
                    timeout=10,
                )
                if not resp or resp.status_code != 200:
                    continue
                data = resp.json()
                seasons = data.get('season') or []
                s_id = next((s.get('id') for s in seasons if str(s.get('s')) == str(season)), None)
                if not s_id:
                    continue

                resp = requests.get(
                    f'{_BASE}/{path}/episodes.php',
                    params={'s': s_id, 'series': show_id, 'page': 1},
                    cookies=cookies,
                    headers={
                        'User-Agent': ua,
                        'Referer': f'{_BASE}/{path}/',
                        'Accept': 'application/json, text/plain, */*',
                        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                        'Connection': 'keep-alive',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    timeout=10,
                )
                if not resp or resp.status_code != 200:
                    continue
                fflog(f'netmirror: {path}/episodes.php response: {resp.text[:500]}')
                data = resp.json()
                target_s, target_e = f'S{season}', f'E{episode}'
                for ep in data.get('episodes') or []:
                    if ep.get('s') == target_s and ep.get('ep') == target_e:
                        return ep.get('id')
            except Exception:
                pass
        return None

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        results: List[dict] = []
        try:
            if not url or not url.startswith('nm:'):
                return results
            content_id = url.split(':', 1)[1].split('?', 1)[0]
            if not content_id:
                return results

            cookies = self._premium_cookies()
            ua = self._user_agent()
            master_text = self._cached_master(content_id, cookies, ua)
            if not master_text:
                fflog('netmirror: master unavailable, falling back to fixed quality list')
                audios = set()
                resolutions = {res for res, _ in _RES_QUALITY}
            else:
                audios = self._audio_langs(master_text)
                resolutions = self._video_resolutions(master_text)
                fflog(f'netmirror: audio={sorted(audios)} resolutions={sorted(resolutions)}')

            captions = self._cached_captions(content_id, cookies)
            language, info = self._classify_audio(audios, captions)

            for resolution, quality in _RES_QUALITY:
                if resolution not in resolutions:
                    continue
                results.append({
                    'source':     'netmirror',
                    'quality':    quality,
                    'language':   language,
                    'url':        f'nm:{content_id}?q={quality}',
                    'info':       info,
                    'filename':   str(content_id),
                    'direct':     False,
                    'debridonly': False,
                })
        except Exception:
            fflog_exc()
        fflog(f'sources: {len(results)}')
        return results

    @staticmethod
    def _audio_langs(master_text: str) -> 'set[str]':
        return set(re.findall(r'#EXT-X-MEDIA:[^\n]*TYPE=AUDIO[^\n]*LANGUAGE="([^"]*)"', master_text))

    @staticmethod
    def _video_resolutions(master_text: str) -> 'set[str]':
        return set(re.findall(r'#EXT-X-STREAM-INF[^\n]*RESOLUTION=(\d+x\d+)', master_text))

    @staticmethod
    def _classify_audio(audios: 'set[str]', captions: 'Optional[List[dict]]' = None) -> 'tuple[str, str]':
        # pol → 'pl', eng → 'en', else → 'en'. PL audio gets 'LEKTOR' in info
        # (NF/PV PL tracks are virtually always lektor) so SUBTITLES.disallowed
        # filter in lib/ff/sources.py keeps pozycje z napisami i lektorem.
        # 'MULTI' when extra tracks beyond the primary, 'NAPISY' when captions.
        meaningful = audios - _AUDIO_NOISE
        if not meaningful:
            language, info_parts = 'en', []
        else:
            has_pol = 'pol' in meaningful
            has_eng = 'eng' in meaningful
            if has_pol:
                language = 'pl'
                info_parts = ['LEKTOR']
                if meaningful - {'pol'}:
                    info_parts.append('MULTI')
            elif has_eng:
                language = 'en'
                info_parts = ['MULTI'] if (meaningful - {'eng'}) else []
            else:
                language = 'en'
                info_parts = ['MULTI']
        if captions:
            info_parts.append('NAPISY')
        return (language, ' '.join(info_parts))

    def resolve(self, url: str) -> Optional[str]:
        try:
            if not url or not url.startswith('nm:'):
                return None
            body = url[3:]
            if '?' in body:
                content_id, query = body.split('?', 1)
                quality = parse_qs(query).get('q', ['1080p'])[0]
            else:
                content_id, quality = body, '1080p'
            target_res = _QUALITY_TO_RES.get(quality, '1920x1080')

            cookies = self._premium_cookies()
            if not cookies:
                fflog('netmirror: no premium cookies (autocook.json unreachable?)')
                return None

            ua = self._user_agent()
            master_text = self._cached_master(content_id, cookies, ua)
            cache_key = f'{content_id}:{self._cookies_fingerprint(cookies)}'
            cached = _master_cache.get(cache_key)
            master_url = cached[1] if cached else self._signed_master_url(content_id, cookies, ua)
            if not master_url:
                fflog(f'netmirror: no signed master URL for id={content_id}')
                return None

            captions = self._cached_captions(content_id, cookies)
            if captions:
                try:
                    subtitle_urls = [caption['file'] for caption in captions if caption.get('file')]
                    control.window().setProperty('source.subtitles', json.dumps(subtitle_urls))
                    fflog(f'netmirror resolve: {len(subtitle_urls)} subtitle(s) passed to player')
                except Exception:
                    fflog_exc()

            proxy_url = self._build_proxy(master_url, target_res, ua, master_text, cookies)
            if proxy_url:
                fflog(f'netmirror resolve: {quality} → proxy {proxy_url}')
                return build_isa_url(proxy_url, _BASE + '/', ua=ua)

            # Proxy build failed → fall back to direct master (ISA will play
            # but with the live-vs-VOD warnings noted in the docstring).
            fflog(f'netmirror resolve: {quality} → direct master (proxy fail)')
            return build_isa_url(master_url, _BASE + '/', ua=ua)
        except Exception:
            fflog_exc()
            return None

    # ── premium cookies (settings only) ────────────────────────────────────

    def _premium_cookies(self) -> Optional[dict]:
        cookies = self._cookies_from_settings()
        if not cookies:
            fflog('netmirror: _premium_cookies returned None')
        else:
            fflog(f'netmirror: _premium_cookies retrieved keys: {list(cookies.keys())}')
        return cookies

    @staticmethod
    def _user_agent() -> str:
        ua = settings.getString('netmirror.user_agent').strip(' "\'')
        return ua or CHROME_UA

    @staticmethod
    def _cookies_from_settings() -> Optional[dict]:
        t_hash_p = settings.getString('netmirror.cookies_t_hash_p').strip(' "\'')
        t_hash_t = settings.getString('netmirror.cookies_t_hash_t').strip(' "\'')
        t_hash = settings.getString('netmirror.cookies_t_hash').strip(' "\'')
        user_token = settings.getString('netmirror.cookies_user_token').strip(' "\'')
        
        # Log which keys we are checking
        fflog(f'netmirror: checking cookies keys: t_hash_p={bool(t_hash_p)}, t_hash_t={bool(t_hash_t)}, user_token={bool(user_token)}')

        if not (user_token and (t_hash_p or t_hash_t or t_hash)):
            return None
            
        cookies = {'user_token': unquote(user_token)}
        
        # Send ALL available t_hash cookies – mobile/post.php needs both
        # t_hash_p AND t_hash_t to authenticate (single one returns "Invalid User").
        if t_hash_p:
            cookies['t_hash_p'] = unquote(t_hash_p)
        if t_hash_t:
            cookies['t_hash_t'] = unquote(t_hash_t)
        if t_hash:
            cookies['t_hash'] = unquote(t_hash)
            
        addhash = settings.getString('netmirror.cookies_addhash').strip(' "\'')
        if addhash:
            cookies['addhash'] = unquote(addhash)
            
        return cookies

    @staticmethod
    def _cookies_fingerprint(cookies: Optional[dict]) -> str:
        # Scopes _master_cache to current cookies — pasting new cookies
        # changes the fingerprint and forces a fresh master fetch.
        if not cookies:
            return 'none'
        material = ';'.join(f'{name}={value}' for name, value in sorted(cookies.items()))
        return hashlib.md5(material.encode()).hexdigest()[:8]

    # ── search ─────────────────────────────────────────────────────────────

    def _search(self, title: str) -> Optional[str]:
        if not title:
            return None
        fflog(f'netmirror query: {title!r}')
        try:
            resp = requests.get(
                f'{_BASE}/search.php',
                params={'s': title, 't': int(time.time() * 1000)},
                headers={
                    'User-Agent': CHROME_UA,
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': _BASE + '/',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                timeout=12,
            )
            if not resp or resp.status_code != 200:
                return None
            results = resp.json().get('searchResult') or []
        except Exception:
            fflog_exc()
            return None

        if not results:
            fflog(f'netmirror: no search hits for {title!r}')
            return None

        clean_target = cleantitle.get(title)
        for item in results:
            if cleantitle.get(unescape(item.get('t') or '')) == clean_target:
                fflog(f"netmirror: matched {item.get('t')!r} → id={item.get('id')}")
                return item.get('id')

        fflog(f'netmirror: no exact title match (have {len(results)} hits)')
        return None

    # ── master cache (sources → resolve handoff) ───────────────────────────

    def _cached_master(self, content_id: str, cookies: Optional[dict], ua: str) -> Optional[str]:
        # 5 min TTL, keyed by (id, cookies fingerprint). Stores master_text
        # and the captions list (from /mobile/playlist.php) for resolve() reuse.
        now = time.time()
        key = f'{content_id}:{self._cookies_fingerprint(cookies)}'
        cached = _master_cache.get(key)
        if cached and (now - cached[0]) < _MASTER_TTL:
            return cached[2]
        if not cookies:
            return None
        master_url = self._signed_master_url(content_id, cookies, ua)
        if not master_url:
            return None
        try:
            resp = requests.get(
                master_url,
                cookies=cookies,
                headers={
                    'User-Agent': ua,
                    'Referer': f'https://net52.cc/play.php?id={content_id}',
                    'Accept': '*/*',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'Connection': 'keep-alive',
                },
                timeout=12,
            )
            fflog(f'netmirror: master fetch status {getattr(resp,"status_code",None)} for id={content_id}')
            fflog(f'netmirror: master fetch headers: {dict(resp.headers) if resp else "None"}')
            if not resp or resp.status_code != 200 or not resp.text.startswith('#EXTM3U'):
                fflog(f'netmirror: master fetch status {getattr(resp,"status_code",None)} for id={content_id}')
                return None
            master_text = resp.text
            fflog(f'netmirror: full master playlist content:\n{master_text}')
            
            captions = self._captions_from_mobile(content_id, ua)
            _master_cache[key] = (now, master_url, master_text, captions)
            return master_text
        except Exception:
            fflog_exc()
            return None

    def _cached_captions(self, content_id: str, cookies: Optional[dict]) -> List[dict]:
        """Read captions from the master cache (populated by _cached_master)."""
        key = f'{content_id}:{self._cookies_fingerprint(cookies)}'
        cached = _master_cache.get(key)
        return cached[3] if cached and len(cached) >= 4 else []

    # ── premium master URL via /pv/playlist.php ────────────────────────────

    def _signed_master_url(self, content_id: str, cookies: dict, ua: str) -> Optional[str]:
        # /pv/playlist.php returns sources[0].file = '/pv/hls/<id>.m3u8?in=<h>'.
        try:
            params = {'id': content_id, 'tm': int(time.time() * 1000)}
            fflog(f'netmirror: fetching pv/playlist.php with params={params} cookies={list(cookies.keys())}')
            resp = requests.get(
                f'{_BASE}/pv/playlist.php',
                params=params,
                cookies=cookies,
                headers={
                    'User-Agent': ua,
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': f'{_BASE}/pv/',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                timeout=12,
            )
            if not resp or resp.status_code != 200:
                fflog(f'netmirror: pv/playlist.php status {getattr(resp,"status_code",None)}')
                return None
            
            # Log full response body for debug
            fflog(f'netmirror: pv/playlist.php response: {resp.text[:500]}')
            
            try:
                data = resp.json()
            except ValueError:
                return None
            if not isinstance(data, list) or not data:
                return None
            sources_list = data[0].get('sources') or []
            if not sources_list:
                return None
            file_url = sources_list[0].get('file', '')
            if not file_url:
                return None

            fflog(f'netmirror: raw file_url: {file_url}')

            # /pv/hls/<id>.m3u8 → /hls/<id>.m3u8 (full master, real CDNs)
            file_url = file_url.replace('/pv/hls/', '/hls/').replace('/mobile/hls/', '/hls/')
            if file_url.startswith('/'):
                file_url = _BASE + file_url

            # Check for '::p::' as the current premium signature marker
            if '::p::' not in file_url:
                fflog(f'netmirror: master URL missing premium flag (::p::): {file_url[:100]}')
            return file_url


        except Exception:
            fflog_exc()
            return None

    @staticmethod
    def _captions_from_mobile(content_id: str, ua: str) -> List[dict]:
        # /mobile/playlist.php is the only endpoint exposing caption tracks.
        # Filter by ISO code parsed from the srt filename against sub_langs.
        wanted = {code.lower().rstrip('-') for code in const.sources.netmirror.sub_langs}
        try:
            resp = requests.get(
                f'{_BASE}/mobile/playlist.php',
                params={'id': content_id, 'tm': int(time.time() * 1000)},
                headers={
                    'User-Agent': ua,
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': f'{_BASE}/',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                timeout=10,
            )
            if not resp or resp.status_code != 200:
                return []
            data = resp.json()
            if not isinstance(data, list) or not data:
                return []
            tracks = data[0].get('tracks') or []
        except Exception:
            fflog_exc()
            return []

        captions: List[dict] = []
        for track in tracks:
            if track.get('kind') != 'captions':
                continue
            file_url = track.get('file', '')
            if not file_url:
                continue
            match = _CAPTION_LANG_RE.search(file_url)
            if not match:
                continue
            code = match.group(1).lower()
            if code not in wanted:
                continue
            if file_url.startswith('//'):
                file_url = 'https:' + file_url
            captions.append({'file': file_url, 'label': track.get('label', code), 'code': code})
        fflog(f'netmirror captions for {content_id}: {[caption["label"] for caption in captions]}')
        return captions

    # ── HLS proxy ──────────────────────────────────────────────────────────

    def _build_proxy(self, master_url: str, target_res: str, ua: str,
                     master_text: Optional[str] = None,
                     cookies: Optional[dict] = None) -> Optional[str]:
        # Prune master to selected video + filtered audio tracks, fix each
        # sub-playlist (abs URLs, #EXT-X-PLAYLIST-TYPE:VOD, #EXT-X-ENDLIST),
        # register the rewritten master+subs in service_client at /media/.
        try:
            wanted_langs = tuple(const.sources.netmirror.audio_langs)
            text = master_text
            if not text:
                resp = requests.get(
                    master_url,
                    cookies=cookies,
                    headers={'User-Agent': ua, 'Referer': _BASE + '/'},
                    timeout=12,
                )
                if not resp or resp.status_code != 200:
                    fflog(f'netmirror: master fetch status {getattr(resp,"status_code",None)}')
                    return None
                text = resp.text
            if not text.startswith('#EXTM3U'):
                fflog(f'netmirror: master not m3u8, body[:120]={text[:120]!r}')
                return None

            proxy_map: Dict[str, str] = {}
            proxy_base = urljoin(service_client.url, '/media')

            # Netmirror sometimes returns audio URIs with missing host (https:///files/...).
            # Extract host from video variants to fix them.
            cdn_host = None
            host_m = re.search(r'https?://([^/]+)/files/', text)
            if host_m:
                cdn_host = host_m.group(1)

            # Dynamic host discovery: Extract from first video stream
            video_cdn_host = None
            for line in text.splitlines():
                if line.startswith('http') and '/files/' in line:
                    host_m = re.search(r'https?://([^/]+)/files/', line)
                    if host_m:
                        video_cdn_host = host_m.group(1)
                        break
            
            fflog(f'netmirror: resolved CDN host from playlist: {video_cdn_host}')

            new_lines: List[str] = []
            kept_variant = False
            lines = text.splitlines()
            i = 0
            while i < len(lines):
                line = lines[i]
                if line.startswith('#EXT-X-MEDIA') and 'TYPE=AUDIO' in line:
                    uri_m = re.search(r'URI="([^"]+)"', line)
                    if uri_m:
                        uri = uri_m.group(1)
                        # Fix malformed URI by prepending the discovered CDN host
                        if uri.startswith('https:///'):
                            path = uri.replace('https:///', '/')
                            if video_cdn_host:
                                uri = f'https://{video_cdn_host}{path}'
                                fflog(f'netmirror: patched audio URI: {uri}')
                        
                        proxied = self._proxy_sub(uri, proxy_map, ua, video_cdn_host)
                        if proxied:
                            line = line.replace(f'URI="{uri_m.group(1)}"', f'URI="{proxy_base}{proxied}"')
                            new_lines.append(line)
                    i += 1
                    continue

                if line.startswith('#EXT-X-STREAM-INF'):
                    res_m = re.search(r'RESOLUTION=(\d+x\d+)', line)
                    is_target = res_m and res_m.group(1) == target_res
                    nxt = lines[i + 1] if i + 1 < len(lines) else ''
                    if is_target and nxt.startswith('http'):
                        proxied = self._proxy_sub(nxt.strip(), proxy_map, ua, cdn_host)
                        if proxied:
                            new_lines.append(line)
                            new_lines.append(f'{proxy_base}{proxied}')
                            kept_variant = True
                    i += 2
                    continue

                new_lines.append(line)
                i += 1

            if not kept_variant:
                fflog(f'netmirror: target resolution {target_res} not in master')
                return None

            new_master = '\n'.join(new_lines)
            master_hash = hashlib.md5((master_url + target_res).encode()).hexdigest()[:12]
            master_path = f'/nm_{master_hash}.m3u8'
            proxy_map[master_path] = new_master
            service_client.set_media_files(proxy_map)
            return f'{proxy_base}{master_path}'
        except Exception:
            fflog_exc()
            return None

    @staticmethod
    def _proxy_sub(sub_url: str, proxy_map: Dict[str, str], ua: str, cdn_host: Optional[str] = None) -> Optional[str]:
        try:
            # Master sometimes hands us audio URIs missing the host
            # (https:///files/...). Patch with the video-variant host.
            if sub_url.startswith('https:///'):
                if not cdn_host:
                    return None
                sub_url = sub_url.replace('https:///', f'https://{cdn_host}/')

            resp = requests.get(
                sub_url,
                headers={'User-Agent': ua, 'Referer': _BASE + '/'},
                timeout=10,
            )
            if not resp or resp.status_code != 200:
                fflog(f'netmirror: sub status {getattr(resp,"status_code",None)} for {sub_url[:80]}')
                return None
            text = resp.text
            if not text.lstrip().startswith('#EXTM3U'):
                fflog(f'netmirror: sub not m3u8 for {sub_url[:80]}')
                return None
            base_url = sub_url.split('?', 1)[0].rsplit('/', 1)[0] + '/'
            fixed = _fix_sub_playlist(text, base_url)
            sub_hash = hashlib.md5(sub_url.encode()).hexdigest()[:12]
            sub_path = f'/nm_sub_{sub_hash}.m3u8'
            proxy_map[sub_path] = fixed
            return sub_path
        except Exception:
            fflog_exc()
            return None


def _fix_sub_playlist(text: str, base_url: str) -> str:
    # Make CDN segment URLs absolute, force VOD type, append ENDLIST.
    # Without VOD/ENDLIST, ISA treats the stream as live.
    base_root = base_url.rstrip('/')
    out: List[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if line and not line.startswith('#'):
            out.append(line if line.startswith('http') else f"{base_root}/{line.lstrip('/')}")
        else:
            out.append(raw)
    content = '\n'.join(out)
    if '#EXT-X-PLAYLIST-TYPE' not in content and '#EXT-X-MEDIA-SEQUENCE' in content:
        content = content.replace(
            '#EXT-X-MEDIA-SEQUENCE',
            '#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE',
            1,
        )
    if '#EXT-X-ENDLIST' not in content:
        content += '\n#EXT-X-ENDLIST\n'
    return content
