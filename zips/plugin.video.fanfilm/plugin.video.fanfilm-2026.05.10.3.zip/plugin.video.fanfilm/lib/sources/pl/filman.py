# -*- coding: utf-8 -*-
"""
FanFilm – source: filman.cc
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
import base64
import codecs
import re
import time
import json
from typing import Any, TYPE_CHECKING, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from lib.sources import SourceItem, ClassVar, SourceTitleAlias
from urllib.parse import quote_plus, urlparse
from html import unescape

from lib.ff import requests

from lib.sources import single_call
from lib.ff import source_utils, cleantitle, utils, cache, control
from lib.ff.source_utils import ShowData, show_data_asdict, ShowDataDict
from lib.ff.client import parseDOM
from lib.ff.settings import settings
from lib.ff.log_utils import fflog, fflog_exc
from lib.ff.item import FFItem
from const import const

# ─── source ──────────────────────────────────────────────────────────────────────

class _source:
    """Base scraper for filman.cc with premium support as separate scraper."""
    PROVIDER: ClassVar[str] = ''

    has_sort_order: ClassVar[bool] = False
    has_color_identify2: ClassVar[bool] = False
    use_premium_color: ClassVar[bool] = False
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    _LAST_SEARCH_TIME: float = 0

    EMBED_DOMAIN = 'embed.tmp-url.pro'

    HOSTING_MAP = {
        'bigdisk.stream': 'bigdisk',
    }

    _VODI_BASE = 'https://cloud.vodi.cc'
    _VODI_STRATEGIES = ('meganta_md5_v1', 'hmac_sha256_v1')

    # Regex patterns
    RE_HREF = re.compile(r'href="(.*?)"')
    RE_TITLE_ALT = re.compile(r' (?:title|alt)="(.*?)"')
    RE_IFRAME = re.compile(r'data-iframe="([^"]+)"')
    RE_HREF_MP4 = re.compile(r'href="([^"]+)"[^>]*data-mp4="true"')
    RE_LINK_ID = re.compile(r'data-(?:link-)?id="(\d+)"')
    RE_TD = re.compile(r'<td[^>]*>(.*?)</td>', re.DOTALL)
    RE_SEASON_EPISODE = re.compile(r'<span>Sezon (\d+)</span>.*?<ul>(.*?)</ul>', re.DOTALL)
    RE_EPISODE_LINK = re.compile(r'<a href="(.*?)">\s*\[s(\d+)e(\d+)\]\s*(.*?)\s*</a>', re.DOTALL)
    RE_YEAR = re.compile(r'<div class="film_year">(\d{4})</div>')

    # Time units
    TIME_UNITS = {
        'bez': 1,
        'minutę': 60,
        'minuty': 60,
        'minut': 60,
        'godzinę': 3600,
        'godziny': 3600,
        'godzin': 3600,
        'dzień': 86400,
        'dni': 86400,
        'tydzień': 604800,
        'tygodnie': 604800,
        'tygodni': 604800,
        'miesiąc': 2592000,
        'miesiące': 2592000,
        'miesięcy': 2592000,
        'rok': 31536000,
        'lata': 31536000,
        'lat': 31536000,
    }

    @single_call
    def init(self):
        self.base_link = 'https://filman.cc'
        self.login_link = self.base_link + '/logowanie'
        self.search_link = self.base_link + '/search?phrase={title}'
        self.username = settings.getString('filman.username')
        self.password = settings.getString('filman.password')
        stored_ua = settings.getString('filman.user_agent').strip()
        self.USER_AGENT = stored_ua if stored_ua else 'FilmanKodi/1.0 (compatible; Firefox/146.0)'
        self.HEADERS = {'Host': 'filman.cc', 'User-Agent': self.USER_AGENT}
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self._apply_cookie_settings()
        self._purge_old_episode_cache()

    # ── public api (shared) ────────────────────────────────────────────────

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict:
        self.init()
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, year))

    def resolve(self, url: str) -> Optional[str]:
        # kod poniższy powstał w uzgodnieniu z filman.cc - proszę nie zapożyczać bez kontaktu z team fanfilm.
        self.init()
        if not url:
            return None

        rt = ''
        referer = self.base_link + '/'
        if '|' in url:
            url, params = url.split('|', 1)
            params_dict = dict(p.split('=', 1) for p in params.split('&') if '=' in p)
            rt = params_dict.get('rt', '')
            referer = params_dict.get('referer', referer)

        if '/link/go/' in url:
            try:
                link_id = url.split('/')[-1]
                if not rt:
                    resp = self.session.get(self.base_link, verify=False)
                    rt_m = re.search(r"var (?:rt|routeToken)\s*=\s*'([^']+)'", resp.text)
                    rt = rt_m.group(1) if rt_m else ''

                if rt:
                    # Optional: call /link/go/ID first as the site does (it returns 302/404 but might set session)
                    self.session.get(url, verify=False, allow_redirects=False, headers={'Referer': referer})
                    
                    token_url = f"{self.base_link}/link/token?link_id={link_id}&rt={rt}"
                    token_resp = self.session.get(token_url, verify=False, headers={
                        'X-Requested-With': 'XMLHttpRequest',
                        'Referer': referer
                    })
                    data = token_resp.json()
                    if data.get('ok') and data.get('url'):
                        url = base64.b64decode(data['url']).decode('utf-8')
            except Exception:
                fflog_exc()

        if self.EMBED_DOMAIN not in url:
            return url
        try:
            resp = requests.get(url, verify=False, headers={
                'User-Agent': self.USER_AGENT,
                'Referer': self.base_link + '/',
            })
            html = resp.text

            # new scheme: var _e / _a / _b / _c → _xd(base64, _a+_b+_c) XOR
            e_m = re.search(r"var _e\s*=\s*'([^']+)'", html)
            a_m = re.search(r"var _a\s*=\s*'([^']+)'", html)
            b_m = re.search(r"var _b\s*=\s*'([^']+)'", html)
            c_m = re.search(r"var _c\s*=\s*'([^']+)'", html)
            if e_m and a_m and b_m and c_m:
                key = a_m.group(1) + b_m.group(1) + c_m.group(1)
                raw = base64.b64decode(e_m.group(1))
                hoster_url = ''.join(chr(raw[i] ^ ord(key[i % len(key)])) for i in range(len(raw)))
                fflog(f'filman resolve: {hoster_url[:80]}')
                return hoster_url

            # old scheme: base64 + rot13
            e_old = re.search(r"var _e = '([^']+)'", html)
            if e_old:
                hoster_url = codecs.encode(base64.b64decode(e_old.group(1)).decode(), 'rot_13')
                fflog(f'filman resolve (rot13): {hoster_url[:80]}')
                return hoster_url

            fflog(f'filman resolve: no _e in embed page (len={len(html)}, status={resp.status_code})')
        except Exception:
            fflog_exc()
        return None

    # ── helpers ────────────────────────────────────────────────────────────

    def login(self) -> bool:
        if not self.username or not self.password:
            fflog('login: no credentials')
            return False
        try:
            login_data = {
                'login': self.username,
                'password': self.password,
                'remember': 'on',
                'submit': '',
            }
            response = self.session.post(self.login_link, data=login_data, verify=False)
            fflog(
                f"login: POST status={response.status_code} url={response.url} guest_false={'yes' if 'guest: false' in response.text else 'no'}")
            if 'guest: false' in response.text:
                fflog('login: ok')
                return True
            fflog(f"login: failed — response snippet: {response.text[:300]!r}")
        except Exception:
            fflog_exc()
        return False

    def is_logged_in(self) -> bool:
        if getattr(self, '_logged_in', False):
            return True
        self.init()
        had_bkd = any(cookie.name == 'BKD_REMEMBER' for cookie in self.session.cookies)
        if not had_bkd:
            fflog('is_logged_in: no BKD_REMEMBER cookie — skip filman.cc HTTP probe')
            return False
        try:
            response = self.session.get(self.base_link, verify=False)
            if 'guest: false' in response.text:
                self._logged_in = True
                return True
            still_has_bkd = any(cookie.name == 'BKD_REMEMBER' for cookie in self.session.cookies)
            if had_bkd and not still_has_bkd:
                fflog('is_logged_in: server rejected BKD_REMEMBER (cookie expired/rotated) — paste a fresh cookie from the browser')
                return False
        except Exception:
            fflog_exc()
        if self.login():
            self._logged_in = True
            return True
        fflog('is_logged_in: not authenticated — paste fresh BKD_REMEMBER + cf_clearance into addon settings')
        return False

    def _parse_search_results(self, page_content: str, year: int, media_type: str) -> list[dict[str, Any]]:
        candidates = []
        blocks = page_content.split('<div class="poster">')[1:]

        for block in blocks:
            try:
                year_match = self.RE_YEAR.search(block)
                if not year_match or abs(int(year_match.group(1)) - int(year)) > 1:
                    continue

                href_match = self.RE_HREF.search(block)
                if not href_match:
                    continue

                href = href_match.group(1)
                if href.startswith('/'):
                    href = self.base_link + href
                if (media_type == 'movie' and '/m/' not in href) or (media_type == 'tvshow' and '/s/' not in href):
                    continue

                title_match = self.RE_TITLE_ALT.search(block)
                if not title_match:
                    continue

                full_title = unescape(utils.decode_title_from_latin1(title_match.group(1)))
                title_parts_clean = [cleantitle.get_simple(p.strip()) for p in full_title.split('/') if p.strip()]

                candidates.append({
                    'href': href,
                    'full_title': full_title,
                    'title_parts_clean': title_parts_clean
                })
            except Exception:
                continue
        return candidates

    def _match_results(self, page_content: str, primary_title: str, aliases: List[str], year: int, media_type: str) -> Optional[Tuple[str, str]]:
        candidates = self._parse_search_results(page_content, year, media_type)
        search_clean = cleantitle.get_simple(primary_title)
        alias_cleans = {cleantitle.get_simple(a) for a in aliases if a and cleantitle.get_simple(a)}

        for c in candidates:
            for part in c['title_parts_clean']:
                if part == search_clean:
                    return (c['href'], c['full_title'])

        for c in candidates:
            for part in c['title_parts_clean']:
                if part in alias_cleans:
                    return (c['href'], c['full_title'])

        for c in candidates:
            for part in c['title_parts_clean']:
                if source_utils._levenshtein(part, search_clean) <= 3:
                    return (c['href'], c['full_title'])

        return None

    def _filman_episode_url(self, tmdb, show_title: str, episode_number_str: str,
                             absolute_episode_number: int, queries, alias_titles, year) -> Optional[Tuple[str, str]]:
        """Return (url, title) for a filman.cc episode from cache or HTML search."""
        if tmdb:
            cache_id = f"filman_eps_{tmdb}"
            cached = cache.cache_get(cache_id, control.providercacheFile)
            if cached and 'date' in cached and cache._is_cache_valid(int(cached['date']), 24):
                fflog(f"filman: cache hit {cache_id}")
                episodes = json.loads(cached['value'])
                result = self._find_in_episodes(episodes, show_title, episode_number_str, absolute_episode_number)
                if result:
                    return result
                fflog(f"filman: {episode_number_str} not in cache, searching HTML")
            else:
                fflog(f"filman: cache miss {cache_id}")

        for search_title in queries:
            now = time.time()
            elapsed = now - _source._LAST_SEARCH_TIME
            if 0 < elapsed < 0.5:
                time.sleep(0.5 - elapsed)
            _source._LAST_SEARCH_TIME = time.time()

            fflog(f"filman: query {search_title!r} ({year})")
            page = self.session.get(self.search_link.format(title=quote_plus(search_title)), verify=False).text
            result = self._match_results(page, search_title, alias_titles, year, 'tvshow')
            if result:
                show_match = {'href': result[0], 'title': result[1]}
                episode_match = self._extract_episode_url(show_match, episode_number_str, absolute_episode_number, tmdb)
                if episode_match:
                    return episode_match
                return None
        return None

    def _extract_episode_url(self, show_match: dict[str, Any], episode_number_str: str, absolute_episode_number: int = 0, tmdb=None) -> Optional[Tuple[str, str]]:
        try:
            page_html = self.session.get(show_match['href'], verify=False).text
            season_blocks = self.RE_SEASON_EPISODE.findall(page_html)
            fflog(f"season blocks: {len(season_blocks)}, looking for {episode_number_str!r}")
            if not season_blocks:
                snippet = page_html[page_html.find('Sezon')-50:page_html.find('Sezon')+ \
                                                   200] if 'Sezon' in page_html else page_html[:300]
                fflog(f"no season blocks, snippet={snippet!r}")
            episodes = []
            for _, episodes_html in season_blocks:
                for ep_url, season_num, episode_num, _ in self.RE_EPISODE_LINK.findall(episodes_html):
                    if ep_url.startswith('/'):
                        ep_url = self.base_link + ep_url
                    episodes.append((source_utils.format_episode_key(season_num, episode_num), ep_url))

            fflog(f"results: {len(episodes)}")
            if not episodes:
                return None

            if tmdb:
                fflog(f"cache write: filman_eps_{tmdb} ({len(episodes)} episodes)")
                cache.cache_insert(f"filman_eps_{tmdb}", json.dumps(episodes), control.providercacheFile)

            return self._find_in_episodes(episodes, show_match['title'], episode_number_str, absolute_episode_number)

        except Exception:
            fflog_exc()
        return None

    def _find_in_episodes(self, episodes: list[tuple[str, str]], show_title: str, episode_number_str: str, absolute_episode_number: int) -> Optional[Tuple[str, str]]:
        episode_map = dict(episodes)

        # Exact match (show uses proper season/episode keys on filman)
        if episode_number_str in episode_map:
            return (episode_map[episode_number_str], f"{show_title} {episode_number_str}")

        if source_utils.is_anime(self.ffitem):
            # Filman stores anime as a single season (s01eNNN). TMDB assigns
            # arbitrary season numbers. absolute_episode_number() is reliable
            # when continuous_episode_number=True, but position-based indexing
            # on a lexicographically-sorted key list is broken for episode
            # numbers >99 (e.g. s01e999 sorts after s01e1155). Use dict lookup.
            if absolute_episode_number > 0:
                s01_key = source_utils.format_episode_key(1, absolute_episode_number)
                if s01_key in episode_map:
                    return (episode_map[s01_key], f"{show_title} {s01_key}")
            # Not found — cache is stale; return None so caller falls through to re-fetch
            return None

        abs_key = source_utils.format_episode_key(1, absolute_episode_number)
        if absolute_episode_number > 0 and abs_key in episode_map:
            return (episode_map[abs_key], f"{show_title} {abs_key}")

        return None

    # ── Vodi API (premium path) ────────────────────────────────────────────

    def _vodi_token(self) -> Optional[str]:
        if hasattr(self, '_vodi_access_token'):
            return self._vodi_access_token
        token = self._vodi_resolve_token()
        self._vodi_access_token = token
        return token

    def _vodi_resolve_token(self) -> Optional[str]:
        cached = cache.cache_get('filman_vodi_auth', control.providercacheFile)
        if cached and 'date' in cached:
            try:
                auth = json.loads(cached['value'])
                if auth.get('is_free'):
                    if cache._is_cache_valid(int(cached['date']), 2):
                        return None
                else:
                    token = auth.get('access_token', '')
                    refresh = auth.get('refresh_token', '')
                    if token and cache._is_cache_valid(int(cached['date']), 168):
                        return token
                    if refresh:
                        return self._vodi_do_refresh(refresh)
            except Exception:
                fflog_exc()
        return self._vodi_do_login()

    def _vodi_session_get(self) -> 'requests.Session':
        if getattr(self, '_vodi_session', None) is None:
            session = requests.Session()
            session.headers.update({'Content-Type': 'application/json', 'User-Agent': self.USER_AGENT})
            self._vodi_session = session
        return self._vodi_session

    def _vodi_post(self, path: str, payload: dict) -> 'requests.Response':
        session = self._vodi_session_get()
        return session.post(f'{self._VODI_BASE}{path}', data=json.dumps(payload), verify=False, timeout=10)

    def _vodi_do_login(self) -> Optional[str]:
        try:
            resp = self._vodi_post('/auth/login', {
                'username': self.username, 'password': self.password,
                'deviceName': 'Filman Desktop', 'devicePlatform': 'desktop',
                'deviceType': 'pc', 'appVersion': '2.0.2',
            })
            fflog(f'vodi: login status={resp.status_code}')
            if resp.status_code == 429:
                fflog('vodi: 429 on login — abort')
                return None
            if resp.status_code in (200, 201):
                data = resp.json()
                auth = {'access_token': data['token'], 'refresh_token': data.get('refreshToken', ''), 'is_free': False}
                cache.cache_insert('filman_vodi_auth', json.dumps(auth), control.providercacheFile)
                fflog('vodi: login ok (premium)')
                return auth['access_token']
            if resp.status_code in (401, 403):
                cache.cache_insert('filman_vodi_auth', json.dumps({'is_free': True}), control.providercacheFile)
                fflog('vodi: free user — caching for 2h')
        except Exception:
            fflog_exc()
        return None

    def _vodi_relogin(self) -> Optional[str]:
        fflog('vodi: 401 — clearing cached token, re-login')
        if hasattr(self, '_vodi_access_token'):
            del self._vodi_access_token
        cache.cache_insert('filman_vodi_auth', json.dumps({'is_free': False}), control.providercacheFile)
        new_token = self._vodi_do_login()
        if new_token:
            self._vodi_access_token = new_token
        return new_token

    def _vodi_do_refresh(self, refresh_token: str) -> Optional[str]:
        try:
            resp = self._vodi_post('/auth/token/refresh', {'refreshToken': refresh_token})
            if resp.status_code == 429:
                fflog('vodi: 429 on refresh — abort')
                return None
            if resp.status_code == 200:
                data = resp.json()
                auth = {'access_token': data['token'], 'refresh_token': data.get('refreshToken', refresh_token), 'is_free': False}
                cache.cache_insert('filman_vodi_auth', json.dumps(auth), control.providercacheFile)
                fflog('vodi: token refreshed')
                return auth['access_token']
        except Exception:
            fflog_exc()
        return self._vodi_do_login()

    def _vodi_search(self, media_type: str, queries: List[str], alias_titles: List[str], year: str, imdb: str = '') -> Optional[dict]:
        cache_key = f'filman_vodi_id_{media_type}_{imdb}' if imdb else None
        if cache_key:
            cached = cache.cache_get(cache_key, control.providercacheFile)
            if cached and 'date' in cached and cache._is_cache_valid(int(cached['date']), 24):
                try:
                    entry = json.loads(cached['value'])
                    if entry.get('not_found'):
                        fflog(f'vodi: cache hit {cache_key} (not_found)')
                        return None
                    fflog(f'vodi: cache hit {cache_key} id={entry.get("id")}')
                    return entry
                except Exception:
                    fflog_exc()

        token = self._vodi_token()
        if not token:
            return None
        endpoint = f'{self._VODI_BASE}/{"movies" if media_type == "movie" else "series"}/search'
        year_int = int(year) if year else 0
        alias_cleans = [cleantitle.get_simple(a) for a in alias_titles if a]
        _token_refreshed = False
        session = self._vodi_session_get()

        for query in queries:
            try:
                payload = json.dumps({
                    'filters': [{'type': 'title', 'condition': 'contains', 'payload': query}],
                    'sorts': [], 'page': 1, 'itemsPerPage': 20,
                })
                headers = {'Authorization': f'Bearer {token}'}
                resp = session.post(endpoint, data=payload, headers=headers, verify=False, timeout=10)
                fflog(f'vodi: search {media_type} {query!r} → {resp.status_code}')
                if resp.status_code == 429:
                    fflog('vodi: 429 on search — abort (no cache write)')
                    return None
                if resp.status_code == 401 and not _token_refreshed:
                    _token_refreshed = True
                    new_token = self._vodi_relogin()
                    if new_token:
                        token = new_token
                        headers = {'Authorization': f'Bearer {token}'}
                        resp = session.post(endpoint, data=payload, headers=headers, verify=False, timeout=10)
                        fflog(f'vodi: retry → {resp.status_code}')
                        if resp.status_code == 429:
                            fflog('vodi: 429 on retry — abort')
                            return None
                if resp.status_code not in (200, 201):
                    continue
                all_items = resp.json().get('items', [])
                for item in all_items:
                    if year_int and abs(int(item.get('year') or 0) - year_int) > 1:
                        continue
                    item_parts = [cleantitle.get_simple(p.strip()) for p in item.get('title', '').split('/') if p.strip()]
                    for ac in alias_cleans:
                        for part in item_parts:
                            if ac == part or source_utils._levenshtein(ac, part) <= 2:
                                fflog(f'vodi: {media_type} match id={item["id"]} title={item.get("title")!r}')
                                if cache_key:
                                    cache.cache_insert(cache_key, json.dumps({
                                        'id': item['id'],
                                        'title': item.get('title', ''),
                                        'quality': item.get('quality', ''),
                                        'availableQualities': item.get('availableQualities', []),
                                        'version': item.get('version', ''),
                                        'available': item.get('available', True),
                                    }), control.providercacheFile)
                                return item
            except Exception:
                fflog_exc()

        if cache_key:
            cache.cache_insert(cache_key, json.dumps({'not_found': True}), control.providercacheFile)
            fflog(f'vodi: cached negative {cache_key}')
        return None

    def _vodi_find_episode(self, series_id: int, season: str, episode: str, absolute: int, token: str) -> Optional[Dict[str, Any]]:
        cache_key = f'filman_vodi_series_{series_id}'
        seasons = None
        cached = cache.cache_get(cache_key, control.providercacheFile)
        if cached and 'date' in cached and cache._is_cache_valid(int(cached['date']), 24):
            try:
                seasons = json.loads(cached['value'])
                fflog(f'vodi: cache hit {cache_key}')
            except Exception:
                fflog_exc()
                seasons = None

        if seasons is None:
            try:
                session = self._vodi_session_get()
                series_endpoint = f'{self._VODI_BASE}/series/{series_id}'
                resp = session.get(series_endpoint,
                                   headers={'Authorization': f'Bearer {token}'}, verify=False, timeout=10)
                if resp.status_code == 429:
                    fflog(f'vodi: 429 on /series/{series_id} — abort')
                    return None
                if resp.status_code == 401:
                    new_token = self._vodi_relogin()
                    if not new_token:
                        return None
                    token = new_token
                    resp = session.get(series_endpoint,
                                       headers={'Authorization': f'Bearer {token}'}, verify=False, timeout=10)
                    fflog(f'vodi: /series/{series_id} retry → {resp.status_code}')
                    if resp.status_code == 429:
                        return None
                if resp.status_code not in (200, 201):
                    return None
                seasons = resp.json().get('seasons', {})
                cache.cache_insert(cache_key, json.dumps(seasons), control.providercacheFile)
                fflog(f'vodi: cached {cache_key} ({len(seasons)} seasons)')
            except Exception:
                fflog_exc()
                return None

        try:
            season_eps = seasons.get(str(int(season)), [])
            for ep in season_eps:
                if str(ep.get('episode', '')) == str(int(episode)):
                    return ep
            # Anime fallback: absolute episode number in s01
            if absolute > 0:
                for ep in seasons.get('1', []):
                    if ep.get('episode') == absolute:
                        return ep
        except Exception:
            fflog_exc()
        return None

    @staticmethod
    def _normalize_vodi_quality(raw_quality: str) -> str:
        # vodi marketing label 'HD' = 1080p; source_utils.get_quality treats bare 'HD' as SD
        cleaned = (raw_quality or '').strip()
        if not cleaned:
            return '720p'
        if cleaned.upper() == 'HD':
            return '1080p'
        return source_utils.get_quality(cleaned)

    def _vodi_signed_link(self, source_target: str, source_id: int) -> Optional[str]:
        token = self._vodi_token()
        if not token:
            return None
        try:
            session = self._vodi_session_get()
            payload = {
                'sourceTarget': source_target, 'sourceId': int(source_id),
                'data': {'quality': 'auto'},
            }
            _token_refreshed = False
            for code in self._VODI_STRATEGIES:
                payload['code'] = code
                headers = {'Authorization': f'Bearer {token}'}
                resp = session.post(f'{self._VODI_BASE}/signed-links',
                                    data=json.dumps(payload), headers=headers, verify=False, timeout=10)
                if resp.status_code == 429:
                    fflog('vodi: 429 on signed-link — abort')
                    return None
                if resp.status_code == 401 and not _token_refreshed:
                    _token_refreshed = True
                    new_token = self._vodi_relogin()
                    if not new_token:
                        return None
                    token = new_token
                    headers = {'Authorization': f'Bearer {token}'}
                    resp = session.post(f'{self._VODI_BASE}/signed-links',
                                        data=json.dumps(payload), headers=headers, verify=False, timeout=10)
                    fflog(f'vodi: signed-link {code} retry → {resp.status_code}')
                    if resp.status_code == 429:
                        return None
                if resp.status_code in (200, 201):
                    url = resp.json().get('url')
                    if url:
                        fflog(f'vodi: signed-link ok code={code}')
                        return url
                fflog(f'vodi: signed-link {code} → {resp.status_code}')
        except Exception:
            fflog_exc()
        return None

    def _apply_cookie_settings(self):
        bkd = settings.getString('filman.cookies_bkd').strip()
        user_id = settings.getString('filman.cookies_user_id').strip()
        cf = settings.getString('filman.cookies_cf').strip()
        if bkd:
            self.session.cookies.set('BKD_REMEMBER', bkd, domain='filman.cc')
        if user_id:
            self.session.cookies.set('user_id', user_id, domain='filman.cc')
        if cf:
            self.session.cookies.set('cf_clearance', cf, domain='.filman.cc')
        has_cookies = bool(bkd or cf or user_id)
        fflog(f"cookies: {'bkd=' + bkd[:6] + '…' if bkd else ''}"
              f"{' uid=' + user_id if user_id else ''}"
              f"{' cf=' + cf[:6] + '…' if cf else ''}"
              f"{' (none)' if not has_cookies else ''}")
        return has_cookies

    def _purge_old_episode_cache(self):
        try:
            cutoff = int(time.time()) - 86400
            cursor = cache._get_connection_cursor_providers()
            cursor.execute(
                "DELETE FROM cache WHERE (key LIKE 'filman_eps_%' OR key LIKE 'filman_vodi_id_%' OR key LIKE 'filman_vodi_series_%') AND date < ?",
                (cutoff,))
            deleted = cursor.rowcount
            cursor.connection.commit()
            if deleted:
                fflog(f"cache: purged {deleted} expired filman_eps_* entries")
        except Exception:
            fflog_exc()

    def _process_sound(self, sound_string: str) -> Tuple[str, str]:
        sound_string = sound_string.replace('Napisy_Tansl', 'napisy').replace('_', ' ')
        language_code = 'en' if 'ENG' in sound_string else 'pl'
        return sound_string.replace('PL', '').replace('ENG', '').strip() or ' ', language_code

    def _parse_time_string(self, time_string: str) -> float:
        time_match = re.match(r'(?:\b(\d+)\b\s+)?(\w+)', time_string)
        if not time_match:
            return float('inf')
        numeric_value, time_unit = time_match.groups()
        multiplier = self.TIME_UNITS.get(time_unit)
        return (int(numeric_value) if numeric_value else 1) * multiplier if multiplier else float('inf')

    def _normalize_hosting_name(self, domain: str) -> str:
        for suffix, name in self.HOSTING_MAP.items():
            if suffix in domain:
                return name
        parts = domain.rsplit('.', 2)
        if len(parts) >= 3:
            return f"{parts[-2]}.{parts[-1]}"
        return domain

    def _extract_video_info(self, row_html: str, page_content: str) -> dict[str, Any]:
        iframe_match = self.RE_IFRAME.findall(row_html)
        mp4_links = self.RE_HREF_MP4.findall(row_html)
        td_cells = self.RE_TD.findall(row_html)
        if len(td_cells) < 3:
            return {}

        is_premium, video_url = False, ''
        if mp4_links:
            video_url = base64.b64decode(mp4_links[0]).decode('utf-8').replace('\\/', '/')
            if not any(video_url.lower().endswith(ext) for ext in ('.m3u8', '.mp4', '.ts')):
                token_match = re.search(r"attr\('href'\)\)\s*\+\s*'([^']+)'", page_content)
                video_url += token_match.group(1) if token_match else ''
            video_url += f"|referer={self.base_link}&user-agent=Mozilla"
            is_premium = True
        elif iframe_match:
            decoded_iframe = base64.b64decode(iframe_match[0]).decode('utf-8').replace('\\/', '/')
            src_match = re.findall(r"src['\"]:['\"](.+?)['\"]", decoded_iframe)
            video_url = src_match[0] if src_match else decoded_iframe
        elif link_id_m := self.RE_LINK_ID.search(row_html):
            video_url = f"{self.base_link}/link/go/{link_id_m.group(1)}"

        if not video_url:
            return {}

        if '|' in video_url:
            video_url += f"&rt={getattr(self, '_rt_token', '')}"
        else:
            video_url += f"|rt={getattr(self, '_rt_token', '')}&referer={self.base_link}"

        sound_info, language_code = self._process_sound(td_cells[1].strip())
        if is_premium:
            host_name = urlparse(video_url.split('|')[0]).hostname or ''
        else:
            host_m = re.search(r'alt="(.*?)"', td_cells[0])
            host_name = host_m.group(1) if host_m else ''
        ago_m = re.search(r'dodane\s+(.*?temu)', td_cells[0], re.S)

        return {
            'host': self._normalize_hosting_name(host_name or ''),
            'url': video_url,
            'is_premium': is_premium,
            'quality': source_utils.check_sd_url(td_cells[2].strip()),
            'sound': sound_info,
            'lang': language_code,
            'ago': ago_m.group(1).strip() if ago_m else ''
        }


# ─── Filman ──────────────────────────────────────────────────────────────────────

class Filman(_source):
    """Free path scraper for filman.cc (HTML scraping with cookies)."""
    PROVIDER = 'filman'

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str, **kwargs) -> Optional[Tuple]:
        self.init()
        fflog(f"searching: {title!r} ({year}) imdb={imdb!r}")
        if not self.is_logged_in():
            return None
        alias_titles = source_utils.build_alias_list(title, localtitle, aliases, year)
        queries = list(source_utils.search_queries(title, localtitle))
        for search_title in queries:
            now = time.time()
            elapsed = now - _source._LAST_SEARCH_TIME
            if 0 < elapsed < 0.5:
                time.sleep(0.5 - elapsed)
            _source._LAST_SEARCH_TIME = time.time()

            fflog(f"query: {search_title!r}")
            page = self.session.get(self.search_link.format(title=quote_plus(search_title)), verify=False).text
            result = self._match_results(page, search_title, alias_titles, year, 'movie')
            fflog(f"match: {result}")
            if result:
                return (result[0], result[1], str(imdb) if imdb else '')
        return None

    def episode(self, url: ShowDataDict, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[Tuple]:
        self.init()
        if not self.is_logged_in():
            return None
        tmdb = self.ffitem.show_item.tmdb_id
        data = ShowData(**url)
        episode_number_str = source_utils.format_episode_key(season, episode)
        absolute_episode_number = self.ffitem.absolute_episode_number()
        alias_titles = source_utils.build_alias_list(data.title, data.local_title, data.aliases, data.year)
        queries = list(source_utils.search_queries(data.title, data.local_title))

        filman_match = self._filman_episode_url(
            tmdb, data.title, episode_number_str, absolute_episode_number or 0,
            queries, alias_titles, data.year)
        if filman_match:
            return (filman_match[0], filman_match[1], str(imdb) if imdb else '', int(season), int(episode))
        fflog(f"no match: {data.title!r}")
        return None

    def sources(self, url: Optional[Tuple], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        self.init()
        if not url:
            return []
        try:
            url = url[0] if isinstance(url, tuple) else url
            if not self.is_logged_in():
                return []
            episode_path = urlparse(url).path
            fflog(f"GET {url}")
            page_html = self.session.get(url, verify=False).text
            
            rt_m = re.search(r"var (?:rt|routeToken)\s*=\s*'([^']+)'", page_html)
            if rt_m:
                self._rt_token = rt_m.group(1)

            table = parseDOM(page_html, 'table', attrs={'id': 'links'})
            if not table:
                fflog(f"no #links table at {url}")
                return []

            rows = table[0].split('<tr')[1:]
            video_info_list = []
            for row_html in rows:
                video_info = self._extract_video_info(row_html, page_html)
                if video_info and not video_info.get('is_premium'):
                    video_info_list.append(video_info)

            fflog(f"sources: {len(video_info_list)}")
            video_info_list.sort(key=lambda x: self._parse_time_string(x.get('ago', '')))

            return [
                {
                    'source': v['host'],
                    'url': v['url'],
                    'quality': v['quality'],
                    'language': v['lang'],
                    'info': v['sound'].strip(),
                    'filename': f"{v['ago']} | {episode_path}",
                    'direct': False,
                    'debridonly': False,
                    'premium': False,
                }
                for v in video_info_list
            ]
        except Exception:
            fflog_exc()
            return []


# ─── FilmanPremium ───────────────────────────────────────────────────────────────

class FilmanPremium(_source):
    """Premium scraper using cloud.vodi.cc API (independent of filman.cc cookies)."""
    PROVIDER = 'filmanpremium'
    has_sort_order = True
    has_color_identify2 = True
    use_premium_color = True

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str, **kwargs) -> Optional[Tuple]:
        self.init()
        fflog(f"searching: {title!r} ({year}) imdb={imdb!r}")
        token = self._vodi_token()
        fflog(f"vodi: token={'ok' if token else 'none (free/expired trial)'}")
        if not token:
            return None
        alias_titles = source_utils.build_alias_list(title, localtitle, aliases, year)
        queries = list(source_utils.search_queries(title, localtitle))
        item = self._vodi_search('movie', queries, alias_titles, year, imdb=imdb)
        if not item:
            return None
        if not item.get('available', True):
            fflog(f"vodi: movie id={item['id']} marked unavailable — skip premium")
            return None
        raw_quality = (item.get('quality') or (item.get('availableQualities') or [''])[0] or '').strip()
        quality = self._normalize_vodi_quality(raw_quality)
        version = item.get('version', '')
        cloudvodi_url = f"cloudvodi:movie:{item['id']}:{quality}:{version}"
        return (cloudvodi_url, item.get('title', title), str(imdb) if imdb else '')

    def episode(self, url: ShowDataDict, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[Tuple]:
        self.init()
        token = self._vodi_token()
        fflog(f"vodi: token={'ok' if token else 'none (free/expired trial)'}")
        if not token:
            return None
        data = ShowData(**url)
        episode_number_str = source_utils.format_episode_key(season, episode)
        absolute_episode_number = self.ffitem.absolute_episode_number()
        alias_titles = source_utils.build_alias_list(data.title, data.local_title, data.aliases, data.year)
        queries = list(source_utils.search_queries(data.title, data.local_title))

        item = self._vodi_search('series', queries, alias_titles, data.year, imdb=imdb)
        if not item:
            return None
        ep = self._vodi_find_episode(item['id'], season, episode, absolute_episode_number or 0, token)
        if not ep:
            fflog(f"vodi: series {item['id']} found but {episode_number_str} not in API")
            return None
        if not ep.get('available', True):
            fflog(f"vodi: ep id={ep['id']} marked unavailable — skip premium")
            return None
        raw_quality = (ep.get('availableQualities') or [''])[0]
        quality = self._normalize_vodi_quality(raw_quality)
        version = item.get('version', '')
        ep_title = f"{item.get('title', data.title)} {episode_number_str}"
        vodi_url = f"cloudvodi:series:{ep['id']}:{quality}:{version}"
        return (vodi_url, ep_title, str(imdb) if imdb else '', int(season), int(episode))

    def sources(self, url: Optional[Tuple], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        self.init()
        if not url:
            return []
        try:
            url = url[0] if isinstance(url, tuple) else url
            if not (isinstance(url, str) and url.startswith('cloudvodi:')):
                return []
            vodi_part, _, _ = url.partition('|')
            parts = vodi_part.split(':', 4)
            source_target = parts[1]
            source_id = int(parts[2])
            quality = parts[3] if len(parts) > 3 and parts[3] else '1080p'
            version = parts[4] if len(parts) > 4 else ''
            direct = self._vodi_signed_link(source_target, source_id)
            if not direct:
                return []
            return [{
                'source': 'vodi.cc',
                'url': direct,
                'quality': quality or '1080p',
                'language': 'pl',
                'info': version,
                'filename': '',
                'direct': True,
                'debridonly': False,
                'premium': True,
            }]
        except Exception:
            fflog_exc()
            return []


def register(sources, group: str) -> None:
    """Register filman free + premium scrapers based on settings toggles."""
    from lib.sources import SourceModule
    for cls in (FilmanPremium, Filman):
        if settings.getBool(f"provider.{cls.PROVIDER}") or const.dev.sources.force_all_sources:
            sources.append(SourceModule(name=cls.PROVIDER, provider=cls(), group=group))
