"""Nothing to do, force import `lib`, it's enough."""
