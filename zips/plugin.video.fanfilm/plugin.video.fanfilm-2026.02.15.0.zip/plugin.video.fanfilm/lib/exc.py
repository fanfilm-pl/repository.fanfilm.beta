

class DeprecatedError(BaseException):
    """Deprecated, method shoudn't be uesed."""
