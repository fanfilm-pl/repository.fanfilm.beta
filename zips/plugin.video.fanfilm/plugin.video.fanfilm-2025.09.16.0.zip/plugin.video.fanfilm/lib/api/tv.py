"""
Simple TV scrappers.

Now supports:
- filmweb.pl
- programtv.onet.pl
"""

from __future__ import annotations
from typing import Optional, Union, Any, Sequence, Iterator, Iterable, ClassVar
from typing_extensions import Literal, TypeAlias, Pattern, Match, TypeVar
import re
from html import unescape
import json
from attrs import define, field, fields

from ..defs import Pagina, ItemList
from ..ff.item import FFItem
from .tmdb import TmdbApi
from ..ff.tmdb import tmdb
from ..ff.calendar import fromisoformat, datetime, dt_date, dt_time, timedelta
from ..ff.control import max_thread_workers
from ..ff import requests
from ..ff.requests import RequestsPoolExecutor
from ..ff.log_utils import fflog
from ..ff.debug.timing import logtime
from ..ff.types import JsonData, PagedItemList
from const import const


TvServiceName: TypeAlias = Literal['filmweb', 'onet']


@define(kw_only=True)
class TvMovie:
    #: FilmWeb ID
    id: str
    #: Title (PL)
    title: str
    #: Movie year
    year: int
    #: TV air time.
    time: datetime
    #: TV channel.
    channel: str
    #: Image URL.
    image: str
    #: URL to media details.
    url: str = ''
    #: Description
    descr: str = ''
    #: Country codes (iso 3166-1)
    countries: set[str] = field(factory=set)
    #: Extra info (used by service)
    service_data: dict[str, Any] | None = None

    def role(self) -> str:
        time = f'{self.time:%H:%M}' if self.time and self.time != self.time.min else ''
        if time and self.channel:
            return f'{time:0>5}, {self.channel}'
        if time:
            return f'{time:0>5}'
        return self.channel


P = TypeVar('P', bound=PagedItemList[TvMovie])


class TvProgram:
    """Base for TV scrappers."""

    SERVICES: ClassVar[dict[str, 'TvProgram']] = {}
    RX_CHAN_SIMPLIFY: ClassVar[Pattern[str]] = re.compile(r'(.+)\s+(\d+)(?: PREMIUM)?(?: HD)?')

    #: Days to look ahead.
    DAY_RANGE = range(0, 1)

    def __init__(self, *, tmdb: TmdbApi) -> None:
        self.tmdb: TmdbApi = tmdb
        self.cache: dict[str, TvMovie] = {}
        self._session: requests.Session | None = None

    @classmethod
    def tv_service(cls, service: TvServiceName) -> Optional['TvProgram']:
        """Get tv program service by name."""
        return cls.SERVICES.get(service)

    @property
    def session(self) -> requests.Session:
        """Requests session (with keep-alive)."""
        if self._session is None:
            self._session = requests.Session(cache='search')
            self._session.headers.update({'Connection': 'keep-alive'})
        return self._session

    def _tv_movie_iter(self, *, day_offset: int = 0, **_) -> Iterator[TvMovie]:
        raise NotImplementedError(f'class {self.__class__.__name__} has no _tv_movie_iter()')

    def _tv_ffitems(self, tv: TvMovie, *, details: bool = False) -> Sequence[FFItem]:
        """Get items for single TV movie."""
        def select1(items: Iterable[FFItem]) -> Iterator[FFItem]:
            """Select by year (±1)."""
            for it in items:
                if not it.year or not tv.year or it.year in range(tv.year - 1, tv.year + 2):
                    yield it

        def select2(items: Iterable[FFItem]) -> Iterator[FFItem]:
            """Select by countries, after ffinto.get_items()."""
            role = tv.role()
            for it in items:
                if not tv.countries or not (ff_countries := it.vtag.getCountryCodes()) or (tv.countries & set(ff_countries)):
                    if role:
                        it.role = role
                    yield it

        if tv.year:
            # tv_years = [tv.year, tv.year + 1, tv.year - 1, 0]  # try year range or no year
            tv_years = [tv.year, 0]  # try year and no year
        else:
            tv_years = [0]  # no year in tv
        for tv_year in tv_years:
            kwargs = {}
            if tv_year:
                kwargs['year'] = tv_year
            fflog.debug(f'[tv] Searching {tv.title!r} ({tv_year}), countries={tv.countries}')
            if items := list(select1(self.tmdb.search(query=tv.title, type='movie', **kwargs))):
                if details:
                    from ..ff.info import ffinfo
                    items = ffinfo.get_items(items)
                if items := list(select2(items)):
                    return items
        return []

    def _get_info(self, items: P) -> P:
        return items

    def _tv_item(self, id: str, *, day_offset: int = 0) -> Optional[TvMovie]:
        """Get single TV movie by ID."""
        return self.cache.get(id)

    def fix_channel_name(self, channel: str) -> Iterable[str]:
        """Fix/simplify/normalize channel name."""
        yield channel
        if mch := self.RX_CHAN_SIMPLIFY.fullmatch(channel):
            yield f'{mch[1]}{mch[2]}'
        if not channel.endswith(' HD'):
            yield f'{channel} HD'
        if not channel.endswith(' PREMIUM'):
            yield f'{channel} PREMIUM'

    def channel_names(self) -> list[str]:
        """Get list of enabled channel names."""
        return [name for ch in const.indexer.movies.tv.channels or () for name in self.fix_channel_name(ch)]

    def _tv_movies(self, *, day_offset: int = 0) -> Iterable[TvMovie]:
        """Get today (±day_offset) in TV movies."""
        tv_list = tuple(self._tv_movie_iter(day_offset=day_offset))
        self.cache = {tv.id: tv for tv in tv_list}
        # remove duplicates (same title+year)
        channels_order = {ch: idx for idx, ch in enumerate(self.channel_names() or ())}
        tv_list = sorted(tv_list, key=lambda tv: (channels_order.get(tv.channel, 9999), tv.time), reverse=True)
        tv_list = {(tv.title, tv.year): tv for tv in tv_list}.values()
        # sort by time (and channel, title if the same)
        if const.indexer.movies.tv.sort_by == 'aired_date':
            tv_list = sorted(tv_list, key=lambda tv: (tv.time, tv.title, tv.channel))
        elif const.indexer.movies.tv.sort_by == 'title':
            tv_list = sorted(tv_list, key=lambda tv: (tv.title, tv.channel, tv.time))
        else:
            pass  # keep order
        return tv_list

    def tv_movies(self, *, page: int = 1, limit: int = 20, day_offset: int = 0) -> Pagina[TvMovie]:
        """Get today ± day_offset in TV movies as page."""
        tv_list = self._tv_movies(day_offset=day_offset)
        return self._get_info(Pagina(tv_list, page=page, limit=limit))

    def tv_movie_all_items(self, *, page: int = 1, limit: int = 20, day_offset: int = 0) -> PagedItemList[FFItem]:
        """Get today in TV movies."""
        tv_list = self._tv_movies(day_offset=day_offset)
        # tv_list = self._tv_movie_iter(day_offset=day_offset)
        tv_list = Pagina(tv_list, page=page, limit=limit)
        # get more info about this page
        tv_list = self._get_info(tv_list)
        # search movies in this page
        with RequestsPoolExecutor(max_thread_workers()) as ex:
            list_of_items = ex.map(self._tv_ffitems, tv_list)
        return ItemList((it for items in list_of_items for it in items), page=page, total_pages=tv_list.total_pages)

    def tv_movie_items(self, id: str, *, day_offset: int = 0) -> Sequence[FFItem]:
        """Get movies for single (TV) movie."""
        if not (tv := self._tv_item(id, day_offset=day_offset)):
            self.tv_movies(page=1, limit=1_000_000_000)
            tv = self.cache.get(id)
        if tv:
            return self._tv_ffitems(tv, details=True)
        return []

    def tv_movie_mixed_items(self, *, page: int = 1, limit: int = 20, day_offset: int = 0) -> PagedItemList[Union[FFItem, TvMovie]]:
        """Get today in TV movies."""
        tv_list = self.tv_movies(page=page, limit=limit, day_offset=day_offset)
        with RequestsPoolExecutor(max_thread_workers()) as ex:
            list_of_items = ex.map(self._tv_ffitems, tv_list)
        return ItemList((items[0] if len(items) == 1 else tv for tv, items in zip(tv_list, list_of_items) if items),
                        page=page, total_pages=tv_list.total_pages)


class FilmWebTv(TvProgram):
    """Tiny filmweb.pl TV provider (uses JSON API)."""

    #: Days to look ahead. Filmweb range is -1..12
    DAY_RANGE = range(-1, 13)

    URL_CHANNELS = 'https://www.filmweb.pl/api/v1/channels'
    URL_TVGUIDE = 'https://www.filmweb.pl/api/v1/channels/{channel_id}/tv-guide'
    URL_TITLE = 'https://www.filmweb.pl/api/v1/title/{id}/info'
    URL_PREVIEW = 'https://www.filmweb.pl/api/v1/film/{id}/preview'
    URL_POSTER = 'https://fwcdn.pl/fpo{path}'
    URL_LANDSCAPE = 'https://fwcdn.pl/fph{path}'  # '$' need to be replaced

    TYPE_MOVIE = 1
    TYPE_SERIES = 2
    TYPE_TVSHOW = 6

    def __init__(self, *, tmdb: TmdbApi) -> None:
        super().__init__(tmdb=tmdb)
        self.url: str = 'https://www.filmweb.pl/program-tv'

    @requests.netcache('search')
    def _tv_movie_iter(self, *, day_offset: int = 0, channel_id: int | str | None = None, **_) -> Iterator[TvMovie]:
        """Get today in TV movies."""

        def get_channel(channel_id: int) -> list[JsonData]:
            resp = self.session.get(self.URL_TVGUIDE.format(channel_id=channel_id), params={'date': date})
            if 200 <= resp.status_code <= 299:
                return resp.json()
            return []

        date = (dt_date.today() + timedelta(days=day_offset)).isoformat()
        with logtime(name='[filmweb] channel list'):
            if channel_id:
                channel_id = int(channel_id)
                channels = {it['id']: it for it in self.session.get(self.URL_CHANNELS).json() if it['id'] == channel_id}
            else:
                channel_list = self.session.get(self.URL_CHANNELS).json()
                if tv_channels := self.channel_names():
                    enabled = set(tv_channels)
                    channel_list = [it for it in channel_list if it.get('name') in enabled]
                # channel_list = channel_list[:35]  # hard limit
                channels = {it['id']: it for it in channel_list}
        with logtime(name='[filmweb] channels'):
            with RequestsPoolExecutor(max_thread_workers()) as ex:
                all_items = [it for channel_items in ex.map(get_channel, channels) for it in channel_items]

        # only movies
        items = [it for it in all_items if it.get('type') == self.TYPE_MOVIE]

        # collect movie data (year..)
        # with logtime(name='[filmweb] titles'):
        #     with RequestsPoolExecutor(max_thread_workers()) as ex:
        #         need_info = (title_id for it in items if (title_id := it.get('film')))
        #         infos = {it['id']: it for it in ex.map(get_info, need_info) if it}

        # result
        fflog(f'[filmweb] Found {len(channels)} channels, {len(all_items)} TV items, {len(items)} TV movies')
        # fflog(f'[filmweb] Found {len(channels)} channels, {len(all_items)} TV items, {len(items)} TV movies, {len(infos)} titles')
        # print(json.dumps([it for it in items if 'film' not in it], indent=2))
        # return
        for it in items:
            cid = it['channel']
            channel = channels.get(cid, {})
            start_time = fromisoformat(it['zonedStartTime'])
            if title_id := it.get('film'):
                iid = str(title_id)
            elif not const.indexer.movies.tv.filmweb.show_non_id:
                iid = f'{cid}-{start_time:%Y%m%d-%H%M}'
            else:
                continue
            yield TvMovie(id=iid, title=it['title'], year=0, time=start_time,
                          channel=channel.get('name') or '', image='', descr=it.get('notes') or '')

    # @requests.netcache('search')
    def _get_info(self, items: P) -> P:

        # def get_info(title_id: int) -> Optional[JsonData]:
        #     resp = self.session.get(self.URL_TITLE.format(id=title_id))
        #     if 200 <= resp.status_code <= 299:
        #         return resp.json()
        #     return None

        def get_info(title_id: int) -> Optional[JsonData]:
            resp = self.session.get(self.URL_PREVIEW.format(id=title_id))
            if 200 <= resp.status_code <= 299:
                data = resp.json()
                data.setdefault('id', title_id)
                return data
            return None

        # collect movie data (year..)
        with logtime(name='[filmweb] titles'):
            with RequestsPoolExecutor(max_thread_workers()) as ex:
                need_info = (int(tv.id) for tv in items if tv.id.isdecimal())
                infos = {it['id']: it for it in ex.map(get_info, need_info) if it}

        # apply ino (year)
        for tv in items:
            if tv.id.isdecimal() and (info := infos.get(int(tv.id))):
                tv.year = info.get('year') or 0
                # if poster := info.get('posterPath'):  # from URL_TITLE
                #     tv.image = self.URL_POSTER.format(path=poster)
                if poster := info.get('poster', {}).get('path'):  # from URL_PREVIEW
                    tv.image = self.URL_POSTER.format(path=poster)
                if title := info.get('title', {}).get('title'):
                    tv.title = title
                elif title := info.get('originalTitle', {}).get('title'):
                    tv.title = title
                if descr := info.get('plotOrDescriptionSynopsis'):
                    tv.descr = descr
                if countries := info.get('countries'):
                    tv.countries = {c.get('code') for c in countries if c.get('code')}

        return items

    def _tv_item(self, id: str, *, day_offset: int = 0) -> Optional[TvMovie]:
        """Get single TV movie by ID."""
        if id not in self.cache:
            if id.isdecimal():
                tv_list = self._get_info(Pagina.single([TvMovie(id=id, title='', year=0, time=datetime.min, channel='', image='')]))
            else:
                tv_list = tuple(self._tv_movie_iter(channel_id=id.partition('-')[0], day_offset=day_offset))
            self.cache.update({tv.id: tv for tv in tv_list})
        return self.cache.get(id)


class OnetTv(TvProgram):
    """Tiny programtv.onet.pl TV scraper."""

    #: Days to look ahead. Onet range is -1..12
    DAY_RANGE = range(-1, 13)

    ONET_CHANNEL_PAGE_COUNT = const.indexer.movies.tv.onet.channel_page_count  # onet has pages 1..9
    TV_URL = 'https://programtv.onet.pl/filtr/film?dzien={day}'  # &strona=2
    ENTRY_URL = 'https://programtv.onet.pl/tv/{entry_url}'
    _rx_page_channels = re.compile(r'<span\s+class="tvLogo">\s*<img\b[^>]*alt="([^"]*)"', re.DOTALL)
    _rx_page_tv_box = re.compile(r'<div\s+class="partTvv\b(.*?)</div>\s*</div>\s*</div>', re.DOTALL)
    _rx_page_tv_channel = re.compile(r'<ul\s+class="channelStripe\b(.*?)</ul>', re.DOTALL)
    _rx_page_tv_prog = re.compile(r'<li\b[^>]*>\s*<a\s+href="(?P<url>[^"]*)".*?<span\s+class="title">(?P<title>[^<]*)\s*<.*?'
                                  r'<span class="type">(?P<descr>[^<]*)\s*<.*?<span class="hour">\s*(?P<time>[:0-9]+)\s*</span>.*?</a>', re.DOTALL)
    _rx_page_tv_year = re.compile(r' (\d{4})(?:-\d{4}(?:/\w+)?)?$')
    _rx_page_tv_id = re.compile(r'/(\w[-\w]*(?:/\w+)?)(?:\?.*)?$')
    _rx_in_tv_descr = re.compile(r'\s*((?P<genre>[^<,]*),)?\s*(?P<country>[^<]*)\s+(?P<year>\d{4})\s*')

    def __init__(self, *, tmdb: TmdbApi) -> None:
        super().__init__(tmdb=tmdb)

    @requests.netcache('search')
    def _tv_movie_iter(self, *, day_offset: int = 0, **_) -> Iterator[TvMovie]:
        """Get today in TV movies."""
        def get(page: int = 1) -> Iterator[TvMovie]:
            url = self.TV_URL.format(day=day_offset)
            if page > 1:
                url += f'&strona={page}'
            page_content = self.session.get(url, headers={'Cookie': 'homepageVersion=tv'}).text
            rx = re.compile(r'\s+')
            channels = self._rx_page_channels.findall(page_content)
            for box in self._rx_page_tv_box.finditer(page_content):
                for chan_index, channel_stipe in enumerate(self._rx_page_tv_channel.finditer(box[1])):
                    channel = channels[chan_index] if chan_index < len(channels) else ''
                    for prog in self._rx_page_tv_prog.finditer(channel_stipe[1]):
                        url = prog['url']
                        title = rx.sub(' ', unescape(prog['title'])).strip()
                        descr = rx.sub(' ', unescape(prog['descr'])).strip()
                        time_str = prog['time'].strip()
                        if ' odc. ' in descr:
                            continue  # skip series
                        if m := self._rx_page_tv_year.search(descr):
                            year = int(m[1])
                        else:
                            year = 0
                        if m := self._rx_page_tv_id.search(url):
                            eid = m[1].replace('/', '_')
                        else:
                            eid = url
                            fflog(f'[TV][onet] Unknown program id for {url=}')
                        if time_str:
                            time = datetime.combine(date, dt_time.fromisoformat(time_str))
                            if time.hour < 3:
                                time += timedelta(days=1)
                        else:
                            time = datetime.min
                        yield TvMovie(id=eid, title=title, year=year, time=time,
                                      channel=channel, image='', url=url, descr=descr)

        date = dt_date.today()
        with RequestsPoolExecutor(const.indexer.movies.tv.onet.channel_worker_count or max_thread_workers()) as ex:
            yield from (it for ent in ex.map(get, range(1, self.ONET_CHANNEL_PAGE_COUNT + 1)) for it in ent)

    def _scan_tv_item(self, tv: TvMovie | None, id: str = '') -> Optional[TvMovie]:
        """Get single TV movie by ID."""
        def make_air(mch: Match[str]) -> tuple[str, datetime]:
            chan, date_str, time_str = map(str.strip, mch.group('chan', 'date', 'time'))
            date = datetime.strptime(f'{date_str} {time_str}', '%d.%m %H:%M')
            date = date.replace(year=today.year)
            if date.month == 1 and today.month == 12:
                date = date.replace(year=today.year + 1)  # program after new year (tomorrow and next days)
            elif date.month == 12 and today.month == 1:
                date = date.replace(year=today.year - 1)  # program before new year (yesterday)
            return chan, date

        today = dt_date.today()
        if not id and tv:
            id = tv.id
        url = self.ENTRY_URL.format(entry_url=id.replace('_', '/'))
        page = self.session.get(url).text
        if mch := self._rx_scan_entry_page.search(page):
            data = json.loads(mch[1])
            # print(json.dumps(data, indent=2))
            data = data[-1]
            air = datetime.min
            chan = ''
            if air_list := [make_air(m) for m in self._rx_scan_entry_time.finditer(page)]:
                channels_order = {ch: idx for idx, ch in enumerate(self.channel_names() or ())}
                air_list.sort(key=lambda v: (channels_order.get(v[0], 9999), v[1]))
                chan, air = air_list[0]
            new = TvMovie(id=id, url=self.ENTRY_URL.format(entry_url=id.replace('_', '/')),
                          title=data.get('name') or '', year=int(data.get('datePublished') or 0), time=air, channel=chan,
                          image=data.get('image', {}).get('url', ''), descr=data.get('description') or '')
            if tv is None:
                tv = new
            else:
                for fld in fields(TvMovie):
                    setattr(tv, fld.name, getattr(new, fld.name))
        return tv

    @requests.netcache('search')
    def _get_info(self, items: P) -> P:
        with RequestsPoolExecutor(max_thread_workers()) as ex:
            ex.map(self._scan_tv_item, items)
        return items

    _rx_scan_entry_page = re.compile(r'<script type="application/ld\+json">\s*(\[.*?\])\s*</script>', flags=re.DOTALL)
    _rx_scan_entry_time = re.compile((r'<li class="reRun">.*?<li class="nameTv">(?P<chan>[^<]+)<.*?'
                                      r'<li class="dateTv">\s*(?:<span>[^<]*</span>\s*)?(?P<date>[^<]+)<.*?'
                                      r'<li class="timeTv">\s*<span>(?P<time>[^<]+)<.*?</a>'), flags=re.DOTALL)

    def _tv_item(self, id: str, *, day_offset: int = 0) -> Optional[TvMovie]:
        """Get single TV movie by ID."""
        if id not in self.cache:
            if tv := self._scan_tv_item(None, id):
                self.cache[tv.id] = tv
        return self.cache.get(id)


TvProgram.SERVICES['filmweb'] = filmweb = FilmWebTv(tmdb=tmdb)
TvProgram.SERVICES['onet'] = onet = OnetTv(tmdb=tmdb)


if __name__ == '__main__':
    from ..ff.cmdline import DebugArgumentParser
    p = DebugArgumentParser()
    p.add_argument('service', nargs='?', choices=('filmweb', 'onet'), default='filmweb', help='tv service')
    args = p.parse_args()
    service = TvProgram.SERVICES[args.service]
    for x in service._tv_movie_iter():
        print(x)
    # for it in filmweb.tv_movie_all_items():
    #     print(it)
