# -*- coding: utf-8 -*-
"""
Shared resolver: vsembed.ru → HLS m3u8 via cloudnestra chain.

Flow:
  1. GET vsembed.ru/embed/... → rcp hash from iframe src
  2. GET cloudnestra.com/rcp/{hash} → prorcp hash from inline JS
  3. GET cloudnestra.com/prorcp/{hash} → tmstrN prefix + m3u8 path template
  4. Try CDN domains in order → return first working m3u8 URL with headers
"""

from __future__ import annotations

import re
from typing import List, Optional
from urllib.parse import quote

from lib.ff import requests
from lib.ff.source_utils import FF_UA
from lib.ff.log_utils import fflog, fflog_exc


_CDN_DOMAINS: List[str] = [
    "neonhorizonworkshops.com",
    "wanderlynest.com",
    "orchidpixelgardens.com",
    "cloudnestra.com",
]


def resolve_vsembed(embed_url: str) -> Optional[str]:
    """Resolve vsembed.ru/embed/... → direct HLS m3u8 URL|headers string."""
    try:
        sess = requests.Session()
        sess.headers.update({"User-Agent": FF_UA})

        resp = sess.get(embed_url, timeout=15, headers={"Referer": "https://vsembed.ru/"})
        iframe_m = re.search(r'id="player_iframe" src="//cloudnestra\.com/rcp/([^"]+)"', resp.text)
        if not iframe_m:
            fflog(f"cloudnestra: no rcp hash in {embed_url}")
            return None
        rcp_hash = iframe_m.group(1)

        resp2 = sess.get(
            f"https://cloudnestra.com/rcp/{rcp_hash}", timeout=15,
            headers={"Referer": embed_url},
        )
        prorcp_m = re.search(r"src: '/prorcp/([^']+)'", resp2.text)
        if not prorcp_m:
            fflog("cloudnestra: no prorcp hash")
            return None
        prorcp_hash = prorcp_m.group(1)

        resp3 = sess.get(
            f"https://cloudnestra.com/prorcp/{prorcp_hash}", timeout=15,
            headers={"Referer": f"https://cloudnestra.com/rcp/{rcp_hash}"},
        )
        content = resp3.text

        pass_m = re.search(r'pass_path = "//([^/]+)/rt_ping\.php"', content)
        tmstr_prefix = pass_m.group(1).split(".")[0] if pass_m else "tmstr5"

        path_m = re.search(r'https://[^.]+\.\{v\d+\}/pl/(H4sI[^ "]+)/master\.m3u8', content)
        if not path_m:
            fflog("cloudnestra: no m3u8 path in prorcp page")
            return None
        m3u8_path = path_m.group(1)

        for cdn in _CDN_DOMAINS:
            m3u8_url = f"https://{tmstr_prefix}.{cdn}/pl/{m3u8_path}/master.m3u8"
            try:
                r = sess.get(m3u8_url, timeout=10, headers={"Referer": "https://cloudnestra.com/"})
                if r.status_code == 200 and b"#EXTM3U" in r.content[:20]:
                    fflog(f"cloudnestra: resolved via {cdn}")
                    return (
                        f"{m3u8_url}|User-Agent={quote(FF_UA)}"
                        f"&Referer=https%3A%2F%2Fcloudnestra.com%2F"
                    )
            except Exception:
                pass

        fflog("cloudnestra: all CDN domains failed")
        return None
    except Exception:
        fflog_exc()
        return None


def resolve_rcp(rcp_hash: str, referer: str = "https://cloudnestra.com/") -> Optional[str]:
    """Resolve a cloudnestra rcp hash directly → HLS m3u8 URL|headers string.

    Use this when you already have the rcp hash (e.g. from vidsrc.me data-hash).
    """
    try:
        sess = requests.Session()
        sess.headers.update({"User-Agent": FF_UA})

        resp2 = sess.get(
            f"https://cloudnestra.com/rcp/{rcp_hash}", timeout=15,
            headers={"Referer": referer},
        )
        prorcp_m = re.search(r"src: '/prorcp/([^']+)'", resp2.text)
        if not prorcp_m:
            fflog(f"cloudnestra: no prorcp hash for rcp/{rcp_hash[:20]}")
            return None
        prorcp_hash = prorcp_m.group(1)

        resp3 = sess.get(
            f"https://cloudnestra.com/prorcp/{prorcp_hash}", timeout=15,
            headers={"Referer": f"https://cloudnestra.com/rcp/{rcp_hash}"},
        )
        content = resp3.text

        pass_m = re.search(r'pass_path = "//([^/]+)/rt_ping\.php"', content)
        tmstr_prefix = pass_m.group(1).split(".")[0] if pass_m else "tmstr5"

        path_m = re.search(r'https://[^.]+\.\{v\d+\}/pl/(H4sI[^ "]+)/master\.m3u8', content)
        if not path_m:
            fflog("cloudnestra: no m3u8 path in prorcp page")
            return None
        m3u8_path = path_m.group(1)

        for cdn in _CDN_DOMAINS:
            m3u8_url = f"https://{tmstr_prefix}.{cdn}/pl/{m3u8_path}/master.m3u8"
            try:
                r = sess.get(m3u8_url, timeout=10, headers={"Referer": "https://cloudnestra.com/"})
                if r.status_code == 200 and b"#EXTM3U" in r.content[:20]:
                    fflog(f"cloudnestra: resolved via {cdn}")
                    return (
                        f"{m3u8_url}|User-Agent={quote(FF_UA)}"
                        f"&Referer=https%3A%2F%2Fcloudnestra.com%2F"
                    )
            except Exception:
                pass

        fflog("cloudnestra: all CDN domains failed")
        return None
    except Exception:
        fflog_exc()
        return None
