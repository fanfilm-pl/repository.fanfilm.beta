
from typing import Optional, List, Sequence, Set, TYPE_CHECKING
import re
from weakref import WeakKeyDictionary
from attrs import frozen
from .core import Indexer, Job
from .search import Search
from .folder import list_directory, item_folder_route, pagination, ApiPage, FolderRequest, mediaref_endpoint
from ..ff.info import ffinfo
from ..ff.routing import route, subobject, info_for, url_for, PathArg
from ..ff.menu import KodiDirectory, gallery_directory, ContextMenuItem, CMenu
from ..ff.item import FFItem, ArtLabel
from ..ff.lists_config import folder_when
from ..api.tmdb import tmdb, tmdb_app
from ..defs import MediaRef, MediaRefWithNoType, FFRef
from ..kolang import L
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.accounts import Account


@frozen
class FolderFollow:
    """The accounts following filmographies and the persons followed by the only one of them, read once a folder."""

    #: The accounts doing it.
    accounts: 'Sequence[Account]'
    #: The persons the only account follows (none for more accounts: the choice tells it).
    followed: 'Set[MediaRef]'


#: The state of following filmographies of a folder.
_followed: 'WeakKeyDictionary[KodiDirectory, FolderFollow]' = WeakKeyDictionary()


class Persons(Indexer):
    """Persons navigation (a little bit degraded)."""

    MODULE = 'persons'
    TYPE = 'person'
    VIEW = 'actors'
    IMAGE = 'common/people.png'
    SEARCH_ICON = 'common/search.png'

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with list_directory(view='addons', icon='persons/main.png') as kdir:
            kdir.entry('person.search', self.search)
            kdir.entry('person.popular', info_for(self.popular))
            kdir.entry('person.my', self.lists, when=folder_when('persons.my'), add=self.add_my_entries)

    def add_my_entries(self, kdir: KodiDirectory) -> None:
        """Add the "my" lists of persons: the menu of lists of persons (the own ones and the person lists of the accounts)."""
        from .lists_menu import add_menu_level
        add_menu_level(kdir, 'persons')

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self, type='person')

    @route('lists/{__scope}')
    def lists(self, scope: str = '') -> None:
        """My person lists; a group folder of the menu by the pointer of its scope."""
        if scope:
            from .lists_menu import menu_directory, pointer_scope
            menu_directory('persons', pointer_scope(scope))
            return
        with list_directory(view=const.indexer.my_lists_view, icon='persons/main.png') as kdir:
            self.add_my_entries(kdir)

    @item_folder_route('/popular', limit=CONST_REF.indexer.persons.discovery_scan_limit, watch_filter=False)
    @pagination(api=ApiPage(size=20))
    def popular(self, req: FolderRequest, /, *, page: PathArg[int] = 1) -> Sequence[FFRef]:
        """Return poplular people (TMDB)."""
        return tmdb_app.popular_people(page=page)

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process discover item. Called from discover()."""
        it.label = f'{it.title}'
        it.mode = it.Mode.Folder
        url = info_for(self.person, person_id=it.ffid)
        if (follow := self.follow_menu(kdir, it)) is not None:
            menu = [*menu, follow]
        kdir.add(it, url=url, auto_menu=self.item_auto_menu(it, kdir=kdir), menu=menu, thumb='common/peopleposter.png',)

    def follow_menu(self, kdir: KodiDirectory, it: FFItem) -> Optional[ContextMenuItem]:
        """
        Return the entry of following the filmography of the person (the features of single services on, the accounts doing it):
        follow / unfollow for one account, a choice of the accounts for more; None if none.
        """
        from ..ff.config import config
        from ..ff.accounts import account_client, context_menu_accounts
        if not config.general.service_menus:
            return None
        if (state := _followed.get(kdir)) is None:
            accounts = context_menu_accounts('follow')
            followed = set(account_client(accounts[0]).followed_persons()) if len(accounts) == 1 else set()
            state = _followed[kdir] = FolderFollow(accounts, followed)
        if not state.accounts:
            return None
        target = url_for(self.follow, person_id=it.ffid)
        if len(state.accounts) > 1:
            services = ', '.join(dict.fromkeys(acc.type.label for acc in state.accounts))
            return CMenu(L(31322, 'Filmography on {service}…').format(service=services), target)
        return CMenu(L(31318, 'Unfollow filmography') if it.ref in state.followed else L(31319, 'Follow filmography'), target)

    @route('/follow/{person_id}')
    def follow(self, person_id: int) -> None:
        """Follow the filmography of the person or stop it (the state now): the only account, else the chosen one (marked if it follows)."""
        from ..ff.accounts import account_client, context_menu_accounts
        from ..ff.control import refresh
        from ..ff.ui import ui
        ref = MediaRef.person(person_id)
        if not (accounts := context_menu_accounts('follow')) or (it := ffinfo.get_item(ref, progress=ffinfo.Progress.NO)) is None:
            return
        clients = [account_client(acc) for acc in accounts]
        followed = [ref in client.followed_persons() for client in clients]
        index = 0
        if len(accounts) > 1:
            labels = [f'{acc.label}: {L(31318, "Unfollow filmography") if on else L(31319, "Follow filmography")}' for acc, on in zip(accounts, followed)]
            if (index := ui.select(L(31320, 'Filmography of {name}').format(name=it.title), labels)) < 0:
                return
        if clients[index].unfollow_person(ref) if followed[index] else clients[index].follow_person(ref, it.title):
            refresh()

    @mediaref_endpoint(param_ref_ffid='person_id')
    @route('/{person_id}')
    def person(self, person_id: int) -> None:
        """Show person."""
        ref = MediaRef.person(person_id)
        it = ffinfo.get_item(ref, progress=ffinfo.Progress.NO)
        if it is None:
            return self.no_content()
        it.mode = it.Mode.Separator
        it.label = f'[B]{it.title}[/B]'
        it.vtag.setMediaType('movie')
        with list_directory(view='artists') as kdir:
            kdir.add(it, url=kdir.no_op)
            kdir.folder(L(32001, 'Movies'), info_for(self.movie, person_id=person_id),
                        thumb='movies/main.png', icon='movies/main.png')
            kdir.folder(L(32002, 'TV Shows'), info_for(self.show, person_id=person_id),
                        menu=[(L(30473, 'TV Appearances'), info_for(self.show, person_id=person_id, include_self=True))],
                        thumb='tvshows/main.png', icon='tvshows/main.png')
            kdir.folder(L(30178, 'Director'), info_for(self.crew, person_id=person_id, job='director'), thumb='persons/main.png')
            kdir.folder(L(30179, 'Producer'), info_for(self.crew, person_id=person_id, job='producer'), thumb='persons/main.png')
            kdir.gallery(L(30572, 'Photos'), info_for(self.media_images, ref=ref), thumb='main/photo.png', flat=True)

    @item_folder_route('/{person_id}/movie')
    @pagination
    def movie(self, person_id: int):
        credits = tmdb.person_credits(person_id, 'movie_credits')
        return credits.cast

    @item_folder_route('/{person_id}/show')
    @pagination
    def show(self, person_id: int, include_self: Optional[bool] = None):
        credits = tmdb.person_credits(person_id, 'tv_credits')
        if include_self is None:
            include_self = const.indexer.persons.show.include_self
        if not include_self:  # filter out self appearances
            r = re.compile(r'\b(?:Self|Herself|Himself)\b')
            return [it for it in credits.cast if not r.search(it.role)]
        return credits.cast

    @item_folder_route('/{person_id}/crew')
    @pagination
    def crew(self, person_id: int, job: Optional[PathArg[Job]] = None):
        credits = tmdb.person_credits(person_id, 'combined_credits')
        jobs = self._jobs.get(job, set())
        if jobs:
            crew = [c for c in credits.crew if c.role in jobs]
        else:
            crew = [c for c in credits.crew if c.role != 'Thanks']
        return crew

    # @route('/{ref}/images/{__art_type}')
    # @route('/{ref}/images')
    # def _X_media_images(self, ref: MediaRefWithNoType, art_type: Optional[ArtLabel] = None) -> None:
    #     """Show person images."""
    #     ref = ref.with_forced_type(self.TYPE)  # type: ignore[reportAssignmentType]
    #     item = ffinfo.get_item(ref)
    #     if item is None:
    #         return self.no_content()
    #     images = ffinfo.media_images(ref)
    #     name = item.title

    #     with gallery_directory() as kdir:
    #         if not images:
    #             return kdir.no_content()

    #         for i, img in enumerate(images.all_images(), 1):
    #             full_url = img.url
    #             it = FFItem(label=f'{name} – {i}', ref=ref, info_type='pictures', mode=FFItem.Mode.Command)
    #             it.setArt(images.art(ref=ref, thumb=img.thumb))
    #             it.setProperty('fanart_image', full_url)
    #             it.setProperty('count', str(i))
    #             it.set_info({'title': name, 'picturepath': full_url})
    #             it.setMimeType('image/jpeg')
    #             kdir.add(it, url=full_url)  # Direct link to image, Kodi will handle it

    #         for i, img_data in enumerate(images_data, 1):
    #             if file_path := img_data.get('file_path'):
    #                 # In tmdb.py art_image_url_fmt is 'https://image.tmdb.org/t/p/{width}{path}'
    #                 thumb_url = tmdb.art_image_url_fmt.format(width='w185', path=file_path)
    #                 full_url = tmdb.art_image_url_fmt.format(width='original', path=file_path)
    #                 it = FFItem(ref=person_ref, info_type='pictures', mode=FFItem.Mode.Command)
    #                 it.label = f'{person_name} – {i}'
    #                 it.setArt({'thumb': thumb_url, 'icon': thumb_url})
    #                 it.setProperty('fanart_image', full_url)
    #                 kdir.add(it, url=url_for(self.show_picture_action, path=full_url))

    # @route
    # def xlists(self) -> None:
    #     """My person lists."""
    #     linfo = ListsInfo(public=True)
    #     with list_directory(view='sets', icon='persons/main.png') as kdir:
    #         ...
