"""
The routes of the configuration window (Kodi): light global routes, dispatched before the navigator is loaded (`lib.main.dispatch_url()`),
so a cold plugin call opening the window imports neither the menus nor the indexers.

Routable module: no `from __future__ import annotations` (the types are used to route).
"""

from typing import Optional

from ..ff.routing import route


@route('/tools/config')
def config(tab: str = '', account: str = '') -> None:
    """Open the configuration window, `tab`: the tab to show (none: the last shown one, else the first one), `account`: the account to select."""
    from ..windows.config_dialog import ConfigDialog
    ConfigDialog(tab=tab, account=account or None).doModal()


@route('/settings')
def settings() -> None:
    """Open the configuration window (the old route of the settings: favourites, shortcuts of skins)."""
    config()
    # control.execute("Dialog.Close(busydialognocancel)")


@route('/tools/accounts/{__account}')
def accounts(account: Optional[str] = None) -> None:
    """Open the configuration window at its tab of the accounts, `account`: the account to select."""
    config(tab='accounts', account=account or '')


@route('/tools/external_addons')  # the old name: lib/sdk/worker.py HOST_PAGE (also in the SDK copies of the provider add-ons)
@route('/tools/source_providers')  # the first route is the one of url_for()
def source_providers() -> None:
    """Open the configuration window at its tab of the source providers."""
    config(tab='addons')


@route('/tools/theme')
def theme() -> None:
    """Open the configuration window on its page of the appearance (the themes and their variant)."""
    config(tab='appearance')


@route('/tools/web')
def web_server() -> None:
    """Open the configuration window at its tab of the web server (its access, the pairing of the devices, the password)."""
    config(tab='web')
