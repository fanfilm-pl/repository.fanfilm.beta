"""
The general lists of the configuration window (its page: `lib.windows.widgets.general_lists`): a grid of the general lists of
the service types (rows) by the menus they can be shown in (columns). A switch of a type, of a list (everywhere) and of a menu
(a column) grays the switches below it, they keep their values (`lib.ff.lists_config`). A grayed switch has no focus: its reason
is in sight (a switch of its row or column is off, or a note of the type, e.g. no key).
"""

from __future__ import annotations
from math import cos, radians, sin
from typing import NamedTuple, TYPE_CHECKING
from attrs import frozen
from .skinfonts import break_label, text_metrics
from ..ff import lists_config as lc
from ..kolang import L
if TYPE_CHECKING:
    from ..ff.accounts import GeneralList
    from ..indexers.lists_menu import MenuDef

#: The angle of the labels of the columns (degrees; 0: flat).
ANGLE = 45
#: A label of a column wider than this (GUI units, its font) is broken into two lines of the most even widths.
BREAK_WIDTH = 160
#: The left of the columns of the menus (the labels of the rows before them).
X0 = 520
#: The width of a column of a menu.
STEP = 84 if ANGLE else 170


class Row(NamedTuple):
    """A row of the grid: a service type or a general list of it."""

    #: The service type.
    type_name: str
    #: The general list (None: the row of the type).
    entry: GeneralList | None
    #: The cells: the column -> the default (only the columns the list can be shown in).
    cells: dict[int, bool]


@frozen(kw_only=True)
class GridHead:
    """The head of the grid: its height (the labels of the columns), the height of the rows."""

    #: The height of the head (the labels of the columns).
    height: int
    #: The height of a row (the rows fit the page).
    row_height: int


def general_types() -> list[str]:
    """Return the service types with general lists (not cut by `const.indexer.<type>.enabled`) in their order."""
    from const import const
    from ..ff.accounts import SERVICE_TYPES
    return [name for name, srv in SERVICE_TYPES.items() if srv.general and getattr(getattr(const.indexer, name, None), 'enabled', True)]


def places() -> list[MenuDef]:
    """Return the menus a general list can be shown in (the columns): with the kind `general` and a list of their media."""
    from ..ff.accounts import SERVICE_TYPES
    from ..indexers.lists_menu import MENUS, entry_media_match
    entries = [gen for name in general_types() for gen in SERVICE_TYPES[name].general_lists]
    return [menu for menu in MENUS.values() if 'general' in menu.kinds and any(entry_media_match(gen, menu.media) for gen in entries)]


def grid_rows() -> list[Row]:
    """
    Return the rows of the grid: every type, then its general lists (with the cells of the menus they can be in); from the
    declarations of the types (`ServiceType.general_lists`): the indexers of the lists are not imported.
    """
    from ..ff.accounts import SERVICE_TYPES
    from ..indexers.lists_menu import entry_media_match
    menus = places()
    rows: list[Row] = []
    for name in general_types():
        rows.append(Row(name, None, {}))
        for gen in SERVICE_TYPES[name].general_lists:
            rows.append(Row(name, gen, {c: menu.id in gen.places for c, menu in enumerate(menus) if entry_media_match(gen, menu.media)}))
    return rows


def place_label(place: str) -> str:
    """Return the label of a menu (a column)."""
    from ..ff.account_admin import menu_label
    return lc.FOLDER_GROUPS['lists'].label() if place == 'lists' else menu_label(place)


def grid_head(menus: list[MenuDef], rows: int) -> GridHead:
    """Return the head of the grid of the menus (its height: the labels of the columns, turned by `ANGLE`) and the height of its rows."""
    width, line_h = text_metrics('small')
    labels = [break_label(place_label(menu.id), width, BREAK_WIDTH if ANGLE else STEP - 10) for menu in menus]
    boxes = [(round(max(width(ln) for ln in label.split('[CR]'))) + 8, round(line_h * (label.count('[CR]') + 1)) + 4) for label in labels]
    sin_a, cos_a = sin(radians(ANGLE)), cos(radians(ANGLE))
    # the lines of a turned label go down-right one after another: the block is moved up-left by the lines above the
    # last one, so the last line starts where a label of one line starts (the middle of its left side)
    shifts = [(label.count('[CR]')) * line_h / 2 for label in labels]
    # the head: the highest turned label (its start 10 over the bottom of the head)
    head = (max((round(w * sin_a + (h / 2 + shift) * cos_a) + 10 for (w, h), shift in zip(boxes, shifts)), default=0) + 6 if ANGLE
            else max(h for _, h in boxes) + 6)
    # the rows fit the page (its height 780: the head, the switches of the columns, the rows)
    row_h = max(34, min(44, (780 - head - 12) // (rows + 1)))
    return GridHead(height=head, row_height=row_h)


def row_active(row: Row) -> bool:
    """Return True if the row is not grayed (its type and list switched on, the type available: `general_available()`, e.g. a key)."""
    from ..ff.accounts import general_available
    return (general_available(row.type_name) and lc.service_active(row.type_name)
            and (row.entry is None or lc.list_active(row.type_name, row.entry.key)))


def row_note(row: Row) -> str:
    """Return the note of a row of a type: why its lists can not be shown (e.g. MDBList without a key)."""
    from ..ff.accounts import general_available
    if row.entry is not None or general_available(row.type_name):
        return ''
    return L(32964, 'needs an account (a key)')


def switch_help(row: Row | None, place: str | None) -> str:
    """Return the help of a switch of the grid: of a menu (no row), of a row (no menu), of a cell (both)."""
    from ..ff.accounts import SERVICE_TYPES
    if row is None:
        return L(32965, 'All general lists in "{place}": off - none of them there (their switches are kept).').format(place=place_label(place or ''))
    service = SERVICE_TYPES[row.type_name].label
    if row.entry is None:
        text = L(32966, 'The general lists of {service}: off - none of them anywhere (their switches are kept).').format(service=service)
        return ' '.join(t for t in (text, row_note(row)) if t)
    if place is None:
        return L(32967, '"{list}" ({service}): off - nowhere (its menus are kept).').format(list=row.entry.label(), service=service)
    return L(32968, '"{list}" ({service}) in "{place}".').format(list=row.entry.label(), service=service, place=place_label(place))


def switches_heading() -> str:
    """Return the head of the column of the switches of the rows."""
    return L(32969, 'Switched on in the menu')


def row_label(row: Row) -> str:
    """Return the label of a row: of its service type, of its general list."""
    from ..ff.accounts import SERVICE_TYPES
    return SERVICE_TYPES[row.type_name].label if row.entry is None else row.entry.label()


def row_checked(row: Row) -> bool:
    """Return the value of the switch of a row: of its type, of its list (everywhere)."""
    return lc.service_active(row.type_name) if row.entry is None else lc.list_active(row.type_name, row.entry.key)


def cell_checked(row: Row, menu: str, c: int) -> bool:
    """Return the value of the switch of a cell (column `c`: the menu `menu`) of a row of a list."""
    assert row.entry is not None  # a row of a type has no cells
    return lc.list_place(row.type_name, row.entry.key, menu, row.cells[c])


def cell_usable(row: Row, menu: str) -> bool:
    """Return True if the switch of a cell can be used (its row and its menu switched on; else grayed, its value kept)."""
    return row_active(row) and lc.place_active(menu)


def set_row(row: Row, checked: bool) -> None:
    """The switch of a row: the general lists of the type or the list (everywhere), written at once."""
    if row.entry is None:
        lc.set_service_active(row.type_name, checked)
    else:
        lc.set_list_active(row.type_name, row.entry.key, checked)


def set_cell(row: Row, menu: str, c: int, checked: bool) -> None:
    """A cell (column `c`: the menu `menu`) of a row of a list: the list in the menu, written at once."""
    assert row.entry is not None  # a row of a type has no cells
    lc.set_list_place(row.type_name, row.entry.key, menu, checked, row.cells[c])  # type: ignore[arg-type]
