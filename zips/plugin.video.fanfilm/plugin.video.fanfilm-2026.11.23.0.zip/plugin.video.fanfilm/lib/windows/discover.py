"""
The window of an advanced search of movies / shows (a discovery of TMDB): the fields of `lib.ff.discover` on the tabs of their groups,
the number of the found media, Search / Clear / Cancel. It only chooses: the caller keeps the search (its history) and shows the found ones.

The ends of a range are bound to each other by the moves of the user (`changed`, never `value_changed`: a value set by the window moves
nothing): the spin box of the low end bounds the scale of the high one and the other way round, the slider of the range sets both
spin boxes and they set it.
"""

from __future__ import annotations
from functools import partial
from threading import Event  # the thread of the window: a plain event (no monitor, it ends with the script)
from typing import Any, Callable, Mapping, Sequence, cast, TYPE_CHECKING
from typing_extensions import TypeAlias
from attrs import evolve, frozen
from .base import BaseDialog, weak_callback
from .style import tokens
from .widgets.tabs import Page
from .widgets.views import ComboItem
from ..ff.discover import ANY_LABEL, NO_LIMIT, ChoiceSource, Chosen, DiscoverField, DiscoverMedia, GROUPS, choices, media_fields
from ..ff.locales import flag_of
from ..ff.theme import art
from ..ff.threads import Thread
from ..ff.logs import fflog
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from ..ff.gui.scale import Scale
    from .widgets.basic import Slider, SpinBox
    from .widgets.buttons import CheckBox
    from .widgets.views import ComboBox

#: The most slots of the choices of a grid (the genres of TMDB: 19 of the movies, 16 of the shows; 5 rows of 4 fit the page).
GRID_SLOTS: int = 20
#: The columns of a grid of the choices.
GRID_COLUMNS: int = 4
#: The sources of the choices of a combo box with the filter of its list ("3", search: long lists).
FILTERED: frozenset[str] = frozenset({'countries', 'languages', 'networks'})
#: The function counting the found media of the text and the filters (None: unknown).
CountFunc: TypeAlias = 'Callable[[str, Mapping[str, Any]], int | None]'
#: The wait for the end of the counting at the close of the window (a request of TMDB under way), seconds.
COUNT_JOIN: float = 5
#: The icon of a choice of a combo box by its value (e.g. the flag of a country).
ChoiceIcon: TypeAlias = 'Callable[[str], str]'


@frozen(kw_only=True)
class ChoiceIcons:
    """The icons of the choices of a source of a combo box."""

    #: The icon of a choice by its value.
    choice: ChoiceIcon
    #: The icon of "any" (an image of the themes, `theme.art()`: as the folders of the lists).
    any_choice: str


#: The icons of the choices of the sources (as the folders of the lists: the flags of the countries).
CHOICE_ICONS: dict[ChoiceSource, ChoiceIcons] = {'countries': ChoiceIcons(choice=flag_of, any_choice='common/country.png')}


@frozen(kw_only=True)
class DiscoverResult:
    """The choice of the window: the text, the filters of TMDB (`DiscoverField.write()`), the names of the found choices (ID: name)."""

    #: The text (the query of the search).
    query: str
    #: The filters of TMDB (the keys of TMDB: `key.gte`).
    filters: dict[str, Any]
    #: The names of the found choices (keywords, people): ID - name.
    names: dict[str, str]


class DiscoverDialog(BaseDialog[DiscoverResult]):
    """The advanced search: the fields of the media, the number of the found ones; the result is the choice (Back, Cancel: None)."""

    @classmethod
    def xml_vars(cls, *, media: DiscoverMedia = 'movie', choices: Mapping[str, Mapping[str, str]] | None = None, **kwargs: Any) -> dict[str, Any]:
        """
        The fields of the media on the tabs of their groups, their pages (the bottom: the last field of a group), the buttons; the slots
        of a grid: one a choice of the given ones (`choices`, `grid_choices()`: no empty row under them), else `GRID_SLOTS`.
        """
        fields = media_fields(media)
        fields_of = {group.name: tuple(field for field in fields if field.group == group.name) for group in GROUPS}
        slots = {field.key: min(len((choices or {}).get(field.key, ())), GRID_SLOTS) or GRID_SLOTS for field in fields if field.kind == 'grid'}
        pages = tuple(Page(name=group.name, title=group.title, top=cls.control_path(fields_of[group.name][0], first=True, slots=slots),
                           bottom=cls.control_path(fields_of[group.name][-1], first=False, slots=slots))
                      for group in GROUPS if fields_of[group.name])
        buttons = {'clear': L(30817, 'Clear'), 'ok': L(32010, 'Search'), 'cancel': '$LOCALIZE[222]'}
        return {
            'TITLE': L(31392, 'Advanced search of movies') if media == 'movie' else L(31393, 'Advanced search of TV shows'),
            'GROUPS': tuple(group for group in GROUPS if fields_of[group.name]),
            'FIELDS_OF': fields_of,
            'PAGES': pages,
            'GRID_SLOTS': slots,
            'GRID_COLUMNS': GRID_COLUMNS,
            'FILTERED': FILTERED,
            'ICON_SOURCES': frozenset(CHOICE_ICONS),  # the sources of the choices with icons (no function in the vars: the key of the XML)
            'EVERY': L(31394, 'Each of the checked ones'),
            'BUTTONS': buttons,
            # the scales of the sliders of whole numbers (a number typed in: a field of the slider, its card with the buttons of the number)
            'TYPED_SCALES': {field.key: scale for field in fields if (scale := cls.typed_scale(field)) is not None},
            # the free width of a page: to the sliders of its ranges (the spin boxes keep theirs), none - to the fields over the columns
            'STRETCH': {name: 0 if any(field.kind == 'range' for field in fields) else 1 for name, fields in fields_of.items()},
            # the focus row of the buttons: a loop
            'BUTTONS_LOOP': ' '.join(f'@{button}' for button in (*buttons, next(iter(buttons)))),
        }

    @staticmethod
    def typed_scale(field: DiscoverField) -> Scale | None:
        """Return the scale of the field if any whole number of it can be typed in (`Scale.typed`: a field of its slider), else None."""
        return scale if field.scale is not None and (scale := field.scale()).typed else None

    @staticmethod
    def grid_choices(media: DiscoverMedia) -> dict[str, dict[str, str]]:
        """
        Return the choices of the grids of the media (TMDB: the genres) for the window (`choices`): its grids as large as they are (the
        template has no network: a test, the windows prepared at the start of Kodi).
        """
        return {field.key: choices(field.source, media) for field in media_fields(media) if field.kind == 'grid'}

    @staticmethod
    def control_path(field: DiscoverField, *, first: bool, slots: Mapping[str, int]) -> str:
        """Return the path of the first / the last control of the field (on its tab; a grid: of its `slots`)."""
        kind = field.kind
        if kind == 'grid':
            return f'{field.key}_every' if first else f'{field.key}_{slots[field.key] - 1}'
        if kind == 'range':
            return f'{field.key}_low'
        return field.key

    def __init__(self,
                 *args: Any,
                 media: DiscoverMedia = 'movie',
                 query: str = '',
                 filters: Mapping[str, Any] | None = None,
                 names: Mapping[str, str] | None = None,
                 defaults: Mapping[str, Any] | None = None,
                 count: CountFunc | None = None,
                 choices: Mapping[str, Mapping[str, str]] | None = None,
                 **kwargs: Any,
                 ) -> None:
        """
        The fields of the media with the filters (none: the defaults), the names of the found choices, the counting of the found media,
        the choices of the fields read before (`grid_choices()`).
        """
        super().__init__(*args)
        #: The media.
        self.media: DiscoverMedia = media
        #: The fields of the media.
        self.fields: tuple[DiscoverField, ...] = media_fields(media)
        #: The filters of no choice (Clear): the least votes and the order of the settings.
        self.defaults: dict[str, Any] = dict(defaults or {})
        #: The names of the found choices (ID: name).
        self.names: dict[str, str] = dict(names or {})
        #: The value of each field (`DiscoverField.read()`; the text: the query).
        self.values: dict[str, Any] = self.read_values(query, filters if filters is not None else self.defaults)
        #: The choices of the fields of a list (the field: the value of TMDB - its label), read once.
        self.choices: dict[str, dict[str, str]] = {key: dict(options) for key, options in (choices or {}).items()}
        #: The switches of the grids by their fields (`grid_boxes()`).
        self.boxes: dict[str, list[CheckBox]] = {}
        #: The counting of the found media (None: no counting).
        self.count_func: CountFunc | None = count
        #: A change waits for the counting.
        self.changed_event: Event = Event()
        #: The window is closed: the counting ends.
        self.closed_event: Event = Event()
        #: The counting thread.
        self.counter: Thread | None = None

    def read_values(self, query: str, filters: Mapping[str, Any]) -> dict[str, Any]:
        """Return the values of the fields of the filters (the text: the query)."""
        return {field.key: query if field.kind == 'text' else field.read(filters) for field in self.fields}

    def field_choices(self, field: DiscoverField) -> dict[str, str]:
        """Return the choices of the field of a list (read once)."""
        if field.key not in self.choices:
            self.choices[field.key] = choices(field.source, self.media)
            if field.kind == 'grid' and len(self.choices[field.key]) > GRID_SLOTS:
                fflog.warning(f'[DISCOVER] {field.key}: {len(self.choices[field.key])} choices, the grid shows {GRID_SLOTS}')
        return self.choices[field.key]

    # --- the controls ---

    def control(self, name: str) -> Any:
        """Return the widget of a control of a field on its tab."""
        return self.find(f'tabs.{name}')

    def on_init(self) -> None:
        """Show the values, connect the controls of the fields, start the counting."""
        for field in self.fields:
            self.connect_field(field)
            self.show_field(field)
        self.find('help').text = ''
        if self.count_func is not None:
            from weakref import ref
            self.counter = Thread(target=count_loop, args=(ref(self), self.count_func, self.changed_event, self.closed_event), name='discover.count',
                                  daemon=True)
            self.counter.start()
            self.changed()

    def connect_field(self, field: DiscoverField) -> None:
        """Connect the signals of the controls of the field (held weakly: the window), give them their help (the foot)."""
        key, kind = field.key, field.kind
        for name, text in self.helps(field).items():
            self.control(name).help = text
        if kind in ('text', 'multi', 'lookup'):
            self.control(key).clicked.connect(partial(weak_callback(self.field_clicked), field, False))
            if kind == 'lookup' and field.exclude:
                self.control(f'{key}_without').clicked.connect(partial(weak_callback(self.field_clicked), field, True))
        elif kind == 'choice':
            self.control(key).activated.connect(partial(weak_callback(self.choice_activated), field))
            self.control(key).about_to_show.connect(partial(weak_callback(self.choice_about_to_show), field))
        elif kind == 'grid':
            self.control(f'{key}_every').toggled.connect(partial(weak_callback(self.grid_toggled), field))
            for box in self.grid_boxes(field):  # its slots (as many as its choices: `xml_vars()`)
                box.toggled.connect(partial(weak_callback(self.grid_toggled), field))
        elif kind == 'range':
            self.control(f'{key}_low').changed.connect(partial(weak_callback(self.range_changed), field, 'low'))
            self.control(f'{key}_high').changed.connect(partial(weak_callback(self.range_changed), field, 'high'))
            self.control(key).changed.connect(partial(weak_callback(self.range_changed), field, 'both'))
        elif kind == 'minimum':
            self.control(key).changed.connect(partial(weak_callback(self.minimum_changed), field))

    def helps(self, field: DiscoverField) -> dict[str, str]:
        """Return the help of the controls of the field by their names (the kind of the field tells it; a grid: of its slots)."""
        key, kind = field.key, field.kind
        if kind == 'text':
            return {key: L(31404, 'The words of the title or of the description (the keyboard).')}
        if kind == 'grid':
            boxes = L(31406, 'OK: on (green) with it, off (red) without it, in the middle any.')
            return {f'{key}_every': L(31405, 'On: the media have each of the checked ones, off: any of them.'),
                    **{f'{key}_{n}': boxes for n in range(len(self.grid_boxes(field)))}}
        if kind == 'lookup':
            found = L(31407, 'Add the found ones (a typed text searched on TMDB) or remove the chosen ones.')
            return {key: found, **({f'{key}_without': L(31408, 'The media have none of them.') + ' ' + found} if field.exclude else {})}
        if kind == 'multi':
            return {key: L(31409, 'Any of the checked ones.')}
        typed = self.typed_scale(field) is not None
        if kind == 'range':
            entry = L(31423, 'OK: the slider and a number typed in (From… / To…).') if typed else ''
            return {f'{key}_low': L(31410, 'From (any: no limit).'), f'{key}_high': L(31411, 'To (any: no limit).'),
                    key: ' '.join(filter(None, (L(31412, 'Both ends at once.'), entry)))}
        if kind == 'minimum' and typed:
            return {key: L(31425, 'OK: the slider and a number typed in.')}
        return {}

    def show_field(self, field: DiscoverField) -> None:
        """Show the value of the field in its controls."""
        key, kind, value = field.key, field.kind, self.values[field.key]
        if kind == 'text':
            self.control(key).text = value or self.hint(L(31395, 'Any text'))
        elif kind in ('multi', 'lookup'):
            labels = self.field_choices(field) if kind == 'multi' and value.with_ids else {}  # the list read for the labels of the chosen ones
            # with / without side by side (an excluded field): + / − before each (as the description of a search)
            plus, minus = ('+ ', '− ') if kind == 'lookup' and field.exclude else ('', '')
            self.control(key).text = plus + (self.chosen_text(value.with_ids, labels) or self.hint(L(30925, 'Any')))
            if kind == 'lookup' and field.exclude:
                self.control(f'{key}_without').text = minus + (self.chosen_text(value.without_ids, labels) or self.hint(L(31396, 'None excluded')))
        elif kind == 'choice':
            if value or field.key in self.choices:  # the list read: a choice, opened before (no choice: the list read when it opens)
                self.show_choices(field)
            else:
                combo = cast('ComboBox', self.control(key))
                combo.items = self.choice_items(field, {})
                combo.current_index = 0
        elif kind == 'grid':
            self.show_grid(field)
        elif kind == 'range':
            self.show_range(field)
        elif kind == 'minimum' and field.scale is not None:
            slider = cast('Slider', self.control(key))
            slider.scale = field.scale()
            slider.value = value

    def show_choices(self, field: DiscoverField) -> None:
        """Show the choices of a combo box ("any" first) and its value."""
        combo = cast('ComboBox', self.control(field.key))
        options = self.field_choices(field)
        value = self.values[field.key]
        combo.items = self.choice_items(field, options)
        combo.current_index = 1 + list(options).index(value) if value in options else 0

    @staticmethod
    def choice_items(field: DiscoverField, options: Mapping[str, str]) -> list[Any]:
        """Return the items of the combo box of the choices ("any" first; a source of icons, `CHOICE_ICONS`: with them)."""
        if (icons := CHOICE_ICONS.get(field.source)) is None:
            return [ANY_LABEL, *options.values()]
        return [ComboItem(label=ANY_LABEL, icon=art(icons.any_choice)),
                *(ComboItem(label=name, icon=icons.choice(value)) for value, name in options.items())]

    def choice_about_to_show(self, field: DiscoverField) -> None:
        """The list of a combo box opens: its choices read the first time (not before the window is shown: long lists of TMDB)."""
        if field.key not in self.choices:
            self.show_choices(field)

    def hint(self, text: str) -> str:
        """Return the text of an empty field (`color.text.hint`)."""
        return f'[COLOR {tokens().color.text.hint}]{text}[/COLOR]'

    def chosen_text(self, ids: Sequence[str], labels: Mapping[str, str]) -> str:
        """Return the text of the chosen choices (their labels, else the names of the found ones)."""
        return ', '.join(labels.get(code) or self.names.get(code) or code for code in ids)

    def grid_boxes(self, field: DiscoverField) -> list[CheckBox]:
        """Return the switches of a grid (the slots of its template: `xml_vars()` when it was generated), found once."""
        if (boxes := self.boxes.get(field.key)) is None:
            boxes = self.boxes[field.key] = []
            for n in range(GRID_SLOTS):
                try:
                    boxes.append(self.control(f'{field.key}_{n}'))
                except KeyError:
                    break
        return boxes

    def show_grid(self, field: DiscoverField) -> None:
        """Show the choices of a grid (the slots over them hidden): checked with, unchecked without, neither any."""
        value: Chosen = self.values[field.key]
        options = list(self.field_choices(field).items())
        cast('CheckBox', self.control(f'{field.key}_every')).checked = value.every
        for n, box in enumerate(self.grid_boxes(field)):
            if n < len(options):
                code, label = options[n]
                box.text = label
                box.checked = True if code in value.with_ids else False if code in value.without_ids else None
                box.visible = True
            else:
                box.visible = False

    def show_range(self, field: DiscoverField) -> None:
        """Show a range: the spin boxes of its ends (each one bounded by the other one), the slider of both."""
        if field.scale is None:
            return
        low, high = self.values[field.key]
        scale = field.scale()
        low_box, high_box = cast('SpinBox', self.control(f'{field.key}_low')), cast('SpinBox', self.control(f'{field.key}_high'))
        low_box.scale = self.end_scale(scale, 'low', high)
        low_box.value = low
        high_box.scale = self.end_scale(scale, 'high', low)
        high_box.value = high
        slider = cast('Slider', self.control(field.key))
        slider.scale = scale
        slider.value = (low, high)

    @staticmethod
    def end_scale(scale: Scale, end: str, other: Any) -> Scale:
        """Return the scale of an end of a range: its own "any" only, up to (the low end) / from (the high end) the other end."""
        if end == 'low':
            return evolve(scale, high=(), **({'maximum': other} if other != NO_LIMIT else {}))
        return evolve(scale, low=(), **({'minimum': other} if other != NO_LIMIT else {}))

    # --- the moves of the user ---

    def field_clicked(self, field: DiscoverField, excluded: bool) -> None:
        """A field of a text, of the found choices, of a list: its dialog."""
        from ..ff.ui import ui
        kind, value = field.kind, self.values[field.key]
        if kind == 'text':
            if (text := ui.input(field.label, value)) is None:
                return
            self.values[field.key] = text.strip()
        elif kind == 'multi':
            options = self.field_choices(field)
            codes = list(options)
            chosen = ui.multiselect(field.label, list(options.values()), preselect=[codes.index(c) for c in value.with_ids if c in options])
            if chosen is None:
                return
            self.values[field.key] = evolve(value, with_ids=tuple(codes[i] for i in chosen))
        elif kind == 'lookup':
            ids = value.without_ids if excluded else value.with_ids
            if (ids := self.lookup(field, ids)) is None:
                return
            self.values[field.key] = evolve(value, without_ids=ids) if excluded else evolve(value, with_ids=ids)
        self.show_field(field)
        self.changed()

    def lookup(self, field: DiscoverField, ids: tuple[str, ...]) -> tuple[str, ...] | None:
        """
        Return the found choices of the field (a keyword, a person): the typed text searched on TMDB, the found ones added to the chosen
        ones, or (some chosen: "Remove…") the chosen ones unchecked removed; None no change.
        """
        from ..ff.ui import ui
        from ..api.tmdb import tmdb_app
        if ids:
            if (action := ui.select(field.label, [L(30890, 'Add…'), L(31397, 'Remove…')])) < 0:
                return None
            if action == 1:
                kept = ui.multiselect(field.label, [self.names.get(code, code) for code in ids], preselect=list(range(len(ids))))
                return None if kept is None else tuple(ids[i] for i in kept)
        if not (text := (ui.input(field.label, '') or '').strip()):
            return None
        found = [(str(it.ref.tmdb_id), it.label) for it in tmdb_app.search(type=field.source, query=text) if it.ref.tmdb_id]
        found = [(code, name) for code, name in found if code not in ids]
        if not found:
            ui.notify(field.label, L(30127, 'Nothing found'))
            return None
        chosen = ui.multiselect(field.label, [name for code, name in found])
        if not chosen:
            return None
        for i in chosen:
            self.names[found[i][0]] = found[i][1]
        return (*ids, *(found[i][0] for i in chosen))

    def choice_activated(self, field: DiscoverField, index: int) -> None:
        """A choice of a combo box ("any" first)."""
        options = list(self.field_choices(field))
        self.values[field.key] = options[index - 1] if 0 < index <= len(options) else ''
        self.changed()

    def grid_toggled(self, field: DiscoverField, checked: bool | None) -> None:
        """A choice of a grid (with, without, any) or "each of the checked ones" toggled."""
        options = list(self.field_choices(field))
        boxes = self.grid_boxes(field)[:len(options)]
        self.values[field.key] = Chosen(with_ids=tuple(code for code, box in zip(options, boxes) if box.checked is True),
                                        without_ids=tuple(code for code, box in zip(options, boxes) if box.checked is False),
                                        every=bool(cast('CheckBox', self.control(f'{field.key}_every')).checked))
        self.changed()

    def range_changed(self, field: DiscoverField, end: str, value: Any) -> None:
        """An end of a range moved (a spin box) or both (the slider): the other controls of the range follow."""
        if field.scale is None:
            return
        low, high = self.values[field.key]
        if end == 'low':
            low = value
        elif end == 'high':
            high = value
        else:
            low, high = value
        self.values[field.key] = (low, high)
        scale = field.scale()
        low_box, high_box = cast('SpinBox', self.control(f'{field.key}_low')), cast('SpinBox', self.control(f'{field.key}_high'))
        if end != 'low':
            low_box.scale = self.end_scale(scale, 'low', high)
            low_box.value = low
        if end != 'high':
            high_box.scale = self.end_scale(scale, 'high', low)
            high_box.value = high
        if end != 'both':
            cast('Slider', self.control(field.key)).value = (low, high)
        self.changed()

    def minimum_changed(self, field: DiscoverField, value: Any) -> None:
        """The least value moved."""
        self.values[field.key] = value
        self.changed()

    # --- the result ---

    def result(self) -> DiscoverResult:
        """Return the choice: the text, the filters of the fields, the names of the found choices of them."""
        query, filters = '', {}
        for field in self.fields:
            if field.kind == 'text':
                query = self.values[field.key]
            else:
                filters.update(field.write(self.values[field.key]))
        found = {code for field in self.fields if field.kind == 'lookup' for code in (*self.values[field.key].with_ids, *self.values[field.key].without_ids)}
        return DiscoverResult(query=query, filters=filters, names={code: name for code, name in self.names.items() if code in found})

    def on_ok_clicked(self) -> None:
        """Search: the choice."""
        self.close(self.result())

    def on_clear_clicked(self) -> None:
        """No choice: the defaults (the least votes and the order of the settings)."""
        self.values = self.read_values('', self.defaults)
        for field in self.fields:
            self.show_field(field)
        self.changed()

    def on_cancel_clicked(self) -> None:
        """No search."""
        self.close()

    def on_focus(self, control_id: int) -> None:
        """The help of the focused control in the foot."""
        self.find('help').text = self._widget_tree.help_of(control_id) if self._widget_tree is not None else ''

    def on_close(self) -> None:
        """End the counting (a thread alive at the end of the script can hang the interpreter of Kodi 22)."""
        self.closed_event.set()
        self.changed_event.set()
        if (counter := self.counter) is not None:
            counter.join(COUNT_JOIN)
        super().on_close()

    # --- the number of the found media ---

    def changed(self) -> None:
        """A value changed: count the found media again (after a while, the last change)."""
        self.changed_event.set()


def count_loop(window: Callable[[], 'DiscoverDialog | None'], count: CountFunc, changed: Event, closed: Event) -> None:
    """
    Count the found media after each change (`const.tune.gui.discover_count_delay` after the last one: one request for a run of changes),
    show the number while the window is open; the window held weakly (freed at its close), the wait not on the monitor of the script.
    """
    try:
        while not closed.is_set():
            changed.wait()
            while changed.is_set() and not closed.is_set():  # the last change wins
                changed.clear()
                closed.wait(const.tune.gui.discover_count_delay)
            if closed.is_set() or (shown := window()) is None:
                return
            choice = shown.result()
            del shown
            number = count(choice.query, choice.filters)
            if closed.is_set() or (shown := window()) is None or not shown.wait_ready(0):
                return
            shown.find('count').text = '' if number is None else L(31398, 'Found: {n}', n=number)
            del shown
    except ReferenceError:  # the window is gone
        return
