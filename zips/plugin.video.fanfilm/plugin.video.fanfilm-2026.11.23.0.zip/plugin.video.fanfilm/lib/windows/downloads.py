"""
The downloads window: the queue of the download engine in its order (never sorted by state: a row keeps its place), refreshed while it is
shown. OK on a row does the action of its state (pause, resume, try again or renew the expired link, play: not while the sources window is
shown), the buttons over the current row pause / resume and remove it, its context menu has the rest; the buttons under the list act on the
whole queue. The window talks to the engine only through the calls of `lib.ff.downloads` (`DownloadsDialog.engine`: the module, a fake
queue of the demo).
"""

from __future__ import annotations
from typing import Any, Callable, cast, TYPE_CHECKING
from threading import Event
from typing_extensions import Literal, Protocol, TypeAlias
from attrs import frozen
from .base import MENU_ACTIONS, BaseDialog
from ..ff import downloads
from ..ff.threads import RLock, Thread
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action
    from .widgets.accounts import ToolButton
    from .widgets.views import ListView
    from ..defs import MediaRef
    from ..ff.downloads import DownloadAction, DownloadErrorKind, DownloadInfo, DownloadsSnapshot, DownloadState

#: What a row can do: an action of the engine, or play the finished file.
RowAction: TypeAlias = "DownloadAction | Literal['play']"


class DownloadsEngine(Protocol):
    """The calls of the download engine the window uses (`lib.ff.downloads`, or a fake queue of the demo)."""

    def snapshot(self) -> DownloadsSnapshot | None:
        """Return the queue, None if the service did not answer."""

    def act(self, download_id: int, action: DownloadAction) -> bool:
        """Do the action with the download."""

    def pause_all(self, paused: bool) -> bool:
        """Pause or release the whole queue."""

    def remove_done(self) -> bool:
        """Remove the finished downloads from the list."""

    def clear_all(self) -> bool:
        """Remove every download with its part file."""

    def forget_missing(self) -> bool:
        """Remove the finished downloads whose file is gone."""


@frozen
class StateLook:
    """How a row of a state looks and what OK on it does."""

    #: The mark of the row (a name of `symbol()`).
    mark: str
    #: The word of the state at the end of the line.
    word: str
    #: What OK on the row does.
    action: RowAction


#: The rows by their states (a running one: `RUNNING_MARK`, the time left instead of the word).
STATE_LOOKS: dict[DownloadState, StateLook] = {
    'queued': StateLook(mark='bullet', word=L(30220, 'queued'), action='pause'),
    'paused': StateLook(mark='pause', word=L(30226, 'paused'), action='resume'),
    'error': StateLook(mark='warning', word=L(30593, 'error'), action='retry'),
    'done': StateLook(mark='tick', word=L(30237, 'done'), action='play'),
}
#: The kinds of the errors of a link a new one helps: OK on such a row renews it (`renew`, the source resolved again).
RENEWED_ERRORS: frozenset[DownloadErrorKind] = frozenset(('expired', 'payment'))
#: The mark of a running row.
RUNNING_MARK: str = 'down'
#: The end of the line of a running row while its time left is not known.
RUNNING_WORD: str = L(30489, 'downloading')
#: The longest time left the end of the line has room for (seconds: `99 h 59 min`).
LONGEST_LEFT: int = 99 * 3600 + 59 * 60
#: The font role of the marks of the rows (the symbol font if Kodi has it).
MARK_STYLE: str = 'normal.symbol'
#: Seconds the refresh thread may take to end at the close of the window (it ends at once unless it waits for the service).
REFRESH_JOIN: float = 5
#: The text of an error of a row by its kind, when the engine gave none.
ERROR_TEXTS: dict[DownloadErrorKind, str] = {
    '': L(30248, 'Download failed'),
    'expired': L(30269, 'The link expired'),
    'space': L(30350, 'No space left on the disk'),
    'write': L(30352, 'The file can not be written'),
    'network': L(30354, 'The network failed'),
    'http': L(30377, 'The server gave no file'),
    'payment': L(30378, 'A new link needs a payment'),
}


@frozen(kw_only=True)
class ShownDownload:
    """A shown download (`row_of()`)."""

    #: The download.
    id: int
    #: Its media (None unknown) and its file.
    ref: MediaRef | None
    dest: str
    #: Its state, it downloads now.
    state: DownloadState
    running: bool
    #: What OK on the row does (None: nothing, an expired link of a source which gets no new one here: no button of it).
    action: RowAction | None
    #: The mark of its state (a name of `symbol()`).
    mark: str
    #: The label: the title and the source.
    label: str
    #: The size is known (the bar shown), the percent (0 - 100) and its text.
    measured: bool
    percent: int
    percent_text: str
    #: The end of the line: the time left of a running row, else the word of its state.
    right: str
    #: The second line of the current row: the sizes, the speed, the source, till when the file is on the account; the error and the source.
    detail: str


def size_text(size: float) -> str:
    """Return the size for the user (`1.2 GB`)."""
    from ..ff.source.utils import human_readable_size
    return human_readable_size(int(size))


def left_text(seconds: float) -> str:
    """Return the time left for the user: `45 s`, `8 min`, `1 h 05 min` (the minutes rounded up)."""
    secs = max(0, round(seconds))
    if secs < 60:
        return L(30381, '{n} s', n=secs)
    hours, minutes = divmod(-(-secs // 60), 60)
    return L(30382, '{h} h {m:02} min', h=hours, m=minutes) if hours else L(30383, '{n} min', n=minutes)


def row_of(info: DownloadInfo) -> ShownDownload:
    """Return the row of the download."""
    measured = info.size > 0 or info.state == 'done'
    percent = 100 if info.state == 'done' else min(100, max(0, info.done * 100 // info.size)) if info.size > 0 else 0
    look = STATE_LOOKS[info.state]
    if info.running:
        right = left_text(info.eta) if info.eta is not None else RUNNING_WORD
    else:
        right = look.word
    source = (info.provider, '' if info.hosting.lower() == info.provider.lower() else info.hosting)
    if info.state == 'error':
        parts = [info.error_text or ERROR_TEXTS[info.error_kind], *source]
    else:
        parts = [f'{size_text(info.done)} / {size_text(info.size)}' if info.size > 0 else size_text(info.done) if info.done else '',
                 f'{size_text(info.speed)}/s' if info.running and info.speed > 0 else '', *source,
                 L(30492, 'on the account till {date}', date=info.expires) if info.expires else '']
    detail = ' · '.join(part for part in parts if part)
    renew = info.state == 'error' and info.error_kind in RENEWED_ERRORS
    action: RowAction | None = look.action if not renew else 'renew' if info.renews else None
    return ShownDownload(id=info.id, ref=info.ref, dest=info.dest, state=info.state, running=info.running, action=action,
                         mark=RUNNING_MARK if info.running else look.mark, label=' · '.join(t for t in (info.title, info.info) if t),
                         measured=measured, percent=percent, percent_text=f'{percent} %' if measured else '', right=right, detail=detail)


def play_url(row: ShownDownload) -> str:
    """
    Return what plays the finished download: the FF play route of its media (`play/{ref}`, `lib.indexers.play.play`) with the argument
    `download` = the ID of the download (the route plays its file instead of a source search), a download of no media its file.
    """
    if row.ref is None:
        return row.dest
    from ..ff.routing import url_for
    from ..indexers.play import play
    return str(url_for(play, ref=row.ref, download=row.id))


@frozen
class RowEntry:
    """An entry of the context menu of a row: its action, its label, does it belong to the row (the row and its index)."""

    #: The action.
    action: RowAction
    #: The label.
    label: str
    #: The entry belongs to the row.
    applies: Callable[[ShownDownload, int], bool]


#: The context menu of a row, in its order.
ROW_ENTRIES: tuple[RowEntry, ...] = (
    RowEntry('pause', L(30511, 'Pause'), lambda row, index: row.action == 'pause'),
    RowEntry('resume', L(30513, 'Resume'), lambda row, index: row.action == 'resume'),
    RowEntry('renew', L(31254, 'Renew the link'), lambda row, index: row.action == 'renew'),
    RowEntry('retry', L(30521, 'Try again'), lambda row, index: row.action in ('retry', 'renew')),
    RowEntry('play', L(30528, 'Play'), lambda row, index: row.action == 'play'),
    RowEntry('first', L(30608, 'Move to the start of the queue'), lambda row, index: row.state != 'done' and index > 0),
    RowEntry('remove', L(30609, 'Remove from the list'), lambda row, index: True),
    RowEntry('remove_file', L(30610, 'Remove with the file'), lambda row, index: row.state == 'done'),
)


def queue_left(snap: DownloadsSnapshot) -> float | None:
    """
    Return the seconds the queue needs yet: the bytes left of the rows to download (running and queued; a queued one of an unknown size
    left out) at the total speed now, at least the longest time left of a running row (a slow one ends last); None unknown (no speed,
    a running row of an unknown size).
    """
    active = [info for info in snap.rows if info.running]
    speed = sum(info.speed for info in active)
    if speed <= 0 or any(info.size <= 0 for info in active):
        return None
    left = sum(max(0, info.size - info.done) for info in snap.rows if info.state == 'queued' and info.size > 0) / speed
    return max([left, *(info.eta for info in active if info.eta is not None)])


def foot_text(snap: DownloadsSnapshot) -> str:
    """
    Return the summary of the queue: active, queued, the total speed, the time the queue needs yet, the free space (the unknown parts left
    out); a paused queue first (also one waiting for the end of the video).
    """
    active = [info for info in snap.rows if info.running]
    queued = sum(1 for info in snap.rows if info.state == 'queued' and not info.running)
    speed = sum(info.speed for info in active)
    left = queue_left(snap)
    parts = [L(30611, 'Paused') if snap.paused_all else L(31276, 'Paused while a video plays') if snap.held_by_play else '',
             L(30613, 'Active: {count}', count=len(active)), L(30618, 'Queued: {count}', count=queued),
             f'{size_text(speed)}/s' if speed > 0 else '', L(31278, 'Time left: {time}', time=left_text(left)) if left is not None else '',
             L(30627, 'Free: {size}', size=size_text(snap.free_space)) if snap.free_space is not None else '']
    return ' · '.join(part for part in parts if part)


class DownloadsDialog(BaseDialog[None]):
    """The downloads window: the queue (`downloads`), the buttons over its current row, the buttons of the queue, its summary in the foot."""

    @classmethod
    def xml_vars(cls, **kwargs: Any) -> dict[str, Any]:
        """
        The texts of the template, the widths of the texts of the rows Python gives (unknown to the layout): the widest mark of a state
        (`MARK`), the widest end of a line (`RIGHT`: the words of the states, the longest time left) - in the language and the fonts of the
        window.
        """
        from math import ceil
        from .skinfonts import symbol, text_metrics
        mark_width, _ = text_metrics(MARK_STYLE)
        text_width, _ = text_metrics('normal')
        marks = (symbol(name, MARK_STYLE) for name in (RUNNING_MARK, *(look.mark for look in STATE_LOOKS.values())))
        ends = (RUNNING_WORD, left_text(LONGEST_LEFT), *(look.word for look in STATE_LOOKS.values()))
        return {'TITLE': L(32347, 'Downloads'), 'REMOVE_DONE': L(30708, 'Remove finished'), 'CLEAR_ALL': L(30762, 'Clear all'),
                'MARK': ceil(max(map(mark_width, marks))), 'RIGHT': ceil(max(map(text_width, ends)))}

    def __init__(self, *args: Any, engine: DownloadsEngine | None = None, current: int | None = None, **kwargs: Any) -> None:
        """The window of the engine (None: `lib.ff.downloads`), its current row the download `current` (None: the first); no controls yet."""
        super().__init__(*args, **kwargs)
        #: The download engine.
        self.engine: DownloadsEngine = cast('DownloadsEngine', downloads) if engine is None else engine
        #: The download of the current row (None: none yet): the focus stays on it when rows come and go.
        self.current_id: int | None = current
        #: The whole queue is paused (the last snapshot).
        self.paused_all: bool = False
        #: One refresh at a time (the thread, an action).
        self._lock: RLock = RLock()
        #: Set at the close: the refresh thread ends (a plain event: the FF one waits on the monitor of the script, gone with it).
        self._watch_end: Event = Event()
        #: The refresh thread (None: not started).
        self._watch: Thread | None = None

    @property
    def view(self) -> ListView:
        """Return the list of the downloads."""
        return cast('ListView', self.find('downloads'))

    def current_row(self) -> ShownDownload | None:
        """Return the current row (None: none)."""
        view = self.view
        return view.rows[view.current] if 0 <= view.current < len(view.rows) else None

    def on_init(self) -> None:
        """
        Show the queue, refresh it while the window is shown (the refresh thread forgets the finished downloads of removed files first: a
        check of every file, a sleeping network folder answers slowly).
        """
        from weakref import ref
        self.refresh()
        if not self.view.rows:
            self.setFocusId(self.find('buttons.close').id)
        if self._watch is None:
            self._watch = Thread(target=watch_queue, args=(ref(self), self._watch_end), name='downloads-window', daemon=True)
            self._watch.start()

    def reopen_state(self) -> dict[str, Any]:
        """Return the state of an open again: the download of the current row too (the one the user is on, not the one of the open)."""
        return {**super().reopen_state(), 'current': self.current_id}

    def restore(self, state: dict[str, Any]) -> None:
        """The current row of the closed window."""
        super().restore(state)
        self.current_id = state.get('current', self.current_id)

    def on_close(self) -> None:
        """End the refresh thread (a thread alive at the end of the script can hang the interpreter of Kodi 22)."""
        self._watch_end.set()
        if (watch := self._watch) is not None:
            watch.join(REFRESH_JOIN)

    def refresh(self) -> None:
        """Show the queue now."""
        self.show(self.engine.snapshot())

    def show(self, snap: DownloadsSnapshot | None) -> None:
        """
        Show the queue (None: the service does not answer): the rows (the same downloads in the same order: only their values, the list
        stays where the user moved it - a key pressed meanwhile is not undone), the focus on the same download (gone: the nearest row), the
        buttons, the foot.
        """
        with self._lock:
            view = self.view
            rows = [row_of(info) for info in snap.rows] if snap is not None else []
            ids = [row.id for row in rows]
            moved = ids != [row.id for row in view.rows]
            current_id = self.current_id  # before the new rows: the fill of the list moves its current row (`current_changed`)
            view.rows = rows
            if moved:
                index = ids.index(current_id) if current_id in ids else min(max(view.current, 0), len(rows) - 1)
                view.current = index
                self.current_id = rows[index].id if rows else None
            self.paused_all = snap is not None and snap.paused_all
            self.find('empty').text = (L(30763, 'No downloads') if snap is not None else
                                       L(30208, 'The downloads are not available now (the service does not answer).'))
            self.find('buttons.pause_all').text = L(30771, 'Resume all') if self.paused_all else L(30808, 'Pause all')
            self.find('foot').text = foot_text(snap) if snap is not None else ''
            self.show_row_buttons()

    def show_row_buttons(self) -> None:
        """
        The buttons of the current row (none: no rows): remove, pause - pause a running or queued one, resume a paused one or one with an
        error (its icon), none for a finished one or one with no action. A hidden control keeps the focus in Kodi: the focus on a button hidden now goes to the remove
        button of the row, without rows to the close button.
        """
        pause, remove = cast('ToolButton', self.find('downloads.pause')), self.find('downloads.remove')
        row = self.current_row()
        pause.visible = row is not None and row.action not in (None, 'play')
        remove.visible = row is not None
        if row is not None:
            pause.icon = 'pause' if row.action == 'pause' else 'play'
        if row is None or not pause.visible:  # the focus asked only then (a call of Kodi waits for its next frame)
            focused = self.focused_id()
            if row is None and focused in self.row_controls():
                self.setFocusId(self.find('buttons.close').id)
            elif focused == pause.id:
                self.setFocusId(remove.id)

    def on_downloads_current_changed(self, index: int) -> None:
        """The user moved the list: its download is the current one, the buttons of its row."""
        if (row := self.current_row()) is not None:
            self.current_id = row.id
        self.show_row_buttons()

    def on_downloads_activated(self, index: int) -> None:
        """OK on a row: the action of its state."""
        if 0 <= index < len(self.view.rows):
            row = self.view.rows[index]
            if row.action is not None:
                self.run(row.action, row)

    def on_downloads_pause_clicked(self) -> None:
        """The pause button of the current row: pause it, resume it (one with an error: try again, renew its expired link)."""
        if (row := self.current_row()) is not None and row.action not in (None, 'play'):
            self.run(row.action, row)

    def on_downloads_remove_clicked(self) -> None:
        """The remove button of the current row: remove it from the list."""
        if (row := self.current_row()) is not None:
            self.run('remove', row)

    def on_action(self, action: Action) -> bool | None:
        """The context menu of the current row (the list or a button of the row has the focus); the rest: the default (Back closes)."""
        if action.getId() in MENU_ACTIONS and (row := self.current_row()) is not None and self.focused_id() in self.row_controls():
            self.row_menu(row, self.view.current)
            return True
        return super().on_action(action)

    def row_controls(self) -> set[int]:
        """Return the IDs of the list and of the buttons of its current row."""
        return {self.view.id, self.find('downloads.pause').id, self.find('downloads.remove').id}

    def row_menu(self, row: ShownDownload, index: int) -> None:
        """Show the context menu of the row (at the index of the list), do the chosen entry."""
        from .context import ContextMenuDialog
        entries = [entry for entry in ROW_ENTRIES if entry.applies(row, index)]
        chosen = ContextMenuDialog(menu=[(entry.label, None) for entry in entries]).do_modal()
        if isinstance(chosen, int) and 0 <= chosen < len(entries):
            self.run(entries[chosen].action, row)

    def run(self, action: RowAction, row: ShownDownload) -> None:
        """Do the action with the download of the row (a removal confirmed: `confirmed()`), then show the queue at once; play: the window closes first."""
        if action == 'play':
            self.play(row)
            return
        if not self.confirmed(action, row):
            return
        self.engine.act(row.id, action)
        self.refresh()

    def confirmed(self, action: RowAction, row: ShownDownload) -> bool:
        """Ask before a removal: of the row only with `const.downloads.confirm_remove`, with its file always; the other actions: yes."""
        from ..ff.ui import ui
        if action == 'remove_file':
            return ui.confirm(L(30853, 'Remove {title} from the list and delete its file?', title=row.label), heading=L(32347, 'Downloads'))
        if action == 'remove' and const.downloads.confirm_remove:
            text = (L(30921, 'Remove {title} from the list? The file stays.', title=row.label) if row.state == 'done' else
                    L(30922, 'Remove {title} from the list? The part downloaded is deleted.', title=row.label))
            return ui.confirm(text, heading=L(32347, 'Downloads'))
        return True

    def play(self, row: ShownDownload) -> None:
        """
        Play the finished download: the window closes first (the player over it). Not while the sources window is shown (its call of the
        play route waits: the video would play under it, then stop at its close): the user closes it first.
        """
        import xbmc
        if sources_shown():
            from xbmcgui import Dialog
            Dialog().ok(L(32347, 'Downloads'), L(31279, 'Close the sources window first'))
            return
        url = play_url(row)
        self.close()
        xbmc.executebuiltin(f'PlayMedia("{url}")')

    def on_buttons_pause_all_clicked(self) -> None:
        """Pause the whole queue, or release it."""
        self.engine.pause_all(not self.paused_all)
        self.refresh()

    def on_buttons_remove_done_clicked(self) -> None:
        """Remove the finished downloads from the list (their files stay)."""
        self.engine.remove_done()
        self.refresh()

    def on_buttons_clear_all_clicked(self) -> None:
        """Remove every download (always confirmed): the unfinished ones with their files, the finished files stay."""
        from ..ff.ui import ui
        if ui.confirm(L(30927, 'Remove all downloads? The files not finished are deleted, the finished files stay.'), heading=L(32347, 'Downloads')):
            self.engine.clear_all()
            self.refresh()

    def on_buttons_close_clicked(self) -> None:
        """Close the window."""
        self.close()


def watch_queue(window: Callable[[], DownloadsDialog | None], closed: Event) -> None:
    """
    Forget the finished downloads of removed files (`forget_missing()`: they go at the next refresh), then show the queue every
    `const.downloads.refresh_interval` seconds while the window is shown, end at its close (`closed`: no wait for the next refresh) or when
    Kodi has it no more (`is_active()`: a reload of the skin). The window held weakly (freed at its close); the wait not on the monitor
    of the script (gone with it).
    """
    try:
        if (shown := window()) is None or not shown.wait_ready():
            return
        engine = shown.engine
        del shown
        engine.forget_missing()
        while not closed.wait(const.downloads.refresh_interval):
            if (shown := window()) is None or not shown.wait_ready(0) or not shown.is_active():
                return
            shown.refresh()
            del shown
    except ReferenceError:  # the window is gone
        return


def sources_shown() -> bool:
    """Return True if Kodi shows the sources window now (a dialog over it too), in any interpreter."""
    from .sources import SourceDialog
    return SourceDialog.is_shown()


def show_downloads(current: int | None = None) -> None:
    """Open the downloads window, its current row the download `current` (None: the first)."""
    DownloadsDialog(current=current).do_modal()
