
from typing import Optional, Union, Iterable, Iterator
from typing_extensions import Self
from attrs import define


@define
class Point:
    x: int
    y: int

    def __len__(self) -> int:
        return 2

    def __iter__(self) -> Iterator[int]:
        return iter((self.x, self.y))

    def __add__(self, other: Union['Point', int]) -> 'Point':
        if isinstance(other, int):
            x = y = other
        elif type(other) is Point:
            x, y = other.x, other.y
        else:
            x, y = other
        return Point(self.x + x, self.y + y)

    def __radd__(self, other: Union['Point', int]) -> 'Point':
        return self.__add__(other)

    def __iadd__(self, other: Union['Point', int]) -> Self:
        if isinstance(other, int):
            x = y = other
        elif type(other) is Point:
            x, y = other.x, other.y
        else:
            x, y = other
        self.x += x
        self.y += y
        return self

    def __sub__(self, other: Union['Point', int]) -> 'Point':
        if isinstance(other, int):
            x = y = other
        elif type(other) is Point:
            x, y = other.x, other.y
        else:
            x, y = other
        return Point(self.x - x, self.y - y)

    def __isub__(self, other: Union['Point', int]) -> Self:
        if isinstance(other, int):
            x = y = other
        elif type(other) is Point:
            x, y = other.x, other.y
        else:
            x, y = other
        self.x -= x
        self.y -= y
        return self

    def __neg__(self) -> 'Point':
        return Point(-self.x, -self.y)


@define
class Size:
    width: int
    height: int

    def __bool__(self) -> bool:
        return self.width > 0 and self.height > 0

    def __len__(self) -> int:
        return 2

    def __iter__(self) -> Iterator[int]:
        return iter((self.width, self.height))

    def __add__(self, other: Union['Size', int]) -> 'Size':
        if isinstance(other, int):
            w = h = other
        elif type(other) is Point:
            w, h = other.width, other.height
        else:
            w, h = other
        return Size(self.width + w, self.height + h)

    def __radd__(self, other: Union['Size', int]) -> 'Size':
        return self.__add__(other)

    def __sub__(self, other: Union['Size', int]) -> 'Size':
        if isinstance(other, int):
            w = h = other
        elif type(other) is Point:
            w, h = other.width, other.height
        else:
            w, h = other
        return Size(max(0, self.width - w), max(0, self.height - h))


@define
class Rect:
    point: Point
    size: Size

    def __bool__(self) -> bool:
        return bool(self.size)

    @property
    def left(self) -> int:
        return self.point.x

    @left.setter
    def left(self, value: int) -> None:
        self.point.x = value

    @property
    def top(self) -> int:
        return self.point.y

    @top.setter
    def top(self, value: int) -> None:
        self.point.y = value

    @property
    def right(self) -> int:
        return self.point.x + self.size.width

    @right.setter
    def right(self, value: int) -> None:
        self.point.x = value - self.size.width

    @property
    def bottom(self) -> int:
        return self.point.y + self.size.height

    @bottom.setter
    def bottom(self, value: int) -> None:
        self.point.y = value - self.size.height

    def move(self, other: Point) -> Self:
        self.point += other
        return self

    def __add__(self, other: Point) -> 'Rect':
        if isinstance(other, Point):
            return Rect(self.point + other, self.size)
        elif isinstance(other, Size):
            return Rect(self.point, self.size + other)
        elif isinstance(other, int):
            return Rect(self.point + other, self.size + 2 * other)
        else:
            raise NotImplementedError(f'Rect + {other.__class__.__name__}')

    def __iadd__(self, other: Point) -> Self:
        if isinstance(other, Point):
            self.point += other
        elif isinstance(other, Size):
            self.size += other
        elif isinstance(other, int):
            self.point += other
            self.size += 2 * other
        else:
            raise NotImplementedError(f'Rect + {other.__class__.__name__}')
        return self

    def __sub__(self, other: Point) -> 'Rect':
        if isinstance(other, Point):
            return Rect(self.point - other, self.size)
        elif isinstance(other, Size):
            return Rect(self.point, self.size - other)
        elif isinstance(other, int):
            return Rect(self.point - other, self.size - 2 * other)
        else:
            raise NotImplementedError(f'Rect - {other.__class__.__name__}')

    def __isub__(self, other: Point) -> Self:
        if isinstance(other, Point):
            self.point -= other
        elif isinstance(other, Size):
            self.size -= other
        elif isinstance(other, int):
            self.point -= other
            self.size -= 2 * other
        else:
            raise NotImplementedError(f'Rect - {other.__class__.__name__}')
        return self


def rect_gaps(outer: Rect, holes: 'Iterable[Rect]') -> 'list[Rect]':
    """
    Return the parts of the rectangle out of the holes (rectangles in it, not overlapping each other): in the bands between the top and
    bottom edges of the holes, the runs of each band no hole covers - none of them overlaps a hole or another one (e.g. Kodi: a control
    under another focusable control keeps its focus when the pointer moves onto that one).
    """
    holes = [hole for hole in holes if hole]
    edges = sorted({outer.top, outer.bottom, *(y for hole in holes for y in (hole.top, hole.bottom) if outer.top < y < outer.bottom)})
    gaps: list[Rect] = []
    for top, bottom in zip(edges, edges[1:]):
        x = outer.left
        for hole in sorted((hole for hole in holes if hole.top < bottom and hole.bottom > top), key=lambda hole: hole.left):
            if hole.left > x:
                gaps.append(Rect(Point(x, top), Size(hole.left - x, bottom - top)))
            x = max(x, hole.right)
        if x < outer.right:
            gaps.append(Rect(Point(x, top), Size(outer.right - x, bottom - top)))
    return gaps
