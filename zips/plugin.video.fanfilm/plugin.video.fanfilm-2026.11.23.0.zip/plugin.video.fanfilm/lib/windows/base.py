from __future__ import annotations
from typing import Optional, Union, Any, Tuple, Dict, Sequence, Callable, Type, ClassVar, cast, overload, TYPE_CHECKING
from typing_extensions import Self, TypeVar, Generic, Literal
# a plain event where a Kodi exit must not end its wait at once (`SkinGuard._run()`: a loop of such waits would spin)
from threading import Thread, Condition, Lock, current_thread, Event as PlainEvent
from pathlib import Path
from inspect import ismethod
from functools import wraps
from contextlib import ExitStack
from weakref import ref as weak_ref, WeakMethod, finalize
import hashlib
import json
from time import monotonic, sleep
from attrs import define, frozen, field
from xbmcgui import Window, WindowXML, WindowXMLDialog, Control, ControlList
from xbmcgui import (
    ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_STOP, ACTION_NAV_BACK,
    ACTION_MOUSE_RIGHT_CLICK, ACTION_MOUSE_LONG_CLICK, ACTION_CONTEXT_MENU,
    ACTION_JUMP_SMS2, ACTION_JUMP_SMS9, REMOTE_0, REMOTE_9,
    ACTION_MOUSE_START, ACTION_MOUSE_END, ACTION_GESTURE_NOTIFY, ACTION_GESTURE_END, ACTION_NOOP, ACTION_SELECT_ITEM,
)
from ..ff import control
from ..kodi import version as kodi_version
from ..ff.tricks import MISSING, MissingType, make_mutable_metaclass
from ..ff.threads import Queue, Event, wait_ended
from ..ff.logs import fflog, fflog_exc
from ..service.exc import KodiExit
# from ..ff.debug import logtime
from const import const
if TYPE_CHECKING:
    from xbmcgui import ListItem, Action
    from .gui import CustomXmlData, CustomXmlRequest
    from .bindings import WindowBindings
    from .widgets import Widget, WidgetTree, W as WDG


T = TypeVar('T')
B = TypeVar('B', 'BaseWindow', 'BaseDialog')
#: The window type of `WindowRef`.
W = TypeVar('W', bound='AbstractWindow')
#: A callback (`weak_callback()`, `closes_on_kodi_exit()`).
C = TypeVar('C', bound=Callable[..., Any])
Args = Tuple[Type[T], ...]
KwArgs = Dict[str, Any]
RESULT = TypeVar('RESULT')

Errors = Literal['strict', 'ignore']

#: A frame of Kodi (60 fps): the step of a wait for its next frame (`AbstractWindow.set_focus_shown()`).
KODI_FRAME: float = 1 / 60

#: The resolution folder of the XML files of the windows (Kodi's default: 720p).
DEFAULT_RES: str = '1080i'


def xml_folder_of(script_path: str, skin: str = 'Default', res: str = DEFAULT_RES) -> Path:
    """Return the folder of the XML files of the windows of the skin (Kodi finds a generated XML there, with the media folder)."""
    return Path(script_path) / 'resources' / 'skins' / skin / res

#: Type letter in edit-control (on Linux).
ACTION_EDIT_TYPING = 61952
ACTION_EDIT_BACKSPACE = 61448
ACTION_EDIT_DELETE = 61575
EDIT_ACTIONS = {
    ACTION_EDIT_TYPING,
    ACTION_EDIT_BACKSPACE,
    ACTION_EDIT_DELETE,
}

#: Actions (keys) to close / cancel / escape.
CANCEL_ACTIONS = {
    ACTION_PARENT_DIR,
    ACTION_PREVIOUS_MENU,
    # ACTION_PAUSE,
    ACTION_STOP,
    ACTION_NAV_BACK,
}

#: Actions (keys) for context-menu.
MENU_ACTIONS = {
    ACTION_MOUSE_RIGHT_CLICK,
    ACTION_MOUSE_LONG_CLICK,
    ACTION_CONTEXT_MENU,
}


class WindowRef(Generic[W]):
    """
    The window of a helper (a tab of a window, a tree in a window), held weakly (see `AbstractWindow`): reading gives
    the window itself, `ReferenceError` if it is gone.
    """

    def __set_name__(self, owner: type, name: str) -> None:
        """Remember the attribute of the weak reference in the helper."""
        #: The attribute of the weak reference in the helper.
        self.attr: str = f'_{name}_ref'

    @overload
    def __get__(self, obj: None, owner: type | None = None) -> Self: ...

    @overload
    def __get__(self, obj: object, owner: type | None = None) -> W: ...

    def __get__(self, obj: object | None, owner: type | None = None) -> W | Self:
        """Return the window (the descriptor itself on the class)."""
        if obj is None:
            return self
        if (win := getattr(obj, self.attr)()) is None:
            raise ReferenceError(f'The window of {type(obj).__name__} is gone')
        return win

    def __set__(self, obj: object, win: W) -> None:
        """Keep the window weakly."""
        setattr(obj, self.attr, weak_ref(win))


def number_button(action: Action) -> int | None:
    """Return the digit of the action (a remote digit, `JumpSMS<n>` of a remote, the keyboard), None for another action."""
    aid = action.getId()
    if ACTION_JUMP_SMS2 <= aid <= ACTION_JUMP_SMS9:
        return aid - ACTION_JUMP_SMS2 + 2
    if REMOTE_0 <= aid <= REMOTE_9:
        return aid - REMOTE_0
    return None


def is_key_action(action_id: int) -> bool:
    """
    Return True if the action is of a key: not of the mouse (a tap too: a click by the touch keymap) or of a gesture (Kodi
    `CAction::IsMouse()`, `IsGesture()`), not `noop` (the inspector wakes a window by it, a key of a keymap made dead).
    """
    return not (ACTION_MOUSE_START <= action_id <= ACTION_MOUSE_END or ACTION_GESTURE_NOTIFY <= action_id <= ACTION_GESTURE_END
                or action_id == ACTION_NOOP)


def current_row(list_id: int) -> int:
    """
    Return the current row of the Kodi list (-1: no such list; an empty one tells its last cursor - check the length of its rows) by its info
    label: no GUI lock, so cheap at every action (a move of the mouse too) - a control call (`getSelectedPosition()`) waits for the next frame
    and makes Kodi sleep longer in every frame while such calls go on (`CApplication::FrameMove`); a click, a key choosing a row reads the list.
    """
    from xbmc import getInfoLabel
    return int(getInfoLabel(f'Container({list_id}).CurrentItem') or 0) - 1


def weak_callback(func: C | None) -> C | None:
    """
    Return the callback holding its object weakly if it is a bound method (e.g. of the window, see `AbstractWindow`),
    a call of a dead one does nothing (None); other callables (and None) as they are.
    """
    if not ismethod(func):
        return func
    method = WeakMethod(func)

    def call(*args: Any, **kwargs: Any) -> Any:
        """Call the method if its object lives."""
        if (bound := method()) is not None:
            return bound(*args, **kwargs)
        return None

    return cast(C, call)


def closes_on_kodi_exit(callback: C) -> C:
    """
    Decorate a Kodi callback of the window: a Kodi exit in it (e.g. a sign-in waits in `xsleep()`) closes the window
    (`AbstractWindow.kodi_exit()`), Kodi would report it as an error of the callback.
    """
    @wraps(callback)
    def call(self: AbstractWindow, *args: Any, **kwargs: Any) -> Any:
        """Call the callback, a Kodi exit closes the window."""
        try:
            return callback(self, *args, **kwargs)
        except KodiExit as exc:
            fflog(f'[WINDOW] {type(self).__name__}: Kodi exit in {callback.__name__}()')
            self.kodi_exit(exc)
            return None

    return cast(C, call)


#: Aspect ratio mode for ControlImage. 0 = stretch (default)
ASPECT_RATIO_FILL = ASPECT_RATIO_STRETCH = 0
#: Aspect ratio mode for ControlImage. 1 = scale up (crops)
ASPECT_RATIO_CROP = ASPECT_RATIO_SCALE_UP = 1
#: Aspect ratio mode for ControlImage. 2 = scale down (black bar)
ASPECT_RATIO_KEEP = ASPECT_RATIO_SCALE_DOWN = 2


@frozen
class WindowCommand:
    method: Callable
    args: Args
    kwargs: KwArgs


class WindowThread(Thread, Generic[B]):
    """Thread to call window's do_modal() in thread (non blocking)."""

    def __init__(self,
                 win_class: Type[B],
                 name: Optional[str] = None,
                 args: Args = (),
                 kwargs: KwArgs = {},  # noqa: B006
                 ) -> None:
        super().__init__(name=name)
        #: Window class to create the window.
        self.win_class = win_class
        #: Arguments for window create.
        self.args: Args = args
        #: Keyword arguments for window create.
        self.kwargs: KwArgs = kwargs
        #: The window.
        self.win: B | None = None
        #: Thread condition variable for window creation.
        self.win_ready = Condition()
        #: Window commands (do_modal/doModal) queue.
        self.win_commands: Queue[WindowCommand | None] = Queue()
        #: The exception of the window constructor (the creator waiting for the window raises it).
        self.exc: BaseException | None = None

    def run(self) -> None:
        """Do job. Main thread proc."""
        from ..ff.kotools import KodiMonitor
        if const.debug.log_gui:
            fflog.debug(f'••• [TH] create win {self.win_class}, {self.args}, {self.kwargs}')
        try:
            self.win = self.win_class(*self.args, **self.kwargs)
        except BaseException as exc:
            self.exc = exc
        finally:
            if const.debug.log_gui:
                fflog.debug('••• [TH] notify')
            with self.win_ready:
                self.win_ready.notify()
        if self.win is None:
            return
        try:
            # Kodi exit stops the thread (the window closes) for the whole life of the thread, not only of a command
            with KodiMonitor.instance().abort_context(self.stop):
                while True:
                    fflog.debug('••• [TH] wait for command')
                    cmd = self.win_commands.get()
                    fflog.debug(f'••• [TH] {cmd=}')
                    if not cmd:
                        break
                    cmd.method(*cmd.args, **cmd.kwargs)
                    self.win_commands.task_done()
        finally:
            if const.debug.log_gui:
                fflog.debug('••• [TH] close')
            self.win.close()
            # the window keeps its thread (`_thread`): the thread must not keep the window (see `AbstractWindow`)
            self.win = None
        if const.debug.log_gui:
            fflog.debug('••• [TH] finished')

    def command(self, method: Callable, *args, **kwargs) -> None:
        """Postpone window method call."""
        self.win_commands.put(WindowCommand(method, args, kwargs))

    def stop(self) -> None:
        """Stop the window thread."""
        self.win_commands.put(None)


class _WindowMetaClass(type):
    """Base Window meta-class to modify __init__ arguments."""

    def __call__(self, *args, **kwargs):
        return super().__call__(*args, **kwargs).__wrapped__


@frozen
class XmlWindowsArgs:
    xml_filename: str
    script_path: str
    default_skin: str
    default_res: str
    xml_source: Path
    xml_path: Path
    customized_xml: bool
    custom_data: CustomXmlData
    #: The stamp of the environment of the XML (`_customize_xml_stamp()`), '' unknown or not generated.
    env: str = ''

    @property
    def media_path(self) -> Path:
        """Path to media folder for XML."""
        return self.xml_path.parent.parent / 'media'


class AbstractWindow:
    """
    Mix-in class for Window and Dialog with custom XML support.

    Nothing the window keeps may keep the window: the attributes of a Kodi window (a SWIG object) are invisible to
    the GC, a cycle through the window (window → helper → window) is never collected and the window with all it keeps
    (its items) outlives the script (Kodi: "has left several classes in memory"). A helper keeps the window by
    `WindowRef`, a callback of the window by `weak_callback()`.
    """

    XML: ClassVar[str] = ''
    DEFAULT_ACTIONS_ENABLED: ClassVar[bool] = True
    #: The widgets of a window made of them (None: an old window).
    _widget_tree: WidgetTree | None = None
    #: The state of a window opened again (`restore()`): its focus is set after `on_init()`; None: not opened again.
    _reopened: dict[str, Any] | None = None
    #: The stamp of the environment of the window `do_modal()` executed last (opened again, `reopen()`: of the new one), '' none yet.
    shown_env: str = ''
    #: Python asked for the focus of a control (`setFocusId()`, `setFocus()`) in the open of the window (`onInit()`).
    _focus_asked: bool = False
    #: The control with the focus as the window saw it last (`onFocus()`): the focus of the state of a window whose skin is gone (`reopen_state()`).
    _last_focus: int = 0
    #: The control of the last click (`onClick`): Kodi sends the click of OK before its action - the action goes to it (`onAction`), 0 none.
    _clicked: int = 0
    #: The window is closed (`_claim_close()`): by the user, by Kodi or by the skin guard, the first of them only.
    _closed: bool = False

    if TYPE_CHECKING:
        ff_xml_args: XmlWindowsArgs
        custom_xml_data: CustomXmlData
        #: The window is shown (`onInit()` done) and not closed yet, its controls exist.
        _ready: bool
        #: Set on `onInit()` and on close, see `wait_ready()`.
        _ready_event: Event
        #: Last values of the bindings (window property -> value).
        _binding_values: dict[str, str]
        #: The batches of the bindings (`WindowBindings.batch()`): thread ident -> a refresh is deferred to the end.
        _binding_batches: dict[int, bool]
        #: Last enabled state set by `set_control_enabled()` (control ID -> enabled).
        _control_enabled: dict[int, bool]
        #: The end of the busy section of the open (`_open_busy()`): at the show of the window (`onInit()`), once.
        _end_busy: Callable[[], None]

        def getControl(self, iControlId: int) -> Control: ...

    def setFocus(self, pControl: Control) -> None:
        """Focus the control (Kodi), noted for the default control of the open (`onInit()`)."""
        self._focus_asked = True
        super().setFocus(pControl)  # type: ignore[misc]

    def setFocusId(self, iControlId: int) -> None:
        """Focus the control of the ID (Kodi), noted for the default control of the open (`onInit()`)."""
        self._focus_asked = True
        super().setFocusId(iControlId)  # type: ignore[misc]

    @classmethod
    def widget_source(cls, script_path: str) -> Path:
        """
        Return the source of the window made of widgets: its class name in snake case (`ConfigDialog` -> `config_dialog.xml`);
        a class with no source of its own takes the one of its nearest base class with a source (a variant of a window).
        """
        from ..ff.routing import camel_to_snake
        from .gui import WIDGETS_FOLDER
        folder = Path(script_path) / 'resources' / 'skins' / WIDGETS_FOLDER
        for klass in cls.__mro__:
            if issubclass(klass, AbstractWindow) and (path := folder / f'{camel_to_snake(klass.__name__)}.xml').exists():
                return path
        return folder / f'{camel_to_snake(cls.__name__)}.xml'

    @classmethod
    def xml_vars(cls, **kwargs) -> dict[str, Any] | None:
        """Get custom XML variables for window/dialog to apply in GUI templates."""
        return None

    @classmethod
    def xml_request(cls, **kwargs) -> CustomXmlRequest | None:
        """Get custom XML request for window/dialog."""
        xml_vars = cls.xml_vars(**kwargs)
        if xml_vars is None:
            request = None
        else:
            from .gui import CustomXmlRequest
            request = CustomXmlRequest(vars=xml_vars)
        return kwargs.pop('xml_request', request)

    @classmethod
    def _resolve_args(cls,
                      xmlFilename: Optional[str] = None,
                      scriptPath: Optional[str] = None,
                      defaultSkin: Optional[str] = None,
                      defaultRes: Optional[str] = None,
                      *args,
                      **kwargs,
                      ) -> XmlWindowsArgs:
        """Return the arguments of the Kodi window, its XML generated if not cached (a window of widgets)."""
        if xmlFilename is None:
            xmlFilename = cls.XML
        if scriptPath is None:
            scriptPath = control.addonPath
        if defaultSkin is None:
            defaultSkin = 'Default'
        if defaultRes is None:
            defaultRes = DEFAULT_RES
        xml_folder = xml_folder_of(scriptPath, defaultSkin, defaultRes)
        xml_source = xml_folder / xmlFilename
        customized_xml = False
        env = ''
        if not xmlFilename and (widget_source := cls.widget_source(scriptPath)).exists():  # a window of widgets
            xml_source, customized_xml = widget_source, True
        if customized_xml:
            # the output next to the default skin XML files: Kodi finds it there with the media folder of the window
            from .skinfonts import fonts_frozen
            with fonts_frozen():  # the fonts of the skin once for the template vars and the generation
                env = _customize_xml_stamp()  # first: it checks the style, the template vars read the style of now (`tokens()`)
                xmlFilename, custom_data = _customize_xml(xml_source, request=cls.xml_request(**kwargs), folder=xml_folder, env=env)
            xml_path = xml_folder / xmlFilename
        else:
            from .gui import CustomXmlData
            xml_path = xml_source
            custom_data = CustomXmlData()
        return XmlWindowsArgs(xmlFilename, scriptPath, defaultSkin, defaultRes, xml_source, xml_path, customized_xml, custom_data, env=env)

    @property
    def widgets(self) -> Widget:
        """Return the root of the widgets of the window (its children: the top widgets; `KeyError` for an old window)."""
        if self._widget_tree is None:
            raise KeyError(f'{type(self).__name__} is not made of widgets')
        return self._widget_tree.root

    @overload
    def find(self, path: str) -> Widget: ...

    @overload
    def find(self, path: str, cls: type[WDG]) -> WDG: ...

    def find(self, path: str, cls: type[WDG] | None = None) -> Any:
        """Return the widget of the window by its path (`KeyError` if there is none)."""
        return self.widgets.find(path) if cls is None else self.widgets.find(path, cls)

    @property
    def bindings(self) -> WindowBindings:
        """Bindings of the window (`{=expr}` template fields), call `refresh()` after the shown data changes (`batch()`: once)."""
        from .bindings import WindowBindings
        return WindowBindings(self)

    @property
    def can_reopen(self) -> bool:
        """Return True if `reopen()` opens the window again (a modal dialog of `BaseDialog.__new__()`); none of this class does."""
        return False

    @property
    def reopening(self) -> bool:
        """Return True if the window is closed by `reopen()` to be opened again at once; none of this class is."""
        return False

    def reopen_state(self) -> dict[str, Any]:
        """
        Return the state of the window an open again restores (`BaseDialog.reopen()`, `restore()`): the path of the widget with the
        focus and the name of its control (no widget: none). A window with its own state extends it (only texts, numbers: never
        the window or its parts). A window not shown (its skin gone: no Kodi call) gives the focus it saw last.
        """
        cid = self.focused_id() if self._ready else self._last_focus
        if self._widget_tree is None or (widget := self._widget_tree.widget_of(cid)) is None or widget.entry is None:
            return {}
        return {'focus': widget.path, 'control': next(name for name, wid in widget.entry.ids.items() if wid == cid)}

    def restore(self, state: dict[str, Any]) -> None:
        """
        Restore the state of the window opened again (`reopen_state()` of the closed one) before Kodi shows it (no Kodi controls yet,
        as in `__init__()`); the focus is set after `on_init()`. A window with its own state extends it.
        """
        self._reopened = state

    def _restore_focus(self, state: dict[str, Any]) -> None:
        """Focus the control of the state (`reopen_state()`) if its widget is there and visible, else the focus of the window stays."""
        if not (path := state.get('focus')):
            return
        try:
            widget = self.find(path)
            cid = widget.control_id(state.get('control', ''))
        except KeyError:  # not there any more, an old window
            return
        parent: Widget | None = widget
        while parent is not None and parent.entry is not None:
            if not parent.visible:
                return
            parent = parent.parent
        self.setFocusId(cid)

    def on_closing(self) -> bool | None:
        """Custom function called when window going to close. Custom callback. Return False to cancel software closing."""

    def on_close(self) -> bool | None:
        """Custom function called on window close. Custom callback."""

    def on_init(self) -> bool | None:
        """Kodi call it on window initialization, access to XML controls is allowed from now. Custom callback."""

    def default_action(self, action: Action) -> bool:
        """Handle default action."""
        action_id = action.getId()
        if action_id in CANCEL_ACTIONS:
            self.close()
            return True
        return False

    def on_action(self, action: Action) -> bool | None:
        """Kodi sent the action. Custom callback."""
        if self.default_action(action) is True:
            return True
        return None

    def on_click(self, control_id: int) -> bool | None:
        """Kodi sent the control's click. Custom callback."""

    def on_focus(self, control_id: int) -> bool | None:
        """Kodi sent the control's focus. Custom callback."""

    def on_control(self, control: Control) -> bool | None:
        """Kodi sent all click events on owned and selected controls when the control itself doesn't handle the message. Custom callback."""

    def on_notification(self, sender: str, method: str, data: str) -> bool | None:
        """Kodi notification handler. Custom callback."""

    def on_edit_finished(self, control_id: int) -> bool | None:
        """FanFilm sent the edit control finished editing. Custom callback."""

    def on_number_button(self, button: int) -> bool:
        """FanFilm sent the number button pressed. Custom callback. Return True if handled."""
        return False

    def _base_on_notification(self, sender: str, method: str, data: str) -> None:
        """Kodi notification handler."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onNotification: {sender=}, {method=}, {data=}')
        self.on_notification(sender, method, data)
        if sender == 'xbmc' and method == 'Input.OnInputFinished':
            self.on_edit_finished(self.focused_id())

    def is_topmost(self) -> bool:
        """
        Return True if the window is the topmost dialog of Kodi: nothing over it (a list of a row, a keyboard, a dialog of its own), by the
        name of its XML file. A call of Kodi (the GUI lock).
        """
        from xbmc import getCondVisibility
        return getCondVisibility(f'Window.IsDialogTopmost({self.ff_xml_args.xml_filename})')

    def is_active(self) -> bool:
        """
        Return True if Kodi still has the window, a dialog over it too (by the name of its XML file: Kodi tells no ID of a Python window). A
        reload of the skin destroys its controls without its close: a thread checks it right before it touches them (a touch of a destroyed
        control can crash Kodi). A call of Kodi: it waits for the GUI lock (about a frame).
        """
        from xbmc import getCondVisibility
        return getCondVisibility(f'Window.IsActive({self.ff_xml_args.xml_filename})')

    @classmethod
    def is_shown(cls) -> bool:
        """
        Return True if Kodi has a window of the class now, a dialog over it too, opened in any interpreter (a plugin call, the service): by
        the names of the XML files of its variants in the profile (`xmlcache.variant_names()`; an old window: its XML). A call of Kodi.
        """
        from xbmc import getCondVisibility
        from .xmlcache import variant_names
        script_path = control.addonPath
        if (source := cls.widget_source(script_path)).exists():
            names = variant_names(source, instance=_XML_INSTANCE, folder=xml_folder_of(script_path))
        else:
            names = [cls.XML]
        return getCondVisibility(' | '.join(f'Window.IsActive({name})' for name in names))

    def _skin_gone(self, state: dict[str, Any] | None) -> None:
        """Close the window whose skin is gone (`SkinGuard`), not asking `on_closing()`, once; only a modal dialog opens again with the state."""
        if self._claim_close():
            self._close_window()

    def _claim_close(self) -> bool:
        """Mark the window closed: True for the first one only (the user, Kodi, the skin guard close it in different threads)."""
        with _CLOSE_LOCK:
            closed, self._closed = self._closed, True
        return not closed

    def _already_closed(self) -> None:
        """Cleanup if already closed (by Kodi)."""
        from ..ff.kotools import KodiMonitor
        KodiMonitor.instance().remove_watcher(self._base_on_notification)
        self._set_ready(False)
        skin_guard.discard(self)
        self.on_close()

    def _close_window(self) -> None:
        """Close the Kodi window and clean up: the one way of a close `on_closing()` let through."""
        super().close()  # type: ignore[reportAttributeAccessIssue]
        self._already_closed()

    def close(self) -> bool:
        """Close the window unless `on_closing()` keeps it open (False), once."""
        if self.on_closing() is False:
            return False
        if self._claim_close():
            self._close_window()
        return True

    def kodi_exit(self, exc: KodiExit) -> None:
        """Kodi exits in a callback of the window (`closes_on_kodi_exit()`): close the window."""
        self.close()

    @closes_on_kodi_exit
    def onInit(self) -> None:
        """Kodi call it on window initialization, access to XML controls is allowed from now."""
        from ..ff.kotools import KodiMonitor
        if const.debug.log_gui:
            fflog(' +++++++++ onInit:')
        # Kodi keeps its cancellable busy dialog under a window opened while it waits for the plugin (e.g. play).
        # When this window closes, a quick Back hits the busy dialog and Kodi stops the script, processing other
        # messages meanwhile; a queued plugin call then deadlocks Kodi (K21, K22: CScriptInvocationManager::Stop
        # holds its lock in CPythonInvoker::stop). This window replaces the busy dialog anyway.
        self._end_busy()  # the one of the open, if it opened one
        control.close_busy_dialog()
        self.bindings.refresh()  # at once: `on_init()` may focus a control a binding shows
        self._focus_asked = False
        with self.bindings.batch():
            if self._widget_tree is not None:
                self._widget_tree.apply()
            self.on_init()
            if (state := self._reopened) is not None:  # opened again: the focus of the closed one, over the one of `on_init()`
                self._reopened = None
                self._restore_focus(state)
        if not self._focus_asked and (default := self.custom_xml_data.default_focus):  # a list Kodi could not focus: its items now
            self.setFocusId(default)
        KodiMonitor.instance().add_watcher(self._base_on_notification)
        self._set_ready(True)
        skin_guard.add(self)
        request_windows(self.ff_xml_args.env)  # shown: a worker of the other windows of a new environment no longer competes with it

    def _set_ready(self, ready: bool) -> None:
        """
        Set the window is shown (or closed), wake threads in `wait_ready()`; the inspector keeps the shown windows, the outline of the layout
        counts the generated ones (the Kodi debug info with them).
        """
        was, self._ready = self._ready, ready
        self._ready_event.set()
        if const.dev.inspector.enabled:
            from .inspector import track
            track(self, ready)
        if const.dev.outline.enabled and ready != was and self.ff_xml_args.customized_xml:
            from .outline import track_window
            track_window(ready)

    def wait_ready(self, timeout: Optional[float] = None) -> bool:
        """
        Wait until Kodi shows the window. Return True if it is shown, False if closed (or never shown), on timeout or Kodi exit.

        Kodi loads the window XML and calls `onInit()` only after `doModal()` / `show()`, a thread which updates
        the window must not touch its controls before (they do not exist yet).
        """
        self._ready_event.wait(timeout)
        return self._ready

    @closes_on_kodi_exit
    def onAction(self, action: Action) -> None:
        """Kodi sent the action."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onAction: id = {action.getId()!r}, amount = {action.getAmount1()!r}, {action.getAmount2()!r},'
                  f' button = {action.getButtonCode()!r}')
        if const.dev.inspector.enabled:
            from .inspector import on_action
            if on_action(self, action):
                return
        if const.dev.outline.enabled and action.getId() == const.dev.outline.key:
            from .outline import toggle_outline
            toggle_outline()
            return
        clicked, self._clicked = self._clicked, 0
        with self.bindings.batch():
            key = is_key_action(action.getId())
            focus = self.focused_id() if key or self._widget_tree is not None else 0  # once: Kodi takes the GUI lock to tell it
            if clicked and action.getId() == ACTION_SELECT_ITEM:
                # OK of the click before it (`onClick` first): the control clicked, not one the click focused meanwhile (a card it opened -
                # its focus is a thread message: the OK would close it at once)
                # ponytail: a click with no action after it (`SendClick`) keeps it to the next action; a key other than OK clears it
                focus = clicked
            if key and not focus and self._ready:
                # the mouse over no control took the focus; Kodi gives it back to the window <defaultcontrol> only (a list of items
                # from Python has none: `defer_default_control()`), the key gives back the last one (else the default) and goes on
                # to the window, not to the widgets: the focus is set by a Kodi thread message, no control has it yet
                # ponytail: the last focus hidden meanwhile (its group hidden by a binding, `Widget.visible` does not see it) gets no
                # fallback, check `Control.IsVisible()` of it and of its widgets if it ever happens
                if target := self._last_focus or self.custom_xml_data.default_focus:
                    self.setFocusId(target)
            if (btn := number_button(action)) is not None:
                if const.debug.log_gui:
                    fflog(f' +++++++++ onAction / on_number_button: {btn = }')
                if self.on_number_button(btn) is True:
                    return
            if self._widget_tree is not None and focus:  # the widget of the focused control, then its parents
                widget = self._widget_tree.widget_of(focus)
                while widget is not None and widget.entry is not None:
                    if widget.handle_action(action) is True:
                        return
                    widget = widget.parent
            if self.on_action(action) is True:
                return
            if self.DEFAULT_ACTIONS_ENABLED:
                self.default_action(action)

    @closes_on_kodi_exit
    def onClick(self, controlId: int) -> None:
        """Kodi sent the control's click."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onClick: {controlId = }')
        self._clicked = controlId
        with self.bindings.batch():
            if self._widget_tree is not None and (widget := self._widget_tree.widget_of(controlId)) is not None:
                if widget.handle_click(controlId) is True:
                    return
            self.on_click(controlId)

    @closes_on_kodi_exit
    def onFocus(self, controlId: int) -> None:
        """Kodi sent the control's focus."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onFocus: {controlId = }')
        if controlId != self.focused_id():  # the focus moved on (e.g. a held key, the window lags behind): its own event comes
            return
        self._last_focus = controlId
        with self.bindings.batch():
            if self._widget_tree is not None:
                self._widget_tree.focus(controlId)
            self.on_focus(controlId)

    @closes_on_kodi_exit
    def onControl(self, control: Control) -> None:
        """Kodi sent all click events on owned and selected controls when the control itself doesn't handle the message."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onControl: {control = }')
        self.on_control(control)

    def focused_id(self) -> int:
        """Return ID of focused control or zero if no focus."""
        try:
            return self.getFocusId()  # type: ignore[reportAttributeAccessIssue]
        except RuntimeError:  # from kodi docs: raises RuntimeError if no control has focus
            return 0

    def get_control(self, control_id: int, type: type[T] = Control) -> T | None:
        """Get control by ID or None if not found."""
        try:
            ctl = cast(T, self.getControl(control_id))
            if type and isinstance(ctl, type):
                return ctl
            return None
        except RuntimeError:
            return None

    def set_control_enabled(self, control_id: int, enabled: bool, *, focusable: bool = False, errors: Errors = 'ignore') -> None:
        """
        Enable or disable control by ID. A disabled `focusable` control looks disabled (a check box) but keeps the focus
        (its help can tell why it is disabled), the window ignores its clicks.
        """
        if self._control_enabled.get(control_id) != (state := bool(enabled or focusable)):  # a Kodi call waits for the GUI lock
            try:
                control = self.getControl(control_id)
            except RuntimeError:
                if errors == 'strict':
                    msg = f'No control {control_id!r} in {self.__class__.__name__}'
                    fflog(msg)
                    raise KeyError(msg)
                return
            self._control_enabled[control_id] = state
            control.setEnabled(state)

    def set_focus(self, control: Control | int) -> None:
        """Set focus to control by ID or Control."""
        if isinstance(control, int):
            self.setFocusId(control)
        else:
            self.setFocus(control)

    def set_focus_shown(self, control_id: int, *, shown: int = 0) -> None:
        """
        Set the focus to a control a window property just shows (its `<visible>`, `shown`: the one of its group - `Control.IsVisible()` of
        Kodi is of the control itself, not of its parents): Kodi shows it at its next frame and refuses the focus of a hidden one (the focus
        lost or moved on: another control has it), so the focus waits till Kodi shows it (at most `const.tune.gui.set_xml_value_lag`).
        """
        from xbmc import getCondVisibility
        end = monotonic() + const.tune.gui.set_xml_value_lag
        while not getCondVisibility(f'Control.IsVisible({shown or control_id})') and monotonic() < end:
            sleep(KODI_FRAME)
        self.setFocusId(control_id)

    def add_items(self, control_id: int, items: Sequence[Union[str, ListItem]]) -> None:
        """
        Set the items of the control list `control_id` (the old ones are removed).

        The list shares a `ListItem` with Kodi, a shown row gets its layout bound to the list. Kodi 21 frees the layouts
        of the rows in the list with the window only: a removed row must not outlive the window (give the list new items,
        keep the removed ones in no cache / cycle), freed after it, it crashes Kodi (`RemoveLookup()` of a freed list).
        """
        control = self.getControl(control_id)
        if isinstance(control, ControlList):
            control.reset()
            control.addItems(items)  # type: ignore[reportArgumentType]  # ControlList.addItems() accepts Sequence[]


class BaseWindow(AbstractWindow, WindowXML, metaclass=make_mutable_metaclass(WindowXML)):

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: str = control.addonPath,
                defaultSkin: str = 'Default',
                defaultRes: str = DEFAULT_RES,
                *args,
                **kwargs) -> Self:
        t = monotonic()
        obj: BaseWindow
        end_busy = _open_busy()
        try:
            xml_args = cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
            obj = super().__new__(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args)
        except BaseException:
            end_busy()
            raise
        obj._end_busy = end_busy
        finalize(obj, end_busy)  # a window never shown
        obj._ready = False
        obj._ready_event = Event()
        obj._binding_values = {}
        obj._binding_batches = {}
        obj._control_enabled = {}
        obj.custom_xml_data = xml_args.custom_data
        obj.ff_xml_args = xml_args
        obj._widget_tree = _widget_tree(obj, xml_args.custom_data)
        obj.__init__(xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args, **kwargs)
        fflog(f'XML Window {cls.__name__} created in {monotonic() - t:.3f} seconds')
        return obj


class BaseDialog(AbstractWindow, WindowXMLDialog, Generic[RESULT], metaclass=make_mutable_metaclass(WindowXMLDialog)):

    if TYPE_CHECKING:
        _result: RESULT | None
        _exception: Optional[BaseException]
        _thread: WindowThread | None
        #: The call which created the dialog (its class, the arguments as given): `reopen()` creates a new one by it; None unknown
        #: (a class of its own `__new__()`: the arguments given to it are not these ones).
        _creation: WindowCommand | None
        #: The state of an open again asked by `reopen()` (`do_modal()` opens it), None not asked.
        _reopen: dict[str, Any] | None
        #: The XML of the new window of an open again asked by `reopen()` (resolved before the close), None: resolved by its creation.
        _reopen_xml: XmlWindowsArgs | None
        #: The state of the open again the skin guard gave (`_skin_gone()`): `_reopen` once its close is claimed (`_do_modal()`).
        _skin_state: dict[str, Any] | None

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: Optional[str] = None,
                defaultSkin: Optional[str] = None,
                defaultRes: Optional[str] = None,
                *args,
                modal: bool = True,
                busy: bool = True,
                _call_init: bool = False,
                **kwargs) -> Self:
        t = monotonic()
        obj: Self
        if const.debug.log_gui:
            fflog.debug(f'BaseDialog.__new__({cls=}, {xmlFilename=}, {scriptPath=}, {defaultSkin=}, {defaultRes=}, {args=}, {modal=}, {_call_init=}, ...)')
        # fflog.debug(f'BaseDialog.__new__({cls=}, {xmlFilename=}, {scriptPath=}, {defaultSkin=}, {defaultRes=}, {args=}, {modal=}, {_call_init=}, {kwargs=})')
        end_busy = _open_busy(busy)
        try:
            # (the window closed to open this one resolved it already, `do_modal()`: not twice)
            xml_args = _reopen_xml.pop(cls, None) or cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
            if modal:
                obj = super().__new__(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res)
                obj._thread = None
            else:
                # for non-blocking dialogs, window is created in thread
                th = WindowThread[Self](super().__new__, name=f'WindowThread.{xml_args.xml_filename}',
                                        args=(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args))
                if const.debug.log_gui:
                    fflog.debug(f'••• start thread {th}')
                th.start()
                with th.win_ready:
                    if const.debug.log_gui:
                        fflog.debug('••• wait for window')
                    th.win_ready.wait_for(lambda: th.win is not None or th.exc is not None)
                if th.win is None:
                    raise RuntimeError(f'Window {cls.__name__} can not be created: {th.exc!r}') from th.exc
                obj = th.win
                obj._thread = th
        except BaseException:
            end_busy()
            raise
        obj._end_busy = end_busy
        finalize(obj, end_busy)  # a window never shown
        obj._closed = False
        obj._result = None
        obj._exception = None
        obj._creation = None
        if cls.__new__ is BaseDialog.__new__ and modal and not _call_init:  # the defaults: given as they are
            obj._creation = WindowCommand(cls, (xmlFilename, scriptPath, defaultSkin, defaultRes, *args), kwargs if busy else {**kwargs, 'busy': busy})
        obj._reopen = None
        obj._reopen_xml = None
        obj._skin_state = None
        obj._ready = False
        obj._ready_event = Event()
        obj._binding_values = {}
        obj._binding_batches = {}
        obj._control_enabled = {}
        obj.custom_xml_data = xml_args.custom_data
        obj.ff_xml_args = xml_args
        obj._widget_tree = _widget_tree(obj, xml_args.custom_data)
        if _call_init:
            if const.debug.log_gui:
                fflog.debug('••• init')
            obj.__init__(xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args, **kwargs)
        if const.debug.log_gui:
            fflog.debug('••• created')
        fflog(f'XML Window {cls.__name__} created in {monotonic() - t:.3f} seconds')
        return obj
        # return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def __init__(self, *args, **kwargs) -> None:
        """Useless, because WindowXMLDialog uses __new__ only."""
        pass

    def raise_exception(self, exception: BaseException) -> None:
        """Set exception to raise from do_modal() / doModal()."""
        self._exception = exception

    def kodi_exit(self, exc: KodiExit) -> None:
        """
        Kodi exits in a callback: close the dialog, a modal one raises the exit from `do_modal()` (the caller ends as
        without the window); a modeless one only closes (no one waits in `do_modal()`, a kept exception would keep
        its traceback, i.e. the window).
        """
        if self.is_modal():
            self.raise_exception(exc)
        self.close()

    def result(self) -> RESULT | None:
        """Get result of dialog."""
        if self._closed:
            return self._result
        raise RuntimeError('Dialog is not closed yet, call do_modal() or close() first.')

    def set_result(self, result: Any) -> None:
        """Explicit set the result. Useful with do_modal() / doModal()."""
        self._result = result

    def close(self, result: RESULT | MissingType | None = MISSING) -> bool:
        fflog.debug(f'••• going to close (closed={self._closed})')
        if self._closed:
            return True
        if result is not MISSING:
            if TYPE_CHECKING:
                assert not isinstance(result, MissingType)
            self._result = result
        if self.on_closing() is False:
            fflog.debug('••• close cancelled')
            return False  # not closed: the next close() is not a no-op
        self._shut()
        return True

    def _shut(self) -> None:
        """Close the dialog (`on_closing()` asked already, or not to ask), once."""
        if not self._claim_close():
            return
        if self._thread:
            if const.debug.log_gui:
                fflog.debug('••• postpone exit')
            self._thread.stop()
        if const.debug.log_gui:
            fflog.debug('••• close')
        self._close_window()  # not super().close(): it would ask on_closing() again and call on_close() twice
        if const.debug.log_gui:
            fflog.debug('••• finished')

    def _skin_gone(self, state: dict[str, Any] | None) -> None:
        """
        Close the dialog whose skin is gone (`SkinGuard`, its thread), not asking `on_closing()`. A modal one only gets the close of Kodi:
        its `do_modal()` returns and cleans up in the thread of the window (`_do_modal()`, before an open again with the state, so the old
        `on_close()` runs before the new window), the open again only if that close is the first one (not a Back of the user meanwhile).
        A modeless one (no one waits in `do_modal()`) is cleaned up here.
        """
        if self._thread:
            self._shut()
            return
        self._skin_state = state if self.can_reopen else None
        WindowXMLDialog.close(self)

    @property
    def can_reopen(self) -> bool:
        """Return True if `reopen()` opens the dialog again (a modal one of `BaseDialog.__new__()`), False if it only closes it."""
        return self._creation is not None

    @property
    def reopening(self) -> bool:
        """Return True if the dialog is closed by `reopen()` to be opened again at once (its `do_modal()` opens the new one)."""
        return self._reopen is not None

    def reopen(self, state: dict[str, Any] | None = None) -> bool:
        """
        Close the dialog to open it again at once with the state (None: `reopen_state()`): its `do_modal()` creates a new window of
        its class with the same arguments (the window XML generated again: e.g. of a new style), restores the state (`restore()`) and
        returns the result of the new one. The XML of the new window is resolved first, this one still shown (generated if not cached: the
        busy dialog as of its creation; the new window takes it as it is): the same cached XML - the window stays as it is. Return False
        if the window stays (the caller shows its data again itself), True if it closes. Only a modal dialog created by
        `BaseDialog.__new__()` is opened again; another one only closes (logged).
        """
        from .xmlcache import SHARED_SUFFIX
        creation = self._creation
        if creation is not None:
            kwargs = {key: value for key, value in creation.kwargs.items() if key != 'busy'}
            end_busy = _open_busy(creation.kwargs.get('busy', True))
            try:
                xml_args = type(self)._resolve_args(*creation.args, **kwargs)
            finally:
                end_busy()
            name = xml_args.xml_filename
            if name == self.ff_xml_args.xml_filename and not name.endswith(SHARED_SUFFIX):  # (the shared file: of any content)
                return False
            self._reopen, self._reopen_xml = self.reopen_state() if state is None else state, xml_args
        else:
            fflog(f'[WINDOW] {type(self).__name__}: not opened again (a modeless dialog or its own __new__()), only closed')
        if not self.close():  # `on_closing()` keeps it open: no open again
            self._reopen = self._reopen_xml = None
            return False
        return True

    def do_modal(self) -> RESULT | None:
        """
        Execute the window. Call do_modal() / doModal() direct (modal) or in thread (modeless). A modal dialog closed by `reopen()`
        is opened again: a new window, its result returned (the caller sees one call).
        """
        self.shown_env = self.ff_xml_args.env
        result = self._do_modal()
        creation, state, xml_args, self._reopen, self._reopen_xml = self._creation, self._reopen, self._reopen_xml, None, None
        while state is not None and creation is not None:  # a local only: neither window keeps the other one (`AbstractWindow`)
            if not skin_guard.wait_loaded():  # closed by a reload of the skin: the new one first
                fflog(f'[WINDOW] {creation.method.__name__}: the new skin is not loaded or Kodi exits, not opened again')
                break
            if xml_args is not None:  # resolved by the closed one (`reopen()`): only for this creation
                _reopen_xml[creation.method] = xml_args
            try:
                win = creation.method(*creation.args, **creation.kwargs)
            finally:
                _reopen_xml.pop(creation.method, None)
            win.restore(state)
            self.shown_env = win.ff_xml_args.env
            result = win._do_modal()
            state, xml_args, win._reopen, win._reopen_xml = win._reopen, win._reopen_xml, None, None
            del win
        return result

    def _do_modal(self) -> RESULT | None:
        """Execute the window once (see `do_modal()`)."""
        if self._thread:
            self.show()
            if const.debug.log_gui:
                fflog.debug(f'••• postpone {self.doModal}')
            if 1 or type(self) is BaseDialog:
                parent_do_modal = super().doModal
            else:
                parent_do_modal = super().do_modal  # type: ignore[reportAttributeAccessIssue]  # called in derived class, then do_modal exists
            fflog.debug(f'••• sending {parent_do_modal}')
            self._thread.command(parent_do_modal)  # the thread itself stops on Kodi exit (`WindowThread.run()`)
            if const.debug.log_gui:
                fflog.debug(f'••• sent {parent_do_modal}')
        else:
            super().doModal()
            self._end_busy()  # closed without its show (no `onInit()`)
            if self._claim_close():  # closed by Kodi (the skin guard too: opened again with its state)
                if self._skin_state is not None:
                    self._reopen = self._skin_state
                self._already_closed()
            self._skin_state = None
        if (exc := self._exception) is not None:
            # The dialog must not keep the exception: its traceback holds this frame (and `self`), that cycle
            # runs through a Kodi object, GC can not see it and the dialog with its items leaks (Kodi warns
            # "left several classes in memory" on the interpreter exit).
            self._exception = None
            try:
                raise exc
            finally:
                del exc
        return self._result

    def doModal(self) -> Any:
        """Execute the window. Call doModal direct (modal) or in thread (modeless)."""
        return self.do_modal()

    def is_modal(self) -> bool:
        """Return True if dialog is modal."""
        return not self._thread

    def destroy(self) -> None:
        """Close and clean up."""
        self.close()
        if self._thread:
            self._thread.join()


#: The close of a window is claimed under it (`AbstractWindow._claim_close()`).
_CLOSE_LOCK: Lock = Lock()


@define
class _Guarded:
    """A window under the skin guard (`SkinGuard`)."""

    #: The window, held weakly.
    ref: Callable[[], AbstractWindow | None]
    #: Kodi had the window active once (`Window.IsActive()`): Kodi makes it active after `onInit()`.
    seen: bool = False
    #: Kodi 22 had it not active, no reload of the skin announced yet: the time of it (`monotonic()`), 0 not.
    lost: float = 0
    #: Its skin is gone (`GUI.OnSkinUnloading`): the guard thread closes it.
    gone: bool = False
    #: The state of its open again (`reopen_state()`), None: only closed.
    state: dict[str, Any] | None = None


class SkinGuard:
    """
    The shown windows against a reload of the skin: Kodi destroys their controls without a close, `doModal()` of Python would wait till the
    Kodi exit. Kodi 22 announces it (`GUI.OnSkinUnloading`, then `GUI.OnSkinLoaded` / `GUI.OnSkinLoadFailed`): the one shown window, a dialog
    which can be opened again (`can_reopen`), opens again once the new skin is loaded, with its state from Python (`reopen_state()`); several
    shown windows (one over another) only close. Kodi 21 tells nothing, so (and as a fallback of Kodi 22) one thread polls every
    `const.tune.gui.skin_guard_interval` `Window.IsActive(<xml>)` of every shown window (true under a dialog, a video): a window seen active,
    then not, closes. Kodi 22 tells Python of the reload a bit later than its windows go (about 0.1 s), so there a window seen gone by the
    poll waits one interval for the announcement: it comes — a reload (opened again as above), it does not — Kodi closed it for another
    reason (only closed). A window whose skin is gone is not ready at once (a thread checking `wait_ready(0)` leaves its controls alone),
    then the guard thread closes it (a close of Kodi from any thread; not in the notification: a watcher must not remove a watcher). The
    windows held weakly; the thread (and its watcher) ends when no window is shown and no reload is pending.
    """

    def __init__(self) -> None:
        """No window, no thread."""
        #: Guards the state below.
        self._lock: Lock = Lock()
        #: The shown windows.
        self._windows: list[_Guarded] = []
        #: Wakes the thread (a window gone, closed, the skin loaded).
        self._wake: PlainEvent = PlainEvent()
        #: Kodi announces the reloads of the skin (Kodi 22).
        self.announces: bool = kodi_version >= 22
        #: Set unless a reload of the skin is pending (unloaded, not loaded yet); its wait ends on a Kodi exit.
        self._loaded: Event = Event()
        self._loaded.set()
        #: The last reload failed (`GUI.OnSkinLoadFailed`) or its load did not come in time.
        self._failed: bool = False
        #: The time of the last unload of the skin.
        self._unloaded_at: float = 0
        #: The thread (None: not running).
        self._thread: Thread | None = None
        #: The remove of the notification watcher of the thread (None: not watching).
        self._unwatch: Callable[[], None] | None = None

    def add(self, win: AbstractWindow) -> None:
        """Guard the shown window (`onInit()`), the thread started if not running."""
        with self._lock:
            if any(guarded.ref() is win for guarded in self._windows):
                return
            self._windows.append(_Guarded(weak_ref(win)))
            if self._loaded.is_set():
                self._failed = False  # a window shown: the skin works (a failed reload is over)
            if self._thread is None:
                from ..ff.kotools import KodiMonitor
                monitor = KodiMonitor.instance()
                monitor.add_watcher(self.on_notification)
                self._unwatch = lambda: monitor.remove_watcher(self.on_notification)
                self._thread = Thread(target=self._run, name='SkinGuard', daemon=True)
                self._thread.start()

    def discard(self, win: AbstractWindow) -> None:
        """
        Forget the closed window; the last one waits for the end of the thread (at most an interval): a thread alive at the end of the
        script can hang the interpreter of Kodi 22.
        """
        with self._lock:
            self._windows = [guarded for guarded in self._windows if guarded.ref() not in (win, None)]
            thread = self._thread if not self._windows else None
        self._wake.set()
        if thread is not None and thread is not current_thread():
            thread.join(const.tune.gui.skin_guard_interval)

    def wait_loaded(self) -> bool:
        """
        Wait for the load of a new skin (none pending: at once), at most `const.tune.gui.skin_load_timeout`; return False if it failed or
        Kodi exits (no window opened again).
        """
        return self._loaded.wait(const.tune.gui.skin_load_timeout) and not self._failed and not wait_ended()

    def on_notification(self, sender: str, method: str, data: str) -> None:
        """Kodi 22 unloads the skin: every shown window is not ready, gone (the one shown dialog with its state); the skin loaded (or not)."""
        if sender != 'xbmc':
            return
        if method == 'GUI.OnSkinUnloading':
            with self._lock:
                self._failed = False
                self._loaded.clear()
                self._unloaded_at = monotonic()
                shown = [(guarded, win) for guarded in self._windows
                         if (win := guarded.ref()) is not None and not guarded.gone and (win._ready or guarded.lost)]
                for guarded, win in shown:
                    guarded.lost = 0  # announced: the poll does not give it up meanwhile
            for guarded, win in shown:
                if win._ready:
                    win._set_ready(False)
            if len(shown) == 1:
                [(guarded, win)] = shown
                if win.can_reopen:
                    guarded.state = win.reopen_state()  # not ready: no Kodi call
            for guarded, win in shown:
                guarded.gone = True
            del shown
            self._wake.set()
        elif method in ('GUI.OnSkinLoaded', 'GUI.OnSkinLoadFailed'):
            self._failed = method == 'GUI.OnSkinLoadFailed'
            self._loaded.set()
            self._wake.set()

    def _run(self) -> None:
        """Poll the shown windows, close the ones whose skin is gone; end when none is shown and no reload is pending."""
        while True:
            self._wake.wait(const.tune.gui.skin_guard_interval)
            self._wake.clear()
            with self._lock:
                if not self._loaded.is_set() and monotonic() - self._unloaded_at > const.tune.gui.skin_load_timeout:
                    self._failed = True  # no load announced in time: a window waiting for it only closes
                    self._loaded.set()
                self._windows = [guarded for guarded in self._windows if guarded.ref() is not None]
                if not self._windows and self._loaded.is_set():
                    if self._unwatch is not None:
                        self._unwatch()
                    self._thread = self._unwatch = None
                    return
                windows = list(self._windows)
            for guarded in windows:
                if (win := guarded.ref()) is None:
                    continue
                if not guarded.gone and win._ready:
                    if win.is_active():
                        guarded.seen = True
                    elif guarded.seen and win._ready:  # not closed meanwhile
                        win._set_ready(False)
                        if self.announces:  # its announcement comes a bit later (`on_notification()`)
                            guarded.lost = monotonic()
                        else:
                            guarded.gone = True
                elif not guarded.gone and guarded.lost:
                    with self._lock:  # not while its announcement is handled
                        if guarded.lost and monotonic() - guarded.lost >= const.tune.gui.skin_guard_interval:
                            guarded.gone = True  # no reload announced: closed by Kodi for another reason, only closed
                if guarded.gone:
                    fflog(f'[WINDOW] {type(win).__name__}: its skin is gone, {"opened again" if guarded.state is not None else "closed"}')
                    try:
                        win._skin_gone(guarded.state)
                    except Exception:
                        fflog_exc()
                    self.discard(win)
                del win


#: The guard of the shown windows against a reload of the skin.
skin_guard: SkinGuard = SkinGuard()


#: The XML of a window resolved by the one closed to open it (`BaseDialog.reopen()`), by its class: only while `do_modal()` creates it
#: (`BaseDialog.__new__()` takes it).
_reopen_xml: dict[type, XmlWindowsArgs] = {}


def _open_busy(busy: bool = True) -> Callable[[], None]:
    """
    Start the busy section of a window open (from the creation of the window to its show: the XML generated if not cached, Kodi loads
    it): the dialog only if the open still runs after `const.tune.gui.xml_busy_delay` (0: never; `busy` False: never, e.g. a window with
    the one under it for its wait). Return its end (once, later calls do nothing): the show of the window (`onInit()`), an error of the
    creation, the window closed or collected without its show.
    """
    stack = ExitStack()
    if busy and (delay := const.tune.gui.xml_busy_delay):
        stack.enter_context(control.busy_section(delay=delay))
    return stack.close


def _widget_tree(win: AbstractWindow, data: CustomXmlData) -> WidgetTree | None:
    """Return the widgets of the window from the manifest of its XML (None: an old window, no widgets)."""
    if not data.widgets:
        return None
    from .widgets import WidgetTree
    return WidgetTree(win, data.widgets)


def _customize_xml(xml_source: Path, *, request: CustomXmlRequest | None = None, folder: Path | None = None,
                   env: str | None = None) -> tuple[str, CustomXmlData]:
    """
    Fix window/dialog source XML to handle what kodi can not. Return the output XML file name and its data. `env`: the stamp of the
    environment (`_customize_xml_stamp()`, None: taken now) - taken before the request of the template vars, which read the style it checks.

    The processing is slow (1-2 s for the sources dialog), the output is cached (a variant for each different template data).
    An output which can not be written is an error: the source is a template (`ff:*`, `{…}`), Kodi can not show it.
    """
    from .gui import CustomXmlRequest, render_xml
    from .xmlcache import customized_xml
    if request is None:
        request = CustomXmlRequest()
    try:
        return customized_xml(xml_source, request, env=_customize_xml_stamp() if env is None else env, render=render_xml,
                              limit=const.tune.gui.xml_variants, folder=folder, instance=_XML_INSTANCE, foreign_ttl=const.tune.gui.xml_foreign_ttl)
    except IOError as exc:
        raise RuntimeError(f'Window XML {xml_source.name} can not be generated: {exc}') from exc


#: Instance (Kodi profile) of the customized XML files: Kodi instances and profiles share the add-on folder.
_XML_INSTANCE: str = hashlib.sha1(control.dataPath.encode('utf-8')).hexdigest()[:8]

#: The file of the profile data with the last complete `prepare_windows()` (`PreparedWindows`, JSON).
PREPARED_WINDOWS_FILE: str = 'windows-prepared.stamp'
#: Home window property: the environment (digest) a worker prepares the windows for now (one worker of it in a Kodi session).
PREPARING_WINDOWS_PROPERTY: str = 'fanfilm.windows.preparing'
#: The argument of the worker script (`worker.py`) of the windows only, at once: a window of a new environment was shown, the service
#: started (`environment_hint()`).
WINDOWS_JOB: str = 'windows'
#: The second argument of the worker of the windows: every window again, prepared for the environment or not (the template data of a
#: window changed, e.g. a setting of the sources in the Configuration: a new variant of the same environment).
WINDOWS_AGAIN: str = 'again'


@frozen(kw_only=True)
class PreparedWindows:
    """The last complete `prepare_windows()` (`PREPARED_WINDOWS_FILE`)."""

    #: The environment (digest) the windows were prepared for, '' never.
    env: str = ''
    #: The pointers of the configuration the preparation read: the stamp of the environment, the template data of every window.
    pointers: tuple[str, ...] = ()
    #: The digest of their values then (`_settings_digest()`), '' unknown (the configuration written during the preparation).
    digest: str = ''


def _prepared() -> PreparedWindows:
    """Return the last complete `prepare_windows()`, an empty one if never (or its file is not readable)."""
    try:
        data = json.loads((Path(control.dataPath) / PREPARED_WINDOWS_FILE).read_text(encoding='utf-8'))
        return PreparedWindows(env=str(data['env']), pointers=tuple(map(str, data['pointers'])), digest=str(data['digest']))
    except (OSError, ValueError, KeyError, TypeError):
        return PreparedWindows()


def _settings_digest(pointers: Sequence[str]) -> str:
    """Return the digest of the stored values at the pointers of the configuration (not of the declared defaults: they change with the code)."""
    from ..ff.config import config
    from .xmlcache import env_digest
    return env_digest(json.dumps([[pointer, config.get(pointer, None)] for pointer in sorted(pointers)], sort_keys=True))


def windows_preparing(stamp: str) -> bool:
    """Return True if a worker prepares the windows for the environment of the stamp now (`PREPARING_WINDOWS_PROPERTY`)."""
    from .xmlcache import env_digest
    return bool(stamp) and Window(control.HOME_WINDOW).getProperty(PREPARING_WINDOWS_PROPERTY) == env_digest(stamp)


def template_settings_changed(stamp: str) -> bool:
    """
    Return True if a setting the prepared windows depend on changed since their preparation: one read by the stamp of the environment
    (the themes) or by the template data of a window. Unknown (not prepared for the environment of the stamp): True. Any other
    write of the configuration (a setting no template reads, the memory of a tree) leaves every cached variant valid.
    """
    from .xmlcache import env_digest
    prepared = _prepared()
    return prepared.env != env_digest(stamp) or not prepared.digest or _settings_digest(prepared.pointers) != prepared.digest


def request_windows(stamp: str, *, again: bool = False) -> None:
    """
    Start the worker of the windows (`WINDOWS_JOB`) if they are not prepared for the environment of the stamp (a window of it
    is shown: `onInit()`), nor a worker prepares them; any change of the environment, in FF (the Appearance page writes, the
    Configuration opens again) or not (the skin, its colours, the language, a new FF), so the other windows open from the cache.
    `again`: prepared or not (`WINDOWS_AGAIN`: the template data changed in the same environment, a setting the windows read written).
    """
    if not stamp or not const.tune.gui.xml_prepare_delay:
        return  # an old window, unknown dependencies, never prepared
    from .xmlcache import env_digest
    env = env_digest(stamp)
    if not again and (env == _prepared().env or Window(control.HOME_WINDOW).getProperty(PREPARING_WINDOWS_PROPERTY) == env):
        return
    fflog(f'[WINDOWS] start the worker of the windows ({env}{", again" if again else ""})')
    start_windows_worker(again=again)


def start_windows_worker(*, again: bool = False) -> None:
    """
    Start the worker script of the windows (`WINDOWS_JOB`, `again`: `WINDOWS_AGAIN`). A start of a script ends the reuse of the plugin
    interpreter (the next call is a cold one), the call of this one and its window go on.
    """
    control.execute(f'RunScript({control.plugin_id},{WINDOWS_JOB}{f",{WINDOWS_AGAIN}" if again else ""})')


def environment_hint() -> tuple[str, ...]:
    """
    Return what the service watches of the environment of the windows (`_customize_xml_stamp()`), cheap and changed out of FF: the skin
    of the fonts (`font_stamp()`: Kodi, the skin, its version and files, its font, the symbol font), its colour theme, the language. A change
    starts the worker of the windows, which takes the whole stamp.
    """
    from xbmc import getInfoLabel, getLanguage
    from .skinfonts import font_stamp
    return (*font_stamp(), getInfoLabel('Skin.CurrentColourTheme'), getLanguage())


def prepare_windows(*, requested: bool = False, again: bool = False) -> int:
    """
    Generate the default variant (no arguments: what the routes open) of every window of widgets into the XML cache
    of the instance, as its first open would (`_resolve_args()`: the same stamp, instance and folder). Run by the worker
    script after a FanFilm update, `const.tune.gui.xml_prepare_delay` after its call (Kodi has its own start to do; 0: never),
    `requested` (a window of a new environment shown, `request_windows()`; the service: its start, a change of the skin...): at once.
    Nothing to do if the last complete run was of the same environment (`PREPARED_WINDOWS_FILE`) or a worker of it runs, unless `again`
    (the template data changed: a window with its variant cached costs the read of its manifest); a worker of another
    environment (a newer one) ends this one. After every window the worker waits as long as the window took (half of a core
    at most); the Kodi exit ends it at once in a wait, after the window of the moment in a generation: its announcement (`System.OnQuit`,
    the FF monitor of the worker sees it) comes long before the abort of the scripts (Kodi stops the services first, all the Python
    of Kodi shares one GIL). A change of the environment (`environment_hint()`, after every window) ends it without the stamp: the check
    of the service starts the worker of the new one. Return the number of the windows done (generated or found cached).
    """
    from .. import info
    from ..ff.kotools import kodi_abort_event
    from ..ff.threads import xsleep_until_exit
    def exits() -> bool:
        """Return True if Kodi exits: the monitor of the worker from its start sees the abort (a monitor made later does not), the FF one the announcement."""
        return monitor is None or monitor.abortRequested() or kodi_abort_event.is_set()

    monitor = info.script_monitor
    if exits():
        return 0
    if not (delay := const.tune.gui.xml_prepare_delay) or (not requested and xsleep_until_exit(delay)):
        return 0  # never (the first open of a window generates it) or Kodi exits
    from ..ff.config import config, file_stat
    hint = environment_hint()  # before the stamp: a change between them ends the worker after its first window
    written = file_stat(config.path())  # a window prepared before a write read the older values
    with config.reads() as pointers:  # the settings of the stamp (the themes)
        stamp = _customize_xml_stamp()
    if not stamp:
        return 0  # unknown dependencies: nothing is cached
    from .xmlcache import env_digest
    env = env_digest(stamp)
    prepared = Path(control.dataPath) / PREPARED_WINDOWS_FILE
    if not again and _prepared().env == env:
        fflog(f'[WINDOWS] prepared already ({env})')
        return 0
    home = Window(control.HOME_WINDOW)
    if not again and home.getProperty(PREPARING_WINDOWS_PROPERTY) == env:
        fflog(f'[WINDOWS] a worker of this Kodi session took them ({env})')
        return 0
    # Checked, then set: two workers started at the same moment both run (the cache takes it). One attempt of an environment in a Kodi
    # session: an error (the worker logs it) keeps the property - it would come again, a worker started by every shown window
    # (`request_windows()`) would end the reuse of the plugin interpreter each time; the first open of a window generates it, the next
    # session tries again.
    home.setProperty(PREPARING_WINDOWS_PROPERTY, env)
    from .render import window_classes
    from .skinfonts import fonts_frozen
    started = monotonic()
    count = 0
    # the fonts of the skin once for all the windows; the settings their modules and template data read
    # ponytail: any read of the block counts (a log switch read by the first log too): a needless worker at most, read by the windows only if it matters
    with fonts_frozen(), config.reads() as window_pointers:
        for cls in window_classes():
            if home.getProperty(PREPARING_WINDOWS_PROPERTY) != env:
                fflog(f'[WINDOWS] {count} windows prepared, a worker of another environment goes on')
                return count
            start = monotonic()
            try:
                cls._resolve_args()
            except Exception:
                fflog_exc()
            count += 1
            # ponytail: the window of the moment is never cut (a Pi 4: up to 2.8 s, the configuration), a check inside the generation if it matters
            if exits() or xsleep_until_exit(monotonic() - start):  # the wait of a monitor made after the abort would take the time of the window
                fflog(f'[WINDOWS] {count} windows prepared, Kodi exits')
                return count  # no Kodi call: the stopping Kodi holds the GUI lock (a window property waits for it)
            if environment_hint() != hint:  # the next windows would be of another environment, under the stamp of this one
                if home.getProperty(PREPARING_WINDOWS_PROPERTY) == env:
                    home.clearProperty(PREPARING_WINDOWS_PROPERTY)  # this environment may come back (the skin switched back)
                fflog(f'[WINDOWS] {count} windows prepared, the environment changed (the service starts its worker)')
                return count
    from ..ff.config.store import write_json_atomic
    pointers |= window_pointers
    digest = _settings_digest(tuple(pointers)) if file_stat(config.path()) == written else ''
    write_json_atomic(prepared, {'env': env, 'pointers': sorted(pointers), 'digest': digest})
    home.clearProperty(PREPARING_WINDOWS_PROPERTY)
    fflog(f'[WINDOWS] {count} windows prepared ({env}) in {monotonic() - started:.2f} s')
    return count


def _customize_xml_stamp() -> str:
    """Return stamp of the environment the customized XML depends on, or empty string if unknown."""
    try:
        import cdefs
        from xbmc import getLanguage
        from ..kodi import version_info
        from .skinfonts import font_stamp
        from .style import check_style
        from .gui import texture_stamp
        from .xgui import widget_stamp
        from ..ff.filecache import mtime_stamp
        addon = Path(control.addonPath)
        # only the XML files (`rglob('*')` made a Path of every texture and output file: half of every cached window open)
        files = [path for path in (addon / 'resources' / 'skins').rglob('*.xml') if not path.name.startswith('tmp--')]
        files.extend(Path(__file__).parent.glob('*.py'))
        files.extend((Path(__file__).parent / 'widgets').glob('*.py'))  # the widget classes: their template data (`frames.py` ...)
        files.extend((addon / 'lib' / 'ff' / 'tricks.py', addon / 'lib' / 'ff' / 'format.py', addon / 'lib' / 'kolang.py',
                      addon / 'const.py', addon / 'cdefs.py'))
        files.extend((addon / 'resources' / 'language').rglob('*.po'))  # L() texts
        if cdefs.local_path is not None and cdefs.local_path.is_file():
            files.append(cdefs.local_path)
        if not (mtimes := mtime_stamp(files)):
            return ''
        # font_stamp(): skin, fontset; check_style(): the style files read again if changed; texture_stamp(): the textures of the themes
        # (after the style: the variant of their surface); widget_stamp(): the widgets of the themes
        return repr((control.addonInfo('version'), font_stamp(), check_style().stamp, texture_stamp(), widget_stamp(), getLanguage(),
                     tuple(version_info), mtimes))
    except Exception:
        fflog_exc()
        return ''
