"""
The folders of the configuration window (its page: `lib.windows.widgets.folders`): when a level of a menu of lists is a folder
(`When`: never, if many, always - one of them in a row; `lib.ff.lists_config.FOLDER_POINTS`), with a preview of the lists in
the main menu built by the menu builder itself (no network: the user lists of an account are a placeholder).
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from cdefs import When
from ..ff import lists_config as lc
from ..ff.lists_config import when_label
from ..kolang import L
from .style import tokens
if TYPE_CHECKING:
    from ..ff.lists_config import FolderPoint
    from ..indexers.lists_menu import MenuNode, MenuScope

#: The values of a row in the order of the columns.
WHENS: tuple[When, ...] = (When.NEVER, When.IF_MANY, When.ALWAYS)
#: The depth of the preview (folders opened).
PREVIEW_DEPTH = 3
#: The lines of the preview at most.
PREVIEW_LINES = 40
#: The indent of a level of the preview (no-break spaces: kept by Kodi).
INDENT = '\u00a0' * 4
#: The left of the columns (the labels of the rows before them).
X0 = 470
#: The width of a column.
STEP = 120
#: The height of a row.
ROW_H = 29
#: The height of the head (the labels of the columns).
HEAD = 40


def preview_lines(group: str = 'main') -> list[str]:
    """
    Return the lines of the preview of the menu of the group (`lc.FOLDER_GROUPS`): its context (`· …` - the other entries
    of the menu above), the folder of the group or its entries in place, their folders opened. The lists in the main menu
    are the main menu too (they are in it, in their folder or in place).
    """
    from ..indexers.lists_menu import MenuScope, build_menu, pointer_scope

    def route(scope: MenuScope) -> MenuScope:
        """Return the scope itself (a folder of the preview is opened by it)."""
        return scope

    def level(menu_id: str, scope: MenuScope, depth: int, prefix: str, nodes: list[MenuNode] | None = None) -> list[str]:
        """Return the lines of a level of the menu (`nodes`: its nodes built already)."""
        out: list[str] = []
        for node in build_menu(menu_id, scope, route=route) if nodes is None else nodes:  # type: ignore[arg-type]  # a menu ID
            if node.inline is not None:
                line = f'[I]{L(30149, "My Lists")} …[/I]'
            elif isinstance(node.target, MenuScope):
                line = f'{node.label} ›'
            else:
                line = node.label + (f'  [COLOR {tokens().color.text.dim}]{node.role}[/COLOR]' if node.role else '')
            out.append(f'{prefix}· {line}')  # the fonts of the skins have no box-drawing characters
            if isinstance(node.target, MenuScope) and depth < PREVIEW_DEPTH:
                out.extend(level(menu_id, node.target, depth + 1, prefix + INDENT))
        return out

    def menu(menu_id: str, scope: MenuScope, *, label: str = '', when: str = '') -> list[str]:
        """Return the lines of a menu: its folder (`label`, by the folder point `when`; no point - always) or its entries in place."""
        nodes = list(build_menu(menu_id, scope, route=route))  # type: ignore[arg-type]  # a menu ID
        if not nodes:
            return []
        if label and (not when or lc.folder_when(when)(len(nodes))):
            return [f'· {label} ›', *level(menu_id, scope, 1, INDENT, nodes)]
        return level(menu_id, scope, 1, '', nodes)

    from ..ff.account_admin import menu_label
    more = '· …'
    if group in ('main', 'lists'):
        shown = lc.FOLDER_GROUPS[group].in_menus()  # the lists in the main menu at all
        lines = [more, *(menu('lists', MenuScope(), label=lc.FOLDER_GROUPS['lists'].label(), when='main.lists') if shown else ()), more]
    elif group == 'my':
        lines = [more, *menu('movies', MenuScope(), label=menu_label('movies')), more]
    elif group == 'history':
        lines = [more, *menu('history', MenuScope())]
    elif group == 'own':
        lines = menu('lists', pointer_scope('own'))  # the menu of `/own`
    elif group == 'persons':
        shown = lc.FOLDER_GROUPS[group].in_menus()  # the persons in the main menu at all
        lines = [more, *(menu('persons', MenuScope(), label=menu_label('persons'), when='persons.my') if shown else ())]
    else:
        lines = []
    if len(lines) > PREVIEW_LINES:
        lines = [*lines[:PREVIEW_LINES - 1], '…']
    return lines


def preview_text(group: str) -> str:
    """Return the preview of the menu of the group (`preview_lines()`; an error shown in it: a preview must not break the window)."""
    try:
        return '\n'.join(preview_lines(group))
    except Exception as exc:
        from ..ff.logs import fflog_exc
        fflog_exc()
        return f'[COLOR {tokens().color.warning}]{exc}[/COLOR]'


def preview_label() -> str:
    """Return the head of the preview of a menu."""
    return L(32972, 'Preview')


def head_color(group: str, shown: str) -> str:
    """
    Return the color of the head of a group: grayed out of the menus (`FolderGroup.in_menus()`), else the match color for the group of the
    preview (`shown`).
    """
    if not lc.FOLDER_GROUPS[group].in_menus():
        return tokens().color.text.disabled
    return tokens().color.text.match if group == shown else tokens().color.text.dim


def label_color(group: str) -> str:
    """Return the color of the label of a level of the group: grayed out of the menus (its switches stay enabled)."""
    return tokens().color.text.strong if lc.FOLDER_GROUPS[group].in_menus() else tokens().color.text.disabled


def entry_texts(key: str) -> dict[str, str]:
    """
    Return the texts of the entry of a menu for its helps (format fields): its label (`entry`), the title of the tab switching it (`tab`),
    of the tab of the folders (`folders`).
    """
    from ..ff.menu_entries import MENU_ENTRY
    from .config_dialog import page_ref
    titles = {name: ref.title() if (ref := page_ref(cls)) is not None else '' for name, cls in (('tab', 'MenusPage'), ('folders', 'FoldersPage'))}
    return {'entry': MENU_ENTRY[key].label(), **titles}


def group_note(group: str) -> str:
    """Return what the help of a level of the group says of the entry of a menu it is in (`FolderGroup.requires`; none: '')."""
    folder_group = lc.FOLDER_GROUPS[group]
    if not folder_group.requires:
        return ''
    texts = entry_texts(folder_group.requires)
    if folder_group.in_menus():
        return L(31329, 'Shown while "{entry}" is on in the tab "{tab}".').format(**texts)
    return L(31330, '"{entry}" is off in the tab "{tab}": these folders have no effect in the menus of FanFilm.').format(**texts)


def switch_help(point: FolderPoint, when: When) -> str:
    """Return the help of a switch: a `When` of a level of a menu (and the note of the entry its group is in)."""
    where = f'{lc.FOLDER_GROUPS[point.group].label()}: {point.label()}'
    text = L(32973, '{where} - {when}: a folder never, if there are more items, always (else the items in place).').format(
        where=where, when=when_label(when))
    return ' '.join(part for part in (text, group_note(point.group)) if part)


def entry_switch_help(key: str) -> str:
    """Return the help of the switch of the entry of a menu in the head of a group: the same setting as the one of the menus tab."""
    return L(31331, '"{entry}" in the main menu: shown or hidden - the same setting as "{entry}" in the tab "{tab}".').format(**entry_texts(key))


def head_toggles() -> dict[str, str]:
    """Return the groups whose head has the switch of the entry of a menu (the first group of each entry): group → entry key."""
    toggles: dict[str, str] = {}
    for group, folder_group in lc.FOLDER_GROUPS.items():
        if folder_group.requires and folder_group.requires not in toggles.values():
            toggles[group] = folder_group.requires
    return toggles
