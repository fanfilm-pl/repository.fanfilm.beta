"""
The fanart.tv API (https://fanarttv.docs.apiary.io, v3.2): all the images of a movie (by its TMDB ID) or a TV show with its seasons
(by its TVDB ID) in one answer. The answers go through the list cache (`cached_list()`, the TTL of the `art` kind), "not in fanart.tv"
(404) too; the key of the project is the one of FanFilm (`lib.ff.apis`), the personal key of the user (`client-key`: newer images)
is in the settings of the accounts.
"""

from __future__ import annotations
from typing import Iterable, TYPE_CHECKING
from threading import Lock
from typing_extensions import Literal, TypeAlias
from ..ff import requests
from ..ff import apis
from ..ff.listcache import FetchedList, cached_list
from ..ff.logs import fflog
from const import const

if TYPE_CHECKING:
    from ..ff.types import JsonData

#: The kind of the media of fanart.tv, its path: `movies` (by the TMDB or IMDb ID), `tv` (by the TVDB ID).
FanartKind: TypeAlias = Literal['movies', 'tv']
#: The media of fanart.tv: its kind and its ID.
FanartId: TypeAlias = 'tuple[FanartKind, int | str]'


def client_key() -> str:
    """Return the personal key of the user (the settings of the accounts), empty if not given."""
    from ..ff.config import config
    return config.account_settings.fanart_client_key or ''


class FanartApi:
    """The fanart.tv client: one HTTP session (its connections kept alive between the folders of the service)."""

    #: The base URL of the API.
    base: str = 'https://webservice.fanart.tv/v3.2'

    def __init__(self) -> None:
        #: The HTTP session, created at the first request.
        self._session: requests.Session | None = None
        #: The lock of the creation of the session.
        self._lock: Lock = Lock()

    @staticmethod
    def connections() -> int:
        """Return the number of the concurrent connections (`const.fanart.connection.max`): the HTTP pool, the threads of `many()`."""
        return max(1, const.fanart.connection.max)

    def session(self) -> requests.Session:
        """Return the HTTP session with a pool of `connections()`."""
        with self._lock:
            if self._session is None:
                self._session = sess = requests.Session()
                sess.mount(self.base, requests.adapters.HTTPAdapter(pool_maxsize=self.connections()))
            return self._session

    def headers(self) -> dict[str, str]:
        """Return the headers of a request: the key of FanFilm and the personal key of the user."""
        headers = {'api-key': apis.fanarttv_API_key}  # type: ignore[attr-defined]  # decoded at import
        if key := client_key():
            headers['client-key'] = key
        return headers

    def get(self, kind: FanartKind, media_id: int | str) -> JsonData | None:
        """Return the images of the media (the answer of fanart.tv), an empty dict if fanart.tv has none, None on a failure."""
        path = f'{kind}/{media_id}'

        def fetch() -> FetchedList | None:
            try:
                resp = self.session().get(f'{self.base}/{path}', headers=self.headers(), timeout=const.fanart.connection.timeout)
            except requests.RequestException as exc:
                fflog(f'[FANART] {path} failed: {exc}')
                return None
            if resp.status_code == 404:
                return FetchedList([(None, {})])
            if resp.status_code != 200:
                fflog(f'[FANART] {path} failed: HTTP {resp.status_code}')
                return None
            try:
                data = resp.json()
            except ValueError:
                fflog(f'[FANART] {path} failed: not JSON')
                return None
            return FetchedList([(None, data if isinstance(data, dict) else {})])

        stored = cached_list('fanart', path, fetch, kind='art')
        return stored.items[0] if stored is not None and stored.items else None

    def many(self, media: Iterable[FanartId]) -> dict[FanartId, JsonData]:
        """Return the images of many media at once (the threads of `connections()`), without the failed ones."""
        media = tuple(dict.fromkeys(media))
        if not media:
            return {}
        if len(media) == 1:
            kind, media_id = media[0]
            data = self.get(kind, media_id)
            return {} if data is None else {media[0]: data}
        with requests.RequestsPoolExecutor(min(len(media), self.connections())) as ex:
            results = list(ex.map(lambda m: self.get(*m), media))
        return {m: data for m, data in zip(media, results) if data is not None}


#: The fanart.tv client (one per interpreter: its session is shared).
fanart_api: FanartApi = FanartApi()
