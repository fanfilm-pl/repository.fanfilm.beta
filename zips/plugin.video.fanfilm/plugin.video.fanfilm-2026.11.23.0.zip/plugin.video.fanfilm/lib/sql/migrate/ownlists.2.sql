-- ownlists.db v2: the address of a dynamic list (its media come from it, e.g. a saved advanced search `tmdb://movie?…`; no items).
ALTER TABLE list ADD COLUMN "link" TEXT NOT NULL DEFAULT '';
