"""
The Cloudflare cookies of the native providers from a Cloudflare solver server (the API `/v1` of FlareSolverr: Byparr, Trawl,
FlareBypasser...): the settings of the group "Cloudflare server" (the card `SourceSettings`) and of the providers (`cf_cookie_settings()`).

The service keeps one queue and asks the server for one site at a time: at its start and at the interval of a provider (less
`TIMER_MARGIN`), at once (the front of the queue) when a search meets the challenge of a site (`challenge_seen()`, `lib.ff.requests`)
or every site at "Refresh now". Only the sites of the providers searched with "Use the Cloudflare server" on. A good answer (HTTP 200
of the site and `cf_clearance`) goes to the settings of the providers of the site.
"""

from __future__ import annotations
import threading
import time
from collections import deque
from fnmatch import fnmatch
from typing import Any, Mapping
from urllib.parse import urlsplit
from .config import config
from .logs import fflog, fflog_exc
from .threads import xsleep
from ..kolang import L

#: A site is refreshed this long before the end of its interval [s].
TIMER_MARGIN: int = 5 * 60
#: A site whose solve failed waits this long for the next search challenge (its interval goes on) [s].
FAILURE_COOLDOWN: int = 30 * 60
#: One site told once in this time by one process (a search meets the challenge many times) [s].
TELL_INTERVAL: int = 60
#: The interval of the service work of the queue [s] (a request wakes it at once).
WORK_INTERVAL: int = 60


# --- the plugin (a search, the settings) ---

#: The sites told by this process: the host -> the time.
_told: dict[str, float] = {}


def challenge_seen(url: str) -> None:
    """
    Tell the service a request met the Cloudflare challenge (one host once in `TELL_INTERVAL`; the server off: nothing). At once, not in a
    thread: the plugin interpreter ends with the search (the service only queues the site).
    """
    host = urlsplit(url).hostname or ''
    if not host or not config.sources.settings.cf_solver or time.time() - _told.get(host, 0) < TELL_INTERVAL:
        return
    _told[host] = time.time()
    tell_service(timeout=2, host=host)


def tell_service(timeout: float = 5, **data: Any) -> bool:
    """Send a request to the queue of the service (`{"host": ...}` or `{"all": true}`), return True if it answered."""
    from ..service.client import service_client
    try:
        return service_client.post(f'{service_client.url}cf_solver/refresh', json=data, timeout=timeout).ok
    except Exception as exc:
        fflog(f'[CF] service not told {data}: {exc}')
        return False


def refresh_now() -> None:
    """The button "Refresh now": every site to the queue (the service tells the result); no site: told at once."""
    from .ui import ui
    if not solver_sites():
        ui.notify(L(33021, 'Cloudflare server'), L(33022, 'No provider uses the Cloudflare server.'))
    elif tell_service(all=True):
        ui.notify(L(33021, 'Cloudflare server'), L(33023, 'Refreshing the cookies…'))


# --- the service ---

def solver_sites() -> dict[str, int]:
    """Return the sites of the Cloudflare cookies of the providers searched with the server on: the host -> its interval [s]."""
    from ..sources.natives import catalog_providers, native_catalog, provider_searched, provider_value
    sites: dict[str, int] = {}
    for prov in catalog_providers(native_catalog(build=False)):
        name = prov['id']
        for host, values in prov.get('cookies', {}).items():
            if 'cf_clearance' in values and provider_value(name, 'cf_solver') is True and provider_searched(name):
                interval = int(provider_value(name, 'cf_solver_interval') or 360) * 60 - TIMER_MARGIN
                sites[host] = min(interval, sites.get(host, interval))
    return sites


def site_of(host: str, sites: Mapping[str, Any]) -> str:
    """Return the site of a host ('' none): the same host, its subdomain or a pattern."""
    return next((site for site in sites if host == site or host.endswith(f'.{site}') or fnmatch(host, site)), '')


class CfSolver:
    """The queue of the sites of the service (one at a time) and its work."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        #: The sites waiting, the one asked now.
        self.queue: deque[str] = deque()
        self.busy: str = ''
        #: The last ask of a site, the last failure [time.time()].
        self.asked: dict[str, float] = {}
        self.failed: dict[str, float] = {}
        #: The sites of "Refresh now" -> their result (None: waiting): one notification of all.
        self.report: dict[str, bool | None] = {}
        self.work: Any = None

    def start(self) -> None:
        """Start the work of the queue (the service): the first pass at once (the cookies of the start)."""
        from ..service.base import cyclic_call
        self.work = cyclic_call((20, WORK_INTERVAL), self.run)

    def request(self, host: str = '', *, every: bool = False) -> None:
        """A site to the front of the queue (a search challenge: no repeat in its cooldown), or every site (the button)."""
        if not config.sources.settings.cf_solver:
            return
        sites = solver_sites()
        now = time.time()
        with self.lock:
            if every:
                self.report = {site: None for site in sites}
                self.queue.extendleft(site for site in sites if site not in self.queue and site != self.busy)
            elif (site := site_of(host, sites)) and site != self.busy and site not in self.queue:
                if now - self.failed.get(site, 0) < FAILURE_COOLDOWN:
                    return
                self.queue.appendleft(site)
            else:
                return
        if self.work is not None:
            self.work.force_call()

    def run(self) -> None:
        """The work: the sites of their interval to the queue, then the queue one site at a time."""
        if not config.sources.settings.cf_solver:
            with self.lock:
                self.queue.clear()
            return
        sites = solver_sites()
        now = time.time()
        with self.lock:
            self.queue.extend(site for site, interval in sites.items() if site not in self.queue and now >= self.asked.get(site, 0) + interval)
        while True:
            with self.lock:
                while self.queue and self.queue[0] not in sites:
                    self.report.pop(self.queue.popleft(), None)
                if not self.queue:
                    break
                site = self.busy = self.queue.popleft()
            try:
                good = self.solve(site)
            finally:
                with self.lock:
                    self.busy = ''
            with self.lock:
                self.asked[site] = time.time()
                if not good:
                    self.failed[site] = time.time()
                if site in self.report:
                    self.report[site] = good
                    if None not in self.report.values():
                        self.tell_report()

    def tell_report(self) -> None:
        """The notification of "Refresh now": the sites refreshed, the failed ones."""
        from .kotools import Notification
        failed = sorted(site for site, good in self.report.items() if not good)
        text = L(33024, 'Refreshed: {count} of {all}', count=len(self.report) - len(failed), all=len(self.report))
        self.report = {}
        Notification('FanFilm', f'{L(33021, "Cloudflare server")}: {text}' + (f' ({", ".join(failed)})' if failed else ''), sound=False).show()

    def solve(self, site: str) -> bool:
        """Ask the server for the cookies of a site; good ones (HTTP 200, `cf_clearance`) to the providers of the site."""
        timeout = int(config.sources.settings.cf_solver_timeout)
        answer = call_server(str(config.sources.settings.cf_solver_url).rstrip('/'), f'https://{site}/', timeout)
        solution = answer.get('solution') or {}
        cookies = {cookie.get('name'): cookie.get('value') for cookie in solution.get('cookies') or ()}
        if solution.get('status') != 200 or not (clearance := cookies.get('cf_clearance')):
            fflog(f'[CF] {site}: no cookie ({answer.get("status")}, {solution.get("status")}, {answer.get("message", "")})')
            return False
        user_agent = str(solution.get('userAgent') or '')
        set_cookie(site, clearance, user_agent)
        fflog(f'[CF] {site}: new cookie')
        return True


def call_server(url: str, site_url: str, timeout: int) -> dict[str, Any]:
    """Return the answer of the server (`{}` none); the wait ends with the service (the call goes on in its thread)."""
    from . import requests
    result: dict[str, Any] = {}

    def call() -> None:
        try:
            resp = requests.post(f'{url}/v1', json={'cmd': 'request.get', 'url': site_url, 'maxTimeout': timeout * 1000}, timeout=timeout + 30)
            result.update(resp.json())
        except Exception as exc:
            result['message'] = str(exc)

    thread = threading.Thread(target=call, name='cf-solver-call', daemon=True)
    thread.start()
    while thread.is_alive():
        xsleep(1)
    return result


def set_cookie(site: str, clearance: str, user_agent: str) -> None:
    """Set the Cloudflare cookie and the user agent of the providers of a site (only them: a partial payload), forwarded to the other FanFilm."""
    from .cookies import receive_cookies
    try:
        receive_cookies({'host': site, 'cookies': [{'name': 'cf_clearance', 'value': clearance}], **({'user_agent': user_agent} if user_agent else {}),
                         'partial': True})
    except Exception:
        fflog_exc()


#: The queue of the service.
solver: CfSolver = CfSolver()
