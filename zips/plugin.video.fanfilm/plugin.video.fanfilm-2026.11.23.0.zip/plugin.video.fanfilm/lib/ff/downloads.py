"""
The downloads of FanFilm: the records the plugin, the windows and the service share, and the calls of the download engine from both
sides. The engine (`lib.service.downloads`) lives in the service: a call from code run there goes straight to it, a call from the plugin
interpreter (the sources window) through the service client. The rows are kept by `lib.ff.db.downloads` (written by the service only).

A download is a row of the queue: its state is `queued`, `paused`, `error` or `done`; "it downloads now" is no stored state (the
engine has a thread of it: `DownloadInfo.running`), the bytes got are the size of its part file.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from pathlib import PurePosixPath
from urllib.parse import urlsplit
import os
import re
import shutil
from attrs import frozen, asdict
import xbmcvfs

from ..defs import MediaRef
from ..kolang import L
from .source.facts import language_type

if TYPE_CHECKING:
    from .item import FFItem
    from .types import JsonData
    from ..sources import Source, ResolveResult, ResolvePay
    from ..service.downloads import Downloads

#: The stored state of a download.
DownloadState: TypeAlias = Literal['queued', 'paused', 'error', 'done']
#: Why a download stopped with an error: the link expired, no space left, the file can not be written, the network failed (after the
#: retries), an answer of the server no download can come of, the renewal of the link needs a payment.
DownloadErrorKind: TypeAlias = Literal['', 'expired', 'space', 'write', 'network', 'http', 'payment']
#: What the user does with a download: `pause` / `resume` it, `retry` after an error (the same link), `renew` its link (its source
#: resolved again by the caller, with the dialogs of its provider: `renew()`), `remove` the row (its part file too, a finished file stays),
#: `remove_file` the row with its file, `first` moves it to the start of the queue.
DownloadAction: TypeAlias = Literal['pause', 'resume', 'retry', 'renew', 'remove', 'remove_file', 'first']
#: The result of adding a download: added, the same source is in the queue already (finished, or its target file is taken), the same
#: source not finished got the new link of the request (`Downloads.relink()`: an expired link renewed by hand), the service did not answer
#: (nothing is added).
AddResult: TypeAlias = Literal['added', 'duplicate', 'renewed', 'unavailable']
#: The calls of the whole queue without arguments (the service client sends them by name).
DownloadsCall: TypeAlias = Literal['remove_done', 'clear_all', 'forget_missing']

#: The suffix of the file of a download not finished yet (no video extension: the provider of the downloaded files and Kodi skip it).
PART_SUFFIX: str = '.part'
#: The extension of a downloaded file whose source and link tell none (or an unknown one).
DEFAULT_EXTENSION: str = 'mp4'
#: A path of the network (VFS of Kodi): a URL with a scheme (`smb://`, `nfs://`, `davs://`...); a local one has none.
RX_VFS: re.Pattern[str] = re.compile(r'^[a-z][a-z0-9+.-]+://', re.IGNORECASE)
#: A playlist of a stream (HLS, DASH) in the path of a link: no file to download.
RX_PLAYLIST: re.Pattern[str] = re.compile(r'\.(?:m3u8?|mpd)$', re.IGNORECASE)
#: The extensions of the subtitle files Kodi reads next to a video.
SUBTITLE_EXTENSIONS: frozenset[str] = frozenset(('.srt', '.vtt', '.ass', '.ssa', '.sub', '.smi'))
#: The extension of a subtitle file whose link tells none (or an unknown one).
DEFAULT_SUBTITLE_EXTENSION: str = '.srt'


@frozen(kw_only=True)
class DownloadRequest:
    """A download to add to the queue: what the sources window knows after the resolve of the chosen source."""

    #: The media (a movie, an episode), None unknown.
    ref: MediaRef | None
    #: The title of the row (a movie with its year, a show with `S01E02`).
    title: str
    #: The description of the source of the row (the quality, the language).
    info: str
    #: The target file (a Kodi path: a local one or of the network), unique in the queue.
    dest: str
    #: The resolved link and its headers.
    url: str
    headers: dict[str, str]
    #: The size in bytes the source declares (0: unknown).
    size: int
    #: Till when the file is on the account of the provider (`on_account_expires` of the source, '' unknown).
    expires: str = ''
    #: The source (`Source.as_json(dynamic=True)`): the renewal of an expired link resolves it again.
    source: JsonData

    def __to_json__(self) -> JsonData:
        """Return the JSON form (the calls of the service)."""
        return {**asdict(self, recurse=False), 'ref': None if self.ref is None else self.ref.__to_json__()}

    @classmethod
    def __from_json__(cls, data: JsonData) -> DownloadRequest:
        """Return the request of its JSON form."""
        return cls(**{**data, 'ref': None if (ref := data.get('ref')) is None else MediaRef.__from_json__(ref)})


@frozen(kw_only=True)
class DownloadLink:
    """A new link of a download (its source resolved again)."""

    url: str
    headers: dict[str, str]
    #: Till when the file is on the account of the provider ('' unknown: the old date kept).
    expires: str = ''

    def __to_json__(self) -> JsonData:
        """Return the JSON form (the calls of the service)."""
        return asdict(self, recurse=False)

    @classmethod
    def __from_json__(cls, data: JsonData) -> DownloadLink:
        """Return the link of its JSON form."""
        return cls(url=str(data['url']), headers=dict(data.get('headers') or {}), expires=str(data.get('expires') or ''))


@frozen(kw_only=True)
class DownloadAdded:
    """The answer of adding a download: its result and its row (a window focuses it)."""

    #: The result.
    result: AddResult
    #: The ID of the row of the download: the added one, the renewed one, the one in the queue already; None: none (the service did not answer,
    #: the DB failed).
    id: int | None = None


class DownloadFailure(Exception):
    """
    A download stops with an error (no retry): its kind and the text for the user. No new link of a renewal (`renew_link()`) too: `payment`
    (the provider needs a payment it may not take, it has no transfer), else `expired`.
    """

    def __init__(self, kind: DownloadErrorKind, text: str) -> None:
        """Keep the kind of the error and its text for the user."""
        super().__init__(text)
        #: The kind of the error.
        self.kind: DownloadErrorKind = kind
        #: The text for the user.
        self.text: str = text


@frozen(kw_only=True)
class DownloadInfo:
    """A download as the windows see it: its row with the live values of the engine."""

    id: int
    ref: MediaRef | None
    title: str
    info: str
    dest: str
    state: DownloadState
    error_kind: DownloadErrorKind
    #: The text of the error for the user ('' none).
    error_text: str
    #: The size in bytes (0: unknown) and the bytes got.
    size: int
    done: int
    #: The engine downloads it now.
    running: bool
    #: Bytes per second (0 not running) and the seconds left (None unknown).
    speed: float
    eta: float | None
    #: Till when the file is on the account of the provider ('' unknown).
    expires: str
    #: The place in the queue (the order of the list).
    position: int
    #: The host of its link ('' unknown; the limit of the downloads per host).
    host: str = ''
    #: The name of the provider of its source for the user ('' unknown, `provider_name()`).
    provider: str = ''
    #: The hosting of its source as the provider named it ('' unknown, `Source.hosting`).
    hosting: str = ''
    #: Its source gets a new link without a search (not one of a provider add-on: only "Download" of the sources window again).
    renews: bool = True

    def __to_json__(self) -> JsonData:
        """Return the JSON form (the calls of the service)."""
        return {**asdict(self, recurse=False), 'ref': None if self.ref is None else self.ref.__to_json__()}

    @classmethod
    def __from_json__(cls, data: JsonData) -> DownloadInfo:
        """Return the download of its JSON form."""
        return cls(**{**data, 'ref': None if (ref := data.get('ref')) is None else MediaRef.__from_json__(ref)})


@frozen(kw_only=True)
class DownloadsSnapshot:
    """The queue at a moment."""

    rows: tuple[DownloadInfo, ...]
    #: The pause of the whole queue (the rows keep their states).
    paused_all: bool
    #: The free space of the folders of the downloads in bytes: the least of the local ones, None unknown (network folders).
    free_space: int | None
    #: The queue waits for the end of the video (the setting `pause_on_play`; not told with the pause of the whole queue).
    held_by_play: bool = False

    def __to_json__(self) -> JsonData:
        """Return the JSON form (the calls of the service)."""
        return {'rows': [row.__to_json__() for row in self.rows], 'paused_all': self.paused_all, 'free_space': self.free_space,
                'held_by_play': self.held_by_play}

    @classmethod
    def __from_json__(cls, data: JsonData) -> DownloadsSnapshot:
        """Return the queue of its JSON form."""
        return cls(rows=tuple(DownloadInfo.__from_json__(row) for row in data['rows']), paused_all=bool(data['paused_all']),
                   free_space=data.get('free_space'), held_by_play=bool(data.get('held_by_play')))


def _engine() -> Downloads | None:
    """Return the engine of this interpreter (the service: started at its first use), None in the plugin (the calls go to the service)."""
    from ..service import local_works
    if (works := local_works()) is not None:
        return works.downloads_worker()
    return None


def add(request: DownloadRequest) -> DownloadAdded:
    """Add a download to the queue (the engine starts it)."""
    if (engine := _engine()) is not None:
        return engine.add(request)
    from ..service.client import service_client
    return service_client.downloads_add(request) or DownloadAdded(result='unavailable')


def snapshot() -> DownloadsSnapshot | None:
    """Return the queue (read only), None if the service did not answer."""
    if (engine := _engine()) is not None:
        return engine.snapshot()
    from ..service.client import service_client
    return service_client.downloads_snapshot()


def act(download_id: int, action: DownloadAction) -> bool:
    """
    Do the action with the download, return False if there is no such download or the service did not answer. The renewal of its link
    resolves here, in the interpreter of the caller (`renew()`).
    """
    if action == 'renew':
        return renew(download_id)
    if (engine := _engine()) is not None:
        return engine.act(download_id, action)
    from ..service.client import service_client
    return service_client.downloads_act(download_id, action)


def relink(download_id: int, link: DownloadLink) -> bool:
    """Give the download its new link (queued again), return False if there is no such download or the service did not answer."""
    if (engine := _engine()) is not None:
        return engine.relink(download_id, link)
    from ..service.client import service_client
    return service_client.downloads_relink(download_id, link)


def renew_link(source: JsonData, ref: MediaRef | None, *, pay: ResolvePay) -> DownloadLink:
    """
    Return the new link of a download: its source (`DownloadRequest.source`) resolved again for its media without a search
    (`SourceManager.resolve_stored()`). `pay` (`ResolvePay`): `ask` - with the dialogs of the provider (a click of the user), `yes` / `no` -
    no dialog, a transfer paid without asking (only by a provider with its automatic use on) / never. Raise `DownloadFailure` if no new link
    comes of it (a stream that can not be downloaded too): `payment` - a payment needed (not made quietly, no transfer left).
    """
    from .info import ffinfo
    from .logs import fflog_exc
    from .source.manager import SourceManager, DeadLink
    if ref is None or (ffitem := ffinfo.find_item(ref, progress=ffinfo.Progress.NO)) is None:
        raise DownloadFailure('expired', L(31266, 'The media of the download is not known: no new link'))
    try:
        resolved = SourceManager().resolve_stored(source, ffitem=ffitem, for_resolve={'pay': pay})
    except DeadLink as exc:
        raise DownloadFailure('payment' if exc.kind == 'no_transfer' else 'expired', str(exc)) from exc
    except Exception as exc:
        fflog_exc()
        raise DownloadFailure('expired', L(31269, 'No new link: {error}', error=exc)) from exc
    if reason := downloadable(resolved):
        raise DownloadFailure('expired', reason)
    stream = resolved.stream or {}
    return DownloadLink(url=stream.get('url') or resolved.url, headers=dict(stream.get('headers') or {}), expires=resolved.get('on_account_expires') or '')


def renew(download_id: int) -> bool:
    """
    Renew the link of the download on a click of the user: its source resolved again HERE (the interpreter of the window: the dialogs of its
    provider shown as in the sources window, a confirmation of a transfer), the new link to the engine. No new link: the reason as a toast,
    the row stays as it is. Return True if the download is queued with the new link.
    """
    from .control import infoDialog, busy_dialog, close_busy_dialog
    from .db import downloads as db
    if (row := db.get(download_id)) is None or row.state == 'done':
        return False
    busy_dialog()
    try:
        link = renew_link(row.source, row.ref, pay='ask')
    except DownloadFailure as exc:
        close_busy_dialog()
        infoDialog(exc.text, heading=row.title, icon='WARNING')
        return False
    close_busy_dialog()
    return relink(download_id, link)


def pause_all(paused: bool) -> bool:
    """Pause or release the whole queue (the states of the rows stay)."""
    if (engine := _engine()) is not None:
        return engine.pause_all(paused)
    from ..service.client import service_client
    return service_client.downloads_pause_all(paused)


def remove_done() -> bool:
    """Remove the finished downloads from the list (their files stay)."""
    if (engine := _engine()) is not None:
        return engine.remove_done()
    from ..service.client import service_client
    return service_client.downloads_call('remove_done')


def clear_all() -> bool:
    """Stop and remove every download with its part file (the finished files stay)."""
    if (engine := _engine()) is not None:
        return engine.clear_all()
    from ..service.client import service_client
    return service_client.downloads_call('clear_all')


def forget_missing() -> bool:
    """Remove the finished downloads whose file is gone (the setting `forget_removed`; a window calls it at its opening)."""
    if (engine := _engine()) is not None:
        return engine.forget_missing()
    from ..service.client import service_client
    return service_client.downloads_call('forget_missing')


def is_vfs(path: str) -> bool:
    """Return True if the path is of the network (`xbmcvfs`), False if it is a local one."""
    return bool(RX_VFS.match(path))


def downloadable(source: Source) -> str:
    """
    Return '' if the source can be downloaded, else the reason for the user. Before its resolve: a local file, a `plugin://` address,
    a known playlist (m3u8). After it (`source.stream`): parts, DRM, a stream of InputStream Adaptive, a playlist (m3u8, mpd), no http(s).
    """
    if (stream := source.stream) is None:
        if source.get('local'):
            return L(31061, 'A local file can not be downloaded')
        if source.url.startswith('plugin://'):
            return L(31210, 'A source of another add-on can not be downloaded')
        if source.is_m3u8():
            return L(31211, 'A stream (a playlist) can not be downloaded')
        return ''
    url = stream.get('url') or ''
    if stream.get('parts'):
        return L(31212, 'A source of many parts can not be downloaded')
    if stream.get('drm'):
        return L(31224, 'A stream protected by DRM can not be downloaded')
    if stream.get('isa') or stream.get('play') == 'isa' or RX_PLAYLIST.search(urlsplit(url).path):
        return L(31211, 'A stream (a playlist) can not be downloaded')
    if urlsplit(url).scheme not in ('http', 'https'):
        return L(31249, 'Only a file of an HTTP link can be downloaded')
    return ''


def download_info(src: Source) -> str:
    """
    Return the description of a download of a source (its file name): the language type of its facts (the words of the providers:
    `Lektor`, `Dubbing Kino`, `Napisy`...; else the word in its info) with dots (`Dubbing.Kino`: the download keeps no space), the
    language (of its audio), the quality, the extra info.
    """
    audio_type = language_type(src.facts) or next((word for word in ('Lektor', 'Dubbing', 'Napisy') if word in src.get('info', '')), '')
    return f"{'.'.join(audio_type.split())} | {src.get('language', '').upper()} | {src.get('quality', '')} |{src.get('info2', '')}"


def free_space(path: str) -> int | None:
    """Return the free space of the local disk of the path (a folder or its nearest existing folder), None for a network path or if unknown."""
    if is_vfs(path):
        return None
    folder = os.path.abspath(path)
    while not os.path.isdir(folder) and os.path.dirname(folder) != folder:
        folder = os.path.dirname(folder)
    try:
        return shutil.disk_usage(folder).free
    except OSError:
        return None


def subtitle_name(base: str, lang: str, ext: str, number: int = 1) -> str:
    """
    Return the name of a subtitle file of a video (`base`: its path or name without the extension), as Kodi finds it:
    `<base>[.<lang>][.<n>]<ext>` (`n` from 2: another one of the same language). `subtitle_pattern()` matches it.
    """
    return ''.join((base, f'.{lang}' if lang else '', f'.{number}' if number > 1 else '', ext))


def subtitle_pattern(base: str) -> re.Pattern[str]:
    """Return the pattern of the names of the subtitle files of a video (`subtitle_name()`, the extension checked by the caller)."""
    return re.compile(rf'{re.escape(base)}(?P<lang>\.[^.]+)?(?:\.\d+)?(?P<ext>\.[^.]+)')


def remove_subtitles(dest: str) -> list[str]:
    """
    Remove the subtitle files of the target file (`copy_subtitles()`) in its folder, local or of the network. A file another video of the
    folder owns stays (`<base>.<word>.srt` of a video `<base>.<word>.mkv`). Return the removed files.
    """
    vfs = is_vfs(dest)
    folder, _, name = dest.rpartition('/' if vfs else os.sep)
    rx = subtitle_pattern(os.path.splitext(name)[0])
    try:
        names = xbmcvfs.listdir(f'{folder}/')[1] if vfs else os.listdir(folder or os.curdir)
    except OSError:
        return []
    # the names without the extension of the other files (the videos, their part files)
    stems = {os.path.splitext(file[:-len(PART_SUFFIX)] if file.endswith(PART_SUFFIX) else file)[0] for file in names
             if os.path.splitext(file)[1].lower() not in SUBTITLE_EXTENSIONS}
    removed: list[str] = []
    for file in names:
        if not (mch := rx.fullmatch(file)) or mch['ext'].lower() not in SUBTITLE_EXTENSIONS:
            continue
        if mch['lang'] and file[:mch.end('lang')] in stems:
            continue  # of another video
        path = f'{folder}/{file}' if vfs else os.path.join(folder, file)
        if vfs:
            if xbmcvfs.delete(path):
                removed.append(path)
            continue
        try:
            os.remove(path)
            removed.append(path)
        except OSError:
            pass  # removed meanwhile
    return removed


def copy_subtitles(stream: ResolveResult, dest: str) -> list[str]:
    """
    Copy the external subtitles of the resolved stream (`subtitles`: local files or links, read by `xbmcvfs`) next to the target file,
    named as Kodi finds them (`<name>.<lang>.srt`). Return the copied files.
    """
    subtitles = [sub for sub in stream.get('subtitles', ()) if sub.get('url')]
    if not subtitles:
        return []
    base = os.path.splitext(dest)[0]
    xbmcvfs.mkdirs(dest.rpartition('/' if is_vfs(dest) else os.sep)[0])
    copied: list[str] = []
    for sub in subtitles:
        url = sub['url']
        if (ext := PurePosixPath(urlsplit(url).path).suffix.lower()) not in SUBTITLE_EXTENSIONS:
            ext = DEFAULT_SUBTITLE_EXTENSION
        target, number = subtitle_name(base, sub.get('lang') or '', ext), 2
        while target in copied:
            target, number = subtitle_name(base, sub.get('lang') or '', ext, number), number + 1
        if xbmcvfs.copy(url, target):
            copied.append(target)
    return copied


def _join(folder: str, *names: str) -> str:
    """Return the path of the names in the folder (a network folder joined by `/`)."""
    if is_vfs(folder):
        return '/'.join((folder.rstrip('/'), *names))
    return os.path.join(folder, *names)


def _legal(name: str) -> str:
    """Return the legal file name of the text (transliterated as the old downloader did, see `make_legal_fname()`)."""
    from .cleantitle import normalize
    from .libtools import make_legal_fname
    return make_legal_fname(normalize(name))


def _extension(source: Source, url: str) -> str:
    """Return the extension of the file: of the file name of the source or of the path of the link if it is a video one, else the default."""
    from .source.utils import supported_video_extensions
    known = {ext.lower() for ext in supported_video_extensions()}
    for name in (source.file_name, PurePosixPath(urlsplit(url).path).name):
        if (suffix := PurePosixPath(name).suffix.lower()) and suffix in known:
            return suffix[1:]
    return DEFAULT_EXTENSION


def build_request(ffitem: FFItem, source: Source, resolved: Source) -> DownloadRequest:
    """
    Return the download of the resolved source of the media: the target file in the folder of the movies / of the show and its season
    (the settings of the names: the local title, the extra info of the source), its name made different from another download of the queue.
    Raise ValueError (the text for the user) if the folder of the downloads is not set.
    """
    from .config import config
    from ..service.misc import serialize
    from ..service.downloads import file_exists
    stream = resolved.stream or {}
    url = stream.get('url') or resolved.url
    local_title = config.downloads.local_title
    vtag = ffitem.vtag
    if ffitem.ref.is_episode:
        show = ffitem.show_item or ffitem
        name = vtag.getTvShowTitle() if local_title else (vtag.getEnglishTvShowTitle() or vtag.getTvShowTitle())
        year = show.year
        marker = f'S{ffitem.season or 0:02d}E{ffitem.episode or 0:02d}'
        folder = config.downloads.shows_folder
        sub_folders: tuple[str, ...] = (_legal(f'{name} ({year})' if year else name), f'Season {ffitem.season or 0}')
        base = f'{_legal(name)}.{marker}'
        title = f'{vtag.getTvShowTitle() or name} {marker}'
    else:
        name = ffitem.title if local_title else (vtag.getOriginalTitle() or ffitem.title)
        year = ffitem.year
        folder = config.downloads.movies_folder
        base = _legal(f'{name} ({year})' if year else name)
        sub_folders = (base,)
        title = f'{ffitem.title} ({year})' if year else ffitem.title
    if not folder:
        raise ValueError(L(31252, 'The folder of the downloads is not set'))
    folder = _join(xbmcvfs.translatePath(folder), *sub_folders)
    ext = _extension(source, url)
    info = _legal(download_info(source).replace('|', '.').replace('/', '-').replace(' ', '')).strip('.')
    queue = snapshot()
    taken = {row.dest for row in queue.rows} if queue is not None else set()

    def free(dest: str) -> bool:
        """Return True if no other download has the target file (in the queue, its part file)."""
        return dest not in taken and not file_exists(f'{dest}{PART_SUFFIX}')

    names = [f'{base}.{info}' if config.downloads.extra_info and info else base]
    if info and names[0] == base:
        names.append(f'{base}.{info}')  # another source of the same media: told apart by its description
    dest = next((path for name in names if free(path := _join(folder, f'{name}.{ext}'))), '')
    number = 2
    while not dest:
        if free(path := _join(folder, f'{names[-1]} ({number}).{ext}')):
            dest = path
        number += 1
    quality, language = source.get('quality') or '', (source.get('language') or '').upper()
    expires = resolved.get('on_account_expires') or source.get('on_account_expires') or ''  # the resolve may put the file on the account
    return DownloadRequest(ref=ffitem.ref, title=title, info=' · '.join(text for text in (quality, language) if text), dest=dest, url=url,
                           headers=dict(stream.get('headers') or {}), size=source.size, expires=expires,
                           source=serialize(source.as_json(dynamic=True)))
