"""
FanFilm logs: the log core of the SDK (`lib.sdk.log`, no import of FanFilm) bound to FanFilm (settings, service, threads, const)
and the FanFilm only tools. The modules import the logs from here: `from lib.ff.logs import fflog, fflog_exc`.
"""

from __future__ import annotations
import json
import pstats
import time
from io import StringIO
from typing import Any
from ..sdk.log import (  # noqa: F401  (the logs of FanFilm)
    LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR, LOGFATAL, LOGFF, TOP_PATH,
    LogProto, LogExcProto, LogKwargs, CallerInfo, Options, options, addon_name,
    log, error, warning, info, debug, fflog, fferror, ffwarning, ffinfo, ffdebug,
    log_exc, fflog_exc, traceback_list, traceback_lines, traceback_string,
    LogFile, log_submodule, print_as_fflog, _Format, xbmc, xbmcaddon, xbmc_log,
    LogHandler, use_logging, logging_config, py_level, kodi_level, extra_log_details, developer_level, developer_line_written, kodi_debug_logged,
)


def _flog() -> tuple[str, ...]:
    """Return the base words of the log format."""
    subn = ["%s" % n for n in ('ff', 'sipa')]
    try:
        subm = __import__(f'lib.{subn[0]}.{subn[-1][::-1]}')
    except ModuleNotFoundError:
        return ()  # tests
    while subn:
        subm = getattr(subm, subn.pop(0)[::(len(subn)>1)*2-1])
    return tuple(
        getattr(subm, k)
        for k in dir(subm)
        if k[:1] != "_" and len(k) > 1
        for v in (getattr(subm, k),)
        if isinstance(v, str)
    )


#: The switch of the developer logs is being read (a log of the read itself: shown).
_reading_show_fflog: bool = False


def _read_show_fflog() -> bool:
    """Return the switch of the developer logs of the configuration (shown if it is not available, e.g. during an update)."""
    global _reading_show_fflog
    if not xbmcaddon or _reading_show_fflog:
        return True
    _reading_show_fflog = True
    try:
        from .config import config  # local import to avoid circular import
        return config.maintenance.fflog
    except Exception:  # never lose a line: shown
        return True
    finally:
        _reading_show_fflog = False


def _prefix() -> str:
    """Return the line prefix: the add-on name, the service mark."""
    from .. import service
    return f'[{addon_name}][service]' if service.SERVICE else f'[{addon_name}]'


def _check_thread_cancel() -> None:
    """Raise `ThreadCancelled` if the current thread is canceled."""
    try:
        from .threads import check_thread_cancel
    except ImportError:
        # `lib.ff.threads` may be partially initialized when logging happens during early bootstrap
        # (threads -> const -> log). No cancellable thread runs yet, so skipping the check is safe.
        pass
    else:
        check_thread_cancel()


def _format_keys() -> str:
    """Return the keys regex of the values tuning the log format."""
    from const import const
    return const.debug.log_tune


#: The detailed loggers are being read (a log line of the read itself: no details yet).
_reading_log_details: bool = False


def _read_log_details() -> dict[str, bool]:
    """
    Return the detailed loggers: the loggers of every area (`const.debug.log_areas`) with its details in the configuration or by the
    active diagnostic code (`lib.ff.diagnostic`, for its window: `_details_until()`).
    """
    global _reading_log_details
    if _reading_log_details:
        return {}
    _reading_log_details = True
    try:
        from const import const
        from .diagnostic import code_details
        from .config import config
        from .config.choices import log_area_key
        details: dict[str, bool] = {}
        for key, area in const.debug.log_areas.items():
            details.update(dict.fromkeys(area.loggers, area.group is not None and config.maintenance.get(log_area_key(key))))
        details.update(code_details())  # the code only switches on
        return details
    finally:
        _reading_log_details = False


def _details_until() -> float | None:
    """Return the time (`boot_clock()`) the detailed loggers read are good until: the window of the diagnostic code, None - no limit."""
    if _reading_log_details:
        return None
    from .diagnostic import details_until
    return details_until()


def reload_log_options() -> None:
    """Read the switches of the developer logs again (a changed configuration, changed settings)."""
    del options.show_fflog
    del options.log_details


def _logging_config() -> dict[str, Any]:
    """Return the `loggers` section of the developer logs configuration."""
    from const import const
    return const.debug.logging


options.read_show_fflog = _read_show_fflog
options.prefix = _prefix
options.on_log = _check_thread_cancel
options.logging_config = _logging_config
options.read_log_details = _read_log_details
options.read_details_until = _details_until
log.format = _Format(_flog(), keys=_format_keys)
xbmc.log = log
use_logging(False)  # the records of `logging` to the Kodi log


class Profiler:

    def __init__(self, file_path_prefix: str = 'profile', *, builtins: bool = False):
        import cProfile
        self._profiler = cProfile.Profile(builtins=builtins)
        self.file_path_prefix = file_path_prefix
        self.sort_keys = [
            "ncalls",
            "tottime",
            "cumtime",
        ]  # Możesz dodać inne klucze, jeśli są potrzebne

    def profile(self, f):
        def method_profile_on(*args, **kwargs):
            try:
                self._profiler.enable()
                result = self._profiler.runcall(f, *args, **kwargs)
                return result
            except Exception as e:
                log("Profiler Error: %s" % e, LOGWARNING)
                return f(*args, **kwargs)
            finally:
                try:
                    self._profiler.disable()
                except Exception:
                    pass

        def method_profile_off(*args, **kwargs):
            return f(*args, **kwargs)

        if _is_debugging():
            return method_profile_on
        else:
            return method_profile_off

    def __del__(self):
        self.dump_stats()

    def dump_stats(self):
        if self._profiler is not None:
            for sort_key in self.sort_keys:
                s = StringIO()
                ps = pstats.Stats(self._profiler, stream=s).sort_stats(sort_key)
                ps.print_stats()
                file_path = f"{self.file_path_prefix}_{sort_key}.prof"
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(s.getvalue())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return


def trace(method):
    def method_trace_on(*args, **kwargs):
        start = time.time()
        result = method(*args, **kwargs)
        end = time.time()
        log(f"{method.__name__!r} time: {end - start:2.4f}s args: |{args!r}| kwargs: |{kwargs!r}|", LOGDEBUG)
        return result

    def method_trace_off(*args, **kwargs):
        return method(*args, **kwargs)

    if _is_debugging():
        return method_trace_on
    else:
        return method_trace_off


def _is_debugging():
    command = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Settings.getSettings",
        "params": {"filter": {"section": "system", "category": "logging"}},
    }
    js_data = execute_jsonrpc(command)
    for item in js_data.get("result", {}).get("settings", {}):
        if item["id"] == "debug.showloginfo":
            return item["value"]

    return False


def execute_jsonrpc(command):
    from . import control

    if not isinstance(command, str):
        command = json.dumps(command)
    response = control.jsonrpc(command)
    return json.loads(response)
