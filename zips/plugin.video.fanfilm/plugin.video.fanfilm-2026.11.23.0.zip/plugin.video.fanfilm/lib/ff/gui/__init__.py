"""
The models of the GUI of FanFilm without Kodi windows (no `xbmcgui`, no template): data the windows show and the settings declare, so a
process without windows (the service) can use them, e.g. the scale of a slider (`scale`). The windows themselves: `lib.windows`.
"""
