"""
The diagnostic code: a short code the user enters (the row of the maintenance page, with the developer logs on) switches on the
details of the areas of its bits (`LogArea.bit` of `const.debug.log_areas`) for `const.debug.diagnostic.minutes` after the next start
of Kodi (a fresh Kodi log and a fresh FanFilm; from the first interpreter of FanFilm, a widget before the service too) - what the team
needs to see a problem, in the Kodi log.

The code: Crockford base32 - 5 bits a character, the last character the lowest bits, any case, `O` reads `0`, `I` / `L` read `1`.
The state (`STATE_FILE` in the add-on profile): pending (entered, waiting for the next run of Kodi), active (from the first interpreter of
FanFilm of that run - `log_run()`, by `boot_clock()`), ended (the next start, or its time over). While active: the basic lines (`TAG`),
the registry of the data written already (`unseen()`: written once in a window, again only changed), the dumps (`log_blob()`: gzip +
base64), the budget of the Kodi log size.

CLI: `python -m lib.ff.diagnostic encode <bit>...`, `decode <code>`, `decode-log <kodi.log> [<folder>]` (the dumps to files),
`tui [<code>] [--set <Kodi data>[:<add-on>]]` (the generator of a code in the terminal, `lib.dev.tui.diagnostic`).
"""

from __future__ import annotations
import json
import os
import re
from base64 import b64decode, b64encode
from hashlib import sha1
from pathlib import Path
from threading import get_ident
from typing import Any, Iterable, Iterator, Mapping, Sequence
from typing_extensions import Literal, TypeAlias
from attrs import asdict, evolve, frozen
from .logs import fflog, fflog_exc
from ..sdk.log import boot_clock
from const import const

#: The characters of the code (Crockford base32), a character - `CHAR_BITS` bits.
ALPHABET: str = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
#: The bits of a character of the code.
CHAR_BITS: int = 5
#: The characters of a code at most.
MAX_LENGTH: int = 6
#: The look-alike characters read as the ones of the code (Crockford).
LOOK_ALIKES: dict[str, str] = {'O': '0', 'I': '1', 'L': '1'}
#: The characters left out of an entered code (a code dictated with separators).
SEPARATORS: str = ' -_.'
#: The file of the state of the code in the add-on profile: read by the logs, so never a database (a log line inside a lock of a
#: database would wait for itself), a plain file read once by an interpreter.
STATE_FILE: str = 'diagnostic.json'
#: The module of the state store of the registry of the data written in the window (`unseen()`, out of the way of the logs).
STATE_MODULE: str = 'diagnostic'
#: The key of the registry of the data written in the window (`unseen()`).
SEEN_KEY: str = 'seen'
#: The seconds between the checks of the size of the Kodi log while a code is active (`const.debug.diagnostic.log_budget`).
BUDGET_CHECK: float = 10.0
#: The tag of the diagnostic lines in the Kodi log.
TAG: str = '[DIAG]'
#: The characters of the data of a line of a dump.
BLOB_LINE: int = 4096
#: The logger of the diagnostic lines (the basic ones: INFO, always with an active code).
LOGGER: str = __name__
#: The key of the window of the registry of the data written (`unseen()`: the run of Kodi of the window, its start without one).
SEEN_WINDOW: str = '_window'
#: The time of the first line of a Kodi log: the run of Kodi (a new log at every start of Kodi).
KODI_LOG_START: re.Pattern[bytes] = re.compile(rb'\d{4}-\d\d-\d\d[ T][\d:.]+')
#: The run of Kodi of this interpreter (`log_run()`), a list: not read yet.
_log_run: list[str] = []

#: The phase of a code: entered and waiting for the next run of Kodi, active from its first interpreter of FanFilm, ended.
Phase: TypeAlias = Literal['pending', 'active', 'ended']


@frozen(kw_only=True)
class Decoded:
    """A decoded code."""

    #: The code (normalized).
    code: str
    #: Its bits.
    bits: frozenset[int]
    #: Its bits no area has (a code of a newer FanFilm).
    unknown: frozenset[int]

    @property
    def areas(self) -> tuple[str, ...]:
        """The keys of the areas of its bits (in the order of the bits)."""
        keys = area_bits()
        return tuple(keys[bit] for bit in sorted(self.bits) if bit in keys)


@frozen(kw_only=True)
class CodeState:
    """The state of the code (`STATE_FILE`)."""

    #: The code (normalized).
    code: str
    #: Its phase.
    phase: Phase = 'pending'
    #: The start of its window (`boot_clock()`), active only.
    started: float = 0.0
    #: The run of Kodi (`log_run()`) it was entered in (pending: it waits for another one) or active in; empty: unknown (an
    #: older FanFilm, a Kodi log not read).
    run: str = ''

    @property
    def end(self) -> float:
        """The end of its window (`boot_clock()`)."""
        return self.started + 60 * const.debug.diagnostic.minutes

    def left(self, now: float | None = None) -> float:
        """Return the seconds of its window left (0: not active or over)."""
        if self.phase != 'active':
            return 0.0
        now = boot_clock() if now is None else now
        return max(0.0, self.end - now) if self.started <= now else 0.0  # a start "in the future": a window of an earlier boot


# --- the code ---


def area_bits() -> dict[int, str]:
    """Return the areas of the developer logs by their bits of the code (`LogArea.bit`)."""
    return {area.bit: key for key, area in const.debug.log_areas.items() if area.bit is not None}


def normalize(code: str) -> str:
    """
    Return the code normalized (upper case, the look-alikes read, the separators left out, the leading zeros up to
    `const.debug.diagnostic.min_length`: "00A", never a bare "A" for the user); ValueError if invalid.
    """
    text = ''.join(LOOK_ALIKES.get(char, char) for char in code.upper() if char not in SEPARATORS)
    if bad := sorted({char for char in text if char not in ALPHABET}):
        raise ValueError(f'invalid characters of the code: {"".join(bad)}')
    text = text.lstrip('0')
    if len(text) > MAX_LENGTH:
        raise ValueError(f'the code is longer than {MAX_LENGTH} characters')
    return text.rjust(max(const.debug.diagnostic.min_length, 1), '0')


def decode(code: str) -> Decoded:
    """Return the decoded code (ValueError if invalid)."""
    text = normalize(code)
    value = 0
    for char in text:
        value = (value << CHAR_BITS) | ALPHABET.index(char)
    bits = frozenset(bit for bit in range(value.bit_length()) if value >> bit & 1)
    return Decoded(code=text, bits=bits, unknown=bits - area_bits().keys())


def encode(bits: Iterable[int], *, min_length: int = 0) -> str:
    """Return the code of the bits, at least `min_length` characters (leading zeros)."""
    value = sum(1 << bit for bit in set(bits))
    chars = []
    while value:
        chars.append(ALPHABET[value & ((1 << CHAR_BITS) - 1)])
        value >>= CHAR_BITS
    return ''.join(reversed(chars)).rjust(max(min_length, 1), '0')


def state_text(code: CodeState | None) -> str:
    """Return the state of a code as a text (the row of the maintenance page, the TUI)."""
    from math import ceil
    from ..kolang import L
    if code is None:
        return L(32667, 'none')
    if code.phase == 'pending':
        return L(31108, '{code} - waits for a restart of Kodi', code=code.code)
    if left := code.left():
        return L(31109, '{code} - {minutes} min left', code=code.code, minutes=ceil(left / 60))
    return L(31110, '{code} - ended', code=code.code)  # ended, or its time over (an active one of an earlier boot too)


def area_names(keys: Iterable[str]) -> str:
    """Return the labels of the areas (a text of a line, a dialog)."""
    return ', '.join(str(const.debug.log_areas[key].label) for key in keys if key in const.debug.log_areas)


# --- the state ---


#: The state of the code read in this interpreter (once; again after `reload_code()`), a list: not read yet.
_state: list[CodeState | None] = []
#: The Kodi log is larger than its budget (the details and the dumps stopped in this interpreter).
_budget_reached: bool = False
#: The time of the last check of the size of the Kodi log (`boot_clock()`).
_budget_checked: float = -BUDGET_CHECK


def state_path() -> Path:
    """Return the path of the file of the state of the code (the add-on profile)."""
    from .control import dataPath
    return Path(dataPath) / STATE_FILE


def read_state(path: Path | None = None) -> CodeState | None:
    """Return the state of the code (`path`: of another profile, default: of FanFilm; None: no code, or unreadable)."""
    try:
        data = json.loads((path or state_path()).read_text(encoding='utf-8'))
    except Exception:  # no file, a broken one; never break a log line: no code
        return None
    if not isinstance(data, dict) or not isinstance(data.get('code'), str) or data.get('phase') not in ('pending', 'active', 'ended'):
        return None
    return CodeState(code=data['code'], phase=data['phase'], started=float(data.get('started') or 0.0), run=str(data.get('run') or ''))


def kodi_log_path() -> Path:
    """Return the path of the Kodi log of this Kodi."""
    from xbmcvfs import translatePath
    return Path(translatePath('special://logpath')) / 'kodi.log'


def log_run(log: Path | None = None) -> str:
    """
    Return the run of Kodi by its log: the time of its first line (`log`: of another profile, e.g. the TUI `--set`; default: of this
    Kodi, read once by an interpreter). Every interpreter of the run finds the same one, Kodi starts a new log at its start; empty if
    the log can not be read. Not `lib.service.base.KodiRun` (a property of the Home window the service writes at its start): a plugin
    before the service would write it and the service would lose its start of Kodi.
    """
    if log is None and _log_run:
        return _log_run[0]
    path = kodi_log_path() if log is None else log
    try:
        with open(path, 'rb') as file:
            mch = KODI_LOG_START.search(file.read(64))
    except OSError:
        mch = None
    run = mch[0].decode('ascii') if mch is not None else ''
    if log is None:
        _log_run.append(run)
    return run


def write_state(code: CodeState | None, path: Path | None = None) -> None:
    """
    Write the state of the code (None: no code) - `path`: of another profile (e.g. a Kodi of the TUI `--set`), default: of FanFilm, read
    again in this interpreter.
    """
    if own := path is None:
        path = state_path()
    if code is None:
        path.unlink(missing_ok=True)
    else:
        _write_state_file(code, path)
    if own:
        reload_code()


def _write_state_file(code: CodeState, path: Path) -> None:
    """Write the file of the state of the code (never half a file for a reader; no reload: also from the read of the logs)."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        part = path.with_suffix(f'.{os.getpid()}.{get_ident()}.part')  # two interpreters of Kodi (one process) at its start
        part.write_text(json.dumps(asdict(code)), encoding='utf-8')
        part.replace(path)
    except OSError:
        fflog_exc()


def reload_code() -> None:
    """Read the state of the code again (a write of it, the start of its window); the details of the logs too."""
    from .logs import reload_log_options
    global _budget_reached
    _state.clear()
    _budget_reached = False
    reload_log_options()


def code_state() -> CodeState | None:
    """
    Return the state of the code (read once in this interpreter): a pending code of another run of Kodi (`log_run()`) is active from
    now (the first interpreter of FanFilm of this run: a widget before the service too, the file written for the others), an active one
    of another run is ended (the service writes it, `service_started()`).
    """
    if not _state:
        code = read_state()
        if code is not None and code.phase != 'ended' and (run := log_run()) and code.run != run:
            if code.phase == 'pending':
                code = evolve(code, phase='active', started=boot_clock(), run=run)
                _write_state_file(code, state_path())
            elif code.run:  # (an active one of no run - an older FanFilm, an unread log - is ended by the service)
                code = evolve(code, phase='ended')
        _state.append(code)
    return _state[0]


def enter_code(code: str) -> CodeState | None:
    """Enter a code (pending until the next start of the service), an empty one: no code. ValueError if invalid."""
    if not code.strip():
        write_state(None)
        return None
    new = CodeState(code=decode(code).code, run=log_run())  # active in the next run of Kodi
    write_state(new)
    fflog(f'{TAG} code {new.code} entered: {area_names(decode(new.code).areas)}; active after a restart of Kodi', module=LOGGER)
    return new


def service_started(kodi_start: bool) -> CodeState | None:
    """
    The start of the service: at the start of Kodi (`kodi_start`) a pending code becomes active now (its window starts, the registry
    of the written data cleared), an active one ends (the next start: another restart); a restart of the service in this run of Kodi
    (an update of FF...) changes nothing, the active window goes on. Return the active state or None.
    """
    from .db import state
    old = read_state()
    if old is None or old.phase == 'ended':
        return None
    if old.phase == 'active' and old.run and old.run == log_run():
        reload_code()  # the state of the file (a widget may have written it after this interpreter read it)
        return old  # active from the first interpreter of FanFilm of this run (`code_state()`), e.g. a widget before the service
    if not kodi_start:
        return old if old.phase == 'active' else None
    if old.phase == 'active':
        write_state(evolve(old, phase='ended'))
        state.delete(SEEN_KEY, module=STATE_MODULE, mode=state.StateMode.DB)
        return None
    new = evolve(old, phase='active', started=boot_clock(), run=log_run())
    state.delete(SEEN_KEY, module=STATE_MODULE, mode=state.StateMode.DB)
    write_state(new)
    return new


def end_window() -> CodeState | None:
    """The end of the window of the active code: the reports of its areas (`end_reports()`), its last line, the code ended; return it."""
    if (old := code_state()) is None or old.phase != 'active':
        return None
    end_reports(decode(old.code).areas)
    fflog(f'{TAG} code {old.code} ended', module=LOGGER)
    write_state(evolve(old, phase='ended'))
    return old


def end_reports(areas: Sequence[str]) -> None:
    """Write the reports of the areas of the code at the end of its window (its time is over: written directly, not by `diag()`)."""
    lines: list[str] = []
    try:
        from .accounts import accounts_header
        lines.append(accounts_header())  # the first sync done now (at the start of the service: not yet)
        if 'sync' in areas:
            from .sync import sync_report
            lines.extend(sync_report())
    except Exception:
        fflog_exc()
    for line in lines:
        fflog(f'{TAG} {line}', module=LOGGER)


def active_code() -> CodeState | None:
    """Return the active code in its window (with the developer logs on), else None."""
    from .logs import options
    if (code := code_state()) is None or code.left() <= 0 or not options.show_fflog:
        return None
    return code


def active_areas() -> tuple[str, ...]:
    """Return the keys of the areas of the active code (none without it)."""
    if (code := active_code()) is None:
        return ()
    return decode(code.code).areas


def details_allowed() -> bool:
    """Return True if the details of the active code are written: in its window and in the budget of the Kodi log (checked at times)."""
    global _budget_reached, _budget_checked
    if active_code() is None or _budget_reached:
        return False
    if (now := boot_clock()) - _budget_checked >= BUDGET_CHECK:
        _budget_checked = now
        if log_size() > const.debug.diagnostic.log_budget:
            _budget_reached = True
            fflog(f'{TAG} the Kodi log is larger than {const.debug.diagnostic.log_budget} bytes: the details and the dumps off', module=LOGGER)
            return False
    return True


def log_size() -> int:
    """Return the size of the Kodi log (0 if unknown)."""
    try:
        return kodi_log_path().stat().st_size
    except Exception:
        return 0


def code_details() -> dict[str, bool]:
    """Return the detailed loggers of the active code (its areas with loggers; none: no code, out of the budget)."""
    if not details_allowed():
        return {}
    return {logger: True for key in active_areas() for logger in const.debug.log_areas[key].loggers}


def code_nodes() -> frozenset[str]:
    """Return the nodes of the tree of the source providers detailed by the active code (`LogArea.nodes` of its areas)."""
    if not details_allowed():
        return frozenset()
    return frozenset(node for key in active_areas() for node in const.debug.log_areas[key].nodes)


def details_until() -> float | None:
    """Return the time (`boot_clock()`) the details read now are good until: the end of the window, the next check of the budget."""
    if (code := active_code()) is None:
        return None
    return min(code.end, boot_clock() + BUDGET_CHECK)


# --- the lines of the window ---


def unseen(kind: str, items: Mapping[str, Any]) -> dict[str, Any]:
    """
    Return the items (a key -> its data) not written in the window yet or changed since and register them (the state store, never read by
    the logs: a new interpreter does not repeat them); none without an active code.
    """
    from .db import state
    if not items or (code := active_code()) is None:
        return {}
    seen = state.get(SEEN_KEY, module=STATE_MODULE, mode=state.StateMode.DB)
    window = code.run or code.started  # the run: the same in every interpreter (two may start the window at once, `code_state()`)
    if not isinstance(seen, dict) or seen.get(SEEN_WINDOW) != window:
        seen = {SEEN_WINDOW: window}  # a registry of an earlier window (started by an interpreter before the service)
    book = dict(seen.get(kind) or {})
    new = {}
    for key, data in items.items():
        mark = sha1(json.dumps(data, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:16]
        if book.get(key) != mark:
            book[key] = mark
            new[key] = data
    if new:
        state.set(SEEN_KEY, {**seen, kind: book}, module=STATE_MODULE, mode=state.StateMode.DB)
    return new


def diag(text: str) -> None:
    """Write a basic line of the active code (INFO; nothing without it)."""
    if active_code() is not None:
        fflog(f'{TAG} {text}', module=LOGGER, stack_depth=2)


def log_blob(name: str, data: Any) -> bool:
    """
    Write a dump of the active code with the area "dump" (the data as JSON): the text tuned as every log line (`log.format`), then gzip
    + base64, in lines of `BLOB_LINE` characters `[DIAG] blob <name> <i>/<n> <data>`, the first one with the checksum (`decode-log`).
    Return False if not written (no code, no "dump", out of the budget).
    """
    import gzip
    from .logs import log
    if 'dump' not in active_areas() or not details_allowed():
        return False
    text = log.format.sub(3 * '\052', json.dumps(data, ensure_ascii=False, default=str))
    packed = b64encode(gzip.compress(text.encode('utf-8'))).decode('ascii')
    parts = [packed[i:i + BLOB_LINE] for i in range(0, len(packed), BLOB_LINE)] or ['']
    check = sha1(packed.encode('ascii')).hexdigest()[:12]
    for i, part in enumerate(parts, 1):
        fflog(f'{TAG} blob {name} {i}/{len(parts)}{f" sha1={check} json={len(text)}" if i == 1 else ""} {part}', module=LOGGER, stack_depth=2)
    return True


def blobs(lines: Iterable[str]) -> Iterator[tuple[str, Any]]:
    """Yield the dumps (their names and data) of the lines of a Kodi log (`log_blob()`); a broken one: its error as the data."""
    parts: dict[str, list[str]] = {}
    checks: dict[str, str] = {}
    for line in lines:
        if (at := line.find(f'{TAG} blob ')) < 0:
            continue
        words = line[at + len(TAG) + 6:].split()
        if len(words) < 2:
            continue
        name, count, *rest = words
        index, _, total = count.partition('/')
        if index == '1':
            parts[name] = []
            checks[name] = next((word[5:] for word in rest if word.startswith('sha1=')), '')
        if name not in parts or not rest:
            continue
        parts[name].append(rest[-1])
        if index == total:
            yield name, _unpack(''.join(parts.pop(name)), checks.pop(name, ''))


def _unpack(packed: str, check: str) -> Any:
    """Return the data of a dump (its error text if broken)."""
    import gzip
    if check and sha1(packed.encode('ascii')).hexdigest()[:12] != check:
        return {'error': 'checksum mismatch'}
    try:
        return json.loads(gzip.decompress(b64decode(packed)).decode('utf-8'))
    except Exception as exc:
        return {'error': str(exc)}


def log_header(code: CodeState) -> None:
    """Write the header of the window of the code: the code and its areas, the versions, the system (the lines of its areas: `log_header_lines()`)."""
    import platform
    import sys
    from .control import addonInfo
    decoded = decode(code.code)
    unknown = f'; {len(decoded.unknown)} unknown parts - update FanFilm' if decoded.unknown else ''
    diag(f'code {code.code} = {", ".join(decoded.areas) or "basic lines only"}{unknown}; {const.debug.diagnostic.minutes:g} min')
    try:
        import xbmc
        kodi = xbmc.getInfoLabel('System.BuildVersion')
        skin = xbmc.getSkinDir()
    except Exception:
        kodi = skin = '?'
    diag(f'FanFilm {addonInfo("version")}, Kodi {kodi}, Python {sys.version.split()[0]}, {platform.system()} {platform.release()}, skin {skin}')


def log_header_lines() -> None:
    """Write the lines of the header of the areas (`header_lines()`: the catalog of the providers, the accounts - costly at the Kodi start)."""
    for line in header_lines():
        diag(line)


def header_lines() -> Sequence[str]:
    """Return the lines of the header of the areas (the settings of the user they depend on); a part failing: the others still."""
    def api() -> Sequence[str]:
        """Return the language of the API."""
        from .control import api_language
        return [f'api {api_language("tmdb")}']

    def sources() -> Sequence[str]:
        """Return the view of the sources, the providers on, the debrid services."""
        from .source.filters import sources_header_lines
        return sources_header_lines()

    def accounts() -> Sequence[str]:
        """Return the accounts, their capabilities and their sync."""
        from .accounts import accounts_header
        return [accounts_header()]

    lines: list[str] = []
    for part in (api, sources, accounts):
        try:
            lines.extend(part())
        except Exception:
            fflog_exc()
    return lines


def main(argv: Sequence[str] | None = None) -> None:
    """The CLI: encode the bits, decode a code, the dumps of a Kodi log to files."""
    import sys
    from argparse import ArgumentParser
    parser = ArgumentParser(prog='python -m lib.ff.diagnostic', description='The diagnostic code of FanFilm.')
    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('areas', help='the areas by their bits')
    enc = sub.add_parser('encode', help='the code of the bits or of the area keys')
    enc.add_argument('parts', nargs='+')
    dec = sub.add_parser('decode', help='the areas of a code')
    dec.add_argument('code')
    tui = sub.add_parser('tui', help='the generator of a code in the terminal (its code printed at the end)')
    tui.add_argument('code', nargs='?', default='', help='a code: its fields switched on at the start')
    tui.add_argument('--set', metavar='DATA[:ADDON]', help='the Kodi profile the key "w" writes the code to as pending (its data folder, the add-on)')
    log = sub.add_parser('decode-log', help='the dumps of a Kodi log to JSON files')
    log.add_argument('log', type=Path)
    log.add_argument('folder', type=Path, nargs='?', default=Path('.'))
    if argv is None:
        from .. import cmdline_argv  # the arguments of the command line (`sys.argv` is the one of the fake plugin call)
        argv = cmdline_argv[1:]
    args = parser.parse_args(argv)
    bits = area_bits()
    if args.cmd == 'areas':
        for bit, key in sorted(bits.items()):
            print(f'{bit // CHAR_BITS + 1}  {bit:2}  {key:24} {const.debug.log_areas[key].label}')
    elif args.cmd == 'encode':
        keys = {key: bit for bit, key in bits.items()}
        print(encode((int(part) if part.isdigit() else keys[part] for part in args.parts), min_length=const.debug.diagnostic.min_length))
    elif args.cmd == 'tui':
        from ..dev.tui.diagnostic import run, target_path
        if args.code:
            try:
                decode(args.code)  # an invalid code: its error before the screen
            except ValueError as exc:
                tui.error(str(exc))
        print(run(args.code, target_path(args.set) if args.set else None))
    elif args.cmd == 'decode':
        decoded = decode(args.code)
        print(f'{decoded.code}: {", ".join(decoded.areas) or "-"}' + (f'; unknown bits {sorted(decoded.unknown)}' if decoded.unknown else ''))
    else:
        args.folder.mkdir(parents=True, exist_ok=True)
        with open(args.log, encoding='utf-8', errors='replace') as lines:
            for i, (name, data) in enumerate(blobs(lines), 1):
                path = args.folder / f'{i:03}-{name}.json'
                path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
                print(path, file=sys.stderr)


if __name__ == '__main__':
    main()
