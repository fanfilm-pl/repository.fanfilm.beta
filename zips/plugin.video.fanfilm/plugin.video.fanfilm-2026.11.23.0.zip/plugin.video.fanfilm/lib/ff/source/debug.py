"""
The debug of the sources (the page Debug of the panel of the window of the sources; its possibility: the switch of the maintenance page): what
is debugged - the sources of the chosen providers (the switch `on`) and of every provider with dropped sources (`all_dropped`), either of them
on: the mode of the debug (the window marks it, the dropped sources are kept, the list shows only the providers of the debug - one of them,
`current` -, the search again in them; the chosen providers searched without the cache read: their skips come only from a search). The state in `source_filters.json` (`/debug`): only so that the debug on again comes back where it was.
"""

from __future__ import annotations
from typing import Any, Collection, Iterable, TYPE_CHECKING
from attrs import field, frozen
if TYPE_CHECKING:
    from .funnel import SourceFunnel
    from ...sources import ProviderModule

#: The state of the debug in `source_filters.json`: `{"on": bool, "all_dropped": bool, "providers": <ADDONS_CONFIG value>, "current": <provider>}`.
DEBUG_CONFIG: str = '/debug'


@frozen(kw_only=True)
class DebugState:
    """The state of the debug of the sources."""

    #: The debug of the chosen providers is on.
    on: bool = False
    #: Every provider with dropped sources is debugged too.
    all_dropped: bool = False
    #: The chosen providers (an `ADDONS_CONFIG` value: the choice of the tree), none: no provider.
    providers: dict[str, Any] = field(factory=dict)
    #: The provider the list shows only ('' all the providers of the debug).
    current: str = ''

    @property
    def mode(self) -> bool:
        """True in the mode of the debug (either switch on)."""
        return self.on or self.all_dropped


def debug_enabled() -> bool:
    """Return True if the debug of the sources is possible (the switch of the maintenance page)."""
    from ..config import config
    return config.maintenance.debug_tab


def debug_state() -> DebugState:
    """Return the state of the debug (as written; not possible: off, the rest kept)."""
    from .filters import filters_store
    data = filters_store.get(DEBUG_CONFIG) or {}
    if not isinstance(data, dict):
        data = {}
    enabled = debug_enabled()
    return DebugState(on=enabled and data.get('on') is True, all_dropped=enabled and data.get('all_dropped') is True,
                      providers=data.get('providers') if isinstance(data.get('providers'), dict) else {}, current=str(data.get('current') or ''))


def set_debug_state(**changes: Any) -> None:
    """Write the changes of the state of the debug (`DebugState` fields)."""
    from ..config import escape_key
    from .filters import filters_store
    with filters_store.batch():
        for name, value in changes.items():  # its field only: the other ones as the file has them
            filters_store.set(f'{DEBUG_CONFIG}/{escape_key(name)}', value)


def debug_mode() -> bool:
    """Return True in the mode of the debug (the dropped sources kept)."""
    return debug_state().mode


def chosen_providers(state: DebugState, search_mods: Iterable[ProviderModule]) -> set[str]:
    """
    Return the chosen providers of the debug of the search (switch `on`) by their names: searched without the cache read (the skips of a provider
    come only from its search, never cached; its result is cached as always).
    """
    from ...sources.addons.external import choice_searches
    return {srcmod.name for srcmod in search_mods if state.on and choice_searches(state.providers, srcmod)}


def fresh_providers(search_mods: Collection[ProviderModule]) -> set[str]:
    """
    Return the providers of a search searched without the cache read (their result cached as always) by their names: every one with the area
    of the logs "no cache" (its row of the maintenance page, the diagnostic code), else the chosen ones of the debug (`chosen_providers()`).
    """
    from ..maintenance import area_on
    if area_on('sources.no_cache'):
        return {srcmod.name for srcmod in search_mods}
    return chosen_providers(debug_state(), search_mods)


def debug_providers(state: DebugState, search_mods: Iterable[ProviderModule], funnel: SourceFunnel) -> list[str]:
    """
    Return the providers of the debug (by their names, their order): the chosen ones of the search (switch `on`), with the ones which have dropped
    sources (switch `all_dropped`).
    """
    chosen = chosen_providers(state, search_mods)
    dropped = {drop.source.provider for drop in funnel.dropped if drop.step != 'filter'} if state.all_dropped else set()
    return sorted(chosen | dropped, key=str.lower)


def shown_providers(state: DebugState, providers: Collection[str]) -> Collection[str]:
    """Return the providers the list shows in the mode of the debug: the current one (if still of the debug), else all of them."""
    return {state.current} if state.current in providers else providers
