"""
The funnel of the sources of a search: what every provider sent and what its steps on the way to the list dropped (the torrents the
debrids were not asked about, the duplicates of a link, the blocked hosts, the rules, the excluded words, the unresolvable ones, the
filter of the user). The numbers of every step by the providers always (one line of the log a search), every dropped source with its
reason as a detail line of the area of the dropped sources (written, not kept), the dropped sources kept only for the debug (the debug
tab of the window of the sources, the dropped sources in its list: the mode of the debug, `lib.ff.source.debug`).
"""

from __future__ import annotations
from collections import Counter
from typing import Any, Iterable, Mapping, Sequence, TYPE_CHECKING
from attrs import define, field, frozen
from threading import Lock
from ..logs import developer_line_written, fflog
from ...kolang import L
from ...sdk.skips import Skip
if TYPE_CHECKING:
    from ..item import FFItem
    from ...sources import Source

#: The logger of the lines of the dropped sources (the area of the dropped sources of the developer logs).
DROPPED_LOGGER: str = 'lib.ff.source.manager.dropped'
#: The logger of the report of a search (under the area of the source search).
REPORT_LOGGER: str = 'lib.ff.source.manager.report'


@frozen(kw_only=True)
class FunnelStep:
    """A step of the sources on the way to the list."""

    #: The key.
    key: str
    #: The label (a column of the debug tab, the reason of a dropped source).
    label: str


#: The steps in their order (the first one: what the providers sent; the skipped ones: what the providers did not send, the mode of the debug).
FUNNEL_STEPS: tuple[FunnelStep, ...] = (
    FunnelStep(key='sent', label=L(31029, 'Sent')),
    FunnelStep(key='skipped', label=L(31054, 'Skipped by the provider')),
    FunnelStep(key='torrents', label=L(31030, 'Torrents not checked')),
    FunnelStep(key='duplicates', label=L(31031, 'Duplicates')),
    FunnelStep(key='hosts', label=L(31032, 'Blocked hosts')),
    FunnelStep(key='rules', label=L(31033, 'Rules')),
    FunnelStep(key='keywords', label=L(31034, 'Excluded words')),
    FunnelStep(key='unresolvable', label=L(31035, 'Unresolvable')),
    FunnelStep(key='filter', label=L(30951, 'Filters and sort')),
)
#: The steps which drop sources of the sent ones.
DROP_STEPS: tuple[FunnelStep, ...] = tuple(step for step in FUNNEL_STEPS if step.key not in ('sent', 'skipped'))
#: The labels of the steps by their keys.
STEP_LABELS: dict[str, str] = {step.key: step.label for step in FUNNEL_STEPS}


@frozen(kw_only=True)
class DroppedSource:
    """A source a step dropped."""

    #: The source.
    source: Source
    #: The step (`FunnelStep.key`).
    step: str
    #: Why ('' the step itself), e.g. the provider of the kept one of a duplicate.
    reason: str = ''

    @property
    def text(self) -> str:
        """Return the reason as the row of the source tells it: the step and its reason."""
        label = STEP_LABELS.get(self.step, self.step)
        return f'{label}: {self.reason}' if self.reason else label


@define(kw_only=True)
class SourceFunnel:
    """The steps of the sources of a search: the numbers by the providers, the dropped sources (only with `details`)."""

    #: The dropped sources are kept (the debug).
    details: bool = False
    #: The numbers by the provider and the step (`sent`: the sources it sent, another step: the sources it dropped).
    counts: Counter[tuple[str, str]] = field(factory=Counter)
    #: The dropped sources in the order of their steps (only with `details`).
    dropped: list[DroppedSource] = field(factory=list)

    def sent(self, sources: Iterable[Source]) -> None:
        """Count what the providers sent (the start of the funnel, a new one)."""
        self.counts = Counter()
        self.dropped = []
        for src in sources:
            self.counts[src.provider, 'sent'] += 1

    def step(self, key: str, before: Sequence[Source], after: Sequence[Source], reasons: dict[int, str] | None = None) -> None:
        """
        Count the sources the step `key` dropped (`before` not in `after`; `reasons`: why, by the `id()` of a source); a step counted again
        (the filter of another selection) replaces its numbers.
        """
        if any(step == key for _, step in self.counts):
            self.counts = Counter({pair: count for pair, count in self.counts.items() if pair[1] != key})
            self.dropped = [drop for drop in self.dropped if drop.step != key]
        if len(after) == len(before):
            return
        kept = {id(src) for src in after}
        drops = [DroppedSource(source=src, step=key, reason=(reasons or {}).get(id(src), '')) for src in before if id(src) not in kept]
        for drop in drops:
            self.counts[drop.source.provider, key] += 1
        if self.details:
            self.dropped.extend(drops)
        if key != 'filter' and developer_line_written(DROPPED_LOGGER):  # the lines of the dropped sources (not kept: the area of the logs)
            fflog.debug(f'[SOURCES] dropped ({key}): {len(drops)}' + ''.join(f'\n    {drop.text}: {drop.source!r}' for drop in drops), module=DROPPED_LOGGER)

    def add_skipped(self, dropped: list[DroppedSource]) -> None:
        """Count and keep the candidates the providers skipped (the step `skipped`; not of the sent ones: no number of the list less)."""
        for drop in dropped:
            self.counts[drop.source.provider, 'skipped'] += 1
        if self.details:
            self.dropped.extend(dropped)

    def providers(self) -> list[str]:
        """Return the providers which sent sources (by their names)."""
        return sorted({provider for provider, step in self.counts if step == 'sent'})

    def total(self, key: str) -> int:
        """Return the number of the step of all the providers."""
        return sum(count for (_, step), count in self.counts.items() if step == key)

    def dropped_of(self, provider: str) -> list[DroppedSource]:
        """Return the dropped sources of the provider."""
        return [drop for drop in self.dropped if drop.source.provider == provider]

    def report(self, title: str, times: Mapping[str, Any]) -> None:
        """
        Write the report of the search (a detail line of the area of the source search, only if written): every provider of the search (`times`:
        its `ProviderTimes`) - how it went, sent, in the list, the steps -, the dropped and the skipped sources with their reasons (the mode of the
        debug: kept).
        """
        if not developer_line_written(REPORT_LOGGER):
            return
        lines = [f'[SOURCES] report: {title}, providers {len(times)}']
        for name in sorted(times, key=str.lower):
            sent = self.counts[name, 'sent']
            drops = ', '.join(f'-{count} {step.key}' for step in DROP_STEPS if (count := self.counts[name, step.key]))
            skipped = f', {count} skipped' if (count := self.counts[name, 'skipped']) else ''
            lines.append(f'  {name}: {provider_state(times[name])}, sent {sent}, in the list {sent - self.total_of(name)}'
                         + (f' ({drops})' if drops else '') + skipped)
            lines.extend(f'    [{drop.text}] {drop.source!r}' for drop in self.dropped if drop.source.provider == name)
        fflog.debug('\n'.join(lines), module=REPORT_LOGGER)

    def total_of(self, provider: str) -> int:
        """Return the number of the sources of the provider the steps dropped (of the sent ones)."""
        return sum(self.counts[provider, step.key] for step in DROP_STEPS)

    def log(self, shown: int) -> None:
        """Log the numbers of the steps (one information line)."""
        steps = ', '.join(f'-{count} {step.key}' for step in DROP_STEPS if (count := self.total(step.key)))
        if skipped := self.total('skipped'):
            steps = ', '.join(text for text in (steps, f'{skipped} skipped by the providers') if text)
        fflog(f'[SOURCES] funnel: {self.total("sent")} sent{", " + steps if steps else ""}, {shown} in the list')


class SearchSkips:
    """The candidates the providers of a search skipped (the mode of the debug: `lib.sdk.skips`), by the providers; never cached."""

    def __init__(self) -> None:
        """No skip yet."""
        #: The skips by the names of the providers.
        self.by_provider: dict[str, list[Skip]] = {}
        #: Guards the skips.
        self.lock: Lock = Lock()

    def clear(self) -> None:
        """Forget the skips (a new search)."""
        with self.lock:
            self.by_provider = {}

    def add(self, provider: str, skips: list[Skip]) -> None:
        """Keep the skips of a provider."""
        if skips:
            with self.lock:
                self.by_provider.setdefault(provider, []).extend(skips)

    def take(self) -> dict[str, list[Skip]]:
        """Return the skips and forget them."""
        with self.lock:
            skips, self.by_provider = self.by_provider, {}
        return skips


#: The skips of the current search.
search_skips: SearchSkips = SearchSkips()


def skipped_sources(ffitem: FFItem, skips: dict[str, list[Skip]]) -> list[DroppedSource]:
    """
    Return the skipped candidates as dropped sources of the step `skipped` (a source of their fields, the reason of the provider; their info: the
    one of the provider, else their name - the file name, the title, the link).
    """
    from ...sources import Source
    dropped: list[DroppedSource] = []
    for provider, items in skips.items():
        for item in items:
            meta = {key: str(value) for key, value in item.items() if key != 'reason'}
            meta.setdefault('filename', meta.get('title', ''))
            meta.setdefault('info', meta['filename'] or meta.get('url', ''))  # the text of its row: the provider gave no other (no hosting, no facts)
            meta = {'url': '', 'quality': '', 'language': '', **meta, 'provider': provider}
            src = Source.from_meta(ffitem=ffitem, meta=meta)  # type: ignore[arg-type]
            dropped.append(DroppedSource(source=src, step='skipped', reason=str(item.get('reason', ''))))
    return dropped


def provider_state(times: Any) -> str:
    """Return how the search of a provider went by its times (`ProviderTimes`): not ended (a time limit, an error), the cache, searched."""
    if times.dynamic is None:
        return 'not ended'
    if times.find is None:
        return f'cache {times.cache or 0:.2f} s'
    return f'searched {times.find:.2f} s' + (f' (show {times.show:.2f} s)' if times.show else '')


def funnel_details() -> bool:
    """Return True if the dropped sources are kept: only in the mode of the debug of the sources (whatever the levels of the logs)."""
    from .debug import debug_mode
    return debug_mode()
