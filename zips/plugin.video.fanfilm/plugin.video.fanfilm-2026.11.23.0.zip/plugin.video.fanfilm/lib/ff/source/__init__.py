"""The sources of a search: the manager, the filters and keys of the user, the facts, the funnel, the debug, the utils of the providers."""
