"""
The FF web server by its settings (the card `Web` of `lib.ff.config.options`, the page "Web server" of the configuration window): the address
it listens on, the access of a browser of this device, the pairing open; the data of the server kept under the root of the card (its devices,
its password, its instance: `lib.service.web_auth`; the targets of the forwarded cookies: `lib.service.web_client`).
"""

from __future__ import annotations
from .config import config
from .config.choices import NO_ROLE, OFF_ROLE

#: The root of the web server in the configuration (`config.json`): its settings (the card) and its data.
WEB_CONFIG: str = '/web'
#: The address the server listens on: only this device (the loopback), any interface.
LOOPBACK_ADDRESS: str = '127.0.0.1'
ANY_ADDRESS: str = '0.0.0.0'
#: The devices of the web server in the configuration: `{<id>: <device>}` (`lib.service.web_auth`).
DEVICES_CONFIG: str = f'{WEB_CONFIG}/devices'
#: The password of the web server in the configuration (its SCRAM keys, never the password).
PASSWORD_CONFIG: str = f'{WEB_CONFIG}/password'
#: The ID of this FF (random, once): a client tells two Kodi apart whatever their addresses.
INSTANCE_CONFIG: str = f'{WEB_CONFIG}/instance'
#: The other FanFilm the received cookies are forwarded to: `{<id>: <target>}` (this FF paired with each one as its client, `lib.service.web_client`).
TARGETS_CONFIG: str = f'{WEB_CONFIG}/targets'
#: The job of the worker script showing the requests for the access (`worker.py`, `lib.windows.pair_request.show_requests()`).
WEB_REQUEST_JOB: str = 'web_request'
#: The window property of the Home window while a worker shows the requests (one at a time: the shown window follows the new requests).
WEB_REQUEST_PROPERTY: str = 'fanfilm.web.request'
#: The objects of the web server in the configuration which are access data as a whole (a backup keeps them only with the access data).
WEB_ACCESS_DATA: tuple[str, ...] = (DEVICES_CONFIG, PASSWORD_CONFIG, INSTANCE_CONFIG, TARGETS_CONFIG)


def local_role() -> str:
    """Return the role of a browser of this device without pairing ('' none: it pairs, or it is refused - `local_off()`)."""
    role = config.web.this_device
    return '' if role in (NO_ROLE, OFF_ROLE) else role


def local_off() -> bool:
    """Return True if a browser of this device at the loopback is refused (a paired one too)."""
    return config.web.this_device == OFF_ROLE


def pairs() -> bool:
    """Return True if a device can pair: the network open, or a browser of this device pairing (no role of its own)."""
    return bool(config.web.network) or config.web.this_device == NO_ROLE


def listen_address() -> str | None:
    """Return the address the web server listens on: any interface with the network open, else the loopback (this device off too: None)."""
    if config.web.network:
        return ANY_ADDRESS
    return None if local_off() else LOOPBACK_ADDRESS
