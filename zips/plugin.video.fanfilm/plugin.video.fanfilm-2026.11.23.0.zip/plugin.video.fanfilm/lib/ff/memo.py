"""
The memory of one answer: values read many times while one answer is built (the web page of the configuration: the state of the accounts,
the add-ons enabled in Kodi) are read once. Only inside `answer_memo()` (a block of the thread, after the writes of the request: a value
read there does not change while the answer is built); out of it every read goes to its source, as before.

The pattern: `config.reads()` (a block of the thread, a nested one is the same).
"""

from __future__ import annotations
from contextlib import contextmanager
from threading import local
from typing import Callable, Generator, Hashable, TypeVar

#: A remembered value (immutable: a tuple, a frozenset, a number, a text; a list would be shared by its readers).
T = TypeVar('T')

#: The memory of the thread in its block (`memory`: None out of a block).
_state: local = local()


@contextmanager
def answer_memo() -> Generator[None, None, None]:
    """Remember the values of `memoized()` in the block of this thread (a nested block: the same memory), forget them after it."""
    if getattr(_state, 'memory', None) is not None:
        yield
        return
    _state.memory = {}
    try:
        yield
    finally:
        _state.memory = None


def in_answer() -> bool:
    """Return True in the block of `answer_memo()` of this thread (a value of many reads is then read once)."""
    return getattr(_state, 'memory', None) is not None


def memoized(name: str, key: Hashable, build: Callable[[], T]) -> T:
    """Return the value of `name` for `key` built once in the block of `answer_memo()` (`build()`), out of a block: built now."""
    memory: dict[tuple[str, Hashable], object] | None = getattr(_state, 'memory', None)
    if memory is None:
        return build()
    try:
        return memory[name, key]  # type: ignore[return-value]
    except KeyError:
        value = memory[name, key] = build()
        return value
