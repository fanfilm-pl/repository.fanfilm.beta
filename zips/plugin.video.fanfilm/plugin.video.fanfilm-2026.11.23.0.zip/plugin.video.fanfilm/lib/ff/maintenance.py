"""
The maintenance by its settings (the card `Maintenance` of `lib.ff.config.options`, the page "Maintenance" of the configuration window):
the developer tools (shown and working by `const.debug.developer_tools`, None - by the choice kept in the configuration), the rows of the
developer logs, the details of their areas.
"""

from __future__ import annotations
from .config.choices import log_area_key
from const import const

#: The root of the maintenance in the configuration (`config.json`): its settings (the card) and the choice of the developer tools.
MAINTENANCE_CONFIG: str = '/maintenance'
#: The row of the diagnostic code (`lib.ff.diagnostic`, its state: not a value of the configuration).
DIAGNOSTIC_SETTING: str = 'diagnostic'
#: The choice of the developer tools in the configuration (with `const.debug.developer_tools` None: "0" pressed three times).
DEVELOPER_CONFIG: str = f'{MAINTENANCE_CONFIG}/developer'


def developer_tools() -> bool:
    """Return True if the developer tools are shown and work: `const.debug.developer_tools`, None - the choice of the configuration."""
    from .config import config
    if (tools := const.debug.developer_tools) is not None:
        return tools
    return config.get(DEVELOPER_CONFIG, None) is True


def toggle_developer_tools() -> bool | None:
    """Show or hide the developer tools (the choice of the configuration), return their new state; None: the const decides (no change)."""
    from .config import config
    if const.debug.developer_tools is not None:
        return None
    shown = not developer_tools()
    config.set(DEVELOPER_CONFIG, shown, default=False)
    return shown


def area_on(key: str) -> bool:
    """Return True if the details of an area of the developer logs are on: its row of the maintenance page or the diagnostic code."""
    from .config import config
    from .diagnostic import active_areas
    return (const.debug.log_areas[key].group is not None and bool(config.maintenance.get(log_area_key(key)))) or key in active_areas()
