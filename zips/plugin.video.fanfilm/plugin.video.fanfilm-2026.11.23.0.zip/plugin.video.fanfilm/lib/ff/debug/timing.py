"""Simple timing utilities, the samples of a slow call."""

from __future__ import annotations
import os
import re
import sys
import faulthandler
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryFile
from threading import Event, get_ident
from time import monotonic, thread_time
from functools import update_wrapper
from inspect import iscoroutinefunction
from typing import Optional, Any, TextIO, Callable, TypeVar, Generator, IO
from typing_extensions import Literal, Self, ParamSpec, Protocol, overload
from ...ff.logs import fflog as _fflog, developer_line_written
from ...ff.logs import LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR, LOGFATAL  # noqa: F401
from const import const

P = ParamSpec('P')
T = TypeVar('T')
R = TypeVar('R', covariant=True)

PRINT = -1


class WithDescrProtocol(Protocol[P, R]):

    @overload
    def __new__(cls, wrapped: Callable[P, R]) -> WithDescrProtocol[P, R]: ...
    @overload
    def __new__(cls, wrapped: Literal[None] = None) -> WithDescrProtocol: ...

    def __call__(self, *args: P.args, **kwargs: P.kwargs) -> R: ...

    def __enter__(self) -> Self: ...
    def __exit__(self, exc_type, exc_value, traceback): ...

    async def __aenter__(self) -> Self: ...
    async def __aexit__(self, exc_type, exc_value, traceback): ...


@overload
def logtime(wrapped: Callable[P, R], /, *, name: Optional[str] = None, file: TextIO = sys.stdout, fflog: int = LOGINFO) -> Callable[P, R]: ...


@overload
def logtime(wrapped: str, /, *, file: TextIO = sys.stdout, fflog: int = LOGINFO) -> WithDescrProtocol: ...


@overload
def logtime(wrapped: Literal[None] = None, /, *, name: Optional[str] = None, file: TextIO = sys.stdout, fflog: int = LOGINFO) -> WithDescrProtocol: ...


def logtime(wrapped: Callable[P, R] | str | None = None, /, *, name: Optional[str] = None, file: TextIO = sys.stdout, fflog: int = LOGINFO) -> Any:
    """
    Print timing log.

    Examples:
    >>> @logtime
    ... def f():
    ...     pass

    >>> with logtime(name='myblock'):
    ...     pass
    """

    class LogTiming:

        def __init__(self, *, name: str | None = None, file: TextIO = sys.stdout, fflog: int = fflog):
            self.name: Optional[str] = name
            self.file: TextIO = file
            self.fflog: int = fflog
            self.t: float = 0

        def __call__(self, wrapped):
            async def awrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                """Log async call time consumption."""
                t = monotonic()
                try:
                    result = await wrapped(*args, **kwargs)
                finally:
                    t = monotonic() - t
                    self.log(t, f'async call {wrapped.__qualname__}()')
                return result

            def swrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                """Log call time consumption."""
                t = monotonic()
                result = wrapped(*args, **kwargs)
                t = monotonic() - t
                self.log(t, f'call {wrapped.__qualname__}()')
                return result

            if iscoroutinefunction(wrapped):
                wrapper = awrapper
            else:
                wrapper = swrapper
            update_wrapper(wrapper, wrapped)
            return wrapper

        def __enter__(self):
            self.t = monotonic()
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            t = monotonic() - self.t
            self.log(t, 'with statement')

        async def __aenter__(self):
            self.t = monotonic()
            return self

        async def __aexit__(self, exc_type, exc_value, traceback):
            t = monotonic() - self.t
            self.log(t, 'async with statement')

        def log(self, t, funcname):
            if self.name is not None:
                funcname = self.name
            if self.fflog >= 0:
                _fflog(f'Time of {funcname} is {t:.3f}', level=self.fflog)
            else:
                print(f'Time of {funcname} is {t:.3f}', file=self.file)

    if isinstance(wrapped, str):
        if name is None:
            name = wrapped
        wrapped = None
    obj = LogTiming(name=name, file=file)
    if wrapped is None:   # with statement or decorator with arguments
        return obj
    return obj(wrapped)   # decorator without arguments


#: The logger of the timing lines (the area "timing" of the developer logs): the lines of other modules give it as `module`.
TIMING_LOGGER: str = __name__
#: A cyclic work of the service shorter than this [s] has no timing line (a check every second would fill the log).
TIMING_MIN_WORK: float = 0.1
#: The step of the samples of a slow call [s].
SLOW_SAMPLE_STEP: float = 1
#: The places of a slow call in its line (the most often sampled first).
SLOW_TOP: int = 5
#: The frames of FanFilm of one place of a slow call (the innermost one and its caller).
SLOW_PLACE_FRAMES: int = 2
#: The frames of FanFilm of a sample line (the area "timing").
SLOW_SAMPLE_FRAMES: int = 4
#: The folder of FanFilm (as imported, a link not resolved: the paths of the frames): the frames of its files are the places of a slow call.
_ADDON_DIR: str = os.path.abspath(Path(__file__).parents[3])
#: The folder of FanFilm as `faulthandler` writes a path (not ASCII as `\\xNN`, `\\uNNNN`: e.g. a Windows user "Paweł").
_ADDON_DIR_DUMPED: str = _ADDON_DIR.encode('ascii', 'backslashreplace').decode('ascii')
#: The header of a thread in the dump of `faulthandler` (its ident).
_THREAD_RX: re.Pattern[str] = re.compile(r'^(?:Current thread|Thread) (0x[0-9a-fA-F]+)')
#: A frame in the dump of `faulthandler` (the file, the line, the function).
_FRAME_RX: re.Pattern[str] = re.compile(r'File "([^"]+)", line (\d+),? in (\S+)')


def _dump_file() -> IO[str]:
    """Return a new file for a dump of the threads: in memory where the system has it, a temporary file otherwise."""
    if hasattr(os, 'memfd_create'):
        try:
            return os.fdopen(os.memfd_create('ff-threads'), 'w+', errors='replace')
        except OSError:
            pass
    return TemporaryFile('w+', errors='replace')


def thread_dump(ident: int) -> list[str]:
    """
    Return the lines of the stack of the thread `ident` of this interpreter (the innermost frame first, as `faulthandler` writes them).
    The dump of `faulthandler` has the threads of this interpreter only, no Python objects; `sys._current_frames()` has
    the threads of every interpreter of the process (other add-ons in Kodi) and makes their frame objects here. No lines
    if the dump can not be written (no file for it).
    """
    try:
        with _dump_file() as file:
            faulthandler.dump_traceback(file, all_threads=True)
            file.seek(0)
            text = file.read()
    except OSError:
        return []
    lines: list[str] = []
    found = False
    for line in text.splitlines():
        if (mch := _THREAD_RX.match(line)) is not None:
            if found:
                break
            found = int(mch[1], 16) == ident
        elif found and line.strip():
            lines.append(line.strip())
    return lines


def thread_frames(ident: int) -> list[str]:
    """Return the frames of FanFilm of the thread `ident` of this interpreter, the innermost first (`lib/ff/x.py:12 func`), see `thread_dump()`."""
    frames: list[str] = []
    for line in thread_dump(ident):
        if (mch := _FRAME_RX.search(line)) is not None and (path := os.path.abspath(mch[1])).startswith(_ADDON_DIR_DUMPED + os.sep):
            frames.append(f'{Path(path[len(_ADDON_DIR_DUMPED) + 1:]).as_posix()}:{mch[2]} {mch[3]}')
    return frames


@contextmanager
def slow_watch(label: str) -> Generator[None, None, None]:
    """
    Watch a call of this thread: if it runs longer than `const.debug.slow_call`, its thread is sampled every second from then
    on and its end logs one line with the time, the CPU time of the thread and the frames of FanFilm found most often (the
    area "timing": every sample too). A call within the limit costs the start and the join of the watching thread.
    """
    after = const.debug.slow_call
    if not after:
        yield
        return
    from ..threads import Thread
    ident = get_ident()
    start, cpu = monotonic(), thread_time()
    done = Event()  # not the Kodi aware event: the watch ends with the call (the join below), never by its own
    places: Counter[str] = Counter()

    def sample() -> None:
        """Sample the thread of the call after `after` s until its end."""
        if done.wait(after):
            return
        detailed = developer_line_written(TIMING_LOGGER)
        while True:
            if frames := thread_frames(ident):
                places[' < '.join(frames[:SLOW_PLACE_FRAMES])] += 1
                if detailed:
                    _fflog.debug(f'[SLOW] {label} {monotonic() - start:.1f} s: {" < ".join(frames[:SLOW_SAMPLE_FRAMES])}', module=TIMING_LOGGER)
            if done.wait(SLOW_SAMPLE_STEP):
                return

    watch = Thread(target=sample, name='Slow call watch', daemon=True)
    watch.start()
    try:
        yield
    finally:
        done.set()
        watch.join()
        if (elapsed := monotonic() - start) >= after:
            top = ', '.join(f'{place} {count}×' for place, count in places.most_common(SLOW_TOP))
            _fflog(f'[SLOW] {label}: {elapsed:.1f} s, cpu {thread_time() - cpu:.1f} s, {sum(places.values())} samples: {top}')
