"""
The filters of a discovery of TMDB (`TmdbApi.DISCOVER_FILTERS`) as a text: the query of a `tmdb://` address of an own list
(`OwnList.query_tmdb`), the filters of an advanced search in its history (`lib.indexers.search`).

The text is in the form of TMDB itself (a condition: `key.gte=value`, `key.lte=value`), sorted, the values quoted: the same filters
give the same text (one entry of the history, one key of the cache of the lists).

The fields of an advanced search (`FIELDS`: one declaration for its window `lib.windows.discover` and the web page): a field is a filter
of TMDB with its label, its media, its group (a tab), the source of its choices; its kind (the control) comes from the filter
(`DiscoverField.kind`), its value from the filters and back (`DiscoverField.read()`, `DiscoverField.write()`).
"""

from __future__ import annotations
from datetime import date as dt_date
from typing import Any, Callable, Iterable, Mapping, Sequence
from typing_extensions import Literal, TypeAlias
from urllib.parse import quote, unquote
from attrs import Factory, field as attr_field, frozen

from ..api.tmdb import Condition, DiscoveryFilters, TmdbApi, filter_ids
from ..kolang import L
from .gui.scale import Scale, ScaleValue
from const import const

#: The media of an advanced search.
DiscoverMedia: TypeAlias = Literal['movie', 'show']
#: The group of a field (a tab of the window).
DiscoverGroup: TypeAlias = Literal['what', 'when', 'where', 'rating']
#: Where the choices of a field come from ('' none: a text, a number).
ChoiceSource: TypeAlias = Literal['', 'genres', 'keyword', 'person', 'providers', 'countries', 'languages', 'networks', 'status', 'type', 'sort']
#: The kind of a field (its control): a text, the grid of the genres (with / without), the found ones (with / without), several of
#: a list, one of a list, a range, a least value.
FieldKind: TypeAlias = Literal['text', 'grid', 'lookup', 'multi', 'choice', 'range', 'minimum']
#: The sources of the choices of the kinds (the others: one of a list).
SOURCE_KINDS: Mapping[str, FieldKind] = {'genres': 'grid', 'keyword': 'lookup', 'person': 'lookup', 'providers': 'multi'}
#: The separator of the values of a list: all of them (AND).
ALL: str = ','
#: The separator of the values of a list: any of them (OR).
ANY: str = '|'
#: The value of no limit at an end of a range, of no least value (a special value of their scales: a number, the spin boxes take
#: None as their first position).
NO_LIMIT: int = 0
#: The text of no limit at an end of a scale, no choice.
ANY_LABEL: str = L(30772, 'any')


@frozen
class DiscoverGroupDef:
    """A group of the fields (a tab of the window)."""

    #: The name (the page of the tab).
    name: DiscoverGroup
    #: The title of its tab.
    title: str


#: The groups of the fields in their order (the tabs).
GROUPS: tuple[DiscoverGroupDef, ...] = (
    DiscoverGroupDef('what', L(33041, 'What')),
    DiscoverGroupDef('when', L(33042, 'When')),
    DiscoverGroupDef('where', L(33043, 'Where')),
    DiscoverGroupDef('rating', L(31367, 'Rating and order')),
)


@frozen(kw_only=True)
class Chosen:
    """The value of a field of several choices: the chosen IDs (with), the excluded ones (without), all of them or any of them."""

    #: The chosen IDs (the media have them).
    with_ids: tuple[str, ...] = ()
    #: The excluded IDs (the media have none of them).
    without_ids: tuple[str, ...] = ()
    #: All the chosen ones (AND), else any of them (OR).
    every: bool = True


@frozen(kw_only=True)
class DiscoverField:
    """A field of an advanced search: a filter of TMDB (`key`), its label, its media, its group, where its choices come from."""

    #: The filter of TMDB (a range: its key without `.gte` / `.lte`).
    key: str
    #: The label.
    label: str
    #: The group (a tab).
    group: DiscoverGroup
    #: The media the filter is of.
    media: tuple[DiscoverMedia, ...] = ('movie', 'show')
    #: Where its choices come from ('' none).
    source: ChoiceSource = ''
    #: The filter of the excluded choices ('' none).
    exclude: str = ''
    #: The scale of a range, of a least value (its ends: no limit), None none; not in the repr (the template data of the window).
    scale: Callable[[], Scale] | None = attr_field(default=None, repr=False)
    #: A range: the least value only - by its scale (`Scale.least`), once.
    least: bool = attr_field(init=False, repr=False, default=Factory(lambda self: self.scale is not None and self.scale().least, takes_self=True))
    #: The separator of the chosen ones: all of them (AND), any of them (OR); several of a list.
    join: str = ALL
    #: The filter of the region of the choices (with some chosen: the region of FanFilm, `const.indexer.region`), '' none.
    region: str = ''

    @property
    def kind(self) -> FieldKind:
        """Return the kind (the control): by the source of the choices, a condition of TMDB (`.gte`) a range or a least value, else a text."""
        if self.source:
            return SOURCE_KINDS.get(self.source, 'choice')
        if f'{self.key}.gte' in TmdbApi.DISCOVER_FILTERS:
            return 'minimum' if self.least else 'range'
        return 'text'

    @property
    def years(self) -> bool:
        """Return True if the range is of the dates in years (the scale of years, the dates of the whole years)."""
        return TmdbApi.DISCOVER_FILTERS.get(f'{self.key}.gte') is dt_date

    def read(self, filters: Mapping[str, Any]) -> Any:
        """Return the value of the field of the filters (`filters_from_text()`; a range: a pair, `NO_LIMIT` no limit; several: `Chosen`)."""
        kind = self.kind
        if kind in ('range', 'minimum'):
            low, high = (self._number(filters.get(f'{self.key}.{end}')) for end in ('gte', 'lte'))
            return low if kind == 'minimum' else (low, high)
        value = str(filters.get(self.key) or '')
        if kind in ('grid', 'lookup', 'multi'):
            return Chosen(with_ids=filter_ids(value), without_ids=filter_ids(str(filters.get(self.exclude) or '')) if self.exclude else (),
                          every=ANY not in value if kind == 'grid' else self.join == ALL)
        return value

    def write(self, value: Any) -> dict[str, Any]:
        """Return the filters of the value of the field (`read()`): none for no value (no limit, nothing chosen)."""
        kind = self.kind
        if kind in ('range', 'minimum'):
            low, high = (value, NO_LIMIT) if kind == 'minimum' else value
            return {f'{self.key}.{end}': self._end(number, end) for end, number in (('gte', low), ('lte', high)) if number != NO_LIMIT}
        if isinstance(value, Chosen):
            join = (ALL if value.every else ANY) if kind == 'grid' else self.join
            filters = {self.key: join.join(value.with_ids)} if value.with_ids else {}
            if self.region and value.with_ids:  # the choices of the region of FanFilm (VOD services)
                filters[self.region] = const.indexer.region
            if self.exclude and value.without_ids:  # TMDB excludes any of them (`,` the same as `|`)
                filters[self.exclude] = ALL.join(value.without_ids)
            return filters
        return {self.key: value} if value else {}

    def _number(self, text: Any) -> Any:
        """Return the number of a value of a range (a date: its year), `NO_LIMIT` for none."""
        if text is None or text == '':
            return NO_LIMIT
        if self.years:
            return int(str(text)[:4])
        try:
            return int(text)
        except ValueError:
            return float(text)

    def _end(self, number: Any, end: str) -> str:
        """Return the value of TMDB of an end of a range (a year: its first / last day)."""
        if self.years:
            return f'{number}-01-01' if end == 'gte' else f'{number}-12-31'
        return str(number)


def years_scale() -> Scale:
    """Return the scale of the years of a range (no limit at its ends; the last one: two years ahead - the announced ones)."""
    return Scale(minimum=1900, maximum=dt_date.today().year + 2, step=1, major=20, low=(ScaleValue(NO_LIMIT, ANY_LABEL),),
                 high=(ScaleValue(NO_LIMIT, ANY_LABEL),))


def runtime_scale() -> Scale:
    """Return the scale of the runtime in minutes (no limit at its ends)."""
    return Scale(minimum=10, maximum=240, step=10, major=60, format=L(31368, '{} min'), tick_format='{}', low=(ScaleValue(NO_LIMIT, ANY_LABEL),),
                 high=(ScaleValue(NO_LIMIT, ANY_LABEL),))


def rating_scale() -> Scale:
    """Return the scale of the least rating (none at its low end)."""
    return Scale(minimum=1, maximum=9.5, step=0.5, major=1, format='{:g}', tick_format='{:g}', low=(ScaleValue(NO_LIMIT, ANY_LABEL),), least=True)


def votes_scale() -> Scale:
    """Return the scale of the least number of the votes (the one of the settings: none at its low end)."""
    from .config.choices import votes_scale as settings_votes_scale
    return settings_votes_scale()


@frozen
class TvChoice:
    """A choice of TMDB of a show (its status, its type): the value of TMDB and its label."""

    #: The value of TMDB.
    value: str
    #: The label.
    label: str


#: The statuses of a show of TMDB (`with_status`).
TV_STATUSES: tuple[TvChoice, ...] = (
    TvChoice('0', L(31369, 'Returning series')),
    TvChoice('1', L(31370, 'Planned')),
    TvChoice('2', L(31371, 'In production')),
    TvChoice('3', L(31372, 'Ended')),
    TvChoice('4', L(31373, 'Canceled', ctx='a status of a show')),
    TvChoice('5', L(31374, 'Pilot')),
)
#: The types of a show of TMDB (`with_type`).
TV_TYPES: tuple[TvChoice, ...] = (
    TvChoice('0', L(31375, 'Documentary')),
    TvChoice('1', L(31376, 'News')),
    TvChoice('2', L(31377, 'Miniseries')),
    TvChoice('3', L(31378, 'Reality')),
    TvChoice('4', L(31379, 'Scripted')),
    TvChoice('5', L(31380, 'Talk show')),
    TvChoice('6', L(31381, 'Video', ctx='a type of a show')),
)


@frozen
class Network:
    """A TV network of TMDB (`with_networks`): its ID, its name, its logo."""

    #: The ID of TMDB.
    id: int
    #: The name.
    name: str
    #: The URL of the logo.
    logo: str


# Hmmm... logo i nazwy można wziąć z API: https://api.themoviedb.org/3/network/{network_id}
#: The predefined TV networks.
NETWORKS: tuple[Network, ...] = (
    Network(id=54, name='Disney Channel', logo='https://i.imgur.com/ZCgEkp6.png'),
    Network(id=44, name='Disney XD', logo='https://i.imgur.com/PAJJoqQ.png'),
    Network(id=2, name='ABC', logo='https://i.imgur.com/qePLxos.png'),
    Network(id=493, name='BBC America', logo='https://i.imgur.com/TUHDjfl.png'),
    Network(id=6, name='NBC', logo='https://i.imgur.com/yPRirQZ.png'),
    Network(id=13, name='Nickelodeon', logo='https://i.imgur.com/OUVoqYc.png'),
    Network(id=14, name='PBS', logo='https://i.imgur.com/r9qeDJY.png'),
    Network(id=16, name='CBS', logo='https://i.imgur.com/8OT8igR.png'),
    Network(id=19, name='FOX', logo='https://i.imgur.com/6vc0Iov.png'),
    Network(id=21, name='The WB', logo='https://i.imgur.com/rzfVME6.png'),
    Network(id=24, name='BET', logo='https://i.imgur.com/ZpGJ5UQ.png'),
    Network(id=30, name='USA Network', logo='https://i.imgur.com/Doccw9E.png'),
    Network(id=32, name='CBC', logo='https://i.imgur.com/unQ7WCZ.png'),
    Network(id=33, name='MTV', logo='https://i.imgur.com/QM6DpNW.png'),
    Network(id=34, name='Lifetime', logo='https://i.imgur.com/tvYbhen.png'),
    Network(id=35, name='Nick Junior', logo='https://i.imgur.com/leuCWYt.png'),
    Network(id=41, name='TNT', logo='https://i.imgur.com/WnzpAGj.png'),
    Network(id=43, name='National Geographic', logo='https://i.imgur.com/XCGNKVQ.png'),
    Network(id=47, name='Comedy Central', logo='https://i.imgur.com/ko6XN77.png'),
    Network(id=49, name='HBO', logo='https://i.imgur.com/Hyu8ZGq.png'),
    Network(id=55, name='Spike', logo='https://i.imgur.com/BhXYytR.png'),
    Network(id=67, name='Showtime', logo='https://i.imgur.com/SawAYkO.png'),
    Network(id=56, name='Cartoon Network', logo='https://i.imgur.com/zmOLbbI.png'),
    Network(id=65, name='History Channel', logo='https://i.imgur.com/LEMgy6n.png'),
    Network(id=84, name='TLC', logo='https://i.imgur.com/c24MxaB.png'),
    Network(id=68, name='TBS', logo='https://i.imgur.com/RVCtt4Z.png'),
    Network(id=71, name='The CW', logo='https://i.imgur.com/Q8tooeM.png'),
    Network(id=74, name='Bravo', logo='https://i.imgur.com/TmEO3Tn.png'),
    Network(id=76, name='E!', logo='https://i.imgur.com/3Delf9f.png'),
    Network(id=77, name='Syfy', logo='https://i.imgur.com/9yCq37i.png'),
    Network(id=80, name='Adult Swim', logo='https://i.imgur.com/jCqbRcS.png'),
    Network(id=91, name='Animal Planet', logo='https://i.imgur.com/olKc4RP.png'),
    Network(id=110, name='CTV', logo='https://i.imgur.com/qUlyVHz.png'),
    Network(id=129, name='A&E', logo='https://i.imgur.com/xLDfHjH.png'),
    Network(id=158, name='VH1', logo='https://i.imgur.com/IUtHYzA.png'),
    Network(id=174, name='AMC', logo='https://i.imgur.com/ndorJxi.png'),
    Network(id=928, name='Crackle', logo='https://i.imgur.com/53kqZSY.png'),
    Network(id=202, name='WGN America', logo='https://i.imgur.com/TL6MzgO.png'),
    Network(id=209, name='Travel Channel', logo='https://i.imgur.com/mWXv7SF.png'),
    Network(id=213, name='Netflix', logo='https://i.imgur.com/jI5c3bw.png'),
    Network(id=251, name='Audience', logo='https://i.imgur.com/5Q3mo5A.png'),
    Network(id=270, name='SundanceTV', logo='https://i.imgur.com/qldG5p2.png'),
    Network(id=318, name='Starz', logo='https://i.imgur.com/Z0ep2Ru.png'),
    Network(id=359, name='Cinemax', logo='https://i.imgur.com/zWypFNI.png'),
    Network(id=364, name='truTV', logo='https://i.imgur.com/HnB3zfc.png'),
    Network(id=384, name='Hallmark Channel', logo='https://i.imgur.com/zXS64I8.png'),
    Network(id=397, name='TV Land', logo='https://i.imgur.com/1nIeDA5.png'),
    Network(id=1024, name='Amazon', logo='https://i.imgur.com/ru9DDlL.png'),
    Network(id=1267, name='Freeform', logo='https://i.imgur.com/f9AqoHE.png'),
    Network(id=4, name='BBC One', logo='https://i.imgur.com/u8x26te.png'),
    Network(id=332, name='BBC Two', logo='https://i.imgur.com/SKeGH1a.png'),
    Network(id=3, name='BBC Three', logo='https://i.imgur.com/SDLeLcn.png'),
    Network(id=100, name='BBC Four', logo='https://i.imgur.com/PNDalgw.png'),
    Network(id=214, name='Sky One', logo='https://i.imgur.com/xbgzhPU.png'),
    Network(id=9, name='ITV', logo='https://i.imgur.com/5Hxp5eA.png'),
    Network(id=26, name='Channel 4', logo='https://i.imgur.com/6ZA9UHR.png'),
    Network(id=99, name='Channel 5', logo='https://i.imgur.com/5ubnvOh.png'),
    Network(id=136, name='E4', logo='https://i.imgur.com/frpunK8.png'),
    Network(id=210, name='HGTV', logo='https://i.imgur.com/INnmgLT.png'),
    Network(id=453, name='Hulu', logo='https://i.imgur.com/uSD2Cdw.png'),
    Network(id=1436, name='YouTube Red', logo='https://i.imgur.com/ZfewP1Y.png'),
    Network(id=64, name='Discovery Channel', logo='https://i.imgur.com/8UrXnAB.png'),
    Network(id=2739, name='Disney+', logo='https://i.imgur.com/DVrPgbM.png'),
    Network(id=2552, name='Apple TV +', logo='https://i.imgur.com/fAQMVNp.png'),
    Network(id=2697, name='Acorn TV', logo='https://i.imgur.com/fSWB5gB.png'),
    Network(id=1709, name='CBS All Access', logo='https://i.imgur.com/ZvaWMuU.png'),
    Network(id=3186, name='HBO Max', logo='https://i.imgur.com/mmRMG75.png'),
    Network(id=2243, name='DC Universe', logo='https://i.imgur.com/bhWIubn.png'),
    Network(id=2076, name='Paramount Network', logo='https://i.imgur.com/ez3U6NV.png'),
    Network(id=4330, name='Paramount+', logo='https://i.imgur.com/dmUjWmU.png'),
    Network(id=3353, name='Peacock', logo='https://imgur.com/1JXFkSM.png'),
    Network(id=504, name='TVN', logo='https://i.imgur.com/yA8TJ4o.png'),
    Network(id=483, name='TVP1', logo='https://i.imgur.com/as4ipbu.png'),
    Network(id=466, name='TVP2', logo='https://i.imgur.com/qj1Ta1Q.png'),
    Network(id=315, name='Polsat', logo='https://i.imgur.com/knnmJG5.png'),
)


#: The fields of an advanced search in their order (in a group: its rows).
FIELDS: tuple[DiscoverField, ...] = (
    DiscoverField(key='with_text_query', label=L(30595, 'Text'), group='what'),
    DiscoverField(key='with_genres', label=L(32011, 'Genres'), group='what', source='genres', exclude='without_genres'),
    DiscoverField(key='with_keywords', label=L(31422, 'Keywords (EN)'), group='what', source='keyword', exclude='without_keywords'),
    DiscoverField(key='with_people', label=L(31382, 'Cast and crew'), group='what', media=('movie',), source='person'),
    DiscoverField(key='primary_release_date', label=L(31383, 'Years'), group='when', media=('movie',), scale=years_scale),
    DiscoverField(key='first_air_date', label=L(31383, 'Years'), group='when', media=('show',), scale=years_scale),
    DiscoverField(key='with_runtime', label=L(31384, 'Runtime'), group='when', scale=runtime_scale),
    DiscoverField(key='with_status', label=L(31385, 'Status'), group='when', media=('show',), source='status'),
    DiscoverField(key='with_type', label=L(31386, 'Type'), group='when', media=('show',), source='type'),
    DiscoverField(key='with_origin_country', label=L(31387, 'Country'), group='where', source='countries'),
    DiscoverField(key='with_original_language', label=L(31388, 'Original language'), group='where', source='languages'),
    DiscoverField(key='with_watch_providers', label=L(32975, 'VOD services'), group='where', source='providers', join=ANY, region='watch_region'),
    DiscoverField(key='with_networks', label=L(31389, 'Network'), group='where', media=('show',), source='networks'),
    DiscoverField(key='vote_average', label=L(31390, 'Least rating'), group='rating', scale=rating_scale),
    DiscoverField(key='vote_count', label=L(31144, 'Number of votes'), group='rating', scale=votes_scale),
    DiscoverField(key='sort_by', label=L(30901, 'Order'), group='rating', source='sort'),
)


def media_fields(media: DiscoverMedia) -> tuple[DiscoverField, ...]:
    """Return the fields of the media."""
    return tuple(field for field in FIELDS if media in field.media)


#: The characters of a value kept as they are in the text (the separators of several values: `,` all of them, `|` any of them).
SAFE_CHARS: str = ',|'


def filter_pairs(filters: Mapping[str, Any]) -> Iterable[tuple[str, str]]:
    """Return the pairs (the key of TMDB, the value) of the filters: a condition by its comparisons, several values by `|`, no None."""
    for key, value in filters.items():
        if value is None:
            continue
        if isinstance(value, Condition):
            yield from ((f'{key}.{op}', str(val)) for op, val in value.cond)
        elif not isinstance(value, str) and isinstance(value, Sequence):
            yield key, '|'.join(map(str, value))
        else:
            yield key, str(value)


def filters_text(filters: Mapping[str, Any]) -> str:
    """Return the filters as a text (the query of a `tmdb://` address): the pairs of TMDB sorted, the values quoted."""
    return '&'.join(f'{key}={quote(value, safe=SAFE_CHARS)}' for key, value in sorted(filter_pairs(filters)))


def filters_from_text(text: str) -> DiscoveryFilters:
    """Return the filters of a text (`filters_text()`, the query of a `tmdb://` address; the comparisons `<=`, `>=` too)."""
    return Condition.filters_from_str_expr_list(unquote(expr) for expr in text.split('&') if expr)


def choices(source: ChoiceSource, media: DiscoverMedia) -> dict[str, str]:
    """Return the choices of a source for the media (the value of TMDB: its label) in their order; a found one (keyword, person): none."""
    from ..api.tmdb import tmdb_app
    from . import locales
    if source == 'genres':
        translations = const.indexer_group.genres.translations.get(locales.kodi_locale(), {})
        return {str(it['id']): translations.get(it['id'], it['name']) for it in tmdb_app.genres(media)}
    if source == 'countries':
        names = locales.country_translations()
        found = ((it['iso_3166_1'], names.get(it['iso_3166_1']) or it.get('native_name') or it['english_name']) for it in tmdb_app.configuration('countries'))
        return dict(sorted(found, key=lambda pair: pair[1].lower()))
    if source == 'languages':
        names = locales.language_translations()
        found = ((it['iso_639_1'], names.get(it['iso_639_1']) or it['english_name']) for it in tmdb_app.configuration('languages'))
        return dict(sorted(found, key=lambda pair: pair[1].lower()))
    if source == 'providers':
        return {str(it.id): it.name for it in tmdb_app.providers(media, region=const.indexer.region)}
    if source == 'networks':
        return {str(it.id): it.name for it in sorted(NETWORKS, key=lambda network: network.name.lower())}
    if source == 'status':
        return {it.value: it.label for it in TV_STATUSES}
    if source == 'type':
        return {it.value: it.label for it in TV_TYPES}
    if source == 'sort':
        from .config.choices import sort_options
        orders = const.indexer.movies.discover_sort_by if media == 'movie' else const.indexer.tvshows.discover_sort_by
        return {str(option.value): str(option.label) for option in sort_options(orders)}
    return {}


#: The parts of a short description of an advanced search (`describe()`): their separator.
DESCRIBE_SEPARATOR: str = ' · '
#: The fields not in a short description (the text is the query of the entry, the order and the votes say nothing of the media).
NOT_DESCRIBED: frozenset[str] = frozenset({'with_text_query', 'sort_by', 'vote_count'})


def describe(media: DiscoverMedia, filters: Mapping[str, Any], names: Mapping[str, str] | None = None, *,
             memo: dict[str, dict[str, str]] | None = None) -> str:
    """
    Return a short description of the filters of an advanced search, e.g. "Comedy · 1990–1999 · ≤ 100 min" (the names of the found
    choices: `names`, the ID: its name; the excluded ones after "−"); `memo`: the choices read once for many descriptions (a folder).
    """
    names = names or {}
    memo = {} if memo is None else memo

    def labels_of(source: ChoiceSource) -> dict[str, str]:
        """Return the choices of the source (read once)."""
        if source not in memo:
            memo[source] = choices(source, media)
        return memo[source]

    parts: list[str] = []
    for field in media_fields(media):
        if field.key in NOT_DESCRIBED:
            continue
        value = field.read(filters)
        kind = field.kind
        if kind == 'range' and field.scale is not None:
            if value != (NO_LIMIT, NO_LIMIT):
                scale = field.scale()
                parts.append(scale.range_text(*scale.range_positions(*value), values=value))  # a typed end off the steps: its number
        elif kind == 'minimum' and field.scale is not None:
            if value != NO_LIMIT:
                parts.append(f'{field.label} ≥ {field.scale().value_text(value)}')
        elif isinstance(value, Chosen):
            if not value.with_ids and not value.without_ids:
                continue
            labels = labels_of(field.source) if kind != 'lookup' else {}
            join = ', ' if value.every else ' / '
            text = join.join(labels.get(code) or names.get(code) or code for code in value.with_ids)
            if value.without_ids:
                text = ' '.join(filter(None, (text, *(f'−{labels.get(code) or names.get(code) or code}' for code in value.without_ids))))
            parts.append(text)
        elif value:
            parts.append(labels_of(field.source).get(value, value) if field.source else value)
    return DESCRIBE_SEPARATOR.join(parts)


def discover_url(media: DiscoverMedia, filters: Mapping[str, Any]) -> str:
    """Return the address of a discovery of the media with the filters (all of them: `OwnList.query_tmdb()` adds no defaults)."""
    return f'tmdb://{media}?{filters_text(filters)}'
