"""
User configuration of FanFilm: `config.json` in the add-on profile, the choices made in FF windows.

Values are addressed by JSON Pointer (`/sources/addons/<add-on ID>/active`, RFC 6901: `~1` is `/`, `~0` is `~`), so
keys with dots (add-on IDs) are plain keys. Not the internal policies (`const`) nor the Kodi settings (`settings.xml`).
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Callable, Mapping, TYPE_CHECKING
from .store import (LOCK_WAIT, MIGRATION_READS, ConfigBlock, ConfigStore, FileStat, escape_key, file_lock, file_stat, pointer_keys, pointer_value,
                    write_json_atomic)  # noqa: F401
from .migrations import (CONFIG_VERSION, MIGRATIONS, clean_legacy_settings, legacy_settings_pending, migrate, migrate_data, reset_config,
                         restore_legacy_settings)  # noqa: F401
from ..logs import reload_log_options
if TYPE_CHECKING:
    from .blocks import Card
    from .options import AccountSettings, Downloads, General, Library, Maintenance, Media, SourceSettings, Web

    class SourcesNode:
        """The branch of the sources: its card of settings."""

        #: The settings of the sources.
        settings: SourceSettings


#: No default of a read: of a declared setting its value of its card (`Config.get()`).
DECLARED: Any = object()


class ConfigNode:
    """A branch of the configuration over the cards of settings (`config.sources`): its cards are its attributes (`config.sources.settings`)."""

    def __init__(self, store: Config, pointer: str) -> None:
        """The branch of a configuration at the pointer."""
        #: The configuration.
        self._store: Config = store
        #: The pointer of the branch.
        self._pointer: str = pointer

    def __getattr__(self, name: str) -> Any:
        """Return the card of settings or the branch over more of them at the name under the branch."""
        if name.startswith('_'):
            raise AttributeError(name)
        return self._store.branch(f'{self._pointer}/{name}')


class Config(ConfigStore):
    """
    The user configuration of FanFilm (`config.json`). Its settings are declared in the cards of settings (`lib.ff.config.options`) and read
    by them, with their declared defaults:

    - `config.media.language`, `config.sources.settings.search_timeout` - a card is an attribute at its root, a setting is its field
      (typed: the annotations of the card); `config.media.language = 'pl-PL'` writes it;
    - `config.media.get('language')` - by a key not known before (or no name of Python);
    - `config('/media/language')`, `config.get('/media/language')` - by its pointer; with a default given: the stored value or that default,
      as of any other value of the file.
    """

    if TYPE_CHECKING:
        general: General
        media: Media
        sources: SourcesNode
        maintenance: Maintenance
        account_settings: AccountSettings
        library: Library
        downloads: Downloads
        web: Web

    def __init__(self, path: Callable[[], Path], **kwargs: Any) -> None:
        """The configuration of the file at the path (`ConfigStore`): no card made yet."""
        super().__init__(path, **kwargs)
        #: The cards of settings by their roots (made at the first use: the declaration is imported then).
        self._cards: dict[str, Card] | None = None
        #: The language of the information of what the cards made of their declarations last (`fresh_cards()`).
        self._cards_stamp: Any = None

    def cards(self) -> dict[str, Card]:
        """Return the cards of settings of the configuration by their roots."""
        if self._cards is None:
            from .options import CARDS
            self._cards = {card.ROOT: card(self) for card in CARDS}
        return self._cards

    def fresh_cards(self) -> None:
        """
        Forget what the cards made of their declarations (`Card.reset()`: the options and the texts made of other data) if the language
        of the information changed since (a text names it). A window of the settings calls it before it shows them; the Kodi language is
        followed by the cards themselves (`Card.texts()`).
        """
        from .blocks import Card
        from .options import Media
        # ponytail: a reload of `const` (its orders, its roles) is not seen here; a stamp of `const` if its reload ever counts on it
        stamp = self.get(Media.pointer(Media.language.key), None)
        if stamp != self._cards_stamp:
            self._cards_stamp = stamp
            Card.reset()

    def card(self, root: str) -> Card | None:
        """Return the card of settings at the root, None: none there."""
        return self.cards().get(root)

    def branch(self, pointer: str) -> Any:
        """Return the card of settings at the pointer or the branch over more of them (`ConfigNode`); `AttributeError`: none of them there."""
        cards = self.cards()
        if (card := cards.get(pointer)) is not None:
            return card
        if any(root.startswith(f'{pointer}/') for root in cards):
            return ConfigNode(self, pointer)
        raise AttributeError(f'no card of settings at {pointer!r}')

    def __getattr__(self, name: str) -> Any:
        """Return the card of settings (or the branch over more of them) at the name: `config.media`, `config.sources.settings`."""
        if name.startswith('_'):
            raise AttributeError(name)
        return self.branch(f'/{name}')

    def get(self, pointer: str, default: Any = DECLARED) -> Any:
        """
        Return a copy of the value at the pointer. No default given: of a declared setting its value of its card (its declared default if
        not stored), else None; a default given: the stored value or that default.
        """
        if default is not DECLARED:
            return super().get(pointer, default)
        root, _, key = pointer.rpartition('/')
        if (card := self.card(root)) is not None and (key := pointer_keys(f'/{key}')[0]) in card.settings():
            return card.get(key)
        return super().get(pointer)

    def __call__(self, pointer: str, default: Any = DECLARED) -> Any:
        """Return the value at the pointer (`get()`): `config('/media/language')`."""
        return self.get(pointer, default)

    def eval(self, expression: str | bool | None, *, names: Mapping[str, Any] | None = None) -> Any:
        """
        Return the value of an expression (`lib.ff.expr`: the names of every FF expression - `const`, `settings`, `config`, the units…): a
        bare name is a card of settings (`media.language == "pl-PL"`), `names` are the names of the caller before the others; a bool or
        None is the value as it is, a wrong expression is logged and raised.
        """
        from ..expr import config_eval
        return config_eval(expression, names)


def _config_path() -> Path:
    """Return the path of `config.json` (the add-on profile)."""
    from ..control import dataPath
    return Path(dataPath) / 'config.json'


#: The user configuration of FanFilm.
config: Config = Config(_config_path)
config.changed.append(reload_log_options)  # the switches of the developer logs are in it
