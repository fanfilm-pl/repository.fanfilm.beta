"""
A configuration file of FanFilm (`ConfigStore`: `config.json` and the other JSON files of the profile): read again when it changes,
changed under its lock among the interpreters, written atomically. Values are addressed by JSON Pointer.
"""

from __future__ import annotations
import json
import os
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from threading import RLock, local
from typing import Any, Callable, Generator, Mapping
from typing_extensions import TypeAlias
from attrs import define
from ...sdk.tricks import write_atomic
from ..logs import fflog, fflog_exc
from ..tricks import MISSING

#: How many times a file is read for a migration nobody else finished meanwhile (`ConfigStore._read()`).
MIGRATION_READS: int = 3

#: How long another interpreter (process) is waited for (seconds): the lock of a file it holds (then the file is used without
#: the lock), its migration (`lib.ff.account_migration.MigrationLock`).
LOCK_WAIT: float = 30

#: Stat of a file (mtime, size), None if it does not exist.
FileStat: TypeAlias = 'tuple[float, int] | None'


def file_stat(path: Path) -> FileStat:
    """Return the stat (mtime, size) of the file, None if it does not exist."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    return st.st_mtime, st.st_size


def write_json_atomic(path: Path, data: Any) -> FileStat:
    """
    Write JSON atomically (`write_atomic()`: the service and the plugin, two interpreters of one Kodi process, write the
    same file at once). Return its stat, None on error (logged).
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        write_atomic(path, json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8'))
        return file_stat(path)
    except OSError:
        fflog_exc(f'[CONFIG] can not write {path}')
        return None


@contextmanager
def file_lock(path: Path) -> Generator[bool, None, None]:
    """
    Hold the lock of the file among the interpreters of FanFilm (threads of the Kodi process, each with its own modules) and
    processes: a write transaction of SQLite on `<file name>.lock`, as the locks of the databases. Its connection holds it: closed
    at the end of the block, gone with a killed process (no stale lock, nobody releases the lock of another one).

    Yield False if it is not taken (logged): a wait over `LOCK_WAIT`, a new lock file in a read-only folder, a lock file which is not
    a database - the block runs without the lock then.
    """
    import sqlite3
    con: sqlite3.Connection | None = None
    locked = False
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(str(path.with_name(f'{path.name}.lock')), timeout=LOCK_WAIT, isolation_level=None)
        con.execute('PRAGMA journal_mode=MEMORY')  # no journal file made and removed at every lock
        con.execute('BEGIN IMMEDIATE')
        locked = True
    except (sqlite3.Error, OSError) as exc:
        fflog.warning(f'[CONFIG] no lock of {path} ({exc!r}), used without it')
    try:
        yield locked
    finally:
        if con is not None:
            try:
                con.close()
            except sqlite3.Error:
                fflog_exc()


def escape_key(key: str) -> str:
    """Return the key escaped for a JSON Pointer (`~0`, `~1`)."""
    return key.replace('~', '~0').replace('/', '~1')


def pointer_keys(pointer: str) -> list[str]:
    """Return the keys of a JSON Pointer (`/a/b~1c` -> `['a', 'b/c']`; '' -> the whole document)."""
    if not pointer:
        return []
    if not pointer.startswith('/'):
        raise ValueError(f'JSON Pointer must start with "/": {pointer!r}')
    return [key.replace('~1', '/').replace('~0', '~') for key in pointer[1:].split('/')]


def remove_keys(data: dict[str, Any], keys: list[str]) -> bool:
    """Remove the value at the keys (the objects left empty too) from the data in place. Return True if it was there."""
    nodes = [data]
    for key in keys[:-1]:
        if not isinstance(child := nodes[-1].get(key), dict):
            return False
        nodes.append(child)
    if keys[-1] not in nodes[-1]:
        return False
    del nodes[-1][keys[-1]]
    for node, key in zip(reversed(nodes[:-1]), reversed(keys[:-1])):
        if node[key]:
            break
        del node[key]
    return True


def pointer_value(data: Any, pointer: str, default: Any = None) -> Any:
    """Return a copy of the value at the pointer in the data, `default` if there is none."""
    node = data
    for key in pointer_keys(pointer):
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return deepcopy(node)


def migrate_config(data: dict[str, Any]) -> bool:
    """Migrate the data of `config.json` (in place) to its current version (`lib.ff.config.migrations`). Return True if they changed."""
    from .migrations import migrate
    return migrate(data)


@define(kw_only=True)
class ConfigBlock:
    """
    A block of changes of `ConfigStore.batch()`: the fresh data of the file (read under its lock), changed in place. A value
    written from what the file has (a list with an item changed, an entry only if it is still there) is read here (`get()`),
    not from the store (it has the file before the block).
    """

    #: The path of the file.
    path: Path
    #: The data of the file read at the start of the block (a copy, migrated), changed by the block.
    data: dict[str, Any]
    #: False if the file is broken (nothing is changed nor written).
    valid: bool
    #: True if the block changed the data.
    changed: bool = False
    #: The result of the block: the changes written (or none to write), in a nested block the changes taken (written by the outer one).
    ok: bool = True

    def get(self, pointer: str, default: Any = None) -> Any:
        """Return a copy of the value at the pointer in the fresh file with the changes of the block, `default` if there is none."""
        return pointer_value(self.data, pointer, default)


class ConfigStore:
    """
    The configuration file: read again when it changes (another interpreter or process, a hand edit), a change is written to
    the fresh file (a change of another one is kept). A broken file is never overwritten (a change fails, logged). The data of
    an older version are migrated (`migrate`: the migrations of `config.json` by default).

    Every store of the file (one in each interpreter) reads a changed file (with its migration) and changes it (read - change -
    write: `set()`, `remove()`, `batch()`) under the lock of the file (`file_lock()`), so a change is not lost to a change of
    another interpreter made at the same time and a file is migrated by one of them. A value read out of a block and written
    later is not guarded (the last one wins): change such data in a `batch()`.

    The order of the locks: `MigrationLock` -> `source_filters.json` -> `config.json`, never the other way; nothing waits for
    another interpreter under the lock of a file (a call of the service, a `MigrationLock`).
    """

    def __init__(self, path: Callable[[], Path], *, migrate: Callable[[dict[str, Any]], bool] = migrate_config) -> None:
        #: Returns the path of the file (at call time).
        self.path: Callable[[], Path] = path
        #: Migrates the data to the current version in place (True: changed).
        self.migrate: Callable[[dict[str, Any]], bool] = migrate
        #: The data read last (not changed in place: a change builds new data).
        self._data: dict[str, Any] = {}
        #: Stat of the file the data were read from.
        self._stat: FileStat = None
        #: True if the file was read.
        self._loaded: bool = False
        #: False if the file read last is broken (its data are empty then).
        self._valid: bool = True
        #: True if the data migrated at the last read are not in the file (its write failed: the file has the older version).
        self._unwritten: bool = False
        #: Guards reading and writing.
        self._lock: RLock = RLock()
        #: The changes of the running block (`batch()`, its thread holds the lock), None out of a block.
        self._changes: ConfigBlock | None = None
        #: The section of the file of the thread holding `_lock` (`_file_section()`): True - under the lock of the file, False - the
        #: lock not taken (logged once), None - out of a section.
        self._file_locked: bool | None = None
        #: Called when the data change: read again (another process, a hand edit) or written (the caches of values read from them).
        self.changed: list[Callable[[], None]] = []
        #: The pointers read by the thread in its block of `reads()` (`pointers`: a set, none out of a block).
        self._reads: local = local()

    def _notify(self) -> None:
        """Tell the data changed (`changed`)."""
        for call in self.changed:
            call()

    @contextmanager
    def _file_section(self, path: Path) -> Generator[None, None, None]:
        """
        Run the block (a fresh read, a change written; its thread holds `_lock`) under the lock of the file among the interpreters.
        A nested one (a read in a block of changes, a change made by a migration) is in the section of the outer one: the lock is
        taken (or failed and logged) once.
        """
        if self._file_locked is not None:
            yield
            return
        # ponytail: an interpreter hung in a block (not stopped by Kodi) holds the lock for the session, the others wait `LOCK_WAIT`
        # each time and go without it; the wait does not see Kodi closing. A watchdog of the holder if it ever happens.
        self._file_locked = False  # in the section from now: the log of a lock not taken may read the configuration
        try:
            with file_lock(path) as locked:
                self._file_locked = locked
                yield
        finally:
            self._file_locked = None

    def _read(self, path: Path) -> tuple[dict[str, Any], FileStat, bool]:
        """
        Return the data of the file, its stat and False if it is broken (the data empty then). The data of an older version are migrated
        and written; no file is the first version (the old settings moved in by the migration, a new file written).

        A migration reads the old user settings, removed once every move of them is finished (`clean_legacy_settings()`: it needs this
        file written by a process which finished first). If the file changed since it was read: the result is dropped, the file read again
        (it keeps changing: not used now, as a broken one - read again at the next use).
        """
        data: dict[str, Any] = {}
        stat: FileStat = None
        for _ in range(MIGRATION_READS):
            self._unwritten = False
            stat = file_stat(path)
            data = {}
            if stat is not None:
                try:
                    with open(path, encoding='utf-8') as f:
                        data = json.load(f)
                except (OSError, ValueError) as exc:
                    fflog.warning(f'[CONFIG] broken {path} ({exc}), not used')
                    return {}, stat, False
                if not isinstance(data, dict):
                    fflog.warning(f'[CONFIG] broken {path} (not an object), not used')
                    return {}, stat, False
            if not self.migrate(data):
                return data, stat, True
            # a hand edit meanwhile (the stores of the interpreters wait for the lock of the file)
            if file_stat(path) == stat:
                break
        else:
            fflog.warning(f'[CONFIG] {path} keeps changing during its migration, not used now')
            return {}, stat, False
        # written before the log: the first log of an interpreter reads the configuration (`logs._read_show_fflog()`), no second migration
        written = write_json_atomic(path, data)  # not written (logged): migrated again next time
        self._unwritten = written is None
        stat = written or stat
        fflog(f'[CONFIG] {path} migrated to version {data.get("version")}')
        return data, stat, True

    def data(self) -> dict[str, Any]:
        """Return the whole configuration (do not change it)."""
        path = self.path()
        if not self._loaded or file_stat(path) != self._stat:
            with self._lock:
                loaded = self._loaded
                with self._file_section(path):
                    self._data, self._stat, self._valid = self._read(path)
                self._loaded = True
            if loaded:  # the first read: nothing read from them yet
                self._notify()
        return self._data

    @property
    def valid(self) -> bool:
        """Return False if the file is broken (nothing in it is used, it is never overwritten)."""
        self.data()
        return self._valid

    @property
    def stored(self) -> bool:
        """Return True if the data read are the ones of the file: not broken, its migration written (not only done in the memory)."""
        self.data()
        return self._valid and not self._unwritten

    def get(self, pointer: str, default: Any = None) -> Any:
        """Return a copy of the value at the pointer, `default` if there is none."""
        if (pointers := getattr(self._reads, 'pointers', None)) is not None:
            pointers.add(pointer)
        return pointer_value(self.data(), pointer, default)

    @contextmanager
    def reads(self) -> Generator[set[str], None, None]:
        """
        Collect the pointers this thread reads (`get()`) in the block: what a result made there depends on in the file. A read of
        the whole data (`data()`) has no pointer and is not collected.
        """
        pointers: set[str] = set()
        outer: set[str] | None = getattr(self._reads, 'pointers', None)
        self._reads.pointers = pointers
        try:
            yield pointers
        finally:
            self._reads.pointers = outer
            if outer is not None:
                outer.update(pointers)

    def get_bool(self, pointer: str, default: bool) -> bool:
        """Return the switch at the pointer, `default` if there is none (or it is not a bool)."""
        value = self.get(pointer, None)
        return value if isinstance(value, bool) else default

    def set(self, pointer: str, value: Any, *, default: Any = MISSING) -> bool:
        """
        Set the value at the pointer (missing objects made) in the fresh file and write it, remove it if it is the `default`
        (only the changes are stored: a changed default reaches everyone who did not change it). Return True if written (in a
        block of `batch()`: taken, written at its end).
        """
        if default is not MISSING and value == default:
            return self.remove(pointer)
        keys = pointer_keys(pointer)
        if not keys:
            raise ValueError('The whole configuration can not be set')
        with self._batch() as changes:
            if changes.valid:
                node = changes.data
                for key in keys[:-1]:
                    if not isinstance(child := node.get(key), dict):
                        child = node[key] = {}
                    node = child
                node[keys[-1]] = deepcopy(value)
                changes.changed = True
        return changes.ok

    def remove(self, *pointers: str) -> bool:
        """
        Remove the values at the pointers (the objects left empty too) in the fresh file and write it once.
        Return True if written or none of them there (in a block of `batch()`: taken, written at its end).
        """
        paths = [pointer_keys(pointer) for pointer in pointers]
        if not all(paths):
            raise ValueError('The whole configuration can not be removed')
        with self._batch() as changes:
            if changes.valid and any([remove_keys(changes.data, keys) for keys in paths]):  # a list: every pointer removed
                changes.changed = True
        return changes.ok

    @contextmanager
    def batch(self) -> Generator[ConfigBlock, None, None]:
        """
        Write the changes of the block (`set()`, `remove()`: one user action) once at its end, to the fresh file read at its start;
        an exception in the block writes nothing (the whole action or none of it), a nested block joins the outer one. The other
        threads wait for the end of the block; reads of the store in it (`get()`, `data()`) see the file before it, the block
        returned has the fresh file (`ConfigBlock.get()`) and, after it, if the changes are written (`ConfigBlock.ok`).
        """
        with self._batch() as block:
            yield block

    def replace(self, data: Mapping[str, Any], *, keep: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]] | None = None) -> bool:
        """
        Replace the whole configuration with the data (a restored backup; migrated here) under the lock of the file, also a broken
        file (the way to repair it: the only write over one). `keep(data, current)` returns the data to write with what stays of
        the current configuration (empty: a broken one; no file: the old settings moved in by its migration). Return True if written.
        """
        path = self.path()
        with self._lock:
            if self._changes is not None:
                raise RuntimeError('The whole configuration can not be replaced in a block of changes')
            with self._file_section(path):
                new = deepcopy(dict(data))
                self.migrate(new)
                if keep is not None:
                    new = keep(new, self._read(path)[0])
                written = self._write(path, new)
            if written:  # out of the lock of the file
                self._notify()
        return written

    @contextmanager
    def _batch(self) -> Generator[ConfigBlock, None, None]:
        """Return the changes of the block (a nested one: of the outer block), written at the end of the outermost one (`batch()`)."""
        with self._lock:
            if (outer := self._changes) is not None:
                yield outer
                return
            path = self.path()
            written = False
            with self._file_section(path):
                data, _, valid = self._read(path)
                # a migration not written (the write failed): written by the block, even if it changes nothing
                changes = self._changes = ConfigBlock(path=path, data=deepcopy(data), valid=valid, changed=self._unwritten, ok=valid)
                try:
                    yield changes
                finally:
                    self._changes = None
                if changes.valid and changes.changed:
                    changes.ok = written = self._write(path, changes.data)
            if written:  # out of the lock of the file: the work of this interpreter only
                self._notify()

    def _write(self, path: Path, data: dict[str, Any]) -> bool:
        """Write the changed data (under the locks) and keep them. Return True if written (the caller tells it then: `_notify()`)."""
        if (stat := write_json_atomic(path, data)) is None:
            return False
        self._data, self._stat, self._loaded, self._valid, self._unwritten = data, stat, True, True, False
        return True
