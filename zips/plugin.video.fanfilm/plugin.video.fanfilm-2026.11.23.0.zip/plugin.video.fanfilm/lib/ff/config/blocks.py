"""
The settings declared once: the vocabulary of a setting (`ProviderSetting`, its options, its old settings of `settings.xml`, its entry of
a catalog - of the cards of the configuration and of the native providers) and a card of settings (`Card`): a class with its settings as
typed fields in their groups, the values in the configuration (`config.json`) under its root, only the changed ones (a default: removed).
The cards are declared in `lib.ff.config.options` and read by the configuration (`config.<card>.<key>`).
"""

from __future__ import annotations
import re
from copy import deepcopy
from typing import Any, Callable, ClassVar, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, NotRequired, TypeAlias, TypedDict
from attrs import evolve, field, frozen
from .store import escape_key, pointer_keys
from ..tricks import MISSING
if TYPE_CHECKING:
    from . import Config

#: The kind of a setting (its editor): a switch, a text, a password (never shown, typed openly unless `const.dialog.config.hide_passwords`),
#: a number (`minimum` .. `maximum`), one of the `options`, a color (AARRGGBB), a file path, a folder (a path of Kodi), an action (`action` runs),
#: a state (read only, written by the provider).
SettingKind: TypeAlias = Literal['bool', 'text', 'password', 'int', 'range', 'scale', 'select', 'color', 'path', 'folder', 'action', 'state']

#: A text of a declaration of a setting: the text, or a function of no argument returning it (called when the text is shown; a lazy
#: label `LL()` is one: the text in the Kodi language of then).
DeclaredText: TypeAlias = 'str | Callable[[], str]'
#: The options of a declaration of a setting: the options, or a function of no argument returning them (called when they are used).
DeclaredOptions: TypeAlias = 'Sequence[SettingOption] | Callable[[], Sequence[SettingOption]]'

#: The ID of the old setting of `settings.xml` of a setting of none (`ProviderSetting.legacy`: of a native provider).
NO_LEGACY: str = '{name}.{key}'
#: A colour of a setting: AARRGGBB (hex), '' the default one.
COLOR_VALUE: re.Pattern[str] = re.compile(r'(?:[0-9A-Fa-f]{8})?')


@frozen(kw_only=True)
class LegacyValue:
    """The value of a setting of the old settings of `settings.xml` (`ProviderSetting.legacy_value`): all of them moved."""

    #: The IDs of the old settings.
    ids: tuple[str, ...]
    #: The value of their texts (in the order of `ids`, '' - none), MISSING - nothing to move. A function of a module or a record (the declaration is a
    #: template var of its page, kept in the cache of the window), out of the representation (the address of a function).
    value: Callable[..., Any] = field(repr=False)


@frozen(kw_only=True)
class SettingOption:
    """An option of a `select` setting."""

    #: The stored value (None: nothing stored, the option of no value of its own).
    value: str | int | None
    #: Its label.
    label: DeclaredText


@frozen(kw_only=True)
class ProviderSetting:
    """
    A setting of a provider (or of a node: a provider which is a group) or of a card of settings, stored in its configuration under `key`.
    Of a card (`Setting`) the label, the help, the default, the options and the scale may be a function of no argument: called when used
    (a default of `const`, the options of what they choose - nothing of them imported by the declaration).
    """

    #: The key in the configuration of the provider (`username`, `color.identify2`).
    key: str
    #: The kind (its editor).
    kind: SettingKind
    #: The label.
    label: DeclaredText
    #: The default value.
    default: Any = ''
    #: The help of the row.
    help: DeclaredText = ''
    #: The options of a `select` setting.
    options: DeclaredOptions = ()
    #: The range of an `int` setting.
    minimum: int | None = None
    maximum: int | None = None
    #: The scale of a `range` setting (`lib.ff.gui.scale.Scale`, its value the pair of its knobs) or a `scale` one (one knob, its value a number).
    scale: Any = None
    #: The Kodi builtin of the row (`RunPlugin(...)`): OK runs it instead of the editor of the kind.
    action: str = ''
    #: The row is usable if every key has one of its values (`{'source_type': (1, 2)}`), empty: always; else a row of a provider is hidden,
    #: a row of a card grayed (the reason in its help: `Card.reason()`).
    when: Mapping[str, Sequence[Any]] = field(factory=dict)
    #: The row of a card is shown if every key has one of its values (as `when`), empty: always; else hidden - the rows under it take its
    #: place (`Card.row_shown()`). Only of the cards of settings, never of a stored catalog.
    shown_when: Mapping[str, Sequence[Any]] = field(factory=dict)
    #: A switch which blocks: off (red) the sources of it are hidden, on (gray) it does not matter.
    negative: bool = False
    #: The row is usable if one of these Kodi add-ons is enabled (else grayed), empty: always.
    requires: tuple[str, ...] = ()
    #: The setting ID of the old `settings.xml` (`{name}`: the provider name, `{key}`: the key), the migration reads it.
    legacy: str = NO_LEGACY
    #: The value of the old settings of `settings.xml` of a setting made of more of them or of an old value of another meaning (an index),
    #: None: the old setting `legacy` by the kind (`old_value()`). Only of the cards of settings, never of a stored catalog.
    legacy_value: LegacyValue | None = None
    #: Its value tunes the log format whatever its key (e.g. a key of an API, an URL with a token); a password always (its kind).
    tune: bool = False
    #: The setting is the one of another card in a second place: the pointer of its value (`/library/add_downloads`, the root of that card and
    #: its key); the value, its write and the reason it is grayed come of that card, its own `when` too. Only of the cards of settings,
    #: never of a stored catalog.
    link: str = ''


class CatalogSetting(TypedDict):
    """A setting in the catalog (the fields of `ProviderSetting`, an optional one only if set)."""

    #: The key in the configuration of the provider.
    key: str
    #: The kind (its editor).
    kind: SettingKind
    #: The label (the Kodi language of the catalog).
    label: str
    #: The default value.
    default: Any
    #: The help of the row.
    help: NotRequired[str]
    #: The options of a `select` setting: `{"value": ..., "label": ...}`.
    options: NotRequired[list[dict[str, Any]]]
    #: The range of an `int` setting.
    minimum: NotRequired[int]
    maximum: NotRequired[int]
    #: The scale of a `range` setting.
    scale: NotRequired[Any]
    #: The Kodi builtin of the row.
    action: NotRequired[str]
    #: The row is usable if every key has one of its values.
    when: NotRequired[dict[str, list[Any]]]
    #: The row of a card is shown if every key has one of its values (`ProviderSetting.shown_when`).
    shown_when: NotRequired[dict[str, list[Any]]]
    #: A switch which blocks (`ProviderSetting.negative`).
    negative: NotRequired[bool]
    #: The row is usable if one of these Kodi add-ons is enabled.
    requires: NotRequired[list[str]]
    #: The setting ID of the old `settings.xml` (`{name}`, `{key}`).
    legacy: str
    #: The value of the old settings (`ProviderSetting.legacy_value`).
    legacy_value: NotRequired[LegacyValue]
    #: Its value tunes the log format whatever its key (`ProviderSetting.tune`, a password).
    tune: NotRequired[bool]
    #: The pointer of the value of the setting of another card it is (`ProviderSetting.link`).
    link: NotRequired[str]


def now(value: Any) -> Any:
    """Return a value of a declaration: of a function - what it returns now."""
    return value() if callable(value) else value


def catalog_setting(setting: ProviderSetting) -> CatalogSetting:
    """Return the catalog entry of a setting (only what is set; a value of a function: what it returns now)."""
    entry: CatalogSetting = {'key': setting.key, 'kind': setting.kind, 'label': now(setting.label), 'default': now(setting.default),
                             'legacy': setting.legacy}
    if setting.help:
        entry['help'] = now(setting.help)
    if setting.options:
        entry['options'] = [{'value': opt.value, 'label': now(opt.label)} for opt in now(setting.options)]
    if setting.minimum is not None:
        entry['minimum'] = setting.minimum
    if setting.maximum is not None:
        entry['maximum'] = setting.maximum
    if setting.scale is not None:
        entry['scale'] = now(setting.scale)
    if setting.action:
        entry['action'] = setting.action
    if setting.negative:
        entry['negative'] = True
    if setting.when:
        entry['when'] = {key: list(values) for key, values in setting.when.items()}
    if setting.shown_when:
        entry['shown_when'] = {key: list(values) for key, values in setting.shown_when.items()}
    if setting.requires:
        entry['requires'] = list(setting.requires)
    if setting.legacy_value is not None:
        entry['legacy_value'] = setting.legacy_value
    if setting.tune or setting.kind == 'password':
        entry['tune'] = True
    if setting.link:
        entry['link'] = setting.link
    return entry


def accept(setting: CatalogSetting, value: Any) -> Any:
    """
    Return a value of a setting checked by its declaration (its kind, options, range, scale), ValueError (why) if it is none of them: a value
    from outside (the web page) before it is written; an action or a state is never written so. A scale of any whole number (`Scale.typed`):
    a number typed in too, as it is (`Scale.entered()`: kept between the edges, a special value equal to it), as the number dialog of a slider.
    """
    kind = setting['kind']
    if kind == 'bool':
        if not isinstance(value, bool):
            raise ValueError('expect true or false')
    elif kind in ('text', 'password', 'path', 'folder'):
        if not isinstance(value, str):
            raise ValueError('expect a text')
    elif kind == 'color':
        if not isinstance(value, str) or not COLOR_VALUE.fullmatch(value):
            raise ValueError('expect a colour AARRGGBB')
    elif kind == 'int':
        low, high = setting.get('minimum'), setting.get('maximum')
        if not isinstance(value, int) or isinstance(value, bool) or (low is not None and value < low) or (high is not None and value > high):
            raise ValueError(f'expect a number {low}..{high}')
    elif kind == 'select':
        if not any(option['value'] == value and type(option['value']) is type(value) for option in setting.get('options', ())):
            raise ValueError('expect one of the options')
    elif kind == 'scale' and (scale := setting.get('scale')) is not None and scale.typed and isinstance(value, int) and not isinstance(value, bool):
        if value < 0 and scale.entered(value) != value:  # a special value of a negative number: as it is
            raise ValueError('expect a whole number not below 0')
        value = scale.entered(value)
    elif kind in ('scale', 'range'):
        scale = setting.get('scale')
        values = [scale.value_at(pos) for pos in range(scale.last + 1)] if scale is not None else []
        knobs = (value if isinstance(value, list) and len(value) == 2 else None) if kind == 'range' else [value]
        if knobs is None or any(isinstance(knob, bool) or knob not in values for knob in knobs):
            raise ValueError('expect a value of the scale')
        if kind == 'range':  # each knob in its positions (`Scale.knob_positions()`), the maximum one from the minimum one
            low = values.index(knobs[0])
            high = next((pos for pos in scale.knob_positions('max', low) if values[pos] == knobs[1]), None)
            if low not in scale.knob_positions('min') or high is None:
                raise ValueError('expect the knobs of the range in their positions')
    else:
        raise ValueError(f'a setting of the kind {kind} is not written so')
    return value


def value_label(setting: CatalogSetting, value: Any) -> str:
    """Return the label of a value of a setting (an option: its label, yes / no of a switch, else the value)."""
    from ...kolang import L
    if setting['kind'] == 'bool':
        return L(30736, 'Yes') if value else L(30752, 'No')
    return next((option['label'] for option in setting.get('options', ()) if option['value'] == value), str(value))


# --- the old settings ---

def old_default_color(value: Any) -> bool:
    """Return True if a color value is the default color of an old FanFilm (`0`, `00000000`; now '', then `00000000` is a color)."""
    return isinstance(value, str) and bool(value) and not value.strip('0')


def old_value(kind: SettingKind, default: Any, raw: str) -> Any:
    """
    Return the value of an old setting (a text of `settings.xml`) by the kind and the default of its setting, MISSING if none (an action,
    empty, the old default color `0` / `00000000`: now '', wrong).
    """
    if kind == 'action' or raw == '' or (kind == 'color' and old_default_color(raw)):
        return MISSING
    if kind == 'bool':
        return raw.strip().lower() == 'true'
    if kind == 'range':  # an old single number: the maximum
        try:
            return [default[0], int(raw)]
        except ValueError:
            return MISSING
    if kind == 'int' or (kind in ('select', 'scale') and isinstance(default, int)):
        try:
            return int(raw)
        except ValueError:
            return MISSING
    return raw


# --- a card of settings ---

@frozen(kw_only=True)
class Setting(ProviderSetting):
    """
    A setting of a card of settings, a field of its class (`setting()`): its key is the name of the field, the field of a card is its value
    (read, written).
    """

    #: The key in the configuration under the root of the card: the name of the field (given: another one, e.g. no name of Python).
    key: str = ''

    def __set_name__(self, owner: type, name: str) -> None:
        """The field of a card: its name is the key (one declared with its key keeps it)."""
        if not self.key:
            object.__setattr__(self, 'key', name)

    def __get__(self, card: Card | None, owner: type | None = None) -> Any:
        """Return the value of the setting of a card, the setting itself of the class."""
        return self if card is None else card.get(self.key)

    def __set__(self, card: Card, value: Any) -> None:
        """Set the setting of a card."""
        card.set(self.key, value)


def setting(**fields: Any) -> Any:
    """Return a setting of a card of settings (`Setting`, its fields) for a typed field of the card: `enabled: bool = setting(kind='bool', …)`."""
    return Setting(**fields)


@frozen(kw_only=True)
class SettingGroup:
    """
    A group of the settings (a frame of their page). In a card: a field before the settings of the group (its key: the name of the field
    without its leading `_` - a group is no value of the card).
    """

    #: The title (in a card: a lazy label, the text of now in the groups of a page).
    label: DeclaredText
    #: The key (the name of its widget).
    key: str = ''
    #: The settings in their order (the entries of their catalog: a page shows them).
    settings: tuple[CatalogSetting, ...] = ()
    #: The column of the page (0 the left one).
    column: int = 0
    #: The page of its card showing the group (`SettingsPage.PAGE` of a page of the configuration window), '': the page of the card. The values
    #: stay in the root of the card whatever page shows them: a group moved to another page needs no migration.
    page: str = ''
    #: A group of the developer tools: shown and working only with them (`lib.ff.maintenance.developer_tools()`), its values kept.
    developer: bool = False
    #: The group is shown if every key has one of its values (as `ProviderSetting.when`), empty: always (`Card.group_shown()`).
    when: Mapping[str, Sequence[Any]] = field(factory=dict)

    @property
    def conditional(self) -> bool:
        """Return True if the group is not always shown (its `when`, the developer tools)."""
        return self.developer or bool(self.when)

    @property
    def rows_conditional(self) -> bool:
        """Return True if a row of the group is not always shown (its `shown_when`): the page sizes its frame."""
        return any(setting.get('shown_when') for setting in self.settings)


@frozen(kw_only=True)
class ConfigRoot:
    """A branch of the configuration (`config.json`): who keeps what in it."""

    #: The pointer of the branch.
    pointer: str
    #: What it is (and the module of its data, of no card of settings).
    note: str


class Card:
    """
    A card of settings: the settings declared as the typed fields of its class (`setting()`) after the fields of their groups
    (`SettingGroup`), in the order of the page; their values in the configuration under the root of the card (only the changed ones).

        class Web(Card, root='/web'):
            _access = SettingGroup(label=<title>)
            enabled: bool = setting(kind='bool', label=<label>, default=True)

    A card of a configuration (`config.web`) reads and writes them: `config.web.enabled`, `config.web.get('enabled')`.
    """

    #: The root of the values in the configuration (a JSON pointer).
    ROOT: ClassVar[str] = ''
    #: The fields of the declaration in their order: a group, then its settings.
    ROWS: ClassVar[tuple[Any, ...]] = ()
    #: What is made of the declaration when needed and kept (`reset()` drops it): the settings by their keys, the groups of a page…
    _made: ClassVar[dict[str, Any]] = {}
    #: The Kodi language of what the cards made of their declarations (`texts()`: another one - made again).
    _language: ClassVar[str] = ''

    def __init_subclass__(cls, root: str = '', **kwargs: Any) -> None:
        """A card declared: its root, its fields in their order (a group named by its field)."""
        super().__init_subclass__(**kwargs)
        cls.ROOT = root
        cls.ROWS = tuple(evolve(row, key=row.key or name.lstrip('_')) if isinstance(row, SettingGroup) else row
                         for name, row in cls.__dict__.items() if isinstance(row, (SettingGroup, Setting)))
        cls._made = {}

    def __init__(self, store: Config) -> None:
        """The card of a configuration."""
        #: The configuration of the values.
        self.store: Config = store

    # --- the declaration ---

    @classmethod
    def extra(cls, group: str) -> tuple[ProviderSetting, ...]:
        """Return the settings of a group which are no fields (made of other data, e.g. of `const`), after its fields; read by `get(key)`."""
        return ()

    @classmethod
    def reset(cls) -> None:
        """
        Forget what was made of the declaration of the card and of the cards of it: the texts, the options and the scales are made again at
        the next use (in the Kodi language, of `const` and the values of now).
        """
        cls._made = {}
        for card in cls.__subclasses__():
            card.reset()

    @classmethod
    def texts(cls) -> dict[str, Any]:
        """
        Return what the card made of its declaration with texts in it (the groups of a page, the catalog), nothing of another Kodi language:
        after a change of it every card forgets what it made (the texts are lazy labels, translated again).
        """
        from ...kolang import L
        # ponytail: by the Kodi language, not by the language epoch of `kolang` (private): what is made while Kodi still loads the strings
        # of a new language (about 2 s) may keep a text of the old one until the next change
        if (language := L.locale) != Card._language:
            Card._language = language
            Card.reset()
        return cls._made

    @classmethod
    def declared(cls) -> tuple[tuple[SettingGroup, tuple[ProviderSetting, ...]], ...]:
        """Return the groups with their settings as declared (the fields, the ones of `extra()`), in the order of the page."""
        if (found := cls._made.get('declared')) is None:
            rows: list[tuple[SettingGroup, list[ProviderSetting]]] = []
            for row in cls.ROWS:
                if isinstance(row, SettingGroup):
                    rows.append((row, []))
                else:
                    rows[-1][1].append(row)
            # ponytail: the settings made of `const` (`extra()`) are the ones of the first use, not again after a reload of `const`
            found = cls._made['declared'] = tuple((group, (*settings, *cls.extra(group.key))) for group, settings in rows)
        return found

    @classmethod
    def settings(cls) -> dict[str, ProviderSetting]:
        """Return the declared settings by their keys."""
        if (found := cls._made.get('settings')) is None:
            found = cls._made['settings'] = {setting.key: setting for _, settings in cls.declared() for setting in settings}
        return found

    @classmethod
    def groups(cls) -> tuple[SettingGroup, ...]:
        """Return the groups of the settings for a page: the entries of their catalog (the texts, the options and the scales made now, once)."""
        made = cls.texts()
        if (found := made.get('groups')) is None:
            found = made['groups'] = tuple(evolve(group, label=now(group.label), settings=tuple(catalog_setting(setting) for setting in settings))
                                           for group, settings in cls.declared())
        return found

    @classmethod
    def catalog(cls) -> dict[str, CatalogSetting]:
        """Return the entries of the catalog of the settings by their keys (`groups()`)."""
        made = cls.texts()
        if (found := made.get('catalog')) is None:
            found = made['catalog'] = {setting['key']: setting for group in cls.groups() for setting in group.settings}
        return found

    @classmethod
    def developer_keys(cls) -> frozenset[str]:
        """Return the keys of the settings of the developer tools (of the groups of them)."""
        if (found := cls._made.get('developer')) is None:
            found = cls._made['developer'] = frozenset(setting.key for group, settings in cls.declared() if group.developer for setting in settings)
        return found

    @classmethod
    def access_keys(cls) -> tuple[str, ...]:
        """Return the keys of the settings which are access data (a key, a password): declared so (`ProviderSetting.tune`, a password) or by their keys."""
        if (found := cls._made.get('access')) is None:
            from ..logs import log
            # ponytail: the keys of access data by `const.debug.log_tune` at the first use, not again after a reload of `const`
            found = cls._made['access'] = tuple(key for key, setting in cls.settings().items()
                                                if setting.tune or setting.kind == 'password' or log.format.tunes(key))
        return found

    @classmethod
    def pointer(cls, key: str) -> str:
        """Return the pointer of the value of the setting in the configuration."""
        return f'{cls.ROOT}/{escape_key(key)}'

    @classmethod
    def pointers(cls) -> tuple[str, ...]:
        """Return the pointers of the values of every setting of the card (what its defaults restored remove)."""
        return tuple(cls.pointer(key) for key in cls.settings())

    @classmethod
    def default(cls, key: str) -> Any:
        """Return the declared default of the setting (of a function: of now), a copy: the caller may change it."""
        return deepcopy(now(cls.settings()[key].default))

    @classmethod
    def option_values(cls, key: str) -> frozenset[Any]:
        """Return the values of the options of a `select` setting (made once: a read of the setting checks its value by them)."""
        values: dict[str, frozenset[Any]] = cls._made.setdefault('values', {})
        if (found := values.get(key)) is None:
            found = values[key] = frozenset(option.value for option in now(cls.settings()[key].options))
        return found

    # --- the values ---

    def _tune_log(self, key: str, value: Any) -> None:
        """Tune the log format by the value of a setting of access data (e.g. a key of an API: `***` in the logs); the others: nothing."""
        if key in self.access_keys():
            from ..logs import log
            log.format.tune(key, value, any_key=True)

    def owner(self, key: str) -> tuple[Card, str]:
        """
        Return the card of the value of the setting and its key there: another card for a setting of it (`link`), else this one;
        `KeyError` for a link to no card.
        """
        if link := self.settings()[key].link:
            root = link.rpartition('/')[0]  # an escaped key has no `/`
            if (card := self.store.card(root)) is None:
                raise KeyError(f'setting {self.ROOT}/{key}: no card of its link {link!r}')
            return card, pointer_keys(link)[-1]
        return self, key

    def get(self, key: str) -> Any:
        """
        Return the value of the setting: in the configuration, else its declared default (a colour of '' too: the default one of the colour
        picker; a `select` of no option of it - e.g. a legacy value a migration let through unmapped - the same; a setting of the developer
        tools without them: they are off). It tunes the log format. A setting of another card (`link`): its value there.
        """
        card, owned = self.owner(key)
        if card is not self:
            return card.get(owned)
        setting = self.settings()[key]
        if key in self.developer_keys():
            from ..maintenance import developer_tools
            if not developer_tools():
                return self.default(key)
        value = self.store.get(self.pointer(key), MISSING)
        if value is MISSING or value == '' and setting.kind == 'color':
            value = self.default(key)
        elif setting.kind == 'select' and value not in self.option_values(key):
            value = self.default(key)
        elif setting.kind == 'range' and not isinstance(value, (list, tuple)):  # stored as one number by an older version: the maximum
            value = [self.default(key)[0], value]
        self._tune_log(key, value)
        return value

    def set(self, key: str, value: Any) -> None:
        """
        Set the setting (its declared default - a colour of '' too, the default one of the colour picker -: removed, only the changes are
        stored). It tunes the log format. A setting of another card (`link`): set there.
        """
        card, owned = self.owner(key)
        if card is not self:
            return card.set(owned, value)
        default = self.default(key)
        if value == '' and self.settings()[key].kind == 'color':
            value = default
        self._tune_log(key, value)
        self.store.set(self.pointer(key), value, default=default)

    def unmet(self, when: Mapping[str, Sequence[Any]]) -> dict[str, Sequence[Any]]:
        """Return the part of a `when` (of a setting, of a group) which does not hold now: the keys with none of their values (empty: it holds)."""
        return {key: values for key, values in when.items() if self.get(key) not in values}

    def group_shown(self, group: SettingGroup) -> bool:
        """Return True if the group is shown now: its `when` holds, a group of the developer tools only with them."""
        if group.developer:
            from ..maintenance import developer_tools
            if not developer_tools():
                return False
        return not self.unmet(group.when)

    def row_shown(self, setting: CatalogSetting) -> bool:
        """Return True if the row of a setting is shown now: its `shown_when` holds."""
        return not self.unmet(setting.get('shown_when', {}))

    def reason(self, setting: CatalogSetting) -> str:
        """
        Return why a setting can not be used now ('' it can): its `when` - every key of it has one of its values (else: the settings and their
        values); a setting of another card (`link`) the reason of that card too.
        """
        from ...kolang import L
        catalog = self.catalog()
        reasons = [L(31205, 'Used with "{setting}": {values}.', setting=catalog[key]['label'],
                     values=', '.join(value_label(catalog[key], value) for value in values))
                   for key, values in self.unmet(setting.get('when', {})).items()]
        if setting.get('link'):  # (a setting a page shows in place of one of the card is none of its settings: no link)
            card, owned = self.owner(setting['key'])
            if card is not self:
                reasons.append(card.reason(card.catalog()[owned]))
        return ' '.join(reason for reason in reasons if reason)

    # --- the old settings ---

    @classmethod
    def migrate_legacy(cls, data: dict[str, Any], old: dict[str, str]) -> list[str]:
        """
        Move the old settings of `settings.xml` (`old`: the values of the user file by their IDs) into the data of the configuration (a value
        written already is kept), return the moved IDs.
        """
        moved: list[str] = []
        values: dict[str, Any] = {}
        for key, setting in cls.settings().items():
            default = cls.default(key)
            if (legacy := setting.legacy_value) is not None:  # of more old settings or of another meaning
                moved.extend(legacy.ids)
                value = legacy.value(*(old.get(sid, '') for sid in legacy.ids))
            elif (sid := setting.legacy) == NO_LEGACY:  # no old setting
                continue
            else:
                moved.append(sid)
                value = old_value(setting.kind, default, old.get(sid, ''))
            if value is not MISSING and value != default:
                values[key] = value
        if values:
            *parents, last = pointer_keys(cls.ROOT)
            node = data
            for key in parents:
                if not isinstance(node.get(key), dict):
                    node[key] = {}
                node = node[key]
            current = node.get(last) if isinstance(node.get(last), dict) else {}
            node[last] = {**values, **current}
        return list(dict.fromkeys(moved))  # an old setting of more settings once

    @classmethod
    def restore_legacy(cls, data: dict[str, Any], old: dict[str, str], *, access: bool = True) -> list[str]:
        """
        Write the old settings of `settings.xml` found in `old` (an old user file restored) over their values in the data of the configuration
        (the other ones kept; the access data too unless `access`), return the moved IDs (`migrate_legacy()`).
        """
        def ids(setting: ProviderSetting) -> Sequence[str]:
            """Return the IDs of the old settings of the setting."""
            return setting.legacy_value.ids if setting.legacy_value is not None else (setting.legacy,)

        settings = cls.settings()
        if not access:
            kept = {sid for key in cls.access_keys() for sid in ids(settings[key])}
            old = {sid: value for sid, value in old.items() if sid not in kept}
        node: Any = data
        for key in pointer_keys(cls.ROOT):
            node = node.get(key) if isinstance(node, dict) else None
        if isinstance(node, dict):
            for key, setting in settings.items():
                if any(sid in old for sid in ids(setting)):
                    node.pop(key, None)
        return cls.migrate_legacy(data, old)
