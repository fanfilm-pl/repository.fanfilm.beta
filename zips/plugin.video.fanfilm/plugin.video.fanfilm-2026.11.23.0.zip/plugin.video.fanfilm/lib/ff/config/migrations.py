"""
The migrations of `config.json`: the changes of its data between its versions, the moves of the old settings of `settings.xml` into it
(the blocks of settings) and what cleans them after.
"""

from __future__ import annotations
from copy import deepcopy
from typing import Any, Callable, Iterable, Mapping
from urllib.parse import unquote
from attrs import frozen
from cdefs import When
from .store import pointer_keys, remove_keys
from ..logs import fflog_exc
from ..tricks import MISSING

#: Version of the `config.json` data (a file of an older version is migrated, `MIGRATIONS`).
CONFIG_VERSION: int = 20


# --- the values of the old settings of `settings.xml` (`LegacyValue.value` of the settings of the cards, `lib.ff.config.options`) ---

#: The old codes of the languages TMDB has not (`settings.xml`) -> their codes.
LANGUAGE_FIXES: dict[str, str] = {'gr-GR': 'el-GR', 'nn-NO': 'no-NO'}
#: The old options of the flattening of the seasons (`settings.xml`: never, if only one season, always) -> the seasons as a folder.
FLATTEN_WHENS: dict[str, When] = {'0': When.ALWAYS, '1': When.IF_MANY, '2': When.NEVER}


def legacy_language(code: str) -> Any:
    """Return the language of the old setting (a code TMDB has not: its code; an old label, e.g. "Polish": nothing to move)."""
    from .choices import AUTO_LANGUAGE, languages
    code = LANGUAGE_FIXES.get(code, code)
    return code if code == AUTO_LANGUAGE or any(lang.code == code for lang in languages()) else MISSING


@frozen
class LegacySort:
    """The order of a discovery of an old setting (`settings.xml`: its index in the orders of the discovery)."""

    #: The media of the discovery (`const.indexer.<media>.discover_sort_by`: `movies`, `tvshows`).
    media: str

    def __call__(self, index: str) -> Any:
        """Return the order of the old index, MISSING: none."""
        from const import const
        try:
            return tuple(getattr(const.indexer, self.media).discover_sort_by)[int(index)]
        except (ValueError, IndexError):
            return MISSING


def legacy_season_folder(index: str) -> Any:
    """Return the seasons as a folder of the old flattening of the seasons (`settings.xml`: its option)."""
    when = FLATTEN_WHENS.get(index)
    return MISSING if when is None else when.value


@frozen
class LegacySwitched:
    """The number of an old switch of a number (`settings.xml`): the number if on, else 0 (off)."""

    #: The number of the switch on without its value (the old default).
    default: int

    def __call__(self, on: str, number: str) -> Any:
        """Return the number of the switch on, 0 off."""
        if on != 'true':
            return 0
        try:
            return int(number)
        except ValueError:
            return self.default


def legacy_lists(selected: str, migrated: str) -> Any:
    """
    Return the lists of the old settings (`settings.xml`: the tokens quoted, by commas; the mark of the migration of the old automatic
    synchronizations done): the tokens, an empty list if none was chosen after that migration, MISSING never chosen.
    """
    tokens = [unquote(token) for token in selected.split(',') if token]
    return tokens if tokens or migrated == 'true' else MISSING


def legacy_sync_start(on_start: str) -> Any:
    """Return the delay of the synchronization after the start of Kodi of the old switch (`settings.xml`): at once, MISSING: none (the default)."""
    return 0 if on_start == 'true' else MISSING


def legacy_sync_hours(hours: str) -> Any:
    """Return the hours of the synchronization of the old setting (`settings.xml`: 0-24): the nearest ones of the scale up, 0 off."""
    from .choices import SYNC_HOURS
    try:
        number = int(hours)
    except ValueError:
        return MISSING
    return 0 if number <= 0 else next((value for value in SYNC_HOURS if value >= number), SYNC_HOURS[-1])


def _migrate_2(data: dict[str, Any]) -> None:
    """Version 2: the switch of an entry is `active` (as of the accounts), not `enabled` (the external add-ons of sources)."""
    addons = data.get('sources', {}).get('addons') if isinstance(data.get('sources'), dict) else None
    for entry in (addons.values() if isinstance(addons, dict) else ()):
        if isinstance(entry, dict) and 'enabled' in entry:
            entry['active'] = entry.pop('enabled')


def _migrate_3(data: dict[str, Any]) -> None:
    """
    Version 3: the switches of the entries of the menus are in `/menus` (`lib.ff.menu_entries`): "My persons" from the folder
    points of the lists, the anime in the main menu from the settings (`anime_folder`, no definition any more).
    """
    folders = data.get('lists', {}).get('folders') if isinstance(data.get('lists'), dict) else None
    if isinstance(folders, dict) and isinstance(shown := folders.pop('persons.my.shown', None), bool) and not shown:
        data.setdefault('menus', {}).setdefault('person.my', {})['shown'] = False
    if isinstance(folders, dict) and not folders:
        del data['lists']['folders']
        if not data['lists']:
            del data['lists']
    from ..settings import settings
    if settings.moved_setting('anime_folder').lower() == 'true':
        data.setdefault('menus', {}).setdefault('anime', {})['shown'] = True


def _migrate_4(data: dict[str, Any]) -> None:
    """
    Version 4: the highlight color and the list order of a native provider (`/sources/providers/<name>`) are the values of
    its node of the tree of the source providers (`/sources/nodes/<name>`: `color`, `priority` - bigger first).
    """
    from ...sources.natives import OLD_NODE_SETTINGS, node_from_old
    sources = data.get('sources')
    providers = sources.get('providers') if isinstance(sources, dict) else None
    for name, values in (providers.items() if isinstance(providers, dict) else ()):
        if isinstance(values, dict) and any(key in values for key in OLD_NODE_SETTINGS):
            if node := node_from_old(*(values.pop(key, None) for key in OLD_NODE_SETTINGS)):
                sources.setdefault('nodes', {}).setdefault(name, node)


def _migrate_5(data: dict[str, Any]) -> None:
    """Version 5: the active themes are a list (`/gui/themes`, the most important first), not the one chosen theme (`/gui/theme`)."""
    gui = data.get('gui')
    if not isinstance(gui, dict) or 'theme' not in gui:
        return
    if isinstance(theme := gui.pop('theme'), str) and theme:
        gui.setdefault('themes', [theme])
    if not gui:
        del data['gui']


def _migrate_6(data: dict[str, Any]) -> None:
    """
    Version 6: a color setting of Kodi with its old default changed since (`OLD_SETTING_COLORS`) is removed from the user settings once,
    the new default shown (Kodi keeps the old default of an add-on setting); that colour chosen by hand later is kept.
    """
    from ...sources.natives import OLD_SETTING_COLORS
    from ..settings import settings
    values = settings.user_values()
    if old := [sid for sid, color in OLD_SETTING_COLORS.items() if values.get(sid, '').upper() == color]:
        settings.clear_moved_settings(old)


def _migrate_7(data: dict[str, Any]) -> None:
    """
    Version 7: the settings of the sources (the colours, the row, the search; `lib.ff.config.options`) are in `/sources/settings`,
    moved out of the user settings of Kodi (their definitions removed: read as texts).
    """
    from .options import SourceSettings
    from ..settings import settings
    SourceSettings.migrate_legacy(data, settings.user_values())


def _migrate_8(data: dict[str, Any]) -> None:
    """Version 8: the languages of the providers moved to the settings of the sources after version 7 (`migrate_legacy()`)."""
    from .options import SourceSettings
    from ..settings import settings
    if (value := settings.user_values().get('providers.lang')) is not None:
        SourceSettings.migrate_legacy(data, {'providers.lang': value})


def _migrate_9(data: dict[str, Any]) -> None:
    """
    Version 9: the server of a Floppy account is a field of its entry of `/accounts` (configuration: in a backup), copied from
    the account data (`accounts.db`, kept there: a file not written would lose it).
    """
    from ..db.accounts import account_data_store
    for entry in (data.get('accounts') if isinstance(data.get('accounts'), list) else ()):
        if isinstance(entry, dict) and entry.get('type') == 'floppy' and isinstance(entry.get('id'), str) and not entry.get('server'):
            if server := account_data_store(entry['id']).get('server'):
                entry['server'] = server


def _migrate_10(data: dict[str, Any]) -> None:
    """
    Version 10: the settings of the maintenance (the developer logs, the changelog after an update, the cache of the lists;
    `lib.ff.config.options`) are in `/maintenance`, moved out of the user settings of Kodi (the limit of the threads of a search is
    `const.sources.search.max_parallel` now: not moved).
    """
    from .options import Maintenance
    from ..settings import settings
    Maintenance.migrate_legacy(data, settings.user_values())


def _migrate_11(data: dict[str, Any]) -> None:
    """
    Version 11: the dimmed rows of the sources by how much is seen of them (`filtered_visible`, %: 100 - the old `filtered_dim`, a round step of
    `VISIBLE_SCALE`), not by how much they are dimmed.
    """
    from .choices import visible_scale
    from .options import SourceSettings
    settings = (data.get('sources') or {}).get('settings')
    if not isinstance(settings, dict) or not isinstance(dim := settings.pop('filtered_dim', None), (int, float)):
        return
    visible = min(visible_scale().values, key=lambda value: abs(value - (100 - dim)))
    if visible != SourceSettings.default('filtered_visible'):
        settings['filtered_visible'] = visible


def _migrate_12(data: dict[str, Any]) -> None:
    """
    Version 12: the settings of the accounts (the notification of the sync, the own keys of the applications; `lib.ff.config.options`)
    are in `/account_settings`, moved out of the user settings of Kodi (the switch which only showed the keys: not moved).
    """
    from .options import AccountSettings
    from ..settings import settings
    AccountSettings.migrate_legacy(data, settings.user_values())


def _migrate_13(data: dict[str, Any]) -> None:
    """
    Version 13: the settings of the movies and the TV shows (the language of the information, the images, the discovery of TMDB, the seasons;
    `lib.ff.config.options`) are in `/media`, moved out of the user settings of Kodi (a switch of a number: the number, 0 off; an index of an
    option: its value).
    """
    from .options import Media
    from ..settings import settings
    Media.migrate_legacy(data, settings.user_values())


def _migrate_14(data: dict[str, Any]) -> None:
    """
    Version 14: fanart.tv - the switch of Fanart (the background of the media) in `/media`, the personal key of fanart.tv in
    `/account_settings`, moved out of the user settings of Kodi (an own key of a fanart.tv project: not moved, FanFilm's one only).
    """
    from .options import AccountSettings, Media
    from ..settings import settings
    values = settings.user_values()
    Media.migrate_legacy(data, values)
    AccountSettings.migrate_legacy(data, values)


def _migrate_15(data: dict[str, Any]) -> None:
    """
    Version 15: the settings of the library (its folders, the adding, the episodes, the synchronized lists and when; `lib.ff.config.options`)
    are in `/library`, moved out of the user settings of Kodi (the chosen lists: their tokens, the mark of their old migration: a stored list);
    the hidden setting of the capture of the playback (no reader) is not moved.
    """
    from .options import Library
    from ..settings import settings
    Library.migrate_legacy(data, settings.user_values())


def _migrate_16(data: dict[str, Any]) -> None:
    """
    Version 16: the settings of the downloads (the switch, the folders, the names of the files, the window after a download added, the
    additional folder of the provider of the downloaded files; `lib.ff.config.options`) are in `/downloads`, moved out of the user
    settings of Kodi.
    """
    from .options import Downloads
    from ..settings import settings
    Downloads.migrate_legacy(data, settings.user_values())


def _migrate_17(data: dict[str, Any]) -> None:
    """
    Version 17: the general settings (the start of Kodi, the m3u8 links, the widgets, the ratings, the context menu, Up Next;
    `lib.ff.config.options`) are in `/general`, moved out of the user settings of Kodi; the new ratings of a season and of a show start with
    the old rating of an episode (the old one rated them too).
    """
    from .options import General
    from ..settings import settings
    General.migrate_legacy(data, settings.user_values())


def _migrate_18(data: dict[str, Any]) -> None:
    """
    Version 18: the paired devices of the web server and the keys of its password are removed: they went over the network at their
    pairing, at the setting of the password (now a key agreement gives the keys and seals the rest, `lib.service.web_crypto`); every page
    and browser script pairs again, the password is set again.
    """
    from ..web_settings import DEVICES_CONFIG, PASSWORD_CONFIG
    remove_keys(data, pointer_keys(DEVICES_CONFIG))
    remove_keys(data, pointer_keys(PASSWORD_CONFIG))


def _migrate_19(data: dict[str, Any]) -> None:
    """
    Version 19: the switch of the synchronization of the lists of the library at the start of Kodi (`/library/sync_on_start`) is its delay
    (`/library/sync_start_delay` [s]): on - at once, off - none (the default).
    """
    if isinstance(library := data.get('library'), dict) and library.pop('sync_on_start', None) is True:
        library['sync_start_delay'] = 0


def _migrate_20(data: dict[str, Any]) -> None:
    """
    Version 20: the access of the web server is of this device and of the network (`/web/this_device`, `/web/network`) - its switches
    `/web/enabled` and `/web/local_only` are gone: off - both off; only from this device - the network off; else the network on (the
    default). The value `/web/access` of an older version of the card is removed (read by nothing).
    """
    from .choices import OFF_ROLE
    if not isinstance(web := data.get('web'), dict):
        return
    enabled, local_only = web.pop('enabled', True), web.pop('local_only', False)
    web.pop('access', None)
    if enabled is False:
        web['this_device'], web['network'] = OFF_ROLE, False
    elif local_only is True:
        web['network'] = False


#: Migrations of the data: the version -> the change of the data of the version before (in place). A step moving old settings
#: (`settings.xml`) only reads them: they stay in the user file until every move is finished (`clean_legacy_settings()`), so the
#: file is the same for a step run twice (two processes, a write of the data failed). A new step moves only its own new settings
#: (as version 8): a whole block moved again would bring back a value the user set to its default since.
MIGRATIONS: dict[int, Callable[[dict[str, Any]], None]] = {
    2: _migrate_2,
    3: _migrate_3,
    4: _migrate_4,
    5: _migrate_5,
    6: _migrate_6,
    7: _migrate_7,
    8: _migrate_8,
    9: _migrate_9,
    10: _migrate_10,
    11: _migrate_11,
    12: _migrate_12,
    13: _migrate_13,
    14: _migrate_14,
    15: _migrate_15,
    16: _migrate_16,
    17: _migrate_17,
    18: _migrate_18,
    19: _migrate_19,
    20: _migrate_20,
}


def migrate_data(data: dict[str, Any], *, version: int, migrations: Mapping[int, Callable[[dict[str, Any]], None]], first: int = 1) -> bool:
    """
    Migrate the data (in place) to the `version` by the `migrations` of the versions after theirs (no version: `first`).
    Return True if they changed.
    """
    current = data.get('version', first)
    if not isinstance(current, int) or current >= version:
        return False
    for ver in range(current + 1, version + 1):
        if (step := migrations.get(ver)) is not None:
            step(data)
    data['version'] = version
    return True


def migrate(data: dict[str, Any]) -> bool:
    """Migrate the data of `config.json` (in place) to `CONFIG_VERSION` (no version: 1). Return True if they changed."""
    return migrate_data(data, version=CONFIG_VERSION, migrations=MIGRATIONS)


def legacy_settings_pending() -> list[str]:
    """
    Return the moves of the old settings (`settings.xml`) not finished yet, by what their files tell: the versions of `config.json`,
    the accounts, the native providers, the filters of the sources, the old automatic synchronizations of the lists which were on.
    A finished one has its new place written; until then the old values are only in the user settings (no setting without a
    definition may be removed there). Every reader of a setting without a definition has its move here.
    """
    from . import config
    from ...sources.natives import MIGRATED_CONFIG
    from ..accounts import ACCOUNTS_CONFIG
    from ..lists import legacy_auto_sync_pending
    from ..source.filters import filters_store
    moves = {
        'config': config.stored and config.get('/version') == CONFIG_VERSION,
        'accounts': config.get(ACCOUNTS_CONFIG) is not None,
        'providers': bool(config.get(MIGRATED_CONFIG)),
        'filters': filters_store.stored and isinstance(filters_store.get('/version'), int),
        'lists': not legacy_auto_sync_pending(),
    }
    return [name for name, done in moves.items() if not done]


def clean_legacy_settings() -> None:
    """
    Remove the old settings left in the user settings (no definition, moved nowhere: of removed providers and options, Kodi keeps
    them for ever; moved: their moves only read them) by one write of the file with a backup, after every move of the old settings:
    the lazy ones are finished first (the accounts here, the filters of the sources by the read of their file in `legacy_settings_pending()`;
    not the lists: they need the services). The worker script runs it after a FanFilm update (after `migrate_settings()`), the service
    at its other starts (a move finished since).
    """
    from ..settings import settings
    try:
        from ..accounts import account_store
        account_store.accounts()
        if set(settings.user_values()) - set(settings.load_defaults() or ()):  # no write (nor backup) of the file for none of them
            settings.clear_undefined()
    except Exception:
        fflog_exc('[CONFIG] the old settings not cleaned')


def reset_config(pointers: Iterable[str]) -> bool:
    """
    Remove the branches of the configuration at the pointers (as after a new installation) by one write of the file, their access data kept
    (`lib.ff.backup.with_access()`: the accounts, the keys, the logins and the passwords, the devices of the web server). Return True if written
    (none of them there too).
    """
    from . import config
    from ..backup import with_access
    paths = [pointer_keys(pointer) for pointer in pointers]
    with config.batch() as changes:
        if changes.valid:
            current = deepcopy(changes.data)
            if any([remove_keys(changes.data, keys) for keys in paths]):  # a list: every pointer removed
                fresh = with_access(changes.data, current)
                changes.data.clear()
                changes.data.update(fresh)
                changes.changed = True
    return changes.ok


def restore_legacy_settings(old: dict[str, str], *, access: bool) -> bool:
    """
    Move the old settings of an old user file restored (`old`: its values by their IDs; `lib.ff.backup`) into the configuration again, over
    the values there (`Card.restore_legacy()`: the cards of settings; not the accounts, the native providers, the filters of the
    sources), their access data only with `access`. Return True if written (nothing to move too).
    """
    from . import config
    from .options import CARDS
    with config.batch() as changes:
        if changes.valid:
            current = deepcopy(changes.data)
            for card in CARDS:
                card.restore_legacy(changes.data, old, access=access)
            changes.changed = changes.data != current
    return changes.ok
