"""
What the declaration of the settings (`lib.ff.config.options`) is made of other data: the options of a setting (of `const`, of the sizes of
the images, of the languages…), the scales, the texts with a value of now, the settings made of `const`. Functions of no argument a setting
names; called when used (a page shows the setting, a read checks its option) - what they need is imported then, not by the declaration.
"""

from __future__ import annotations
from typing import Any, Mapping, Sequence, TYPE_CHECKING
from attrs import frozen
from .blocks import ProviderSetting, SettingOption
from ...kolang import L
if TYPE_CHECKING:
    from ..gui.scale import Scale

#: The language of the information: of Kodi.
AUTO_LANGUAGE: str = 'AUTO'
#: The number of the example of a season (its label in the options).
SEASON_EXAMPLE: int = 1
#: The example of the progress bar in the help of its setting: the watched part (%).
PROGRESS_EXAMPLE: int = 45
#: The hours between two synchronizations of the lists of the library (0: none of its own).
SYNC_HOURS: tuple[int, ...] = (1, 2, 3, 4, 6, 8, 12, 24)
#: The delays of the synchronization of the lists of the library after the start of Kodi [s] (besides none and at once).
SYNC_START_DELAYS: tuple[int, ...] = (60, 300, 600, 900)
#: The value of the role of a browser of this device (the web server) which pairs as any other.
NO_ROLE: str = 'none'
#: The value of the role of a browser of this device (the web server) which is refused (a paired one too).
OFF_ROLE: str = 'off'
#: The key prefix of the details of an area of the developer logs (`log.<key of the area>`).
LOG_AREA_PREFIX: str = 'log.'
#: The options of the details of the logs (an area, a node of the tree of the source providers): the level of their detail lines.
LOG_LEVEL_OPTIONS: tuple[SettingOption, ...] = (SettingOption(value=False, label='DEBUG'), SettingOption(value=True, label='INFO'))


# --- the movies and the TV shows ---

@frozen(kw_only=True)
class Language:
    """A language of the information."""

    #: The code (TMDB: language-REGION).
    code: str
    #: The label.
    label: str


def languages() -> tuple[Language, ...]:
    """Return the languages of the information in the order of the options."""
    return (
        Language(code='bg-BG', label=L(32674, 'Bulgarian')),
        Language(code='zh-CN', label=L(32675, 'Chinese')),
        Language(code='hr-HR', label=L(32676, 'Croatian')),
        Language(code='cs-CZ', label=L(32677, 'Czech')),
        Language(code='da-DK', label=L(32678, 'Danish')),
        Language(code='nl-NL', label=L(32679, 'Dutch')),
        Language(code='en-US', label=L(32680, 'English')),
        Language(code='fi-FI', label=L(32681, 'Finnish')),
        Language(code='fr-FR', label=L(32682, 'French')),
        Language(code='de-DE', label=L(32683, 'German')),
        Language(code='el-GR', label=L(32684, 'Greek')),
        Language(code='he-IL', label=L(32685, 'Hebrew')),
        Language(code='hu-HU', label=L(32686, 'Hungarian')),
        Language(code='it-IT', label=L(32687, 'Italian')),
        Language(code='ja-JP', label=L(32688, 'Japanese')),
        Language(code='ko-KR', label=L(32689, 'Korean')),
        Language(code='no-NO', label=L(32690, 'Norwegian')),
        Language(code='pl-PL', label=L(32691, 'Polish')),
        Language(code='pt-PT', label=L(32692, 'Portuguese')),
        Language(code='ro-RO', label=L(32693, 'Romanian')),
        Language(code='ru-RU', label=L(32694, 'Russian')),
        Language(code='sr-RS', label=L(32695, 'Serbian')),
        Language(code='sk-SK', label=L(32696, 'Slovak')),
        Language(code='sl-SI', label=L(32697, 'Slovenian')),
        Language(code='es-ES', label=L(32698, 'Spanish')),
        Language(code='sv-SE', label=L(32699, 'Swedish')),
        Language(code='th-TH', label=L(32700, 'Thai')),
        Language(code='tr-TR', label=L(32701, 'Turkish')),
        Language(code='uk-UA', label=L(32702, 'Ukrainian')),
    )


def language_options() -> tuple[SettingOption, ...]:
    """Return the options of the language of the information: of Kodi (its language in the label: its code, else the language of it), then the languages."""
    from ..locales import kodi_locale
    langs = languages()
    kodi = kodi_locale()
    language = kodi.partition('-')[0]  # Kodi 21: also 'en-' (no region)
    kodi_label = (next((lang.label for lang in langs if lang.code == kodi), None)
                  or next((lang.label for lang in langs if lang.code.startswith(f'{language}-')), kodi))
    return (SettingOption(value=AUTO_LANGUAGE, label=L(31141, 'Kodi ({language})', language=kodi_label)),
            *(SettingOption(value=lang.code, label=lang.label) for lang in langs))


def sort_options(orders: Sequence[str]) -> tuple[SettingOption, ...]:
    """Return the options of the order of a discovery of TMDB (`const.indexer.*.discover_sort_by`): the label of its field (a field twice: its direction)."""
    fields = {
        'popularity': L(32714, 'Popularity'),
        'primary_release_date': L(32715, 'Year'),
        'first_air_date': L(32715, 'Year'),
        'title': L(30238, 'Name'),
        'name': L(30238, 'Name'),
        'original_title': L(31142, 'Original title'),
        'original_name': L(31142, 'Original title'),
        'vote_average': L(31143, 'Rating'),
        'vote_count': L(31144, 'Number of votes'),
        'revenue': L(31145, 'Revenue'),
    }
    directions = {'asc': L(31146, 'ascending'), 'desc': L(31147, 'descending')}

    def label(order: str) -> str:
        """Return the label of an order (`<field>.<direction>`)."""
        field, _, direction = order.partition('.')
        text = fields.get(field, field)
        if sum(other.partition('.')[0] == field for other in orders) > 1:
            text = f'{text}, {directions.get(direction, direction)}'
        return text

    return tuple(SettingOption(value=order, label=label(order)) for order in orders)


def movie_sort_default() -> str:
    """Return the default order of the discovery of the movies (the first one of `const.indexer.movies.discover_sort_by`)."""
    from const import const
    return const.indexer.movies.discover_sort_by[0]


def show_sort_default() -> str:
    """Return the default order of the discovery of the TV shows (the first one of `const.indexer.tvshows.discover_sort_by`)."""
    from const import const
    return const.indexer.tvshows.discover_sort_by[0]


def movie_sort_options() -> tuple[SettingOption, ...]:
    """Return the options of the order of the discovery of the movies."""
    from const import const
    return sort_options(tuple(const.indexer.movies.discover_sort_by))


def show_sort_options() -> tuple[SettingOption, ...]:
    """Return the options of the order of the discovery of the TV shows."""
    from const import const
    return sort_options(tuple(const.indexer.tvshows.discover_sort_by))


def season_label_options() -> tuple[SettingOption, ...]:
    """Return the options of the label of a season: the formats of a season with a title (`const.indexer.seasons.with_title_labels`) on an example."""
    from ..tricks import Formatter, adict
    from const import const
    locale = adict(season=L(30406, 'Season'))  # the language of the window (the labels of a list: of the information, `KodiLabels`)
    title = L(31148, 'Pilot', ctx='an example of a season title')
    fmt = Formatter()
    return tuple(SettingOption(value=index, label=fmt.format(label_format, locale=locale, title=title, season=SEASON_EXAMPLE, episode=0))
                 for index, label_format in enumerate(const.indexer.seasons.with_title_labels))


def quality_options() -> tuple[SettingOption, ...]:
    """Return the options of the quality of the images: with the sizes of TMDB of a poster and a landscape (`TmbdArtService.art_names`)."""
    from ..art import ArtQuality, TmbdArtService
    names = TmbdArtService.art_names
    labels = {ArtQuality.LOW: L(32705, 'low'), ArtQuality.HIGH: L(32706, 'high'), ArtQuality.BEST: L(32707, 'highest')}
    return tuple(SettingOption(value=int(quality), label=L(31149, '{quality} ({poster} / {landscape})', quality=label,
                                                           poster=names['poster'].sources[0].quality[quality],
                                                           landscape=names['landscape'].sources[0].quality[quality]))
                 for quality, label in labels.items())


def image_source_options() -> tuple[SettingOption, ...]:
    """Return the options of the source of the images (`ImageSource`)."""
    from ..art import ImageSource, image_source_labels
    return tuple(SettingOption(value=source.value, label=image_source_labels[source]) for source in ImageSource)


def season_folder_options() -> tuple[SettingOption, ...]:
    """Return the options of the seasons as a folder: `When` (the words of the page of the folders)."""
    from cdefs import When
    from ..lists_config import when_label
    return tuple(SettingOption(value=when.value, label=when_label(when)) for when in When)


def progress_example() -> str:
    """Return the example of the progress bar (`const.indexer.progressbar`: its look) with its percent."""
    from ..progress import progressbar_str
    return f'{progressbar_str((1,) * PROGRESS_EXAMPLE + (0,) * (100 - PROGRESS_EXAMPLE))} {PROGRESS_EXAMPLE}%'


def progress_bar_help() -> str:
    """Return the help of the setting of the progress bar: with an example of it."""
    return L(31170, '{help} E.g. {example}', help=L(31154, 'The progress of watching above the description of a movie, a show, an episode.'),
             example=progress_example())


def service_menus_help() -> str:
    """Return the help of the gate of the features of single services: where they are switched on, the features of every service type."""
    from ..account_admin import context_menu_text
    from ..accounts import SERVICE_TYPES
    features = '; '.join(f'{typ.label}: {", ".join(context_menu_text(menu).label for menu in typ.context_menus)}'
                         for typ in SERVICE_TYPES.values() if typ.context_menus)
    return L(31324, 'The entries are switched on in the accounts. {features}.', features=features)


# --- the scales ---

def off_scale(maximum: int, *, major: int) -> Scale:
    """Return the scale of a number from 1 with its off (0) at the low end."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(minimum=1, maximum=maximum, step=1, low=(ScaleValue(0, L(32887, 'off')),), major=major)


def months_scale() -> Scale:
    """Return the scale of a number of months (0: off)."""
    return off_scale(12, major=3)


def years_scale() -> Scale:
    """Return the scale of a number of years (0: off)."""
    return off_scale(80, major=10)


def shown_scale() -> Scale:
    """Return the scale of the number of the names shown of a title in a folder (0: all)."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(minimum=1, maximum=5, step=1, low=(ScaleValue(0, L(31150, 'all')),), major=1)


def votes_scale() -> Scale:
    """Return the scale of the least number of the votes of a title (0: every title): logarithmic (10-20 is another step than 700-710)."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(minimum=10, maximum=2000, log=(1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6.5, 8), low=(ScaleValue(0, L(31150, 'all')),), least=True)


def actor_scale() -> Scale:
    """Return the scale of the number of the actors in the information of a title (0: all)."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(minimum=1, maximum=50, step=1, low=(ScaleValue(0, L(31150, 'all')),), major=10)


def premiere_delay_scale() -> Scale:
    """Return the scale of the days after the premiere of an episode it is added to the library (0: at once)."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(minimum=1, maximum=3, step=1, low=(ScaleValue(0, L(31195, 'at once')),))


def sync_hours_scale() -> Scale:
    """Return the scale of the hours between two synchronizations of the lists of the library (`SYNC_HOURS`, 0: off)."""
    from ..gui.scale import Scale, ScaleValue
    return Scale(values=SYNC_HOURS, low=(ScaleValue(0, L(32887, 'off')),))


@frozen
class MinutesText:
    """The text of a number of seconds in minutes (`Scale.format`: a record, not a function - its repr is a stable key of the XML cache of a window)."""

    #: The template of the minutes (`{n}`: their number).
    template: str

    def __call__(self, seconds: float) -> str:
        """Return the text of the seconds in minutes."""
        return self.template.format(n=f'{seconds / 60:g}')


def sync_start_scale() -> Scale:
    """
    Return the scale of the delay of the synchronization of the lists of the library after the start of Kodi [s] (`SYNC_START_DELAYS`,
    shown in minutes; None: none, 0: at once).
    """
    from ..gui.scale import Scale, ScaleValue
    return Scale(values=SYNC_START_DELAYS, low=(ScaleValue(None, L(32667, 'none')), ScaleValue(0, L(31195, 'at once'))),
                 format=MinutesText(L(31338, 'after {n} min')), tick_format=MinutesText('{n}'))


def visible_scale() -> Scale:
    """Return the scale of how much is seen of a dimmed row of a source (the filter cuts it, a step dropped it), %: round steps of 5, never gone."""
    from ..gui.scale import Scale
    return Scale(values=tuple(range(10, 101, 5)), format='{:g} %', tick_format='{:g}')


def search_time_scale() -> Scale:
    """
    Return the scale of the two times of the search of the sources: one axis of round steps of about the same ratio (as the size of a source),
    the end not under 5 s.
    """
    from ..gui.scale import Scale
    return Scale(values=(0, 1, 1.5, 2, 3, 5, 7, 10, 15, 20, 30, 50, 70, 100, 150, 200), format='{:g} s', tick_format='{:g}', knob_max_least=5)


# --- the downloads ---

def local_title_label() -> str:
    """Return the label of the switch of the file name from the local title: with the code of the language of the information now (e.g. `PL`)."""
    from ..control import api_language
    return L(30317, 'Save title: {lang}').replace('{lang}', api_language('tmdb').partition('-')[0].upper())


# --- the web server ---

def first_role() -> str:
    """Return the default role of a browser of this device without pairing: the first one of `const.tune.service.web_server.roles`."""
    from const import const
    return tuple(const.tune.service.web_server.roles)[0]


def role_options() -> tuple[SettingOption, ...]:
    """Return the options of the access of a browser of this device: off, after pairing, then the roles of the web server without pairing."""
    from const import const
    return (SettingOption(value=OFF_ROLE, label=L(33039, 'Off')), SettingOption(value=NO_ROLE, label=L(31259, 'After pairing')),
            *(SettingOption(value=key, label=role.label) for key, role in const.tune.service.web_server.roles.items()))


# --- the maintenance ---

def log_area_key(area: str) -> str:
    """Return the key of the setting of the details of an area of the developer logs."""
    return f'{LOG_AREA_PREFIX}{area}'


def area_settings(group: str, when: Mapping[str, Sequence[Any]]) -> tuple[ProviderSetting, ...]:
    """Return the settings of the details of the areas of the developer logs of the group of the page (`LogArea.group`), used by their `when`."""
    from const import const
    level = L(31046, 'The level of the detail lines of the area in the Kodi log: DEBUG (with the debug logging of Kodi), INFO (always with the '
              'developer logs).')
    return tuple(ProviderSetting(key=log_area_key(key), kind='select', label=area.label, default=False, options=LOG_LEVEL_OPTIONS, when=when,
                                 help=f'{area.help} {level}' if area.help else level)
                 for key, area in const.debug.log_areas.items() if area.group == group)
