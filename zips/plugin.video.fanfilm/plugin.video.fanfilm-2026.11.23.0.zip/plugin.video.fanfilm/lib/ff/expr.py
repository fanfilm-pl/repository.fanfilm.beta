"""
The evaluator of the FF expressions (`settings.eval()`, `config.eval()`, `cdefs.Expr`: the rules of `const`): one set of names for all of
them - `const`, `settings` (the settings of Kodi), `config` (the user configuration, read only), `math`, `L`, the units, the enums of
`cdefs` - and of functions. A bare name is what its caller reads: a setting of Kodi (`settings.eval()`), a card of the configuration
(`config.eval()`: `media.language`).
"""

from __future__ import annotations
from typing import Any, Callable, Mapping, TYPE_CHECKING
if TYPE_CHECKING:
    from simpleeval import SimpleEval

#: The names of every expression (made once, `expr_names()`).
_names: dict[str, Any] = {}


class ConfigReader:
    """
    The user configuration in an expression, read only: `config('/gui/theme', 'default')` or `config.get(...)` (a value at a pointer; no
    default: of a declared setting its declared one), `config.media.language` (a setting of a card of settings).
    """

    def __init__(self, pointer: str = '') -> None:
        """The reader of the configuration, of its branch at the pointer."""
        #: The pointer of the branch read ('': the whole configuration).
        self._pointer: str = pointer

    def _target(self) -> Any:
        """Return what is read: the configuration of now (a test may replace it), its branch over cards of settings, a card."""
        from . import config as config_module
        return config_module.config.branch(self._pointer) if self._pointer else config_module.config

    def __call__(self, pointer: str, *default: Any) -> Any:
        """Return the value at the pointer in the configuration (`Config.get()`)."""
        from . import config as config_module
        return config_module.config.get(pointer, *default)

    def get(self, key: str, *default: Any) -> Any:
        """
        Return the value at the pointer in the configuration; of a card: its setting of the key (a default given: the stored value of the
        key or that default, declared or not).
        """
        from .config.blocks import Card
        target = self._target()
        if not isinstance(target, Card):
            return self(key, *default)
        return target.store.get(target.pointer(key), *default) if default else target.get(key)

    def __getattr__(self, name: str) -> Any:
        """Return the setting of a card, a card or a branch over cards at the name (nothing else of the configuration: no writer)."""
        from .config.blocks import Card
        if name.startswith('_'):
            raise AttributeError(name)
        target = self._target()
        if isinstance(target, Card):
            if name not in target.settings():
                raise AttributeError(f'no setting {name!r} at {self._pointer!r}')
            return target.get(name)
        reader = ConfigReader(f'{self._pointer}/{name}')
        reader._target()  # `AttributeError`: no card there
        return reader


def expr_names() -> dict[str, Any]:
    """Return the names of every expression."""
    if not _names:
        names: dict[str, Any] = {}
        import math
        from enum import Enum
        import cdefs
        from cdefs import MINUTE, HOUR, DAY, WEEK, KiB, MiB, GiB, TiB
        from const import const
        from .settings import settings
        from ..kolang import L
        names.update({
            'const': const,            # trick to use const settings in expressions
            'settings': settings.data,     # trick to direct use the settings in expressions
            'config': ConfigReader(),  # the user configuration (read only): config.media.language
            'math': math,
            'L': L,
            'MINUTE': MINUTE, 'HOUR': HOUR, 'DAY': DAY, 'WEEK': WEEK,
            'KiB': KiB, 'MiB': MiB, 'GiB': GiB, 'TiB': TiB,
            'KB': KiB, 'MB': MiB, 'GB': GiB, 'TB': TiB,
        })
        for name in dir(cdefs):
            if name[:1].isupper() and (cls := getattr(cdefs, name)) and isinstance(cls, type) and issubclass(cls, Enum):
                names[name] = cls
        _names.update(names)  # whole at once: another thread sees none or all of them
    return _names


def expr_functions() -> dict[str, Callable[..., Any]]:
    """Return the functions of every expression."""
    return {
        'len': len,
        'min': min,
        'max': max,
        'sum': sum,
        'all': all,
        'any': any,
        'sorted': sorted,
        'list': list,
        'tuple': tuple,
        'set': set,
        'abs': abs,
        'round': round,
        'bound': lambda a, x, b: max(a, min(b, x)),
        # ponytail: a stat of the file per call (fresh after a change), cache per evaluation if the rules get slow
        # read the user configuration, e.g. config('/gui/theme', 'default'), config('/media/language') (its declared default)
        'config': expr_names()['config'],
    }


def evaluator(bare: Callable[[str], Any], names: Mapping[str, Any] | None = None) -> SimpleEval:
    """
    Return an evaluator of expressions: the names of the caller (`names`) first, then the names of every expression, a bare name else by
    `bare` (what the caller reads by its name).
    """
    from simpleeval import SimpleEval
    shared = expr_names()

    def name_handler(node: Any) -> Any:
        """Return the value of a name of an expression."""
        if names and node.id in names:
            return names[node.id]
        if val := shared.get(node.id):
            return val
        return bare(node.id)

    return SimpleEval(names=name_handler, functions=expr_functions())


def config_eval(expression: str | bool | None, names: Mapping[str, Any] | None = None) -> Any:
    """
    Return the value of an expression of the configuration: a bare name is a card of settings (`media.language`), a branch over them;
    a bool or None is the value as it is. A wrong expression is logged and raised.
    """
    if expression is None or expression is False or expression is True:
        return expression
    try:
        return evaluator(lambda name: getattr(expr_names()['config'], name), names).eval(expression)
    except Exception as exc:
        from .logs import log
        log.warning(f'Evaluate expression {expression!r} FAILED: {exc}')
        raise
