"""
The cookies FF receives (the browser script by the web server, the Cloudflare server, another FanFilm): their sites and targets (the settings
of the native providers, the accounts), their write, their forward to the other FanFilm of the home (`lib.service.web_client`: the targets) -
the cookies of the providers only, of the accounts too with `const.tune.service.web_server.relay.accounts`.
"""

from __future__ import annotations
from typing import Any, Mapping
from fnmatch import fnmatch
from attrs import frozen
from .logs import fflog
from .types import JsonData
from ..kolang import L
from const import const

#: The prefix of a target of a cookie: a value of a native provider (`provider:<name>:<key>`), an account (`account:<type>:<key>`).
PROVIDER_TARGET: str = 'provider:'
ACCOUNT_TARGET: str = 'account:'


@frozen(kw_only=True)
class CookiesWritten:
    """The cookies of a site written: the number of their targets, the targets changed (the settings, the accounts)."""

    #: The number of the targets written.
    count: int
    #: The changed targets (for the log, the notification).
    changed: frozenset[str]
    #: The values given to the accounts by their types (IMDb: the warning of no session cookie).
    accounts: Mapping[str, Mapping[str, str]]


def setting_name(value: str | tuple[str, str]) -> str:
    """Return the target of a cookie of `cookie_sites()`: a plain one, or the first one of a (target, 'append') pair (`write_cookies()`)."""
    return value[0] if isinstance(value, tuple) else value


def cookie_sites() -> dict[Any, dict[str, Any]]:
    """
    Return the sites of the cookies: `const.tune.service.web_server.cookies` (the accounts) and the sites of the native
    providers (their declarations in the stored catalog), a value of a provider as `provider:<name>:<key>`.
    """
    from ..sources.natives import catalog_providers, native_catalog
    sites: dict[Any, dict[str, Any]] = {host: dict(conv) for host, conv in const.tune.service.web_server.cookies.items()}
    for prov in catalog_providers(native_catalog(build=False)):
        for host, values in prov.get('cookies', {}).items():
            sites.setdefault(host, {}).update({cookie: f'{PROVIDER_TARGET}{prov["id"]}:{key}' for cookie, key in values.items()})
    return sites


def site_matches(host: str, site: Any) -> bool:
    """Return True if the host is of the site of `cookie_sites()` (a pattern or a regular expression)."""
    return fnmatch(host, site) if isinstance(site, str) else bool(site.fullmatch(host))


def target_value(target: str) -> str | None:
    """Return the value of a target of a cookie (`provider:<name>:<key>`, a setting of a native provider), None: no such target."""
    if target.startswith(PROVIDER_TARGET):
        from ..sources.natives import provider_value
        _, name, key = target.split(':', 2)
        return str(provider_value(name, key))
    return None


def set_target_value(target: str, value: str) -> None:
    """Set the value of a target of a cookie (`provider:<name>:<key>`, a setting of a native provider; another target: nothing)."""
    if target.startswith(PROVIDER_TARGET):
        from ..sources.natives import set_provider_value
        _, name, key = target.split(':', 2)
        set_provider_value(name, key, value)


def write_cookies(data: Mapping[str, Any]) -> CookiesWritten:
    """
    Write the cookies of a site (`{"host": ..., "cookies": [{"name", "value"}], "user_agent": ...}`: a value of the request named by
    a target `:<name>`) to their targets: the settings of the providers (a pair (target, 'append') adds the value to the ones by commas),
    the accounts. A cookie of the site not in the payload is cleared (the browser has it no more), kept in a `partial` one (the Cloudflare
    server: only its cookie).
    """
    count = 0
    changed: set[str] = set()
    accounts: dict[str, dict[str, str]] = {}
    host = data.get('host') or ''
    partial = bool(data.get('partial'))
    for site, conv in cookie_sites().items() if host else ():
        if not site_matches(host, site):
            continue
        cookies = {name: value for cookie in data.get('cookies', []) if (name := cookie.get('name')) and (value := cookie.get('value'))}
        for cookie_name, target in conv.items():
            if cookie_name == ':UA':  # user-agent
                cookie_name = ':user_agent'
            given = cookie_name[1:] in data if cookie_name.startswith(':') else cookie_name in cookies
            if partial and not given:
                continue  # not in a partial payload: kept
            value = data.get(cookie_name[1:], '') if cookie_name.startswith(':') else cookies.get(cookie_name, '')
            if isinstance(target, str) and target.startswith(ACCOUNT_TARGET):  # to an account
                _, type_name, key = target.split(':', 2)
                if value:
                    accounts.setdefault(type_name, {})[key] = value
                continue
            append = isinstance(target, tuple)  # (target, 'append')
            if append:
                target = target[0]
                if not value:
                    continue  # nothing to append - leave the setting alone
                current = [v for part in (target_value(target) or '').split(',') if (v := part.strip())]
                if value in current:
                    continue  # already there
                value = ','.join([*current, value])
            if value != (target_value(target) or ''):
                changed.add(target)
            set_target_value(target, value)
            count += 1
        otp_setting = conv.get('otp_code')
        if otp_setting and otp_setting in changed and (target_value(otp_setting) or '').strip():
            from ..sources.en.netmirror import source as NetMirrorSource
            NetMirrorSource.prefetch_otp_token()
    for type_name, values in accounts.items():
        count += len(values)
        changed.update(to_account(type_name, values))
    return CookiesWritten(count=count, changed=frozenset(changed), accounts=accounts)


def to_account(type_name: str, values: Mapping[str, str]) -> set[str]:
    """Give the cookies to the accounts (IMDb: the account of the cookie user), return what changed (for the log)."""
    from . import account_admin
    from .kotools import Notification
    changed: set[str] = set()
    if type_name != 'imdb':
        return changed
    if user := values.get('public'):
        before = {acc.id for acc in account_admin.account_store.accounts()}
        if (acc := account_admin.add_public_imdb(user)) and acc.id not in before:  # an existing account of the user: no change
            changed.add(acc.id)
    if values.get('at-main'):
        free = account_admin.free_imdb_cookie()
        target, nick = account_admin.receive_imdb_cookie(dict(values))
        if target:
            changed.add(target)
        elif nick and (not free or free.get('at-main') != values['at-main']):  # a new free cookie: tell once
            Notification('FanFilm', L(30693, 'IMDb cookie of {nick}: add the account in the accounts').format(nick=nick), sound=False).show()
    return changed


def forwarded(data: Mapping[str, Any]) -> JsonData | None:
    """
    Return the payload of the cookies of a site forwarded to the other FanFilm: only the ones of the providers (the accounts too with
    `relay.accounts`), None if nothing is left.
    """
    host = data.get('host') or ''
    accounts = const.tune.service.web_server.relay.accounts
    names: set[str] = set()
    for site, conv in cookie_sites().items() if host else ():
        if site_matches(host, site):
            names.update(name for name, target in conv.items()
                         if accounts or setting_name(target).startswith(PROVIDER_TARGET))
    cookies = [cookie for cookie in data.get('cookies', []) if cookie.get('name') in names]
    fields = {name[1:]: data[name[1:]] for name in names if name.startswith(':') and name[1:] in data}
    if ':UA' in names and 'user_agent' in data:
        fields['user_agent'] = data['user_agent']
    if not cookies and not fields:
        return None
    return {'host': host, 'cookies': cookies, **fields, **({'partial': True} if data.get('partial') else {})}


def current_payloads() -> list[JsonData]:
    """
    Return the cookies of the providers set now as partial payloads by their sites (a new target gets them at once, its other cookies kept);
    a site of a pattern and a value added by commas (`append`) skipped: neither is one cookie.
    """
    payloads: list[JsonData] = []
    accounts = const.tune.service.web_server.relay.accounts
    for site, conv in cookie_sites().items():
        if not isinstance(site, str) or any(ch in site for ch in '*?['):
            continue
        cookies, fields = [], {}
        for name, target in conv.items():
            if isinstance(target, tuple) or not (target.startswith(PROVIDER_TARGET) or accounts) or not (value := target_value(target)):
                continue
            if name.startswith(':'):
                fields['user_agent' if name == ':UA' else name[1:]] = value
            else:
                cookies.append({'name': name, 'value': value})
        if cookies:
            payloads.append({'host': site, 'cookies': cookies, **fields, 'partial': True})  # no snapshot of a browser: the others kept
    return payloads


def receive_cookies(data: Mapping[str, Any]) -> CookiesWritten:
    """
    Write the cookies of a site (`write_cookies()`); changed and not forwarded already (`relayed`): forwarded to the targets (in a thread,
    `lib.service.web_client.forward_cookies()`).
    """
    written = write_cookies(data)
    if written.changed and not data.get('relayed') and (payload := forwarded(data)) is not None:
        from .web_settings import TARGETS_CONFIG
        from .config import config
        if config.get(TARGETS_CONFIG):
            from .threads import Thread
            from ..service.base import service_scope
            from ..service.web_client import forward_cookies
            fflog(f'[WEB] forwarding cookies of {payload["host"]}')
            Thread(target=forward_cookies, args=([payload],), name='web-forward', scope=service_scope).start()  # cut at the stop of the service
    return written
