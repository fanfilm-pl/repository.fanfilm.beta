"""
Downloads DB (the "dumb" side): ``downloads.db`` with the queue of the downloads (`lib.service.downloads` writes it, the only writer).

``download`` (:class:`DownloadRow`) -- a download: its target file (unique), the link with its headers, the state, the error,
the source (to renew the link), the place in the queue (``position``: a fixed order, new rows at the end).

Every operation is "best effort": a DB error never reaches the caller (an empty read, a skipped write).
"""

from __future__ import annotations
from typing import Any, Callable, Collection, Optional, TypeVar, cast
from functools import wraps
from time import time
import json

from .db import PrimaryKey, db_manager
from .orm import OrmDatabase, DbTable, DbCursor, field as db_field, select, update, delete, IN, MISSING, best_effort
from ..tricks import JsonEncoder
from ..types import JsonData
from ...defs import MediaRef, XMediaRef

#: Downloads DB version.
DB_VERSION: int = 1

#: The old DB of the downloads (before this one: its own SQLite file of the old downloader), removed when this DB is created.
LEGACY_DB_FILE: str = 'downloads.1'

#: The reference of a download without media (`MediaRef` None).
NO_REF: XMediaRef = XMediaRef('', 0)

F = TypeVar('F', bound=Callable[..., Any])

#: The count of the writes of this interpreter (the service, the only writer): a reader keeps the rows while it is the same.
writes: int = 0


def to_xref(ref: MediaRef | None) -> XMediaRef:
    """Return the normalized reference (xref) of `ref`, `NO_REF` for None."""
    return NO_REF if ref is None else ref.xref


class DownloadRow(DbTable):
    """A download of the queue."""

    __tablename__ = 'download'
    __table_args__ = ('UNIQUE("dest")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: The media (normalized, `NO_REF`: unknown).
    xref: XMediaRef = db_field(default=MISSING, converter=to_xref)
    #: The title of the row (a movie with its year, a show with `S01E02`).
    title: str = ''
    #: The description of the source (the quality, the language).
    info: str = ''
    #: The target file (a Kodi path, translated: a local path or a network URL).
    dest: str = ''
    #: The link of the file.
    url: str = ''
    #: The headers of the link requests (JSON object).
    headers_json: str = '{}'
    #: The size in bytes (0: unknown): the source declares it, the server tells it.
    size: int = 0
    #: The validator of the file of the link (`ETag`, else `Last-Modified`) for `If-Range` of a resume, '' unknown.
    validator: str = ''
    #: The state: `queued`, `paused`, `error`, `done` (`lib.ff.downloads.DownloadState`).
    state: str = 'queued'
    #: The kind of the error (`lib.ff.downloads.DownloadErrorKind`, '' none) and its text for the user.
    error_kind: str = ''
    error_text: str = ''
    #: The source (`Source.as_json(dynamic=True)`, JSON object): the renewal of the link resolves it again.
    source_json: str = '{}'
    #: Till when the file is on the account of the provider ('' unknown).
    expires: str = ''
    #: The time it was added (unix seconds).
    created_at: int = 0
    #: The place in the queue (ascending).
    position: int = 0

    @property
    def ref(self) -> MediaRef | None:
        """Return the media, None if unknown."""
        return MediaRef.from_sql_ref(self.xref) if self.xref.type else None

    @property
    def headers(self) -> dict[str, str]:
        """Return the headers of the link requests."""
        return json.loads(self.headers_json or '{}')

    @property
    def source(self) -> JsonData:
        """Return the source (JSON data)."""
        return json.loads(self.source_json or '{}')


def to_json(data: Any) -> str:
    """Convert `data` to a JSON string."""
    return json.dumps(data, cls=JsonEncoder)


def _best_effort(default: Callable[[], Any]) -> Callable[[F], F]:
    """Decorate an operation of the downloads DB, see `orm.best_effort()`."""
    return best_effort(default, db=lambda: db)


def _write(func: F) -> F:
    """Decorate a write of the downloads DB: counted in `writes` after it (the rows read before are out of date)."""
    @wraps(func)
    def counted(*args: Any, **kwargs: Any) -> Any:
        """Write, count the write."""
        global writes
        try:
            return func(*args, **kwargs)
        finally:
            writes += 1

    return cast(F, counted)


@_best_effort(lambda: None)
@_write
def add(row: DownloadRow) -> int | None:
    """Add the download at the end of the queue (its `position` set). Return its ID, None if it was not written."""
    with db.cursor(write=True) as cur:
        cur.execute('SELECT MAX("position") AS last FROM download')
        last = cur.fetchone()['last']
        row.position = 0 if last is None else last + 1
        if not row.created_at:
            row.created_at = int(time())
        cur.add(row)
    return row.id


@_best_effort(lambda: None)
def get(download_id: int) -> Optional[DownloadRow]:
    """Return the download, None if there is none."""
    with db.cursor() as cur:
        return cur.exec(select(DownloadRow).where(DownloadRow.id == download_id)).first()


@_best_effort(list)
def rows() -> list[DownloadRow]:
    """Return all downloads in the order of the queue."""
    with db.cursor() as cur:
        return list(cur.exec(select(DownloadRow).order_by(DownloadRow.position, DownloadRow.id)).all())


@_best_effort(lambda: False)
def has_queued() -> bool:
    """Return True if the queue has a download to do (`queued`)."""
    with db.cursor() as cur:
        cur.execute('SELECT 1 FROM download WHERE "state" = \'queued\' LIMIT 1')
        return cur.fetchone() is not None


@_best_effort(lambda: False)
@_write
def set_fields(download_id: int, **fields: Any) -> bool:
    """Set the columns of the download (`DownloadRow` fields). Return True if it was written."""
    with db.cursor(write=True) as cur:
        cur.exec(update(DownloadRow).set(**fields).where(DownloadRow.id == download_id))
    return True


@_best_effort(lambda: False)
@_write
def move_first(download_id: int) -> bool:
    """Move the download to the start of the queue. Return True if it was written."""
    with db.cursor(write=True) as cur:
        cur.execute('SELECT MIN("position") AS first FROM download')
        first = cur.fetchone()['first']
        cur.exec(update(DownloadRow).set(position=(first or 0) - 1).where(DownloadRow.id == download_id))
    return True


@_best_effort(lambda: False)
@_write
def remove(download_ids: Collection[int]) -> bool:
    """Remove the downloads. Return True if it was written."""
    if download_ids:
        with db.cursor(write=True) as cur:
            cur.exec(delete(DownloadRow).where(IN(DownloadRow.id, list(download_ids))))
    return True


def remove_legacy_db(cur: DbCursor) -> None:
    """Fresh DB: remove the old DB of the downloads (`LEGACY_DB_FILE`, its history is not moved)."""
    db_manager.remove_db(LEGACY_DB_FILE)


#: Global downloads DB.
db: OrmDatabase = OrmDatabase('downloads', DownloadRow, version=DB_VERSION, on_create=remove_legacy_db)
