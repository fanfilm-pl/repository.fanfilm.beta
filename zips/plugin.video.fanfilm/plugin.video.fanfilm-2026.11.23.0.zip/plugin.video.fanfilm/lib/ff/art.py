
from __future__ import annotations
from enum import Enum, IntEnum
from typing import Sequence, Iterator, NamedTuple, ClassVar, TYPE_CHECKING, cast
from typing import List, Dict  # py3.8, class bases
from urllib.parse import quote
from attrs import frozen, field, fields, evolve
from .types import JsonData
from .item import ArtLabel
from ..defs import MediaRef
from ..kolang import L, LL, LazyLabel
from const import const

if TYPE_CHECKING:
    from .item import ArtValues
    from ..defs import FFRef


class ArtLang(Enum):
    NO = 0
    YES = 1
    FANART = 2
    EMPTY = 3


class ArtSortByKey(NamedTuple):
    """Sort images by key SettingsEnum. Must match to setting `image.sort_by`."""

    vote_average: Sequence[str]
    vote_count: Sequence[str]


class ArtQuality(IntEnum):
    """Image quality SettingsEnum. Must match to setting `image.quality`."""
    LOW = 0
    HIGH = 1
    BEST = 2

    THUMB = LOW


class ArtQualityParam(NamedTuple):
    """An image quality SettingsEnum. Must match to ArtQuality and setting `image.quality`."""

    low: str
    high: str
    best: str


@frozen
class ArtName:
    key: str
    quality: ArtQualityParam
    # thumb: str = field(default='w500', kw_only=True)


@frozen
class ArtDef:
    lang_type: ArtLang
    sources: Sequence[ArtName]

    def langs(self, *, yes: Sequence[str | None], no: Sequence[str | None] = (None,), skip_fanart: bool = False) -> Sequence[str | None]:
        """Get list of languages for this art definition."""
        if self.lang_type is ArtLang.NO:
            return no
        if self.lang_type is ArtLang.YES:
            return yes
        if self.lang_type is ArtLang.FANART:
            return [] if skip_fanart else no
        # ArtLang.EMPTY
        return []


class ImageSource(Enum):
    """The source of the images of the media (the setting `image_source`); TMDB is always the fallback."""

    #: TMDB only (no request of fanart.tv).
    TMDB = 'tmdb'
    #: TMDB, fanart.tv for what TMDB has not (clearart, discart, banner...).
    TMDB_FANART = 'tmdb+fanart'
    #: fanart.tv first, then TMDB: the language first (a Polish poster of TMDB over an English one of fanart.tv).
    FANART = 'fanart'

    @property
    def services(self) -> tuple[ArtService, ...]:
        """Return the art services in the order of the preference."""
        if self is ImageSource.TMDB:
            return (TmbdArtService.service,)
        if self is ImageSource.TMDB_FANART:
            return (TmbdArtService.service, FanartArtService.service)
        return (FanartArtService.service, TmbdArtService.service)

    @property
    def language_first(self) -> bool:
        """Return True if an image in a better language wins over the order of the services."""
        return self is ImageSource.FANART

    @property
    def fanart(self) -> bool:
        """Return True if fanart.tv is asked."""
        return self is not ImageSource.TMDB


#: The labels of the sources of the images (the options of the setting `image_source`).
image_source_labels: dict[ImageSource, LazyLabel] = {
    ImageSource.TMDB: LL(31172, 'TMDB'),
    ImageSource.TMDB_FANART: LL(31173, 'TMDB + fanart.tv'),
    ImageSource.FANART: LL(31174, 'fanart.tv + TMDB'),
}


@frozen(kw_only=True)
class ArtSettings:
    """Cache for settings for TMDB."""
    lang: str
    quality: ArtQuality
    sort_by: int
    #: The source of the images (not in the repr: the stamp of the parsed nodes has it only when not default, `stamp`).
    source: ImageSource = field(default=ImageSource.TMDB, repr=False)
    #: The background (fanart) of the media, else the one of FanFilm.
    fanart: bool = field(default=True, repr=False)

    @property
    def stamp(self) -> str:
        """Return the stamp of the parsed nodes: the repr, the settings out of it only when not default (the cached nodes stay valid)."""
        extra = ''.join(f', {f.name}={getattr(self, f.name)!r}' for f in fields(ArtSettings) if not f.repr and getattr(self, f.name) != f.default)
        return f'{self!r}{extra}'


@frozen(kw_only=True)
class ImageInfo:
    """Information about an image."""

    url: str
    lang: str = ''
    width: int = 0
    height: int = 0
    vote_average: float = 0.0
    vote_count: int = 0
    _thumb: str = ''

    def __bool__(self) -> bool:
        return bool(self.url)

    @property
    def thumb(self) -> str:
        """Get thumbnail URL."""
        return self._thumb or self.url

    @property
    def is_landscape(self) -> bool:
        """Return True if image is landscape."""
        return self.width >= self.height

    @property
    def is_portrait(self) -> bool:
        """Return True if image is portrait."""
        return self.height > self.width

    @property
    def aspect_ratio(self) -> float:
        """Get aspect ratio (width / height)."""
        return self.width / self.height if self.height != 0 else 0.0

    def art(self, art_type: ArtLabel, ref: FFRef | None = None, *, thumb: str | None = None) -> ArtValues:
        """Return art dict for Kodi."""
        art: dict[ArtLabel, str] = {art_type: self.url}
        if thumb is not None:
            art['thumb'] = thumb
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            is_episode = bool(ref and ref.ref.is_episode)
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        return art


class ArtInfo(Dict[ArtLabel, List[ImageInfo]]):
    """Information about images. Result of ArtService.parse_arts()."""

    def art(self, ref: FFRef | None = None, *, thumb: str | None = None) -> ArtValues:
        """Return art dict for Kodi."""
        art: dict[ArtLabel, str] = {key: images[0].url for key, images in self.items() if images}
        if thumb is not None:
            art['thumb'] = thumb
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            is_episode = bool(ref and ref.ref.is_episode)
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        return art

    def all_images(self) -> Iterator[ImageInfo]:
        """Iterate over all images."""
        for images in self.values():
            for img in images:
                yield img

    def all_urls(self) -> Iterator[str]:
        """Iterate over all image URLs."""
        for images in self.values():
            for img in images:
                yield img.url


#: An image candidate: its service, its art name (a list of the service), the raw image.
@frozen
class ArtCandidate:
    """A candidate image of an art type."""

    #: The service of the image.
    service: ArtService
    #: The art name (the list of the service) of the image.
    name: ArtName
    #: The raw image of the service.
    image: JsonData


class Art:

    def __init__(self) -> None:
        #: Setting cache.
        self._settings: ArtSettings | None = None

    def reset(self) -> None:
        """Reset settings."""
        self._settings = None

    @property
    def settings(self, lang: str | None = None) -> ArtSettings:
        """Get settings."""
        if self._settings is None:
            from .control import apiLanguage
            from .config import config
            self._settings = ArtSettings(
                lang=apiLanguage().get('tmdb', 'pl-PL'),
                quality=ArtQuality(config.media.image_quality),
                sort_by=config.media.image_order,
                source=ImageSource(config.media.image_source),
                fanart=config.media.fanart,
            )
        return self._settings

    @settings.deleter
    def settings(self) -> None:
        self._settings = None

    def _settings_with(self, quality: ArtQuality | None) -> ArtSettings:
        """Return the settings, with another quality if given."""
        return self.settings if quality is None else evolve(self.settings, quality=quality)

    @staticmethod
    def _langs(translation_order: Sequence[str] | None, settings: ArtSettings) -> tuple[str | None, ...]:
        """Return the languages of the images (no language last, None) of the translation order."""
        if translation_order is None:
            translation_order = (settings.lang, 'en-US', 'en-GB', 'en', 'xx-XX', 'xx', 'null')
        return (*dict.fromkeys(loc.partition('-')[0] for loc in translation_order), None)

    @staticmethod
    def candidates(aname: ArtLabel, data: dict[ArtService, JsonData], *,
                   services: Sequence[ArtService],
                   langs: Sequence[str | None],
                   sort_by: int,
                   language_first: bool = False,
                   is_episode: bool = False,
                   ) -> Iterator[ArtCandidate]:
        """
        Yield the images of the art type, the best first: of the services in their order (the first art name of a service with
        any image of the languages), or the languages first (`language_first`: an image in a better language of any service).
        """
        def groups(srv: ArtService) -> Iterator[tuple[str | None, list[ArtCandidate]]]:
            """Yield the images of the service by the languages (of its first art name with any of them)."""
            artdef = srv.art_names.get(aname)
            if artdef is None or (images := data.get(srv)) is None:
                return
            for src in artdef.sources:
                ilist = srv.images(images, src.key)
                if ilist:
                    found = False
                    for lang in artdef.langs(yes=langs, no=(None,), skip_fanart=is_episode):
                        # Przeglądając **po kolei** języki sortujemy po głosowaniu i wielkości (o ile klucze podane).
                        # reversed() daje nam ostatni z pasujących obrazów (oczywiście wśród `sort_by`), bo liczymy, że ten będzie lepszy.
                        best = sorted((im for im in reversed(ilist) if srv.lang(im) == lang), key=lambda im: srv.sort_key(im, sort_by))
                        if best:
                            found = True
                            yield lang, [ArtCandidate(service=srv, name=src, image=im) for im in best]
                    if found:
                        return

        if not language_first:
            for srv in services:
                for _, cands in groups(srv):
                    yield from cands
            return
        by_lang: dict[str | None, list[ArtCandidate]] = {}
        for srv in services:
            for lang, cands in groups(srv):
                by_lang.setdefault(lang, []).extend(cands)
        for lang in (*langs, None):
            yield from by_lang.pop(lang, ())

    def parse_art(self, *,
                  images: JsonData | None = None,
                  item: JsonData | None = None,
                  translation_order: Sequence[str] | None,
                  ref: MediaRef | None = None,
                  quality: ArtQuality | None = None
                  ) -> dict[str, str]:
        """Parse TMDB images (and fanart.tv ones of the item, `_fanart`) and retrun kodi art dict."""
        art_settings = self._settings_with(quality)
        is_episode = bool(ref and ref.is_episode)
        if images is None:
            if item is None:
                return {}
            images = item.get('images') or {}
        data = {TmbdArtService.service: images, FanartArtService.service: (item or {}).get('_fanart')}
        services = art_settings.source.services
        langs = self._langs(translation_order, art_settings)
        art: dict[str, str] = {}
        image_url = 'https://image.tmdb.org/t/p/{width}{path}'
        for aname in dict.fromkeys(name for srv in services for name in srv.art_names):
            cand = next(self.candidates(aname, data, services=services, langs=langs, sort_by=art_settings.sort_by,
                                        language_first=art_settings.source.language_first, is_episode=is_episode), None)
            if cand is not None:
                art[aname] = cand.service.url(cand.image, cand.name, art_settings.quality)
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        if item and (poster := item.get('poster_path')):
            art.setdefault('poster', image_url.format(width='w780', path=poster))
        if item and (landscape := item.get('still_path')):
            art.setdefault('landscape', image_url.format(width='w1280', path=landscape))
        if item and (backdrop := item.get('backdrop_path')):
            backdrop = image_url.format(width='w1280', path=backdrop)
            art.setdefault('fanart', backdrop)
            art.setdefault('landscape', backdrop)
        if item and (logo := item.get('logo_path')):
            art.setdefault('clearlogo', image_url.format(width='original', path=logo))
            art.setdefault('thumb', image_url.format(width='w500', path=logo))
        if not art_settings.fanart and 'fanart' in art:
            from .control import addonFanart
            art['fanart'] = addonFanart()
        return art

    def parse_arts(self, *,
                   images: JsonData | None = None,
                   item: JsonData | None = None,
                   fanart: JsonData | None = None,
                   translation_order: Sequence[str] | None,
                   ref: MediaRef | None = None,
                   quality: ArtQuality | None = None
                   ) -> ArtInfo:
        """Parse TMDB images and the fanart.tv ones (`fanart`: every service, the gallery) and retrun kodi art dict."""
        art_settings = self._settings_with(quality)
        is_episode = bool(ref and ref.is_episode)
        if images is None:
            if item is None:
                return ArtInfo()
            images = item.get('images') or {}
        data = {TmbdArtService.service: images, FanartArtService.service: fanart}
        source = art_settings.source
        services = source.services if source.fanart else (*source.services, FanartArtService.service)  # the gallery: both
        langs = self._langs(translation_order, art_settings)
        art = ArtInfo()
        for aname in dict.fromkeys(name for srv in services for name in srv.art_names):
            infos = {}
            for cand in self.candidates(aname, data, services=services, langs=langs, sort_by=art_settings.sort_by,
                                        language_first=source.language_first, is_episode=is_episode):
                info = cand.service.info(cand.image, cand.name, art_settings.quality)
                infos.setdefault(info.url, info)
            if infos:
                art[aname] = list(infos.values())
        return art


class ArtService:
    """An art service: its lists of images (`art_names`), the language and the votes of an image, its URL."""

    #: The service (one object: the key of the data of the services).
    service: ClassVar[ArtService]
    #: The key of the language of an image.
    lang_key: ClassVar[str]
    #: The languages of no language (an image without a text).
    no_langs: ClassVar[Sequence[str | None]]
    #: The keys of the votes of an image by the setting `image_order` (rating, number of votes).
    sort_by: ClassVar[ArtSortByKey]
    #: The art types (of Kodi) and the lists of the service with them, the better ones first.
    art_names: ClassVar[dict[ArtLabel, ArtDef]]

    def images(self, data: JsonData, key: str) -> list[JsonData]:
        """Return the images of the list `key` of the data of the service."""
        return data.get(key) or []

    def lang(self, image: JsonData) -> str | None:
        """Return the language of the image, None if it has no language."""
        lang = image.get(self.lang_key)
        return None if lang in self.no_langs else lang

    def sort_key(self, image: JsonData, sort_by: int) -> tuple[float, ...]:
        """Return the sort key of the image (the better first) by the setting `image_order`."""
        return tuple(-float(image.get(key) or 0) for key in self.sort_by[sort_by])

    def url(self, image: JsonData, name: ArtName, quality: ArtQuality) -> str:
        """Return the URL of the image in the quality."""
        raise NotImplementedError

    def thumb(self, image: JsonData, name: ArtName) -> str:
        """Return the URL of the thumbnail of the image."""
        return self.url(image, name, ArtQuality.THUMB)

    def info(self, image: JsonData, name: ArtName, quality: ArtQuality) -> ImageInfo:
        """Return the information of the image (the gallery)."""
        return ImageInfo(url=self.url(image, name, quality), thumb=self.thumb(image, name), lang=self.lang(image) or '',
                         width=int(image.get('width') or 0), height=int(image.get('height') or 0),
                         vote_average=float(image.get('vote_average') or 0.0), vote_count=int(image.get('vote_count') or image.get('likes') or 0))


class TmbdArtService(ArtService):
    """The Movie Database service."""

    # Opisy zmiennych są w ArtService

    movies_url = "https://api.themoviedb.org/3/movie/{media_id}/images?api_key={tm_user}"
    tvshows_url = "https://api.themoviedb.org/3/tv/{media_id}/images?api_key={tm_user}"
    image_url: str = "https://image.tmdb.org/t/p/{quality}{path}"

    lang_key = 'iso_639_1'
    no_langs = ('00', 'xx', None)
    sort_by = ArtSortByKey(['vote_average'], ['vote_count'])
    art_names: dict[ArtLabel, ArtDef] = {
        'fanart':    ArtDef(ArtLang.FANART, (  # no-lang
            ArtName('backdrops', ArtQualityParam('w780', 'w1280', 'w1280')),
            ArtName('stills', ArtQualityParam('w780', 'w1280', 'w1280')),
        )),
        'landscape': ArtDef(ArtLang.YES, (
            ArtName('backdrops', ArtQualityParam('w780', 'w1280', 'original')),
            ArtName('stills', ArtQualityParam('w780', 'w1280', 'original')),
        )),
        'poster':    ArtDef(ArtLang.YES, (
            ArtName('posters', ArtQualityParam('w500', 'w780', 'w780')),
        )),
        'clearlogo': ArtDef(ArtLang.YES, (
            ArtName('logos', ArtQualityParam('w500', 'w780', 'original')),
        )),
        'actor':    ArtDef(ArtLang.NO, (
            ArtName('profiles', ArtQualityParam('w500', 'w780', 'original')),
        )),
    }

    def images(self, data: JsonData, key: str) -> list[JsonData]:
        """Return the images of the list `key` (no SVG: Kodi does not show them)."""
        return [im for im in data.get(key) or () if not im['file_path'].endswith('.svg')]

    def url(self, image: JsonData, name: ArtName, quality: ArtQuality) -> str:
        """Return the URL of the image in the size of the quality."""
        return self.image_url.format(quality=name.quality[quality], path=image['file_path'])

    # TMDB image sizes (see https://api.themoviedb.org/3/configuration)
    # "images": {
    #   "base_url": "http://image.tmdb.org/t/p/",
    #   "secure_base_url": "https://image.tmdb.org/t/p/",
    #   "backdrop_sizes": [ "w300", "w780", "w1280", "original" ],
    #   "logo_sizes":     [ "w45", "w92", "w154", "w185", "w300", "w500", "original" ],
    #   "poster_sizes":   [ "w92", "w154", "w185", "w342", "w500", "w780", "original" ],
    #   "profile_sizes":  [ "w45", "w185", "h632", "original" ],
    #   "still_sizes":    [ "w92", "w185", "w300", "original" ]
    # }


#: All sizes of fanart.tv: the original image only (the thumbnail is its preview).
FANART_ORIGINAL: ArtQualityParam = ArtQualityParam('original', 'original', 'original')


class FanartArtService(ArtService):
    """The fanart.tv service (`lib.api.fanart`): the movies (`movie*`) and the TV shows (`tv*`, `show*`) in one declaration."""

    lang_key = 'lang'
    no_langs = ('', '00', None)
    sort_by = ArtSortByKey(['likes'], ['likes'])
    art_names: dict[ArtLabel, ArtDef] = {
        'fanart':       ArtDef(ArtLang.FANART, (ArtName('moviebackground', FANART_ORIGINAL), ArtName('showbackground', FANART_ORIGINAL))),
        'landscape':    ArtDef(ArtLang.YES, (ArtName('moviethumb', FANART_ORIGINAL), ArtName('tvthumb', FANART_ORIGINAL))),
        'poster':       ArtDef(ArtLang.YES, (ArtName('movieposter', FANART_ORIGINAL), ArtName('tvposter', FANART_ORIGINAL))),
        'clearlogo':    ArtDef(ArtLang.YES, (ArtName('hdmovielogo', FANART_ORIGINAL), ArtName('hdtvlogo', FANART_ORIGINAL),
                                             ArtName('movielogo', FANART_ORIGINAL), ArtName('clearlogo', FANART_ORIGINAL))),
        'clearart':     ArtDef(ArtLang.YES, (ArtName('hdmovieclearart', FANART_ORIGINAL), ArtName('hdclearart', FANART_ORIGINAL),
                                             ArtName('movieart', FANART_ORIGINAL), ArtName('clearart', FANART_ORIGINAL))),
        'discart':      ArtDef(ArtLang.YES, (ArtName('moviedisc', FANART_ORIGINAL),)),
        'banner':       ArtDef(ArtLang.YES, (ArtName('moviebanner', FANART_ORIGINAL), ArtName('tvbanner', FANART_ORIGINAL))),
        'characterart': ArtDef(ArtLang.NO, (ArtName('characterart', FANART_ORIGINAL),)),
    }
    #: The lists of the seasons in the answer of a show (an image has its `season`) -> the lists of a season (its art as the one of a show).
    season_names: ClassVar[dict[str, str]] = {'seasonposter': 'tvposter', 'seasonthumb': 'tvthumb', 'seasonbanner': 'tvbanner'}

    @classmethod
    def season_part(cls, data: JsonData, season: int) -> JsonData:
        """Return the images of the season from the answer of its show (the images of all the seasons only if it has none of its own)."""
        part: JsonData = {}
        for key, season_key in cls.season_names.items():
            images = data.get(key) or ()
            own = [im for im in images if str(im.get('season')) == str(season)]
            if found := own or [im for im in images if im.get('season') == 'all']:
                part[season_key] = found
        return part

    def url(self, image: JsonData, name: ArtName, quality: ArtQuality) -> str:
        """Return the URL of the image (the original one in every quality; some URLs of fanart.tv have spaces)."""
        return quote(image['url'], safe="%/:=&?~#+!$,;'@()*[]")

    def thumb(self, image: JsonData, name: ArtName) -> str:
        """Return the URL of the preview of the image (200 px wide)."""
        return self.url(image, name, ArtQuality.THUMB).replace('.fanart.tv/fanart/', '.fanart.tv/preview/')


TmbdArtService.service = TmbdArtService()
FanartArtService.service = FanartArtService()


@frozen
class ArtTypeLabel:
    """The labels of an art type: one image (a gallery item, a folder) and the images (a gallery title)."""

    #: One image, e.g. "Poster" (a gallery item "Poster 3").
    one: str
    #: The images, e.g. "Posters" (a gallery title "Matrix – Posters").
    many: str


#: The labels of the art types (the actor art type is the photo of a person).
art_type_translations: dict[ArtLabel, ArtTypeLabel] = {
    'thumb': ArtTypeLabel(one=L(30703, 'Picture'), many=L(30374, 'Pictures')),
    'fanart': ArtTypeLabel(one=L(30704, 'Fanart'), many=L(30487, 'Fanarts')),
    'landscape': ArtTypeLabel(one=L(30705, 'Landscape'), many=L(30488, 'Landscapes')),
    'poster': ArtTypeLabel(one=L(30706, 'Poster'), many=L(30494, 'Posters')),
    'clearlogo': ArtTypeLabel(one=L(30707, 'Logo'), many=L(30496, 'Logos')),
    'clearart': ArtTypeLabel(one=L(31180, 'Clear art'), many=L(31181, 'Clear arts')),
    'discart': ArtTypeLabel(one=L(31182, 'Disc art'), many=L(31183, 'Disc arts')),
    'banner': ArtTypeLabel(one=L(31184, 'Banner'), many=L(31185, 'Banners')),
    'characterart': ArtTypeLabel(one=L(31186, 'Character art'), many=L(31187, 'Character arts')),
    'actor': ArtTypeLabel(one=L(30538, 'Photo'), many=L(30572, 'Photos')),
}


def art_type_label(art_type: ArtLabel) -> ArtTypeLabel:
    """Return the labels of the art type, its name if it has none."""
    return art_type_translations.get(art_type) or ArtTypeLabel(one=art_type, many=art_type)


def list_art(art: ArtValues) -> ArtValues:
    """Return the art of a list of a service (its own image or the images of its first item): a poster is the thumb too (`const.indexer.art.fake_thumb`)."""
    if const.indexer.art.fake_thumb and (poster := art.get('poster')):
        return {'thumb': poster, **art}
    return art


def tmdb_list_art(item: JsonData) -> ArtValues:
    """Return the art of a list of a service from the TMDB paths of its first item (`poster_path`, `backdrop_path`)."""
    return list_art(cast('ArtValues', Art().parse_art(item=item, translation_order=None)))
