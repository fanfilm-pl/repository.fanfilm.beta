"""
The state of the versions of FanFilm (no setting: in the persistent state, `version_state()`): the version at the last start of the
service, the version of the changelog shown.
"""

from __future__ import annotations

#: The state of the versions (`version_state()`): the version at the last start of the service, the version of the changelog shown.
ADDON_VERSION_STATE: str = 'addon.version'
CHANGELOG_VERSION_STATE: str = 'changelog.version'
#: The module of the state of the versions.
VERSION_STATE_MODULE: str = 'version'


def version_state(key: str) -> str:
    """
    Return a version of the state (`ADDON_VERSION_STATE`, `CHANGELOG_VERSION_STATE`); none there yet: the one an older FanFilm kept in the user
    settings of Kodi ('' none), written to the state at once (the cleaning of the old settings removes it from the user file).
    """
    from .db import state
    from .settings import settings
    from const import StateMode
    if version := state.get(key, module=VERSION_STATE_MODULE, mode=StateMode.DB):
        return version
    if version := settings.user_values().get(key, ''):
        set_version_state(key, version)
    return version


def set_version_state(key: str, version: str) -> None:
    """Set a version of the state (`ADDON_VERSION_STATE`, `CHANGELOG_VERSION_STATE`)."""
    from .db import state
    from const import StateMode
    state.set(key, version, module=VERSION_STATE_MODULE, mode=StateMode.DB)
