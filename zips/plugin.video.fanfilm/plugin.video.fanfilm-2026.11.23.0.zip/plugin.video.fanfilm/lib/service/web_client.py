"""
The client of the FF web server of another FanFilm (`web_server.Server`): the key agreement of a pairing, a request for the access (approved
on the other Kodi), signed and sealed requests of the paired device - the same protocol as the page and the browser script (`web/mod/ffauth.js`,
`web/mod/fanfilm.user.js`), made of `web_crypto` and `web_auth`. This FF forwards the cookies it receives (the browser script, the Cloudflare
server) to its targets (`targets()`: the other FanFilm paired with it as a browser script, `forward_cookies()`).
"""

from __future__ import annotations
from typing import Any, Iterable, Mapping, TYPE_CHECKING
import base64
import json
import time
from attrs import asdict, evolve, frozen
from . import web_crypto
from .web_auth import (DEVICE_HEADER, PAIR_HEADER, SCRIPT_CLIENT, SEALED, SIGNATURE_HEADER, TIME_HEADER, b64, request_signature)
from ..ff.config import config, escape_key
from ..ff.logs import fflog
from ..ff.types import JsonData
from ..ff.web_settings import TARGETS_CONFIG
from ..kolang import LL
from const import const
if TYPE_CHECKING:
    from ..kolang import LazyLabel

#: The result of the last forward to a target: sent, the target removed this FF (it pairs again), failed (no answer: sent again next time).
SENT: str = 'sent'
UNPAIRED: str = 'unpaired'
FAILED: str = 'failed'
#: The texts of the results of a forward.
RESULT_LABELS: Mapping[str, LazyLabel] = {SENT: LL(31346, 'sent'), UNPAIRED: LL(31347, 'unpaired: add it again'), FAILED: LL(31348, 'not sent')}


@frozen(kw_only=True)
class Answer:
    """An answer of the server: its status and its JSON (a sealed one opened; None: not JSON)."""

    #: The HTTP status.
    status: int
    #: The JSON of the answer.
    json: Any = None

    @property
    def error(self) -> str:
        """Return the error the server told ('' none)."""
        return str(self.json.get('error', '')) if isinstance(self.json, Mapping) else ''


@frozen(kw_only=True)
class Agreement:
    """A key agreement of a pairing (`/pair/key`): its ID and the key of its seals."""

    #: Its ID (`PAIR_HEADER`).
    sid: str
    #: The key of its seals.
    key: bytes

    @property
    def device_key(self) -> bytes:
        """Return the key of the device paired by it."""
        return web_crypto.device_key(self.key)


@frozen(kw_only=True)
class Signed:
    """A request of a paired device: its body (sealed), its headers (the signature), the binding of the seal of its answer."""

    #: The body.
    body: bytes
    #: The headers.
    headers: dict[str, str]
    #: The binding of the answer (the signature).
    answer: bytes


def sealed_body(key: bytes, data: Any, binding: bytes) -> bytes:
    """Return the body of the JSON data sealed by the key (`{"sealed": ...}`)."""
    content = json.dumps(data).encode()
    return json.dumps({SEALED: web_crypto.seal(key, content, binding=binding, direction=web_crypto.REQUEST)}).encode()


def signed_request(key: bytes, device: str, method: str, path: str, data: Any = None, *, stamp: str | None = None) -> Signed:
    """Return the signed request of a device (its content sealed bound to the time of its signature), `stamp` the time (now)."""
    stamp = f'{time.time():.6f}' if stamp is None else stamp
    body = b'' if data is None else sealed_body(key, data, f'{method}\n{path}\n{stamp}'.encode())
    signature = request_signature(key.hex(), method, path, stamp, body)
    headers = {DEVICE_HEADER: device, TIME_HEADER: stamp, SIGNATURE_HEADER: signature, **({'Content-Type': 'application/json'} if body else {})}
    return Signed(body=body, headers=headers, answer=signature.encode())


def opened(key: bytes, data: Any, binding: bytes) -> Any:
    """Return the JSON of an answer opened (sealed by the key bound to `binding`), as it is if not sealed; a broken seal: `OSError`."""
    if isinstance(data, Mapping) and set(data) == {SEALED}:
        try:
            return json.loads(web_crypto.unseal(key, str(data[SEALED]), binding=binding, direction=web_crypto.ANSWER))
        except ValueError as exc:  # `SealError` too
            raise OSError(f'broken seal of the answer: {exc}') from exc
    return data


class WebClient:
    """The client of the web server of another FanFilm at its address (`http://<address>:<port>`)."""

    def __init__(self, base: str, *, timeout: float | None = None) -> None:
        """The client of the server; no connection yet."""
        #: The address of the server.
        self.base: str = base.rstrip('/')
        #: The time limit of a request [s].
        self.timeout: float = const.tune.service.web_server.relay.timeout if timeout is None else timeout
        #: The difference of the clock of the server (its time told by a refused signature).
        self.offset: float = 0

    def _send(self, method: str, path: str, body: bytes, headers: dict[str, str]) -> tuple[int, Any]:
        """Return the status and the JSON of a request (None: not JSON); no answer: `OSError`."""
        from ..ff import requests
        try:
            resp = requests.request(method, f'{self.base}{path}', data=body or None, headers=headers, timeout=self.timeout)
        except requests.RequestException as exc:
            raise OSError(str(exc)) from exc
        try:
            return resp.status_code, resp.json()
        except ValueError:
            return resp.status_code, None

    def agree(self) -> Agreement:
        """Return a new key agreement of a pairing; refused: `OSError`."""
        secret = web_crypto.new_secret()
        public = web_crypto.public_key(secret)
        status, data = self._send('POST', '/pair/key', json.dumps({'key': b64(public)}).encode(), {'Content-Type': 'application/json'})
        if status != 200 or not isinstance(data, Mapping):
            raise OSError(f'key agreement: {status} {data}')
        try:  # another server at the address: no FanFilm
            server = base64.b64decode(str(data['key']), validate=True)
            return Agreement(sid=str(data['sid']), key=web_crypto.pairing_key(secret, server, public + server + str(data['sid']).encode()))
        except (KeyError, ValueError) as exc:
            raise OSError(f'key agreement: {exc}') from exc

    def pair_call(self, method: str, path: str, agreement: Agreement, data: Any = None) -> Answer:
        """Return the answer of a request of a pairing sealed by its key agreement."""
        binding = f'{method}\n{path}\n{agreement.sid}'.encode()
        body = b'' if data is None else sealed_body(agreement.key, data, binding)
        headers = {PAIR_HEADER: agreement.sid, **({'Content-Type': 'application/json'} if body else {})}
        status, answer = self._send(method, path, body, headers)
        return Answer(status=status, json=opened(agreement.key, answer, binding))

    def call(self, key: bytes, device: str, method: str, path: str, data: Any = None) -> Answer:
        """
        Return the answer of a request of the paired device (signed, sealed); its clock corrected once after a refused time. No answer, a
        broken one: `OSError`.
        """
        for _ in range(2):
            req = signed_request(key, device, method, path, data, stamp=f'{time.time() + self.offset:.6f}')
            status, answer = self._send(method, path, req.body, req.headers)
            result = Answer(status=status, json=opened(key, answer, req.answer))
            if status == 401 and result.error == 'time' and isinstance(result.json.get('time'), (int, float)):
                self.offset = result.json['time'] - time.time()
                continue
            return result
        return result


# --- the targets of the forwarded cookies ---

@frozen(kw_only=True)
class Target:
    """Another FanFilm this one forwards the cookies to: paired with it as a browser script (its device there, the key of the device)."""

    #: Its ID (the one of the other FanFilm: its instance).
    id: str
    #: Its name (the name of its Kodi).
    name: str
    #: The address of its web server.
    address: str
    #: The ID of this FF as its device.
    device: str
    #: The key of the device (hex).
    key: str
    #: The result of the last forward (`SENT`, `UNPAIRED`, `FAILED`; '' none yet).
    result: str = ''
    #: The time of the last forward.
    time: float = 0

    def to_json(self) -> JsonData:
        """Return the stored data."""
        return asdict(self)


def targets() -> list[Target]:
    """Return the targets (a broken entry skipped)."""
    found: list[Target] = []
    for tid, data in (config.get(TARGETS_CONFIG) or {}).items():
        try:
            found.append(Target(**data))
        except TypeError:
            fflog.warning(f'[WEB] broken target {tid}: skipped')
    return sorted(found, key=lambda target: target.name)


def save_target(target: Target) -> None:
    """Store the target (a new one, or its new state)."""
    config.set(f'{TARGETS_CONFIG}/{escape_key(target.id)}', target.to_json())


def remove_target(target: Target) -> None:
    """Unpair this FF on the target (its answer not waited for: removed here anyway) and remove it."""
    try:
        WebClient(target.address).call(bytes.fromhex(target.key), target.device, 'POST', '/pair/logout', {})
    except OSError as exc:
        fflog(f'[WEB] target {target.name!r} not told of its removal: {exc}')
    config.remove(f'{TARGETS_CONFIG}/{escape_key(target.id)}')


def forward_cookies(payloads: Iterable[JsonData], only: Iterable[Target] | None = None) -> None:
    """
    Send the cookies (`POST /cookies` payloads, marked `relayed`: not forwarded again) to the targets (`only` some of them), their results
    stored: sent, unpaired (the target removed this FF), failed.
    """
    payloads = [{**payload, 'relayed': True} for payload in payloads]
    if not payloads:
        return
    for target in (targets() if only is None else only):
        client = WebClient(target.address)
        result = SENT
        try:
            for payload in payloads:
                answer = client.call(bytes.fromhex(target.key), target.device, 'POST', '/cookies', payload)
                if answer.status == 401:
                    result = UNPAIRED
                    break
                if answer.status != 200:
                    result = FAILED
        except OSError as exc:
            fflog(f'[WEB] cookies not forwarded to {target.name!r}: {exc}')
            result = FAILED
        fflog(f'[WEB] cookies forwarded to {target.name!r}: {result}')
        pointer = f'{TARGETS_CONFIG}/{escape_key(target.id)}'
        with config.batch() as block:  # removed meanwhile (the window of the configuration): not back
            if isinstance(stored := block.get(pointer), dict) and stored.get('device') == target.device:
                config.set(pointer, evolve(target, result=result, time=time.time()).to_json())


def request_pairing(address: str, name: str) -> tuple[Agreement, Answer]:
    """Ask another FanFilm for the access as a browser script (approved on its Kodi): the key agreement and the request; `OSError`."""
    client = WebClient(address)
    agreement = client.agree()
    return agreement, client.pair_call('POST', '/pair/request', agreement, {'client': SCRIPT_CLIENT, 'name': name})
