"""
The advanced search of movies / shows on the web page (`web_server.Server`, the routes `/search/…`): the fields of `lib.ff.discover`
(one declaration with the window of Kodi) with their choices, the number of the found media, the found choices of TMDB (keywords, people),
the history of the search; "Show in Kodi" (a new entry of the history, its found items opened in Kodi - playing: none, the page tells it)
and "Save as a FanFilm list" (a dynamic list of the search). The values of the page are checked by the declaration (`values_filters()`):
a value of no choice or off the scale is an error.
"""

from __future__ import annotations
from typing import Any, Mapping, TYPE_CHECKING
from ..api.tmdb import filter_ids
from ..ff.discover import ANY_LABEL, Chosen, DiscoverField, DiscoverMedia, GROUPS, choices, describe, media_fields
from ..ff.types import JsonData
from ..kolang import L
if TYPE_CHECKING:
    from ..ff.gui.scale import Scale
    from ..indexers.search import Search

#: The media of the advanced search (the search of TMDB: the movies, the shows).
MEDIA: tuple[DiscoverMedia, ...] = ('movie', 'show')
#: The found choices of TMDB at most (a lookup of a keyword, a person).
LOOKUP_LIMIT: int = 20


def search_of(media: str) -> Search:
    """Return the search of the media (its indexer: the final filters, the found items, the history); ValueError for an unknown media."""
    from ..indexers.navigator import nav
    if media not in MEDIA:
        raise ValueError(f'no media {media!r}')
    return nav.movie.search if media == 'movie' else nav.show.search


def field_json(field: DiscoverField, media: DiscoverMedia) -> JsonData:
    """
    Return a field for the page: its key, label, group, kind, the choices of a list (value, label), the positions of a scale (any whole
    number typed in too: `typed`).
    """
    data: JsonData = {'key': field.key, 'label': field.label, 'group': field.group, 'kind': field.kind, 'exclude': bool(field.exclude),
                      'lookup': field.source if field.kind == 'lookup' else ''}
    if field.kind in ('grid', 'multi', 'choice'):
        data['choices'] = [{'value': value, 'label': label} for value, label in choices(field.source, media).items()]
    if field.scale is not None:
        scale = field.scale()
        data['positions'] = [{'value': scale.value_at(pos), 'text': scale.text(pos)} for pos in range(scale.last + 1)]
        if (decimals := scale.decimals) is not None:  # any number typed in too (a whole one: the number dialog of the window)
            data['typed'] = True
            if decimals:
                data['decimals'] = decimals
    return data


def schema(media: str) -> JsonData:
    """Return the advanced search of the media for the page: the groups (the tabs), the fields, the values of no choice (the defaults)."""
    search = search_of(media)
    fields = media_fields(search.type)  # type: ignore[arg-type]
    return {'media': search.type, 'groups': [{'name': group.name, 'title': group.title} for group in GROUPS],
            'fields': [field_json(field, search.type) for field in fields],  # type: ignore[arg-type]
            'defaults': values_json(fields, '', default_filters(search)), 'any': ANY_LABEL}


def default_filters(search: Search) -> dict[str, Any]:
    """Return the filters of no choice of the search: the least votes and the order of the settings (as the window)."""
    from ..ff.discover import filter_pairs
    indexer: Any = search.indexer
    return dict(filter_pairs({key: value for key, value in indexer.discover_filters().items() if key in ('vote_count', 'sort_by')}))


def values_json(fields: tuple[DiscoverField, ...], query: str, filters: Mapping[str, Any]) -> JsonData:
    """Return the values of the fields of the filters for the page (several: with, without, every; a range: a pair, 0 no limit)."""
    values: JsonData = {}
    for field in fields:
        value = query if field.kind == 'text' else field.read(filters)
        if isinstance(value, Chosen):
            value = {'with': list(value.with_ids), 'without': list(value.without_ids), 'every': value.every}
        elif isinstance(value, tuple):
            value = list(value)
        values[field.key] = value
    return values


def _typed(scale: Scale, number: Any) -> bool:
    """Return True for a number typed in of the scale (`Scale.decimals`): between its edges, of its decimal places at most."""
    places = scale.decimals
    return (places is not None and isinstance(number, (int, float)) and not isinstance(number, bool) and scale.entered(number) == number
            and round(number, places) == number)


def values_filters(media: DiscoverMedia, values: Mapping[str, Any]) -> tuple[str, dict[str, Any]]:
    """
    Return the text and the filters of TMDB of the values of the page (`values_json()`), checked by the declaration: a choice of none
    of the list, a number of no position of the scale, a wrong type - ValueError.
    """
    query, filters = '', {}
    for field in media_fields(media):
        if (value := values.get(field.key)) is None:
            continue
        kind = field.kind
        if kind == 'text':
            if not isinstance(value, str):
                raise ValueError(f'{field.key}: not a text')
            query = value.strip()
            continue
        if kind in ('grid', 'lookup', 'multi'):
            if not isinstance(value, Mapping):
                raise ValueError(f'{field.key}: not a choice')
            known = None if kind == 'lookup' else set(choices(field.source, media))
            ids = {part: tuple(str(code) for code in value.get(part) or ()) for part in ('with', 'without')}
            if known is not None and (wrong := {*ids['with'], *ids['without']} - known):
                raise ValueError(f'{field.key}: no choice {", ".join(sorted(wrong))}')
            if kind == 'lookup' and any(not code.isdigit() for code in (*ids['with'], *ids['without'])):
                raise ValueError(f'{field.key}: not an ID of TMDB')
            chosen = Chosen(with_ids=ids['with'], without_ids=ids['without'] if field.exclude else (), every=bool(value.get('every', True)))
            filters.update(field.write(chosen))
        elif kind == 'choice':
            if not isinstance(value, str) or value and value not in choices(field.source, media):
                raise ValueError(f'{field.key}: no choice {value!r}')
            filters.update(field.write(value))
        elif kind in ('range', 'minimum') and field.scale is not None:
            numbers = list(value) if kind == 'range' and isinstance(value, (list, tuple)) else [value]
            scale = field.scale()
            allowed = {scale.value_at(pos) for pos in range(scale.last + 1)}
            typed = [_typed(scale, number) for number in numbers]  # off the steps too
            if len(numbers) != (2 if kind == 'range' else 1) or any(number not in allowed and not ok for number, ok in zip(numbers, typed)):
                raise ValueError(f'{field.key}: not a value of the scale {value!r}')
            filters.update(field.write(tuple(numbers) if kind == 'range' else numbers[0]))
    return query, filters


def count(media: str, values: Mapping[str, Any]) -> JsonData:
    """Return the number of the found media of the values (the first page of the discovery: the same one the found items read)."""
    search = search_of(media)
    query, filters = values_filters(search.type, values)  # type: ignore[arg-type]
    indexer: Any = search.indexer
    items = indexer.search_found(query, page=1, type=search.type, **{'sort_by': 'popularity.desc', **filters})
    return {'count': getattr(items, 'total_results', None)}


def lookup(kind: str, text: str) -> JsonData:
    """Return the found choices of TMDB of the text (a keyword, a person): their IDs and names."""
    from ..api.tmdb import tmdb_app
    if kind not in {field.source for field in media_fields('movie') + media_fields('show') if field.kind == 'lookup'}:
        raise ValueError(f'no lookup {kind!r}')
    if not (text := text.strip()):
        return {'found': []}
    found = tmdb_app.search(type=kind, query=text)  # type: ignore[arg-type]
    return {'found': [{'id': str(it.ref.tmdb_id), 'name': it.label} for it in list(found)[:LOOKUP_LIMIT] if it.ref.tmdb_id]}


def history(media: str) -> JsonData:
    """Return the history of the search of the media: its entries (the text and a short description of the filters, the values)."""
    from ..ff.db.search import get_search_history
    search = search_of(media)
    fields = media_fields(search.type)  # type: ignore[arg-type]
    entries = []
    for sit in get_search_history(search.name):
        query, filters, names = search.entry_filters(sit)
        text = describe(search.type, filters, names)  # type: ignore[arg-type]
        entries.append({'id': sit.id, 'query': query, 'description': text, 'names': names, 'values': values_json(fields, query, filters)})
    return {'entries': entries}


def entry_options(filters: Mapping[str, Any], names: Mapping[str, Any]) -> dict[str, Any]:
    """Return the options of an entry of the history of the filters (the names of the found choices: only the chosen ones, as texts)."""
    from ..ff.discover import filters_text
    chosen = {code for key, value in filters.items() if key in ('with_keywords', 'without_keywords', 'with_people') for code in filter_ids(str(value))}
    options: dict[str, Any] = {'discover': filters_text(filters)}
    if found := {str(code): str(name) for code, name in names.items() if str(code) in chosen}:
        options['names'] = found
    return options


def send(media: str, values: Mapping[str, Any], names: Mapping[str, Any]) -> JsonData:
    """
    Keep the search as a new entry of the history and open its found items in Kodi (in a folder of FanFilm: there, else the videos
    window); Kodi playing: nothing opened, the page tells it.
    """
    import xbmc
    from ..ff.control import open_folder
    from ..ff.db.search import set_search_item
    search = search_of(media)
    query, filters = values_filters(search.type, values)  # type: ignore[arg-type]
    sid = set_search_item(name=search.name, type=search.type, query=query, options=entry_options(filters, names))
    if xbmc.Player().isPlaying():
        return {'id': sid, 'opened': False, 'message': str(L(31418, 'Kodi is playing: the search is in its history'))}
    open_folder(str(search.entry_url(sid)))
    return {'id': sid, 'opened': True, 'message': str(L(31419, 'Opened in Kodi'))}


def save(media: str, values: Mapping[str, Any], name: str) -> JsonData:
    """Save the search as a dynamic list of FanFilm of the name; ValueError: no name, the name is taken."""
    search = search_of(media)
    query, filters = values_filters(search.type, values)  # type: ignore[arg-type]
    from ..ff.ownlists import own_db
    if not (name := name.strip()):
        raise ValueError('no name')
    if own_db.folder(name) is not None:
        raise ValueError(str(L(31403, 'The list exists already')))
    if not search.create_list(name, query, filters):
        raise ValueError(str(L(31421, 'The list is not saved (the log tells why)')))
    return {'name': name, 'message': str(L(31420, 'Saved as a FanFilm list'))}
