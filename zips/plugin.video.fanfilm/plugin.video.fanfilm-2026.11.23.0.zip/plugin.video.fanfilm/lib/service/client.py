"""
Simple FF Service client to use it in FF plugin.
"""

from __future__ import annotations
from typing import Optional, Union, Any, Dict, Iterable, Mapping, Sequence, Iterator, ClassVar, overload, TYPE_CHECKING
from typing_extensions import Literal
from contextlib import contextmanager
from time import monotonic
import json
import requests
from attrs import asdict

from ..ff.logs import fflog, fflog_exc
from ..ff.url import URL
from ..ff.kotools import xsleep
from ..ff.db import state
from ..defs import MediaRef
from ..ff.tricks import JsonEncoder
from ..ff.threads import Thread
from . import running_works, local_works, service_ended
from .misc import PluginRequestInfo, serialize, StateVar, LibraryAutoAddSource, folder_wait
from ..kolang import L
if TYPE_CHECKING:
    from ..ff.item import FFItem
    from ..ff.types import JsonData
    from ..ff.downloads import DownloadRequest, DownloadsSnapshot, DownloadAction, DownloadsCall, DownloadAdded, DownloadLink
    from .misc import VolatileFfid
    from .main import Works
from const import const, StateMode


class IncorrectResponse(ValueError):
    @property
    def data(self):
        return self.args[0] if self.args else None


def _json_copy(value: Any) -> JsonData:
    """Return the JSON form of `value` as sent over HTTP (a copy of the static data only)."""
    return json.loads(json.dumps(value, cls=JsonEncoder))


class ServiceEnded(requests.ConnectionError):
    """The service of this interpreter ended (its calls still end): no request to it (the handlers of a failed connection take it)."""


class ServiceClient:
    """Simple FF Service client."""

    LOG_EXCEPTION: ClassVar[bool] = True
    FAKE: ClassVar[bool] = False

    def __init__(self, *, port: Optional[int] = const.tune.service.http_server.port) -> None:
        self._url: str | None = None
        self._volatile_ffid: VolatileFfid | None = None
        #: The end of the wait for the service in this plugin call (None: no wait yet), see `_wait_left()`.
        self._deadline: float | None = None
        #: A call of this interpreter found no service (RAM only): the next calls wait `retry_timeout`, not `startup_timeout`.
        self._missing: bool = False
        if port:
            self._url = f'http://127.0.0.1:{port}/'

    @overload
    def _make_url(self, *, connect: Literal[True] = True) -> str: ...

    @overload
    def _make_url(self, *, connect: Literal[False]) -> str | None: ...

    def _make_url(self, *, connect: bool = True) -> str | None:
        """
        Service HTTP server URL; without the service an invalid one, after the wait of the plugin call (`_wait_left()`). Raise
        `ServiceEnded` in the interpreter of the ended service.
        """
        if service_ended():
            fflog.debug('[SERVICE] ended: no request to it')
            raise ServiceEnded('the service ended')
        waited = False
        while self._url is None:
            if url := self._stored_url():
                self.set_url(url)
                break
            if not connect:
                return None
            if self.FAKE:
                self._url = 'http://127.0.0.1:8123/'
                break
            if self._wait_left() <= 0:
                if waited:
                    fflog('ERROR: No FF service URL')
                self._missing = True
                return 'http://127.0.0.1:8123/'  # invalid URL (invalid port)
            waited = True
            if self._wait_for_service() and not self._stored_url():
                xsleep(const.tune.service.http_server.wait_for_url or .01)  # it answered, its URL is not stored yet
        return self._url

    def reset(self) -> None:
        """New plugin call (a reused interpreter): a new wait for the service, `retry_timeout` if a call found none."""
        self._deadline = None

    def set_url(self, url: str) -> None:
        """Set the service URL (stored or announced by the service): the service is there."""
        self._url = url
        self._missing = False

    def _wait_left(self) -> float:
        """
        Return the time this plugin call may still wait for the service: `startup_timeout` in all (from its first wait),
        `retry_timeout` if a call of this interpreter found no service.
        """
        if self._deadline is None:
            timeout = const.tune.service.retry_timeout if self._missing else const.tune.service.startup_timeout
            self._deadline = monotonic() + (timeout or 0)
        return max(0.0, self._deadline - monotonic())

    @property
    def url(self) -> str:
        """Service HTTP server URL."""
        return self._make_url()

    @contextmanager
    def log_conn(self) -> Iterator[None]:
        try:
            yield None
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')

    def post(self, url: str | bytes, data: Any | None = None, json: Any | None = None, **kwargs) -> requests.Response:
        try:
            if json is not None:
                json = serialize(json)
            return requests.post(url, data=data, json=json, **kwargs)
        except TypeError:
            import json as json_mod
            fflog.error('JSON FAILED: {json!r}')
            headers = {**(kwargs.pop('headers', None) or {}), 'Content-Type': 'application/json'}  # the service reads only declared JSON
            return requests.post(url, data=json_mod.dumps(json, cls=JsonEncoder), headers=headers, **kwargs)

    def _stored_url(self) -> str | None:
        """Service HTTP server URL from the state DB, written by the service of this Kodi run (None if there is none)."""
        return state.get('url', module='service', mode=StateMode.DB, from_boot=True)

    def _wait_for_service(self) -> bool:
        """Wait for service to be available (its URL in the state DB, or its answer), the time left of the plugin call."""
        from ..ff.kotools import KodiRpc, Notification
        from ..ff.control import is_plugin_folder
        if (timeout := self._wait_left()) <= 0:
            return bool(self._stored_url())

        def ready() -> bool:
            """The service has written its URL already."""
            return bool(self._stored_url())

        if is_plugin_folder():
            with Notification('FanFilm', L(30475, 'Waiting for service...')):
                return KodiRpc().wait_for_service(timeout=timeout, ready=ready)
        else:
            return KodiRpc().wait_for_service(timeout=timeout, ready=ready)

    def folder_ready(self, *, timeout: Optional[float] = None) -> bool:
        """Wait for folder ready (watching progress update)."""
        if timeout is None:
            timeout = const.folder.lock_wait_timeout
        if (works := local_works()) is not None:
            return folder_wait(works.events.get('folder'), timeout)  # an aborted call waits to the timeout (no cut connection)
        try:
            data = self.post(f'{self.url}folder/ready', timeout=timeout + 0.5, json={'timeout': timeout}).json()
            return data.get('ready', False)
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
            return False

    def plugin_request_info(self) -> PluginRequestInfo:
        """Get folder info."""
        timeout = 3.0
        try:
            data = requests.get(f'{self.url}plugin/request/info', timeout=timeout + 0.5).json()
            if not isinstance(data, Mapping) or 'plugin_request' not in data:
                raise IncorrectResponse(data)
            return PluginRequestInfo.__from_json__(data['plugin_request'])
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return PluginRequestInfo()

    def plugin_request_enter(self, url: Union[URL, str], *, timestamp: Optional[float] = None) -> PluginRequestInfo:
        """Notify server about FF plugin folder enter."""
        if not isinstance(url, str):
            url = str(url)
        timeout = 3.0
        if (works := local_works()) is not None:
            works.folder.enter(url, timestamp=timestamp, ready=works.events.get('folder'))
            return self._entered(PluginRequestInfo.__from_json__(_json_copy(works.folder)))  # a snapshot: the service changes its folder
        try:
            data = None
            for _ in range(3):
                try:
                    data = self.post(f'{self.url}plugin/request/enter', timeout=timeout + 0.5, json={
                        'url': url,
                        'timestamp': timestamp,
                    }).json()
                except ServiceEnded:
                    raise  # no wait for it
                except requests.exceptions.ConnectionError:
                    self._url = None  # reset URL to force re-fetch
                    self._wait_for_service()
                else:
                    break
            if not isinstance(data, Mapping) or 'plugin_request' not in data:
                raise IncorrectResponse(data)
            return self._entered(PluginRequestInfo.__from_json__(data['plugin_request']))
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return PluginRequestInfo()

    def _entered(self, info: PluginRequestInfo) -> PluginRequestInfo:
        """Log the folder entered, return its info."""
        if const.debug.log_folders:
            fflog(f'[FOLDER] ENTER  >>>>>  {info}')
        else:
            fflog('[FOLDER] ENTER  >>>')
        return info

    def plugin_request_exit(self, *, folder: Optional[Sequence[FFItem]] = None, focus: int = -1, timestamp: Optional[float] = None) -> PluginRequestInfo:
        """Notify server about FF plugin generate folder exit."""
        from ..info import exec_id
        timeout = 3.0
        data = None
        iid = exec_id()
        try:
            to_sent = json.dumps({
                'folder': folder,
                'focus': focus,
                'timestamp': timestamp,
            }, cls=JsonEncoder)
            if const.debug.log_folders:
                fflog(f'[FOLDER] EXIT [{iid}]   >>>>>  {to_sent}')
            else:
                fflog(f'[FOLDER] EXIT [{iid}]   >>>')
            if (works := local_works()) is not None:
                return self._exit_local(works, json.loads(to_sent), timeout=timeout + 0.5)
            data = self.post(f'{self.url}plugin/request/exit', timeout=timeout + 0.5, data=to_sent, headers={'Content-Type': 'application/json'}).json()
            if not isinstance(data, Mapping) or 'plugin_request' not in data:
                raise IncorrectResponse(data)
            return PluginRequestInfo.__from_json__(data['plugin_request'])
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except (ConnectionError, requests.exceptions.ConnectionError) as exc:
            fflog.error(f'Connection to service {self._url} failed: {exc}')
        except requests.exceptions.Timeout:
            fflog.warning(f'[FOLDER] EXIT [{iid}]: no answer of the service in {timeout + 0.5} s')
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        finally:
            fflog(f'[FOLDER] EXIT [{iid}]   done')
        return PluginRequestInfo()

    def _exit_local(self, works: Works, data: JsonData, *, timeout: float) -> PluginRequestInfo:
        """
        Exit the folder in the service itself, its items copied as over HTTP (`data`: the JSON form of the exit). The copies and the
        exit run in a thread of the service: an item made in the plugin call is destroyed at its end (`RemoteCalls`), the reads of
        Kodi DB are not cut by its abort.
        """
        from . import base  # its scope read now: a new one at each start of the service

        thread = Thread(target=works.folder.exit_json, args=(data,), name='folder exit', scope=base.service_scope)
        thread.start()
        thread.join(timeout)
        if thread.is_alive():
            fflog.warning(f'[FOLDER] EXIT: not done in {timeout} s')
            return PluginRequestInfo()  # as no answer over HTTP
        return PluginRequestInfo.__from_json__(_json_copy(works.folder))

    def announce_mark(self, path: str) -> None:
        """Tell the service Kodi lists the show folder `path` next to (un)mark it natively (see `PluginRequestInfo.announce_mark()`)."""
        if (works := local_works()) is not None:
            works.folder.announce_mark(path)
            return
        try:
            self.post(f'{self.url}plugin/request/mark', timeout=3.5, json={'path': path})
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()

    folder_info = plugin_request_info
    folder_enter = plugin_request_enter
    folder_exit = plugin_request_exit

    def _local_volatile_ffid(self) -> VolatileFfid | None:
        """
        Return the volatile ffids registry to use here, None to ask the service over HTTP: in the service its own registry (no request to
        itself); in the plugin a fake one for a widget call on startup (the service could not exist yet). A CLI with `SERVICE` true (the
        settings tool) must not assign ffids: it would import the service.
        """
        from . import SERVICE
        if SERVICE:
            works = running_works()
            return None if works is None else works.volatile_ffid  # None: the service ended (the request refused, `ServiceEnded`)
        # already has FF HTTP server URL – no need to use fake FFID
        if self._url is not None:
            return None
        # it is folder (not widget) – we have to use real FF HTTP server
        from ..ff.control import is_plugin_folder
        if is_plugin_folder():
            return None
        # check if server is up and we could get the URL – if yes, don't use fake FFID
        url = self._stored_url()
        if url:
            self._url = url
            return None
        # fake FFID is not used yet – create one
        if self._volatile_ffid is None:
            from .misc import VolatileFfid
            self._volatile_ffid = VolatileFfid()
        return self._volatile_ffid

    def get_ffid_ref(self, ffid: int, *, timeout: Optional[float] = None) -> Optional[MediaRef]:
        """Get ref by volatile ffid."""
        req_timeout = None if timeout is None else timeout + .5
        if vffid := self._local_volatile_ffid():
            return vffid.get(ffid)
        try:
            data = requests.get(f'{self.url}ffid/{ffid}', timeout=req_timeout).json()
            if not isinstance(data, Mapping) or 'ref' not in data:
                raise IncorrectResponse(data)
            if data.get('status') == 'ok':
                return MediaRef(**data['ref'])
            msg = data.get('message', '')
            fflog(f'Get volatile FFID failed: {msg}')
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return None

    def get_ffid_ref_dict(self, ffid_list: Iterable[int], *, timeout: Optional[float] = None) -> Dict[int, MediaRef]:
        """Get refs by volatile ffid list, return dict[ffid] = ref."""
        req_timeout = None if timeout is None else timeout + .5
        if vffid := self._local_volatile_ffid():
            return {ffid: ref for ffid in ffid_list if (ref := vffid.get(ffid)) is not None}
        try:
            data = requests.get(f'{self.url}ffid/', params={'ffid': ','.join(map(str, ffid_list))}, timeout=req_timeout).json()
            if not isinstance(data, Mapping) or 'refs' not in data:
                raise IncorrectResponse(data)
            if data.get('status') == 'ok':
                return {it['ffid']: MediaRef(**jref) for it in data['refs'] if it and (jref := it['ref'])}
            msg = data.get('message', '')
            fflog(f'Get volatile FFID failed: {msg}')
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return {}

    def create_ffid_dict(self, refs: Iterable[MediaRef], *, timeout: Optional[float] = None) -> Dict[MediaRef, int]:
        """Create new volatile ffid for given ref."""
        req_timeout = None if timeout is None else timeout + .5
        if vffid := self._local_volatile_ffid():
            return {ref: vffid.register(ref) for ref in refs}
        try:
            data = self.post(f'{self.url}ffid', timeout=req_timeout, json={'refs': list(refs)}).json()
            if not isinstance(data, Mapping) or 'refs' not in data:
                raise IncorrectResponse(data)
            if data.get('status') == 'ok':
                return {MediaRef(**jref): it['ffid'] for it in data['refs'] if it and (jref := it['ref'])}
            msg = data.get('message', '')
            fflog(f'Create volatile FFID failed: {msg}')
        except IncorrectResponse as exc:
            fflog.warning(f'Incorrect response: {exc.data!r}')
        except ServiceEnded:
            pass  # its calls end, nothing to tell it (`_make_url()` logs it)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return {}

    def accounts_sync(self, account: str | None = None, *, wait: bool = True) -> list[str] | None:
        """
        Sync the account (None: all syncing ones) in the service now (`lib.ff.sync`). Return the IDs of the failed accounts
        with `wait` (the service tells them too), else [] (started); None if the service does not answer (or the timeout).
        """
        timeout = const.accounts.sync.wait_for_service_timeout if wait else 0
        try:
            resp = self.post(f'{self.url}accounts/sync', json={'account': account, 'timeout': timeout}, timeout=timeout + 2).json()
        except requests.RequestException as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')
            return None
        try:
            return None if (failed := resp.get('failed', [])) is None else list(failed)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return None

    def sync_wake(self) -> None:
        """Ask the service to deliver the waiting changes of accounts now (`lib.ff.sync`), no waiting for it."""
        try:
            self.post(f'{self.url}accounts/deliver', json={}, timeout=2)
        except requests.RequestException as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')  # the next sync of the service delivers them

    def restart_service(self) -> None:
        """Ask the service to restart in a fresh interpreter (`service/restart`), no waiting for it."""
        try:
            self.post(f'{self.url}service/restart', json={}, timeout=2)
        except requests.RequestException as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')

    def account_refresh(self, account_id: str) -> Optional[bool]:
        """Refresh the access token of the account in the service. Returns None if service is not available."""
        try:
            resp = self.post(f'{self.url}account/refresh', json={'id': account_id}, timeout=const.trakt.auth.service_timeout).json()
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')
            return None
        except requests.RequestException as exc:
            fflog(f'Account {account_id!r} refresh in service {self._url} failed: {exc}')
            return False
        try:
            return bool(resp.get('refreshed'))
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return False

    def state_get(self, module: str, key: str = '') -> Sequence[StateVar]:
        """Return service state variable."""
        try:
            url = f'{self.url}state/{module}'
            if key:
                url = f'{url}/{key}'
            resp = requests.get(url).json()
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')
        else:
            try:
                return [StateVar(**it) for it in resp.get('variables', ())]
            except Exception:
                if self.LOG_EXCEPTION:
                    fflog_exc()
        return []

    def state_set(self, variables: Iterable[StateVar], *, connect: bool = True) -> Optional[bool]:
        """Set list of variables to service state."""
        url = self._make_url(connect=connect)
        if not url:
            fflog(f'No URL {connect=}')
            return None
        try:
            resp = self.post(f'{url}state', json={'variables': tuple(variables)}).json()
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {url} failed: {exc}')
        else:
            try:
                return resp.get('status') == 'ok'
            except Exception:
                if self.LOG_EXCEPTION:
                    fflog_exc()
        return None

    def state_delete(self, module: str, key: str = '', *, connect: bool = True) -> Optional[bool]:
        """Delete service state variable."""
        url = self._make_url(connect=connect)
        if not url:
            fflog(f'No URL {connect=}')
            return None
        url = f'{url}state/{module}'
        if key:
            url = f'{url}/{key}'
        try:
            requests.delete(url)
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')
        else:
            return True
        return None

    def state_wait(self, module: str, key: str, value: Any, *, timeout: Optional[float] = None) -> Optional[bool]:
        """Wait for service state variable change."""
        try:
            self.post(f'{self.url}state/wait', json={'wait_for':
                                                     {'module': module, 'key': key, 'value': value},
                                                     'timeout': timeout,
                                                     }).json()
        except requests.ConnectionError as exc:
            fflog(f'Connection to service {self._url} failed: {exc}')
        else:
            return True
        return None

    def advanced_settings(self) -> Dict[str, Any]:
        """Return advancedsettings.xml as JSON structure."""
        with self.log_conn():
            return requests.get(f'{self.url}advanced_settings').json()

    def library_add(self, items: Sequence[Union[MediaRef, FFItem]], *, name: Optional[str] = None,
                    sync: bool | None = None, quiet: bool = False) -> None:
        """Add to library items by theirs ref."""
        with self.log_conn():
            self.post(f'{self.url}library', json={
                'name': name,
                'items': [it.ref for it in items],
                'sync': sync,
                'quiet': quiet,
            })

    def web(self, method: Literal['GET', 'POST', 'DELETE'], path: str, data: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        """
        Return the answer of the pairing API of the web server of the service (`/web/...`: the configuration window, Kodi is the root
        of the trust), None if the web server is off (409) or the service does not answer.
        """
        try:
            resp = requests.request(method, f'{self.url}web/{path}', json=None if method == 'GET' else dict(data or {}),
                                    params=data if method == 'GET' else None, timeout=10)
        except requests.RequestException as exc:
            fflog(f'Web pairing call {path} failed: {exc}')
            return None
        if not resp.ok:
            fflog(f'Web pairing call {path}: {resp.status_code} {resp.text[:200]}')
            return None
        return resp.json()

    def library_auto_add(self, source: LibraryAutoAddSource, *, sync: bool | None = None, quiet: bool | None = None) -> None:
        """Add to library items by theirs ref. `sync` and `quiet` are ignored (not implement yet)."""
        with self.log_conn():
            self.post(f'{self.url}library/auto', json={
                'source': source,
                'sync': sync,
                'quiet': quiet,
            })

    def progress_shows(self, *, account: str | None = None, first: int | None = None, timeout: float | None = None) -> list[MediaRef] | None:
        """
        Return the shows in progress computed by the service (it joins a running computation; the aired episodes of the `first`
        shows read, the pages shown), None if it does not answer in time.
        """
        try:
            data = requests.get(f'{self.url}progress/shows', params={'account': account or '', 'first': first or ''},
                                timeout=None if timeout is None else timeout + .5).json()
            if data.get('status') == 'ok':
                return [MediaRef(**ref) for ref in data['shows']]
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return None

    def set_media_files(self, data: Dict[str, str]) -> None:
        """Set media list files (m3u8 proxy)."""
        with self.log_conn():
            self.post(f'{self.url}media', json=data)

    def _downloads(self, path: str, data: Any = None, *, method: Literal['GET', 'POST'] = 'POST') -> JsonData | None:
        """Return the answer of the download engine of the service (`/downloads...`), None if it does not answer in time."""
        try:
            if method == 'GET':
                resp = requests.get(f'{self.url}{path}', timeout=const.downloads.service_timeout)
            else:
                # no data: no body (a route reads none, the server would take its bytes left unread for the next request line)
                resp = self.post(f'{self.url}{path}', json=data, timeout=const.downloads.service_timeout)
            if resp.ok and isinstance(answer := resp.json(), dict) and answer.get('status') == 'ok':
                return answer
            fflog(f'Downloads call {path} failed: {resp.status_code} {resp.text[:200]}')
        except (requests.RequestException, ValueError) as exc:
            fflog(f'Downloads call {path} to service {self._url} failed: {exc}')
        return None

    def downloads_add(self, request: DownloadRequest) -> DownloadAdded | None:
        """Add the download to the queue of the service. Return the result with the ID of its row, None if the service does not answer."""
        from ..ff.downloads import DownloadAdded
        if (answer := self._downloads('downloads', request)) is None:
            return None
        return DownloadAdded(result=answer['result'], id=answer.get('id'))

    def downloads_snapshot(self) -> DownloadsSnapshot | None:
        """Return the queue of the service, None if it does not answer."""
        from ..ff.downloads import DownloadsSnapshot
        if (answer := self._downloads('downloads', method='GET')) is None:
            return None
        return DownloadsSnapshot.__from_json__(answer['snapshot'])

    def downloads_act(self, download_id: int, action: DownloadAction) -> bool:
        """Do the action with the download in the service. Return False if it is not done (no such download, the service does not answer)."""
        return bool((answer := self._downloads(f'downloads/{int(download_id)}/{action}')) and answer.get('done'))

    def downloads_relink(self, download_id: int, link: DownloadLink) -> bool:
        """Give the download of the service its new link. Return False if it is not done (no such download, the service does not answer)."""
        return bool((answer := self._downloads(f'downloads/{int(download_id)}/link', link)) and answer.get('done'))

    def downloads_pause_all(self, paused: bool) -> bool:
        """Pause or release the whole queue of the service. Return False if the service does not answer."""
        return bool((answer := self._downloads('downloads/pause_all', {'paused': paused})) and answer.get('done'))

    def downloads_call(self, call: DownloadsCall) -> bool:
        """Call the engine of the service for the whole queue (`remove_done`...). Return False if the service does not answer."""
        return bool((answer := self._downloads(f'downloads/{call}')) and answer.get('done'))


#: Default global service client.
service_client = ServiceClient()
