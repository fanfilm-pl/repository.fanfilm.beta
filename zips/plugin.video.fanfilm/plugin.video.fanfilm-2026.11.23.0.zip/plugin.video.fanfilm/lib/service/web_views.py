"""
The pages of the configuration window with their own view on the web page (`web_server.Server`, the routes `/config/<page>`), by the logic
of the window, no copy of it: the source providers (`addons`: the tree, the panel of its row, its settings - `ProvidersTabLogic` with a tree
of no Kodi, `TreeSelection`), the menus (`menus`: `MenusTabLogic`, the same tree), the debrid services (`debrid`: `lib.windows.debrid`),
the accounts (`accounts`: `lib.windows.accounts`), the general lists (`general`: `lib.windows.general_lists`), the data providers (`feeds`),
the folders (`folders`: `lib.windows.folders`), the appearance (`appearance`: the themes, the tokens of the page) and the filter and the sort
of the sources of a media (`filters`: the edit of the panel of the window, `SelectionEdit`; the window of a row of the sources). An
action which may ask (yes / no, a label, a choice, a sign-in) runs as in the window, its dialogs on the page (`web_dialog`); an action which
opens a window of another add-on (the settings of an add-on, the authorization and the settings of ResolveURL) is only in Kodi.
"""

from __future__ import annotations
from functools import partial
from typing import Any, Callable, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import get_args
from . import web_config, web_dialog
from ..ff.types import JsonData
from ..windows.external_addons import NODE_SETTINGS, PanelButton, ProvidersTabLogic
from ..windows.menus import MenusTabLogic
from ..windows.tree import RowMarks, TreeSelection
from ..ff.source.keys import FilterState, SortCriterion
from ..windows.widgets.source_filters import SelectionEdit
if TYPE_CHECKING:
    from ..ff.item import FFItem
    from ..ff.source.filters import SelectionMedia
    from ..ff.source.keys import SourceKey
    from ..windows.source_panel import FilterTree
    from ..windows.widgets.setting_list import SettingRow
    from ..windows.accounts import AccountPanel
    from ..windows.debrid import DebridPanel
    from ..ff.debrid import DebridAccount, DebridInfo

#: The memories of the partial states of the nodes of the trees of the source providers and of the menus (of the window: their templates).
PROVIDERS_MEMORY: str = 'addons'
MENUS_MEMORY: str = 'menus'
#: The buttons of the panel of the source providers which open a window of another add-on (only in Kodi).
PROVIDERS_KODI_ONLY: frozenset[str] = frozenset({'settings'})
#: The buttons of the panel of a row of the native providers (as the window: its name and its settings in the place of the others).
NATIVE_BUTTONS: frozenset[str] = frozenset({'defaults'})
#: The actions of the debrid services which open a window of ResolveURL (only in Kodi).
DEBRID_KODI_ONLY: frozenset[str] = frozenset({'authorize', 'settings'})

#: The account info of the debrid services by their names (asked by the page: `debrid` "infos"; a read of the page forgets them).
_debrid_infos: dict[str, DebridInfo | None] = {}


def _delta(data: Mapping[str, Any]) -> int:
    """Return the number of the places of a move (`delta`: up < 0 < down; ↑ ↓ of a row, a drag on the page), ValueError of none."""
    if not isinstance(delta := data.get('delta'), int) or isinstance(delta, bool) or not delta:
        raise ValueError(f'delta {delta!r}')
    return delta


# --- the trees: the source providers, the menus ---

class WebTree:
    """A tree of a page of the window for the web page: its selection of no Kodi (`TreeSelection`) with every node expanded, its rows by keys."""

    if TYPE_CHECKING:
        #: The tree.
        view: TreeSelection

    def expand(self) -> None:
        """Expand every node (the page collapses them itself)."""
        model = self.view.model
        model.expanded = {id(item) for item in model.items() if item.children_items is not None}
        model.rows = model.flatten()

    def key_of(self, pos: int) -> str:
        """Return the key of the row (its path in the tree)."""
        return self.view.model.keys[id(self.view.model.rows[pos].item)]

    def find_row(self, key: str) -> bool:
        """Select the row of the key (none: the first row), return False if the tree has no row of the key (the tree changed meanwhile)."""
        model = self.view.model
        pos = next((n for n, row in enumerate(model.rows) if model.keys[id(row.item)] == key), -1)
        self.view.pos = max(pos, 0)
        return pos >= 0

    def row_dimmed(self, item: FFItem) -> bool:
        """Return True if the row is dimmed by the logic of the page too (else by the model: a hidden menu)."""
        return False

    def row_marks(self, item: FFItem) -> RowMarks:
        """Return the marks of a row (its own colour, up), none here."""
        return RowMarks()

    def rows_json(self) -> list[JsonData]:
        """Return the rows of the tree: the key, the label, the level, a node (its counter), its check, dimmed, its marks (its own colour, up)."""
        model = self.view.model
        found: list[JsonData] = []
        for row in model.rows:
            item = row.item
            marks = self.row_marks(item)
            selected, total = self.view.counter(item)
            found.append({'key': model.keys[id(item)], 'label': item.getLabel(), 'level': row.level, 'node': row.node, 'check': model.check(item),
                          'count': f'{selected} / {total}' if row.node else '', 'dim': model.dimmed(item) or self.row_dimmed(item),
                          'color': marks.color, 'up': marks.up})
        return found


class WebProviders(WebTree, ProvidersTabLogic):
    """The tab of the source providers for the page: the logic of the window, its tree of no Kodi with every node expanded."""

    def __init__(self) -> None:
        """Read the provider add-ons and the choice (as the tab of the window)."""
        self.init_logic()
        self.view = TreeSelection(self.load(), memory=PROVIDERS_MEMORY, multi=True, on_check=self.checked)
        self.expand()

    def select(self, key: str) -> bool:
        """Make the panel of the row of the key (none: the first row), return False if the tree has no row of the key."""
        found = self.find_row(key)
        self.select_panel(self.view.pos)
        return found

    def row_dimmed(self, item: FFItem) -> bool:
        """Return True if nothing of the row is searched (`ProvidersTabLogic.dimmed()`)."""
        return self.dimmed(item)

    def row_marks(self, item: FFItem) -> RowMarks:
        """Return the marks of a row: its own colour, priority up (`ProvidersTabLogic.marks()`)."""
        return self.marks(item)

    def show_panel(self, pos: int | None = None) -> None:
        """Make the panel of the row (the page reads it)."""
        self.select_panel(pos)

    def show_rows(self, pos: int = 0) -> None:
        """Nothing to show (the page reads the settings of the panel)."""

    def reload(self) -> None:
        """Read the provider add-ons again (a state changed), the panel of the same row."""
        key = self.key_of(self.pos) if 0 <= self.pos < len(self.view.model.rows) else ''
        self.view.model = self.load()
        self.expand()
        self.select(key)

    def setting_rows(self) -> dict[str, web_config.Row]:
        """
        Return the settings of the panel (of the node, of its native provider) as the rows of the page by their pointers; a value of access data
        of the provider (`tuned_setting()`, a password) only as set or not.
        """
        from ..sources.natives import tuned_setting
        key, provider = self.key_of(self.pos), self.panel.provider
        found: dict[str, web_config.Row] = {}
        for row in self.panel_settings():
            name = row.setting['key']
            found[f'{key}#{name}'] = web_config.Row(row=row, pointer=f'{key}#{name}', kodi_only=row.setting['kind'] in web_config.KODI_ONLY,
                                                   access=row.setting not in NODE_SETTINGS and tuned_setting(provider, name))
        return found

    def state(self) -> JsonData:
        """Return the state of the page: the tree, the row of the panel, the panel (its texts, its buttons), its settings and their state."""
        panel = self.panel
        settings = self.setting_rows()
        menu = self.extra_menu(self.pos)
        return {
            'rows': self.rows_json(), 'row': self.key_of(self.pos),
            'panel': {'category': panel.category, 'title': panel.title, 'heading': panel.heading, 'id': panel.id, 'info': panel.info,
                      'state': panel.state, 'claimed': panel.claimed, 'summary': panel.summary, 'description': panel.description,
                      'native': panel.native, 'reset': menu[0][0] if menu else '',
                      'buttons': [{'name': name, 'text': self.button_text(name), 'usable': self.usable(name), 'help': self.button_help(name),
                                   'kodi_only': name in PROVIDERS_KODI_ONLY}
                                  for name in get_args(PanelButton) if not panel.native or name in NATIVE_BUTTONS]},
            'settings': [{**web_config.setting_json(row), 'view': 'addons', 'row': self.key_of(self.pos)} for row in settings.values()],  # its write (`set`)
            'state': web_config.state(settings),
        }

    def act(self, action: str, data: Mapping[str, Any]) -> None:
        """
        Do an action on the row of the panel: `check` (check / uncheck it: a node - its next step), `defaults` (the default selection of its
        branch), `enable` (enable it in Kodi, activate / deactivate a provider add-on), `reset` (its colour and priority as of its parent),
        `set` (`setting`, `value`: a setting of the panel); PermissionError of a grayed one, KeyError of no such setting.
        """
        pos = self.pos
        if action == 'check':
            if not self.view.can_check(pos):
                raise PermissionError(action)
            self.view.check(pos)
        elif action == 'defaults':
            if not self.usable('defaults'):
                raise PermissionError(action)
            self.default_selection()
        elif action == 'enable':
            if not self.usable('enable'):
                raise PermissionError(action)
            self.enable()
        elif action == 'reset':
            self.reset_node(self.view.model.rows[pos].item)
        elif action == 'set':
            pointer, row = self.setting(data)
            row.row.set(web_config.check(row, pointer, data.get('value')))
        elif action:
            raise KeyError(action)

    def setting(self, data: Mapping[str, Any]) -> tuple[str, web_config.Row]:
        """Return the pointer and the row of the setting `setting` of the panel (KeyError: none)."""
        pointer = f'{self.key_of(self.pos)}#{data.get("setting")}'
        if (row := self.setting_rows().get(pointer)) is None:
            raise KeyError(pointer)
        return pointer, row

    def secret(self, data: Mapping[str, Any]) -> Any:
        """Return the value of a setting of access data of the panel (`setting`; the page shows it at a request), KeyError of another one."""
        _, row = self.setting(data)
        if not row.access:
            raise KeyError(data.get('setting'))
        return row.row.get()


def providers(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the source providers (`data`: the row of the panel, an action on it, `WebProviders.act()`); `secret`: one value of
    access data of the panel (`{"value"}`).
    """
    page = WebProviders()
    key, action = str((data or {}).get('row', '')), str((data or {}).get('action', ''))
    if not page.select(key) and key and action:  # a row gone meanwhile: no action on another one
        raise KeyError(key)
    if data and action == 'secret':
        return {'value': page.secret(data)}
    if data and action:
        page.act(action, data)
    return page.state()


class WebMenus(WebTree, MenusTabLogic):
    """The tab of the menus for the page: the logic of the window (an entry shown / hidden, its place among its siblings), its tree of no Kodi."""

    def __init__(self) -> None:
        """Read the entries in the user order and their switches (as the tab of the window)."""
        self.init_logic()
        self.view = TreeSelection(self.load(), memory=MENUS_MEMORY, multi=True, on_check=self.checked, on_move=self.moved)
        self.expand()

    def state(self) -> JsonData:
        """
        Return the state of the page: the tree (each row: whether it can move up / down among its siblings), the selected row, the default
        order of its menu (the label of the context menu).
        """
        pos, model = self.view.pos, self.view.model
        menu = self.extra_menu(pos) if model.rows else []
        return {'rows': [{**row, 'moves': [model.can_move(n, -1), model.can_move(n, 1)]} for n, row in enumerate(self.rows_json())],
                'row': self.key_of(pos) if model.rows else '', 'reset': menu[0][0] if menu else ''}

    def act(self, action: str, data: Mapping[str, Any]) -> None:
        """
        Do an action on the selected row: `check` (show / hide its entry), `move` (`delta` places among its siblings), `defaults` (the
        default order of its menu); PermissionError of one it can not do now.
        """
        pos, model = self.view.pos, self.view.model
        if action == 'check':
            if not self.view.can_check(pos):
                raise PermissionError(action)
            self.view.check(pos)
        elif action == 'move':
            if not model.can_move(pos, delta := _delta(data)):
                raise PermissionError(action)
            self.view.move(pos, delta)
        elif action == 'defaults':
            if not self.extra_menu(pos):
                raise PermissionError(action)
            self.default_order(pos)
        elif action:
            raise KeyError(action)


def menus(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """Return the state of the menus (`data`: the selected row, an action on it, `WebMenus.act()`)."""
    page = WebMenus()
    key, action = str((data or {}).get('row', '')), str((data or {}).get('action', ''))
    if not page.find_row(key) and key and action:  # a row gone meanwhile: no action on another one
        raise KeyError(key)
    if data and action:
        page.act(action, data)
    return page.state()


# --- the general lists, the data providers, the folders: their grids ---

def _index(data: Mapping[str, Any], name: str, count: int) -> int:
    """Return an index of an item of a grid (`data[name]`), ValueError of none of the `count` items."""
    if not isinstance(index := data.get(name), int) or isinstance(index, bool) or not 0 <= index < count:
        raise ValueError(f'{name} {index!r}')
    return index


def general(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the general lists: the menus (the columns), the service types and their lists (the rows) with their switches; an
    action of `data`: a switch of a menu (`place`: `column`), of a row (`row`: `row`), of a cell (`cell`: `row`, `column`) - `value`.
    """
    from ..ff import lists_config as lc
    from ..windows.general_lists import (cell_checked, cell_usable, grid_rows, place_label, places, row_active, row_checked, row_label, row_note,
                                         set_cell, set_row, switch_help, switches_heading)
    columns, rows = places(), grid_rows()
    if data and (action := str(data.get('action', ''))):
        value = bool(data.get('value'))
        if action == 'place':
            lc.set_place_active(columns[_index(data, 'column', len(columns))].id, value)  # type: ignore[arg-type]
        elif action == 'row':
            set_row(rows[_index(data, 'row', len(rows))], value)
        elif action == 'cell':
            row, c = rows[_index(data, 'row', len(rows))], _index(data, 'column', len(columns))
            if c not in row.cells:
                raise ValueError(f'no cell {c}')
            if not cell_usable(row, columns[c].id):
                raise PermissionError(action)
            set_cell(row, columns[c].id, c, value)
        else:
            raise KeyError(action)
    return {
        'heading': switches_heading(),
        'columns': [{'label': place_label(menu.id), 'checked': lc.place_active(menu.id), 'help': switch_help(None, menu.id)} for menu in columns],
        'rows': [{'type': row.entry is None, 'label': row_label(row), 'checked': row_checked(row), 'active': row_active(row), 'note': row_note(row),
                  'help': switch_help(row, None),
                  'cells': [{'checked': cell_checked(row, columns[c].id, c), 'usable': cell_usable(row, columns[c].id), 'help': switch_help(row, columns[c].id)}
                            if c in row.cells else None for c in range(len(columns))]}
                 for row in rows],
    }


def feeds(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the data providers: the fixed entries with the providers they can take their data from (the chosen one), the VOD
    services of the user; an action of `data`: `choose` (`row`: the key of an entry, `service`), `subscriptions` (their choice: a dialog).
    """
    from ..ff import lists_config as lc
    from ..windows.widgets.feeds import (ask_subscriptions, feed_help, feed_rows, feed_services, service_label, subscriptions_text, vod_help, vod_label,
                                         vod_packages)
    def choose_vod() -> str:
        """Choose the VOD services of the user (as the window: its dialogs on the page)."""
        if (packages := vod_packages()) is not None:
            ask_subscriptions(packages)
        return ''

    rows = feed_rows()
    action = str((data or {}).get('action', ''))
    if data and action == 'subscriptions':
        return web_dialog.start(device, choose_vod)
    if data and action == 'choose':
        if (fd := next((fd for fd in rows if fd.key == data.get('row')), None)) is None:
            raise KeyError(data.get('row'))
        if (service := data.get('service')) not in fd.services:
            raise ValueError(f'service {service!r}')
        lc.set_feed(fd.key, service)
    elif action:
        raise KeyError(action)
    return {
        'columns': [{'service': srv, 'label': service_label(srv)} for srv in feed_services()],
        'rows': [{'key': fd.key, 'label': fd.label(), 'value': lc.feed(fd.key), 'helps': {srv: feed_help(fd, srv) for srv in fd.services}} for fd in rows],
        'vod': {'label': vod_label(), 'text': subscriptions_text(len(lc.subscriptions())), 'help': vod_help()},
    }


def folders(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the folders: the levels of the menus in their groups with their `When` (never, if many, always; a group in no menu:
    `dim`), the switch of the entry of a menu in a head (`switch`, `shown`: the same setting as in the menus), the preview of the menu of each
    group; an action of `data`: `choose` (`index`: a level, `when`: the name of its value), `switch` (`index`: the head of a group, `shown`).
    """
    from cdefs import When
    from ..ff import lists_config as lc
    from ..ff.menu_entries import entry_shown, set_entry_shown
    from ..windows.folders import WHENS, entry_switch_help, preview_label, preview_text, switch_help, when_label
    from ..windows.widgets.folders import FoldersPage
    rows = FoldersPage.rows()
    if data and (action := str(data.get('action', ''))):
        if action == 'switch':
            index = _index(data, 'index', len(lc.FOLDER_POINTS))
            if (head := next((row for row in rows if row.head and row.index == index and row.switch), None)) is None:
                raise ValueError(f'no switch in the head of {index}')
            set_entry_shown(head.switch, bool(data.get('shown')))
        elif action == 'choose':
            point = lc.FOLDER_POINTS[_index(data, 'index', len(lc.FOLDER_POINTS))]
            if (when := When.__members__.get(str(data.get('when')))) not in WHENS:
                raise ValueError(f'when {data.get("when")!r}')
            lc.set_folder(point.key, when)
        else:
            raise KeyError(action)
    return {
        'preview_label': preview_label(),
        'columns': [{'when': when.name, 'label': when_label(when)} for when in WHENS],
        'rows': [{'index': row.index, 'head': row.head, 'label': row.label, 'group': row.group, 'dim': not lc.FOLDER_GROUPS[row.group].in_menus(),
                  **({'switch': row.switch, 'shown': entry_shown(row.switch), 'help': entry_switch_help(row.switch)} if row.switch else {}),
                  **({} if row.head else {'when': lc.folder_when(lc.FOLDER_POINTS[row.index].key).name,
                                          'helps': [switch_help(lc.FOLDER_POINTS[row.index], when) for when in WHENS]})} for row in rows],
        'previews': {group: preview_text(group) for group in dict.fromkeys(row.group for row in rows)},
    }


# --- the appearance: the themes, the variant, the colours of the skin, the tokens of the page ---

def _token_value(kind: str, value: Any, options: list[JsonData]) -> Any:
    """
    Return a value of a token of the page checked by its kind (a colour ARGB, a factor, a font: one of the options); None: the value of the
    themes (out of the local style).
    """
    import re
    if value is None:
        return None
    if kind == 'color':
        if isinstance(value, str) and re.fullmatch(r'[0-9A-Fa-f]{8}', value):
            return value.upper()
    elif any(option['value'] == value for option in options) and not isinstance(value, bool):
        return value
    raise ValueError(f'value {value!r}')


def _form_options(kind: str, value: Any) -> list[JsonData]:
    """Return the options of a row of the form (a factor: its scale; a font: the normal fonts of the skin, none if Kodi can not tell them)."""
    from ..windows.widgets.appearance import AppearancePage, factor_scale
    if kind == 'factor':
        scale = factor_scale(float(value))
        return [{'value': scale.value_at(pos), 'label': scale.text(pos)} for pos in range(scale.last + 1)]
    if kind == 'font':
        try:
            return [{'value': item.value, 'label': item.label} for item in AppearancePage.font_items(str(value))]
        except Exception:  # the fonts of the skin not known here: the row only in Kodi
            from ..ff.logs import fflog_exc
            fflog_exc()
    return []


def appearance(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the appearance: the active themes (the base one last, the tools of each row), the installed ones to add, the form
    (the variant, the colours of the skin, the tokens of the page; a font of the skin: its fonts); an action of `data`: `add` / `remove` /
    `move` (`theme`, `delta` places), `variant` / `skin_colors` / `token` (`token`) - `value`. The windows of Kodi take a change at their next open.
    """
    from ..ff import theme
    from ..windows.style import StyleError, check_style, local_style_files
    from ..windows.widgets.appearance import ThemeRow, form_rows, form_value, local_note, theme_ids, tool_reasons, write_token

    def found() -> tuple[dict[str, theme.ThemeInfo], list[str], list[theme.ThemeInfo]]:
        """Return the installed themes, the active ones (the base one last), the ones to add."""
        themes = {info.id: info for info in theme.found_themes()}
        return themes, theme_ids(), theme.free_themes(themes.values())

    themes, ids, free = found()
    if data and (action := str(data.get('action', ''))):
        value = data.get('value')
        if action == 'add':
            if tool_reasons(0, len(ids), bool(free))['add']:
                raise PermissionError(action)
            if (theme_id := data.get('theme')) not in [info.id for info in free]:
                raise ValueError(f'theme {theme_id!r}')
            theme.add_theme(theme_id)
        elif action in ('remove', 'move'):
            if (theme_id := data.get('theme')) not in ids:
                raise ValueError(f'theme {theme_id!r}')
            delta = _delta(data) if action == 'move' else 0
            if tool_reasons(ids.index(theme_id), len(ids), bool(free))['remove' if not delta else 'up' if delta < 0 else 'down']:
                raise PermissionError(action)
            if action == 'remove':
                theme.remove_theme(theme_id)
            else:
                theme.move_theme(theme_id, delta)  # at most to the end of the active ones (the base one stays the last one)
        elif action == 'variant':
            if value not in theme.variant_choices(themes):
                raise ValueError(f'variant {value!r}')
            theme.set_variant(value)
        elif action == 'skin_colors':
            theme.set_skin_colors(bool(value))
        elif action == 'token':
            if (row := next((row for row in form_rows() if row.token and row.token == data.get('token')), None)) is None:
                raise KeyError(data.get('token'))
            now, _ = form_value(row, check_style(), local_style_files())
            try:
                write_token(row.token, _token_value(row.kind, value, _form_options(row.kind, now)))
            except StyleError as exc:
                raise ValueError(str(exc)) from None
        else:
            raise KeyError(action)
        themes, ids, free = found()
    style, local = check_style(), local_style_files()
    form: list[JsonData] = []
    for row in form_rows():
        value, modified = form_value(row, style, local)
        options = ([{'value': name, 'label': theme.variant_label(name)} for name in theme.variant_choices(themes)] if row.kind == 'variant'
                   else _form_options(row.kind, value))
        form.append({'name': row.name, 'label': row.label, 'kind': row.kind, 'token': row.token, 'help': row.help, 'value': value, 'modified': modified,
                     'options': options, 'kodi_only': row.kind == 'font' and not options})
    return {
        'themes': [{'id': shown.id, 'title': shown.title, 'dim': shown.dim, 'info': shown.info, 'tools': tool_reasons(i, len(ids), bool(free))}
                   for i, shown in enumerate(ThemeRow.of(theme_id, themes) for theme_id in ids)],
        'free': [{'id': info.id, 'name': info.name} for info in free], 'form': form, 'note': local_note(local),
    }


# --- the filter and the sort of the sources of a media (the window of a row of the sources: `selection_<media>`) ---

class WebSelection(SelectionEdit):
    """
    The selection of the user of a media for the page: the edit of the panel of the window (its view by the setting and the state now: the
    simple one - its sets only of what it shows, `SourceFiltersSimple`), a change written at once and kept as the previous one (no session).
    """

    def __init__(self, media: SelectionMedia) -> None:
        """The selection of the media, its view."""
        from ..ff.source.filters import simple_view
        self.init_edit(media)
        #: The advanced view (the tree of the values), else the simple one.
        self.advanced: bool = not simple_view(media)

    def set_names(self) -> list[str]:
        """Return the names of the sets of the list (the simple view: only the ones it shows, as the window)."""
        from ..ff.source.filters import representable, set_state, user_languages
        names = super().set_names()
        return names if self.advanced else [name for name in names if representable(set_state(name), langs=user_languages())]

    def setting_rows(self) -> tuple[dict[str, web_config.Row], dict[str, web_config.Row]]:
        """
        Return the rows of the page as the rows of the cards by their keys (the template of the page shows them): of the filter - its switch,
        the ranges of the quality and the size, the rows of the filter of the simple view -, of the sort (the simple view).
        """
        from ..ff.config.blocks import ProviderSetting, catalog_setting
        from ..ff.source.filters import user_languages
        from ..ff.source.keys import KEY_LABELS
        from ..windows.source_panel import FILTER_HELP, FILTER_SCALES, FILTER_TEXTS, range_value
        from ..windows.widgets.setting_list import SettingRow
        from ..windows.widgets.source_filters import SIMPLE_QUALITY_SCALE, simple_filter_rows

        def row(key: str, kind: str, label: str, get: Callable[[], Any], write: Callable[[Any], None], scale: Any = None) -> SettingRow:
            """Return a row of the panel of the window (its help as the window has it)."""
            entry = catalog_setting(ProviderSetting(key=key, kind=kind, label=label, help=FILTER_HELP[f'tabs.{key}'], default=None, scale=scale))
            return SettingRow(setting=entry, get=get, set=write)

        def found(rows: Sequence[SettingRow]) -> dict[str, web_config.Row]:
            """Return the rows of the page by their keys."""
            return {setting.setting['key']: web_config.Row(row=setting, pointer=f'{self.media}#{setting.setting["key"]}') for setting in rows}

        state = self.state().get('filter', {})
        on = row('on', 'bool', FILTER_TEXTS['on'], lambda: state.get('on', True), lambda value: self.change_filter(on=value))
        if self.advanced:
            return found([on, *(row(path, 'range', KEY_LABELS[path].label, partial(range_value, state, path), partial(self.change_range, path),
                                    FILTER_SCALES[path]) for path in FILTER_SCALES)]), {}
        values = self.values()
        return (found([on, row('quality', 'range', KEY_LABELS['quality'].label, self.simple_quality, self.set_simple_quality, SIMPLE_QUALITY_SCALE),
                       row('size', 'range', KEY_LABELS['size'].label, partial(range_value, state, 'size'), self.set_simple_size, FILTER_SCALES['size']),
                       *self.rows(simple_filter_rows(user_languages()), values)]),
                found(self.sort_rows(values)))


def _filter_tree(edit: WebSelection, *, chosen: FilterState | None = None, order: Sequence[SourceKey] = ()) -> tuple[FilterTree, WebTree]:
    """
    Return the tree of the filter of the selection (the values the keys know and the ones of the state: no search) with every node expanded;
    `chosen`: the tree of the features of a criterion of the sort (two values; `order`: the keys of an order of their own).
    """
    from ..ff.source.filters import user_languages
    from ..windows.source_panel import FilterTree
    state = edit.state().get('filter', {}) if chosen is None else chosen
    tree = FilterTree(None, langs=user_languages(), state=state, order=order)
    web = WebTree()
    web.view = TreeSelection(tree.model(state, tristate=chosen is None), tristate=chosen is None, multi=True)
    web.expand()
    return tree, web


def _criterion_json(crit: SortCriterion) -> JsonData:
    """
    Return a criterion of the sort for the page: its label, help, what OK does (`features`: its features chosen again, else the other direction
    of a number - its direction, `mark`), as the window.
    """
    from ..windows.source_panel import criterion_action, criterion_direction, criterion_help, criterion_label
    return {'label': criterion_label(crit), 'help': criterion_help(crit), 'action': criterion_action(crit), 'features': 'any' in crit,
            'mark': DIRECTION_MARKS.get(criterion_direction(crit), '')}


#: The marks of the directions of a criterion of the sort of a number (`criterion_direction()`).
DIRECTION_MARKS: Mapping[str, str] = {'descending': '↓', 'ascending': '↑'}


def _new_index(data: Mapping[str, Any], count: int) -> int | None:
    """Return the index of a criterion of the sort (`index`; none: a new one), ValueError of none of the `count` ones."""
    return None if data.get('index') is None else _index(data, 'index', count)


def _features(edit: WebSelection, sort: list[SortCriterion], index: int | None) -> JsonData:
    """
    Return the tree of the features of a criterion of the sort (`index`; None: a new one - the node "Order" of the keys not in the sort too)
    for the page: its heading, its rows (a leaf: its path and value, of the order its key; chosen; the help).
    """
    from ..windows.source_panel import SORT_HEADINGS, sort_keys
    any_of = sort[index].get('any', {}) if index is not None else {}
    tree, web = _filter_tree(edit, chosen=FilterState(keys={path: {value: True for value in values} for path, values in any_of.items()}),
                             order=sort_keys(sort) if index is None else ())
    model = web.view.model
    return {'index': index, 'heading': SORT_HEADINGS['new'] if index is None else SORT_HEADINGS['edit'].format(n=index + 1),
            'rows': [{**row, 'leaf': [leaf.path, leaf.value] if (leaf := tree.leaves.get(id(item))) else None,
                      'order': key.path if (key := tree.orders.get(id(item))) else '', 'checked': bool(model.value(item)),
                      'help': tree.feature_help(item, model)}
                     for item, row in zip((row.item for row in model.rows), web.rows_json())]}


def _criterion(data: Mapping[str, Any], sort: list[SortCriterion]) -> list[SortCriterion]:
    """
    Return the criteria with one chosen on the page (`index`, none: a new one at the top): `order` - the path of a key in its natural order (a
    new one), else `any` - the chosen values by the paths of their keys (none chosen: no criterion, as the window).
    """
    from ..windows.source_panel import FilterTree, new_criterion, sort_keys
    index = _new_index(data, len(sort))
    if (order := data.get('order')) is not None:
        if index is not None or (key := next((key for key in sort_keys(sort) if key.path == order), None)) is None:
            raise ValueError(f'order {order!r}')
        return [new_criterion(key), *sort]
    paths, chosen = set(FilterTree.paths()), data.get('any')
    if not isinstance(chosen, Mapping) or any(path not in paths or not isinstance(values, list) or not all(isinstance(value, str) for value in values)
                                              for path, values in chosen.items()):
        raise ValueError(f'any {chosen!r}')
    criterion = SortCriterion(any={path: list(values) for path, values in chosen.items() if values})
    if index is None:
        return [criterion, *sort] if criterion['any'] else sort
    if 'any' not in sort[index]:
        raise PermissionError('criterion')
    return [*sort[:index], *([criterion] if criterion['any'] else []), *sort[index + 1:]]


def filters(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the filter and the sort of the sources of the media `media` (its view: the advanced one - the tree of the values, the
    criteria -, the simple one: the rows of the old settings); an action of `data`: `set` (`setting`, `value`: a row), `check` / `reset_node`
    (`row`: a leaf of the tree - its next value, a node - its default values), `reset` (the filter of a new installation, asked), `sort_move`
    (`index`, `delta`), `sort_remove` / `sort_reverse` (`index`), `features` (`index`, none: a new criterion - its tree of the features and the
    orders), `criterion` (`_criterion()`), `set_entry` (`index`: an item of the list of the sets, it may ask), `previous` (the previous one back).
    """
    from ..ff.source.filters import previous_state, representable, selection_medias, user_languages
    from ..kolang import L
    from ..windows.source_panel import FILTER_PAGES, FILTER_TEXTS
    from const import const
    data = data or {}
    if (media := data.get('media', 'movie')) not in selection_medias():
        raise ValueError(f'media {media!r}')
    edit = WebSelection(media)
    action = str(data.get('action', ''))
    sort = list(edit.state().get('sort', []))
    features: JsonData | None = None
    if action in ('check', 'reset_node', 'reset', 'sort_move', 'sort_remove', 'sort_reverse', 'features', 'criterion') and not edit.advanced:
        raise PermissionError(action)  # the simple view: its rows only
    if action == 'set':
        filter_rows, sort_rows = edit.setting_rows()
        if (found := {**filter_rows, **sort_rows}.get(str(data.get('setting')))) is None:
            raise KeyError(data.get('setting'))
        found.row.set(web_config.check(found, found.pointer, data.get('value')))
    elif action in ('check', 'reset_node'):
        tree, web = _filter_tree(edit)
        if not web.find_row(str(data.get('row', ''))):
            raise KeyError(data.get('row'))
        if action == 'check' and not web.view.can_check(web.view.pos):
            raise PermissionError(action)
        if action == 'check':
            web.view.check(web.view.pos)
        else:
            web.view.reset(web.view.pos)
        edit.change_tree(tree, web.view.model)
    elif action == 'reset':
        if not edit.filter_customized():
            raise PermissionError(action)
        return web_dialog.start(device, edit.reset_filter)
    elif action == 'sort_move':
        index = _index(data, 'index', len(sort))
        if not 0 <= (to := index + _delta(data)) < len(sort):
            raise PermissionError(action)
        sort.insert(to, sort.pop(index))
        edit.change_sort(sort)
    elif action == 'sort_remove':
        del sort[_index(data, 'index', len(sort))]
        edit.change_sort(sort)
    elif action == 'sort_reverse':
        if (reversed_sort := edit.reversed_sort(sort, _index(data, 'index', len(sort)))) is None:
            raise PermissionError(action)  # not a number: no other direction
        edit.change_sort(reversed_sort)
    elif action == 'features':
        if (index := _new_index(data, len(sort))) is not None and 'any' not in sort[index]:
            raise PermissionError(action)
        features = _features(edit, sort, index)
    elif action == 'criterion':
        edit.change_sort(_criterion(data, sort))
    elif action == 'set_entry':
        entry = (items := edit.set_items())[_index(data, 'index', len(items))].value
        return web_dialog.start(device, lambda: edit.run_set_entry(entry) and None)
    elif action == 'previous':
        edit.load_previous()
    elif action:
        raise KeyError(action)
    filter_rows, sort_rows = edit.setting_rows()
    tree_rows: list[JsonData] = []
    if edit.advanced:
        tree, web = _filter_tree(edit)
        model, state = web.view.model, edit.state().get('filter', {})
        tree_rows = [{**row, 'value': None if row['node'] else model.value(item), 'help': tree.help(item, model, state),
                      'reset': row['node'] and not model.is_default(item)}
                     for item, row in zip((row.item for row in model.rows), web.rows_json())]
    base, items = edit.state().get('base'), edit.set_items()
    hide_sets = not edit.advanced and const.sources.filters.simple_hides_sets  # "Previous" in their place (as the window)
    previous = previous_state(media)

    def settings(rows: Mapping[str, web_config.Row]) -> list[JsonData]:
        """Return the rows of the page (their writes: `set` of this view)."""
        return [{**web_config.setting_json(row), 'view': 'filters', 'row': media} for row in rows.values()]

    answer: JsonData = {
        'media': media, 'advanced': edit.advanced,
        'settings': {'filter': settings(filter_rows), 'sort': settings(sort_rows)},
        'state': web_config.state({row.pointer: row for row in (*filter_rows.values(), *sort_rows.values())}),
        'tree': tree_rows, 'customized': edit.advanced and edit.filter_customized(),
        'sort': [_criterion_json(crit) for crit in edit.state().get('sort', [])] if edit.advanced else [],
        'sets': [] if hide_sets else [{'label': item.label, 'separator': item.separator is not None} for item in items],
        'set': next((n for n, item in enumerate(items) if item.value.kind == 'none' or item.value.name == base), -1),
        'previous': hide_sets and previous is not None and representable(previous, langs=user_languages()),
        'texts': {'filter': FILTER_PAGES[0].title, 'sort': FILTER_PAGES[1].title, 'filter_help': FILTER_PAGES[0].help, 'sort_help': FILTER_PAGES[1].help,
                  'add': FILTER_TEXTS['add'], 'set': FILTER_TEXTS['set'], 'reset': L(30926, 'Reset'), 'previous': L(30941, 'Previous'),
                  'title': L(30951, 'Filters and sort')},
    }
    if features is not None:
        answer['features'] = features
    return answer


# --- the debrid services ---

class WebDebrid:
    """The debrid services for the page: a view of the operations of the window (`lib.windows.debrid.DebridView`)."""

    def __init__(self, name: str = '') -> None:
        """Read the debrids, the panel of the debrid `name` (none: the first one)."""
        from ..windows.debrid import DebridPanel
        self.infos: dict[str, DebridInfo | None] = _debrid_infos
        self.accounts: list[DebridAccount] = []
        self.allowed: bool = False
        self.panel: DebridPanel = DebridPanel()
        #: The debrid the page shows after an action.
        self.selected: str = name
        self.show_debrids(select=name)

    def show_debrids(self, *, select: str | None = None) -> None:
        """Read the debrids again (after a change), the panel of the debrid `select` (else the same one)."""
        from ..ff import debrid
        from ..windows.debrid import DebridPanel, panel_of
        self.accounts, self.allowed = debrid.debrid_accounts(), debrid.debrids_allowed()
        if select is not None:
            self.selected = select
        index = next((i for i, acc in enumerate(self.accounts) if acc.name == self.selected), 0)
        acc = self.accounts[index] if self.accounts else None
        self.panel = panel_of(acc, self.infos.get(acc.name), index, len(self.accounts), self.allowed) if acc else DebridPanel()

    def ask_infos(self) -> None:
        """Nothing here: the page asks the account info itself (`debrid` "infos")."""

    def state(self) -> JsonData:
        """Return the state of the page: the debrids (their rows and panels), "Use debrid services", the texts."""
        from ..windows.debrid import DebridListRow, debrid_texts, panel_of
        count = len(self.accounts)
        return {
            'allowed': self.allowed, 'texts': debrid_texts(), 'selected': self.panel.account.name if self.panel.account else '',
            'rows': [{'name': row.name, 'info': row.info, 'initials': row.initials, 'dim': row.dim, 'active': acc.active}
                     for acc in self.accounts for row in (DebridListRow.of(acc, self.infos.get(acc.name), self.allowed),)],
            'panels': {acc.name: _debrid_panel(panel_of(acc, self.infos.get(acc.name), index, count, self.allowed))
                       for index, acc in enumerate(self.accounts)},
        }


def _debrid_panel(panel: DebridPanel) -> JsonData:
    """Return the panel of a debrid for the page: its texts, its actions (only in Kodi: of a window of ResolveURL)."""
    return {'title': panel.title, 'info': panel.info, 'summary': panel.summary,
            'actions': {name: {'available': view.available, 'label': view.label, 'help': view.help, 'kodi_only': name in DEBRID_KODI_ONLY}
                        for name, view in panel.actions.items()}}


def debrid(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the debrid services (no `data`: the account info forgotten, the page asks it again), do an action of `data` on the
    debrid `name`: `infos` (ask the account info of the authorized ones), a switch (`active`, `allowed`: `value`), `move` (`delta` places in
    the priority order), an action of the window (its dialog, `web_dialog`; only in Kodi: refused).
    """
    from ..ff import debrid as ff_debrid
    from ..windows.debrid import CONTROL_ACTIONS, action_account, fetch_infos, run_action, run_switch
    if not data:
        _debrid_infos.clear()
    view = WebDebrid(str((data or {}).get('name', '')))
    action = str((data or {}).get('action', ''))
    if action == 'infos':
        fetch_infos(view)  # type: ignore[arg-type]  # the view of the operations of the window
        view.show_debrids()
    elif action in ('active', 'allowed'):
        run_switch(view, action, bool(data and data.get('value')))  # type: ignore[arg-type]  # the view of the operations of the window
    elif action == 'move' and data:
        if (acc := view.panel.account) is None or acc.name != data.get('name'):
            raise KeyError(data.get('name'))  # gone meanwhile: no move of another one
        if not ff_debrid.move(acc, _delta(data)):
            raise PermissionError(action)
        view.show_debrids(select=acc.name)
    elif action in CONTROL_ACTIONS and action not in DEBRID_KODI_ONLY:
        if (acc := action_account(view.panel, action)) is None:  # type: ignore[arg-type]
            raise PermissionError(action)
        return web_dialog.start(device, _run(lambda: run_action(view, action, acc), view))  # type: ignore[arg-type]
    elif action:
        raise PermissionError(action) if action in DEBRID_KODI_ONLY else KeyError(action)
    return view.state()


# --- the accounts ---

class WebAccounts:
    """The accounts for the page: a view of the operations of the window (`lib.windows.accounts.AccountsView`)."""

    def __init__(self, account: str = '') -> None:
        """Read the accounts, the panel of the account `account` (none: the first one)."""
        from ..windows.accounts import AccountPanel
        self.panel: AccountPanel = AccountPanel()
        #: The account the page shows after an action.
        self.selected: str = account
        self.show_accounts(select=account)

    def show_accounts(self, *, select: str | None = None) -> None:
        """Read the accounts again (after a change), the panel of the account `select` (else the same one)."""
        from ..ff import account_admin as admin
        from ..windows.accounts import AccountPanel
        self.rows = admin.account_rows()
        if select is not None:
            self.selected = select
        acc = next((row.account for row in self.rows if row.account.id == self.selected), self.rows[0].account if self.rows else None)
        self.panel = AccountPanel.of(acc) if acc is not None else AccountPanel()

    def show_panel(self) -> None:
        """The panel again (the sync asked)."""
        self.show_accounts()

    def focus_action(self, action: str) -> None:
        """Nothing here (the page has its own focus)."""

    def state(self) -> JsonData:
        """Return the state of the page: the accounts (their rows - the image of the service, `/art/` - and panels), the lines of the switches."""
        from ..windows.accounts import AccountListRow, AccountPanel, cell_help_text, grid_lines, service_image
        lines = grid_lines()
        panels: dict[str, JsonData] = {}
        icons = {row.account.id: service_image(row.account) for row in self.rows}
        for row in self.rows:
            panel = AccountPanel.of(row.account)
            panels[row.account.id] = {
                'title': panel.title, 'label': panel.label, 'info': panel.info, 'summary': panel.summary, 'sync': panel.sync,
                'active': row.account.active, 'icon': icons[row.account.id],
                'actions': {name: {'available': view.available, 'label': view.label, 'help': view.help} for name, view in panel.actions.items()},
                'cells': {cell: {'value': view.value, 'available': view.available, 'help': cell_help_text(cell, view)}
                          for cell, view in panel.cells.items()}}
        return {'selected': self.panel.account.id if self.panel.account else '',
                'rows': [{'id': shown.id, 'title': shown.title, 'info': shown.info, 'dim': shown.dim, 'icon': icons[shown.id]}
                         for shown in map(AccountListRow.of, self.rows)],
                'panels': panels,
                'grid': {'heading': lines.heading, 'menus_heading': lines.menus_heading, 'context_heading': lines.context_heading,
                         **{name: [[line.name, line.label] for line in getattr(lines, name)] for name in ('capabilities', 'directions', 'menus', 'context_menus')}}}


def accounts(data: Mapping[str, Any] | None = None, *, device: str = '') -> JsonData:
    """
    Return the state of the accounts, do an action of `data` on the account `account` (an action of the window, a switch - `active` or a
    cell: `switch`, its `value`) in its dialog (`web_dialog`: it may ask); `move` (`delta` places in the order) at once.
    """
    from ..ff import account_admin as admin
    from ..windows.accounts import run_action, run_switch
    view = WebAccounts(str((data or {}).get('account', '')))
    action = str((data or {}).get('action', ''))
    if not action:
        return view.state()
    if action == 'move' and data:
        if (acc := view.panel.account) is None or acc.id != data.get('account'):
            raise KeyError(data.get('account'))  # gone meanwhile: no move of another one
        if not admin.move(acc, _delta(data)):
            raise PermissionError(action)
        view.show_accounts(select=acc.id)
        return view.state()
    if action == 'switch':
        name, value = str(data.get('switch', '')) if data else '', bool(data and data.get('value'))
        if name != 'active' and name not in view.panel.cells:
            raise KeyError(name)
        return web_dialog.start(device, _run(lambda: run_switch(view, name, value), view))
    if action not in get_args(admin.AccountAction) or action == 'active':
        raise KeyError(action)
    shown = view.panel.actions.get(action)  # type: ignore[call-overload]
    if action != 'add' and not (view.panel.account and shown is not None and shown.available):
        raise PermissionError(action)
    return web_dialog.start(device, _run(lambda: run_action(view, action), view))  # type: ignore[arg-type]


def _run(action: Callable[[], Any], view: WebDebrid | WebAccounts) -> Callable[[], str]:
    """Return the action of a dialog: its result - the debrid / the account the page shows after it."""
    def run() -> str:
        action()
        return view.selected
    return run


#: The views of the pages and of the rows by their names (`web_config.VIEW_PAGES`, `web_config.ROW_VIEWS`): `(data, device=) -> state` (`data`:
#: an action on it, None: none).
VIEWS: Mapping[str, Callable[..., JsonData]] = {'addons': providers, 'debrid': debrid, 'accounts': accounts, 'menus': menus, 'general': general,
                                                'feeds': feeds, 'folders': folders, 'appearance': appearance, 'filters': filters}
