"""
The configuration of FanFilm on the web page (`web_server.Server`, the routes `/config`): the pages of the configuration window in its order
- a page of a card of settings (`lib.ff.config.options`; the groups and rows the page shows now: `shown_groups()` of its class, every row as
the window has it: `setting_row()`) as JSON: the schema (labels, help, options, the positions of the scales: the Kodi language) and the state
(the values, the shown texts and colours, the positions and texts of the scales, why a row is grayed); a page of its own view (the source
providers, the debrid services, the accounts: `web_views`) by its name. A value of access data (`Card.access_keys()`) is never in the state,
only whether it is set (one value on its own: `secret()`). A write is checked by the declaration (`accept()`) and by the row as the window
shows it now (grayed, a value of the window itself: refused); a switch of the web server which may cut the page off is asked twice on the page
(`guard`). An action of a row the class of its page declares (`setting_row()`: its dialogs by `lib.ff.ui`, no window) runs on the page too
(`run()`), an action the window adds (a window of Kodi) only in Kodi; the defaults of a page restored as in the window (`restore_defaults()`).
"""

from __future__ import annotations
import re
from functools import partial
from typing import Any, Callable, Iterator, Mapping, TYPE_CHECKING
from typing_extensions import TypeAlias, get_args
from attrs import frozen
from ..ff.config import config
from ..ff.config.blocks import Card, CatalogSetting, accept
from ..ff.config.options import SourceSettings, Web
from ..ff.source.filters import SelectionMedia
from ..ff.types import JsonData
from ..kolang import LL
if TYPE_CHECKING:
    from ..kolang import LazyLabel
    from ..windows.config_dialog import PageRef
    from ..windows.widgets.setting_list import SettingRow

#: The fields of a catalog entry not sent to the page (the old settings of `settings.xml`; the scale: its positions instead; a row shown by a
#: condition: in the rows of the page only when shown).
UNSENT_FIELDS: frozenset[str] = frozenset({'legacy', 'legacy_value', 'scale', 'shown_when'})
#: The kinds of the rows only Kodi uses: an action runs a Kodi builtin (or a window of the page), a state is shown by its page.
KODI_ONLY: frozenset[str] = frozenset({'action', 'state'})
#: The settings of the web server which may cut the page off (the access of this device, of the network): asked twice on the page.
GUARDED: frozenset[str] = frozenset(Web.pointer(key) for key in (Web.this_device.key, Web.network.key))
#: The question of a change which may cut the page off (`GUARDED`: asked again; the page asks it of a row, `restore_defaults()` of a page).
GUARD_QUESTION: LazyLabel = LL(33019, 'This page may lose the web server after the change (Kodi can undo it). Change it?')
#: The actions of the web server the page does on its own tab (by their pointers): the password, the requests, the devices.
PAGE_TABS: Mapping[str, str] = {Web.pointer(key): 'devices' for key in (Web.sign_in.key, Web.requests.key, Web.paired_devices.key)}
#: The pages of the window of their own view on the page (`web_views`), by their names.
VIEW_PAGES: frozenset[str] = frozenset({'addons', 'debrid', 'accounts', 'menus', 'general', 'feeds', 'folders', 'appearance'})
#: The rows which open a window of their own in Kodi (the filter and the sort of the sources of a media): on the page a view of its own
#: (`web_views`) - by their pointers: the view, its item.
ROW_VIEWS: Mapping[str, tuple[str, str]] = {SourceSettings.pointer(f'selection_{media}'): ('filters', media) for media in get_args(SelectionMedia)}
#: The pattern of the names of the views in the routes (`/config/<name>`): of the pages, of the rows.
VIEW_ROUTE: str = '|'.join(sorted(VIEW_PAGES | {view for view, _ in ROW_VIEWS.values()}))

#: The images of the themes the page may show (`/art/<variant>/<image>`: the icons of the services), relative to a media folder of a theme.
ART_IMAGE: str = r'services/\w+/\w+\.png'

#: The pages of the window with a card by the pages of this installation (made once: the page modules imported).
_pages: tuple[tuple[PageRef, ...], dict[PageRef, type[Any]]] | None = None


@frozen(kw_only=True)
class Row:
    """A setting of the configuration on the page: its row of the window (the value, its write, why grayed, the shown text), its pointer."""

    #: The row as the window has it (`setting_row()` of its page, a row of a panel of a view).
    row: SettingRow
    #: The pointer of its value in the configuration (its ID on the page).
    pointer: str
    #: Its value is access data (never in the state).
    access: bool = False
    #: Read only on the page: a value of the window itself with no write (`ROW_VALUES` of its page: the version).
    readonly: bool = False
    #: A value of the window itself with a write which may ask (`ROW_VALUES`: the simple view): written in a dialog of the page (`run()`).
    asks: bool = False
    #: Only Kodi uses it (an action of a window, a state of no value of the window): no value on the page.
    kodi_only: bool = False
    #: It may cut the page off (`GUARDED`): the page asks twice.
    guard: bool = False
    #: The tab of the page which does it (an action of the web server: `PAGE_TABS`), '' none.
    tab: str = ''
    #: The view of the page it opens (`ROW_VIEWS`: the view, its item), None: none.
    opens: tuple[str, str] | None = None

    @property
    def entry(self) -> CatalogSetting:
        """Return its entry of the catalog (as the row shows it now)."""
        return self.row.setting


def art_image(path: str) -> str:
    """Return the image of the themes of a path (`ART_IMAGE` at its end, a whole folder: the page shows it by `/art/`), '' another one."""
    return found[1] if path and (found := re.search(f'(?:^|/)({ART_IMAGE})$', path.replace('\\', '/'))) else ''


def card_pages() -> dict[PageRef, type[Any]]:
    """Return the classes of the pages of the window that show a card (the page modules imported once: a class knows its card)."""
    global _pages
    from ..windows.config_dialog import page_refs
    refs = page_refs()
    if _pages is None or _pages[0] != refs:
        found: dict[PageRef, type[Any]] = {}
        for ref in refs:
            cls = ref.page_class()
            card = getattr(cls, 'CARD', None)
            if isinstance(card, type) and issubclass(card, Card) and card is not Card:
                found[ref] = cls
        _pages = (refs, found)
    return _pages[1]


def _page_rows(page: type[Any]) -> Iterator[tuple[str, Row]]:
    """
    Return the rows of a page of a card as it shows them now (its groups and rows shown now, a row in the place of another one:
    `setting_row()`), with the IDs of their groups.
    """
    from ..windows.widgets.setting_list import usable_rows
    card_class = page.CARD
    access = set(card_class.access_keys())
    for group in page.shown_groups():
        for entry in page.shown_settings(group):
            row = usable_rows([page.setting_row(entry)])[0]
            key = row.setting['key']  # the row shown (a row in the place of another one: its own key)
            pointer, own = card_class.pointer(key), page.ROW_VALUES.get(key)
            kodi_only = row.setting['kind'] in KODI_ONLY and own is None and row.run is None and pointer not in ROW_VIEWS
            yield f'{card_class.ROOT}#{group.key}', Row(row=row, pointer=pointer, access=key in access, readonly=own is not None and own.set is None,
                                                       asks=own is not None and own.set is not None, guard=pointer in GUARDED, kodi_only=kodi_only,
                                                       tab=PAGE_TABS.get(pointer, ''), opens=ROW_VIEWS.get(pointer))


#: The rows of the pages of the cards with the IDs of their groups (`page_rows()`): by the page classes.
PageRows: TypeAlias = 'dict[type[Any], list[tuple[str, Row]]]'


def page_rows() -> PageRows:
    """Return the rows of the pages of the cards as they show them now (`_page_rows()`), once for a whole answer (the schema and the state)."""
    return {page: list(_page_rows(page)) for page in card_pages().values()}


def rows(found: PageRows | None = None) -> dict[str, Row]:
    """
    Return the rows of the cards of the configuration on the page now (`found`: read already) by their pointers; read now: in a block of
    reads only (`answer_memo()`: the state of the add-ons... once; the same as the answers the page has, a write checked by them).
    """
    if found is None:
        from ..ff.memo import answer_memo
        with answer_memo():
            found = page_rows()
    return {row.pointer: row for page_list in found.values() for _, row in page_list}


def _page_refs() -> tuple[PageRef, ...]:
    """Return the pages of the window of this installation."""
    from ..windows.config_dialog import page_refs
    return page_refs()


def setting_json(row: Row) -> JsonData:
    """
    Return a setting for the page: its catalog entry (no old settings), its pointer, access data, read only, only Kodi, asked twice, the tab
    of the page which does it; a scale: the values and texts of its positions (any whole number typed in too: `typed`, the fill of its slider:
    `mode`), a range: the positions of each knob (`[start, stop)`).
    """
    data: JsonData = {key: value for key, value in row.entry.items() if key not in UNSENT_FIELDS}
    data['pointer'] = row.pointer
    for flag in ('access', 'readonly', 'asks', 'kodi_only', 'guard', 'tab', 'opens'):
        if value := getattr(row, flag):
            data[flag] = list(value) if isinstance(value, tuple) else value
    if (scale := row.entry.get('scale')) is not None:
        data['positions'] = [{'value': scale.value_at(pos), 'text': scale.text(pos)} for pos in range(scale.last + 1)]
        if row.entry['kind'] == 'scale':
            from ..windows.widgets.setting_list import ListSlider
            data['mode'] = ListSlider(row.entry['kind'], scale).mode  # the fill of its slider as the window has it
            if scale.typed:  # any whole number typed in too (the number dialog of the window)
                data['typed'] = True
        if row.entry['kind'] == 'range':
            low, high = scale.knob_positions('min'), scale.knob_positions('max')
            data['knobs'] = {'min': [low.start, low.stop], 'max': [high.start, high.stop]}
    return data


def schema(found: PageRows | None = None) -> JsonData:
    """
    Return the pages of the configuration in the order of the window: `{"pages": [{"name", "title", "level", "columns": [[{"id", "label",
    "settings": [...]}]]}]}` (a page of a card: the groups it shows now; `level` 1: a page under another one); a page of its own view:
    `"view": true` (`web_views`), another page: `"kodi_only": true`. `found`: the rows read already (`page_rows()`).
    """
    pages: list[JsonData] = []
    with_card = card_pages()
    found = page_rows() if found is None else found
    for ref in _page_refs():
        page: JsonData = {'name': ref.name, 'title': ref.title(), 'level': ref.level}
        if (cls := with_card.get(ref)) is not None:
            groups = {group.key: group for group in cls.shown_groups()}
            columns: dict[int, list[JsonData]] = {}
            grouped: dict[str, list[JsonData]] = {}
            for group_id, row in found[cls]:
                grouped.setdefault(group_id, []).append(setting_json(row))
            for key, group in groups.items():
                group_id = f'{cls.CARD.ROOT}#{key}'
                columns.setdefault(group.column, []).append({'id': group_id, 'label': group.label, 'settings': grouped.get(group_id, [])})
            page['columns'] = [columns[column] for column in sorted(columns)]
        elif ref.name in VIEW_PAGES:
            page['view'] = True
        else:
            page['kodi_only'] = True
        pages.append(page)
    return {'pages': pages}


def stamp() -> str:
    """
    Return the stamp of the configuration: of its file (its time and size; the accounts too) and of the sync of the accounts (another one:
    changed - by the page or outside it).
    """
    from ..ff.config.store import file_stat
    from ..ff.sync import sync_state
    return repr((file_stat(config.path()), sync_state()))


def state(found: Mapping[str, Row] | None = None) -> JsonData:
    """
    Return the state of the rows (`found`, None: of the cards): `{"values": {<pointer>: value | {"set": bool} of access data}, "shown":
    {<pointer>: [text, colour]} (a text of the row itself, a colour: the one in effect - the default one too), "positions": {<pointer>: the
    position of a scale | of the knobs of a range}, "texts": {<pointer>: the text of a scale, a range}, "reasons": {<pointer>: why grayed}}`.
    """
    values: dict[str, Any] = {}
    shown: dict[str, list[str]] = {}
    positions: dict[str, Any] = {}
    texts: dict[str, str] = {}
    reasons: dict[str, str] = {}
    for pointer, row in (rows() if found is None else found).items():
        setting = row.row
        if setting.reason:
            reasons[pointer] = setting.reason
        if row.kodi_only:  # its text: a state of the window (e.g. of the web server, asked from the service)
            continue
        if not row.access and (setting.shown is not None or row.entry['kind'] == 'color'):
            shown[pointer] = list(setting.shown_value())
        value = setting.get()
        values[pointer] = {'set': value not in ('', None)} if row.access else value
        if (scale := row.entry.get('scale')) is not None:
            try:
                if row.entry['kind'] == 'range':
                    low, high = scale.range_positions(*value)
                    positions[pointer], texts[pointer] = [low, high], scale.range_text(low, high, values=tuple(value))  # a typed end: its number
                else:
                    positions[pointer] = scale.position_of(value)
                    texts[pointer] = scale.value_text(value, positions[pointer])  # a number off the steps as it is
            except (TypeError, ValueError):
                pass  # a value of no position (a broken one): no knob shown
    return {'values': values, 'shown': shown, 'positions': positions, 'texts': texts, 'reasons': reasons}


def check(row: Row, pointer: str, value: Any) -> Any:
    """
    Return the value of a write of a row checked by its declaration and by the row now: ValueError of a value of none of its declaration,
    PermissionError of a row read only, grayed or of Kodi only (a write which asks: only in its dialog, `run()`).
    """
    if row.readonly or row.kodi_only or not row.row.usable:
        raise PermissionError(pointer)
    try:
        return accept(row.entry, value)
    except ValueError as exc:
        raise ValueError(f'{pointer}: {exc}') from None


def write(changes: Mapping[str, Any]) -> None:
    """
    Write the changes (`{<pointer>: value}`) checked by their declarations and by the rows now (`check()`; KeyError of a pointer of no row
    shown now; PermissionError of a write which asks: `run()`), all or none (one write).
    """
    found = rows()
    writes: list[Callable[[], None]] = []
    for pointer, value in changes.items():
        if (row := found.get(pointer)) is None:
            raise KeyError(pointer)
        if row.asks:
            raise PermissionError(pointer)
        writes.append(partial(row.row.set, check(row, pointer, value)))
    with config.batch():
        for done in writes:
            done()


def secret(pointer: str) -> Any:
    """Return the value of a setting of access data (shown on the page at a request), KeyError of another pointer."""
    if (row := rows().get(pointer)) is None or not row.access:
        raise KeyError(pointer)
    return row.row.get()


def run(pointer: str, device: str, value: Any = None) -> JsonData:
    """
    Run the action of a row on the page (an action of the class of its page), or a write which asks (`asks`: `value`), in a dialog of the page
    (`web_dialog`); return its first state; KeyError of no such row shown now, PermissionError of a grayed one or of one only in Kodi, ValueError
    of a value of none of its declaration.
    """
    from . import web_dialog
    if (row := rows().get(pointer)) is None or (row.entry['kind'] != 'action' and not row.asks):
        raise KeyError(pointer)
    if row.asks:
        if not row.row.usable:
            raise PermissionError(pointer)
        return web_dialog.start(device, partial(row.row.set, accept(row.entry, value)))
    if row.kodi_only or not row.row.usable or row.row.run is None:
        raise PermissionError(pointer)
    return web_dialog.start(device, row.row.run)


def customized() -> list[str]:
    """Return the names of the pages of the window whose configuration is not the default one (their defaults can be restored)."""
    return [ref.name for ref in _page_refs() if ref.page_class().customized()]


def restore_defaults(name: str, device: str) -> JsonData:
    """
    Restore the configuration of the page `name` as after a new installation after a question (as the context menu of its tab in the
    window: `ask_defaults()` in its dialog, `web_dialog`; a page of a setting which may cut the page off: asked again), return its first
    state; KeyError of no such page, PermissionError of one not changed.
    """
    from . import web_dialog
    from ..windows.widgets.tabs import ask_defaults
    if (ref := next((ref for ref in _page_refs() if ref.name == name), None)) is None:
        raise KeyError(name)
    if not (page := ref.page_class()).customized():
        raise PermissionError(name)
    guarded = not GUARDED.isdisjoint(page.defaults())

    def restore() -> None:
        """Ask (a setting which may cut the page off: again), then restore the defaults."""
        from ..ff.ui import ui  # the interaction of the thread of the dialog (the page)
        if ask_defaults(page) and (not guarded or ui.confirm(str(GUARD_QUESTION), heading=page.TITLE())):
            page.reset_defaults()

    return web_dialog.start(device, restore)
