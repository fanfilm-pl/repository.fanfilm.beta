
"""
FanFilm Add-on

Service base: cyclic works (background threads) shared by service modules.

MIT
"""

from __future__ import annotations
import json
from functools import wraps
from time import monotonic, thread_time
from typing import Sequence, Union, TYPE_CHECKING
from typing_extensions import Protocol
from typing_extensions import TypeAlias
from weakref import WeakSet
from attrs import define, frozen, Factory
from .exc import ExitBaseException
from ..ff.threads import Thread, Event, CancelScope, Lock
from ..ff.control import window
from ..ff.settings import settings
from ..ff.kotools import xsleep, video_playing
from ..ff.debug.timing import TIMING_LOGGER, TIMING_MIN_WORK
from ..ff.logs import fflog, fflog_exc, developer_line_written
from ..plugin_remote import local_quiet
from const import const
if TYPE_CHECKING:
    from typing import Any, Callable
    from .remote import RemoteCalls

#: An interval of a cyclic work [s]: a number or a function of it read at every cycle and after a reload of `const`
#: (e.g. `CONST_REF.tune.db.cleanup_interval`); 0 or None of a function: the work waits (switched off for now).
Interval: TypeAlias = Union[float, 'Callable[[], float | None]']
#: The longest sleep of a work switched off for now [s] (a reload of `const` wakes it anyway).
OFF_SLEEP = 3600
#: The Home window property of the timing of the works counted for the whole run of Kodi (`KodiRun`): JSON. It lives as long as
#: the Kodi process: a restart of the service keeps it, a change of the profile too (Kodi stops only the services: the profile is in it).
RUN_PROPERTY = 'fanfilm.service.run'


class Rechecking(Protocol):
    """A sleeper of an interval of `const` (a member of `service_works`)."""

    def recheck(self) -> None:
        """Read the interval again now (`const` reloaded)."""


@define(eq=False)  # by identity: a member of `service_works`
class Work:
    """Cyclic work (function called periodically in its own thread)."""

    #: Work name (function qualname).
    name: str
    #: Function called cyclically.
    func: Callable[..., None]
    #: Interval between calls [s].
    interval: Interval = 0
    #: Thread running the work.
    thread: Thread | None = None
    #: Event to wake up the sleeping thread (force call or stop).
    break_event: Event = Factory(Event)
    #: Set by stop(), cyclic loop exits instead of calling `func`.
    stopped: bool = False
    #: Set by recheck(): the sleeping thread reads its interval again (no call unless the new one has passed).
    rechecking: bool = False

    def force_call(self) -> None:
        """Force re-call cyclic function now."""
        self.break_event.set()

    def recheck(self) -> None:
        """Read the interval again now (`const` reloaded): a shorter one ends the sleep sooner."""
        self.rechecking = True
        self.break_event.set()

    def stop(self) -> None:
        """Stop cyclic calling (wakes up the sleeping thread)."""
        self.stopped = True
        self.break_event.set()


@frozen
class FirstSleep:
    """The first sleep of a cyclic work counted for the whole run of Kodi (`KodiRun.first_sleep()`)."""

    #: The interval of the sleep.
    interval: Interval
    #: The start of the sleep (`monotonic()`).
    since: float


@define(eq=False)
class KodiRun:
    """
    The timing of the cyclic works counted for the whole run of Kodi (`cyclic_call(per_kodi=True)`), kept in the Home window
    (`RUN_PROPERTY`) over a restart of the service (an update of FF, the add-on disabled and enabled, `service/restart`). Its times are
    of `monotonic()`: the clock of the system, the same in every interpreter of the Kodi process.
    """

    #: The service starts with Kodi (or with its profile), not again in this run of Kodi.
    kodi_start: bool
    #: The profile of Kodi (`special://profile`).
    profile: str
    #: The start of Kodi (of its profile).
    started: float
    #: The end of the last call of a work by its name (`Work.name`).
    ends: dict[str, float] = Factory(dict)
    #: Guards the writes of the property.
    _lock: Lock = Factory(Lock)

    @classmethod
    def load(cls) -> KodiRun:
        """Return the timing of this run of Kodi from the Home window, a new one (written now) at the start of Kodi or of its profile."""
        from xbmcvfs import translatePath
        profile: str = translatePath('special://profile')
        try:
            data = json.loads(window().getProperty(RUN_PROPERTY) or 'null')
            if isinstance(data, dict) and data.get('profile') == profile:
                ends = {str(name): float(end) for name, end in data['ends'].items()}
                return cls(kodi_start=False, profile=profile, started=float(data['start']), ends=ends)
        except (ValueError, TypeError, KeyError, AttributeError):  # a broken property: as at the start of Kodi
            pass
        run = cls(kodi_start=True, profile=profile, started=monotonic())
        run.save()
        return run

    def save(self) -> None:
        """Write the timing to the Home window."""
        window().setProperty(RUN_PROPERTY, json.dumps({'profile': self.profile, 'start': self.started, 'ends': self.ends}))

    def called(self, name: str) -> None:
        """Note the end of a call of the work now."""
        with self._lock:
            self.ends[name] = monotonic()
            self.save()

    def first_sleep(self, name: str, first_interval: Interval, next_interval: Interval) -> FirstSleep | None:
        """
        Return the first sleep of the work: its first interval from the start of Kodi (not called yet in this run of Kodi), else its next
        one from the end of its last call; None for a work called once (`next_interval` a number 0) and called already.
        """
        if (end := self.ends.get(name)) is None:
            return FirstSleep(interval=first_interval, since=self.started)
        if not callable(next_interval) and not next_interval:
            return None
        return FirstSleep(interval=next_interval, since=end)


def calls_quiet() -> bool:
    """
    Return True if no plugin call (a folder, a widget) ran for `const.tune.service.quiet_calls` s: the user waits for none (at the start
    of Kodi the widgets come together). The calls in the service and the ones run in the plugin (`local_quiet()`: the Kodi start before
    the service, a play, an escaped one); none of them in the tests, the CLI.
    """
    quiet = local_quiet(hang=const.tune.service.remote_plugin.hang_timeout)
    if remote_calls is not None:
        quiet = min(quiet, remote_calls.quiet_for())
    return quiet >= const.tune.service.quiet_calls


def service_busy() -> str:
    """Return what the user does now (a video, the calls of the service, see `calls_quiet()`), empty if nothing."""
    if video_playing():
        return 'the end of the video'
    if not calls_quiet():
        return 'the quiet of the calls'
    return ''


def when_idle(func: Callable[..., None], *, limit: Interval | None = None) -> Callable[..., None]:
    """
    Return the maintenance work `func` of a cyclic call waiting while the user does something (`service_busy()`, checked every
    `const.tune.service.wait_check_interval`), at most `limit` s (None: no limit): its CPU and disk work could make the video stutter
    on a weak device, it holds up the widgets of the start of Kodi (one GIL for every add-on). A direct call of `func` (e.g. asked by
    the user) does not wait.
    """
    @wraps(func)
    def call(*args: Any, **kwargs: Any) -> None:
        """Wait while the user does something, then call the work."""
        wait_idle(func.__qualname__, limit=limit)
        func(*args, **kwargs)

    return call


def wait_idle(what: str, *, limit: Interval | None = None, sleep: Callable[[float], bool] | None = None) -> None:
    """
    Wait while the user does something (`service_busy()`, checked every `const.tune.service.wait_check_interval`), at most `limit` s
    (None: no limit), before the work `what` (its name in the log). A step of the wait is `sleep(seconds)`: False ends the wait at
    once (e.g. a request of the user); None: `xsleep()`, the stop of the service ends the wait (the scope of its thread).
    """
    if why := service_busy():
        fflog(f'[SERVICE] {what} waits for {why}')
        start = monotonic()
        while service_busy() and (limit is None or monotonic() - start < (seconds(limit) or 0)):
            if not (sleep or xsleep)(const.tune.service.wait_check_interval):
                break
        fflog(f'[SERVICE] {what} runs after {monotonic() - start:.0f} s')


def seconds(interval: Interval) -> float | None:
    """Return the interval now [s] (a function: its value, None or 0: switched off for now)."""
    return interval() if callable(interval) else interval


def cyclic_call(interval: Interval | tuple[Interval, Interval], func: Callable[..., None], *args: Any, per_kodi: bool = False,
                **kwargs: Any) -> Work | None:
    """
    Call function cyclically in a separate thread (an error of a call is logged, the next cycle calls it again).
    Interval is `(first, next)` or single value [s]; a number 0 of the next one: called once. A function is read at every
    cycle and after a reload of `const` (`recheck_works()`). With `per_kodi` the timing is counted for the whole run of Kodi
    (`KodiRun`), not of the service: after a restart of the service the work sleeps what is left of its interval, a work called
    once does not run again (no `kodi_run`, e.g. the tests: as without it).
    """

    def sleep(interval: Interval, since: float | None = None) -> None:
        """Sleep the interval (read again at a recheck) from `since` (default: now); return at its end or a forced call."""
        start = monotonic() if since is None else since
        while True:
            if (length := seconds(interval)) is None or (length <= 0 and callable(interval)):
                left: float = OFF_SLEEP  # switched off for now: a recheck wakes it
            else:
                left = length - (monotonic() - start)
            if left > 0:
                xsleep(left, cancel_event=work.break_event)
            if work.stopped or not work.rechecking:
                return  # its end (also of a new interval passed already), a forced call, the stop
            work.rechecking = False
            work.break_event.clear()

    def calling() -> None:
        """Thread loop: sleep and call `func` until stop or exit."""
        interval, since = first_interval, first_since
        try:
            # Kodi abort is handled by xsleep() (raises ExitBaseException).
            # Do not check abortRequested() here, a Monitor created after abort never sees it.
            while True:
                sleep(interval, since)
                since = None
                if work.stopped:
                    return
                work.break_event.clear()  # xsleep() doesn't clear it, force_call() would loop forever
                settings.delete()
                start, cpu = monotonic(), thread_time()
                try:
                    func(*args, **kwargs)
                except ExitBaseException:
                    raise
                except Exception:  # an error of one call (e.g. Kodi could not read the settings): the next cycle calls it again
                    fflog_exc()
                else:
                    if run is not None and not scope.is_set():  # a call cut by the stop of the service runs again after its restart
                        run.called(work.name)
                finally:
                    if (elapsed := monotonic() - start) >= TIMING_MIN_WORK and developer_line_written(TIMING_LOGGER):
                        fflog.debug(f'[TIMING] work {work.name}: {elapsed:.3f}s, cpu {thread_time() - cpu:.3f}s', module=TIMING_LOGGER)
                interval = next_interval
                if not callable(interval) and not interval:
                    return
        except ExitBaseException:
            return
        except Exception:
            fflog_exc()
            raise

    if not interval:
        return None
    if isinstance(interval, Sequence):
        first_interval, next_interval = interval
    else:
        first_interval = next_interval = interval
    first_since: float | None = None
    run = kodi_run if per_kodi else None
    if run is not None:
        if (first := run.first_sleep(func.__qualname__, first_interval, next_interval)) is None:
            fflog(f'[SERVICE] {func.__qualname__} called already in this run of Kodi')
            return None
        first_interval, first_since = first.interval, first.since
        if (length := seconds(first_interval)) is not None and not (length <= 0 and callable(first_interval)):  # (else: off for now)
            fflog(f'[SERVICE] {func.__qualname__}: the first call in {max(0.0, length - (monotonic() - first_since)):.0f} s')
    scope = service_scope
    thread = Thread(target=calling, scope=scope)  # stopped with the service, also in the middle of `func`
    thread.name = f'{thread.name}: {func.__qualname__}'
    work = Work(thread=thread, func=func, name=func.__qualname__, interval=next_interval)
    thread.start()
    service_threads.add(thread)
    service_works.add(work)
    return work


def recheck_works() -> None:
    """Make the cyclic works read their intervals again (`const` reloaded)."""
    for work in list(service_works):
        work.recheck()


def join_threads() -> None:
    """Join all service threads."""
    for th in service_threads:
        th.join()
    service_threads.clear()


#: All service threads (joined on service stop).
service_threads: WeakSet[Thread] = WeakSet()
#: All cyclic works and other sleepers of an interval of `const` (`recheck_works()`).
service_works: WeakSet[Rechecking] = WeakSet()
#: Stop scope of the cyclic works of the current service run (new in `main.run()`, set by `main.stop()`): a work busy
#: in `func` ends at its next request (`ff.requests`) or cache read, its sockets are cut (see `lib.ff.threads.CancelScope`).
service_scope: CancelScope = CancelScope()
#: The timing of the works counted for the whole run of Kodi (`KodiRun.load()` first in `main.run()`), None: no service run (tests).
kodi_run: KodiRun | None = None
#: The plugin calls of the service (`RemoteCalls`, set by it), None: none (the tests, the CLI).
remote_calls: RemoteCalls | None = None
