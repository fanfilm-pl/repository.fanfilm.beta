"""
Plugin calls in the service: the thin plugin (`lib.plugin_remote`) sends a call of a handle (a folder, a widget) here, it
runs warm in a thread of its own (`CallScope`, a child of the service scope); a folder of the user runs beside the widgets (its own
place). The switch: `const.tune.service.remote_plugin`.
A changed `local.py` is loaded again between the calls (`cdefs.const_reload()`).
"""

from __future__ import annotations
from threading import Condition
from time import monotonic, thread_time
from typing import Callable, Dict, List, Optional
from weakref import WeakValueDictionary

from . import base
from ..ff.control import CallScope, reload_local, condVisibility
from ..ff.kotools import kodi_abort_event
from ..ff.debug.timing import TIMING_LOGGER
from ..ff.logs import fflog, fflog_exc, developer_line_written
from ..ff.threads import Thread
from ..ff.types import JsonResult
from ..ff.url import URL
from const import const

#: How often the server checks the end of a call which has not answered Kodi, seconds (the answer itself ends the wait at once).
CALL_END_STEP: float = .05
#: How often a call waiting for a free one looks for a window of the user once the running call took `call_timeout`, seconds.
WINDOW_STEP: float = 1.0
#: A window of the user on the screen: a modal dialog but the busy one of Kodi (a folder loads: a work, not the user).
USER_WINDOW: str = ('System.HasActiveModalDialog + !Window.IsModalDialogTopmost(busydialog)'
               ' + !Window.IsModalDialogTopmost(busydialognocancel)')


class RemoteCalls:
    """
    The plugin calls run in the service, by their kind (`_full()`): a folder of the user one at once, the widgets `calls` at once, beside
    each other; the next ones wait for a free place of their kind. They run in the plugin only if every running call of their kind runs
    longer than `call_timeout` while a window of the user is on the screen (`USER_WINDOW`: any modal dialog, also one not of the running
    call, e.g. of a folder for a waiting widget) or longer than `hang_timeout` (a hang), not because of a long queue.
    """

    def __init__(self, *, on_reload: Optional[Callable[[List[str]], None]] = None) -> None:
        #: The calls by their id (given by the thin plugin), for their abort.
        self._calls: Dict[str, CallScope] = {}
        #: The start (`monotonic()`) of the running calls by their id.
        self._running: Dict[str, float] = {}
        #: Guards `_calls` and `_running`, wakes the waiting calls (a call ended, an abort).
        self._cond = Condition()
        #: Called after `local.py` was loaded again (the changed keys), e.g. to publish the switch again.
        self._on_reload = on_reload
        #: The end of the last call (`monotonic()`; the start of the server before any): the maintenance works wait for the quiet.
        self._ended_at: float = monotonic()

    def serve(self) -> None:
        """The server of the calls started: its calls are the ones of the service (`base.calls_quiet()`), quiet from now."""
        with self._cond:
            self._ended_at = monotonic()
        base.remote_calls = self

    def run(self, call_id: str, argv: List[str], *, folder: bool) -> Optional[JsonResult]:
        """
        Run the plugin call, return when it answered Kodi or ended without the answer (`answered`); `here`: run it in the
        plugin (a play, no free call in time, the switch off). At Kodi exit no call starts (`answered` false at once: Kodi
        stops only after the thin plugin ended, it does not abort it). None: the id is of a call still known (a wrong client).
        """
        from ..indexers.play import is_play_url
        if kodi_abort_event.is_set():
            return {'answered': False}
        if not const.tune.service.remote_plugin.enabled or is_play_url(URL(argv[0] + argv[2])):  # a play: the source search, the player
            return {'here': True}
        call = CallScope(argv, parent=base.service_scope)
        call.folder = folder
        call.items = WeakValueDictionary()
        with self._cond:
            if call_id in self._calls:
                return None  # another call: its abort and its end must stay its own
            self._calls[call_id] = call  # an abort while the call waits for a free one
        try:
            entered = self._enter(call_id, call)
        except BaseException:
            self._leave(call_id)
            raise
        if not entered:
            self._leave(call_id)
            if call.is_set() or kodi_abort_event.is_set():  # aborted while it waited, Kodi exits
                return {'answered': False}
            return {'here': True}
        thread = Thread(target=self._run, args=(call_id, call), scope=call, name=f'Plugin call {call_id}')
        try:
            thread.start()
        except BaseException:
            self._leave(call_id)
            raise
        while not call.answer.wait(CALL_END_STEP):
            if not thread.is_alive():
                break
        return {'answered': call.answered}

    def abort(self, call_id: str) -> bool:
        """Abort the call (Kodi aborted its thin plugin): its threads stop, its sockets are cut, it writes to Kodi no more."""
        with self._cond:
            if (call := self._calls.get(call_id)) is None:
                return False
            call.set()
            self._cond.notify_all()  # it may wait for a free call
        return True

    def _enter(self, call_id: str, call: CallScope) -> bool:
        """
        Wait for a free call of its kind and take it (`_full()`: a folder of the user, the widgets); False if every running call of its
        kind runs longer than `call_timeout` with a window of the user on the screen or longer than `hang_timeout` (see `RemoteCalls`),
        aborted or Kodi exits.
        """
        start = monotonic()
        tune = const.tune.service.remote_plugin
        shown = checked = False
        with self._cond:
            if waits := bool(self._full(call)) and developer_line_written(TIMING_LOGGER):
                fflog.debug(f'[TIMING] remote call {call_id}: waits for {self._holders(call)}', module=TIMING_LOGGER)
            while not call.is_set() and not kodi_abort_event.is_set() and (running := self._full(call)):
                held = monotonic() - max(running)  # the youngest running call of its kind
                if held >= tune.hang_timeout or (shown and held >= tune.call_timeout):
                    why = 'a window of the user' if shown else 'a hang'
                    fflog(f'[FF] remote call {call_id}: the running calls take over {held:.0f} s ({why}), run in the plugin')
                    if developer_line_written(TIMING_LOGGER):
                        fflog.debug(f'[TIMING] remote call {call_id}: to the plugin after {monotonic() - start:.3f}s, held by {self._holders(call)}',
                                    module=TIMING_LOGGER)
                    return False
                if held < tune.call_timeout:
                    shown = False
                    self._cond.wait(min(tune.call_timeout, tune.hang_timeout) - held)
                    continue
                if checked:
                    checked = False
                    self._cond.wait(min(WINDOW_STEP, tune.hang_timeout - held))
                    continue
                # Kodi GUI never under the lock: Kodi stops an aborted thin plugin holding its GUI lock, the abort takes this lock
                self._cond.release()
                try:
                    shown = not call.is_set() and not kodi_abort_event.is_set() and bool(condVisibility(USER_WINDOW))
                finally:
                    self._cond.acquire()
                checked = not shown  # the state again first: a wake-up while the lock was free is not lost
            if call.is_set() or kodi_abort_event.is_set():
                return False
            if waits:
                fflog.debug(f'[TIMING] remote call {call_id}: waited {monotonic() - start:.3f}s', module=TIMING_LOGGER)
            if not self._running:
                self._reload_local()  # no call runs: a call sees one `const` from its start to its end
            self._running[call_id] = monotonic()
            return True

    def _kind(self, call: CallScope) -> dict[str, float]:
        """Return the running calls (id: start) of the kind of the call, under the lock: a folder of the user or not (a widget)."""
        # ponytail: the kind is `call.folder` - a FF folder shown by the media window, not this call: a widget started over a FF folder
        # (more than 3 FF widgets, a reload) takes the place of the folder, a folder opened from the list of add-ons goes with the
        # widgets; at worst as one call at once
        return {cid: since for cid, since in self._running.items()
                if (running := self._calls.get(cid)) is not None and bool(running.folder) == bool(call.folder)}

    def _full(self, call: CallScope) -> list[float]:
        """
        Return the starts of the running calls of the kind of the call if no place of its kind is free (a folder of the user: one, the
        list of the folder of the service is one; the widgets: `const.tune.service.remote_plugin.calls`), else empty; under the lock.
        """
        running = self._kind(call)
        return list(running.values()) if len(running) >= (1 if call.folder else const.tune.service.remote_plugin.calls) else []

    def _holders(self, call: CallScope) -> str:
        """Return the running calls of the kind of the call (their id, path, age) for a timing line, under the lock."""
        now = monotonic()
        return ', '.join(f'{cid} {held.argv[0] if (held := self._calls.get(cid)) is not None and held.argv else "?"} ({now - since:.1f}s)'
                         for cid, since in self._kind(call).items())

    def reload_local(self) -> None:
        """Load `local.py` again if it changed and no call runs (a cycle of the service; the next call does it too)."""
        from cdefs import local_changed
        if local_changed():
            with self._cond:
                if not self._running:
                    self._reload_local()

    def _reload_local(self) -> None:
        """Load a changed `local.py` again (under the lock, no call runs, `reload_local()`), the works and the server follow it."""
        if (changed := reload_local()) is None:
            return
        base.recheck_works()  # the cyclic works read their intervals again
        if self._on_reload is not None:
            try:
                self._on_reload(changed)
            except Exception:
                fflog_exc()

    def kodi_exit(self) -> None:
        """Kodi exits: the calls waiting for a free one end at once (no call starts any more, see `run()`)."""
        with self._cond:
            self._cond.notify_all()

    def _leave(self, call_id: str) -> None:
        """Free the call, wake the waiting ones."""
        with self._cond:
            self._calls.pop(call_id, None)
            if self._running.pop(call_id, None) is not None:
                self._ended_at = monotonic()
            self._cond.notify_all()

    def quiet_for(self) -> float:
        """
        Return the seconds since the end of the last call (since the start of the server before any), 0 while a call runs; a call
        running longer than `const.tune.service.remote_plugin.hang_timeout` is hung, not a call of the user (the works go on).
        """
        now = monotonic()
        with self._cond:
            if any(now - since < const.tune.service.remote_plugin.hang_timeout for since in self._running.values()):
                return 0.0
            return now - self._ended_at

    def _run(self, call_id: str, call: CallScope) -> None:
        """Run the call in its thread, destroy its FFItems (the Kodi GC can not see their cycles), free the call."""
        from ..launch import run_call
        from ..ff.item import FFItem
        from ..ff.kodidb import video_db
        start, cpu = monotonic(), thread_time()
        if const.debug.enabled and const.debug.tty:
            yellow, yellow_bold, off = '\033[93m', '\033[93;1m', '\033[0m'
        else:
            yellow = yellow_bold = off = ''
        try:
            video_db.reset()  # the FF plays of Kodi DB: read again in every call (MySQL)
            if const.debug.enabled:
                fflog(f'{yellow} [FF] remote enter {off} {call_id}: {call.argv}, folder={call.folder}')
            run_call(call)
        finally:
            items = call.items or {}
            count = len(items)
            FFItem.destroy_ffitems(list(items.values()), own=items)  # not the linked items of the service
            self._leave(call_id)
            if const.debug.enabled:
                from ..ff.tricks import memory_stats
                fflog(f'{yellow} [FF] remote exit {off} {call_id} --- ({monotonic() - start:.3f}s, cpu {thread_time() - cpu:.3f}s),'
                      f' aborted={call.is_set()}, call items={count}, {memory_stats()}')
