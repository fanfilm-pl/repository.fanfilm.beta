"""
Simple HTTP Web server for FanFilm Kodi addon users.

Used to help users set up their Kodi addon by providing a web interface.
"""

if True:  # to avoid: module level import not at top of file (flake8 E402)
    def cli_define():
        from ..dev.main import predefine as tui_predefine, base_args_parser
        p = base_args_parser()
        p.add_argument('-p', '--port', type=int, default=8663, help='server port')
        p.add_argument('-t', '--threading', action='store_true', help='multithreading / concurrent requests')
        p.add_argument('-j', '--user-js', choices=['stable', 'beta'], help='cat fanfilm.user.js file (for stable or beta version)')
        p.add_argument('--help', action='help', help='show this help message and exit')
        args, _ = tui_predefine(args=p.parse_args())
        return args

    if __name__ == '__main__':
        cli_args = cli_define()
    else:
        cli_args = None

from typing import Any, Callable, Optional, Type, Mapping, TYPE_CHECKING
from pathlib import Path
from weakref import WeakSet
from fnmatch import fnmatch
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from ipaddress import ip_address
import base64
import hmac
import json
import secrets
import socket
import ssl
import time
from attrs import frozen
from .http_request import (
    RequestHandler, RoutedServer, Route, request, Address, PUBLIC, Request, host_name,
    HTTPBadRequest, HTTPNotFound, HTTPUnprocessableContent, HTTPStatusException, ExpectedJsonObjectError,
)
from . import web_auth, web_crypto
from .web_auth import (Device, DEVICE_HEADER, PAGE_CLIENT, PAIR_HEADER, SCRIPT_CLIENT, SEALED, SIGNATURE_HEADER, TIME_HEADER,
                       allows, grant)
from .web_config import ART_IMAGE, GUARD_QUESTION, VIEW_ROUTE
from ..ff.threads import Thread, Event
# from ..ff.routing import Router
from ..ff.types import JsonData
from ..ff.logs import fflog, fflog_exc
from ..ff.tricks import JsonEncoder
from ..ff.cookies import cookie_sites, receive_cookies, setting_name, set_target_value, target_value
from ..ff.web_settings import LOOPBACK_ADDRESS, WEB_REQUEST_JOB, WEB_REQUEST_PROPERTY, listen_address, local_off, local_role
from ..kolang import L, LL, kodi_locale
from const import const
if TYPE_CHECKING:
    from .main import Works
    from socketserver import BaseRequestHandler
    from ..kolang import LazyLabel

#: The labels of the groups of the scopes of the routes (`<group>:read` / `<group>:write`, the first part of the path of a route).
SCOPE_GROUPS: 'dict[str, str]' = {
    'info': L(31214, 'State of FanFilm'),
    'cookies': L(31215, 'Cookies from the browser'),
    'credentials': L(31216, 'Cookies and access data of the providers'),
    'diagnostic': L(31117, 'Diagnostic code'),
    'devices': L(31217, 'Paired devices'),
    'password': L(31218, 'Password of the web server'),
    'config': L(33003, 'Configuration of FanFilm'),
    'search': L(31413, 'Search of movies and TV shows'),
}
#: The texts of the page and of the browser script made by FanFilm (in the Kodi language), asked for by their English texts (`T()`,
#: `web/mod/app.js`, `web/mod/fanfilm.user.js`).
WEB_TEXTS: 'tuple[LazyLabel, ...]' = (
    LL(30150, 'Configuration'),
    LL(31335, 'Loading…'),
    LL(30394, 'Error'),
    LL(33004, 'Only in Kodi'),
    LL(33005, 'Set', ctx='a value of access data is set'),
    LL(33006, 'Not set'),
    LL(33007, 'New value'),
    LL(33008, 'Show', ctx='show a value of access data'),
    LL(33010, 'Not saved'),
    LL(33011, 'Read only here: change it in Kodi'),
    LL(33012, 'Theme', ctx='of the web page'),
    LL(33013, 'Auto', ctx='theme of the web page'),
    LL(33014, 'Light', ctx='theme of the web page'),
    LL(33015, 'Dark', ctx='theme of the web page'),
    LL(30736, 'Yes'),
    LL(30752, 'No'),
    LL(30445, 'Cancel'),
    LL(33016, 'OK'),
    LL(33020, 'Enter a value…'),
    LL(30753, 'Default'),
    LL(32863, 'Move up'),
    LL(32866, 'Move down'),
    LL(30890, 'Add…'),
    LL(30512, 'Remove'),
    LL(30100, 'Restore defaults'),
    LL(32056, 'Are you sure?'),
    GUARD_QUESTION,
    # the advanced search
    LL(32010, 'Search'),
    LL(32001, 'Movies'),
    LL(32002, 'TV Shows'),
    LL(31398, 'Found: {n}'),
    LL(31394, 'Each of the checked ones'),
    LL(31414, 'Find'),
    LL(31415, 'Without'),
    LL(31416, 'Show in Kodi'),
    LL(31401, 'Save as a FanFilm list...'),
    LL(30817, 'Clear'),
    LL(32036, 'History'),
    LL(31417, 'Edit'),
    LL(31333, 'From…'),
    LL(31334, 'To…'),
    LL(31402, 'Name of the list'),
    LL(30127, 'Nothing found'),
    # the pairing of this browser, a request of another device
    LL(31426, 'Disconnect'),
    LL(31427, 'Connect to Kodi'),
    LL(31428, 'To approve another device, connect this browser first (e.g. with the code from the TV).'),
    LL(31429, 'Code from the TV (FanFilm → Tools → Web server)'),
    LL(31430, 'Connect'),
    LL(31431, 'Connect with a phone or approve in Kodi'),
    LL(31432, 'QR code'),
    LL(31433, 'Scan this code with a phone already connected to FanFilm or approve the request in Kodi (Tools → Web server).'),
    LL(31435, 'Match code'),
    LL(31436, 'Server password'),
    LL(31437, 'Log in'),
    LL(31356, 'Access request'),
    LL(31438, '[B]{name}[/B] ({address}) asks for access to FanFilm.'),
    LL(31439, 'check that the same one is shown on that device.'),
    LL(31440, 'Role'),
    LL(31357, 'Approve'),
    LL(31235, 'Reject'),
    LL(31441, 'Connected to {name}'),
    LL(31442, 'Too many failed attempts, try later'),
    LL(31443, 'Wrong or expired code'),
    LL(31444, 'Request rejected'),
    LL(31445, 'Request expired'),
    LL(31446, 'Request error: {message}'),
    LL(31447, 'Wrong password'),
    LL(31448, 'This browser cannot approve other devices'),
    LL(31449, 'The request is invalid or already handled'),
    LL(31450, 'Approved: {name}'),
    LL(31451, 'Rejected'),
    # the start page
    LL(31452, 'Start'),
    LL(31453, '✓ This browser is connected to Kodi [B]{kodi}[/B].'),
    LL(31454, 'Connect this browser with Kodi (above): the code from the TV, the QR code of the address row in Kodi (FanFilm → Tools → Web '
              'server) or a request approved in Kodi.'),
    LL(31455, 'A script written in JavaScript'),
    LL(31456, 'Script'),
    LL(31457, 'sends the cookies and the user agent directly to the FanFilm add-on (the browser and Kodi in the same network):'),
    LL(31458, 'Install the extension'),
    LL(31459, 'Install the script'),
    LL(31460, ', NOTE: for the beta version install the script'),
    LL(31461, 'Open the settings of Tampermonkey, set the config mode to “Advanced”'),
    LL(31462, 'Next, in the section [I]Security[/I] set [I]Allow scripts to access cookies[/I] to [I]All[/I] and click the button [I]Save[/I]'),
    LL(31463, 'Click [I]Connect the script[/I] in the [I]Devices[/I] tab (one click, no code) — or [I]Connect[/I] in the FanFilm widget of a '
              'site (bottom right corner)'),
    LL(31464, 'Allow the script access, [I]Always allow[/I] recommended'),
    LL(31465, 'Open a site, for example:'),
    LL(31466, 'The script uses the same settings on all supported sites. It also detects changes of the cookies (up to 5 seconds) and sends them '
              'to the FanFilm add-on automatically.'),
    LL(31467, 'More devices: the QR code in the [I]Devices[/I] tab (a phone scans it from this screen) or the address row in Kodi.'),
    # the credentials
    LL(31468, 'Credentials'),
    LL(30938, 'Save'),
    LL(31469, 'Read error!'),
    LL(31470, 'Save error!'),
    # the diagnostic code
    LL(31310, 'Diagnostics'),
    LL(30782, 'Code'),
    LL(31471, 'Copy'),
    LL(31472, 'Enter a code'),
    LL(31473, 'e.g. 025'),
    LL(31474, 'Unknown parts of the code (bits: {bits}) — update FanFilm'),
    LL(31475, 'State on this Kodi:'),
    LL(31476, 'Point at a field to see its description.'),
    LL(31477, 'no code'),
    LL(31478, 'code {code} — waiting for a restart of Kodi'),
    LL(31479, 'code {code} — {minutes} min left'),
    LL(31480, 'code {code} — ended'),
    LL(31481, 'Copied: {code}'),
    LL(31482, 'Could not copy, select the code and copy it by hand'),
    LL(31483, 'Invalid code: {message}'),
    # the devices
    LL(31484, 'Devices'),
    LL(31485, 'Access requests'),
    LL(31486, 'Connected devices'),
    LL(31487, 'Device'),
    LL(31488, 'Last used'),
    LL(31250, 'Address'),
    LL(31489, 'Approved by'),
    LL(31490, 'Role: {role}'),
    LL(31491, 'Next device'),
    LL(31492, 'Address of this Kodi:'),
    LL(31493, 'The QR code pairs a phone with one scan (from this screen), at most with the role of this browser.'),
    LL(31494, 'QR code for the next device'),
    LL(31495, 'Script in this browser'),
    LL(31496, 'The FanFilm script (Tampermonkey) of this browser gets its own access to this Kodi and adds it to its list.'),
    LL(31497, 'Connect the script'),
    LL(31498, 'The password is set (logging in without the code from the TV).'),
    LL(31499, 'No password.'),
    LL(31500, 'The password never leaves the browser (FanFilm gets only keys, which cannot log in). Without HTTPS do not use a password from '
              'other places — best generate one.'),
    LL(31501, 'New password'),
    LL(31502, 'Repeat'),
    LL(31503, 'Set the password'),
    LL(31504, 'Generate'),
    LL(31242, 'Remove the password'),
    LL(31505, 'Generated password — save it now (e.g. in a password manager), you will not see it again:'),
    LL(31506, 'Error reading the devices: {message}'),
    LL(31507, 'This browser will lose the management of the devices (you can restore it in Kodi). Change?'),
    LL(31508, 'New role: {name}'),
    LL(31239, 'Remove the device {name}?'),
    LL(31509, 'No FanFilm script in this browser — install it (tab Start) and reload the page'),
    LL(31510, 'Script connected to this Kodi'),
    LL(31511, 'Password set'),
    LL(31512, 'The passwords are not the same'),
    LL(31513, 'Remove the server password?'),
    # the browser script (its widget on the sites: the list of Kodi, the pairing, the messages)
    LL(31514, 'Kodi (☑ send)'),
    LL(31515, 'IP or IP:PORT'),
    LL(31516, 'Default port: {port}.'),
    LL(31517, 'Connect to {host}:'),
    LL(31518, 'Code from the TV'),
    LL(31519, 'Connect with the code'),
    LL(31521, 'Scan with a phone connected to FanFilm or approve in Kodi.'),
    LL(31539, 'Ask for access (QR code)'),
    LL(31537, 'Asking Kodi for access…'),
    LL(31538, 'Approve the request in Kodi (code {match})'),
    LL(31522, 'Send'),
    LL(31523, 'Add {nick} as a public IMDb account'),
    LL(31524, 'Sent to Kodi'),
    LL(31525, 'Sending error!'),
    LL(31526, 'Sent: {done}/{all}'),
    LL(31527, 'No host set up!'),
    LL(31528, 'Status: sending to {n} servers...'),
    LL(31529, 'Status: sending...'),
    LL(31530, 'Send to this Kodi'),
    LL(31531, 'Remove from the list (and disconnect in Kodi)'),
    LL(31532, 'Kodi does not answer: remove this device in Kodi too (Web server → Paired devices)'),
    LL(31533, 'No connection with Kodi'),
    LL(31534, 'Kodi did not accept the request'),
    LL(31535, 'No access - connect with Kodi'),
)
#: The names of the device of Kodi in a `Host` header of a browser of it (no pairing only with one of them: a proxy or a tunnel to the
#: loopback gives its own name mostly; `0.0.0.0` is the address the server listens on, not its name).
LOCAL_NAMES: 'frozenset[str]' = frozenset({'127.0.0.1', 'localhost', '::1'})
#: The paths of the pairing (a device without a key: only from a home address), the end of a pairing (a signed device, from anywhere).
PAIR_PATH: str = '/pair/'
LOGOUT_PATH: str = '/pair/logout'
#: The policy of the page: its scripts, styles and connections only of the server (an injected script would read the key of the device);
#: no `unsafe-eval` (the CSP build of sprae parses its expressions itself), inline styles for the ones sprae sets.
CONTENT_SECURITY_POLICY: str = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                                "object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
#: The first byte of a TLS connection (a handshake record): the same port serves HTTPS and HTTP.
TLS_HANDSHAKE: int = 0x16
#: The files of the own certificate of the web server (the names of the web server of Kodi): in the FF profile, else the ones of Kodi
#: in its user data (only read; written there, they would switch the web server of Kodi to HTTPS).
CERT_FILE: str = 'server.pem'
KEY_FILE: str = 'server.key'
KODI_CERT_FOLDER: str = 'special://userdata'
#: The browsers of a device name by their user agent tokens, the first one found (Edge and Opera tell Chrome too, Chrome tells Safari).
BROWSERS: 'dict[str, str]' = {'Edg/': 'Edge', 'OPR/': 'Opera', 'Firefox/': 'Firefox', 'Chrome/': 'Chrome', 'Safari/': 'Safari'}
#: The systems of a device name by their user agent tokens, the first one found (Android tells Linux too).
SYSTEMS: 'dict[str, str]' = {'Android': 'Android', 'iPhone': 'iPhone', 'iPad': 'iPad', 'CrOS': 'ChromeOS', 'Windows': 'Windows',
                             'Mac OS X': 'macOS', 'Linux': 'Linux'}


@frozen(kw_only=True)
class Sealing:
    """The seal of the content of a request and of its answer (`Server.authorize()`)."""

    #: The key of the seals: of the device, of the key agreement of a pairing.
    key: bytes
    #: The binding of the content: the method, the path and the time of the signature of the request (a pairing: the ID of its agreement).
    binding: bytes
    #: The binding of the answer: the signature of the request (a pairing: `binding`).
    answer: bytes
    #: The key agreement of a pairing, None: a device.
    handshake: 'web_auth.Handshake | None' = None


def device_name(user_agent: str) -> str:
    """Return a name of a device from its user agent (`Firefox (Linux)`), the agent itself if not known."""
    browser = next((name for token, name in BROWSERS.items() if token in user_agent), '')
    system = next((name for token, name in SYSTEMS.items() if token in user_agent), '')
    if not browser and not system:
        return user_agent[:40]
    return f'{browser or "Browser"} ({system})' if system else browser


def reachable_name(name: str) -> bool:
    """Return False if another device can not reach the server by the name: `localhost`, a loopback address, `0.0.0.0` (the listening one)."""
    if name == 'localhost':
        return False
    try:
        address = ip_address(name)
    except ValueError:
        return True
    return not (address.is_loopback or address.is_unspecified)


def tls_context() -> 'ssl.SSLContext | None':
    """Return the TLS context of the own certificate (FF profile, else of the web server of Kodi), None if there is none."""
    from ..ff.control import dataPath
    from xbmcvfs import translatePath
    for folder in (Path(dataPath), Path(translatePath(KODI_CERT_FOLDER))):
        cert, key = folder / CERT_FILE, folder / KEY_FILE
        if cert.is_file() and key.is_file():
            try:
                context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                context.load_cert_chain(str(cert), str(key))
            except (OSError, ssl.SSLError) as exc:
                fflog.warning(f'[WEB] certificate {cert} not used: {exc}')
                continue
            fflog(f'[WEB] HTTPS by {cert}')
            return context
    return None


if TYPE_CHECKING:
    class ServerBase(ThreadingHTTPServer):
        pass
elif __name__ == '__main__' and not cli_args.threading:  # DEBUG only !!!
    class ServerBase(HTTPServer):
        pass
else:
    class ServerBase(ThreadingHTTPServer):
        pass


class Server(RoutedServer, ServerBase):
    """FanFilm Web Server."""

    daemon_threads = True  # terminate worker threads when main thread terminates

    MIME_TYPES = {
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
    }

    @staticmethod
    def credentials() -> 'list[str]':
        """Return the names of the supported credentials (the targets of `cookie_sites()`, not the accounts)."""
        return [name for name in (setting_name(value) for hc in cookie_sites().values() for value in hc.values()) if not name.startswith('account:')]

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler] = RequestHandler,
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        from ..ff.kotools import Notification
        super().__init__(server_address, RequestHandlerClass, works=works)
        self.path = Path(__file__).parent.parent.parent / 'web'
        self._active_requests: 'WeakSet[socket.socket]' = WeakSet()
        #: The pairing of the devices (codes, requests, failures of the addresses).
        self.pairing: web_auth.Pairing = web_auth.Pairing()
        #: The signatures of the requests of the window of `signature_window` (a request is never accepted twice), by their times.
        self._signatures: 'dict[str, float]' = {}
        #: The SCRAM logins started by their full nonces.
        self._scram: 'dict[str, web_auth.ScramStart]' = {}
        #: The TLS context of the own certificate (None: HTTP only), read at the start.
        self.tls: 'ssl.SSLContext | None' = None
        # The web server is driven from outside Kodi (a browser): its notifications are silent (e.g. a TV while watching).
        self._update_notif = Notification('FanFilm', L(30519, 'Received cookies'), sound=False)

    @staticmethod
    def modify_js_for_beta(file: bytes) -> bytes:
        """Modify JavaScript file content for beta version."""
        import re
        file = re.sub(rb'^(//\s*@name\s+FanFilm)$', rb'\1 Beta', file, flags=re.MULTILINE)
        file = re.sub(rb'^(// @(?:icon|downloadURL|updateURL)\b\s+ https://raw.githubusercontent.com/fanfilm-pl/)repository.fanfilm/',
                      rb'\1repository.fanfilm.beta/', file, flags=re.MULTILINE)
        return file

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass (a TLS connection of the own certificate wrapped first)."""
        fflog(f'New request {request} from {client_address}')
        self._active_requests.add(request)
        try:
            if self.tls is not None and self._tls_hello(request):
                request = self.tls.wrap_socket(request, server_side=True)
                self._active_requests.add(request)
            self.RequestHandlerClass(request, client_address, self)
        except (ssl.SSLError, OSError) as exc:
            fflog(f'[WEB] connection of {client_address} failed: {exc}')
        finally:
            self._active_requests.discard(request)
        fflog(f'Finish request {request} from {client_address}')

    @staticmethod
    def _tls_hello(sock: 'socket.socket') -> bool:
        """Return True if the connection starts with a TLS handshake (its first byte read without taking it, in the thread of the request)."""
        timeout = sock.gettimeout()
        sock.settimeout(const.tune.service.web_server.auth.wait_timeout)
        try:
            first = sock.recv(1, socket.MSG_PEEK)
        except OSError:
            return False
        finally:
            sock.settimeout(timeout)
        return bool(first) and first[0] == TLS_HANDSHAKE

    # --- authorization ---

    def scopes(self, device: 'Device | None') -> 'tuple[str, ...]':
        """Return the scopes of a device (none without a device)."""
        return () if device is None else device.scopes

    def authorize(self, request: Request) -> None:
        """
        Find the device of the request (`request.device`): a signed request of a device (a page, the browser script), a browser of the
        device of Kodi (the loopback: the role of its setting, no key); open its sealed content (`_open()`). A public route passes, else 401
        without a device, 403 without the scope of the route (an undeclared scope: 403 too). Refused first (403): the loopback with this
        device off (`local_off()`, a paired one too), a pairing (`PAIR_PATH`, its logout not) of no home request (`home_request()`).
        """
        address = web_auth.address_of(request.handler)
        if local_off() and ip_address(address).is_loopback:
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': 'this device off'})
        if request.url.path.startswith(PAIR_PATH) and request.url.path != LOGOUT_PATH and not self.home_request(request, address):
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': 'not a home address'})
        device = self._device(request)
        object.__setattr__(request, 'device', device)
        self._open(request, device)
        scope = request.route.scope
        if scope == PUBLIC:
            return
        if device is None:
            raise HTTPStatusException(status_code=401, data={'status': 'error', 'error': 'not paired', 'pair': True})
        if not scope or not allows(self.scopes(device), scope):
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': f'no scope {scope or "(none)"}'})

    @staticmethod
    def home_request(request: Request, address: str) -> bool:
        """
        Return True for a request of the home network (`web_auth.home_address()`); the loopback only by a local name (`LOCAL_NAMES`): a tunnel
        or a proxy of this device (from the internet) gives its own name.
        """
        if not web_auth.home_address(address):
            return False
        return not ip_address(address).is_loopback or host_name(request.headers.get('Host', '')) in LOCAL_NAMES

    def _device(self, request: Request) -> 'Device | None':
        """Return the device of the request (see `authorize()`), None if there is none; a wrong signature: 401."""
        headers = request.headers
        address = web_auth.address_of(request.handler)
        if (did := headers.get(DEVICE_HEADER)) is not None:
            device = self._signed_device(request, did)
        elif ip_address(address).is_loopback and host_name(headers.get('Host', '')) in LOCAL_NAMES:
            return self.local_device()  # None: it pairs as any other device
        else:
            return None
        web_auth.touch_device(device, address)
        return device

    @staticmethod
    def local_device() -> 'Device | None':
        """Return the device of a browser of the device of Kodi without pairing (the role of its setting, `local_role()`), None: it pairs."""
        if not (role := local_role()):
            return None
        return Device(id='local', name=L(31219, 'This device'), scopes=web_auth.role_scopes(role), key='')

    def _open(self, request: Request, device: 'Device | None') -> None:
        """
        Set the seal of the request (`request.sealing`): by the key of its device (bound to its signature), else by the key agreement of
        its pairing (`PAIR_HEADER`; none: 401), none for a device without a key (this device without pairing). Its sealed content is
        opened first (its route reads it as `request.json`); a content not sealed by the key: 400, a broken seal: 400 (and the end of a
        key agreement, a failure of the address) - both plain: the client may have no key.
        """
        handshake = None
        if device is not None and device.key:
            key = bytes.fromhex(device.key)
            binding = f'{request.method}\n{request.handler.path}\n{request.headers.get(TIME_HEADER, "")}'.encode()
            answer = request.headers.get(SIGNATURE_HEADER, '').encode()
        elif (sid := request.headers.get(PAIR_HEADER)) is not None:
            if (handshake := self.pairing.handshake(sid)) is None:
                raise HTTPStatusException(status_code=401, data={'status': 'error', 'error': 'no key agreement', 'pair': True})
            key = handshake.key
            binding = answer = f'{request.method}\n{request.handler.path}\n{sid}'.encode()
        else:
            return
        sealing = Sealing(key=key, binding=binding, answer=answer, handshake=handshake)
        if not request.content:
            object.__setattr__(request, 'sealing', sealing)
            return
        data = request.json
        if not isinstance(data, Mapping) or set(data) != {SEALED} or not isinstance(data[SEALED], str):
            raise HTTPBadRequest(message='expect a sealed content')
        try:
            content = json.loads(web_crypto.unseal(key, data[SEALED], binding=binding, direction=web_crypto.REQUEST).decode('utf-8') or '{}')
        except (web_crypto.SealError, ValueError):
            if handshake is not None:
                self.pairing.end_handshake(handshake.sid)
                self.pairing.fail(web_auth.address_of(request.handler))
            raise HTTPBadRequest(message='seal') from None
        object.__setattr__(request, '_json', content)
        object.__setattr__(request, 'sealing', sealing)

    def answer_data(self, request: Request, data: Any) -> Any:
        """Return the JSON answer of a route (an error too) sealed by the key of the request (`request.sealing`), as it is without one."""
        if (sealing := request.sealing) is None or data is None:
            return data
        content = json.dumps(data, cls=JsonEncoder).encode()
        return {SEALED: web_crypto.seal(sealing.key, content, binding=sealing.answer, direction=web_crypto.ANSWER)}

    @staticmethod
    def _pair_handshake() -> web_auth.Handshake:
        """
        Return the key agreement of a request of a pairing (it seals the pairing), 400 without one (`/pair/key` first) or with one of an
        access request already (one pairing of an agreement).
        """
        if (sealing := request.sealing) is None or sealing.handshake is None or sealing.handshake.rid:
            raise HTTPBadRequest(message='pair by a new key agreement (/pair/key)')
        return sealing.handshake

    def _signed_device(self, request: Request, did: str) -> Device:
        """Return the device of a signed request (a page, the script); 401 if its signature is wrong, old (the time of FF told) or used already."""
        def refused(error: str) -> HTTPStatusException:
            """Return the error of a refused signature."""
            return HTTPStatusException(status_code=401, data={'status': 'error', 'error': error, 'time': time.time()})

        stamp, signature = request.headers.get(TIME_HEADER, ''), request.headers.get(SIGNATURE_HEADER, '')
        window = const.tune.service.web_server.auth.signature_window
        now = time.time()
        try:
            if abs(now - float(stamp)) > window:
                raise refused('time')
        except ValueError:
            raise refused('time') from None
        if (device := web_auth.device_by_id(did)) is None:
            raise refused('not paired')
        expected = web_auth.request_signature(device.key, request.method, request.handler.path, stamp, request.content)
        if not hmac.compare_digest(expected, signature):
            raise refused('signature')
        self._signatures = {sig: at for sig, at in self._signatures.items() if now - at <= 2 * window}
        if signature in self._signatures:
            raise refused('replay')
        self._signatures[signature] = now
        return device

    @staticmethod
    def _client(data: Any) -> str:
        """Return the client of a pairing (`PAGE_CLIENT` or `SCRIPT_CLIENT`) from the data of its request."""
        return SCRIPT_CLIENT if isinstance(data, Mapping) and data.get('client') == SCRIPT_CLIENT else PAGE_CLIENT

    def _paired(self, device: Device) -> JsonData:
        """Return the answer of a paired device: it, this FF, the name of Kodi (its key the device derives itself)."""
        return {'device': self.device_json(device), 'instance': web_auth.instance_id(), 'name': self.kodi_name()}

    def device_json(self, device: Device) -> JsonData:
        """Return a device for its clients (no key): its scopes, the label of its role."""
        return {'id': device.id, 'name': device.name, 'client': device.client, 'scopes': list(device.scopes), 'role': web_auth.role_label(device.scopes),
                'created': device.created, 'used': device.used, 'address': device.address, 'approved_by': device.approved_by}

    @staticmethod
    def kodi_name() -> str:
        """Return the name of this Kodi (its setting of the device name)."""
        from xbmc import getInfoLabel
        return getInfoLabel('System.FriendlyName') or 'Kodi'

    def _request_name(self, data: Any) -> str:
        """Return the name of a device of a pairing: given, else from its user agent."""
        name = data.get('name') if isinstance(data, Mapping) else None
        return str(name) if name else device_name(request.headers.get('User-Agent', ''))

    def server_url(self) -> str:
        """Return the address of the server for a browser: https with the own certificate, the loopback if it listens only there, else the IP of Kodi."""
        from xbmc import getIPAddress
        host = LOOPBACK_ADDRESS if self.server_address[0] == LOOPBACK_ADDRESS else getIPAddress()
        return f'{"https" if self.tls is not None else "http"}://{host}:{self.server_address[1]}'

    def _base_url(self) -> str:
        """Return the address of the server as the request used it (a name of the device of Kodi itself: `server_url()`)."""
        host = request.headers.get('Host') or ''
        if not host or not reachable_name(host_name(host)):
            return self.server_url()
        return f'{"https" if isinstance(request.handler.connection, ssl.SSLSocket) else "http"}://{host}'

    @Route.get(r'/info')
    def info(self) -> JsonData:
        """Return this FF (its ID, the name of Kodi, its version, HTTPS, the address of its server) and the scopes of the device."""
        from ..ff.control import addonInfo
        device = request.device
        return {'instance': web_auth.instance_id(), 'name': self.kodi_name(), 'version': addonInfo('version'), 'tls': self.tls is not None,
                'device': self.device_json(device), 'scopes': list(self.scopes(device)), 'roles': self.roles(), 'address': self._base_url()}

    @staticmethod
    def roles() -> 'list[JsonData]':
        """Return the roles (for a choice of an approver, of Kodi)."""
        return [{'id': key, 'label': str(role.label), 'scopes': list(role.scopes)} for key, role in const.tune.service.web_server.roles.items()]

    @Route.post(r'/pair/key', scope=PUBLIC)
    def pair_key(self) -> JsonData:
        """Agree the key of a pairing (`{"key": <public X25519 key, base64>}`): its ID (`PAIR_HEADER` of the pairing) and the key of FF."""
        data = request.json
        try:
            public = base64.b64decode(str(data.get('key', '')), validate=True) if isinstance(data, Mapping) else b''
        except ValueError:
            public = b''
        handshake, own = self.pairing.new_handshake(public, web_auth.address_of(request.handler))
        return {'sid': handshake.sid, 'key': web_auth.b64(own)}

    @Route.post(r'/pair/code', scope=PUBLIC)
    def pair_code(self) -> JsonData:
        """Pair the device by a code shown by Kodi (`{"code": ..., "client": "page" | "script", "name": ...}`, sealed by its key agreement)."""
        handshake = self._pair_handshake()
        self.pairing.end_handshake(handshake.sid)  # one pairing of an agreement, a wrong code too
        data = request.json
        if not isinstance(data, Mapping) or not isinstance(code := data.get('code'), str):
            raise ExpectedJsonObjectError()
        device = self.pairing.use_code(code, name=self._request_name(data), client=self._client(data),
                                       address=web_auth.address_of(request.handler), key=web_crypto.device_key(handshake.key).hex())
        return self._paired(device)

    @Route.post(r'/pair/request', scope=PUBLIC)
    def pair_request(self) -> JsonData:
        """
        Ask for the access (`{"client": ..., "name": ..., "role": ...}`, sealed by its key agreement): return the request (its ID, its
        secret, its code to compare).
        """
        handshake = self._pair_handshake()
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        role = data.get('role')
        scopes = web_auth.role_scopes(role) if isinstance(role, str) and role else (web_auth.ALL_SCOPES,)
        req = self.pairing.new_request(name=self._request_name(data), client=self._client(data), address=web_auth.address_of(request.handler),
                                       scopes=scopes, handshake=handshake)
        self._tell_request(req)
        return {'id': req.id, 'poll': req.poll, 'match': req.match, 'expires': req.expires, 'approve': f'{self._base_url()}/approve#{req.id}'}

    @staticmethod
    def _tell_request(req: web_auth.PairRequest) -> None:
        """
        Tell Kodi a device asks for the access: the window of the requests (the worker script, `WEB_REQUEST_JOB`: one request - its window,
        several - their list; a shown one follows the new ones), while something plays a silent notification (its name and its code).
        """
        from xbmc import getCondVisibility
        from xbmcgui import Window
        from ..ff import control
        from ..ff.kotools import Notification
        if getCondVisibility('Player.HasMedia'):
            Notification('FanFilm', L(31261, 'Access requested: {name} ({code}) - Tools, FanFilm web server', name=req.name, code=req.match),
                         sound=False).show()
        elif not Window(control.HOME_WINDOW).getProperty(WEB_REQUEST_PROPERTY):  # a shown window follows the new requests itself
            control.execute(f'RunScript({control.plugin_id},{WEB_REQUEST_JOB})')

    @Route.get(r'/pair/request/(?P<rid>[-\w]+)', scope=PUBLIC)
    def pair_wait(self, rid: str) -> JsonData:
        """Wait for the answer of a request (`?poll=<secret>`): `waiting` again, `rejected`, `expired`, or paired (again until it is dropped)."""
        req = self.pairing.wait(rid, request.params.get('poll', ''), const.tune.service.web_server.auth.wait_timeout)
        if req.state == web_auth.APPROVED and req.device is not None:
            return {**self._paired(req.device), 'state': req.state}
        return {'state': req.state}

    @Route.get(r'/pair/request/(?P<rid>[-\w]+)/qr.svg', scope=PUBLIC)
    def pair_qrcode(self, rid: str) -> 'tuple[int, bytes, dict[str, str]]':
        """Return the QR code of the approval of a request (`?poll=<secret>`; a phone of the owner scans it)."""
        import io
        import segno
        if (req := self.pairing.request(rid)) is None or not hmac.compare_digest(req.poll, request.params.get('poll', '')):
            raise HTTPNotFound()
        out = io.BytesIO()
        segno.make(f'{self._base_url()}/approve#{req.id}').save(out, kind='svg', scale=6, border=2)
        return 200, out.getvalue(), {'Content-Type': 'image/svg+xml'}

    @Route.get(r'/pair/password', scope=PUBLIC)
    def password_challenge(self) -> JsonData:
        """Start a login by the password (`?nonce=<client nonce>`): the SCRAM salt, iterations and the full nonce; 404 without a password."""
        if (keys := web_auth.password_keys()) is None:
            raise HTTPNotFound()
        client_nonce = request.params.get('nonce', '')
        if not 16 <= len(client_nonce) <= 64 or ',' in client_nonce:
            raise HTTPBadRequest(message='nonce')
        self.pairing.check_address(web_auth.address_of(request.handler))
        now = time.time()
        nonce = client_nonce + secrets.token_urlsafe(18)
        self._scram = {key: start for key, start in self._scram.items() if start.expires > now}
        self._scram[nonce] = web_auth.ScramStart(client_nonce=client_nonce, expires=now + const.tune.service.web_server.auth.code_ttl)
        return {'nonce': nonce, 'salt': keys.salt, 'iterations': keys.iterations, 'user': web_auth.SCRAM_USER}

    @Route.post(r'/pair/password', scope=PUBLIC)
    def password_login(self) -> JsonData:
        """
        Pair the device by the proof of the password (`{"nonce": ..., "proof": ..., "client": ...}`, sealed by its key agreement): the server
        signature with it.
        """
        handshake = self._pair_handshake()
        self.pairing.end_handshake(handshake.sid)  # one pairing of an agreement, a wrong password too
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        address = web_auth.address_of(request.handler)
        self.pairing.check_address(address)
        nonce, proof = str(data.get('nonce', '')), str(data.get('proof', ''))
        start = self._scram.pop(nonce, None)
        keys = web_auth.password_keys()
        signature = None
        if start is not None and start.expires > time.time() and keys is not None:
            signature = keys.verify(keys.auth_message(start.client_nonce, nonce), proof)
        if signature is None:
            self.pairing.fail(address)
            raise HTTPStatusException(status_code=401, data={'status': 'error', 'error': 'wrong password'})
        device = web_auth.add_device(name=self._request_name(data), scopes=(web_auth.ALL_SCOPES,), client=self._client(data),
                                     address=address, key=web_crypto.device_key(handshake.key).hex(), approved_by=L(32648, 'Password'))
        return {**self._paired(device), 'signature': signature}

    @Route.post(LOGOUT_PATH, scope=PUBLIC)
    def logout(self) -> JsonData:
        """Unpair the device of the request (the page forgets its key)."""
        if (device := request.device) is not None and device.id != 'local':
            web_auth.remove_device(device.id)
        return {'status': 'ok'}

    @Route.get(r'/devices')
    def list_devices(self) -> JsonData:
        """Return the devices and the requests waiting for an approval."""
        return {'devices': [self.device_json(device) for device in web_auth.devices()],
                'requests': [req.public() for req in self.pairing.pending()], 'roles': self.roles(),
                'password': web_auth.password_keys() is not None}

    @Route.delete(r'/devices/(?P<did>\w+)')
    def delete_device(self, did: str) -> JsonData:
        """Remove a device."""
        if web_auth.device_by_id(did) is None:
            raise HTTPNotFound()
        web_auth.remove_device(did)
        return {'status': 'ok'}

    @Route.get(r'/devices/requests/(?P<rid>[-\w]+)')
    def waiting_request(self, rid: str) -> JsonData:
        """Return a request waiting for an approval (the approval page of its QR code)."""
        if (req := self.pairing.request(rid)) is None or req.state != web_auth.WAITING:
            raise HTTPNotFound()
        return {'request': req.public(), 'roles': self.roles()}

    @Route.post(r'/devices/requests/(?P<rid>[-\w]+)')
    def answer_request(self, rid: str) -> JsonData:
        """Approve (`{"approve": true, "role": ...}`, at most the scopes of the approver) or reject a request."""
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        approver = request.device
        role = data.get('role')
        wanted = web_auth.role_scopes(role) if isinstance(role, str) and role else (web_auth.ALL_SCOPES,)
        if (req := self.pairing.request(rid)) is not None:
            wanted = grant(wanted, req.scopes)
        req = self.pairing.answer(rid, approve=bool(data.get('approve')), scopes=grant(wanted, self.scopes(approver)),
                                  approved_by=approver.name)
        return {'request': req.public()}

    @Route.post(r'/devices/code')
    def device_code(self) -> JsonData:
        """
        Return a new pairing code given by a device (`{"role": ...}`, at most its own scopes; none: its own) for the next device: the code,
        its end, its link and the QR code of the link (an SVG data URL: the code never in a URL of the server).
        """
        import io
        import segno
        data = request.json
        role = data.get('role') if isinstance(data, Mapping) else None
        own = self.scopes(request.device)
        if role and not (isinstance(role, str) and web_auth.role_scopes(role)):
            raise HTTPUnprocessableContent(message='expect a role')
        code = self.pairing.new_code(grant(web_auth.role_scopes(role) if role else own, own))
        url = f'{self._base_url()}/pair#{code.code}'
        out = io.BytesIO()
        segno.make(url).save(out, kind='svg', scale=6, border=2)
        return {'code': code.code, 'expires': code.expires, 'url': url, 'scopes': list(code.scopes),
                'qr': f'data:image/svg+xml;base64,{base64.b64encode(out.getvalue()).decode()}'}

    @Route.post(r'/devices/script')
    def script_device(self) -> JsonData:
        """
        Pair the browser script of this browser (the page gives it its key, a new random one: the answer sealed by the key of the page): the
        role of the script, at most the scopes of the page; the earlier scripts of the page are replaced.
        """
        page = request.device
        scopes = grant(web_auth.role_scopes(const.tune.service.web_server.auth.script_role), self.scopes(page))
        key = web_crypto.new_secret().hex()
        device = web_auth.add_device(name=f'{page.name} — script', scopes=scopes, client=SCRIPT_CLIENT,
                                     address=web_auth.address_of(request.handler), key=key, approved_by=page.name, page=page.id)
        return {'device': self.device_json(device), 'key': key, 'instance': web_auth.instance_id(), 'name': self.kodi_name(),
                'host': request.headers.get('Host', '')}

    @Route.post(r'/devices/(?P<did>\w+)')
    def change_device(self, did: str) -> JsonData:
        """Give a device a new role (`{"role": ...}`): at most the scopes of the device which changes it."""
        data = request.json
        if not isinstance(data, Mapping) or not isinstance(role := data.get('role'), str) or not web_auth.role_scopes(role):
            raise HTTPUnprocessableContent(message='expect a role')
        changer = request.device
        if (device := web_auth.set_device_scopes(did, grant(web_auth.role_scopes(role), self.scopes(changer)), changed_by=changer.name)) is None:
            raise HTTPNotFound()
        return {'device': self.device_json(device)}

    @Route.post(r'/password')
    def set_password(self) -> JsonData:
        """Set the password by its SCRAM keys made in the browser (`{"salt", "iterations", "stored_key", "server_key"}`) or remove it (`{}`)."""
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if not data:
            web_auth.set_password_keys(None)
            return {'password': False}
        try:
            keys = web_auth.ScramKeys(salt=str(data['salt']), iterations=int(data['iterations']), stored_key=str(data['stored_key']),
                                      server_key=str(data['server_key']))
        except (KeyError, ValueError, TypeError):
            raise HTTPUnprocessableContent(message='expect salt, iterations, stored_key, server_key') from None
        if keys.iterations < const.tune.service.web_server.auth.scram_iterations:
            raise HTTPUnprocessableContent(message=f'iterations < {const.tune.service.web_server.auth.scram_iterations}')
        web_auth.set_password_keys(keys)
        return {'password': True}

    @Route.get(r'/texts', scope=PUBLIC)
    def texts(self) -> JsonData:
        """
        Return the language of Kodi (`pl-PL`: the language of the page, its dates) and the texts of the page and of the browser script in it
        by their English texts (`WEB_TEXTS`): `{"language", "texts": {<English>: <text>}}`.
        """
        return {'language': kodi_locale(), 'texts': {label.args[-1]: str(label) for label in WEB_TEXTS}}

    @staticmethod
    def _config() -> JsonData:
        """
        Return the configuration of FanFilm for the page: its pages (the schema) and its state (`web_config`); after the writes of the
        request, the values of many reads read once (`answer_memo()`).
        """
        from . import web_config
        from ..ff.memo import answer_memo
        with answer_memo():
            found = web_config.page_rows()  # the rows once: the schema and the state
            return {**web_config.schema(found), 'state': web_config.state(web_config.rows(found)), 'stamp': web_config.stamp(),
                    'customized': web_config.customized()}

    @Route.get(r'/config/stamp')
    def config_stamp(self) -> JsonData:
        """Return the stamp of the configuration (the page reads it again at a change: of Kodi, of another page)."""
        from . import web_config
        return {'stamp': web_config.stamp()}

    @Route.get(r'/config')
    def config_pages(self) -> JsonData:
        """Return the configuration of FanFilm for the page: its pages (the schema) and its state (`web_config`)."""
        from ..ff.config import config
        config.fresh_cards()  # as a window of the settings: the options of another language of the information made again
        return self._config()

    @Route.post(r'/config')
    def config_write(self) -> JsonData:
        """
        Write changes of the configuration (`{"changes": {<pointer>: value}}`), return it again (a change may show or hide rows); 422 a wrong
        one, 403 a row the page can not change now.
        """
        from . import web_config
        from ..ff.config import config
        config.fresh_cards()
        data = request.json
        if not isinstance(data, Mapping) or not isinstance(changes := data.get('changes'), Mapping):
            raise ExpectedJsonObjectError()
        try:
            web_config.write(changes)
        except PermissionError as exc:
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': f'not changed here now: {exc}'}) from None
        except KeyError as exc:
            raise HTTPUnprocessableContent(message=f'no setting {exc}') from None
        except ValueError as exc:
            raise HTTPUnprocessableContent(message=str(exc)) from None
        fflog(f'[WEB] configuration changed by {request.device.name!r}: {", ".join(changes)}')  # the pointers only, never a value
        return self._config()

    @Route.post(r'/config/value')
    def config_value(self) -> JsonData:
        """Return one value of access data (`{"key": <pointer>}`): the page shows it at a request (a write scope: a secret revealed)."""
        from . import web_config
        data = request.json
        try:
            return {'value': web_config.secret(str(data.get('key', '')) if isinstance(data, Mapping) else '')}
        except KeyError:
            raise HTTPNotFound() from None

    @Route.post(r'/config/run')
    def config_run(self) -> JsonData:
        """
        Run the action of a row or a write which asks (`{"key": <pointer>, "value"?}`, `web_config.run()`), return its dialog (`web_dialog`);
        403 an action only in Kodi or grayed, 422 no such row shown now or a wrong value.
        """
        from . import web_config
        data = request.json
        pointer = str(data.get('key', '')) if isinstance(data, Mapping) else ''
        try:
            answer = web_config.run(pointer, request.device.id, data.get('value') if isinstance(data, Mapping) else None)
        except PermissionError as exc:
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': f'not done here now: {exc}'}) from None
        except KeyError as exc:
            raise HTTPUnprocessableContent(message=f'no action {exc}') from None
        except ValueError as exc:
            raise HTTPUnprocessableContent(message=str(exc)) from None
        fflog(f'[WEB] {pointer} run by {request.device.name!r}')
        return answer

    @Route.post(r'/config/defaults')
    def config_defaults(self) -> JsonData:
        """
        Restore the configuration of a page as after a new installation (`{"page": <name>}`, after a question: `web_config.restore_defaults()`),
        return its dialog (`web_dialog`); 403 a page not changed, 422 no such page.
        """
        from . import web_config
        data = request.json
        name = str(data.get('page', '')) if isinstance(data, Mapping) else ''
        try:
            answer = web_config.restore_defaults(name, request.device.id)
        except PermissionError as exc:
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': f'not changed: {exc}'}) from None
        except KeyError as exc:
            raise HTTPUnprocessableContent(message=f'no page {exc}') from None
        fflog(f'[WEB] defaults of {name} by {request.device.name!r}')
        return answer

    @Route.get(rf'/config/(?P<page>{VIEW_ROUTE})')
    def config_view(self, page: str) -> JsonData:
        """
        Return the state of a page of its own view (`web_views.VIEWS`: e.g. the source providers, the accounts, the menus); no write in it:
        the values of many reads read once (`answer_memo()`; an action writes first - no memory there).
        """
        from . import web_views
        from ..ff.memo import answer_memo
        with answer_memo():
            return web_views.VIEWS[page](None, device=request.device.id)

    @Route.post(rf'/config/(?P<page>{VIEW_ROUTE})')
    def config_view_action(self, page: str) -> JsonData:
        """
        Do an action on a page of its own view (`{"row" | "name" | "account", "action", ...}`, `web_views`), return its state or its dialog
        (`web_dialog`); 403 an action the page can not do now (only in Kodi, grayed), 422 a wrong one.
        """
        from . import web_views
        from ..ff.config import config
        config.fresh_cards()
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        try:
            answer = web_views.VIEWS[page](data, device=request.device.id)
        except PermissionError as exc:
            raise HTTPStatusException(status_code=403, data={'status': 'error', 'error': f'not done here now: {exc}'}) from None
        except KeyError as exc:
            raise HTTPUnprocessableContent(message=f'no {exc}') from None
        except ValueError as exc:
            raise HTTPUnprocessableContent(message=str(exc)) from None
        if action := data.get('action'):
            fflog(f'[WEB] {page}: {action} by {request.device.name!r}')  # the action only, never a value
        return answer

    @Route.post(r'/config/dialog')
    def config_dialog(self) -> JsonData:
        """The answer of the page to a dialog of an action (`web_dialog.reply()`), return its next state; 404 no such dialog of the device."""
        from . import web_dialog
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        try:
            return web_dialog.reply(request.device.id, data)
        except KeyError:
            raise HTTPNotFound() from None
        except ValueError as exc:
            raise HTTPUnprocessableContent(message=str(exc)) from None

    @Route.get(r'/(index.html|pair|approve)?', scope=PUBLIC)
    def root(self) -> 'tuple[int, str, dict[str, str]] | str':
        """Return the page (its policy: `CONTENT_SECURITY_POLICY`)."""
        try:
            return 200, (self.path / 'index.html').read_text(encoding='utf-8'), {'Content-Security-Policy': CONTENT_SECURITY_POLICY}
        except OSError:
            fflog_exc()
            return '<!DOCTYPE html><html><head><title>FanFilm Web Server</title></head><body>Not supported</body></html>'

    def file(self, path: Path) -> 'tuple[int, bytes, dict[str, str]]':
        """Read static file and return response tuple (status, content, headers)."""
        ext = path.suffix.lower()
        headers: 'dict[str, str]' = {}
        if ctype := self.MIME_TYPES.get(ext):
            headers['Content-Type'] = ctype
        try:
            return 200, path.read_bytes(), headers
        except FileNotFoundError:
            fflog.info(f'Missing static file: {path}')
        except OSError:
            fflog_exc()
        raise HTTPNotFound(f'File not found: {path}')

    @Route.get(rf'/art/(?P<variant>dark|light)/(?P<rel>{ART_IMAGE})', scope=PUBLIC)
    def art(self, variant: str, rel: str) -> 'tuple[int, bytes, dict[str, str]]':
        """
        Return an image of the themes for a surface of the page of the variant (`theme.art()`: of an active theme, else of the base one; an
        icon of a service): only the images of the services, public as the page itself.
        """
        from ..ff import theme
        return self.file(Path(theme.art(rel, variant=variant)))  # none: 404

    @Route.get(r'/(?P<path>(?:static|mod)/.+)', scope=PUBLIC)
    def static(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(self.path / path)

    @Route.get(r'/beta/(?P<path>.+)', scope=PUBLIC)
    def static_beta(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        status, file, headers = self.file(self.path / 'mod' / path)
        if path.endswith('.js') and status == 200 and isinstance(file, bytes):
            file = self.modify_js_for_beta(file)
        return status, file, headers

    @Route.get(r'/addon/(?P<path>(?:fanart\.jpg|icon\.png))', scope=PUBLIC)
    def static_addon(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(Path(__file__).parent.parent.parent / path)

    def _list_credentials(self) -> JsonData:
        from ..sources.natives import catalog_providers, native_catalog
        #: The labels of the settings of the native providers by their targets (`provider:<name>:<key>`): a row as in the settings.
        setting_labels = {f'provider:{prov["id"]}:{setting["key"]}': str(setting['label'])
                          for prov in catalog_providers(native_catalog(build=False)) for setting in prov.get('settings', ()) if setting.get('label')}

        def label(js_name: str, target: str) -> str:
            if target in setting_labels:
                return setting_labels[target]
            if js_name == ':user_agent':
                return L(30353, 'User agent')
            if js_name.startswith(':'):
                return js_name[1:].replace('_', ' ').title()
            if js_name == 'cf_clearance':
                return L(30526, 'Cloudflare cookie')
            return L(30527, 'Cookie ({name})').format(name=js_name)

        return {
            'settings': [
                {
                    'name': name,
                    'value': value,
                    'section': host,
                    'cookie': js_name,
                    'label': label(js_name, name),
                    # 'buttons': ['user_agent'] if js_name == ':user_agent' else [],
                } for host, hsets in cookie_sites().items()
                for js_name, raw_name in hsets.items()
                if (name := setting_name(raw_name)) and not name.startswith('account:') and (value := target_value(name)) is not None
            ]
        }

    def _get_cookie_value(self, target: str, cookie: str) -> str:
        from ..ff.source.utils import extract_cookie
        for cookies_defs in cookie_sites().values():
            for cookie_name, setting in cookies_defs.items():
                if setting_name(setting) == target:
                    return extract_cookie(cookie=cookie, cookie_name=cookie_name)
        return cookie

    @Route.get(r'/credentials/?')
    def list_credentials(self) -> JsonData:
        return self._list_credentials()

    @Route.post(r'/credentials/?')
    def set_all_credentials(self) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if setting_list := data.get('settings'):
            fflog(f'Updating credentials: {", ".join(str(setting.get("name")) for setting in setting_list)}')  # the names only, never a value
            for setting in setting_list:
                name, cookie = setting.get('name'), setting.get('value')
                if name in self.credentials():
                    cookie = self._get_cookie_value(name, cookie)
                    set_target_value(name, cookie)
        return self._list_credentials()

    @Route.post(r'/cookies')
    def update_cookies(self) -> JsonData:
        """
        Write the cookies of a site (`{"host", "cookies", "user_agent", ...}`, `lib.ff.cookies.receive_cookies()`: forwarded to the other FanFilm
        too); a change told by a silent notification (none for the cookies forwarded by another FanFilm).
        """
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        host = data.get('host')
        fflog(f'Updating cookies: {host} ({", ".join(str(cookie.get("name")) for cookie in data.get("cookies", []))})')
        written = receive_cookies(data)
        warning = ''
        if fnmatch(host or '', '*imdb.com') and not written.accounts.get('imdb', {}).get('at-main') and not data.get('imdb_user_id'):
            # no session cookie (not signed in, or the script can not read HttpOnly cookies): nothing for the accounts;
            # told to the sender (the script shows the warning), in Kodi only as the update notification (silent)
            warning = L(30692, 'IMDb: no at-main cookie - not signed in, or the script can not read HttpOnly cookies')
            (fflog if data.get('forced_by_user') else fflog.debug)('IMDb cookies without at-main (not signed in, or no HttpOnly access of the script)')
        if written.changed or data.get('forced_by_user'):
            fflog(f'Changed settings: {", ".join(sorted(written.changed))}')
            if const.tune.service.web_server.update_notification and not data.get('relayed'):
                if warning and data.get('forced_by_user'):
                    from ..ff.kotools import Notification
                    Notification('FanFilm', warning, sound=False).show()
                else:
                    self._update_notif.show()
        return {
            'success': True,
            'settings_count': written.count,
            **({'warning': warning} if warning else {}),
        }

    @staticmethod
    def _diagnostic_page() -> None:
        """Raise HTTPNotFound if the tab "Diagnostics" (the code generator) is off (`const.debug.diagnostic.web_page`)."""
        if not const.debug.diagnostic.web_page:
            raise HTTPNotFound()

    # --- the advanced search (`web_search`: the fields of `lib.ff.discover`) ---

    @staticmethod
    def _search_values(*, body: bool) -> 'tuple[Mapping[str, Any], JsonData]':
        """Return the values of the page (a body `{"values": …}`, else the param `values`: JSON) and the body; 400 not an object."""
        if body:
            data = request.json
            if not isinstance(data, Mapping):
                raise ExpectedJsonObjectError()
        else:
            try:
                data = {'values': json.loads(request.params.get('values') or '{}')}
            except ValueError:
                raise HTTPBadRequest(message='invalid values') from None
        if not isinstance(values := data.get('values') or {}, Mapping):
            raise HTTPBadRequest(message='invalid values')
        return values, data

    @staticmethod
    def _search_call(func: 'Callable[[], JsonData]') -> JsonData:
        """Return the answer of a call of `web_search`: 422 a value the declaration refuses (an unknown media, no choice, off the scale)."""
        try:
            return func()
        except ValueError as exc:
            raise HTTPUnprocessableContent(message=str(exc)) from None

    @Route.get(r'/search/(?P<media>movie|show)')
    def search_schema(self, media: str) -> JsonData:
        """Return the advanced search of the media: the groups, the fields (their choices, the positions of their scales), the defaults."""
        from . import web_search
        return self._search_call(lambda: web_search.schema(media))

    @Route.get(r'/search/(?P<media>movie|show)/count')
    def search_count(self, media: str) -> JsonData:
        """Return the number of the found media of the values (`?values=<JSON>`)."""
        from . import web_search
        values, _ = self._search_values(body=False)
        return self._search_call(lambda: web_search.count(media, values))

    @Route.get(r'/search/(?P<media>movie|show)/history')
    def search_history(self, media: str) -> JsonData:
        """Return the history of the search of the media (its entries with their values)."""
        from . import web_search
        return self._search_call(lambda: web_search.history(media))

    @Route.get(r'/search/lookup/(?P<kind>\w+)')
    def search_lookup(self, kind: str) -> JsonData:
        """Return the found choices of TMDB of the text (`?text=`): a keyword, a person."""
        from . import web_search
        return self._search_call(lambda: web_search.lookup(kind, request.params.get('text', '')))

    @Route.post(r'/search/(?P<media>movie|show)/send')
    def search_send(self, media: str) -> JsonData:
        """Keep the search (`{"values", "names"}`) as a new entry of the history, open its found items in Kodi (playing: not opened)."""
        from . import web_search
        values, data = self._search_values(body=True)
        names = data.get('names') if isinstance(data.get('names'), Mapping) else {}
        fflog(f'[WEB] search of {media} sent to Kodi by {request.device.name!r}')
        return self._search_call(lambda: web_search.send(media, values, names))

    @Route.post(r'/search/(?P<media>movie|show)/save')
    def search_save(self, media: str) -> JsonData:
        """Save the search (`{"values", "name"}`) as a dynamic list of FanFilm; 422 no name, the name taken."""
        from . import web_search
        values, data = self._search_values(body=True)
        fflog(f'[WEB] search of {media} saved as a list by {request.device.name!r}')
        return self._search_call(lambda: web_search.save(media, values, str(data.get('name') or '')))

    @Route.get(r'/diagnostic/areas')
    def diagnostic_areas(self) -> JsonData:
        """Return the areas of the diagnostic code by their bits, the labels of their groups (the characters) and the code of this Kodi."""
        from math import ceil
        from ..ff import diagnostic
        self._diagnostic_page()
        state = diagnostic.read_state()  # fresh: a code entered in the plugin after the start of the service (cached there)
        return {
            'groups': [str(label) for label in const.debug.diagnostic.groups],
            'areas': [{'bit': bit, 'key': key, 'group': bit // diagnostic.CHAR_BITS, 'label': str(const.debug.log_areas[key].label),
                       'help': str(const.debug.log_areas[key].help)} for bit, key in sorted(diagnostic.area_bits().items())],
            'min_length': const.debug.diagnostic.min_length,
            'state': None if state is None else {'code': state.code, 'phase': state.phase, 'minutes_left': ceil(state.left() / 60)},
        }

    @Route.get(r'/diagnostic/code')
    def diagnostic_code(self) -> JsonData:
        """Return the code of the bits (`?bits=0,2,6`, none: no bits) or the bits of a code (`?code=25`); the encoder of `lib.ff.diagnostic`."""
        from ..ff import diagnostic
        self._diagnostic_page()
        min_length = const.debug.diagnostic.min_length
        if (code := request.params.get('code')) is not None:
            try:
                decoded = diagnostic.decode(code)
            except ValueError as exc:
                raise HTTPUnprocessableContent(message=str(exc)) from None
            return {'code': diagnostic.encode(decoded.bits, min_length=min_length), 'bits': sorted(decoded.bits), 'unknown': sorted(decoded.unknown)}
        bits = request.params.get('bits', '')  # an empty value: not in the params (no bits)
        try:
            bit_set = {int(bit) for bit in bits.split(',') if bit.strip()}
        except ValueError:
            raise HTTPBadRequest(message=f'invalid bits: {bits}') from None
        if any(bit < 0 or bit >= diagnostic.CHAR_BITS * diagnostic.MAX_LENGTH for bit in bit_set):
            raise HTTPBadRequest(message=f'bits out of range: {bits}')
        known = diagnostic.area_bits()
        return {'code': diagnostic.encode(bit_set, min_length=min_length), 'areas': [known[bit] for bit in sorted(bit_set) if bit in known]}


class WebServer:
    """The main function that starts the HTTP Web Server."""

    def __init__(self,
                 *,
                 works: Optional['Works'],
                 ) -> None:
        self._running: bool = False
        self._server: Optional[Server] = None
        self._httpd_thread: Optional[Thread] = None
        self.works: Optional['Works'] = works

    @property
    def running(self) -> bool:
        return self._running

    @property
    def server(self) -> Optional[Server]:
        """Return the running server (its pairing: Kodi shows its codes and requests), None if it does not run."""
        return self._server

    def apply_access(self) -> None:
        """
        Start, stop or move the server by its settings (`listen_address()`: off - it does not listen; another address - started there again),
        e.g. at a change of the configuration.
        """
        address = listen_address()
        if self._running and (self._server is None or self._server.server_address[0] != address):
            self.stop()
        if address is not None and not self._running:
            self.start()

    def start(self) -> None:
        """Start proxy server (in new therad) on the address of its settings (`listen_address()`; off: nothing)."""
        if self._running:
            return
        if (address := listen_address()) is None:
            fflog('=== Web Server off ===')
            return

        try:
            # create HTTP server and start serve in new therad
            self._server = Server((address, const.tune.service.web_server.port), RequestHandler, works=self.works)
            self._server.allow_reuse_address = True
            self._server.tls = tls_context()
            self._httpd_thread = Thread(target=self._server.serve_forever, kwargs={'poll_interval': const.tune.service.server_poll_interval},
                                        name='Service WEB')
            self._httpd_thread.start()
            self._running = True

            # get port number and set server URL in the settings
            fflog(f'=== Web Server Started: {self._server.url} ===')

        except Exception:
            # creating HTTP server failed, clear URL in the settings
            self._running = False
            fflog_exc()
            raise

    def stop(self):
        """Stop proxy server."""
        if not self._running:
            return

        # shutdown and close the server
        try:
            if self._server is not None:
                self._server.shutdown()
                self._server.server_close()
                if self._server._active_requests:
                    fflog(f'Active requests: {self._server._active_requests}')
                for req in self._server._active_requests:
                    try:
                        req.shutdown(2)
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                    try:
                        req.close()
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                self._server._active_requests.clear()
                self._server.socket.close()
                self._server._update_notif.close()
                self._server = None
            if self._httpd_thread is not None:
                self._httpd_thread.join()
                self._httpd_thread = None
        except Exception as exc:
            fflog(f'Exception during stopping web server: {exc}')
            fflog_exc()
        self._running = False
        fflog('=== Web Server Stopped ===')


# DEBUG (command line tests)
def main(args):
    def _run_server():
        from .main import Works
        address = '0.0.0.0'
        works = Works(
            events={
                'folder': Event(),
            },
        )
        works.events['folder'].set()
        server = Server((address, args.port), RequestHandler, works=works)
        server.allow_reuse_address = True
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('   Interrupted, shutting down ...')
            server.shutdown()
            server.server_close()
            print('Server stopped.')
        finally:
            from .main import stop
            from ..ff.kotools import destroy_xmonitor
            stop()
            destroy_xmonitor()
        # from threading import enumerate as thread_enumerate
        # from .main import threads
        # print('Active threads:', thread_enumerate())
        # print('FanFilm threads:', threads)

    if args.user_js == 'stable':
        print((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_text(encoding='utf-8'))
    elif args.user_js == 'beta':
        print(Server.modify_js_for_beta((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_bytes()).decode('utf-8'))
    else:
        _run_server()


if __name__ == '__main__' and cli_args is not None:
    main(cli_args)
