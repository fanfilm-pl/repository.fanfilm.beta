"""
Request and routes for simple HTTP Proxy for FanFilm Kodi addon.
"""

from typing import Optional, Union, Any, Tuple, Dict, Set, FrozenSet, Iterable, Mapping
from typing import ClassVar, Type, Callable, TYPE_CHECKING
from typing_extensions import TypeAlias, ParamSpec
import re
# from contextlib import closing
# from contextvars import ContextVar, copy_context
from http.server import BaseHTTPRequestHandler
from http import HTTPStatus
from ipaddress import ip_address
from urllib.parse import parse_qsl
import socket  # for socket.timeout for py < 3.10
import json
from threading import local
from traceback import format_exc
from inspect import Signature, signature
from attrs import define, frozen, field, fields
if TYPE_CHECKING:
    from .main import Works
    from email.message import Message as HeaderMessage

# import requests
import urllib3

from ..ff.logs import fflog, fflog_exc
from ..sdk import threads as sdk_threads
from ..ff.url import URL
# from ..ff.routing import Router
from ..ff.types import JsonResult, remove_optional, is_optional
from ..ff.tricks import JsonEncoder
from const import const


class Answered:
    """The result of a route method that wrote the whole answer itself (`ANSWERED`): the handler writes nothing more."""


#: The route method wrote the whole answer itself (and keeps the connection as it set it).
ANSWERED = Answered()

PS = ParamSpec('PS')
#: A value a route method returns: the content of the answer or `ANSWERED`.
RouteResultValue: TypeAlias = Union[JsonResult, str, bytes, bytearray, None, Answered]
RouteResult: TypeAlias = Union[Tuple[int, RouteResultValue], Tuple[int, RouteResultValue, Optional[Dict[str, str]]], RouteResultValue]

# Disable SSL warnings

urllib3.disable_warnings()
if urllib3.__version__.startswith('1.'):
    urllib3.util.ssl_.DEFAULT_CIPHERS += ':HIGH:!DH:!aNULL'

Host: TypeAlias = str
Port: TypeAlias = int
Address: TypeAlias = Tuple[Host, Port]

#: The domains of the names of a local network only (RFC 6761 `localhost`, RFC 6762 `local`, RFC 8375 `home.arpa`, ICANN `internal`,
#: the never delegated `lan` / `home`, `localdomain` of the resolvers): no page of the internet has such a name.
LOCAL_DOMAINS: Tuple[str, ...] = ('.localhost', '.local', '.home.arpa', '.internal', '.lan', '.home', '.localdomain')


def host_name(host: Host) -> str:
    """Return the name of a `Host` header without its port, lower case (an IPv6 address without its brackets: `[fe80::1]:8663` -> `fe80::1`)."""
    name = host.strip().lower()
    if name.startswith('['):
        return name[1:].partition(']')[0]
    return name.partition(':')[0] if name.count(':') == 1 else name


def local_host(host: Host) -> bool:
    """
    Return True if the `Host` header (a name with an optional port) is not a name of a page of the internet: an IP address, a name
    without a domain (`kodi`, `localhost`) or of a local domain (`LOCAL_DOMAINS`). A page of another name on the address of a server
    in the network (DNS rebinding) reads its answers as its own.
    """
    name = host_name(host)
    try:
        ip_address(name)
        return True
    except ValueError:
        pass
    name = name.rstrip('.')
    return '.' not in name or name.endswith(LOCAL_DOMAINS)

# HTTP route dispatchers.
# GET = Router(standalone=True)
# POST = Router(standalone=True)


class HTTPStatusException(Exception):
    def __init__(self, *args, status_code: int = 0, text: Optional[str] = None, data: Optional[JsonResult] = None,
                 headers: Optional[Mapping[str, str]] = None) -> None:
        super().__init__(*args)
        self.status_code = status_code
        self.text = text
        self.data = data
        self.headers = headers


class HTTPBadRequest(HTTPStatusException):
    def __init__(self, *args, status_code: int = 400, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
        if message is None:
            message = 'bad request'
        if data is None:
            data = {'status': 'error', 'error': message}
        super().__init__(status_code=status_code, *args, data=data, text=text)


class HTTPNotFound(HTTPStatusException):
    def __init__(self, *args, status_code: int = 404, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
        if message is None:
            message = 'not found'
        if data is None:
            data = {'status': 'error', 'error': message}
        super().__init__(status_code=status_code, *args, data=data, text=text)


class HTTPMethodNotAllowed(HTTPStatusException):
    def __init__(self, *args, status_code: int = 405, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None,
                 allow: Optional[Iterable[str]] = None) -> None:
        if message is None:
            message = 'method not allowed'
        if data is None:
            data = {'status': 'error', 'error': message}
        headers = {}
        if allow:
            headers['Allow'] = ', '.join(allow)
        super().__init__(status_code=status_code, *args, data=data, text=text, headers=headers)


# class HTTPNotAcceptable(HTTPStatusException):
#     def __init__(self, *args, status_code: int = 406, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
#         if message is None:
#             message = 'innorect request'
#         if data is None:
#             data = {'status': 'error', 'error': message}
#         super().__init__(status_code=status_code, *args, data=data, text=text)


class HTTPUnprocessableContent(HTTPStatusException):
    def __init__(self, *args, status_code: int = 422, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
        if message is None:
            message = 'unprocessable content'
        if data is None:
            data = {'status': 'error', 'error': message}
        super().__init__(status_code=status_code, *args, data=data, text=text)


class ExpectedJsonObjectError(HTTPUnprocessableContent):
    def __init__(self, *, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
        if message is None:
            message = 'expect JSON object'
        super().__init__(data=data, text=text)


class HTTPUnsupportedMediaType(HTTPStatusException):
    """The content is not of the type the route reads (415)."""

    def __init__(self, *args, status_code: int = 415, message: Optional[str] = None, text: Optional[str] = None, data: Optional[JsonResult] = None) -> None:
        """The error answer: `data` (default: the `message`) or `text`."""
        if message is None:
            message = 'unsupported media type'
        if data is None:
            data = {'status': 'error', 'error': message}
        super().__init__(status_code=status_code, *args, data=data, text=text)


class RequestCut(ConnectionResetError):
    """The content of the request is shorter than its `Content-Length`: its connection was cut (e.g. by the Kodi exit), not its data."""


#: The attribute of a route method: its routes (one for each route decorator).
_ROUTES_ATTR = '_ff_http_routes'
#: The scope of a route anyone uses (no authorization of a server with a policy, `RoutedServer.authorize()`).
PUBLIC: str = 'public'
#: The group of the scope of a route: the first part of its path pattern if it is a plain name (`/cookies`, `/credentials/?`).
_rx_scope_group = re.compile(r'/(?P<group>[a-z][a-z0-9_]*)(?=[/?($\\]|$)')


def route_scope(methods: Iterable[str], path: str) -> str:
    """
    Return the scope of a route derived from its methods and its path pattern: `<group>:read` (GET / HEAD only) or `<group>:write`,
    the group the first part of the path; '' if the pattern does not start with a plain name (a server with a policy needs a declared one).
    """
    if not (mch := _rx_scope_group.match(path)):
        return ''
    return f'{mch["group"]}:{"read" if set(methods) <= {"GET", "HEAD"} else "write"}'


@define
class Route:
    """Simple request route for HTTP server."""
    #: HTTP method.
    methods: Set[str]
    #: Function to call (a method of a server class, called with the server).
    call: Callable[..., RouteResult]
    #: Path pattern.
    pattern: re.Pattern
    #: Call method signature.
    signature: Signature
    #: The scope a device needs for the route (a server with a policy, `RoutedServer.authorize()`): derived from the methods and the path
    #: (`route_scope()`) unless declared, `PUBLIC` anyone.
    scope: str = ''

    @classmethod
    def route(cls, method: Union[str, Iterable[str]], path: str, *,
              scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """
        HTTP route decorator of a method of a server class (`RoutedServer`): the server of the class (or of a subclass) serves it.
        The scope: derived (`route_scope()`) unless given (`PUBLIC`, or a scope of a path not starting with a plain name).
        """
        def wrapper(func: Callable[PS, RouteResult]) -> Callable[PS, RouteResult]:
            route = Route(methods=methods, call=func, pattern=re.compile(path), signature=signature(func),
                          scope=route_scope(methods, path) if scope is None else scope)
            func.__dict__.setdefault(_ROUTES_ATTR, []).append(route)
            return func

        if isinstance(method, str):
            methods = {method}
        else:
            methods = set(method)
        return wrapper

    @classmethod
    def get(cls, path: str, *, scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """HTTP GET route decorator."""
        return cls.route('GET', path, scope=scope)

    @classmethod
    def post(cls, path: str, *, scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """HTTP POST route decorator."""
        return cls.route('POST', path, scope=scope)

    @classmethod
    def put(cls, path: str, *, scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """HTTP PUT route decorator."""
        return cls.route('PUT', path, scope=scope)

    @classmethod
    def patch(cls, path: str, *, scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """HTTP PATCH route decorator."""
        return cls.route('PATCH', path, scope=scope)

    @classmethod
    def delete(cls, path: str, *, scope: Optional[str] = None) -> Callable[[Callable[PS, RouteResult]], Callable[PS, RouteResult]]:
        """HTTP DELETE route decorator."""
        return cls.route('DELETE', path, scope=scope)


@frozen(hash=False)
class Request:
    """Simple request route for HTTP server."""
    #: HTTP methid.
    method: str
    #: Request URL.
    url: URL
    #: Called route.
    route: Route
    #: Matched pattern.
    match: re.Match
    #: Match args.
    args: Dict[str, Any]
    #: Query params.
    params: Dict[str, str]
    # Request handler.
    handler: 'RequestHandler'
    #: JSON constent data (e.g. POST body).
    _json: Optional[JsonResult] = field(default=None, hash=False, repr=False, init=False)
    #: Request content (bytes).
    _content: Optional[bytes] = field(default=None, hash=False, repr=False, init=False)
    #: Request text content (str).
    _text: Optional[str] = field(default=None, hash=False, repr=False, init=False)
    #: The device of the request, set by the policy of the server (`RoutedServer.authorize()`), None: none (a server without a policy).
    device: Any = field(default=None, hash=False, repr=False, init=False)
    #: The seal of the content of the request and of its answer, set by the policy of the server (`RoutedServer.authorize()`), None: plain.
    sealing: Any = field(default=None, hash=False, repr=False, init=False)

    def __bool__(self) -> bool:
        return bool(self.method and self.url)

    @property
    def headers(self) -> 'HeaderMessage':
        if self.handler is None:
            from email.message import Message
            fflog.warning('No handler in Request(), access to no-request?')
            return Message()
        return self.handler.headers

    @property
    def json(self) -> JsonResult:
        """JSON content data (e.g. POST body)."""
        if self._json is None:
            if self.handler is None:
                fflog.warning('No handler in Request(), access to no-request?')
                return {}
            data = self.handler._read_json(self.content)
            object.__setattr__(self, '_json', data)
            # fflog(f'HTTP JSON: {data}')
        else:
            data = self._json
        return data

    @property
    def content(self) -> bytes:
        """Input content bytes (POST, PUT, PATCH)."""
        if self._content is None:
            object.__setattr__(self, '_content', self.handler._read_content())
            assert self._content is not None
        return self._content

    @property
    def text(self) -> str:
        """Input content text (POST, PUT, PATCH)."""
        if self._text is None:
            object.__setattr__(self, '_text', self.handler._decode_text(self.content))
            assert self._text is not None
        return self._text

    def _assign(self, request: 'Request') -> None:
        """Force assign values."""
        for f in fields(self.__class__):
            object.__setattr__(self, f.name, getattr(request, f.name))

    @classmethod
    def _empty(cls) -> 'Request':
        """No request."""
        route = Route(methods=set(), call=None, pattern=None, signature=None)                              # type: ignore
        return Request(method='', url=URL(''), route=route, match=None, args={}, params={}, handler=None)  # type: ignore


#: Global always non-request.
no_request: Request = Request._empty()


class CurrentRequest(local):
    """The request of the current thread: the server handles every request in its own thread."""

    #: The request of the route method being called, `no_request` outside it.
    request: Request = no_request


#: The request of the current thread.
_current = CurrentRequest()


class RequestProxy:
    """The request of the current thread (`request`), several requests are handled at once."""

    def __getattr__(self, name: str) -> Any:
        """Return the attribute of the request of the current thread."""
        return getattr(_current.request, name)


#: The current request, only for route methods (the request of the current thread).
request: Request = RequestProxy()  # type: ignore[assignment]


class RequestHandler(BaseHTTPRequestHandler):
    """
    A custom HTTP request handler class for handling GET and POST requests.
    """

    DEFAULT_PORT: ClassVar[int] = const.tune.service.http_server.port
    #: The bytes of the content of the request not read yet (`Content-Length`): a route which reads none leaves them in the connection.
    _content_left: int = 0
    _rx_content_type = re.compile(r'(?P<mime>[-/\w]+)(?:;\scharset=(?P<enc>[-\w]+))?')

    def __init__(self, request, client_address, server, auto_head: bool = True):
        self.server: 'RoutedServer'  # type: ignore  # override server type to our server
        self.http_request: Optional[Request] = None
        self.auto_head: bool = auto_head
        #: Number of request in single connction (connection: keep).
        self.request_count: int = 0
        # NOTE: BaseHTTPRequestHandler.__init__ handle and dispatch request. All initialization must be done before.
        super().__init__(request, client_address, server)

    # def setup(self):
    #     BaseHTTPRequestHandler.setup(self)

    @property
    def url(self) -> URL:
        """Request URL."""
        u = self.server.url
        return URL(f'{u.scheme}://{u.netloc}{self.path}')

    def log_message(self, format, *args):
        """Log an arbitrary message. Override BaseHTTPRequestHandler.log_message."""
        try:
            message = format % args
            if const.tune.service.http_server.verbose >= 1:
                fflog.info(f'{self.address_string()} - - [{self.log_date_time_string()}] {message.translate(self._control_char_table)}', stack_depth=2)
            else:
                fflog.debug(f'{self.address_string()} - - [{self.log_date_time_string()}] {message.translate(self._control_char_table)}', stack_depth=2)
        except Exception:
            pass

    def _output_response(self, data: bytes, /):
        # def iter_content(_bytes):
        #     if _bytes is not None:
        #         yield _bytes

        # for chunk in iter_content(bytes):
        #     self.wfile.write(chunk)
        # if not self.wfile.closed:
        #     self.wfile.write(data)
        self.wfile.write(data)  # a gone connection: `response()`

    def _client_gone(self, exc: OSError) -> bool:
        """
        Return True if the connection is gone before the answer (the Kodi exit or the client cut it): one line, the connection closed;
        False for another error.
        """
        if self._cut_on_exit(exc):
            return True
        if not isinstance(exc, ConnectionError):
            return False
        fflog.warning(f'{self.command} {self.path}: the client has gone before the answer ({exc.__class__.__name__})')
        self.close_connection = True
        return True

    def _read_content(self) -> bytes:
        """Read input content bytes (POST, PUT, PATCH): its `Content-Length` read with the request (none, invalid: no content)."""
        length, self._content_left = self._content_left, 0
        content = self.rfile.read(length)
        if len(content) < length:
            raise RequestCut(f'the content cut: {len(content)} of {length} bytes')
        return content

    def _decode_text(self, content: bytes) -> str:
        """Read input content text (POST, PUT, PATCH)."""
        content_type = self.headers.get('Content-Type', '')
        encoding: Optional[str] = None
        if mch := self._rx_content_type.match(content_type):
            encoding = mch['enc'] or None
        return content.decode(encoding or 'utf-8', errors='ignore')

    def _content_mime(self) -> str:
        """Return the MIME type of the content (`Content-Type` without its charset), empty if not given."""
        mch = self._rx_content_type.match(self.headers.get('Content-Type', ''))
        return mch['mime'].lower() if mch else ''

    def _read_json(self, content: bytes) -> JsonResult:
        """
        Return the JSON of the input content (POST, PUT, PATCH; read once by the request, e.g. its signature reads it too). A request
        other than GET / HEAD declares it (`application/json`): a web page can not send it to the local server without the CORS
        preflight (never answered here), a form or a text it can.
        """
        if self.command not in ('GET', 'HEAD') and self._content_mime() != 'application/json':
            raise HTTPUnsupportedMediaType(message=f'expect application/json, got {self.headers.get("Content-Type")!r}')
        return json.loads(self._decode_text(content) or '{}')

    def _cut_on_exit(self, exc: BaseException) -> bool:
        """
        Return True if Kodi exit cut the connection (`abort_network()`; Windows: WinError 10038, Linux reads EOF): it is
        logged and closed, no traceback.
        """
        if not isinstance(exc, OSError) or not sdk_threads.network_aborted:
            return False
        fflog(f'HTTP connection cut on Kodi exit: {exc!r}')
        self.close_connection = True
        return True

    def handle_one_request(self) -> None:
        """Parses and dispatchs the request to the appropriate do_*() method."""
        self.protocol_version = "HTTP/1.1"
        self.server_version = 'FanFilmProxyServer/0.1'
        self.request_count += 1

        # Python http/server.py
        try:
            if self._content_left:  # the content of the previous request its route did not read: not the next request line
                if self._content_left > 65536:  # not worth reading (its size is the word of the client)
                    self.close_connection = True
                    return
                self.rfile.read(self._content_left)
                self._content_left = 0
            self.raw_requestline = self.rfile.readline(65537)
            if len(self.raw_requestline) > 65536:
                self.requestline = ''
                self.request_version = ''
                self.command = ''
                self.send_error(HTTPStatus.REQUEST_URI_TOO_LONG)
                return
            if not self.raw_requestline:
                self.close_connection = True
                return
            if not self.parse_request():
                # An error code has been sent, just exit
                return
            try:
                self._content_left = max(int(self.headers.get('Content-Length') or 0), 0)
            except ValueError:
                self.close_connection = True  # no length: the end of its content unknown
        except (TimeoutError, socket.timeout) as e:
            # a read or a write timed out.  Discard this connection
            # fflog_exc(level=fflog.DEBUG)
            fflog_exc()
            if self.request_count > 1:
                fflog(f'HTTP Request headers timed out: {e!r}, count={self.request_count}')
            else:
                self.log_error(f'Request headers timed out: {e!r}')
            self.close_connection = True
            return
        except ConnectionError as e:
            # peer closed/reset the connection before the request finished - routine (tab closed,
            # navigation, aborted fetch), not worth a full traceback
            fflog(f'HTTP connection closed by peer: {e!r}')
            self.close_connection = True
            return
        except OSError as e:
            if not self._cut_on_exit(e):  # Kodi exit: abort_network() closed an idle keep-alive connection
                raise
            return

        if (host := self.headers.get('Host')) is not None and not self.server.serves_host(host):
            # a page of another name (DNS rebinding) on the address of the server; no Host (HTTP/1.0): not a browser
            err = HTTPStatusException(status_code=HTTPStatus.MISDIRECTED_REQUEST, data={'status': 'error', 'error': 'misdirected request'})
            return self.response(err.status_code, data=err.data)

        # try to find route and prepare request
        url = self.url
        if const.tune.service.http_server.verbose >= 2:
            fflog(f'#### FANFILM HTTP: {self.command} {self.path}, {self.headers}')
        self.http_request = None
        method = self.command
        path = url.path
        allow: Set[str] = set()
        auto_head: bool = self.auto_head and method == 'HEAD'
        request: Request = no_request
        answered: bool = False
        for route in self.server.routes:
            if mch := route.pattern.fullmatch(path):
                allow.update(route.methods)
                if method in route.methods or (auto_head and 'GET' in route.methods):
                    params = dict(parse_qsl(url.query))
                    request = Request(method, url, match=mch, route=route, args=mch.groupdict(),
                                      params=params, handler=self)
                    self.http_request = request
                    break
        else:
            err = HTTPNotFound()
            return self.response(err.status_code, text=err.text, data=err.data, headers=err.headers, request=request)
        # handle request
        try:
            def prepare_arg(name: str, value: Optional[str]) -> Any:
                if route.signature:
                    if (p := route.signature.parameters.get(name)) and p.annotation:
                        try:
                            if value is None and is_optional(p.annotation):
                                return None
                            typ = remove_optional(p.annotation)
                            if typ is str and value is None:
                                return ''  # corner case: need str and got None (from regex)
                            return typ(value)
                        except Exception:
                            pass
                return value

            if request:
                route = request.route
                if const.tune.service.http_server.verbose >= 3 and '/state' in self.path:
                    fflog(f'#### fanfilm HTTP: {self.command} {self.path}: json={json.dumps(request.json, cls=JsonEncoder)}')
                kwargs = {k: prepare_arg(k, v) for k, v in request.args.items()}
                _current.request = request  # `request` of the route method (the request of this thread)
                try:
                    self.server.authorize(request)
                    result = route.call(self.server, **kwargs)
                finally:
                    _current.request = no_request
                status_code = 0
                headers: Optional[Mapping[str, str]] = None
                if result is ANSWERED:  # the route wrote the answer and keeps the connection as it set it
                    answered = True
                    return
                if isinstance(result, tuple) and len(result) > 1:  # and isinstance(result[0], int):
                    status_code, result, *ex = result
                    if TYPE_CHECKING:
                        assert isinstance(status_code, int)
                    if ex:
                        headers = ex[0]
                if isinstance(result, (str, bytes, bytearray, memoryview)):
                    self.response(status_code=status_code, text=result, headers=headers, head=method == 'HEAD', request=request)
                else:
                    self.response(status_code=status_code, data=self.server.answer_data(request, result), headers=headers,
                                  head=method == 'HEAD', request=request)
            elif allow:
                raise HTTPMethodNotAllowed(allow=allow)
            else:
                raise HTTPNotFound()
            if not self.wfile.closed:
                self.wfile.flush()  # actually send the response if not already done.
        except HTTPStatusException as exc:
            if const.tune.service.http_server.verbose >= 2:
                fflog(f'#### fanfilm HTTP: {self.command} {self.path}: response {exc.status_code}: {exc!r}')
            self.response(exc.status_code, text=exc.text, data=self.server.answer_data(request, exc.data), headers=exc.headers, request=request)
        except TimeoutError as e:
            # a read or a write timed out.  Discard this connection
            self.log_error(f'Request timed out: {e!r}')
            self.close_connection = True
        except RequestCut as exc:  # no answer to a cut connection
            if not self._cut_on_exit(exc):
                fflog(f'HTTP request cut by peer: {exc!r}')
                self.close_connection = True
        except Exception as exc:
            if self._cut_on_exit(exc):  # Kodi exit: abort_network() cut the connection while the answer was written
                return
            fflog_exc()
            try:
                self.response(500, text=f'** EXCEPTION **\n\n{format_exc()}', request=request)
            except Exception:
                pass
        finally:
            # request_var._assign(Request._empty())
            if not answered:
                self.wfile.close()

    def response(self, status_code: int = 0, *, text: Union[str, bytes, bytearray, memoryview, None] = None, data: Optional[JsonResult] = None,
                 headers: Optional[Mapping[str, str]] = None, head: bool = False, request: Optional[Request] = None) -> None:
        """Server response."""
        if data is not None:
            content = json.dumps(data, cls=JsonEncoder).encode()
            ctype = 'application/json'
        elif text is not None:
            if isinstance(text, str):
                content = text.encode('utf-8')
            else:
                content = text
            if b'<html' in content[:200]:
                ctype = 'text/html'
            else:
                ctype = 'text/plain'
        else:
            content = None
            ctype = ''

        if headers is None:
            headers = {}
        else:
            headers = dict(headers)
        if content is None:
            self.send_response(status_code or 204)
            headers.setdefault('Content-Length', '0')
            # no 'Content-Type' header for 204
        else:
            self.send_response(status_code or 200)
            if ctype:
                headers.setdefault('Content-Type', ctype)
            headers.setdefault('Content-Length', str(len(content)))
        if headers:
            for header, value in headers.items():
                if value is not None:
                    self.send_header(header, str(value))
        try:  # the headers are written here (also of an error answer), then the content
            self.end_headers()
            if content and not head:
                self._output_response(content)
        except OSError as exc:  # Windows: the handle closed by the Kodi exit (WinError 10038), the client gone (10053)
            if not self._client_gone(exc):
                raise
            return
        if const.tune.service.http_server.verbose >= 3:
            if request:
                fflog(f'#### FANFILM HTTP: {request.method} {request.url}: {status_code}: {(content or "")[:100]!r}')
            else:
                fflog(f'#### FANFILM HTTP: ??? ???: {status_code}: {(content or "")[:100]!r}')


class RoutedServer:
    """
    A mixin of an HTTP server class (before the `socketserver` base): the server serves the route methods (`Route.get()`…) of
    its class and of its bases, the class first (its route of a pattern is found first, its method hides the one of the same
    name of a base, as `RouteObject` of the plugin routes); the routes of two server classes are apart.
    """

    #: The routes of the server class, collected at its definition.
    routes: ClassVar[Tuple[Route, ...]] = ()

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Collect the routes of the class and of its bases (a name is the attribute of the first class of the MRO)."""
        super().__init_subclass__(**kwargs)
        attrs: Dict[str, Any] = {}
        for kls in cls.__mro__:
            for name, value in vars(kls).items():
                attrs.setdefault(name, value)
        cls.routes = tuple(route for value in attrs.values() for route in getattr(value, _ROUTES_ATTR, ()))

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler] = RequestHandler,
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        """Bind the server (`socketserver` base), its URL and the works of the service."""
        super().__init__(server_address, RequestHandlerClass)  # type: ignore[call-arg]  # the socketserver base of the subclass
        host, port = self.server_address  # type: ignore[attr-defined]
        #: The base URL of the server.
        self.url: URL = URL(f'http://{host}:{port}/')
        #: The works of the service (None in tests and CLI).
        self.works: Optional['Works'] = works
        #: The Host headers of the requests the server answers: its own names on a loopback address, None (a local name, `local_host()`)
        #: on another one.
        self.hosts: Optional[FrozenSet[str]] = frozenset({f'{host}:{port}', f'localhost:{port}'}) if ip_address(host).is_loopback else None

    def authorize(self, request: Request) -> None:
        """
        Check the request before its route (the policy of the server: it raises `HTTPStatusException`, it may set `request.device`);
        none here: the server of the service answers its own names on the loopback only (`serves_host()`).
        """

    def answer_data(self, request: Request, data: JsonResult) -> JsonResult:
        """Return the JSON answer of a route as it is sent (the policy of the server, e.g. sealed); here as it is."""
        return data

    def serves_host(self, host: Host) -> bool:
        """Return True if the server answers a request of the `Host` header: one of `hosts`, a local name if any (`local_host()`)."""
        return host.lower() in self.hosts if self.hosts is not None else local_host(host)
