from __future__ import annotations
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .main import Works

#: Service flag
#: - True if service process (sets at beginning of service.py)
#: - False if plugin process
SERVICE: bool = False


def running_works() -> Works | None:
    """
    Return the works of the service in its interpreter (its module loaded), None out of it or after its end (`service.py` deletes
    them, its calls still end) — and while the module is still imported. No import: a CLI with `SERVICE` true must not start the
    servers of the service.
    """
    return getattr(sys.modules.get(f'{__name__}.main'), 'works', None)


def local_works() -> Works | None:
    """Return the works of the service to use in the service itself (no request to itself), None out of it or after its end."""
    return running_works() if SERVICE else None


def service_ended() -> bool:
    """Return True in the service interpreter after the end of the service: its calls still running must not ask it."""
    return SERVICE and f'{__name__}.main' in sys.modules and running_works() is None
