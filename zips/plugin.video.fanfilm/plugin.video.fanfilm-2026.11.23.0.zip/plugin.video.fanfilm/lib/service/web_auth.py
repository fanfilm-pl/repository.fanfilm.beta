"""
The authorization of the FF web server (`web_server.Server`): the devices paired with Kodi (a browser page and the browser script: their
requests signed and their bodies sealed by the key of the device, `web_crypto`) and their scopes, the pairing (a key agreement first, then
a code shown by Kodi, a request approved in Kodi or by a device of the owner, the password of SCRAM-SHA-256), the failures of an address.

Kodi is the root of the trust: who sees its screen pairs a device with any role. A device approves another one only with `devices:write`,
at most with its own scopes. A browser of the device of Kodi has the role of its setting without pairing (`lib.ff.web_settings.local_role()`).
"""

from __future__ import annotations
from typing import Any, Iterable
import base64
import hashlib
import hmac
import secrets
import time
from ipaddress import IPv4Network, ip_address
from threading import Condition
from attrs import asdict, define, evolve, field, frozen
from . import web_crypto
from .http_request import HTTPBadRequest, HTTPStatusException
from ..ff.config import config, escape_key
from ..ff.logs import fflog
from ..ff.web_settings import DEVICES_CONFIG, INSTANCE_CONFIG, PASSWORD_CONFIG
from const import const

#: The scope of every scope.
ALL_SCOPES: str = '*'
#: The scope of the approval of other devices.
DEVICES_WRITE: str = 'devices:write'
#: The characters of a pairing code and of a generated password (base32 without the ones mistaken for others: 0 O 1 I).
CODE_ALPHABET: str = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
#: The length of a pairing code.
CODE_LENGTH: int = 8
#: The user of SCRAM (one password of the server, no users).
SCRAM_USER: str = 'fanfilm'
#: The clients of the devices: a browser page, the browser script.
PAGE_CLIENT: str = 'page'
SCRIPT_CLIENT: str = 'script'
#: The home networks besides the private ones of `ipaddress` (`home_address()`): the shared space of the carrier NAT (RFC 6598, Tailscale).
HOME_NETWORKS: tuple[IPv4Network, ...] = (IPv4Network('100.64.0.0/10'),)
#: The headers of a signed request of a device (a page, the browser script): its device, the time of its signature, the signature.
DEVICE_HEADER: str = 'X-FF-Device'
TIME_HEADER: str = 'X-FF-Time'
SIGNATURE_HEADER: str = 'X-FF-Signature'
#: The header of a request of a pairing: the ID of its key agreement (`/pair/key`), the key of its seals.
PAIR_HEADER: str = 'X-FF-Pair'
#: The only field of a sealed JSON content (of a request of a device with a key, of its answer): the seal (`web_crypto.seal()`).
SEALED: str = 'sealed'
#: The state of a request of a device: waiting, approved (its device paired), rejected, expired.
WAITING: str = 'waiting'
APPROVED: str = 'approved'
REJECTED: str = 'rejected'
EXPIRED: str = 'expired'


def allows(scopes: Iterable[str], scope: str) -> bool:
    """Return True if the scopes give the scope (`*` gives every one)."""
    scopes = tuple(scopes)
    return ALL_SCOPES in scopes or scope in scopes


def grant(wanted: Iterable[str], limit: Iterable[str]) -> tuple[str, ...]:
    """Return the scopes of `wanted` the `limit` gives (`*` of `wanted`: all of the limit)."""
    wanted, limit = tuple(wanted), tuple(limit)
    if ALL_SCOPES in limit:
        return wanted
    if ALL_SCOPES in wanted:
        return limit
    return tuple(scope for scope in wanted if scope in limit)


def role_scopes(role: str) -> tuple[str, ...]:
    """Return the scopes of a role (`const.tune.service.web_server.roles`), none of an unknown one."""
    if (found := const.tune.service.web_server.roles.get(role)) is None:
        return ()
    return tuple(found.scopes)


def role_label(scopes: Iterable[str]) -> str:
    """Return the label of the role of the scopes (any order), else the scopes."""
    wanted = sorted(scopes)
    return next((str(role.label) for role in const.tune.service.web_server.roles.values() if sorted(role.scopes) == wanted), ', '.join(wanted))


def new_code(length: int = CODE_LENGTH) -> str:
    """Return a random code of `CODE_ALPHABET`."""
    return ''.join(secrets.choice(CODE_ALPHABET) for _ in range(length))


def normal_code(code: str) -> str:
    """Return a code as typed (any case, spaces, dashes) in its stored form."""
    return ''.join(ch for ch in code.upper() if ch.isalnum())


def instance_id() -> str:
    """Return the ID of this FF (made once, in the configuration)."""
    if not (found := config.get(INSTANCE_CONFIG)):
        with config.batch() as block:  # one ID also for two first requests at once
            if not (found := block.get(INSTANCE_CONFIG)):
                found = secrets.token_hex(8)
                config.set(INSTANCE_CONFIG, found)
    return found


@frozen(kw_only=True)
class Device:
    """A device paired with Kodi."""

    #: Its ID (random).
    id: str
    #: Its name (from its browser, its system).
    name: str
    #: Its scopes (given at its pairing: a change of a role does not widen them).
    scopes: tuple[str, ...] = field(converter=tuple)
    #: The key of its requests (hex): derived at its pairing on both sides (`web_crypto.device_key()`, never sent; the one of the script
    #: of a page sent once, sealed by the key of the page).
    key: str
    #: The client: a browser page (`PAGE_CLIENT`) or the browser script (`SCRIPT_CLIENT`).
    client: str = PAGE_CLIENT
    #: The time of its pairing, of its last use (written at most every `touch_interval`), its last address.
    created: float = 0
    used: float = 0
    address: str = ''
    #: Who approved it: '' Kodi, else the name of the device.
    approved_by: str = ''
    #: The page which gave its key (a browser script of a page: a new one of the page replaces it), '' none.
    page: str = ''

    def to_json(self) -> dict[str, Any]:
        """Return the stored data (`scopes` a list)."""
        data = asdict(self)
        data['scopes'] = list(self.scopes)
        return data


def devices() -> list[Device]:
    """Return the devices (in the order of their pairing; the ones not used for `device_idle_days` removed)."""
    found: list[Device] = []
    idle: list[str] = []
    limit = time.time() - const.tune.service.web_server.auth.device_idle_days * 86400
    for did, data in (config.get(DEVICES_CONFIG) or {}).items():
        try:
            device = Device(**data)
        except TypeError:
            fflog.warning(f'[WEB] broken device {did}: removed')
            idle.append(did)
            continue
        if max(device.used, device.created) < limit:
            idle.append(did)
        else:
            found.append(device)
    if idle:
        config.remove(*(f'{DEVICES_CONFIG}/{escape_key(did)}' for did in idle))
    return sorted(found, key=lambda device: device.created)


def add_device(*, name: str, scopes: Iterable[str], client: str, address: str, key: str, approved_by: str = '', page: str = '') -> Device:
    """Pair a new device of the key of its requests (hex), return it; a browser script of a page replaces the earlier ones of the page."""
    now = time.time()
    device = Device(id=secrets.token_hex(8), name=name[:80] or client, scopes=tuple(scopes), key=key, client=client,
                    created=now, used=now, address=address, approved_by=approved_by, page=page)
    replaced = [other.id for other in devices() if other.page == page] if page else []
    with config.batch():
        if replaced:
            config.remove(*(f'{DEVICES_CONFIG}/{escape_key(did)}' for did in replaced))
        config.set(f'{DEVICES_CONFIG}/{escape_key(device.id)}', device.to_json())
    fflog(f'[WEB] paired {device.name!r} ({client}, {address}, {", ".join(device.scopes)}), approved by {approved_by or "Kodi"}')
    return device


def device_by_id(did: str) -> Device | None:
    """Return the device of the ID, None if there is none."""
    return next((device for device in devices() if device.id == did), None)


def _change_device(did: str, **fields: Any) -> bool:
    """
    Set the fields of the device, only if it is still there (in the fresh file of the block: a device removed meanwhile does
    not come back, its other fields changed meanwhile stay). Return True if written.
    """
    pointer = f'{DEVICES_CONFIG}/{escape_key(did)}'
    with config.batch() as block:
        if not isinstance(block.get(pointer), dict):
            return False
        for name, value in fields.items():
            config.set(f'{pointer}/{name}', value)
    return block.ok


def touch_device(device: Device, address: str) -> None:
    """Remember the use of the device (written if the last one is older than `touch_interval` or its address changed)."""
    now = time.time()
    if address != device.address or now - device.used >= const.tune.service.web_server.auth.touch_interval:
        _change_device(device.id, used=now, address=address)


def set_device_scopes(did: str, scopes: Iterable[str], *, changed_by: str = '') -> Device | None:
    """Give a device new scopes (a new role, at once), return it (None: no such device)."""
    if (device := device_by_id(did)) is None:
        return None
    changed = evolve(device, scopes=tuple(scopes))
    if not _change_device(did, scopes=list(changed.scopes)):
        return None
    fflog(f'[WEB] scopes of {device.name!r}: {", ".join(device.scopes)} -> {", ".join(changed.scopes)}, changed by {changed_by or "Kodi"}')
    return changed


def remove_device(did: str | None = None) -> bool:
    """Remove the device of the ID (None: every device), return True if written."""
    if did is None:
        return config.remove(DEVICES_CONFIG)
    return config.remove(f'{DEVICES_CONFIG}/{escape_key(did)}')


# --- SCRAM-SHA-256 (RFC 5802, RFC 7677; no channel binding: `c=biws`) ---


def b64(data: bytes) -> str:
    """Return the base64 text of the bytes."""
    return base64.b64encode(data).decode('ascii')


@frozen(kw_only=True)
class ScramKeys:
    """The stored keys of a password (none of them signs in: `ClientKey` is never stored)."""

    #: The salt (base64).
    salt: str
    #: The iterations of the derived key.
    iterations: int
    #: `StoredKey` = H(ClientKey), base64.
    stored_key: str
    #: `ServerKey`, base64.
    server_key: str

    @classmethod
    def of_password(cls, password: str, *, salt: bytes | None = None, iterations: int | None = None) -> ScramKeys:
        """Return the keys of a password (a new random salt, the iterations of `const` unless given)."""
        salt = secrets.token_bytes(16) if salt is None else salt
        iterations = const.tune.service.web_server.auth.scram_iterations if iterations is None else iterations
        salted = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
        client_key = hmac.new(salted, b'Client Key', 'sha256').digest()
        return cls(salt=b64(salt), iterations=iterations, stored_key=b64(hashlib.sha256(client_key).digest()),
                   server_key=b64(hmac.new(salted, b'Server Key', 'sha256').digest()))

    def auth_message(self, client_nonce: str, nonce: str, user: str = SCRAM_USER) -> str:
        """Return the SCRAM `AuthMessage`: client-first-bare, server-first, client-final-without-proof."""
        return f'n={user},r={client_nonce},r={nonce},s={self.salt},i={self.iterations},c=biws,r={nonce}'

    def verify(self, auth_message: str, proof: str) -> str | None:
        """Return the `ServerSignature` (base64) if the `ClientProof` (base64) is of the password, else None."""
        try:
            proof_bytes = base64.b64decode(proof, validate=True)
        except ValueError:
            return None
        stored = base64.b64decode(self.stored_key)
        signature = hmac.new(stored, auth_message.encode('utf-8'), 'sha256').digest()
        if len(proof_bytes) != len(signature):
            return None
        client_key = bytes(a ^ b for a, b in zip(proof_bytes, signature))
        if not hmac.compare_digest(hashlib.sha256(client_key).digest(), stored):
            return None
        return b64(hmac.new(base64.b64decode(self.server_key), auth_message.encode('utf-8'), 'sha256').digest())

    def to_json(self) -> dict[str, Any]:
        """Return the stored data."""
        return asdict(self)


@frozen(kw_only=True)
class ScramStart:
    """A login by the password started (its challenge given): the nonce of the client, the end of its validity."""

    #: The nonce of the client (the start of the full nonce).
    client_nonce: str
    #: The end of its validity (`time.time()`).
    expires: float


def password_keys() -> ScramKeys | None:
    """Return the keys of the password of the web server, None if there is none."""
    data = config.get(PASSWORD_CONFIG)
    try:
        return ScramKeys(**data) if isinstance(data, dict) else None
    except TypeError:
        return None


def set_password_keys(keys: ScramKeys | None) -> bool:
    """Set the keys of the password (None: no password), return True if written."""
    if keys is None:
        return config.remove(PASSWORD_CONFIG)
    return config.set(PASSWORD_CONFIG, keys.to_json())


def new_password() -> str:
    """Return a generated password: 12 characters of `CODE_ALPHABET` in groups of 4 (60 bits)."""
    code = new_code(12).lower()
    return '-'.join(code[i:i + 4] for i in range(0, 12, 4))


# --- Signed requests of the devices ---


def signature_message(method: str, path: str, stamp: str, body: bytes) -> bytes:
    """Return the signed text of a request: its method, its path (with the query), the time of its signature, SHA-256 of its body (hex)."""
    return f'{method.upper()}\n{path}\n{stamp}\n{hashlib.sha256(body).hexdigest()}'.encode('utf-8')


def request_signature(key: str, method: str, path: str, stamp: str, body: bytes) -> str:
    """Return the signature of a request (HMAC-SHA256 by the key of the device, base64)."""
    return b64(hmac.new(bytes.fromhex(key), signature_message(method, path, stamp, body), 'sha256').digest())


# --- Pairing (in the memory of the service) ---


@define(kw_only=True)
class Handshake:
    """A key agreement of a pairing (`/pair/key`): one pairing by it (a code, the password), or the requests of one access request."""

    #: Its ID (random: the `X-FF-Pair` header of the requests of the pairing).
    sid: str
    #: The key of the seals of the pairing (`web_crypto.pairing_key()`).
    key: bytes
    #: The address of the device.
    address: str
    #: The end of its validity (`time.time()`): the one of its access request when it has one.
    expires: float
    #: The ID of its access request ('' none).
    rid: str = ''


@define(kw_only=True)
class PairCode:
    """A code shown by Kodi: a device typing it (or scanning its QR code) is paired with its scopes."""

    #: The code (`normal_code()`).
    code: str
    #: The scopes of the device.
    scopes: tuple[str, ...]
    #: The end of its validity (`time.time()`).
    expires: float
    #: The wrong tries of it.
    tries: int = 0
    #: The device paired by it ('' none yet): Kodi shows it.
    device: str = ''


@define(kw_only=True)
class PairRequest:
    """A request of a device for the access: Kodi or a device of the owner approves it."""

    #: Its ID (random: the QR code of its approval).
    id: str
    #: The secret of the requesting device (its waiting for the answer).
    poll: str
    #: The code shown on the requesting device and to the approver (both see the same one).
    match: str
    #: The name of the device, its client, its address.
    name: str
    client: str
    address: str
    #: The scopes asked (`*`: any the approver gives).
    scopes: tuple[str, ...]
    #: The end of its validity.
    expires: float
    #: `WAITING`, `APPROVED`, `REJECTED`, `EXPIRED`.
    state: str = WAITING
    #: The key of the device to pair (hex, of its key agreement).
    key: str = ''
    #: The approved device.
    device: Device | None = None

    def public(self) -> dict[str, Any]:
        """Return the request for an approver (no secret of it)."""
        return {'id': self.id, 'match': self.match, 'name': self.name, 'client': self.client, 'address': self.address,
                'scopes': list(self.scopes), 'expires': self.expires, 'state': self.state}


def too_many(status: int = 429) -> HTTPStatusException:
    """Return the error of an address refused for its failures."""
    return HTTPStatusException(status_code=status, data={'status': 'error', 'error': 'too many failures, try later'})


class Pairing:
    """The key agreements, the codes and the requests of the pairing, the failures of the addresses (in the memory of the service, short lived)."""

    def __init__(self) -> None:
        #: Guards the state, wakes the devices waiting for an answer.
        self._cond: Condition = Condition()
        #: The key agreements by their IDs.
        self.handshakes: dict[str, Handshake] = {}
        #: The codes by their text.
        self.codes: dict[str, PairCode] = {}
        #: The requests by their IDs.
        self.requests: dict[str, PairRequest] = {}
        #: The times of the failures of an address (a wrong code, a wrong password).
        self.failures: dict[str, list[float]] = {}
        #: The ends of the cooldowns of the addresses of rejected requests (`reject_cooldown`: no new request of them).
        self.rejected: dict[str, float] = {}

    def _expire(self, now: float) -> None:
        """Drop the expired key agreements and codes, mark the expired requests (under the lock); the old failures forgotten."""
        self.handshakes = {sid: entry for sid, entry in self.handshakes.items() if entry.expires > now}
        self.codes = {code: entry for code, entry in self.codes.items() if entry.expires > now}
        for req in list(self.requests.values()):
            if req.expires <= now:
                if req.state == WAITING:
                    req.state = EXPIRED
                if req.expires + const.tune.service.web_server.auth.request_ttl <= now:  # its device has had time to read the end
                    del self.requests[req.id]
        window = const.tune.service.web_server.auth.failure_window
        self.failures = {address: kept for address, times in self.failures.items() if (kept := [t for t in times if now - t < window])}
        self.rejected = {address: end for address, end in self.rejected.items() if end > now}

    def check_address(self, address: str) -> None:
        """Raise 429 if the address failed too often (`failures_max` in `failure_window`)."""
        with self._cond:
            self._expire(time.time())
            if len(self.failures.get(address, ())) >= const.tune.service.web_server.auth.failures_max:
                raise too_many()

    def fail(self, address: str) -> None:
        """Count a failure of the address."""
        with self._cond:
            self.failures.setdefault(address, []).append(time.time())

    def new_handshake(self, public: bytes, address: str) -> tuple[Handshake, bytes]:
        """
        Agree a key with a device by its public X25519 key: return the agreement and the public key of FF. The earlier agreement of the
        address (not of a request) is replaced - two pages of one address pairing at once: the first one is refused (401), it agrees
        again; 503 if too many wait, 400 for a public key of no agreement.
        """
        self.check_address(address)
        secret = web_crypto.new_secret()
        own = web_crypto.public_key(secret)
        sid = secrets.token_urlsafe(12)
        try:
            key = web_crypto.pairing_key(secret, public, public + own + sid.encode())
        except web_crypto.SealError:
            raise HTTPBadRequest(message='public key') from None
        with self._cond:
            now = time.time()
            self._expire(now)
            self.handshakes = {other: entry for other, entry in self.handshakes.items() if entry.address != address or entry.rid}
            if len(self.handshakes) >= const.tune.service.web_server.auth.handshakes_max:
                raise too_many(503)
            entry = self.handshakes[sid] = Handshake(sid=sid, key=key, address=address, expires=now + const.tune.service.web_server.auth.handshake_ttl)
            return entry, own

    def handshake(self, sid: str) -> Handshake | None:
        """Return the key agreement of the ID, None if there is none (expired, used)."""
        with self._cond:
            self._expire(time.time())
            return self.handshakes.get(sid)

    def end_handshake(self, sid: str) -> None:
        """Forget the key agreement of the ID (its one pairing done or failed)."""
        with self._cond:
            self.handshakes.pop(sid, None)

    def new_code(self, scopes: Iterable[str]) -> PairCode:
        """Return a new code of the scopes (the earlier codes stay until they expire)."""
        with self._cond:
            now = time.time()
            self._expire(now)
            while (code := new_code()) in self.codes:
                pass
            entry = self.codes[code] = PairCode(code=code, scopes=tuple(scopes), expires=now + const.tune.service.web_server.auth.code_ttl)
            return entry

    def code(self, code: str) -> PairCode | None:
        """Return the code (Kodi shows whether it paired a device), None if expired."""
        with self._cond:
            self._expire(time.time())
            return self.codes.get(normal_code(code))

    def use_code(self, code: str, *, name: str, client: str, address: str, key: str) -> Device:
        """Pair a device of the key by a code (once): return it; a wrong code is a failure of the address (401), too many: 429."""
        self.check_address(address)
        with self._cond:
            entry = self.codes.get(normal_code(code))
            if entry is None or entry.device:
                for other in self.codes.values():  # a wrong code counts against every code waiting (no guessing at leisure)
                    other.tries += 1
                self.codes = {key: other for key, other in self.codes.items() if other.tries < const.tune.service.web_server.auth.code_attempts}
                found = None
            else:
                found = entry
        if found is None:
            self.fail(address)
            raise HTTPStatusException(status_code=401, data={'status': 'error', 'error': 'wrong code'})
        device = add_device(name=name, scopes=found.scopes, client=client, address=address, key=key)
        with self._cond:
            found.device = device.id
            self._cond.notify_all()
        return device

    def new_request(self, *, name: str, client: str, address: str, scopes: Iterable[str], handshake: Handshake) -> PairRequest:
        """
        Return a new request of a device (an earlier one of the address and the client replaced) by its key agreement (it lives as long as the
        request, the key of the device is of it); 429 if too many wait or the address was rejected lately (`reject_cooldown`), 400 for an
        agreement of another request.
        """
        self.check_address(address)
        with self._cond:
            now = time.time()
            self._expire(now)
            if address in self.rejected:
                raise HTTPStatusException(status_code=429, data={'status': 'error', 'error': 'rejected, try later'})
            replaced = {req.id for req in self.requests.values() if (req.address, req.client) == (address, client) and req.state == WAITING}
            for rid in replaced:
                self.requests[rid].state = EXPIRED
            self.handshakes = {sid: entry for sid, entry in self.handshakes.items() if entry.rid not in replaced}  # no pile of agreements
            if sum(req.state == WAITING for req in self.requests.values()) >= const.tune.service.web_server.auth.requests_max:
                raise too_many(503)
            if handshake.rid or self.handshakes.get(handshake.sid) is not handshake:
                raise HTTPBadRequest(message='key agreement')
            req = PairRequest(id=secrets.token_urlsafe(12), poll=secrets.token_urlsafe(16), match=f'{secrets.randbelow(1000):03d}',
                              name=name[:80] or client, client=client, address=address, scopes=tuple(scopes),
                              expires=now + const.tune.service.web_server.auth.request_ttl,
                              key=web_crypto.device_key(handshake.key).hex())
            self.requests[req.id] = req
            handshake.rid = req.id
            handshake.expires = req.expires + const.tune.service.web_server.auth.request_ttl  # as long as the request is kept
            self._cond.notify_all()
            fflog(f'[WEB] access requested by {req.name!r} ({client}, {address})')
            return req

    def pending(self) -> list[PairRequest]:
        """Return the requests waiting for an approval."""
        with self._cond:
            self._expire(time.time())
            return [req for req in self.requests.values() if req.state == WAITING]

    def request(self, rid: str) -> PairRequest | None:
        """Return the request of the ID, None if there is none."""
        with self._cond:
            self._expire(time.time())
            return self.requests.get(rid)

    def wait(self, rid: str, poll: str, timeout: float) -> PairRequest:
        """
        Wait for the answer of the request (at most `timeout`), return it (an approved one again and again: it holds no secret). 404 if
        there is no such request of the secret.
        """
        deadline = time.time() + timeout
        with self._cond:
            while True:
                now = time.time()
                self._expire(now)
                if (req := self.requests.get(rid)) is None or not hmac.compare_digest(req.poll, poll):
                    raise HTTPStatusException(status_code=404, data={'status': 'error', 'error': 'no such request'})
                if req.state != WAITING or now >= deadline:
                    return evolve(req)
                self._cond.wait(min(deadline - now, req.expires - now))

    def answer(self, rid: str, *, approve: bool, scopes: Iterable[str] = (), approved_by: str = '') -> PairRequest:
        """
        Approve (a new device of the scopes) or reject a waiting request (its address: no new request for `reject_cooldown`), return it;
        404 if it does not wait.
        """
        with self._cond:
            self._expire(time.time())
            if (req := self.requests.get(rid)) is None or req.state != WAITING:
                raise HTTPStatusException(status_code=404, data={'status': 'error', 'error': 'no such request'})
            if not approve:
                req.state = REJECTED
                self.rejected[req.address] = time.time() + const.tune.service.web_server.auth.reject_cooldown
                self._cond.notify_all()
                fflog(f'[WEB] request of {req.name!r} rejected by {approved_by or "Kodi"}')
                return req
        device = add_device(name=req.name, scopes=scopes, client=req.client, address=req.address, key=req.key, approved_by=approved_by)
        with self._cond:
            req.state, req.device = APPROVED, device
            self._cond.notify_all()
        return req

    def wait_change(self, timeout: float) -> None:
        """Wait for a change of the pairing (a new request, a paired code) at most `timeout` (Kodi shows them)."""
        with self._cond:
            self._cond.wait(timeout)


def home_address(address: str) -> bool:
    """
    Return True for an address of the home network (a pairing comes only from one): the loopback, a private one (RFC 1918, IPv6 ULA),
    link-local, the shared space of the carrier NAT (`HOME_NETWORKS`: Tailscale too); a public one or no address: False.
    """
    try:
        ip = ip_address(address)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local or any(ip in network for network in HOME_NETWORKS if ip.version == network.version)


def address_of(handler: Any) -> str:
    """Return the address of the client of a request handler."""
    return str(handler.client_address[0])
