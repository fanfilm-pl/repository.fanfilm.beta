"""
The cryptography of the FF web server over plain HTTP (a page of a network address is no secure context: no WebCrypto there): the key
agreement X25519 (RFC 7748) of a pairing, HKDF-SHA256 (RFC 5869) of its keys, the seal of a JSON body - HMAC-SHA256 in the counter mode
as its stream, a HMAC-SHA256 tag of it (encrypt-then-MAC). Only the standard library; the page (`web/mod/ffauth.js`) and the browser
script (`web/mod/fanfilm.user.js`) do the same (the vectors of `test/data/web_seal.json` for all of them).

Nothing of it protects a page against a changed page itself (an active attacker of the network gives it another script): it keeps the
keys, the passwords and the cookies from a listener of the network. Python ints are not constant-time: only one-time keys of a pairing
meet X25519 here.
"""

from __future__ import annotations
import base64
import hmac
import os
import struct

#: The prime of Curve25519 and (A - 2) / 4 of its Montgomery ladder (RFC 7748 § 5).
P25519: int = 2 ** 255 - 19
A24: int = 121665
#: The base point of X25519 (u = 9).
X25519_BASE: bytes = (9).to_bytes(32, 'little')
#: The size of a key, of the nonce of a seal, of its tag (bytes).
KEY_SIZE: int = 32
NONCE_SIZE: int = 24
TAG_SIZE: int = 32
#: The size of a block of the stream of a seal (HMAC-SHA256).
BLOCK_SIZE: int = 32
#: The directions of a seal: a request, the answer of it (a sealed request never passes for an answer).
REQUEST: bytes = b'req'
ANSWER: bytes = b'res'


class SealError(ValueError):
    """A seal not opened (broken, of another key, binding or direction), a public key of no agreement."""


def x25519(scalar: bytes, point: bytes) -> bytes:
    """Return X25519 of a secret scalar and a public u-coordinate (RFC 7748 § 5: 32 bytes each, little-endian)."""
    k = int.from_bytes(scalar, 'little') & ~7 & ~(1 << 255) | (1 << 254)
    x1 = int.from_bytes(point, 'little') & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in reversed(range(255)):
        bit = (k >> t) & 1
        if swap ^ bit:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = bit
        a, b = (x2 + z2) % P25519, (x2 - z2) % P25519
        aa, bb = a * a % P25519, b * b % P25519
        e = (aa - bb) % P25519
        da, cb = (x3 - z3) * a % P25519, (x3 + z3) * b % P25519
        x3 = (da + cb) ** 2 % P25519
        z3 = x1 * (da - cb) ** 2 % P25519
        x2 = aa * bb % P25519
        z2 = e * (aa + A24 * e) % P25519
    if swap:
        x2, z2 = x3, z3
    return (x2 * pow(z2, P25519 - 2, P25519) % P25519).to_bytes(32, 'little')


def new_secret() -> bytes:
    """Return a new random secret key (of X25519, of a device)."""
    return os.urandom(KEY_SIZE)


def public_key(secret: bytes) -> bytes:
    """Return the public X25519 key of a secret one."""
    return x25519(secret, X25519_BASE)


def hkdf(material: bytes, *, salt: bytes = b'', info: bytes = b'', length: int = KEY_SIZE) -> bytes:
    """Return a key derived by HKDF-SHA256 (RFC 5869): extracted by the salt (none: zeros), expanded by the info."""
    prk = hmac.new(salt or bytes(32), material, 'sha256').digest()
    out, block = b'', b''
    for counter in range(1, -(-length // 32) + 1):
        block = hmac.new(prk, block + info + bytes((counter,)), 'sha256').digest()
        out += block
    return out[:length]


def pairing_key(secret: bytes, public: bytes, transcript: bytes) -> bytes:
    """
    Return the key of the seals of a pairing: HKDF of X25519 of the own secret and the public key of the other side, salted by the
    transcript of the agreement (both public keys, its ID). SealError for a public key of no agreement (a wrong size, zero of X25519:
    RFC 7748 § 6.1).
    """
    if len(public) != KEY_SIZE:
        raise SealError('public key')
    shared = x25519(secret, public)
    if not any(shared):
        raise SealError('public key')
    return hkdf(shared, salt=transcript, info=b'pair')


def device_key(pairing: bytes) -> bytes:
    """Return the key of a device paired by the key of its pairing (both sides derive it, it never goes over the network)."""
    return hkdf(pairing, info=b'device')


def _stream(key: bytes, nonce: bytes, size: int) -> bytes:
    """Return the stream of a seal: HMAC-SHA256 of the nonce and of the number of the block (4 bytes, big-endian)."""
    start = hmac.new(key, nonce, 'sha256')
    blocks: list[bytes] = []
    for number in range(-(-size // BLOCK_SIZE)):
        block = start.copy()
        block.update(struct.pack('>I', number))
        blocks.append(block.digest())
    return b''.join(blocks)[:size]


def _xor(data: bytes, stream: bytes) -> bytes:
    """Return the data XOR the stream (of the same size)."""
    return (int.from_bytes(data, 'little') ^ int.from_bytes(stream, 'little')).to_bytes(len(data), 'little')


def _tag(key: bytes, direction: bytes, binding: bytes, nonce: bytes, sealed: bytes) -> bytes:
    """Return the tag of a seal: HMAC-SHA256 of its direction, of the size of its binding (4 bytes, big-endian), the binding, nonce, ciphertext."""
    return hmac.new(key, direction + struct.pack('>I', len(binding)) + binding + nonce + sealed, 'sha256').digest()


def _seal_keys(key: bytes) -> tuple[bytes, bytes]:
    """Return the key of the stream and the key of the tag of the seals of a key."""
    return hkdf(key, info=b'seal enc'), hkdf(key, info=b'seal mac')


def seal(key: bytes, data: bytes, *, binding: bytes, direction: bytes, nonce: bytes | None = None) -> str:
    """Return the seal of the data (base64 of the nonce, the ciphertext, the tag) by the key, bound to the binding and the direction."""
    enc, mac = _seal_keys(key)
    nonce = os.urandom(NONCE_SIZE) if nonce is None else nonce
    sealed = _xor(data, _stream(enc, nonce, len(data)))
    return base64.b64encode(nonce + sealed + _tag(mac, direction, binding, nonce, sealed)).decode('ascii')


def unseal(key: bytes, text: str, *, binding: bytes, direction: bytes) -> bytes:
    """Return the data of a seal (`seal()`), SealError if it is broken or of another key, binding or direction."""
    try:
        raw = base64.b64decode(text, validate=True)
    except (ValueError, TypeError):
        raise SealError('not base64') from None
    if len(raw) < NONCE_SIZE + TAG_SIZE:
        raise SealError('too short')
    nonce, sealed, tag = raw[:NONCE_SIZE], raw[NONCE_SIZE:-TAG_SIZE], raw[-TAG_SIZE:]
    enc, mac = _seal_keys(key)
    if not hmac.compare_digest(tag, _tag(mac, direction, binding, nonce, sealed)):
        raise SealError('tag')
    return _xor(sealed, _stream(enc, nonce, len(sealed)))
