"""
The dialogs of an action of the configuration on the web page (`web_views`, the routes `/config/...`): the action of the window runs in
its own thread with the interaction of the page (`WebUI`, `lib.ff.ui.thread_ui()`) - a question of it (yes / no, a choice, a text, a date,
a long text shown)
and an authorization (its link and code: `WebAuthSession`) wait for the page, which asks the user and answers (`reply()`); the notes of the
action (`ui.notify()`) and its end (its result) go to the page with its next state. A question not answered in time is canceled
(`const.tune.service.web_server.dialog`), so is every one at the exit of Kodi; a dialog is of the device which started it.
"""

from __future__ import annotations
from datetime import date
from secrets import token_urlsafe
from threading import Condition
from time import monotonic
from typing import Any, Callable, Sequence, TYPE_CHECKING
from ..ff.kotools import kodi_abort_event
from ..ff.logs import fflog_exc
from ..ff.types import JsonData
from ..ff.ui import AuthSession, KodiUI, thread_ui
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from ..ff.item import FFItem

#: The dialogs running by their IDs.
_dialogs: dict[str, Dialog] = {}


def _index_of(answer: Any, count: int) -> bool:
    """Return True if an answer of the page is an index of one of `count` items (a number, not a bool)."""
    return isinstance(answer, int) and not isinstance(answer, bool) and 0 <= answer < count


class Dialog:
    """An action of the page running in its own thread and its state for the page: a question, an authorization, the notes, the end."""

    def __init__(self, device: str, run: Callable[[], Any]) -> None:
        """Start the action `run` (its result: the end of the dialog) of the device."""
        from ..ff.threads import Thread
        #: The ID (the page answers by it).
        self.id: str = token_urlsafe(12)
        #: The device of the page.
        self.device: str = device
        self._cond: Condition = Condition()
        #: The question waiting for the page (None: none), the state it was asked in (an answer of an older state: of another question).
        self.question: JsonData | None = None
        self._asked: int = 0
        self._answer: Any = None
        self._answered: bool = False
        #: The authorization shown (its title, link, code and progress; None: none).
        self.auth: JsonData | None = None
        #: The user canceled (a question, an authorization).
        self.canceled: bool = False
        #: The notes of the action not given to the page yet.
        self.notes: list[JsonData] = []
        #: The action ended (its time: `monotonic()`), its result.
        self.done: bool = False
        self.ended: float = 0
        self.result: Any = None
        #: The number of the changes of the state (the page waits for the next one).
        self.version: int = 0
        _dialogs[self.id] = self
        Thread(target=self._run, args=(run,), name='web-dialog', daemon=True).start()

    def _run(self, run: Callable[[], Any]) -> None:
        """Run the action with the interaction of the page, its result is the end of the dialog."""
        result: Any = None
        try:
            with thread_ui(WebUI(self)):
                result = run()
        except Exception:
            fflog_exc()
            self.note('FanFilm', L(30394, 'Error'), error=True)
        with self._cond:
            self.done, self.ended, self.result = True, monotonic(), result
            self._changed()

    def _changed(self) -> None:
        """The state changed: the page waiting for it gets it (under the lock)."""
        self.version += 1
        self._cond.notify_all()

    def _wait(self, ready: Callable[[], bool], timeout: float) -> bool:
        """Wait (under the lock) until `ready()`, the timeout or the exit of Kodi (checked every second), return `ready()`."""
        end = monotonic() + timeout
        while not ready() and not kodi_abort_event.is_set() and (left := end - monotonic()) > 0:
            self._cond.wait(min(left, 1))
        return ready()

    def note(self, heading: str, message: str, *, error: bool = False) -> None:
        """Give a note of the action to the page."""
        with self._cond:
            self.notes.append({'heading': heading, 'message': message, 'error': error})
            self._changed()

    def ask(self, question: JsonData) -> Any:
        """Ask the page, return its answer (None: canceled, not answered in time)."""
        with self._cond:
            self.question, self._answer, self._answered = question, None, False
            self._changed()
            self._asked = self.version
            self._wait(lambda: self._answered or self.canceled, const.tune.service.web_server.dialog.answer_timeout)
            self.question = None
            return self._answer if self._answered else None

    def show_auth(self, auth: JsonData | None) -> None:
        """Show an authorization on the page (None: it ended)."""
        with self._cond:
            self.auth = auth
            self._changed()

    def reply(self, seen: int, answer: Any = None, *, cancel: bool = False) -> None:
        """
        The answer of the page to the question of the state `seen` (an older one: a late answer of another question, none), `cancel`: the user
        canceled the question, the authorization.
        """
        with self._cond:
            if cancel:
                self.canceled = True
            elif self.question is not None and seen >= self._asked:
                self._answer, self._answered, self.question = answer, True, None
            self._changed()

    def state(self, seen: int) -> JsonData:
        """
        Return the state for the page after a change since the state `seen` (its version; at most `const...dialog.wait`): the question, the
        authorization, the notes since the last state, the end with the result (then the dialog is gone).
        """
        with self._cond:
            self._wait(lambda: self.version != seen and bool(self.done or self.question is not None or self.auth is not None or self.notes),
                       const.tune.service.web_server.dialog.wait)
            notes, self.notes = self.notes, []
            data: JsonData = {'dialog': self.id, 'version': self.version, 'notes': notes}
            if self.done:
                _dialogs.pop(self.id, None)
                return {**data, 'done': True, 'result': self.result}
            if self.question is not None:
                data['question'] = self.question
            if self.auth is not None:
                data['auth'] = self.auth
            return data


class WebAuthSession(AuthSession):
    """An authorization on the web page: its link and code (no QR code: the page links it), its progress, a cancel of the page."""

    def __init__(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None, dialog: Dialog) -> None:
        """Show the authorization on the page (no QR code: `qrcode_scale` not used)."""
        self.dialog: Dialog = dialog
        self.data: JsonData = {'title': title, 'url': url, 'code': code, 'progress': 0}
        dialog.show_auth(self.data)

    def update(self, progress: float) -> None:
        """Show the progress (0..100) when its whole percent changes."""
        if int(progress) != self.data['progress']:
            self.data = {**self.data, 'progress': int(progress)}
            self.dialog.show_auth(self.data)

    def is_canceled(self) -> bool:
        """Return True if the user canceled the authorization on the page (Kodi exits: too)."""
        return self.dialog.canceled or kodi_abort_event.is_set()

    def close(self) -> None:
        """The authorization ended."""
        self.dialog.show_auth(None)


class WebUI(KodiUI):
    """Interaction by the web page (an action of a dialog: `Dialog.ask()`)."""

    def __init__(self, dialog: Dialog) -> None:
        """The interaction of the dialog."""
        self.dialog: Dialog = dialog

    def notify(self, heading: str, message: str, *, error: bool = False) -> None:
        """Give a note to the page."""
        self.dialog.note(heading, message, error=error)

    def confirm(self, message: str, *, heading: str = '') -> bool:
        """Ask the user (yes / no)."""
        return self.dialog.ask({'kind': 'confirm', 'heading': heading, 'text': message}) is True

    def select(self, heading: str, items: Sequence[str]) -> int:
        """Ask the user to select an item, return its index or -1 if canceled."""
        answer = self.dialog.ask({'kind': 'select', 'heading': heading, 'items': list(items)})
        return answer if _index_of(answer, len(items)) else -1

    def multiselect(self, heading: str, items: Sequence[str], preselect: Sequence[int] = ()) -> list[int] | None:
        """Ask the user to select items, return their indexes or None if canceled."""
        answer = self.dialog.ask({'kind': 'multiselect', 'heading': heading, 'items': list(items), 'default': list(preselect)})
        if not isinstance(answer, list):
            return None
        return [n for n in answer if _index_of(n, len(items))]

    def show_text(self, heading: str, text: str) -> None:
        """Show a long text (until the user closes it)."""
        self.dialog.ask({'kind': 'text', 'heading': heading, 'text': text})

    def choose_tree(self, heading: str, roots: Sequence[FFItem], *, multi: bool, preselect: Sequence[FFItem] = ()) -> Any:
        """
        Ask the user for a leaf of a tree on the page (`multi`: the leaves, `preselect` checked first): its rows (every node expanded; the
        label, the second line, the level, a node, a leaf - its index -, the image of a service: `web_config.art_image()`), the counter of the
        window (its placeholders), the answer the indexes of the leaves; return the leaf (the leaves in the order of the tree), None if canceled.
        """
        from .web_config import art_image
        from ..windows.tree import TreeModel, selected_text
        model = TreeModel(roots, selected=preselect)
        model.expanded = {id(item) for item in model.items() if item.children_items is not None}  # every row (the page collapses them)
        model.rows = model.flatten()
        leaves = model.all_leaves()
        index = {id(leaf): n for n, leaf in enumerate(leaves)}
        rows = [{'key': str(n), 'label': row.item.getLabel(), 'info': row.item.getLabel2(), 'level': row.level, 'node': row.node,
                 'leaf': id(row.item) in index, 'index': index.get(id(row.item), -1), 'icon': art_image(row.item.getArt('icon'))}
                for n, row in enumerate(model.rows)]
        answer = self.dialog.ask({'kind': 'tree', 'heading': heading, 'multi': multi, 'rows': rows, 'counter': selected_text('{selected}', '{total}'),
                                  'default': [index[id(leaf)] for leaf in leaves if id(leaf) in model.selected]})
        if not multi:
            return leaves[answer] if _index_of(answer, len(leaves)) else None
        return [leaves[n] for n in sorted({n for n in answer if _index_of(n, len(leaves))})] if isinstance(answer, list) else None

    def input(self, heading: str, default: str = '', *, hidden: bool = False) -> str | None:
        """Ask the user for a text, return None if canceled."""
        answer = self.dialog.ask({'kind': 'input', 'heading': heading, 'default': '' if hidden else default, 'hidden': hidden})
        return answer if isinstance(answer, str) and answer else None

    def input_date(self, heading: str, default: date | None = None) -> date | None:
        """Ask the user for a date (`YYYY-MM-DD`), return None if canceled."""
        answer = self.dialog.ask({'kind': 'date', 'heading': heading, 'default': default.isoformat() if default else ''})
        try:
            return date.fromisoformat(answer) if isinstance(answer, str) else None
        except ValueError:
            return None

    def auth_session(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None) -> AuthSession:
        """Show the authorization on the page (its link and code)."""
        return WebAuthSession(title=title, url=url, code=code, dialog=self.dialog)


def start(device: str, run: Callable[[], Any]) -> JsonData:
    """
    Run the action of the page in its own dialog, return its first state (its end at once, a question, an authorization); the dialogs ended
    long ago and never read by their pages (a page closed) forgotten.
    """
    old = monotonic() - const.tune.service.web_server.dialog.answer_timeout
    for gone in [key for key, dialog in _dialogs.items() if dialog.done and dialog.ended < old]:
        _dialogs.pop(gone, None)
    return Dialog(device, run).state(0)


def reply(device: str, data: JsonData) -> JsonData:
    """
    The answer of the page (`{"dialog", "version": seen, "answer"?, "cancel"?}`; neither: wait for the next state), return the next state;
    KeyError of no such dialog of the device, ValueError of a version of no number.
    """
    if (dialog := _dialogs.get(str(data.get('dialog', '')))) is None or dialog.device != device:
        raise KeyError(data.get('dialog'))
    if not isinstance(seen := data.get('version', 0), int) or isinstance(seen, bool):
        raise ValueError(f'version {seen!r}')
    if data.get('cancel') or 'answer' in data:
        dialog.reply(seen, data.get('answer'), cancel=bool(data.get('cancel')))
    return dialog.state(seen)
