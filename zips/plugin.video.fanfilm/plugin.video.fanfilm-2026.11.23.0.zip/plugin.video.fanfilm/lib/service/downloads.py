"""
The download engine of the service: the queue of `lib.ff.db.downloads` downloaded by threads of the service.

One scheduler thread (woken by `wake()`, and every `TICK` seconds while a download runs or waits in `queued`; idle - nothing queued, nothing
running - it waits for a wake only: every call which queues a row wakes it) starts a worker thread for every queued download it may start:
not paused (the row or the whole queue), the downloads enabled, no video plays (with the setting `pause_on_play`), fewer than
`const.downloads.limit.total` running and fewer than `const.downloads.limit.host` from its host. All threads are in the stop scope
of the service (`base.service_scope`): its stop cuts their connections and the rows stay `queued` (they go on at the next start).
A worker opens its connection itself (a stopped thread cuts the sockets it created).

A local target is written to `<dest>.part` (resumed by `Range` + `If-Range`), renamed at the end; a network one (`smb://`...) through
`xbmcvfs.File` (no append there: always from the start). The engine is the only writer of the DB.

An expired link: the worker resolves the source again at once, without any dialog (`renew_link()`) - once for an expiry (no new one before
some bytes of the new link). A transfer is paid so only with the setting `auto_pay` (`pay='yes'`: by a provider with its own automatic use of
the transfer on), else never (`pay='no'`). What needs a payment, a window (a way of ResolveURL) or a provider add-on waits in `error` for a
click of the user (`lib.ff.downloads.renew()` resolves in the interpreter of the window, with the dialogs).
A finished download adds its media to the library (the setting `add_downloads` of the library; an episode: its show, once a show).
A new link (`relink()`) clears the validator of the old one: the part file goes on only if the new link gives the same size (of an unknown
size it is removed: from zero). A new enqueue of the same source not finished gives it the link of the request (`add()`: `renewed`).
"""

from __future__ import annotations
from typing import Callable, Generator, get_args
from collections import deque
from contextlib import contextmanager
from errno import ENOSPC
from http import HTTPStatus
from http.client import HTTPException
from time import monotonic
from urllib.parse import urlsplit
import os
import re
import socket

from attrs import define, field
import xbmcvfs
from urllib3.exceptions import HTTPError as Urllib3Error, TimeoutError as Urllib3Timeout

from ..defs import MediaRef
from ..ff import requests
from ..ff.config import config
from ..ff.control import infoDialog
from ..ff.db import downloads as db, state
from ..ff.downloads import (DownloadRequest, DownloadInfo, DownloadsSnapshot, DownloadAction, DownloadErrorKind, DownloadsCall, DownloadLink,
                            DownloadAdded, DownloadFailure, PART_SUFFIX, is_vfs, free_space, renew_link, remove_subtitles)
from ..ff.source.utils import provider_name
from ..ff.kotools import video_playing, kodi_abort_event
from ..ff.logs import fflog, fflog_exc
from ..ff.threads import Thread, Event, Lock, ThreadCanceled, check_thread_cancel, current_scope
from ..sdk import threads as sdk_threads
from . import base
from ..kolang import L, kodi_locale
from const import const

#: Seconds between two checks of the scheduler without a wake (a video started, a setting changed) while a download runs or is queued.
TICK: float = 1
#: Seconds of the transfer the speed is the average of.
SPEED_WINDOW: float = 5
#: Seconds of the transfer before its speed is told (the first reads come from the buffers at once: no real speed).
SPEED_MIN_TIME: float = 1
#: Bytes read and written at once (the most: a read gives what came before the connection broke).
CHUNK_SIZE: int = 256 * 1024
#: Seconds a snapshot waits for the scheduler to read the rows after a write (longer: read in the thread of the snapshot).
FRESH_TIMEOUT: float = .5
#: Seconds a stopped worker may take to end (its file closed) before its part file is removed.
JOIN_TIMEOUT: float = 5
#: The state module of the pause of the whole queue (`state`, DB mode: it survives a restart).
STATE_MODULE: str = 'downloads'
#: The state key of the pause of the whole queue.
PAUSED_KEY: str = 'paused'
#: HTTP statuses of an expired link (the hostings answer so a link out of date).
EXPIRED_STATUSES: frozenset[int] = frozenset((HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN, HTTPStatus.NOT_FOUND, HTTPStatus.GONE))
#: The total size of `Content-Range` (`bytes 100-199/1000`, `bytes */1000`).
RX_CONTENT_RANGE: re.Pattern[str] = re.compile(r'bytes\s+(?:(?P<start>\d+)-\d+|\*)/(?P<total>\d+|\*)')


class Retry(Exception):
    """The transfer broke (a network error, an error of the server): it is tried again. Its text is for the user (the last try failed)."""


class Restart(Exception):
    """The part file does not fit the answer (another file, a range not given): the download starts again from zero, at once."""


#: The errors of the network of a transfer (a write error is a `DownloadFailure`).
NETWORK_ERRORS: tuple[type[BaseException], ...] = (requests.RequestException, HTTPException, Urllib3Error, OSError, Retry)


@define(kw_only=True)
class Worker:
    """A running download: its thread and its live values."""

    #: The ID of the download.
    id: int
    #: The host of its link (the limit per host).
    host: str
    #: The thread (None: not started yet).
    thread: Thread | None = None
    #: The bytes got (the part file included).
    done: int = 0
    #: The size (0: unknown), as the server told it.
    size: int = 0
    #: The samples of the speed: (`monotonic()`, bytes got).
    samples: deque[tuple[float, int]] = field(factory=deque)
    #: The bytes received by all its transfers (a renewal of the link waits for some of the last one).
    received: int = 0

    def got(self, done: int) -> None:
        """Note the bytes got now."""
        now = monotonic()
        self.done = done
        self.samples.append((now, done))
        while len(self.samples) > 2 and now - self.samples[0][0] > SPEED_WINDOW:
            self.samples.popleft()

    @property
    def speed(self) -> float:
        """Return the bytes per second of the last seconds (0: not measured yet, less than `SPEED_MIN_TIME` of the transfer)."""
        if len(self.samples) < 2:
            return 0
        first, last = self.samples[0], self.samples[-1]
        return (last[1] - first[1]) / (last[0] - first[0]) if last[0] - first[0] >= SPEED_MIN_TIME else 0

    @property
    def alive(self) -> bool:
        """Return True if the thread runs."""
        return self.thread is not None and self.thread.is_alive()


def target_path(dest: str) -> str:
    """Return the target path of the download (`special://` translated)."""
    return xbmcvfs.translatePath(dest)


def file_size(path: str) -> int:
    """Return the size of the file, 0 if there is none."""
    try:
        if is_vfs(path):
            return xbmcvfs.Stat(path).st_size() if xbmcvfs.exists(path) else 0
        return os.path.getsize(path)
    except OSError:
        return 0


def file_exists(path: str) -> bool:
    """Return True if the file exists."""
    return xbmcvfs.exists(path) if is_vfs(path) else os.path.exists(path)


def folder_of(path: str) -> str:
    """Return the folder of the file (a network one ends with `/`: `xbmcvfs.exists()` of a folder needs it)."""
    return f'{path.rpartition("/")[0]}/' if is_vfs(path) else os.path.dirname(path)


def kodi_quits() -> bool:
    """Return True if Kodi quits: its abort is set, the network of the interpreter is cut (`abort_network()`), maybe before the service stop."""
    return kodi_abort_event.is_set() or sdk_threads.network_aborted


def remove_file(path: str) -> None:
    """Remove the file if it exists."""
    try:
        if is_vfs(path):
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        else:
            os.remove(path)
    except OSError:
        pass  # no such file


def write_failure(exc: OSError) -> DownloadFailure:
    """Return the error of a write of the file: `space` for no space left on the device, else `write`."""
    if exc.errno == ENOSPC:
        return DownloadFailure('space', L(30107, 'Not enough free space'))
    return DownloadFailure('write', L(30108, 'The file can not be written: {error}', error=exc.strerror or exc))


def network_text(exc: BaseException) -> str:
    """Return the network error for the user (the details in the log): no answer in time, the server not reached, the connection broke."""
    if isinstance(exc, Retry):
        return str(exc)
    if isinstance(exc, (requests.Timeout, Urllib3Timeout, socket.timeout)):
        return L(31272, 'The server does not answer')
    if isinstance(exc, requests.ConnectionError):
        return L(31273, 'The server can not be reached')
    return L(31274, 'The connection broke')


def notify(title: str, message: str) -> None:
    """Show the toast of a download; not over the downloads window (its row tells the same)."""
    from ..windows.downloads import DownloadsDialog
    if not DownloadsDialog.is_shown():
        infoDialog(message, heading=title)


class Downloads:
    """The download engine: the scheduler and the workers of the queue."""

    def __init__(self) -> None:
        """Create the engine (not started, see `start()`); the pause of the whole queue is read from the state."""
        #: Guards the workers and the changes of the rows.
        self._lock: Lock = Lock()
        #: Wakes the scheduler.
        self._wake: Event = Event()
        #: The running downloads by their IDs.
        self._workers: dict[int, Worker] = {}
        #: The scheduler thread (None: not started).
        self._scheduler: Thread | None = None
        #: The engine stopped (`stop()`).
        self._stopped: bool = False
        #: The pause of the whole queue.
        self._paused_all: bool = bool(state.get(PAUSED_KEY, module=STATE_MODULE))
        #: The rows of the queue and the count of the DB writes they were read at (`db.writes`), read by the scheduler after a write: every
        #: call of the window comes in a thread of its own, a read of the DB there would connect anew (`snapshot()`).
        self._rows: tuple[int, list[db.DownloadRow]] = (-1, [])
        #: The scheduler read the rows after the last write (`_rows`).
        self._fresh: Event = Event()
        #: The media added to the library by the finished downloads (an episode: its show), once.
        self._library_refs: set[MediaRef] = set()
        #: The setting `auto_pay` seen last (turned on: `settings_changed()`).
        self._paying: bool = bool(config.downloads.auto_pay)

    # --- the engine ---------------------------------------------------------------------------------

    def start(self) -> None:
        """Start the scheduler (it forgets the finished downloads whose file is gone first: the setting `forget_removed`)."""
        self._scheduler = Thread(target=self._schedule, name='Downloads', scope=base.service_scope)
        base.service_threads.add(self._scheduler)
        self._scheduler.start()
        config.changed.append(self.settings_changed)

    def settings_changed(self) -> None:
        """The configuration changed: buying in the background turned on queues again the downloads waiting for a payment."""
        paying, before = bool(config.downloads.auto_pay), self._paying
        self._paying = paying
        if paying and not before:
            for row in db.rows():
                if row.state == 'error' and row.error_kind == 'payment':
                    db.set_fields(row.id, state='queued', error_kind='', error_text='')
            self.wake()

    def stop(self) -> None:
        """Stop the engine: the scheduler and the workers (the rows keep their states)."""
        self._stopped = True
        if self.settings_changed in config.changed:
            config.changed.remove(self.settings_changed)
        with self._lock:
            workers = list(self._workers.values())
        for worker in workers:
            if worker.thread is not None:
                worker.thread.stop()
        if self._scheduler is not None:
            self._scheduler.stop()
        self._wake.set()

    def join(self, timeout: float | None = None) -> None:
        """Wait for the end of the scheduler and the workers (after `stop()`)."""
        if self._scheduler is not None:
            self._scheduler.join(timeout)
        with self._lock:
            workers = list(self._workers.values())
        for worker in workers:
            if worker.thread is not None:
                worker.thread.join(timeout)

    def wake(self) -> None:
        """Make the scheduler check the queue now."""
        self._wake.set()

    def _schedule(self) -> None:
        """
        Run the scheduler: forget the removed files first (in this thread: a network folder may answer slowly), then start the downloads
        which may start, stop the running ones on a pause of the whole queue. It ends with the service or when Kodi quits.
        """
        try:
            self.forget_missing()
        except Exception:
            fflog_exc()
        while not self._stopped and not base.service_scope.is_set() and not kodi_quits():
            busy = True  # an error: checked again in a tick
            try:
                self._read_rows()
                self._fresh.set()
                busy = self._step()
            except ThreadCanceled:
                raise
            except Exception:
                fflog_exc()
            self._wake.wait(TICK if busy else None)  # idle: no tick, a wake only (or Kodi quits)
            self._wake.clear()

    def _held(self) -> bool:
        """Return True if nothing may download now: Kodi quits, the whole queue paused, the downloads off, a video plays (`pause_on_play`)."""
        if kodi_quits():
            return True
        return self._paused_all or not config.downloads.enabled or self._held_by_play()

    def _held_by_play(self) -> bool:
        """Return True if the queue waits for the end of the video (the setting `pause_on_play`)."""
        return bool(config.downloads.pause_on_play and video_playing())

    def _step(self) -> bool:
        """
        Check the queue once: start what may start (in the order of the queue, the limits), stop all on a hold. Return True if it is to be
        checked again in a tick (a download runs or is queued: a hold may end, a worker end), False if idle (a wake only).
        """
        held = self._held()
        with self._lock:
            for download_id in [i for i, worker in self._workers.items() if worker.thread is not None and not worker.alive]:
                del self._workers[download_id]
            if self._stopped:
                return False
            if held:
                for worker in self._workers.values():
                    if worker.thread is not None:
                        worker.thread.stop()  # the row stays `queued`: it goes on after the hold
                # the release of the whole queue wakes the scheduler; the end of a video, the switch of the setting: a tick while some waits
                return bool(self._workers) or (not self._paused_all and db.has_queued())
            queued = [row for row in db.rows() if row.state == 'queued']
            for row in queued:
                if len(self._workers) >= const.downloads.limit.total:
                    break
                if row.id is None or row.id in self._workers:
                    continue
                host = urlsplit(row.url).hostname or ''
                if sum(1 for worker in self._workers.values() if worker.host == host) >= const.downloads.limit.host:
                    continue
                worker = Worker(id=row.id, host=host)
                worker.thread = Thread(target=self._download, args=(worker,), name=f'Download {row.id}', scope=base.service_scope)
                self._workers[row.id] = worker
                base.service_threads.add(worker.thread)
                worker.thread.start()
            return bool(queued or self._workers)

    def _stop_worker(self, download_id: int, *, join: bool = False) -> None:
        """Stop the worker of the download (if it runs); with `join` wait for its end (its file closed)."""
        with self._lock:
            worker = self._workers.get(download_id)
        if worker is not None and worker.thread is not None:
            worker.thread.stop()
            if join:
                worker.thread.join(JOIN_TIMEOUT)

    # --- the worker ---------------------------------------------------------------------------------

    def _download(self, worker: Worker) -> None:
        """
        Download the file of the row (the worker thread): the transfer tried again after a network error, an expired link renewed (once for
        an expiry, as a try), the end in the row.
        """
        tries = 0
        # the bytes received at the last renewal of the link (None: none): no next one before more of them (no loop of payments)
        renewed_at: int | None = None
        while True:
            if (row := db.get(worker.id)) is None or row.state != 'queued':
                return
            try:
                got = worker.done
                if not self._transfer(row, worker):
                    return  # stopped: the row stays as it is
                break
            except Restart:
                continue
            except DownloadFailure as exc:
                if self._canceled():
                    return
                if exc.kind == 'expired' and (renewed_at is None or worker.received > renewed_at) and tries < const.downloads.retry.count:
                    tries += 1
                    renewed_at = worker.received
                    if self._renew(row):
                        continue
                    return
                self._fail(row, exc.kind, exc.text)
                return
            except NETWORK_ERRORS as exc:
                if self._canceled():
                    return  # our own cut: the row stays as it is
                tries = 0 if worker.done > got else tries + 1
                if tries > const.downloads.retry.count:
                    fflog(f'[DOWNLOADS] {row.id} {row.title}: transfer broke, no more retries: {exc!r}')
                    self._fail(row, 'network', network_text(exc))
                    return
                fflog(f'[DOWNLOADS] {row.id} {row.title}: transfer broke (retry {tries}/{const.downloads.retry.count}): {exc!r}')
                if (scope := current_scope()) is not None:
                    scope.wait(const.downloads.retry.delay)  # set: stopped (checked at the next try)
        db.set_fields(row.id, state='done', error_kind='', error_text='')  # the file is complete: also if stopped meanwhile
        self._add_to_library(row.ref)
        if not self._canceled():
            notify(row.title, L(30425, 'Download finished'))

    def _add_to_library(self, ref: MediaRef | None) -> None:
        """
        Add the media of a finished download to the library (the setting `add_downloads`): an episode its show, once (not again for the next
        episode); the queue of the library of the service (nothing with the library off: not remembered, a later one adds it).
        """
        if ref is None or not config.library.add_downloads:
            return
        ref = ref.show_ref or ref
        from .main import add_to_library
        with self._lock:
            if ref not in self._library_refs and add_to_library('downloads', [ref], quiet=True):
                self._library_refs.add(ref)

    def _canceled(self) -> bool:
        """Return True if the current worker thread is stopped (by the engine, the stop of the service, Kodi quits)."""
        if kodi_quits():
            return True
        try:
            check_thread_cancel()
        except ThreadCanceled:
            return True
        return False

    def _fail(self, row: db.DownloadRow, kind: DownloadErrorKind, text: str) -> None:
        """Stop the download with an error (its part file stays), tell the user."""
        fflog(f'[DOWNLOADS] {row.id} {row.title}: {kind}: {text}')
        db.set_fields(row.id, state='error', error_kind=kind, error_text=text)
        notify(row.title, text)

    def _transfer(self, row: db.DownloadRow, worker: Worker) -> bool:
        """
        Transfer the file once (from the part file got so far). Return True if the file is complete, False if the thread is stopped.
        Raise `DownloadFailure`, `Restart`, a network error.
        """
        path = target_path(row.dest)
        vfs = is_vfs(path)
        part = f'{path}{PART_SUFFIX}'
        offset = 0 if vfs else file_size(part)
        headers = {**row.headers, 'Accept-Encoding': 'identity'}  # the bytes of the file as they are: their count, `Range`
        if offset:
            headers['Range'] = f'bytes={offset}-'
            if row.validator:
                headers['If-Range'] = row.validator
        self._make_folder(path)
        worker.got(offset)
        with requests.Session() as session:
            with session.get(row.url, headers=headers, stream=True, timeout=const.downloads.timeout, verify=False) as resp:
                status = resp.status_code
                total = 0
                if mch := RX_CONTENT_RANGE.search(resp.headers.get('Content-Range', '')):
                    total = int(mch['total']) if mch['total'] != '*' else 0
                if status == HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE:
                    if offset and offset == (total or row.size):
                        self._finish(part, path, vfs)
                        return True
                    remove_file(part)
                    raise Retry(L(31275, 'The server failed (HTTP {status})', status=status))
                if status in EXPIRED_STATUSES:
                    raise DownloadFailure('expired', L(30122, 'The link expired (HTTP {status})', status=status))
                if status >= HTTPStatus.INTERNAL_SERVER_ERROR:
                    raise Retry(L(31275, 'The server failed (HTTP {status})', status=status))
                if status not in (HTTPStatus.OK, HTTPStatus.PARTIAL_CONTENT):
                    raise DownloadFailure('http', L(30203, 'The server refused the file (HTTP {status})', status=status))
                if resp.headers.get('Content-Type', '').lower().startswith('text/html'):
                    raise DownloadFailure('expired', L(30204, 'The link expired (a page instead of the file)'))
                length = int(resp.headers.get('Content-Length') or 0)
                if status == HTTPStatus.PARTIAL_CONTENT:
                    start = int(mch['start']) if mch and mch['start'] else -1
                    if start != offset or (offset and row.size and total and total != row.size):
                        if not offset:
                            fflog(f'[DOWNLOADS] {row.id} {row.title}: HTTP 206 from {start} without a range asked')
                            raise Retry(L(31275, 'The server failed (HTTP {status})', status=status))
                        remove_file(part)  # another file or another range: from zero at once
                        raise Restart()
                    total = total or (offset + length if length else 0)
                else:
                    offset, total = 0, length
                validator = resp.headers.get('ETag') or resp.headers.get('Last-Modified') or ''
                if total != row.size or validator != row.validator:
                    db.set_fields(row.id, size=total, validator=validator)
                worker.size = total
                worker.got(offset)
                if not vfs and total and (free := free_space(path)) is not None and free < total - offset:
                    raise DownloadFailure('space', L(30107, 'Not enough free space'))
                done = self._write(resp, part, vfs, offset, worker)
        if self._canceled():
            return False
        if total and done != total:
            fflog(f'[DOWNLOADS] {row.id} {row.title}: the transfer ended at {done} of {total}')
            raise Retry(L(31274, 'The connection broke'))
        self._finish(part, path, vfs)
        return True

    def _write(self, resp: requests.Response, part: str, vfs: bool, offset: int, worker: Worker) -> int:
        """
        Write the body of the answer to the part file (appended after `offset`). Return the bytes of the part file. The bytes as they came
        (`Accept-Encoding: identity`) by plain reads: a read gives what came before the connection broke, the next one raises (a decoding
        read - `iter_content()` - drops the bytes of its unfinished chunk: a cut transfer would never go on).
        """
        done = offset
        with self._open(part, vfs, append=bool(offset)) as write:
            while chunk := resp.raw.read(CHUNK_SIZE, decode_content=False):
                if self._canceled():
                    break
                write(chunk)
                done += len(chunk)
                worker.received += len(chunk)
                worker.got(done)
        return done

    @contextmanager
    def _open(self, part: str, vfs: bool, *, append: bool) -> Generator[Callable[[bytes], None], None, None]:
        """Open the part file, yield its write (a write error is a `DownloadFailure`, see `write_failure()`)."""
        if vfs:
            file = xbmcvfs.File(part, 'w')  # no append mode in Kodi VFS: always from the start

            def write_vfs(data: bytes) -> None:
                """Write the data to the file of the network."""
                if not file.write(data):
                    raise write_failure(OSError(f'write to {part} failed'))

            try:
                yield write_vfs
            finally:
                file.close()
            return
        try:
            local = open(part, 'ab' if append else 'wb')
        except OSError as exc:
            raise write_failure(exc) from exc

        def write_local(data: bytes) -> None:
            """Write the data to the local file."""
            try:
                local.write(data)
            except OSError as exc:
                raise write_failure(exc) from exc

        try:
            yield write_local
        finally:
            try:
                local.close()
            except OSError:
                pass  # the error of its last write is told already

    def _make_folder(self, path: str) -> None:
        """Create the folder of the target file. Raise `DownloadFailure` (`write`) if it can not be created."""
        try:
            if is_vfs(path):
                if not xbmcvfs.exists(folder := folder_of(path)):
                    xbmcvfs.mkdirs(folder)
            else:
                os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        except OSError as exc:
            raise write_failure(exc) from exc

    def _finish(self, part: str, path: str, vfs: bool) -> None:
        """Rename the complete part file to the target file. Raise `DownloadFailure` (`write`) if it can not be renamed."""
        try:
            if vfs:
                if xbmcvfs.exists(path):
                    xbmcvfs.delete(path)
                if not xbmcvfs.rename(part, path):
                    raise OSError(f'rename of {part} failed')
            else:
                os.replace(part, path)
        except OSError as exc:
            raise write_failure(exc) from exc

    # --- the API ------------------------------------------------------------------------------------

    def add(self, request: DownloadRequest) -> DownloadAdded:
        """
        Add the download at the end of the queue (`queued`). The same source in the queue already: not finished - it gets the link of the
        request (`relink()`, its source has just been resolved: `renewed`), finished - `duplicate`; its target file taken: `duplicate`.
        The answer has the ID of its row (the one in the queue for a duplicate).
        """
        source_url = request.source.get('url') if isinstance(request.source, dict) else None
        with self._lock:
            rows = db.rows()
            same = next((row for row in rows if source_url and row.source.get('url') == source_url), None)
            if same is None:
                if (taken := next((row for row in rows if row.dest == request.dest), None)) is not None:
                    return DownloadAdded(result='duplicate', id=taken.id)
                row = db.DownloadRow(xref=request.ref, title=request.title, info=request.info, dest=request.dest, url=request.url,
                                     headers_json=db.to_json(request.headers), size=request.size, expires=request.expires,
                                     source_json=db.to_json(request.source))
                if db.add(row) is None:
                    return DownloadAdded(result='duplicate')  # the target file is in the queue (written by another call meanwhile) or the DB failed
        if same is not None:
            link = DownloadLink(url=request.url, headers=request.headers, expires=request.expires)
            if same.id is None or same.state == 'done' or not self.relink(same.id, link):
                return DownloadAdded(result='duplicate', id=same.id)
            return DownloadAdded(result='renewed', id=same.id)
        self.wake()
        return DownloadAdded(result='added', id=row.id)

    def _read_rows(self) -> list[db.DownloadRow]:
        """Return the rows of the queue (`_rows`): read again only after a write of the DB (`db.writes`)."""
        writes, rows = self._rows
        if writes != db.writes:
            writes = db.writes  # before the read: a write meanwhile reads them again next time
            self._rows = writes, (rows := db.rows())
        return rows

    def snapshot(self) -> DownloadsSnapshot:
        """
        Return the queue with the live values (read only: nothing is removed here). The rows of the memory of the engine: after a write the
        scheduler reads them (its connection; woken, waited for `FRESH_TIMEOUT`), this thread only without it (stopped, slow).
        """
        with self._lock:
            workers = {i: worker for i, worker in self._workers.items() if worker.alive}
        if self._rows[0] != db.writes and self._scheduler is not None and self._scheduler.is_alive():
            self._fresh.clear()
            self.wake()
            self._fresh.wait(FRESH_TIMEOUT)
        rows = self._read_rows()
        translations = const.sources.translations.providers.get(kodi_locale(), {})
        infos: list[DownloadInfo] = []
        for row in rows:
            if row.id is None:
                continue
            path = target_path(row.dest)
            size = row.size
            if (worker := workers.get(row.id)) is not None:
                done, speed, size = worker.done, worker.speed, worker.size or size
            elif row.state == 'done':
                done, speed = size or (0 if is_vfs(path) else file_size(path)), 0.0
            elif is_vfs(path):
                done, speed = 0, 0.0  # no stat of the network at every refresh: its part file is not resumed (always from the start)
            else:
                done, speed = file_size(f'{path}{PART_SUFFIX}'), 0.0
            eta = (size - done) / speed if speed and size > done else None
            source = row.source
            provider = provider_name(source.get('provider') or '', addon=source.get('addon') or '', translations=translations)
            infos.append(DownloadInfo(id=row.id, ref=row.ref, title=row.title, info=row.info, dest=row.dest, state=row.state,  # type: ignore[arg-type]
                                      error_kind=row.error_kind, error_text=row.error_text, size=size, done=done,  # type: ignore[arg-type]
                                      running=worker is not None, speed=speed, eta=eta, expires=row.expires, position=row.position,
                                      host=urlsplit(row.url).hostname or '', provider=provider, hosting=(source.get('hosting') or '').rstrip(' *'),  # no marks of a provider (tb7: of the match)
                                      renews=not source.get('addon')))
        return DownloadsSnapshot(rows=tuple(infos), paused_all=self._paused_all, held_by_play=not self._paused_all and self._held_by_play(),
                                 free_space=self.free_space())

    def free_space(self) -> int | None:
        """Return the free space of the local folders of the downloads: the least one, None if unknown (none, network folders)."""
        free = [space for folder in (config.downloads.movies_folder, config.downloads.shows_folder)
                if folder and os.path.isdir(path := target_path(folder)) and (space := free_space(path)) is not None]
        return min(free) if free else None

    def act(self, download_id: int, action: DownloadAction) -> bool:
        """Do the action with the download. Return False if there is no such download or the action does not fit its state."""
        if (row := db.get(download_id)) is None:
            return False
        if action == 'pause':
            if row.state != 'queued':
                return False
            db.set_fields(download_id, state='paused')
            self._stop_worker(download_id)
        elif action in ('resume', 'retry'):
            if row.state not in ('paused', 'error'):
                return False
            db.set_fields(download_id, state='queued', error_kind='', error_text='')
        elif action in ('remove', 'remove_file'):
            with self._lock:
                db.remove([download_id])  # first: the scheduler starts it no more
            self._stop_worker(download_id, join=True)
            path = target_path(row.dest)
            remove_file(f'{path}{PART_SUFFIX}')
            if action == 'remove_file':
                remove_file(path)
            if action == 'remove_file' or row.state != 'done':
                remove_subtitles(path)  # copied at the enqueue: no video of them now
        elif action == 'first':
            db.move_first(download_id)
        else:
            return False
        self.wake()
        return True

    def relink(self, download_id: int, link: DownloadLink) -> bool:
        """
        Give the download its new link (its source resolved again) and queue it (a paused one stays paused); a running one stops first (it
        goes on with the new link, see `_relink()`). Return False if there is no such download or it is finished.
        """
        if (row := db.get(download_id)) is None or row.state == 'done':
            return False
        self._stop_worker(download_id, join=True)  # its file closed: the part file may go
        return self._relink(download_id, link)

    def _relink(self, download_id: int, link: DownloadLink) -> bool:
        """
        Give the download its new link (no worker writes its file: `relink()`, or its own worker between two transfers), queue it (a
        paused one stays paused): the validator of the old link cleared, the part file goes on only if the new link gives the same size;
        of an unknown size nothing tells it is the same file - the part file removed, from zero. Return False if there is no such download
        or it is finished.
        """
        if (row := db.get(download_id)) is None or row.state == 'done':
            return False
        if not row.size:
            remove_file(f'{target_path(row.dest)}{PART_SUFFIX}')
        db.set_fields(download_id, url=link.url, headers_json=db.to_json(link.headers), validator='', state='paused' if row.state == 'paused' else 'queued',
                      error_kind='', error_text='', **({'expires': link.expires} if link.expires else {}))
        self.wake()
        return True

    def _renew(self, row: db.DownloadRow) -> bool:
        """
        Renew the expired link of the download in its worker: its source resolved again without any dialog, a transfer paid only with the
        setting `auto_pay`. Return True if it has the new link, else the row is in error (`payment` or `expired`).
        """
        fflog(f'[DOWNLOADS] {row.id} {row.title}: the link expired, renewing it')
        try:
            link = renew_link(row.source, row.ref, pay='yes' if config.downloads.auto_pay else 'no')
        except DownloadFailure as exc:
            if not self._canceled():
                self._fail(row, exc.kind, exc.text)
            return False
        return self._relink(row.id, link) and not self._canceled()  # stopped meanwhile: the paid link kept for the next start

    def pause_all(self, paused: bool) -> bool:
        """Pause or release the whole queue (kept in the state, the states of the rows stay)."""
        self._paused_all = paused
        state.set(PAUSED_KEY, paused, module=STATE_MODULE)
        self.wake()
        return True

    def remove_done(self) -> bool:
        """Remove the finished downloads from the queue (their files stay)."""
        return db.remove([row.id for row in db.rows() if row.state == 'done' and row.id is not None])

    def clear_all(self) -> bool:
        """Stop and remove every download with its part file (the finished files stay)."""
        with self._lock:
            rows = db.rows()
            removed = db.remove([row.id for row in rows if row.id is not None])  # first: the scheduler starts them no more
            workers = list(self._workers.values())
        for worker in workers:
            if worker.thread is not None:
                worker.thread.stop()
        for worker in workers:
            if worker.thread is not None:
                worker.thread.join(JOIN_TIMEOUT)
        for row in rows:
            if row.state != 'done':
                remove_file(f'{target_path(row.dest)}{PART_SUFFIX}')
                remove_subtitles(target_path(row.dest))
        return removed

    def forget_missing(self) -> bool:
        """
        Remove the finished downloads whose file is gone, only with the setting `forget_removed` on. The folder of the downloads above
        the file has to exist (else the folder of the file): an unavailable one (a sleeping NAS, an unplugged disk) removes nothing.
        """
        if not config.downloads.forget_removed:
            return True
        roots = [target_path(folder) for folder in (config.downloads.movies_folder, config.downloads.shows_folder) if folder]

        def available(path: str) -> bool:
            """Return True if the place of the file is there."""
            return file_exists(next((root for root in roots if path.startswith(root)), folder_of(path)))

        return db.remove([row.id for row in db.rows() if row.state == 'done' and row.id is not None
                          and not file_exists(path := target_path(row.dest)) and available(path)])

    def call(self, name: DownloadsCall) -> bool:
        """Do the call of the whole queue by its name (the service client sends it so). Raise ValueError for an unknown one."""
        if name not in get_args(DownloadsCall):
            raise ValueError(f'unknown downloads call {name!r}')
        return getattr(self, name)()
