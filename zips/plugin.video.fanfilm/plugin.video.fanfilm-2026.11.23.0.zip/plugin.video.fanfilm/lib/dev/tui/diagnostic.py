"""
The TUI of the diagnostic code (`python -m lib.ff.diagnostic tui [code] [--set <Kodi data>[:<add-on>]]`): the areas of the code in
columns by its characters (the first character of the code - its highest bits - on the left), five fields a column, one frame with the
borders shared; the code on the top, the help of the field under the cursor below. The arrows move, the space or Enter switches a field,
`e` enters a code (its fields switched), `w` writes the code as pending to the Kodi profile of `--set` (only with it), `q` / Esc quits
and prints the code. The code, the bits and the texts of the areas: `lib.ff.diagnostic` and `const.debug.log_areas`.
"""

from __future__ import annotations
import os
import select
import sys
from pathlib import Path
from typing import Iterable
from attrs import define, field, frozen
import sty
from ...ff.diagnostic import CHAR_BITS, STATE_FILE, CodeState, area_bits, decode, encode, log_run, read_state, state_text, write_state
from ...kolang import L
from const import const

#: The keys of the escape sequences of the terminal by their names.
ESCAPES: dict[str, str] = {'\x1b[A': 'up', '\x1b[B': 'down', '\x1b[C': 'right', '\x1b[D': 'left', '\x1bOA': 'up', '\x1bOB': 'down',
                           '\x1bOC': 'right', '\x1bOD': 'left'}
#: The seconds the rest of an escape sequence is waited for (a lone Esc: none comes).
ESCAPE_WAIT: float = 0.05
#: The style of the code: its background, its colour, bold.
CODE_STYLE: str = sty.bg.blue + sty.fg.white + sty.ef.bold
#: The style of the header of a column.
HEADER_STYLE: str = sty.ef.bold
#: The style of the field under the cursor.
CURSOR_STYLE: str = sty.ef.inverse
#: The add-on of `--set` without one given.
DEFAULT_ADDON: str = 'plugin.video.fanfilm'
#: The narrowest inner width of a column.
MIN_COLUMN: int = 8


@frozen
class Field:
    """A field of the TUI: an area of the developer logs."""

    #: Its bit of the code.
    bit: int
    #: The key of the area.
    key: str
    #: The short label.
    label: str
    #: The help line.
    help: str


@frozen
class Column:
    """A column of the TUI: a character of the code."""

    #: The character (1: the last one, the lowest bits).
    char: int
    #: The label of the group of the character (`const.debug.diagnostic.groups`).
    label: str
    #: The fields by the bits of the character (`CHAR_BITS`), None: a bit of no area.
    fields: tuple[Field | None, ...]


def columns() -> tuple[Column, ...]:
    """Return the columns: every character with a declared bit, the first character of the code (the highest bits) first."""
    bits = area_bits()
    groups = const.debug.diagnostic.groups
    chars = max(bits) // CHAR_BITS + 1 if bits else 1

    def field_of(bit: int) -> Field | None:
        """Return the field of a bit (None: no area)."""
        if (key := bits.get(bit)) is None:
            return None
        area = const.debug.log_areas[key]
        return Field(bit=bit, key=key, label=str(area.label), help=str(area.help))

    return tuple(Column(char=char, label=str(groups[char - 1]) if char <= len(groups) else '',
                        fields=tuple(field_of((char - 1) * CHAR_BITS + i) for i in range(CHAR_BITS)))
                 for char in range(chars, 0, -1))


def target_path(spec: str) -> Path:
    """Return the file of the state of the code of a Kodi profile: `<Kodi data>[:<add-on>]` (e.g. `/storage/.kodi:plugin.video.fanfilm.dev4`)."""
    data, _, addon = spec.rpartition(':')
    if not data or '/' in addon or '\\' in addon or '.' not in addon:  # no add-on (a drive letter, a path)
        data, addon = spec, DEFAULT_ADDON
    return Path(data).expanduser() / 'userdata' / 'addon_data' / addon / STATE_FILE


def fit(text: str, width: int) -> str:
    """Return the text cut (an ellipsis) or padded to the width."""
    return text[:width - 1] + '…' if len(text) > width else text.ljust(width)


@define
class Model:
    """The state of the TUI."""

    #: The columns.
    columns: tuple[Column, ...] = field(factory=columns)
    #: The bits on (the unknown ones of an entered code too: kept in the code).
    bits: set[int] = field(factory=set)
    #: The bits of an entered code no area has.
    unknown: set[int] = field(factory=set)
    #: The column of the cursor.
    col: int = 0
    #: The row of the cursor (a field of the column).
    row: int = 0
    #: The text being entered (`e`), None: not entering.
    entering: str | None = None
    #: The message of the last action.
    message: str = ''
    #: The file of the state of the code of the Kodi profile of `--set` (None: no write).
    target: Path | None = None

    @property
    def code(self) -> str:
        """The code of the bits."""
        return encode(self.bits, min_length=const.debug.diagnostic.min_length)

    @property
    def focused(self) -> Field | None:
        """The field under the cursor."""
        return self.columns[self.col].fields[self.row] if self.columns else None

    def __attrs_post_init__(self) -> None:
        """Put the cursor on a field of an area (a character may have bits of no area: its first one)."""
        if self.focused is None:
            self.move(1, 0)

    def move(self, cols: int, rows: int) -> None:
        """
        Move the cursor (it wraps) over the fields of no area: up / down to the next field of the column, left / right to the
        nearest field of the next column with one.
        """
        for _ in range(len(self.columns) * CHAR_BITS):
            self.col = (self.col + cols) % len(self.columns)
            if cols:
                rows_of = [r for r, fld in enumerate(self.columns[self.col].fields) if fld is not None]
                if rows_of:
                    self.row = min(rows_of, key=lambda r: abs(r - self.row))
                    return
                continue
            self.row = (self.row + rows) % CHAR_BITS
            if self.focused is not None:
                return

    def toggle(self) -> None:
        """Switch the field under the cursor."""
        if (fld := self.focused) is not None:
            self.bits ^= {fld.bit}

    def enter(self, text: str) -> bool:
        """Switch the fields of a code (its unknown bits kept); return False if invalid (the message tells why)."""
        try:
            decoded = decode(text)
        except ValueError as exc:
            self.message = str(exc)
            return False
        self.bits, self.unknown = set(decoded.bits), set(decoded.unknown)
        self.message = ''
        return True

    def write(self) -> None:
        """Write the code as pending to the Kodi profile of `--set`."""
        if self.target is None:
            return
        data = self.target.parents[3]  # <Kodi data>/userdata/addon_data/<add-on>/<file>
        log = next((path for path in (data / 'temp' / 'kodi.log', data / 'kodi.log') if path.exists()), data / 'temp' / 'kodi.log')
        # the run of that Kodi now: active in its next one (a restart), not in a widget of the running one
        write_state(CodeState(code=decode(self.code).code, run=log_run(log)), self.target)
        self.message = L(31122, 'Written: {path}', path=self.target)


def handle(model: Model, key: str) -> bool:
    """Apply a key to the model; return False to quit."""
    if model.entering is not None:
        if key in ('\r', '\n'):
            if model.enter(model.entering):
                model.entering = None
        elif key == '\x1b':
            model.entering = None
        elif key in ('\x7f', '\b'):
            model.entering = model.entering[:-1]
        elif len(key) == 1 and key.isprintable():
            model.entering += key
        return True
    moves = {'up': (0, -1), 'down': (0, 1), 'left': (-1, 0), 'right': (1, 0)}
    if key in moves:
        model.move(*moves[key])
    elif key in (' ', '\r', '\n'):
        model.toggle()
    elif key == 'e':
        model.entering, model.message = '', ''
    elif key == 'w':
        model.write()
    elif key in ('q', '\x1b'):
        return False
    return True


def render(model: Model, width: int) -> list[str]:
    """Return the lines of the screen of the model in the width."""
    count = len(model.columns)
    inner = max(MIN_COLUMN, (width - count - 1) // count)
    keys = L(31123, '[arrows] move  [space] switch  [e] enter a code  [q] quit') + (L(31124, '  [w] write') if model.target is not None else '')
    title = f' {L(31117, "Diagnostic code")}: '
    code = f' {model.code} '
    lines = [f'{title}{CODE_STYLE}{code}{sty.rs.all}{" " * max(2, width - len(title) - len(code) - len(keys))}{keys}']
    lines.append(f' {L(30782, "Code")}: {model.entering}_' if model.entering is not None else '')

    def row(cells: Iterable[str], left: str = '│', mid: str = '│', right: str = '│') -> str:
        """Return a line of the frame of the cells."""
        return left + mid.join(cells) + right

    rule = ['─' * inner] * count
    lines.append(row(rule, '┌', '┬', '┐'))
    lines.append(row(f'{HEADER_STYLE}{fit(f" {col.char} {col.label}", inner)}{sty.rs.all}' for col in model.columns))
    lines.append(row(rule, '├', '┼', '┤'))
    for r in range(CHAR_BITS):
        cells = []
        for c, col in enumerate(model.columns):
            fld = col.fields[r]
            text = fit(f' [{"x" if fld.bit in model.bits else " "}] {fld.label}' if fld is not None else '', inner)
            cells.append(f'{CURSOR_STYLE}{text}{sty.rs.all}' if (c, r) == (model.col, model.row) else text)
        lines.append(row(cells))
    lines.append(row(rule, '└', '┴', '┘'))
    fld = model.focused
    lines.append(fit(f' {fld.help}' if fld is not None else '', width))
    if model.unknown:
        lines.append(' ' + L(31116, '{n} unknown part - update FanFilm|||{n} unknown parts - update FanFilm', n=len(model.unknown)))
    if model.target is not None:
        lines.append(f' {model.target}: {state_text(read_state(model.target))}')
    if model.message:
        lines.append(f' {model.message}')
    return lines


def read_key(fd: int) -> str:
    """Return the next key of the terminal (an escape sequence: its name of `ESCAPES`, else as read)."""
    key = os.read(fd, 1).decode(errors='replace')
    if key != '\x1b':
        return key
    while select.select([fd], [], [], ESCAPE_WAIT)[0]:
        key += os.read(fd, 1).decode(errors='replace')
        if key in ESCAPES:
            return ESCAPES[key]
    return key if len(key) > 1 else '\x1b'


def run(code: str = '', target: Path | None = None) -> str:
    """Run the TUI in the terminal (an entered code: its fields switched); return the code at its end."""
    from ..term import raw_term_input
    model = Model(target=target)
    if code:
        model.enter(code)
    out = sys.stdout
    fd = sys.stdin.fileno()
    out.write('\033[?1049h\033[?25l')  # the alternate screen, no cursor
    try:
        with raw_term_input():
            while True:
                width = os.get_terminal_size(out.fileno()).columns
                out.write('\033[H' + ''.join(f'{line}\033[K\n' for line in render(model, width)) + '\033[J')
                out.flush()
                if not handle(model, read_key(fd)):
                    break
    finally:
        out.write('\033[?25h\033[?1049l')
        out.flush()
    return model.code
