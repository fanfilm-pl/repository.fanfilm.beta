# -*- coding: utf-8 -*-
"""
FanFilm - source: NovaHD (novahd.cc)
Copyright (C) 2026 :)

MIT licensed <https://mit-license.org>

/api/sources?type={movie|show}&tmdbId={tmdb}[&season=&episode=] streams
provider links (Falcon, Viper, Wolf, Onyx, Puma, Lynx, ...) as ndjson,
one JSON object per line, terminated by {"done":true}. Only needs an
x-nova-visitor header (any random UUID, client-generated, no handshake).

The API is rate limited per IP (a few cold lookups per minute). Over the
limit it answers 429 or a decoy "Falcon" stream on novahd.cc/api/hls/
(one segment looped: "watch on novahd.cc"). So sources() makes exactly one
API call and stores the stream URL itself (tokens live ~24h); resolve()
makes no requests. Decoy entries are dropped. An answer which is not whole
(an HTTP error, a failed request, no "done" line, a decoy instead of a
stream) is IncompleteResult: shown, not cached.
"""

from __future__ import annotations

import json
import uuid
from typing import ClassVar, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs

from lib.ff import requests
from lib.ff.source.utils import FF_UA, append_headers
from lib.ff.logs import fflog, fflog_exc
from lib.sources import IncompleteResult

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


_BASE = 'https://novahd.cc'
_SOURCES_URL = _BASE + '/api/sources'
_DECOY_PREFIX = _BASE + '/api/hls/'

_HEADERS: Dict[str, str] = {
    'User-Agent': FF_UA,
    'Referer': _BASE + '/',
}

_SCHEME = 'novahd://'
#: The stream scheme of the sources cached before one API call a lookup (resolved by a second call, which is gone); not needed
#: once the sources cache of the older release has expired (`const.sources.cache.ttl` after the update).
_OLD_PLAY_SCHEME = 'novahdplay://'

_LANG_MAP = {
    'english': 'en', 'french': 'fr', 'spanish': 'es', 'latino': 'es',
    'german': 'de', 'deutsch': 'de', 'italian': 'it', 'portuguese': 'pt',
    'português': 'pt', 'russian': 'ru', 'polish': 'pl', 'dutch': 'nl',
    'japanese': 'ja', 'korean': 'ko', 'chinese': 'zh', 'arabic': 'ar',
    'turkish': 'tr',
}


class source:
    PREMIUM: ClassVar[bool] = False
    TMDB_EPISODES: ClassVar[bool] = True
    LABEL: ClassVar[str] = 'Novahd'
    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    ffitem: 'FFItem'

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(_HEADERS)
        self.session.headers['x-nova-visitor'] = str(uuid.uuid4())

    # ── public api ──────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        tmdb = str(self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'movie', 'tmdb': tmdb})

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: 'list[SourceTitleAlias]', year: str) -> Optional[str]:
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        if not tmdb:
            return None
        return _SCHEME + urlencode({'type': 'tv', 'tmdb': tmdb})

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: Optional[str], hostDict: List[str],
                hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        params = _decode(url)
        if not params.get('tmdb'):
            return []

        return self._fetch_items(_build_query(params))

    def resolve(self, url: str) -> Optional[str]:
        """Return the stream URL as it is (stored by `sources()`); none for an old cached `novahdplay://` one (a dead link)."""
        if not url or url.startswith(_OLD_PLAY_SCHEME):
            return None
        if not url.startswith('isa+') and self._is_hls(url.partition('|')[0]):
            return f'isa+{url}'  # labelled "mp4" by the API, but the edge serves an HLS playlist
        return url

    def _is_hls(self, link: str) -> bool:
        """Return True if the stream link answers an HLS playlist (one request to the CDN edge, not to the rate limited API)."""
        try:
            with self.session.get(link, stream=True, timeout=10) as resp:
                return 'mpegurl' in resp.headers.get('content-type', '').lower()
        except Exception:
            fflog_exc()
            return False

    # ── helpers ─────────────────────────────────────────────────────────────

    def _fetch_items(self, query: Dict[str, str]) -> 'List[SourceItem]':
        """Return the stream items of one API call; raise IncompleteResult (shown, not cached) if the answer is not whole."""
        items: 'List[SourceItem]' = []
        seen_urls: set = set()
        reason = 'no end of the stream'
        decoy = False
        try:
            resp = self.session.get(
                f'{_SOURCES_URL}?{urlencode(query)}',
                headers={'Accept': 'application/x-ndjson'},
                timeout=25,
                stream=True,
            )
            if not resp.ok:
                fflog(f'novahd: sources HTTP {resp.status_code} {resp.text[:200]}')
                reason = f'HTTP {resp.status_code}'
            else:
                # A warm (server cached) answer is one plain JSON object, whole without a "done" line.
                plain_json = 'ndjson' not in resp.headers.get('content-type', '')
                for line in resp.iter_lines(decode_unicode=True):
                    if not line or not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                    except ValueError:
                        continue
                    for entry in chunk.get('sources') or []:
                        entry_url = entry.get('url') or ''
                        if entry_url.startswith(_DECOY_PREFIX):
                            fflog('novahd: decoy stream skipped (rate limited)')
                            decoy = True
                            continue
                        if entry_url and entry_url not in seen_urls:
                            seen_urls.add(entry_url)
                            if item := _make_item(entry):
                                items.append(item)
                    if chunk.get('done') or (plain_json and 'sources' in chunk):
                        reason = ''
                        break
        except Exception:
            fflog_exc()
            reason = 'request failed'
        fflog(f'found {len(items)} streams')
        if decoy:
            reason = 'rate limited (a decoy stream)'
        if reason:  # raised here, out of the `try` above (it would swallow it)
            raise IncompleteResult(items, reason)
        return items


def _build_query(params: Dict[str, str]) -> Dict[str, str]:
    media_type = 'show' if params.get('type') in ('tv', 'show') else 'movie'
    query = {'type': media_type, 'tmdbId': params['tmdb']}
    if media_type == 'show':
        query['season'] = params.get('s') or params.get('season', '1')
        query['episode'] = params.get('e') or params.get('episode', '1')
    return query


def _make_item(entry: dict) -> 'Optional[SourceItem]':
    provider = entry.get('provider') or 'NovaHD'
    language_label = entry.get('language') or ''
    stream_url = _stream_url(entry)
    if not stream_url:
        return None

    item: 'SourceItem' = {
        'hosting': f'NovaHD {provider}',
        'quality': _quality_of(entry.get('quality', '')),
        'language': _lang_code(language_label),
        'url': stream_url,
        'direct': True,
        'debridonly': False,
    }
    if 'sub' in language_label.lower():
        item['info2'] = 'Napisy'
    return item


def _stream_url(entry: dict) -> Optional[str]:
    raw_url = entry.get('url')
    if not raw_url:
        return None
    stream_url = f'isa+{raw_url}' if entry.get('type') == 'hls' else raw_url
    return stream_url + append_headers(_HEADERS)


def _quality_of(raw: str) -> str:
    q = (raw or '').strip().lower()
    if q in ('4k', '8k'):
        return '4K'
    if q in ('1080', '1080p', '1080i', '1440p', '2k', 'fhd'):
        return '1080p'
    if q in ('720', '720p', 'hd'):
        return '720p'
    if q in ('480', '480p', 'sd'):
        return 'SD'
    return 'HD'


def _lang_code(label: str) -> str:
    if not label:
        return 'en'
    first_word = label.split()[0].lower()
    return _LANG_MAP.get(first_word, 'en')


def _decode_scheme(url: str, scheme: str) -> Dict[str, str]:
    if not url.startswith(scheme):
        return {}
    parsed = parse_qs(url[len(scheme):], keep_blank_values=True)
    return {k: v[0] for k, v in parsed.items()}


def _decode(url: str) -> Dict[str, str]:
    return _decode_scheme(url, _SCHEME)


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test NovaHD source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=1)
    parser.add_argument('--episode', type=int, default=1)
    args = parser.parse_args()

    src = source()
    if args.type == 'movie':
        url = _SCHEME + urlencode({'type': 'movie', 'tmdb': args.tmdb_id})
    else:
        url = _SCHEME + urlencode({'type': 'tv', 'tmdb': args.tmdb_id})
        url = f'{url}&s={args.season}&e={args.episode}'

    from pprint import pprint
    pprint(src.sources(url, [], []))
