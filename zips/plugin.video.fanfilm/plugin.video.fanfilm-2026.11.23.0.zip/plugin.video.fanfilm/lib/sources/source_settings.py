"""
The search of the sources by its settings (the card `SourceSettings` of `lib.ff.config.options`, the page "Source search" of the
configuration window, `lib.windows.widgets.source_settings`): the times of a search, the row of its one time of the simple view.
"""

from __future__ import annotations
from attrs import evolve, frozen
from ..ff.config import config
from ..ff.config.blocks import CatalogSetting
from ..kolang import L

#: The key of the row of the one time of the search of the simple view (`search_end_setting()`).
SEARCH_END: str = 'search_end'


@frozen(kw_only=True)
class SearchLimits:
    """The times of a search of the sources (seconds, from its start; the setting `search_timeout`)."""

    #: The progress window up to it, then the list of the sources found so far (0: the list at once).
    list_after: float
    #: The end of the search.
    end: float


def search_end_setting() -> CatalogSetting:
    """
    Return the row of the time of the search of the simple view (no list while searching: one time, the end; written with `search_timeout`
    by its page).
    """
    timeout = config.sources.settings.catalog()['search_timeout']
    scale = timeout['scale']
    return {**timeout, 'key': SEARCH_END, 'kind': 'scale', 'default': timeout['default'][1],
            'scale': evolve(scale, values=tuple(value for value in scale.values if value >= scale.knob_max_least)),
            'help': L(30984, 'The time of the search, seconds. At its end the debrid services check the torrents.')}


def search_limits() -> SearchLimits:
    """Return the times of a search of the sources."""
    list_after, end = config.sources.settings.search_timeout
    return SearchLimits(list_after=list_after, end=end)
