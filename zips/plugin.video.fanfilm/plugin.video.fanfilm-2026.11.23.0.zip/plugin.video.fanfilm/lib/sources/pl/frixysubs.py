# -*- coding: utf-8 -*-
"""
FanFilm - źródło: frixysubs
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations

import re
import unicodedata
from urllib.parse import quote_plus
from typing import Any, List, Optional, TYPE_CHECKING

from lib.ff import requests
from lib.ff import cleantitle
from lib.ff.source import utils as source_utils
from lib.ff.source.utils import DEFAULT_UA
from lib.ff.logs import fflog
from lib.ff.item import FFItem
from lib.api import kitsu as kitsu_api
from lib.sdk.facts.vocab import VideoCodec
if TYPE_CHECKING:
    from typing import Collection, ClassVar
    from lib.defs import MediaCategory
    from lib.sources import SourceItem, SourceTitleAlias

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'FrixySubs'

    # set in ff/source/manager.py
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']
    CATEGORIES: ClassVar[Collection[MediaCategory]] = {'anime'}

    def __init__(self):
        self.base_link = 'https://frixysubs.pl'
        self.api_link = self.base_link + '/api'
        self.search_link = f"{self.api_link}/anime?offset=0&limit=50&search=%s"
        self.episode_link = f"{self.api_link}/anime/%s"
        self.session = requests.ProviderSession()
        self.headers = {
            'User-Agent': DEFAULT_UA,
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': self.base_link + '/',
        }

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        if self.ffitem.anime_info is None:
            return None
        movie_info = self.ffitem.anime_info.movie
        if movie_info:
            titles = [movie_info['title'], title]
            fflog.debug(f'movie: kitsu={movie_info["title"]!r}')
        else:
            jp_aliases = [alias['title'] for alias in aliases if alias['country'] == 'jp']
            titles = (jp_aliases[:1] if jp_aliases else []) + [title]
        return self._search(titles, None, None, None, aliases)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> tuple[list[str], str, list[SourceTitleAlias]]:
        jp_aliases = [alias['title'] for alias in aliases if alias['country'] == 'jp']
        titles = (jp_aliases[:1] if jp_aliases else []) + [tvshowtitle]
        return titles, year, aliases

    def episode(self, url: tuple[list[str], str, list[SourceTitleAlias]], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        if self.ffitem.show_item is None or self.ffitem.anime_info is None or not source_utils.is_anime(self.ffitem):
            return None
        tmdb = self.ffitem.show_item.tmdb_id
        aliases = url[2] if len(url) > 2 else []
        return self._search_with_kitsu(url[0], season, episode, str(tmdb) if tmdb else None, aliases)

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        if isinstance(url, list):
            url = url[0]
        anime_link, _, number = url.partition('|')
        episode = self._episode(anime_link, int(number))
        if episode is None:
            fflog(f'{anime_link}: no episode {number}')
            return []
        sources = [self._source(player.get('name') or '', link, anime_link)
                   for player in episode.get('players') or () if (link := player.get('link'))]
        fflog(f'{anime_link} #{number}: {len(sources)} sources')
        return sources

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _source(player_name: str, player_link: str, anime_link: str) -> SourceItem:
        """
        Build a source of a player. The group releases 1080p encodes; its own file links are named "<KIND> (BUZZ)":
        "REMUX" is an MKV with the subtitles as a separate track (an encode, not a remux), "HARDSUB" an MP4 with burned
        subtitles, "AV1 REMUX" the MKV in AV1. The players of the hostings (CDA, VK, GD...) have burned subtitles.
        """
        kind, _, host = player_name.partition('(')
        host = host.rstrip(')').strip()
        kind = kind.strip().upper() if host else ''
        soft = 'REMUX' in kind
        item: SourceItem = {
            'hosting': {'BUZZ': 'buzzheavier'}.get(host.upper(), host) if host else player_name.upper(),
            'quality': '1080p',
            'language': 'pl',
            'url': player_link,
            'info': 'Softsub' if soft else '',
            'filename': anime_link,
            'direct': False,
            'debridonly': False,
            'premium': False,
            'subtitles': [{'lang': 'pl', 'burned': not soft}],
        }
        if 'AV1' in kind:
            item['video'] = {'codec': VideoCodec.AV1}
        return item

    def _get_json(self, url: str) -> dict[str, Any]:
        resp = self.session.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def _find_series(self, title: str) -> list[dict[str, Any]]:
        """Return the series of the search of the title (accents stripped)."""
        plain = ''.join(char for char in unicodedata.normalize('NFD', title) if unicodedata.category(char) != 'Mn')
        series = self._get_json(self.search_link % quote_plus(plain)).get('series') or []
        fflog.debug(f'query {title!r}: {[anime.get("title") for anime in series]}')
        return series

    def _episode(self, anime_link: str, number: int) -> dict[str, Any] | None:
        """Return the episode of the series (its players), None if the series has no such episode."""
        episodes = self._get_json(self.episode_link % anime_link).get('episodes') or []
        if isinstance(episodes, dict):
            episodes = episodes.get('episodes') or []
        return next((ep for ep in episodes if isinstance(ep, dict) and ep.get('number') == number), None)

    def _get_episode_link(self, anime_link: str, episode_number: int) -> Optional[str]:
        """Return the url of the episode for sources(), None if the series has no such episode."""
        return f'{anime_link}|{episode_number}' if self._episode(anime_link, episode_number) else None

    def _search_with_kitsu(self, titles: List[str], season: str, episode: str, tmdb: Optional[str], aliases: list[SourceTitleAlias]) -> Optional[str]:
        if self.ffitem.anime_info is None or not (cours := self.ffitem.anime_info.cours):
            fflog(f'no kitsu data for tmdb={tmdb}')
            return None

        cour, local_ep = kitsu_api.resolve_cour(cours, self.ffitem)
        if not cour or not local_ep:
            fflog(f'no kitsu cour of tmdb={tmdb} S{season}E{episode}')
            return None

        kitsu_title = cour['title']
        kitsu_norm = kitsu_api.normalize_series_title(kitsu_title)
        fflog.debug(f'kitsu cour {kitsu_title!r}, local ep {local_ep}')

        series = self._find_series(kitsu_title)
        if not series:
            fflog(f'no results for {kitsu_title!r}')
            return None

        candidates = []
        tmdb_year = str(self.ffitem.vtag.getYear()) if self.ffitem.vtag.getYear() else None
        kitsu_words = set(kitsu_norm.split())

        for anime in series:
            if anime.get('movieseries'):
                continue
            anime_title = anime.get('title', '').strip()
            anime_link = anime.get('link', '')

            # Year from the title
            year_match = re.search(r'\((\d{4})\)', anime_title)
            res_year = year_match.group(1) if year_match else None

            if res_year and tmdb_year and res_year != tmdb_year:
                fflog.debug(f'  {anime_title!r}: year {res_year} != {tmdb_year}')
                continue

            anime_norm = kitsu_api.normalize_series_title(anime_title)

            # 1. Exact match
            if anime_norm == kitsu_norm:
                fflog(f'matched {anime_title!r} (exact), ep {local_ep}')
                return self._get_episode_link(anime_link, local_ep)

            anime_words = set(anime_norm.split())
            if res_year and res_year in anime_words:
                anime_words.remove(res_year)

            # "... Ken" is a subset of "... Ken 4th Season" — a different season number is another series
            if kitsu_api.series_season(anime_norm) != kitsu_api.series_season(kitsu_norm):
                fflog.debug(f'  {anime_title!r}: another season')
                continue

            if kitsu_words.issubset(anime_words) or anime_words.issubset(kitsu_words):
                # 2. Matching year
                if res_year and res_year == tmdb_year:
                    fflog(f'matched {anime_title!r} (year), ep {local_ep}')
                    return self._get_episode_link(anime_link, local_ep)
                candidates.append((anime_link, anime_title, len(anime_words)))

        if candidates:
            candidates.sort(key=lambda x: x[2])
            anime_link, anime_title, _ = candidates[0]
            fflog(f'matched {anime_title!r} (subset), ep {local_ep}')
            return self._get_episode_link(anime_link, local_ep)

        fflog(f'no match for {kitsu_title!r}')
        return None

    def _search(self, titles: List[str], season: Optional[str], episode: Optional[str], tmdb: Optional[str], aliases: list[SourceTitleAlias] | None = None) -> Optional[str]:
        """Search a movie (or a series without Kitsu data) by the titles."""
        if season is not None and episode is not None:
            if (target_episode := self.ffitem.absolute_episode_number()) is None:
                return None
        else:
            target_episode = 1

        titles = list(dict.fromkeys(title.lower() for title in titles if title))
        alias_cleans: set[str] = cleantitle.normalize_titles(titles=titles, aliases=aliases)

        for title in titles:
            for anime in self._find_series(title):
                anime_title = anime.get('title', '').strip()
                anime_link = anime.get('link', '')
                is_movie = anime.get('movieseries', False)
                result_normalized = cleantitle.normalize(anime_title).lower()
                if not any(all(word in result_normalized for word in mt.split()) for mt in alias_cleans):
                    continue
                if is_movie and season is None:
                    fflog(f'matched movie {anime_title!r}')
                    return f'{anime_link}|1'
                if not is_movie and season is not None:
                    fflog(f'matched series {anime_title!r}, ep {target_episode}')
                    return self._get_episode_link(anime_link, target_episode)
        fflog(f'no match for {titles}')
        return None
