# -*- coding: UTF-8 -*-
"""
FanFilm - source: seriale.vip
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

A DLE (DataLife Engine) site. The players of a movie / a show come by AJAX:

    POST /engine/ajax/controller.php?mod=playlists  (news_id=<id>&xfield=pl)

Embed hostings: vidara (JSON API), veev (LZW-coded player API) and fsst.online (a KVS player on
incvideo1.online with direct MP4 links). The stream links are made in resolve(): their tokens may
live shorter than the sources cache.
"""

from __future__ import annotations

import binascii
import json
import re
from typing import ClassVar, TYPE_CHECKING
from urllib.parse import urlencode, urljoin, urlparse

from lib.ff import cleantitle, requests
from lib.ff.item import FFItem
from lib.ff.logs import fflog
from lib.ff.source.utils import append_headers, search_queries_extended, year_matches
from lib.ff.threads import xsleep

if TYPE_CHECKING:
    from lib.sources import SourceItem

_BASE = 'https://seriale.vip'
_PLAYLIST_URL = _BASE + '/engine/ajax/controller.php?mod=playlists'
_SEARCH_URL = _BASE + '/index.php'
_VIDARA_BASE = 'https://vidara.to'
_TIMEOUT = 20

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': _BASE + '/',
}
_AJAX_HEADERS = {
    **_HEADERS,
    'X-Requested-With': 'XMLHttpRequest',
    'Content-Type': 'application/x-www-form-urlencoded',
}

#: The site paths of movies (the others are shows).
_MOVIE_PATHS = ('films', 'animation', 'anime', 'reality')
_RX_NEWS_ID = re.compile(r'/(films|serials|animation|anime|reality)/(\d+)-')
#: The embeds of the hostings resolve() knows.
_RX_EMBED = re.compile(
    r'https://(?:(?:veev\.to|vidara\.(?:so|to)|vidaraa\.cc|streamix\.so|stmix\.io)/(?:e|v)/[^"]+'
    r'|fsst\.online/embed/[^"]+)'
)


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    LABEL: ClassVar[str] = 'SerialeVIP'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('pl',)
    PREMIUM: ClassVar[bool] = False
    ffitem: FFItem

    def __init__(self) -> None:
        self.session: requests.Session = requests.ProviderSession()

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list, year: str) -> str | None:
        return self._find(title, localtitle, year, 'movie')

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list,
               year: str) -> str | None:
        return self._find(tvshowtitle, localtvshowtitle, year, 'tvshow')

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str, premiered: str, season: str,
                episode: str) -> str | None:
        if not url or not (news_id := _news_id_from_url(url)):
            return None
        embed_url = self._get_episode_embed(news_id, int(season), int(episode))
        fflog.debug(f'episode embed: {embed_url}')
        return embed_url

    def sources(self, url: str | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:
        if not url:
            return []
        if url.startswith(_BASE):
            if not (news_id := _news_id_from_url(url)):
                return []
            embed_urls = self._get_movie_embeds(news_id)
        else:
            embed_urls = [url]
        return [{
            'hosting': _host_label(embed_url),
            'quality': '720p',
            'language': 'pl',
            'url': embed_url,
            'info': 'LEKTOR',
            'direct': False,
            'debridonly': False,
            'premium': False,
        } for embed_url in embed_urls]

    def resolve(self, url: str, **kwargs) -> str | None:
        host = _host_label(url)
        try:
            if host == 'fsst':
                stream_url = self._resolve_fsst(url)
            elif host == 'vidara':
                stream_url = self._resolve_vidara(url)
            elif host in ('veev', 'poophq', 'doods'):
                stream_url = self._resolve_veev(url)
            else:
                fflog(f'unknown hosting: {url}')
                return None
        except (requests.RequestException, ValueError, KeyError, IndexError) as exc:
            fflog(f'dead link: {exc!r} {url}')
            return None
        if not stream_url:
            fflog(f'dead link: {url}')
            return None
        base_url = stream_url.partition('|')[0]
        if '.m3u8' in base_url or '.mpd' in base_url:
            return f'isa+{stream_url}'
        return stream_url

    # ── helpers ────────────────────────────────────────────────────────────

    def _find(self, title: str, localtitle: str, year: str, media_type: str) -> str | None:
        for index, query in enumerate(search_queries_extended(localtitle or title, title or localtitle)):
            if index:
                xsleep(0.4)
            if result := self._search(query, year, media_type):
                return result
        return None

    def _search(self, query: str, year: str, media_type: str) -> str | None:
        fflog.debug(f'query={query!r} year={year} type={media_type}')
        resp = self.session.post(_SEARCH_URL, data={'do': 'search', 'subaction': 'search', 'story': query},
                                 headers=_HEADERS, timeout=_TIMEOUT)
        resp.raise_for_status()

        clean_query = cleantitle.get_simple(query)
        exp_year = int(year) if year and year.isdigit() else 0
        # Isolate each result card first, so the title <h3> of the next card is not taken.
        for card_match in re.finditer(r'<a\s[^>]*class="[^"]*poster[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                                      resp.text, re.DOTALL):
            href, block = card_match.group(1), card_match.group(2)
            if not (url_match := _RX_NEWS_ID.search(href)):
                continue
            title_match = re.search(r'<h3[^>]*class="[^"]*poster__title[^"]*"[^>]*>([^<]+)</h3>', block)
            title = title_match.group(1).strip() if title_match else ''
            if (url_match.group(1) in _MOVIE_PATHS) != (media_type == 'movie'):
                fflog.debug(f'skip (other media type): {title} {href}')
                continue
            if exp_year and not year_matches(href, exp_year):
                fflog.debug(f'skip (year): {title} {href}')
                continue
            if not title or (clean_query and clean_query not in cleantitle.get_simple(title)):
                fflog.debug(f'skip (title): {title} {href}')
                continue
            fflog.debug(f'found: {href}')
            return href
        return None

    def _fetch_playlist(self, news_id: str) -> str | None:
        resp = self.session.post(_PLAYLIST_URL, data={'news_id': news_id, 'xfield': 'pl'},
                                 headers=_AJAX_HEADERS, timeout=_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        if not data.get('success'):
            fflog(f'no playlist: news_id={news_id}')
            return None
        return data['response']

    def _get_movie_embeds(self, news_id: str) -> list[str]:
        html = self._fetch_playlist(news_id)
        if not html:
            return []
        embed_urls: list[str] = []
        for file_url in re.findall(r'data-file="([^"]+)"', html):
            if _RX_EMBED.fullmatch(file_url):
                embed_urls.append(file_url)
            else:
                fflog.debug(f'skip (unknown hosting): {file_url}')
        return embed_urls

    def _get_episode_embed(self, news_id: str, season: int, episode: int) -> str | None:
        html = self._fetch_playlist(news_id)
        if not html:
            return None

        # Each <li data-id="X_Y_Z"> (depth 2) names a hosting + language track. The first LEKTOR track that has the
        # episode wins (vidara numbers episodes per season, veev cumulatively).
        lektor_prefixes = [data_id for data_id, label in re.findall(r'<li data-id="([^"]+)">([^<]+)</li>', html)
                           if data_id.count('_') == 2 and label.strip().upper() == 'LEKTOR']
        video_items = re.findall(r'<li data-file="([^"]+)" data-id="([^"]+)">', html)
        for prefix in lektor_prefixes:
            target_id = f'{prefix}_{season - 1}'
            season_eps = [ep_url for ep_url, data_id in video_items if data_id == target_id]
            if 1 <= episode <= len(season_eps):
                return season_eps[episode - 1]

        fflog(f'episode not found: s{season}e{episode}')
        return None

    def _resolve_fsst(self, embed_url: str) -> str | None:
        # fsst.online redirects to a KVS player (incvideo1.online): file:"[360p]https://...mp4/,[720p]https://...mp4/"
        resp = self.session.get(embed_url, headers=_HEADERS, timeout=_TIMEOUT)
        resp.raise_for_status()
        if not (match := re.search(r'file:\s*"([^"]+)"', resp.text)):
            return None
        variants = re.findall(r'\[(\d+)p\](https?://[^,\s]+)', match.group(1))
        if not variants:
            return None
        stream_url = max(variants, key=lambda variant: int(variant[0]))[1]
        return stream_url + append_headers({'User-Agent': _UA})

    def _resolve_vidara(self, embed_url: str) -> str | None:
        filecode = embed_url.rstrip('/').split('/')[-1]
        resp = self.session.post(
            f'{_VIDARA_BASE}/api/stream',
            data=json.dumps({'filecode': filecode}).encode(),
            headers={
                'User-Agent': _UA,
                'Referer': f'{_VIDARA_BASE}/e/{filecode}',
                'Origin': _VIDARA_BASE,
                'Content-Type': 'application/json',
            },
            timeout=_TIMEOUT,
        )
        if not (streaming_url := resp.json().get('streaming_url')):
            return None
        return streaming_url + append_headers({'User-Agent': _UA, 'Referer': _VIDARA_BASE + '/', 'Origin': _VIDARA_BASE})

    def _resolve_veev(self, embed_url: str) -> str | None:
        headers = {'User-Agent': _UA, 'Referer': embed_url}
        resp = self.session.get(embed_url, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        final_url = resp.url
        media_id = final_url.rstrip('/').split('/')[-1]
        candidates = re.findall(r'''[\.\s'](?:fc|_vvto\[[^\]]*)(?:['\]]*)?\s*[:=]\s*['"]([^'"]+)''', resp.text)
        for candidate in reversed(candidates):
            challenge = _veev_lzw_decode(candidate)
            if challenge == candidate:
                continue
            params = {'op': 'player_api', 'cmd': 'gi', 'file_code': media_id, 'ch': challenge, 'ie': 1}
            dl_url = urljoin(final_url, '/dl') + '?' + urlencode(params)
            file_data = self.session.get(dl_url, headers=headers, timeout=_TIMEOUT).json().get('file')
            if not file_data or file_data.get('file_status') != 'OK':
                return None
            stream_url = _veev_decode_url(_veev_lzw_decode(file_data['dv'][0]['s']), _veev_build_array(challenge)[0])
            return stream_url + append_headers({'User-Agent': _UA, 'Referer': embed_url, 'verifypeer': 'false'})
        return None


def _news_id_from_url(url: str) -> str | None:
    match = _RX_NEWS_ID.search(url)
    return match.group(2) if match else None


def _host_label(url: str) -> str:
    host = urlparse(url).hostname or ''
    return host.split('.')[-2] if '.' in host else host or 'embed'


def _veev_lzw_decode(etext: str) -> str:
    result: list[str] = []
    lut: dict[int, str] = {}
    code_next = 256
    current = etext[0]
    result.append(current)
    for char in etext[1:]:
        code = ord(char)
        entry = char if code < 256 else lut.get(code, current + current[0])
        result.append(entry)
        lut[code_next] = current + entry[0]
        code_next += 1
        current = entry
    return ''.join(result)


def _veev_js_int(text: str) -> int:
    return int(text) if text.isdigit() else 0


def _veev_build_array(encoded: str) -> list[list[int]]:
    arrays: list[list[int]] = []
    chars = list(encoded)
    count = _veev_js_int(chars.pop(0))
    while count:
        current_array: list[int] = []
        for _ in range(count):
            current_array.insert(0, _veev_js_int(chars.pop(0)))
        arrays.append(current_array)
        count = _veev_js_int(chars.pop(0))
    return arrays


def _veev_decode_url(etext: str, tarray: list[int]) -> str:
    decoded = etext
    for step in tarray:
        if step == 1:
            decoded = decoded[::-1]
        decoded = binascii.unhexlify(decoded).decode('utf8')
        decoded = decoded.replace('dXRmOA==', '')
    return decoded
