# -*- coding: utf-8 -*-
"""
FanFilm - source: AnimeZone (animezone.pl)

Dystrybuowane na licencji MIT <https://mit-license.org>

The site (rebuilt 2026-11, Angular) reads everything from a public GraphQL API (GET, no login, no token):

    /api/graph?_locale=pl&query=<query>&variables=<json>

    serieSearch(input)                              -> series: slug, titles, category, release, external links (MyAnimeList)
    singleEpisodePlayableSources(serie, episodeIndex) -> sources: resolution, audio / subtitle language, server pattern + code

A series is matched by the MyAnimeList id of the Kitsu cour (its external link), else by the title and the year.
The embed link of a source is the pattern of its server with the code (`https://video.sibnet.ru/shell.php?videoid={CODE}`):
no resolve step on the site.
"""

from __future__ import annotations

import json
import re
from typing import Any, ClassVar, TYPE_CHECKING

from lib.ff import requests
from lib.ff.logs import fflog
from lib.ff.source.utils import DEFAULT_UA
from lib.api import kitsu as kitsu_api
from lib.sdk.facts.vocab import TrackKind
from lib.sdk.protocol.item import quality_of_resolution
from lib.sources import Provider, skip

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.api.kitsu import CourInfo
    from lib.sources import SourceItem, SourceSearchOverride

_BASE: str = 'https://animezone.pl'
_GRAPH: str = f'{_BASE}/api/graph'

_SEARCH_QUERY: str = (
    'query SerieCatalogueSearch($input:SearchInput!){serieSearch(input:$input){items{'
    'slug title subtitle synonyms kind category{slug} externalLinks{name url} '
    '...on SerieWatchable{release{start}}}}}'
)
_SOURCES_QUERY: str = (
    'query EpisodeSources($slug:String!$episodeIndex:Int!){singleEpisodePlayableSources('
    'serie:{slug:$slug}episodeIndex:$episodeIndex){items{'
    'id resolution ai dubbingLanguage{code} language{code} server{name pattern} code translators{name}}}}'
)
#: Results of one search query (the site sorts by rating: the anime first, its manga / novel after).
_SEARCH_LIMIT: int = 20
#: Categories of a movie; the others are of a series (tv, ova, ona, special...).
_MOVIE_CATEGORIES: frozenset[str] = frozenset({'movie'})
_RX_MAL = re.compile(r'myanimelist\.net/anime/(\d+)')


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    LABEL: ClassVar[str] = 'AnimeZone'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('pl',)
    PREMIUM = False
    CATEGORIES = ('anime',)

    def __init__(self, *, ffitem: FFItem) -> None:
        super().__init__(ffitem=ffitem)
        self.session: requests.Session = requests.ProviderSession()
        self.session.headers.update({'User-Agent': DEFAULT_UA, 'Accept': 'application/json', 'Referer': f'{_BASE}/'})

    # ── public api ─────────────────────────────────────────────────────────

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        anime = ffitem.anime_info
        is_episode = override['season'] is not None and override['episode'] is not None
        titles = [override['original_title'], override['english_title']]
        if is_episode:
            if anime is None or not (cours := anime.cours):
                fflog(f'no kitsu cours: {ffitem}')
                return []
            cour, local_ep = kitsu_api.resolve_cour(cours, ffitem)
            if not cour or not local_ep:
                fflog(f'no kitsu cour of S{override["season"]}E{override["episode"]}')
                return []
            # Show-level titles point at the first cour: a sequel is searched by its own title only
            is_sequel = cour['kitsu_id'] != cours[0]['kitsu_id']
            slug = self._find_serie(cour, [] if is_sequel else titles, movie=False)
        else:
            cour, local_ep = (anime.movie if anime else None), 1
            slug = self._find_serie(cour, titles, movie=True, year=override['year'])
        if not slug:
            return []

        items: list[dict[str, Any]] = self._graph(_SOURCES_QUERY, {'slug': slug, 'episodeIndex': local_ep}
                                                  )['singleEpisodePlayableSources']['items'] or []
        result = [src for item in items if (src := self._source(item, slug, local_ep))]
        fflog(f'{slug} #{local_ep}: {len(result)} sources')
        return result

    # ── helpers ────────────────────────────────────────────────────────────

    def _graph(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        """Run a GraphQL query, return its data (errors raised)."""
        resp = self.session.get(_GRAPH, params={'_locale': 'pl', 'query': query, 'variables': json.dumps(variables)})
        resp.raise_for_status()
        answer = resp.json()
        if answer.get('errors') or not answer.get('data'):
            raise RuntimeError(f'animezone graph error: {answer.get("errors")!r}')
        return answer['data']

    def _search(self, text: str) -> list[dict[str, Any]]:
        fflog.debug(f'query: {text!r}')
        data = self._graph(_SEARCH_QUERY, {'input': {
            'adultContent': False, 'filter': {}, 'query': text,
            'pagination': {'limit': _SEARCH_LIMIT, 'page': 1}, 'sort': {'direction': 'DESC', 'field': 'RATING'},
        }})
        return [serie for serie in data['serieSearch']['items'] or [] if serie.get('kind') == 'WATCHABLE']

    def _find_serie(self, cour: CourInfo | None, titles: list[str], *, movie: bool, year: int | None = None) -> str | None:
        """Return the slug of the series (or the movie) of the Kitsu cour, else of the titles and the year."""
        queries: list[str] = []
        if cour:
            queries.append(cour['title'])
            base, _ = kitsu_api.strip_season_suffix(cour['title'])
            queries.append(base)
            year = cour['start_date'].year if cour['start_date'] else year
        queries.extend(title for title in titles if title)
        wanted = {kitsu_api.normalize_series_title(text) for text in ([cour['title']] if cour else []) + titles if text}
        mal_id = cour['mal_id'] if cour else None

        fallback: str | None = None
        for text in dict.fromkeys(queries):
            for serie in self._search(text):
                slug: str = serie['slug']
                if ((serie.get('category') or {}).get('slug') in _MOVIE_CATEGORIES) != movie:
                    fflog.debug(f'  {slug}: not a {"movie" if movie else "series"}')
                    continue
                serie_mal = next((int(mch.group(1)) for link in serie.get('externalLinks') or ()
                                  if (mch := _RX_MAL.search(link.get('url') or ''))), None)
                if mal_id and serie_mal:
                    if serie_mal == mal_id:
                        fflog(f'matched by MAL id {mal_id}: {slug}')
                        return slug
                    fflog.debug(f'  {slug}: MAL id {serie_mal} != {mal_id}')
                    continue
                names = [serie.get('title'), serie.get('subtitle'), *(serie.get('synonyms') or ())]
                start = (serie.get('release') or {}).get('start') or ''
                if (fallback is None and wanted & {kitsu_api.normalize_series_title(name) for name in names if name}
                        and (not year or start[:4] == str(year))):
                    fallback = slug
                fflog.debug(f'  {slug}: {serie.get("title")!r} {start[:4]} mal={serie_mal}')
        if fallback:
            fflog(f'matched by title and year: {fallback}')
        else:
            fflog(f'no match of {queries}')
        return fallback

    def _source(self, item: dict[str, Any], slug: str, episode: int) -> SourceItem | None:
        server: dict[str, Any] = item.get('server') or {}
        pattern: str = server.get('pattern') or ''
        code: str = item.get('code') or ''
        if '{CODE}' not in pattern or not code:
            skip(self, 'no embed pattern or code', hosting=server.get('name'), url=pattern)
            return None
        subs: str = (item.get('language') or {}).get('code') or ''
        audio: str = (item.get('dubbingLanguage') or {}).get('code') or ''
        groups = ', '.join(name for translator in item.get('translators') or () if (name := translator.get('name')))
        # The languages as facts (the sources window writes "Napisy: PL" itself), not as words in the info
        source_item: SourceItem = {
            'url': pattern.replace('{CODE}', code),
            'hosting': server.get('name') or '',
            'quality': quality_of_resolution(height=int(item.get('resolution') or 0)),
            'language': audio if audio == 'pl' else subs or audio,
            'info': groups,
            'filename': f'{slug} {episode}',
            'direct': False,
            'debridonly': False,
            'premium': False,
        }
        if audio:
            source_item['audio'] = [{'lang': audio, 'kind': TrackKind.DUBBING} if audio == 'pl' else {'lang': audio}]
        if subs:
            source_item['subtitles'] = [{'lang': subs, 'ai': bool(item.get('ai'))}]
        return source_item
