# -*- coding: utf-8 -*-
"""
FanFilm - source: MaKiSuBs (makisubs.pl)

Dystrybuowane na licencji MIT <https://mit-license.org>

Site of a Polish fansub group (PHP, plain HTML, no login):

    list.php?search=<text>                    -> series cards: anime.php?id=N, AniList cover (".../b<anilist id>-...")
    watch.php?anime_id=N&episode=E            -> link groups ("Napisy"...): changePlayer('<embed>'), host name, quality
                                                 (a missing episode redirects to anime.php)

Titles are romaji (as Kitsu), a sequel has its own entry ("... Sezon 2") with its own AniList id.
A series is matched by the AniList id of the Kitsu cour, else by the normalized title.
"""

from __future__ import annotations

import re
from html import unescape
from typing import ClassVar, TYPE_CHECKING

from lib.ff import requests
from lib.ff.logs import fflog
from lib.ff.source.utils import DEFAULT_UA
from lib.api import kitsu as kitsu_api
from lib.sdk.facts.vocab import TrackKind
from lib.sources import Provider, skip

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.api.kitsu import CourInfo
    from lib.sources import SourceItem, SourceSearchOverride

_BASE: str = 'https://makisubs.pl'

_RX_CARD = re.compile(r"""anime\.php\?id=(\d+)['"].*?<img src="[^"]*/anime/cover/\w+/[a-z]*(\d+)-.*?"""
                      r"""class="anime-title">([^<]+)<""", re.S)
_RX_GROUP = re.compile(r'class="link-group-title[^"]*">([^<]*)<(.*?)(?=class="link-group-title|$)', re.S)
_RX_LINK = re.compile(r"""changePlayer\('([^']+)'.*?link-name">\s*([^<]*?)\s*<.*?link-quality">\s*([^<]*?)\s*<""", re.S)


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    LABEL: ClassVar[str] = 'MaKiSuBs'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('pl',)
    PREMIUM = False
    CATEGORIES = ('anime',)

    def __init__(self, *, ffitem: FFItem) -> None:
        super().__init__(ffitem=ffitem)
        self.session: requests.Session = requests.ProviderSession()
        self.session.headers.update({'User-Agent': DEFAULT_UA, 'Referer': f'{_BASE}/'})

    # ── public api ─────────────────────────────────────────────────────────

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        anime = ffitem.anime_info
        if override['season'] is not None and override['episode'] is not None:
            if anime is None or not (cours := anime.cours):
                fflog(f'no kitsu cours: {ffitem}')
                return []
            cour, local_ep = kitsu_api.resolve_cour(cours, ffitem)
        else:
            cour, local_ep = (anime.movie if anime else None), 1
        if not cour or not local_ep:
            fflog(f'no kitsu cour of {ffitem}')
            return []
        anime_id = self._find_anime(cour)
        if not anime_id:
            return []

        url = f'{_BASE}/watch.php?anime_id={anime_id}&episode={local_ep}'
        resp = self.session.get(url, allow_redirects=False)
        if resp.is_redirect:
            fflog(f'anime {anime_id}: no episode {local_ep}')
            return []
        resp.raise_for_status()
        result = [src for group, block in _RX_GROUP.findall(resp.text)
                  for link, host, quality in _RX_LINK.findall(block)
                  if (src := self._source(link, unescape(host), quality, unescape(group), anime_id, local_ep))]
        fflog(f'anime {anime_id} #{local_ep}: {len(result)} sources')
        return result

    # ── helpers ────────────────────────────────────────────────────────────

    def _search(self, text: str) -> list[tuple[str, int, str]]:
        """Return the cards (site id, AniList id, title) of the search."""
        resp = self.session.get(f'{_BASE}/list.php', params={'search': text})
        resp.raise_for_status()
        cards = [(anime_id, int(anilist), unescape(title).strip()) for anime_id, anilist, title in _RX_CARD.findall(resp.text)]
        fflog.debug(f'query {text!r}: {cards}')
        return cards

    def _find_anime(self, cour: CourInfo) -> str | None:
        """Return the site id of the series of the Kitsu cour (by its AniList id, else by its title)."""
        base, _ = kitsu_api.strip_season_suffix(cour['title'])
        wanted = kitsu_api.normalize_series_title(cour['title'])
        anilist_id = cour['anilist_id']
        # The site search is a literal substring match ("Demon's Crest" does not find "Demons' Crest"):
        # the first word of the title is the broad last query, the AniList id picks the series
        first_word = re.match(r'\W*(\w{3,})', base)
        queries = (cour['title'], base) + ((first_word.group(1),) if first_word else ())
        fallback: str | None = None
        for text in dict.fromkeys(queries):
            for anime_id, anilist, title in self._search(text):
                if anilist_id:
                    if anilist == anilist_id:
                        fflog(f'matched by AniList id {anilist_id}: {anime_id} {title!r}')
                        return anime_id
                    skip(self, f'AniList id {anilist} != {anilist_id}', title=title)
                elif fallback is None and kitsu_api.normalize_series_title(title) == wanted:
                    fallback = anime_id
        if fallback:
            fflog(f'matched by title: {fallback}')
        else:
            fflog(f'no match of {cour["title"]!r} (AniList {anilist_id})')
        return fallback

    def _source(self, link: str, host: str, quality: str, group: str, anime_id: str, episode: int) -> SourceItem | None:
        if not link.startswith('http'):
            skip(self, 'not an embed link', hosting=host, url=link)
            return None
        dubbing = 'dubbing' in group.lower()
        # The group fact (subtitles or dubbing) goes to the facts, the sources window writes it itself
        source_item: SourceItem = {
            'url': link,
            'hosting': host,
            'quality': quality or 'SD',
            'language': 'pl',
            'info': '',
            'filename': f'makisubs {anime_id} {episode}',
            'direct': False,
            'debridonly': False,
            'premium': False,
        }
        if dubbing:
            source_item['audio'] = [{'lang': 'pl', 'kind': TrackKind.DUBBING}]
        else:
            source_item['subtitles'] = [{'lang': 'pl'}]
        return source_item
