"""
FanFilm const (low-level developper) settings.
Do NOT change if you don't know what you doing.

Avoid imports here, please.
Supports `local.py` from plugin userdata folder. File is created if missing.

You can override settings in `local.py`.
Just in the same form as in section "CONST SETTINGS",
>>> const.name = value


Define new setting
------------------

To create new const settings (ex. `const.a.b.c` as `int`) you have to:
 - define the settings
 - assing the value

Define new settings in `class const` structure in "CONST DEFINITION" section.
Every section (ex. `a.b.`) must be a class with `@constdef` decorator.
The name after the last dot (ex. `c`) have to be defined as a class variable with a type annotations.
DO NOT assign default value here.
>>> @constdef
>>> class const:
>>>    @constdef
>>>    class a:
>>>        @constdef
>>>        class b:
>>>            c: int

And just assign values in following "CONST SETTINGS" section.
>>> const.a.b.c = value

Every value `const.x.y = value` must be defined in `class const` structure.
Every value defined settings in `class const` structure must be assigned.


Use const settings
------------------

And use in source code.
>>> from const import const
>>> if const.a.b.c == value: ...
"""

# Only safe imports here, double check BEFORE add something new.
from __future__ import annotations
import lib as _  # to avoid "imported but unused" for lib in type hints, lib/__init__.py have to be imported first to add extra paths
import builtins
import runpy
import re
from pathlib import Path
from threading import Lock
from types import ModuleType
from enum import Enum, IntEnum, Flag, IntFlag, auto as auto_enum
from typing import Optional, Union, Any, Collection, Iterable, Iterator, Sequence, Mapping, TypeVar, overload, TYPE_CHECKING
from typing_extensions import Literal, Self, TypeIs, Generic, get_args as get_typing_args, TypedDict, NotRequired
from attrs import frozen, field
from frozendict import frozendict
from lib.indexers.defs import DirItemSource, CodeId
from lib.kolang import L  # noqa: 401
from lib.sdk.protocol import PlayMode  # noqa: F401, how to play the video (declared in the protocol of the SDK)
if TYPE_CHECKING:
    from typing_extensions import TypeAlias, ClassVar
    from datetime import timedelta
    from simpleeval import SimpleEval
    from lib.defs import MediaRef, RefType
    from lib.ff.item import FFItem
    from lib.ff.menu import ContentView
    from lib.ff.lists import AddToServiceDefs  # noqa: F401
    from lib.sources import SourceXMeta, SourceItemPattern
    from lib.api.trakt import SortType as TraktSortType, SortBy as TraktSortBy
    from lib.windows.add_to import AddToDialogMediaBarMode

T = TypeVar('T')

#: ID of source color match: PROVIDER or (PROVIDER, SOURCE).
ExSourceId: TypeAlias = 'str | tuple[str, str]'
#: Supported prgramt Tv services.
ProgramTvService: TypeAlias = Literal['filmweb', 'onet', 'teleman']
#: Services of trending media ("People Watching").
TrendingService: TypeAlias = Literal['tmdb', 'trakt', 'wetrakr']
#: The activity of a provider add-on without a choice of the user: `never` - inactive (enabled consciously), `ours` - inactive
#: but ours (`const.sources.xproviders.ours`) active, `always` - active.
XProviderActivity: TypeAlias = Literal['never', 'ours', 'always']
#: An operation of a key of a tree: `toggle` - check / uncheck the branch of the row, `up` / `down` - the previous / next
#: node of the level of the row (a leaf: of its parent), around, `filter` - the filter field of the tree (a tree with one).
TreeKey: TypeAlias = Literal['toggle', 'up', 'down', 'filter']
#: SQLite `PRAGMA synchronous` level of a WAL database (commit durability).
DbSynchronous: TypeAlias = Literal['OFF', 'NORMAL', 'FULL', 'EXTRA']
#: External source ID (name).
ExtSourceId: TypeAlias = str

#: Minute in seconds.
MINUTE = 60
#: Hour in seconds.
HOUR = 60 * MINUTE
#: Day in seconds.
DAY = 24 * HOUR
#: Week in seconds.
WEEK = 7 * DAY

#: KiB in bytes.
KiB = 1024
#: MiB in bytes.
MiB = 1024 * KiB
#: GiB in bytes.
GiB = 1024 * MiB
#: TiB in bytes.
TiB = 1024 * GiB


def constdef(cls: type[T]) -> T:
    """Const section definition decorator."""

    def __init__(self) -> None:
        cls = type(self)
        ann = getattr(cls, '__annotations__', {})
        for k, v in vars(cls).items():
            if not k.startswith('_'):
                if getattr(v, '_const_def', None):
                    object.__setattr__(self, k, v)
                elif k in ann:
                    name = f'{cls.__qualname__}.{k}'
                    raise TypeError(f'Value for {name!r} is FORBIDEN, assign it in "CONST SETTINGS"')
                else:
                    raise TypeError(f'Pure class {k!r} in {cls.__qualname__!r} is FORBIDDEN, use @constdef')

    def __setattr__(self, key: str, value: Any) -> None:
        if not key.startswith('_'):
            cls = self.__class__
            load: _Load | None = self.__dict__.get('_load')
            if key not in getattr(cls, '__annotations__', {}) and _obsolete_use(load, (*_section_keys(self), key)):
                return  # a withdrawn key (`local.py`): ignored
            if isinstance(value, ConstRef) and _obsolete_use(load, value._keys):
                return  # a reference to a withdrawn key (`local.py`): the key keeps its value
            if isinstance(value, ConstRef) and getattr(section := getattr(self, key, None), '_const_def', None):
                # a whole section linked: each key of the section gets its own reference (so a key can be set alone later)
                for name in getattr(type(section), '__annotations__', {}):
                    setattr(section, name, getattr(value, name))
                return
            if key not in getattr(cls, '__annotations__', {}):
                raise AttributeError(f'No const attribute {cls.__qualname__}.{key}')
            if load is None and getattr(constdef, '_locked', False) and (old := getattr(self, key, ...)) is not ...:
                print(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
                raise RuntimeError(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
            settings: dict[str, SettingsDescriptor] = self.__dict__.setdefault('_settings', {})
            if isinstance(value, SettingsDescriptor):
                if not isinstance(vars(cls).get(key), _SettingSlot):
                    type.__setattr__(cls, key, _SettingSlot(key))  # the class is common to the trees: the expression is of the section
                self.__dict__.pop(key, None)
                settings[key] = value
                return
            settings.pop(key, None)
        object.__setattr__(self, key, value)

    def __getattr__(self, key: str) -> Any:
        """Only a missing attribute: a withdrawn section read in `local.py` is a sink (its assignments are ignored), else an error."""
        load: _Load | None = self.__dict__.get('_load')
        if not key.startswith('_') and load is not None and load.path and _obsolete_section(keys := (*_section_keys(self), key)):
            return _ObsoleteSection(load, keys)
        raise AttributeError(f'No const attribute {self.__class__.__qualname__}.{key}')

    def __repr__(self) -> str:
        return f'<{self.__class__.__qualname__}>'

    cls.__init__ = __init__
    cls.__setattr__ = __setattr__
    cls.__getattr__ = __getattr__
    cls.__repr__ = __repr__
    cls._const_def = True  # type: ignore
    return cls()


def SETTING(expr: str | bool | None) -> Any:  # Must be `Any` to allow assignment in `const` class.
    """Mark setting to be evaluated."""
    return SettingsDescriptor(expr)  # type: ignore[return-value]


all_languages = (
    'aa', 'ab', 'ae', 'af', 'ak', 'am', 'an', 'ar', 'as', 'av', 'ay', 'az', 'ba', 'be', 'bg', 'bi', 'bm', 'bn', 'bo',
    'br', 'bs', 'ca', 'ce', 'ch', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cy', 'da', 'de', 'dv', 'dz', 'ee', 'el', 'en',
    'eo', 'es', 'et', 'eu', 'fa', 'ff', 'fi', 'fj', 'fo', 'fr', 'fy', 'ga', 'gd', 'gl', 'gn', 'gu', 'gv', 'ha', 'he',
    'hi', 'ho', 'hr', 'ht', 'hu', 'hy', 'hz', 'ia', 'id', 'ie', 'ig', 'ii', 'ik', 'io', 'is', 'it', 'iu', 'ja', 'jv',
    'ka', 'kg', 'ki', 'kj', 'kk', 'kl', 'km', 'kn', 'ko', 'kr', 'ks', 'ku', 'kv', 'kw', 'ky', 'la', 'lb', 'lg', 'li',
    'ln', 'lo', 'lt', 'lu', 'lv', 'mg', 'mh', 'mi', 'mk', 'ml', 'mn', 'mo', 'mr', 'ms', 'mt', 'my', 'na', 'nb', 'nd',
    'ne', 'ng', 'nl', 'nn', 'no', 'nr', 'nv', 'ny', 'oc', 'oj', 'om', 'or', 'os', 'pa', 'pi', 'pl', 'ps', 'pt', 'qu',
    'rm', 'rn', 'ro', 'ru', 'rw', 'sa', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sk', 'sl', 'sm', 'sn', 'so', 'sq', 'sr',
    'ss', 'st', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'ti', 'tk', 'tl', 'tn', 'to', 'tr', 'ts', 'tt', 'tw', 'ty',
    'ug', 'uk', 'ur', 'uz', 've', 'vi', 'vo', 'wa', 'wo', 'xh', 'xx', 'yi', 'yo', 'za', 'zh', 'zu',
)


if TYPE_CHECKING:
    _LikeStringCompare = str  # to hit type check with str
    _AnyTypeBase = Any
else:
    _LikeStringCompare = object
    _AnyTypeBase = object


class RegEx(_LikeStringCompare):
    """
    Regex comparator.

    Example:
    >>> R('pattern') == 'string'  # True if fullmatch
    """

    rx: re.Pattern[str]

    def __new__(cls, pattern: str, flags: int = 0) -> Self:
        obj = super().__new__(cls)
        obj.rx = re.compile(pattern, flags)
        return obj

    def __eq__(self, other: object) -> bool:
        if isinstance(other, type(self.rx)):
            other = other.pattern
        elif isinstance(other, R):
            other = other.rx.pattern
        return self.rx.fullmatch(str(other)) is not None

    def __hash__(self) -> int:
        return hash(self.rx)

    def __repr__(self) -> str:
        return f'cdefs.{self.__class__.__name__}({self.rx.pattern!r})'


class Glob(RegEx):
    """
    Glob comparator. Uses fnmatch (glob wildcards).
    Flags supported:
    - re.IGNORECASE (case-insensitive matching)

    Example:
    >>> G('pattern*') == 'string'  # True if fullmatch
    """

    def __new__(cls, pattern: str, flags: int = 0) -> Self:
        from fnmatch import translate
        pattern = translate(pattern)
        return super().__new__(cls, pattern, flags)


class Expr(_AnyTypeBase):
    """
    Expression comparator. Evaluates expression with simple-eval and compares result.
    Use '{}' as placeholder for value. The names are these of `settings.eval()` (const, settings, units).

    Example:
    >>> X('1 + 1') == 2  # True
    >>> X('{} > 1)' == 1)  # False
    >>> X('{} > 1)' == 2)  # True
    >>> X('> 1)' == 2)     # True (shortcat for '{} > 1')
    """

    expr: str

    def __new__(cls, expr: str) -> Self:
        obj = super().__new__(cls)
        expr = expr.strip()
        if expr[:1] in '<>=!':  # shortcat for simple comparisons: "<= 1" means "{} <= 1"
            expr = f'{{}} {expr}'
        obj.expr = expr
        return obj

    def __eq__(self, other: object) -> bool:
        ev = self._get_evaluator()
        expr = self.expr.replace('{}', repr(other))
        try:
            return bool(ev.eval(expr))
        except Exception:
            from lib.ff.logs import fflog_exc
            fflog_exc(f'Error evaluating expression {expr!r} for value {other!r}:')
            return False

    def __hash__(self) -> int:
        return hash(self.expr)

    def __repr__(self) -> str:
        return f'cdefs.Expr({self.expr!r})'

    @classmethod
    def _get_evaluator(cls) -> SimpleEval:
        """Return the evaluator of FF expressions (the names of `settings.eval()`, see `SettingsManager.expr_tools()`)."""
        from lib.ff.settings import settings
        return settings.expr_tools()[0]


#: Short alias for RegEx, to use in settings.
R = RegEx
#: Short alias for Expr, to use in settings.
X = Expr


# ----------------------------------------------------------------------------- #
# -----                          ENUM DEFINITIONS                         ----- #
# ----------------------------------------------------------------------------- #


class InfoDetails(Flag):
    """
    How to obtain details for media item. For info (tmdb) request.
    For direct media (movie, show, season, episode, etc.) uses INFO_* flags.
    For sub-requests (get non-direct show, season) uses SHOW_*, SEASON_* and EPISODE_* flags.
    """

    NONE = 0

    # --- Request media details ---

    #: Get only media details in API language (info request).
    INFO_LANG = 0x001
    #: Request media details for English (info request). For episode could be ignored with SKIP_EPISODES, use EPISODE_EN.
    INFO_EN = 0x002
    #: Request media details for original language (info request). For episode could be ignored with SKIP_EPISODES, use EPISODE_ORIG.
    INFO_ORIG = 0x004
    #: Request media main details like 'external_ids', etc. (info request).
    COMMON_DETAILS = 0x008
    #: Request media main details like 'release_dates', 'keywords', 'credits', 'alternative_titles', etc. (info request).
    MEDIA_DETAILS = 0x010
    #: Request media images (info request).
    IMAGES = 0x020
    #: Request media videos (info request).
    VIDEOS = 0x040
    #: Request media translations (info request).
    TRANSLATIONS = 0x080
    #: Request media aggregate credits (info request). Only for TV shows and with DETAILS flag.
    AGGREGATE_CREDITS = 0x100
    #: Request media episode groups (info request). Only for TV shows.
    EPISODE_GROUPS = 0x200
    #: Media facets for discover (genres, languages, countries, companies, networks, keywords) and the video count.
    #: Not a TMDB request: they come with the details (keywords with MEDIA_DETAILS, videos with VIDEOS), the cached node
    #: keeps them; a node cached without this flag (e.g. from a list) is fetched again for it.
    FACETS = 0x400
    #: Base details: COMMON_DETAILS + MEDIA_DETAILS.
    BASE_DETAILS = COMMON_DETAILS | MEDIA_DETAILS
    #: Typical details: INFO_LANG + BASE_DETAILS + IMAGES + VIDEOS + TRANSLATIONS.
    DETAILS = INFO_LANG | BASE_DETAILS | IMAGES | VIDEOS | TRANSLATIONS
    #: Mask for locale/lang flags.
    ALL_LOCALES = INFO_LANG | INFO_EN | INFO_ORIG

    # --- Request show details (sub-request) ---

    #: Do not get show details for season/episode (sub-request).
    NO_SHOW = 0
    #: Request show (with simple seasons) for API language (show sub-request). Simple seasons have no translations, will be in API language.
    SHOW_LANG = 0x001_000
    #: Request show (with simple seasons) for English (show sub-request). Simple seasons have no translations, will be in English.
    SHOW_EN = 0x002_000
    #: Request show (with simple seasons) for original language (show sub-request). Simple seasons have no translations, will be in original language.
    SHOW_ORIG = 0x004_000
    #: Request media main details like 'external_ids', etc. (show sub-request).
    SHOW_COMMON_DETAILS = 0x008_000
    #: Request media main details like 'release_dates', etc. (show sub-request).
    SHOW_MEDIA_DETAILS = 0x010_000
    #: Request media translations (show sub-request).
    SHOW_IMAGES = 0x020_000
    #: Request media images (show sub-request).
    SHOW_VIDEOS = 0x040_000
    #: Request media videos (show sub-request).
    SHOW_TRANSLATIONS = 0x080_000
    #: Request media episode groups (show sub-request).
    SHOW_EPISODE_GROUPS = 0x200_000
    #: Request media aggregate credits (show sub-request). Only for TV shows and with DETAILS flag.
    SHOW_AGGREGATE_CREDITS = 0x100_000
    #: Request media main details like 'external_ids', 'release_dates', etc. (show sub-request).
    SHOW_BASE_DETAILS = SHOW_COMMON_DETAILS | SHOW_MEDIA_DETAILS
    #: Typical details for show sub-request.
    SHOW_DETAILS = SHOW_LANG | SHOW_BASE_DETAILS | SHOW_IMAGES | SHOW_VIDEOS | SHOW_TRANSLATIONS
    #: Get all season details for show request (with all seasons translations), got simple episodes too.
    SHOW_SEASONS = 0x800_000

    SHOW = SHOW_LANG
    _GET_SHOW = SHOW_LANG | SHOW_EN | SHOW_ORIG

    # --- Request season details (sub-request) ---

    #: Do not get show details for episode (sub-request).
    NO_SEASON = 0
    #: Request season (with simple episodes) for API language (season sub-request). Simple episodes have no translations, will be in API language.
    SEASON_LANG = 0x001_000_000
    #: Request season (with simple episodes) for English (season sub-request). Simple episodes have no translations, will be in English.
    SEASON_EN = 0x002_000_000
    #: Request season (with simple episodes) for original language (season sub-request). Simple episodes have no translations, will be in original language.
    SEASON_ORIG = 0x004_000_000
    #: Request media main details like 'external_ids', etc. (season sub-request).
    SEASON_COMMON_DETAILS = 0x008_000_000
    #: Request media main details like 'release_dates', etc. (season sub-request).
    SEASON_MEDIA_DETAILS = 0x010_000_000
    #: Request media translations (season sub-request).
    SEASON_IMAGES = 0x020_000_000
    #: Request media images (season sub-request).
    SEASON_VIDEOS = 0x040_000_000
    #: Request media videos (season sub-request).
    SEASON_TRANSLATIONS = 0x080_000_000
    #: Request media aggregate credits (season sub-request). Only for TV shows and with DETAILS flag.
    SEASON_AGGREGATE_CREDITS = 0x100_000_000
    #: Request media main details like 'external_ids', 'release_dates', etc. (season sub-request).
    SEASON_BASE_DETAILS = SEASON_COMMON_DETAILS | SEASON_MEDIA_DETAILS
    #: Typical details for season sub-request.
    SEASON_DETAILS = SEASON_LANG | SEASON_BASE_DETAILS | SEASON_IMAGES | SEASON_VIDEOS | SEASON_TRANSLATIONS
    # #: Froce to get season details even if optimized request (season request). The season use SEASON_* flags.
    # SEASON_FORCE = 0x400_000_000
    #: The season (requested or of a requested episode) with all its episodes; without it the season node only (ffinfo
    #: cache), TMDB returns a season with its episodes anyway (with EPISODE_EN the season is asked in English too).
    SEASON_EPISODES = 0x800_000_000

    SEASON = SEASON_LANG
    _GET_SEASON = SEASON_LANG | SEASON_EN | SEASON_ORIG

    # --- Request episode details (sub-request) ---

    EPISODE_LANG = 0x001_000_000_000
    EPISODE_EN = 0x002_000_000_000
    EPISODE_ORIG = 0x004_000_000_000

    #: An episode comes from its season (TMDB: no request of the episode, the season one; the episode uses SEASON_* flags),
    #: ffinfo returns the episodes of the full seasons (SEASON_EPISODES, SHOW_SEASONS) too.
    EPISODE_SKIP = 0x800_000_000_000
    SKIP_EPISODES = EPISODE_SKIP


    # --- Global settings ---

    #: Do NOT optimize requests to get minimal data (seasons with show).
    NO_OPTIMIZE = 0x1_000_000_000_000
    SEPARATE_SEASONS = NO_OPTIMIZE

    #: Flag is not defined. Do NOT use it on production code. Used in CLI tests.
    NOT_DEFINED = 0xfff_fff_fff_fff_fff

    #: Get minimal details by default.
    DEFAULT = DETAILS | SHOW_DETAILS | SEASON | SEASON_EPISODES | EPISODE_EN | SKIP_EPISODES

    #: Shift mask for locale/lang flags for show/season/episode sub-requests.
    __SHIFT: int
    #: Mask for locale/lang flags for show/season/episode sub-requests. 0x800 and 0x400 is not shifted.
    __MASK: int
    #: Regex to split string flags in new().
    __RX_SPLIT: re.Pattern[str]

    ITEM_MASK = 0x7ff
    SHOW_MASK = 0x7ff_000
    SEASON_MASK = 0x7ff_000_000
    EPISODE_MASK = 0x7ff_000_000_000
    # ITEM_MASK: InfoDetails
    # SHOW_MASK: InfoDetails
    # SEASON_MASK: InfoDetails
    # EPISODE_MASK: InfoDetails

    @classmethod
    def new(cls, val: InfoDetails | str | int | None, /, *, default: InfoDetails | int = DEFAULT) -> Self:
        """Return InfoDetails from diff string."""
        if not val:
            return cls(default)
        if isinstance(val, str):
            if val.startswith('InfoDetails.'):
                val = val[12:]  # remove 'InfoDetails.' prefix
            flag = cls.NONE
            for i, part in enumerate(cls.__RX_SPLIT.split(val.upper())):
                part = part.strip()
                if not part:
                    continue
                neg = False
                if part.startswith('+'):
                    if not i:  # first part, add to default
                        flag = cls(default)
                    part = part[1:].strip()
                elif part.startswith('-'):
                    part = part[1:].strip()
                    neg = True
                part = part.replace('-', '_')
                try:
                    f = cls[part.strip()]
                except KeyError:
                    try:
                        from lib.ff.logs import fflog
                        fflog.error(f'Unknown InfoDetails flag {part!r}')
                    except Exception:
                        pass
                    raise
                if neg:
                    flag &= ~f
                else:
                    flag |= f
            return flag
        return cls(val)

    def show(self, *, combine: bool = False, seasons: bool = False) -> InfoDetails:
        """Convert SHOW_* flags to INFO_* flags."""
        shift = self.__SHIFT
        flag = self.__class__((self.value >> shift) & self.__MASK)
        if combine:
            flag |= self
        if seasons and (self & self.SHOW_SEASONS):
            flag |= InfoDetails.SHOW_SEASONS
        return flag

    def season(self, *, combine: bool = False) -> InfoDetails:
        """Convert SEASON_* flags to INFO_* flags."""
        shift = self.__SHIFT * 2
        flag = self.__class__((self.value >> shift) & self.__MASK)
        if combine:
            flag |= self
        return flag

    def episode(self, *, combine: bool = False) -> InfoDetails:
        """Convert EPISODE_* flags to INFO_* flags."""
        shift = self.__SHIFT * 3
        flag = self.__class__((self.value >> shift) & self.__MASK)
        if combine:
            flag |= self
        return flag

    def __to_json__(self) -> Any:
        return str(self)


# --- For Python < 3.10 no private attributes can be defined ---

#: Shift mask for locale/lang flags for show/season/episode sub-requests.
InfoDetails._InfoDetails__SHIFT = 12                          # type: ignore[reportAttributeAccessIssue]
#: Mask for locale/lang flags for show/season/episode sub-requests. 0x800 and 0x400 is not shifted.
InfoDetails._InfoDetails__MASK = 0x7ff                        # type: ignore[reportAttributeAccessIssue]
#: Regex to split string flags in new().
InfoDetails._InfoDetails__RX_SPLIT = re.compile(r'[,|]')      # type: ignore[reportAttributeAccessIssue]

# InfoDetails.ITEM_MASK = InfoDetails(InfoDetails._InfoDetails__MASK << (InfoDetails._InfoDetails__SHIFT * 0))     # type: ignore[reportAttributeAccessIssue]
# InfoDetails.SHOW_MASK = InfoDetails(InfoDetails._InfoDetails__MASK << (InfoDetails._InfoDetails__SHIFT * 1))     # type: ignore[reportAttributeAccessIssue]
# InfoDetails.SEASON_MASK = InfoDetails(InfoDetails._InfoDetails__MASK << (InfoDetails._InfoDetails__SHIFT * 2))   # type: ignore[reportAttributeAccessIssue]
# InfoDetails.EPISODE_MASK = InfoDetails(InfoDetails._InfoDetails__MASK << (InfoDetails._InfoDetails__SHIFT * 3))  # type: ignore[reportAttributeAccessIssue]


class PlayCancel(Enum):
    """How to cancel start video playing (a placeholder is played instead of the video)."""

    #: setResolvedUrl(success=False), nothing is played.
    FALSE = 'false'
    #: Use empty.m3u8.
    EMPTY = 'empty'
    #: Use long black video.
    TT430 = 'tt430'
    #: Use data.ts: a short MPEG-TS with a data stream only. Kodi opens no video stream (no refresh rate or full screen
    #: video switch, where a stop could deadlock Kodi), keeps the resume point and ends the play by itself (~0.2 s).
    DATA = 'data'

    @property
    def ends_itself(self) -> bool:
        """True if the placeholder play ends by itself at once: no stop (a stop while Kodi opens it fails the play)."""
        return self is PlayCancel.DATA

    @property
    def path(self) -> str | None:
        """Placeholder file (in resources/), None if nothing is played."""
        return self._placeholder[0]

    @property
    def mime(self) -> str | None:
        """MIME type of the placeholder: Kodi does not guess it for a resolved plugin item (a probed MPEG-TS fails its re-open)."""
        return self._placeholder[1]

    @property
    def _placeholder(self) -> tuple[str | None, str | None]:
        """Placeholder file (in resources/) and its MIME type."""
        return {
            PlayCancel.EMPTY: ('media/empty.m3u8', 'application/vnd.apple.mpegurl'),
            PlayCancel.TT430: ('media/tt430.mp4', 'video/mp4'),
            PlayCancel.DATA: ('media/data.ts', 'video/mp2t'),
        }.get(self, (None, None))


class WidgetsReload(Enum):
    """
    How to reload Kodi widgets after a progress change known only to FF (a mark from the FF menu, an account sync).

    Kodi reloads a widget only on its own events (a player stop, a video library update); FF changes Kodi setting
    `videolibrary.showunwatchedplots` without changing its meaning (a repeated last value added or removed), Kodi
    announces `VideoLibrary.OnRefresh` and reloads the widgets. The member says what to do when the list is empty
    (no change with the same meaning exists).
    """

    #: An empty list: change it and back (two reloads).
    TWICE = 'twice'
    #: An empty list: nothing (no reload).
    NOTHING = 'nothing'
    #: An empty list: an empty video library scan (`OnScanFinished`); not on Kodi 21 with `cleanonupdate` in
    #: advancedsettings.xml (a scan cleans the whole library there).
    SCAN = 'scan'


class StateMode(Enum):
    """Where keep state varibables."""

    #: Use sqlite state.db.
    DB = 'db'
    #: Use local HTTP service.
    SERVICE = 'service'


class MediaWatchedMode(Enum):
    """(Un)watched detection mode."""

    #: Set FFID as fake DBID (Kodi database ID). NOT RECOMENDED.
    FAKE_DBID = 'dbid'
    #: Watch ListItem changes on folder refresh.
    WATCH_LISTITEM = 'listitem'


class StrmFilename(Enum):
    """STRM file name format."""

    # FF2 old file format. Example: My.Brilliant.Friend.S01E07.strm
    DOT = 'dot'
    # Another format. Example: My_Brilliant_Friend.S01E07.strm
    LOW_LINE = 'line'
    # A normal file name without the year. Example: My Brilliant Friend S01E07.strm
    TITLE = 'title'
    # A full file name with the year (FF3 default). Example: My Brilliant Friend (2018) S01E07.strm
    TITLE_YEAR = 'title_year'
    # No title, Kodi only needs SxxEyy to scrape an episode. Example: S01E07.strm
    BARE = 'bare'


#: Supported scrobble services.
ScrobbleService = Literal['trakt']

#: List services without accounts (the rest of list services are accounts, see `lib.ff.accounts`).
LIST_SERVICES_WITHOUT_ACCOUNT: tuple[str, ...] = ('local', 'library', 'logs')
#: List service: an account ID (`trakt`, `trakt.test`, the settings account ID is the type name) or a service
#: without an account (`local`, `library`, `logs`).
ListService: TypeAlias = str
#: Pointer to lists: `<list service>[:<section>]`, e.g. `trakt:watchlist`, `trakt.test:user`, `library`
#: (`local` is a dummy target, no items, do NOT use it as pointer). Pointers of types: `lib.ff.lists.LIST_POINTERS`.
ListPointer: TypeAlias = str

#: Show or not items in context-menu.
#: False – shows never
#: True  – shows always
#: str   - depends on this settgins.eval()
ShowCxtMenu: TypeAlias = 'bool | str'
#: Supported services in CM "Add to...": `local` contains `library` and `own`.
AddToService: TypeAlias = ListService


@frozen
class ListPointerInfo:
    """Info about pointer to list (service and subset like favorites)."""
    #: The pointer string, like 'trakt:favorites'.
    pointer: ListPointer
    #: Group names for all list pointers. Diffrent groups are separated (horizontal line) in Add-to dialog.
    group: str = field(default='', kw_only=True)
    #: When the pointer (service & section) is enabled in Add-to dialog.
    enabled: ShowCxtMenu = field(default=True, kw_only=True)


@frozen
class AddToMenu:
    """Add-to context menu item definition."""

    name: str
    enabled: ShowCxtMenu = True
    service: AddToService | None = None
    list: str | None = None

    def target(self) -> ListTarget | None:
        """Return target list for this menu item."""
        if not self.service:
            return None
        return ListTarget.from_url(service=self.service, list=self.list)


class ListType(IntFlag):
    """Media list types (own and other lists)."""

    LIST = auto_enum()
    MOVIE = auto_enum()
    SHOW = auto_enum()
    SEASON = auto_enum()
    EPISODE = auto_enum()
    COLLECTION = auto_enum()
    PERSON = auto_enum()
    VIDEO = MOVIE | EPISODE
    MAIN = MOVIE | SHOW
    MEDIA = MOVIE | SHOW | SEASON | EPISODE  # | COLLECTION ?
    ALL_MEDIA = MEDIA | COLLECTION
    MIXED = MEDIA | COLLECTION | PERSON
    MOVIE_LIKE = MOVIE | COLLECTION
    SHOW_LIKE = SHOW | SEASON | EPISODE
    ALL = LIST | MOVIE | SHOW | SEASON | EPISODE | COLLECTION | PERSON
    NONE = 0

    def __str__(self) -> str:
        """Return string representation of this type."""
        return str(self.value)
        # if self == ListType.NONE:
        #     return 'none'
        # if self == ListType.ALL:
        #     return 'all'
        # return ', '.join(sorted(f.attr for f in self.iter_single_flags()))

    @property
    def attr(self) -> str:
        """Return attribute name for this type."""
        return (self.name or '').lower()

    def iter_single(self) -> Iterable[ListType]:
        """Return single-bit flags."""
        n = 1
        while n < self.ALL:
            if n & self:
                yield ListType(n)
            n *= 2

    @classmethod
    def iter_single_flags(cls) -> Iterable[ListType]:
        """Return single flags. Old Python iter(IntFlag) return all flags. New Python return single flags."""
        return cls.ALL.iter_single()

    @classmethod
    def new(cls, val: ListType | str | int | None, /, *, default: ListType | int = 0) -> Self:
        """Return OwnListType from diff string."""
        if not val:
            return cls(default)
        if isinstance(val, str):
            if val.isdecimal():
                return cls(int(val))
            from functools import reduce
            from operator import or_
            return reduce(or_, (cls[f.strip()] for f in val.upper().split(',')))
        return cls(val)

    @classmethod
    def from_media_ref(cls, val: MediaRef | RefType, /) -> Self:
        if not isinstance(val, str):
            val = val.type
        try:
            return cls[val.upper()]
        except KeyError:
            return cls(0)


@frozen(kw_only=True)
class ListTarget:
    """Target list for items."""

    service: ListService
    section: str = ''
    list: str = ''
    types: ListType = ListType.ALL

    @classmethod
    def from_pointer(cls, pointer: ListPointer, list: str | None = None, *, types: ListType = ListType.ALL) -> Self:
        """Create ListTarget from pointer and optional list name/id."""
        service: ListService
        service, _, section = pointer.partition(':')  # type: ignore[assignment]
        if list is None:
            section, _, list = section.partition(':')
        return cls(service=service, section=section, list=list or '', types=types)

    @classmethod
    def from_url(cls, service: ListService, list: str | None = None, *, types: ListType = ListType.ALL, default_section: str = 'user') -> Self:
        """Create ListTarget from URL variables."""
        from lib.ff.logs import fflog
        service, sep, section = service.partition(':')
        if not sep and list and list[0] == ':':
            section = list[1:]
            list = ''
        elif list is None:
            default_section = ''  # no section
        if service not in LIST_SERVICES_WITHOUT_ACCOUNT:
            from lib.ff.accounts import get_account
            if get_account(service) is None:
                fflog.warning(f'Unknown service {service!r} in ListTarget.from_url()')
        return cls(service=service, section=section or default_section, list=list or '', types=types)

    @classmethod
    def from_ffitem(cls, item: 'FFItem') -> Self:
        """Create ListTarget from FFItem folder item."""
        service: ListService = item.getProperty('service')  # type: ignore
        section: str = item.getProperty('section')
        list_id: str = item.getProperty('list_id')
        types = ListType.new(item.getProperty('types'), default=ListType.ALL)
        name = item.getLabel()
        return cls(service=service, section=section, list=list_id or str(item.ffid or name), types=types)

    def pointer(self) -> ListPointer:
        """Return pointer string for this target."""
        if self.section:
            return f'{self.service}:{self.section}'  # type: ignore[return-value]
        return self.service  # type: ignore[return-value]


@frozen(kw_only=True)
class ListSection:
    """
    A section of lists of an account type (`AccountClient.LISTS`, the key is the section: `watchlist`, `favorites`,
    `collection`, `user`). The client reads a fixed section by the method of its name and changes it by `set_<section>()`;
    the own lists (`user`) by `user_lists()`, `list_items()`, `set_in_list()`, `create_list()`, `delete_list()`.
    """

    #: Media of the items (of an own list without its `list_type`).
    types: ListType
    #: Options of a new own list (None: lists can not be created).
    create: Mapping[str, bool] | None = None
    #: Media of a new list (the dialog default).
    new_types: ListType = ListType.NONE
    #: Media of a new list the user may change.
    edit_types: ListType = ListType.NONE
    #: Choices of media of a new list (label -> media), e.g. titles / people.
    type_choices: Mapping[str, ListType] = field(factory=dict)


@frozen
class OwnListDef:
    """User own list (custom or built-in like favorites) definition."""

    # List name, should be unique.
    name: str
    #: List content type (type of items), "media" means mixed (movie & show).
    type: ListType = field(converter=ListType.new)
    #: List of item URL / path.
    url: str
    #: List icon (thumb).
    icon: str | None = field(default=None, kw_only=True)
    #: List icon (thumb).
    mixed: bool = field(default=True, kw_only=True)
    #: List label, if not set then name is used.
    label: str = field(default='', kw_only=True)
    #: Translations, name in locale (ex. "pl-PL") / language (ex. "pl").
    translations: Mapping[str, str] = field(factory=dict, kw_only=True)

    @property
    def title(self) -> str:
        """Return list title."""
        return self.label or self.name

    def own_name(self) -> str | None:
        """Return own name for this list."""
        if self.url.startswith('db://own/'):
            return self.url[9:]  # cut 'db://own/' prefix
        return None

    @staticmethod
    def type_match(type: ListType, media: ListType | str | None) -> bool:
        """Return True if list should be visible for given media type."""
        media = ListType.new(media or ListType.MEDIA)
        # if type == 'list':
        #     # list of lists are always avaliable
        #     return True
        # if media == 'list':
        #     # Only list of lists are allowed but this is not.
        #     return False
        # true if any common type
        return bool(type & media)

    def match(self, media: ListType | str | None) -> bool:
        """Return True if list should be visible for given media type."""
        return self.type_match(self.type, media)


class When(Enum):
    """
    When something is done by the number of items, e.g. a group is a folder (`folder: When`): never (its items go
    directly), if there are many items (more than one), always. Also when to show a list name as a role.
    """

    #: Never (a group: its items directly).
    NEVER = 'never'
    #: If there are many items (more than one).
    IF_MANY = 'if_many'
    #: Always.
    ALWAYS = 'always'

    def __call__(self, count: int) -> bool:
        """Return True if it is done for `count` items."""
        return self is When.ALWAYS or (self is When.IF_MANY and count > 1)


#: A level of a menu of lists: the kind of a list (watchlist, history...), the service type, the account.
MenuLevel = Literal['kind', 'type', 'account']
#: A kind of a list of an account (or a general list of a service type, `general`).
ListKind = Literal['watchlist', 'favorites', 'collection', 'history', 'progress', 'upnext', 'calendar', 'recommendations', 'home', 'ratings',
                   'likes', 'mylists', 'general']


class SourceSearchProgressStyle(Enum):
    """How to show progress of source search."""

    #: Simple progress dialog. Mixed sources (no premium/normal distinction).
    SIMPLE = 0
    #: Extended progress dialog with more info. Premium sources in parentheses.
    EXTENDED = 1
    #: Full progress dialog with all info. Separate lines for premium and normal sources.
    FULL = 2


#: Actions for context-menu in sources window. Must include PlayMode.
#: Action 'play' means auto-action (direct or isa).
SourceAction = Literal['direct', 'isa', 'play', 'buy']
#: Kind of a way FanFilm opens a source (its resolvability): the provider account, a direct link, a Kodi plugin, a debrid
#: service, a FanFilm resolver, a ResolveURL (host) resolver, the provider itself (its `resolve()` gives a link no resolver
#: knows, played as it is).
ResolveKind: TypeAlias = Literal['account', 'direct', 'plugin', 'debrid', 'ff', 'resolveurl', 'provider']
#: What the sources window does with a source no way can open: grey it out (at the list end), hide it, show it as others.
UnresolvablePolicy: TypeAlias = Literal['grey', 'hide', 'show']
#: Kind of a torrent pack source: a whole season, a whole show (the file of the episode is chosen when it is opened).
PackKind: TypeAlias = Literal['season', 'show']


@frozen(kw_only=True)
class ProviderSection:
    """A section of a group of the native providers in the tab of the source providers (a level of the tree)."""

    #: The key of the section in its group (its node of the tree: the color and the priority of its sources, kept).
    key: str
    #: The label of the section.
    label: str
    #: Its providers (their names); the first section of a group has also every provider of the group in no section.
    members: Sequence[str] = ()


@frozen(kw_only=True)
class ProviderGroup:
    """
    A group of the native providers by its members (not by their folder), after the folder groups; a provider of the
    group name is the group itself (its settings are of the group node, its sub-sources are leaves of the group).
    """

    #: The label of the group.
    label: str
    #: Its providers (their names), out of their folder groups.
    members: Sequence[str]


def is_play_mode(obj: object) -> TypeIs[PlayMode]:
    """Type guard for PlayMode."""
    return obj in get_typing_args(PlayMode)


def freeze_pattern(pattern: Any) -> Any:
    """Return the pattern of a selector frozen, nested (hashable: a key of the rules): a mapping a frozendict, a list a tuple, a set a frozenset."""
    if isinstance(pattern, Mapping):
        return frozendict({key: freeze_pattern(value) for key, value in pattern.items()})
    if isinstance(pattern, list):
        return tuple(freeze_pattern(value) for value in pattern)
    if isinstance(pattern, set):
        return frozenset(pattern)
    return pattern


def _make_pattern(pattern: Mapping[str, Any] | None) -> Any:
    """Make a pattern of a selector field (a mapping, nested) frozen, None: no condition."""
    return None if pattern is None else freeze_pattern(pattern)


def match_value(value: Any, pattern: Any) -> bool:
    """
    Return True if the value matches the pattern of a selector (`SourceSelector`): None - any value; a list / tuple value -
    one of its elements; a mapping - a mapping by its keys or an object by its attributes / properties, every key of the
    pattern (nested; a missing one is None); a value, `RegEx`, `Glob`, `Expr` - equal; another collection - one of it.
    """
    if pattern is None:
        return True
    if isinstance(value, (list, tuple)):
        return any(match_value(item, pattern) for item in value)
    if isinstance(pattern, Mapping):
        if value is None:
            return False
        if isinstance(value, Mapping):
            return all(match_value(value.get(key), pat) for key, pat in pattern.items())
        return all(match_value(getattr(value, key, None), pat) for key, pat in pattern.items())
    if isinstance(pattern, (str, int, float, RegEx, Expr)):
        return pattern == value
    try:
        return value in pattern
    except TypeError:  # an unhashable value in a set...
        return False


@frozen(kw_only=True)
class AddonSelector:
    """Match the providers' addon. Empty means doesn't matter."""

    #: Video providers name addon name (alien addon with it's own providers). None means doesn't matter. Empty means the FanFilms addon itself.
    addon: str | None = None

    def has_addon_condition(self) -> bool:
        """Return True if any addon condition is set."""
        return bool(self.addon is not None)

    def has_condition(self) -> bool:
        """Return True if any condition is set."""
        return self.has_addon_condition()


@frozen(kw_only=True)
class ProviderSelector(AddonSelector):
    """Match the provider. Empty means doesn't matter."""

    #: Video provider name (scraper module).
    provider: str = ''
    #: Kodi / system platform name, like "windows", "linux", "android", etc.
    platform: str | Collection[str] | None = None
    #: Kodi minimal version (if int) or Kodi version range/set.
    #: Example (21,22) or the same as range(21,23).
    #: Remember: range() uses start, stop not min, max.
    kodi: int | Collection[int] | RegEx | Expr | None = None

    def has_provider_condition(self) -> bool:
        """Return True if any provider condition is set."""
        return bool(self.provider or self.platform or self.kodi)

    def has_condition(self) -> bool:
        """Return True if any condition is set."""
        return super().has_condition() or self.has_provider_condition()


@frozen(kw_only=True)
class SourceSelector(ProviderSelector):
    """Match the source (and its provider etc.) in the rule. Empty means doesn't matter."""

    #: Video hosting, "source" from sources item list.
    hosting: str = ''  # "source" from sources item list
    #: Setting name (bool) or setting condition.
    setting: str | None = None
    #: Is source m3u8.
    m3u8: bool | None = None
    #: Only premium sources (`Source.rule_premium`: meta['premium'], a torrent cached on a debrid).
    premium: bool | None = None
    #: Meta (provider source data), a pattern (`match_value()`, nested). For keys see SourceItemPattern (lib/sources/__init__.py).
    meta: SourceItemPattern | None = field(default=None, converter=_make_pattern)
    #: Source size (in bytes) parsed from meta['size']. Approximated if meta['size'] is a string like "1 GB".
    size: int | RegEx | Expr | None = None
    #: Real media type (movie, show, season, episode) for this source.
    media: RefType | None = None
    #: The ways to open the source (`Resolvability`: `routes`, `best`, `cached` - True / False / None, `debrid`), a pattern of
    #: its attributes (`match_value()`, nested), e.g. `{'cached': False}`: a torrent no debrid has cached.
    resolvability: Mapping[str, Any] | None = field(default=None, converter=_make_pattern)
    #: The facts of the source (`Source.facts`: `video`, `audio`, `subtitles`, `release`; given by the provider and parsed), a
    #: pattern (`match_value()`, nested; a list: one of its items), e.g. `{'audio': {'lang': 'pl'}}`.
    facts: Mapping[str, Any] | None = field(default=None, converter=_make_pattern)

    def has_source_condition(self) -> bool:
        """Return True if any source condition is set."""
        return bool(self.hosting or self.m3u8 is not None or self.setting or self.premium is not None or self.meta or self.size is not None
                    or self.resolvability or self.facts)

    def has_condition(self) -> bool:
        """Return True if any condition is set."""
        return super().has_condition() or self.has_source_condition()


# TODO: remove - it is DEPRECATED, use SourceSelector instead.
@frozen(kw_only=True)
class SourcePattern(SourceSelector):

    def __init__(self, **kwargs: Any):
        """DEPRECATED, use SourceSelector instead."""
        from lib.ff.logs import log
        log.warning('SourcePattern is DEPRECATED, use SourceSelector instead.')
        super().__init__(**kwargs)


#: The kind of a badge of a source (`SourceAttributeBadge.type`).
BadgeKind: TypeAlias = Literal['icon', 'ribbon', 'line', 'bar', 'number', 'text']
#: The place of a badge in a part of a row (`SourceAttributeBadge.place`): a corner, the middle of a side, the centre (a sticker), a line
#: across the middle - horizontal H, vertical V.
BadgePlace: TypeAlias = Literal['NW', 'NE', 'SW', 'SE', 'N', 'S', 'W', 'E', 'C', 'H', 'V']
#: The look of a line badge (`SourceAttributeBadge.style`, as Qt `QFrame.Shadow`): a plain line in its colour, an engraved one (sunken:
#: a dark half then a light one, raised: the other way round; no colour).
LineStyle: TypeAlias = Literal['plain', 'sunken', 'raised']
#: The part of a row of a badge (`SourceAttributeBadge.panel`): the whole item, the left / the right part, their joint.
BadgePanel: TypeAlias = Literal['left', 'right', 'item', 'split']
#: The part of a row of a badge slot (`BadgeSlot.part`): a part of `SourceAttributeBadge.panel`, over_icon the icons over the item icon.
BadgePart: TypeAlias = Literal['item', 'left', 'right', 'split', 'over_icon']
#: The colour mode of a source item: the colour of the provider as the background of the item, as its accent (a bar and its name).
SourceItemColorMode: TypeAlias = Literal['background', 'accent']


class SourceAttributeBadge(TypedDict):
    """
    Definition of badge to add to source item.

    The slots of a row: `BADGE_SLOTS` (below) - the badges of one place by their `order` one by one from the corner / the side (a badge
    of its `slot`: that one), a badge past the slots of its place (its slot taken) is not shown.

    One badge of a kind, a panel, a place, an order and `over_item_icon` (a later rule replaces it). The icons NE, E and SE (NW, W, SW) of
    a panel lie in one column: three icons (50 px each) in a row (108 px) overlap - a rule using all three accepts it.

    The text tag in the top right corner of the whole item (one, NE) shows the way which opens the source: "PREMIUM" (an account), the
    name of the debrid; a text badge of a rule replaces it (its `text`; none: not shown). The tag moves the badges of the corner (the
    icons NE of the right part, the number NE) left by its width, it lies beside the item icon; the ribbons NE lie over it.

    The constant badges of a colour mode (`const.sources_dialog.const_badges`, e.g. the bar of the colour of the provider and the separator
    of the parts while it is a bar and its name) come after the badges of the rules (their `order` by default): a badge of a rule in their
    place takes its slot first.

    The part `split` is the joint of the left and the right part (its middle on their boundary, `metric.mark.split` wide): its stickers
    C, N, S (ordinary ones, over both parts) over the texts, its vertical lines V (as wide as the part; the slot 1 the whole height, 2
    shorter) under them - the separator of the parts. A line H crosses the middle of a part horizontally.
    """

    #: Badge type. "icon" is a simple icon (thumb) on the corner of item. "ribbon" is a ribbon on the corner of item. "line" is an underline under item.
    #: Number is a badge with number in it. "text" is the text tag in the top right corner of the whole item. Default is "icon".
    #: "icon" and "ribbon" use `panel and `place`, "line" uses `panel` only, "number" uses `place` (of whole item), "text" neither.
    type: NotRequired[BadgeKind]
    #: Badge icon (thumb).
    icon: NotRequired[str | None]
    #: Icon texture border slice (or "left,top,right,bottom" string) in pixels. Default is 0 (no border).
    icon_border: NotRequired[int | str]
    #: Icon border margin (or "left,top,right,bottom" string) in pixels. Default is 0 (no border).
    icon_bordersize: NotRequired[int | str]
    #: Badge color. Default is no color diffuse.
    color: NotRequired[str | None]
    #: Badge place on source item panel. "left", "right", "item" or "split" (the joint of the left and the right part).
    panel: NotRequired[BadgePanel | None]
    #: Badge corner place.
    place: NotRequired[BadgePlace]
    #: Badge order in corner (if many badges in the same corner). Bigger value is more outside.
    order: NotRequired[int]
    #: The slot of its place (1, 2 ...): that one if it is free (taken by a badge of a smaller `order`: not shown), else the first free one.
    slot: NotRequired[int]
    #: Badge icon on item icon is allowed.
    over_item_icon: NotRequired[bool]
    # --- number only ---
    #: Number to show in badge. Default is 0.
    number: NotRequired[int]
    #: Format string for number, like "{number} GB" or "{number}%".
    number_format: NotRequired[str]
    #: Source meta key to get number from. Default is direct number (from `number` field).
    number_source: NotRequired[Literal['', 'index', 'size'] | None]
    # --- text only ---
    #: The text of the tag in the top right corner of the item (instead of the way which opens the source); none: the badge not shown.
    text: NotRequired[str]
    # --- line only ---
    #: The look of the line: "plain" a line in its colour (default), "sunken" / "raised" an engraved one - the image of its part and place
    #: `line.<style>.<part>.<place>`, else of its side `line.<style>.<w|e|n|s>`, else of its direction `line.<style>.<v|h>` (`find_badge()`:
    #: a dark and a light half over any surface, no colour).
    style: NotRequired[LineStyle]


@frozen
class BadgeSlot:
    """
    A slot of a badge in a row of the sources window (a tag / an edge mark of the template `source_dialog.xml`): the slot `n` of a
    place of a part (the badges of one place by their `order`, one by one from the corner / the side).
    """

    #: The part of the row (`SourceAttributeBadge.panel`), over_icon: the icons `over_item_icon` of the right part over the item
    #: icon (with the item icon the other icons of the right part lie beside it).
    part: BadgePart
    #: The kind of the badges (`SourceAttributeBadge.type`).
    kind: BadgeKind
    #: The place of the badges in the part (`SourceAttributeBadge.place`).
    place: BadgePlace
    #: The slot of the place (1, 2 ...).
    n: int = 1

    @property
    def name(self) -> str:
        """Return the name of the slot: its use in the template, the key of its data (`SourceDialog.badge_tags()`)."""
        return f'{self.kind}_{self.part}_{self.place.lower()}_{self.n}'


def badge_slots(part: BadgePart, kind: BadgeKind, places: str, count: int = 1) -> tuple[BadgeSlot, ...]:
    """Return the slots of the badges of a kind in the places of a part (`'NW NE'`), `count` slots of each place."""
    return tuple(BadgeSlot(part, kind, place, n) for place in places.split() for n in range(1, count + 1))  # type: ignore[arg-type]


#: The slots of a row of the sources window (`SourceAttributeBadge`; the template places the slots of a kind of a part).
BADGE_SLOTS: tuple[BadgeSlot, ...] = (
    *badge_slots('item',      'bar',    'N S W E'),
    *badge_slots('item',      'line',   'N S'),
    *badge_slots('item',      'ribbon', 'NW NE SE SW'),
    *badge_slots('item',      'number', 'NW NE'),
    *badge_slots('item',      'text',   'NE'),
    *badge_slots('left',      'bar',    'N S W E'),
    *badge_slots('left',      'line',   'N S W E H'),
    *badge_slots('left',      'ribbon', 'NW NE SE SW'),
    *badge_slots('left',      'icon',   'NW NE SE SW', 2),
    *badge_slots('left',      'icon',   'W E'),
    *badge_slots('right',     'bar',    'N S W E'),
    *badge_slots('right',     'line',   'N S', 2),
    *badge_slots('right',     'line',   'H W E'),
    *badge_slots('right',     'ribbon', 'NW NE SE SW'),
    *badge_slots('right',     'icon',   'NE SE', 5),
    *badge_slots('right',     'icon',   'E'),
    *badge_slots('over_icon', 'icon',   'NE SE', 2),
    *badge_slots('over_icon', 'icon',   'E'),
    *badge_slots('split',     'icon',   'C N S'),
    *badge_slots('split',     'line',   'V', 2),
)


@frozen(kw_only=True)
class SourceAttributeBadgeKey:
    """Unique key for source attribute badge."""

    type: BadgeKind
    panel: BadgePanel
    place: BadgePlace
    order: int = 1
    #: The badge over the item icon (its own slots, beside the ones of the badges not over it).
    over_item_icon: bool = False


def source_attribute_badge_key(badge: SourceAttributeBadge) -> SourceAttributeBadgeKey:
    """Return unique badge key."""
    badge_type = badge.get('type')
    if not badge_type:
        if badge.get('number') is not None:
            badge_type = 'number'
        elif badge.get('text') is not None:
            badge_type = 'text'
        elif badge.get('icon'):
            badge_type = 'icon'
        elif badge.get('color'):
            badge_type = 'ribbon'
        else:
            badge_type = 'icon'  # default
    if badge_type == 'text':  # the one tag of the item
        place, panel = 'NE', 'item'
    elif badge_type == 'number':
        place = badge.get('place') or 'NW'
        # panel = badge.get('panel') or ('left' if 'W' in place else 'right')
        panel = badge.get('panel') or 'item'
    elif badge_type == 'ribbon':
        place = badge.get('place') or 'NE'
        panel = badge.get('panel') or ('left' if 'W' in place else 'right')
    elif badge_type == 'line':
        place = badge.get('place') or 'S'
        panel = badge.get('panel') or 'left'
    elif badge_type == 'bar':
        place = badge.get('place') or 'W'
        panel = badge.get('panel') or ('left' if 'W' in place else 'right')
    else:  # icon - default
        place = badge.get('place') or 'NW'
        panel = badge.get('panel') or 'left'
    return SourceAttributeBadgeKey(type=badge_type, panel=panel, place=place, order=badge.get('order', 1),
                                   over_item_icon=bool(badge.get('over_item_icon')))


def _make_badge(badge: bool | str | SourceAttributeBadge | Sequence[str | SourceAttributeBadge] | None) -> Sequence[SourceAttributeBadge] | None:
    """Make badge definition from bool, str, dict or sequence."""
    if not badge:
        return None
    if badge is True:
        return (SourceAttributeBadge(type='icon'),)
    if isinstance(badge, str):
        return (SourceAttributeBadge(type='icon', icon=badge),)
    if not isinstance(badge, Sequence):
        badge = [badge]
    return tuple(SourceAttributeBadge(type='icon', icon=b) if isinstance(b, str) else b for b in badge)


@frozen(kw_only=True)
class SourceAttribute:
    """Source attribute (what to set in this source) for matched rule."""

    #: Override source color in sources dialog (forced: over the color of the tree of the source providers).
    #: Color is in AARRGGBB format (alpha could not be omitted).
    color: str | None = None
    #: The color of the source if no node of its branch in the tree of the source providers has one (AARRGGBB).
    default_color: str | None = None
    #: Addon bar color, ad AARRGGBB format (alpha could not be omitted).
    #: float (0.0..1.0) is alpha blend, inf 1..255 is alpha override, False is no color.
    addon_color: str | int | float | Literal[False] | None = None
    #: The priority of the source (0-10, bigger first) if no node of its branch in the tree of the source providers has one.
    default_priority: int | None = None
    #: Override source order in sources dialog (forced: the whole order, not the priority of the tree).
    #: By default is from the provider priority (the tree of the source providers).
    #: Bigger value are more important:
    #: +2001..+2006:  download, local, plex, jellyfin, external
    #: +1000:         account (already bought, in library, etc.)
    #: 0..999:        providers
    order: int | None = None
    #: Play mode.
    play: PlayMode | None = None
    #: Context menu.
    menu: Sequence[SourceAction] | None = None
    #: Override source item meta dict.
    meta: SourceItemPattern | None = None
    #: Define extra source item badge (one or more).
    badge: Sequence[SourceAttributeBadge] | None = field(default=None, converter=_make_badge)
    #: Stop processing next rules if this rule is applied. Use it to set final attributes for source.
    final: bool = False


#: Value of const.sources.rules: attribute or False if source item should be ignored (not shown in sources dialog).
SourceRuleValue: TypeAlias = 'SourceAttribute | Literal[False]'


#: Names of supported ratings services.
RatingServiceName = Literal['tmdb', 'trakt', 'mdblist', 'imdb', 'wetrakr', 'floppy']
#: The looks of the ratings dialog (`const.dialog.ratings.style`).
RatingsStyle = Literal['triple', 'lines', 'stars']
#: Names of rate actions.
RatingAction = Literal['context_menu', 'watched_movie', 'watched_episode', 'get']


# ----------------------------------------------------------------------------- #
# -----                          CONST DEFINITION                         ----- #
# ----------------------------------------------------------------------------- #


@constdef
class const:
    """Const (low-level developper) settings."""

    @constdef
    class debug:
        enabled: bool
        tty: bool
        crash_menu: bool
        restart_menu: bool
        dev_menu: bool
        autoreload: bool
        autoreload_quiet: float
        service_notifications: bool
        log_xsleep_jitter: float
        log_folders: bool
        add_to_logs: bool
        log_exception: bool
        log_gui: bool
        log_http: bool
        log_tune: str
        logging: dict[str, Any]

    @constdef
    class debugger:
        enabled: bool

    @constdef
    class dev:

        @constdef
        class imdb:
            api_page_size: int

        @constdef
        class tmdb:
            api_key: str | None
            session_id: str | None

            @constdef
            class v4:
                bearer: str | None
                access_token: str | None

        @constdef
        class trakt:
            client: str | None
            secret: str | None

        @constdef
        class mdblist:
            api_key: str | None

        @constdef
        class db:
            echo: bool
            backup: bool

        @constdef
        class sources:
            prepend_fake_items: Sequence[SourceXMeta]
            append_fake_items: Sequence[SourceXMeta]
            log_exception: bool
            force_all_sources: bool

        @constdef
        class kodidb:
            ver: str | None
            number_or_log_lines: int

        @constdef
        class inspector:
            enabled: bool
            host: str
            port: int
            token: str | None
            key: int | None

        @constdef
        class outline:
            enabled: bool
            labels: bool
            key: int | None

    @constdef
    class global_defs:
        country_language: dict[str, str]

    @constdef
    class core:
        const_reload: bool
        gc_every_nth: int
        exit_every_nth: int
        widgets_exit_every_nth: int | None
        widgets_reload: WidgetsReload | None
        volatile_ffid: bool
        volatile_seasons: bool
        media_watched_mode: MediaWatchedMode

        @constdef
        class kodidb:
            advanced_settings: bool

        @constdef
        class info:
            save_cache: bool
            copy_year: bool

    @constdef
    class media:
        aliases_service: Literal['tmdb', 'trakt']
        info_details: InfoDetails | str | None

        @constdef
        class progress:
            as_watched: int
            merge: Literal['union', 'first']
            removals: bool

            @constdef
            class tolerance:
                resume: float
                time: int

        @constdef
        class cache:
            ttl: Sequence[tuple[int | None, str | int]]
            vigilance_frac: float
            vigilance_min: str | int
            returning_poll: str | int
            cleanup_grace: int

        @constdef
        class ids:
            missing_ttl: int
            tmdb_changes: bool
            tmdb_changes_interval: int
            expire_changed: bool

    @constdef
    class lists:

        @constdef
        class cache:
            ttl: str | int
            fingerprint_ttl: int
            limit: int
            cleanup_grace: int
            general: dict[str, str | int]
            page_limit: int

    @constdef
    class sources_dialog:
        show_empty: bool

        @constdef
        class filters:
            overlap: int
            scale: float
            refresh_interval: float

        rescan_edit: bool
        rescan_guard: float
        time_progress: bool
        external_quality_label: dict[ExtSourceId, str]
        language_type_priority: dict[str, int]
        disabled_hosts: set[str]
        cda_drm: bool
        movie_title_format: str
        episode_title_format: str
        episode_group_title_format: str
        episode_poster: Literal['episode', 'season', 'show']
        tag_uppercase: bool
        const_badges: dict[SourceItemColorMode | Literal['*'], dict[str, SourceAttributeBadge | None]]
        badge_spare_slots: int

        @constdef
        class searching:
            progress_style: SourceSearchProgressStyle

        @constdef
        class row_contrast:
            minimum: float
            gain: float

        @constdef
        class edit_search:
            in_menu: bool
            in_dialog: bool
            in_filters: bool
            cache: set[str] | None
            show_granularity: Literal['show', 'season', 'episode']

    # ----- Folders -----
    @constdef
    class folder:
        cache_to_disc: bool
        lock_wait_timeout: float
        refresh_delay: float
        max_scan_step_interval: float
        db_save: bool
        script_autorefresh: bool
        previous_page: Literal['never', 'always', 'on_last_page']
        max_page_jump: int
        fanart_fallback: Literal['landscape', 'poster', 'thumb', 'banner', 'clearlogo'] | None
        category: int
        category_by_skin: dict[str, int]
        separator_label: str
        role_date_format: str

        @constdef
        class style:
            future: str | None
            role: str | None
            broken: str | None
            list_entry: str | None
            section_label: str | None
            top: str | None
            bottom: str | None
            separator: str | None

    # ----- Indexes -----
    @constdef
    class indexer:
        region: str
        lists_view: ContentView
        my_lists_view: ContentView
        empty_folder_message: bool | str
        page_size: int
        add_to_limit: int
        trending_scan_limit: int
        default_alone_view: dict[RefType | Literal['MIXED'], ContentView]
        default_mixed_view: ContentView

        @constdef
        class art:
            fake_thumb: bool

        @constdef
        class progressbar:
            style: str
            mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
            width: int

            @constdef
            class fill:
                color: str
                char: str

            @constdef
            class partial:
                color: str
                char: str

            @constdef
            class empty:
                color: str
                char: str

            @constdef
            class watched:
                color: str
                char: str

        @constdef
        class no_content:
            show_item: bool
            notification: bool
            script_notification: bool

        @constdef
        class search:
            view: ContentView
            clear_if_sure: bool
            year_dialog: Literal['never', 'context-menu', 'entry', 'always']
            year_pattern: str
            query_option_format: str
            multi_search: bool
            limit: int
            ext_history: bool

        @constdef
        class context_menu:
            add_to: Sequence[AddToMenu]

        # -- Directories: movies
        @constdef
        class movies:
            region: str
            discover_sort_by: Sequence[Literal['original_title.asc', 'original_title.desc',  # list in setting `movies.sort` order
                                               'popularity.asc', 'popularity.desc',
                                               'revenue.asc', 'revenue.desc',
                                               'primary_release_date.asc', 'primary_release_date.desc',
                                               'title.asc', 'title.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            missing_duration: int
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool
            discovery_scan_limit: int

            @constdef
            class resume:
                page_size: int

            @constdef
            class top_rated:
                votes: int | None

            @constdef
            class genre:
                votes: int | None
                # menu: set[int]

            @constdef
            class year:
                votes: int | None

            @constdef
            class joke:
                production_company: bool
                keyword: bool

            @constdef
            class cinema:
                last_days: int
                next_days: int
                use_region: bool

            @constdef
            class tv:
                media_page_size: int
                stub_page_size: int
                service: ProgramTvService | Sequence[ProgramTvService]
                list_mode: Literal['media', 'mixed', 'folders', 'direct', 'direct_or_folder']
                service_view: ContentView
                sort_by: Literal['', 'aired_date', 'title']
                day_range: range
                channels: Sequence[str] | None
                day_first_hour: int

                @constdef
                class filmweb:
                    show_non_id: bool
                    skip_items: Collection[str] | None

                @constdef
                class onet:
                    channel_page_count: int
                    channel_worker_count: int | None
                    more_details: bool

                @constdef
                class teleman:
                    pages_to_scan: int

            @constdef
            class new:
                votes: int | None

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
                width: int

            @constdef
            class search:
                year_pattern: str

            @constdef
            class images:
                art_type_folder: bool
                label_format: str | None

        # -- Directories: tv-shows
        @constdef
        class tvshows:
            region: str
            discover_sort_by: Sequence[Literal['first_air_date.asc', 'first_air_date.desc',  # list in setting `tvshows.sort` order
                                               'name.asc', 'name.desc',
                                               'original_name.asc', 'original_name.desc',
                                               'popularity.asc', 'popularity.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            future_if_no_date: bool
            calendar_range: tuple[int, int]
            discovery_scan_limit: int
            season_details: InfoDetails | str | None
            episodes_details: InfoDetails | str | None

            @constdef
            class top_rated:
                votes: int | None

            @constdef
            class genre:
                votes: int | None
                # menu: set[int]

            @constdef
            class year:
                votes: int | None

            @constdef
            class joke:
                production_company: bool

            @constdef
            class premiere:
                votes: int | None

            @constdef
            class progress:
                show: Literal['show', 'season', 'episode']
                next_policy: Literal['last', 'continued', 'first', 'newest']
                episode_folder: bool
                episode_focus: bool
                episode_select: bool
                episode_label_style: str | None
                show_full_watched: bool
                show_watching: bool
                show_details: InfoDetails | str | None
                page_size: int
                warm_pages: int
                service_wait: float

            @constdef
            class search:
                year_pattern: str

        # -- Directories: seasons
        @constdef
        class seasons:
            no_title_labels: Sequence[str]
            with_title_labels: Sequence[str]
            alone_label: str
            override_title_by_label: bool
            future_if_no_date: bool

        # -- Directories: episodes
        @constdef
        class episodes:
            missing_duration: int
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool
            label: str
            alone_label: str

            @constdef
            class resume:
                page_size: int

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watching', 'watched', 'percent', 'percent_and_watched']
                width: int

        # -- Directories: anime
        @constdef
        class anime:
            region: str | None

            @constdef
            class aired:
                last_days: int

        # -- Directories: persons
        @constdef
        class persons:
            enabled: bool
            discovery_scan_limit: int

            @constdef
            class show:
                include_self: bool

            @constdef
            class images:
                art_type_folder: bool
                label_format: str | None

        # -- Directories: details
        @constdef
        class details:
            info_details: InfoDetails | str | None

            @constdef
            class videos:
                view: ContentView

            @constdef
            class credits:
                info_details: InfoDetails | str | None

        # -- Directories: stump indexers (keywords, companies)
        @constdef
        class stump:
            votes: int | None

            @constdef
            class keywords:
                search_n_keywords: Sequence[int]
                select: bool

        # -- Directories: trakt lists
        @constdef
        class trakt:
            @constdef
            class mine:
                view: ContentView

            @constdef
            class sort:
                default: TraktSortType  # obserwowane
                watchlist: TraktSortType  # obserwowane
                collections: TraktSortType  # kolekcje
                reverse_order: dict[TraktSortBy, bool]

        # -- Directories: tmdb lists
        @constdef
        class tmdb:

            @constdef
            class mine:
                view: ContentView

        # -- Directories: imdb lists
        @constdef
        class imdb:
            page_size: int

            @constdef
            class mine:
                view: ContentView

        # -- Directories: MDBList lists
        @constdef
        class mdblist:
            enabled: bool
            page_size: int
            lists_page_size: int

            @constdef
            class mine:
                view: ContentView

            @constdef
            class top:
                view: ContentView

        # -- Directories: wetrakr lists and accounts
        @constdef
        class wetrakr:
            enabled: bool
            page_size: int

        # -- Directories: justwatch (vod) lists
        @constdef
        class justwatch:
            enabled: bool
            page_size: int

            @constdef
            class new_vod:
                days: int

        # -- Directories: floppy lists
        @constdef
        class floppy:
            page_size: int

        # -- Directories: url lists
        @constdef
        class own:
            page_size: int
            lists: Sequence[OwnListDef]

            # @constdef
            # class favorites:
            #     enabled: bool
            #     mixed: bool
            #     list: OwnListDef

            # @constdef
            # class watchlist:
            #     enabled: bool
            #     mixed: bool
            #     list: OwnListDef

            @constdef
            class mine:
                view: ContentView
                root_direct_role: str

        # -- Directories: history
        @constdef
        class history:
            show_watching: bool
            role: str
            limit: int

        # -- Directories: continue watching
        @constdef
        class progress:
            view: ContentView
            episode_folder: bool
            page_size: int

        # -- Directories: tools
        @constdef
        class tools:
            view: ContentView
            select_theme: bool
            external_addons: bool
            sync_entry: bool

    @constdef
    class accounts:
        """Account types switched on / off (the local Kodi is always there, `kodi` is for remote ones)."""

        @constdef
        class pending:
            max_age: float
            max_retry: float

        @constdef
        class sync:
            startup_interval: int
            interval: int
            idle_interval: int
            fingerprint_interval: int
            notification_delay: int
            wait_for_service_timeout: float
            delivery_quiet: float
            delivery_max_wait: float

        @constdef
        class trakt:
            enabled: bool

        @constdef
        class tmdb:
            enabled: bool

        @constdef
        class mdblist:
            enabled: bool

        @constdef
        class wetrakr:
            enabled: bool

        @constdef
        class floppy:
            enabled: bool

        @constdef
        class imdb:
            enabled: bool

        @constdef
        class own:
            enabled: bool

        @constdef
        class justwatch:
            enabled: bool

        @constdef
        class kodi:  # only remote Kodi (not local)
            enabled: bool

    @constdef
    class indexer_group:

        # -- Genre menu
        @constdef
        class genres:
            translations: dict[str, dict[CodeId, str]]
            icons_set: Literal['fanfilm', 'kodi']
            icons: dict[Literal['fanfilm', 'kodi'], dict[CodeId, str]]

        # -- Language menu
        @constdef
        class languages:
            default: set[CodeId]
            top: set[CodeId]
            groups: tuple[DirItemSource, ...]
            votes: int | None

        # -- Country menu
        @constdef
        class countries:
            default: set[CodeId]
            top: set[CodeId]
            groups: tuple[DirItemSource, ...]
            votes: int | None

    # ----- tmdb.org settings -----
    @constdef
    class tmdb:
        append_to_response_limit: int
        # image_languages: Sequence[str]
        get_image_mode: Literal['append', 'append_en', 'append_lang', 'pull', 'full', 'all']
        include_nolang_images: bool
        language_aliases: Sequence[Sequence[str]]
        skel_max_threads: int
        avoid_keywords: Sequence[int]

        @constdef
        class auth:
            api: Literal[3, 4, None]
            dialog_interval: int
            dialog_expire: int
            qrcode_size: int

        @constdef
        class connection:
            try_count: int
            try_delay: float
            timeout: float
            common_session: bool
            max: int

    # ----- trakt.tv settings -----
    @constdef
    class trakt:
        recommendations_limit: int

        @constdef
        class page:
            limit: int

        @constdef
        class scan:
            @constdef
            class page:
                limit: int
                workers: int

        @constdef
        class sync:

            @constdef
            class alien:
                default: bool
                scheme: dict[str, bool]
                plugins: dict[str, bool]

        @constdef
        class auth:
            auto: bool
            service_timeout: float

            @constdef
            class qrcode:
                size: int

        @constdef
        class connection:
            try_count: int
            try_delay: float
            timeout: float
            close_to_token_expire: float

    # ----- mdblist.com settings -----
    @constdef
    class mdblist:
        @constdef
        class connection:
            try_count: int
            try_delay: float
            timeout: float

        @constdef
        class auth:
            refresh_before: int

    # ----- wetrakr.com settings -----
    @constdef
    class wetrakr:
        @constdef
        class connection:
            try_count: int
            try_delay: float
            timeout: float

        @constdef
        class concurrency:
            read: int
            write: int

        @constdef
        class auth:
            refresh_before: int

    # ----- Floppy (self-hosted) settings -----
    @constdef
    class floppy:
        @constdef
        class connection:
            try_count: int
            try_delay: float
            timeout: float

        @constdef
        class auth:
            refresh_before: int

    # ----- justwatch.com settings -----
    @constdef
    class justwatch:
        episode_max_limit: int

        @constdef
        class connection:
            timeout: float

    # ----- sources settings / tune -----
    @constdef
    class sources:
        stop_providers_at_max: bool
        duration_epsilon: float
        subtitles_max_age: float
        check_anime: str
        exclude_keywords: Sequence[str]
        rules: dict[SourceSelector, SourceRuleValue]
        franchise_names: dict[str, Sequence[str]]
        franchise_names_sep: str
        language_order: Sequence[str]
        request_timeout: float | tuple[float, float] | None
        local_resolvers: bool
        packs: Sequence[PackKind]

        @constdef
        class addons:
            forbidden_names: Sequence[str]

        @constdef
        class filters:
            skip_keys: Sequence[str]
            ways: Sequence[str]
            simple_hides_sets: bool
            short_source_values: bool

        @constdef
        class providers:
            groups: dict[str, ProviderGroup]
            folder_labels: dict[str, str]
            sections: dict[str, Sequence[ProviderSection]]
            default_off: Sequence[str]
            login_retry: int
            episode_priority: bool
            auto_colors: Sequence[str | Sequence[str]]

        @constdef
        class user_agent:
            auto: bool
            anchor: tuple[int, str]
            step: int
            margin: Sequence[int]
            systems: Sequence[str]

        @constdef
        class xproviders:
            ours: Sequence[str]
            default_active: XProviderActivity
            start_delay: int
            watch_interval: int
            timeout_margin: float

        @constdef
        class resolve:
            order: Sequence[ResolveKind]
            unresolvable: UnresolvablePolicy
            try_unresolvable: bool
            cached_premium: bool
            cache_timeout: float

        @constdef
        class cache:
            ttl: int
            empty_ttl: int
            show_ttl: int
            flush_timeout: float

        @constdef
        class kitsu:
            fribb_ttl: int
            fribb_keep: int
            ids_ttl: int
            ids_empty_ttl: int
            meta_ended_ttl: int
            meta_ttl: int
            workers: int

        @constdef
        class translations:
            providers: dict[str, dict[str, str]]
            hostings: dict[str, dict[str, str]]

        @constdef
        class external:

            @constdef
            class playerpl:
                fallback: bool

        @constdef
        class cda:
            duration_epsilon: float
            episode_duration_epsilon: float
            show_premium_free: str
            debug: bool
            min_size_mb: int

        @constdef
        class ekinotv:
            domain: str

        @constdef
        class giptv:
            index_max_age_h: int

        @constdef
        class xtb7:
            episode_separators: tuple[str, ...]
            max_show_search_queries: int
            similarity_check: bool
            similarity_threshold: float
            title_replacements: dict[str, str]
            debug: bool
            search_sessions: int

        @constdef
        class premium:
            no_transfer: bool

        @constdef
        class rapideo:  # rapideo/nopremium/twojlimit
            debug: bool

        @constdef
        class netmirror:
            debug: bool
            token_autorefresh_hours: int

    # ----- Player -----
    @constdef
    class player:
        set_dbid: bool
        cancel_start: PlayCancel
        cancel_resume: PlayCancel
        refresh_on_cancel_resume: float | None
        refresh_on_cancel_from_call: bool
        head_lookup: bool

    # ----- Library -----
    @constdef
    class library:
        flat_show_folder: bool
        strm_filename: StrmFilename
        title_language: str
        safe_filename: bool

        @constdef
        class strm:
            unreadable_ttl: int

        @constdef
        class service:
            sync_every_batch: bool
            sync_wait: bool
            chunk_size: int
            chunk_sleep: float
            update_all_shows: bool
            align: bool

    # ----- Dialogues -----
    @constdef
    class dialog:

        @constdef
        class config:
            hide_passwords: bool

        @constdef
        class changelog:
            version_color: str
            gui_timeout: float

        @constdef
        class local_error:
            line_color: str

        @constdef
        class tree:
            max_depth: int
            left_to_parent: bool
            check: Literal['button', 'icon', '']
            keys: Mapping[TreeKey, Sequence[str]]
            count_remembered: bool

            @constdef
            class filter:
                min_chars: int

        @constdef
        class add_to:
            allowed_conversions: dict[RefType, ListType]
            quiet: bool

            @constdef
            class media_type:
                absent_visible: ListType
                bar_mode: AddToDialogMediaBarMode

            # @constdef
            # class list_ui:
            #     color: str
            #     border: str
            #     selected_color: str
            #     selected_border: str

            @constdef
            class lists:
                local: Sequence[ListPointer]
                default: dict[str, Sequence[ListPointer]]
                services: dict[ListService, dict[str, Sequence[ListPointer]]]

        @constdef
        class ratings:
            style: RatingsStyle
            show_raw_rating: bool
            notification: bool
            colors: Sequence[str]
            autoclose_timeout: int

    @constdef
    class ratings:
        enabled: bool | Sequence[RatingServiceName]
        every_watched: bool
        watched_show_mode: Sequence[Literal['show', 'season', 'episode', 'show_finished', 'season_finished']]
        filter: dict[tuple[RatingServiceName | Literal['*'], RatingAction | Literal['*']], bool]
        all_folders: Literal[False, 'min', 'max', 'avg', 'first'] | RatingServiceName

    # ----- Low level settings (don't change, you are warnend) -----
    @constdef
    class tune:
        sleep_step: float
        event_step: float
        depagine_max_workers: int | None

        @constdef
        class db:
            connection_timeout: float
            cleanup_interval: int
            state_wait_read_interval: float
            state_mode: StateMode
            module_state_mode: dict[str, StateMode]
            synchronous: DbSynchronous
            db_synchronous: dict[str, DbSynchronous]

        @constdef
        class settings:
            vacuum_files: int
            retries: int
            retry_delay: float

        # @constdef
        # class indexer:

        @constdef
        class service:
            check_interval: float
            wait_check_interval: float
            job_list_sleep: int
            group_update_timeout: float
            group_update_busy_dialog: bool
            focus_item_delay: float
            widgets_reload_interval: float
            library_align_interval: float
            startup_delay: float
            startup_timeout: float
            retry_timeout: float
            rpc_call_timeout: float
            server_poll_interval: float
            sleep_step: float

            @constdef
            class http_server:
                port: int
                wait_for_url: float
                verbose: int

            @constdef
            class remote_plugin:
                enabled: bool
                calls: int
                call_timeout: float
                abort_wait: float

            @constdef
            class web_server:
                port: int
                verbose: int
                cookies: dict[str | re.Pattern[str], dict[str, str]]
                update_notification: bool

        @constdef
        class worker:
            sleep_step: float

        @constdef
        class locale:
            retry: float

        @constdef
        class misc:

            @constdef
            class qrcode:
                size: int

        @constdef
        class gui:
            xml_variants: int
            xml_foreign_ttl: float
            xml_prepare_delay: float
            xml_check_interval: float
            xml_busy_delay: float
            set_xml_value_lag: float
            number_typing_timeout: float
            list_follows_mouse: bool
            popup_min_rows: int
            font_roles: dict[str, tuple[float, bool]]
            font_role_tolerance: float

        @constdef
        class notify:
            debounce: float
            max_wait: float


# ----------------------------------------------------------------------------- #
# -----                              THE END                              ----- #
# ----------------------------------------------------------------------------- #


if TYPE_CHECKING:
    ConstRefBase = type(const)
else:
    ConstRefBase = object


class ConstRef(ConstRefBase):
    """Dynamic const reference."""

    def __init__(self, obj: object, *keys: str) -> None:
        self._obj = obj
        self._keys = keys

    if not TYPE_CHECKING:
        def __getattr__(self, key: str) -> Any:
            if key.startswith('_'):
                raise AttributeError(key)
            return ConstRef(self._obj, *self._keys, key)

    def __call__(self, root: Any = None) -> Any:
        """Return the value (of the tree of the root, e.g. `const_snapshot()`, default: its own)."""
        obj = self._obj if root is None else root
        for key in self._keys:
            obj = getattr(obj, key)
        return obj

    def __repr__(self) -> str:
        return f'CONST_REF({".".join(self._keys)})'


CONST_REF = ConstRef(const)


def const_value(value: T, root: Any = None) -> T:
    """
    Return the value, a `CONST_REF` read now (e.g. an argument of a decorator: `const` may be loaded again later), in the
    tree of the root (`const_snapshot()`, default: `const`).
    """
    return value(root) if isinstance(value, ConstRef) else value  # type: ignore[return-value]


def const_snapshot() -> Any:
    """
    Return `const` as it is now: a reload later does not change it (several values read together are of one `const`,
    e.g. `snap = const_snapshot()` then `snap.a.b` and `const_value(CONST_REF.c.d, snap)`).
    """
    snap = object.__new__(type(const))
    object.__setattr__(snap, '__dict__', const.__dict__)
    return snap
#: Path of `local.py` (local const overrides), set by `const_done()`.
local_path: Path | None = None
#: The modification time of `local.py` loaded into `const` (None: no file), see `local_changed()`.
_local_mtime: float | None = None
#: One reload of `const` at a time.
_reload_lock = Lock()


class _Load:
    """
    A tree of const sections being loaded (its sections keep it as `_load`): it is open (not locked) and, while `local.py`
    runs, the withdrawn keys it assigns are recorded and ignored.
    """

    def __init__(self, path: Path | None) -> None:
        #: `local.py` being run, None: `const.py` (a withdrawn key there is an error).
        self.path: Path | None = path
        #: The withdrawn keys assigned in `local.py`.
        self.obsolete: list[ObsoleteUse] = []


@frozen
class LocalError:
    """The error of `local.py`: the whole file is ignored, `const` has its defaults."""

    #: The file.
    path: Path
    #: Its line (None if not known, e.g. a `CONST_REF` resolved after loading).
    line: Optional[int]
    #: The error text.
    message: str

    @classmethod
    def from_exception(cls, exc: BaseException, path: Path) -> LocalError:
        """Return the error of the exception: the line of the syntax error or of the last frame in the file."""
        import traceback
        line = exc.lineno if isinstance(exc, SyntaxError) else None
        if line is None:
            line = next((frame.lineno for frame in reversed(traceback.extract_tb(exc.__traceback__)) if Path(frame.filename) == path), None)
        message = exc.msg if isinstance(exc, SyntaxError) else str(exc)
        return cls(path=path, line=line, message=f'{type(exc).__name__}: {message}')

    def __str__(self) -> str:
        return f'{self.path.name}:{self.line}: {self.message}' if self.line else f'{self.path.name}: {self.message}'


#: The error of `local.py` (ignored then), set by `const_done()`, shown by `lib.ff.control.show_local_error()`.
local_error: LocalError | None = None

#: Withdrawn const keys: the path of a key or of a section (all its keys, e.g. `indexer.lists.menu`) -> where the setting is
#: now (an ID, its text is `lib.ff.control.obsolete_place()`; `style:<token>` - a token of the style of the windows).
#: `local.py` may still assign them: the assignment is ignored
#: and shown (`local_obsolete`), the rest of the file works. Anywhere else (const.py, the code) a withdrawn key is an error.
OBSOLETE: dict[str, str] = {
    'sources.filters.separate_shows': 'config.json /sources/settings/separate_shows',  # the configuration window
    # the settings of the lists (the configuration window)
    'indexer.movies.new_vod': 'lists.feeds',  # JustWatch new VOD: `indexer.justwatch.new_vod.days`, the VOD services of the user
    'indexer.tvshows.new_vod': 'lists.feeds',
    'indexer.justwatch.new_vod.services': 'lists.feeds',
    'indexer.navigator': 'lists.folders',  # the folder points of the menus (`lib.ff.lists_config.FOLDER_POINTS`)
    'indexer.lists.menu': 'lists.folders',
    'indexer.lists.media': 'lists.folders',
    'indexer.lists.mine': 'lists.folders',
    'indexer.lists.general': 'lists.folders',
    'indexer.movies.my_lists': 'lists.folders',
    'indexer.tvshows.my_lists': 'lists.folders',
    'indexer.persons.my_lists': 'lists.folders',
    'indexer.history.menu': 'lists.folders',
    'indexer.trakt.mine.folder': 'lists.folders',
    'indexer.tmdb.mine.folder': 'lists.folders',
    'indexer.imdb.mine.folder': 'lists.folders',
    'indexer.mdblist.mine.folder': 'lists.folders',
    'indexer.wetrakr.mine': 'lists.folders',
    'indexer.justwatch.mine': 'lists.folders',
    'indexer.own.mine.folder': 'lists.folders',
    'indexer.own.mine.sublists': 'lists.folders',
    'indexer.own.mine.show_list_name': 'lists.folders',
    'indexer.movies.trending': 'lists.feeds',  # the data providers of the fixed entries (`lib.ff.lists_config.FEEDS`)
    'indexer.tvshows.trending': 'lists.feeds',
    # the sync of all accounts (not only Trakt)
    'trakt.sync.startup_interval': 'const.accounts.sync.startup_interval',
    'trakt.sync.interval': 'const.accounts.sync.interval',
    'trakt.sync.cooldown': 'removed',
    'indexer.tmdb.root': 'removed',  # the section of the TMDB root menu (flat) went with cda.py
    'tune.service.remote_plugin.queue_timeout': 'const.tune.service.remote_plugin.call_timeout',  # a long call, not a long queue
    'indexer.tvshows.last_show_progress_folder': 'removed',  # "Shows in progress" is one list (no folder of the last ones)
    'trakt.sync.notification_delay': 'const.accounts.sync.notification_delay',
    'trakt.sync.wait_for_service_timeout': 'const.accounts.sync.wait_for_service_timeout',
    'indexer.trakt.show_sync_entry': 'const.indexer.tools.sync_entry',
    'dialog.tree.check_icon': 'const.dialog.tree.check',  # the check column or the check button of a tree
    'dialog.tree.node_toggle': 'const.dialog.tree.keys',  # the keys of a tree in one mapping (`toggle`)
    'sources.resolve.hide_uncached': 'const.sources.rules',  # a rule: `SourceSelector(resolvability={'cached': False}): False`
    'sources.xproviders.install': 'removed',  # the provider add-on of a dialect: `script.fanfilm.provider.<dialect>`
    'library.service.align_resume_tolerance': 'const.media.progress.tolerance.resume',  # one "same resume point" for all
    'media.progress.show.episodes_watched': 'const.indexer.tvshows.progress.show_watching',  # read by nothing; a show in progress by a started episode
    # the colours of the windows: the tokens of the style (`lib.windows.style.TOKENS`)
    'sources_dialog.index_color': 'style:color.text',
    'dialog.auth.link_color': 'style:color.link',
    'dialog.auth.code_color': 'style:color.code',
    'dialog.tree.selected_color': 'style:color.accent',
    'dialog.tree.partial_color': 'style:color.accent.partial',
    'dialog.tree.filter.color': 'style:color.text.match',
    'dialog.tree.indent': 'style:space.indent',
    'dialog.tree.details_row_height': 'style:metric.row.details',
    'dialog.add_to.media_type.absent_color': 'style:color.text.disabled',
    'dialog.add_to.media_type.exist_color': 'style:color.icon.focused',
    'dialog.add_to.media_type.converting_color': 'style:color.warning',
    'dialog.add_to.media_type.disallowed_color': 'style:color.error',
    'tune.gui.style_variant': 'removed',  # a palette of the windows is a theme (`resources/style.json` of a theme add-on)
    'sources.include_languages': 'removed',  # the languages of the user filter of the sources (its language node, `lib.ff.source_keys`)
}


@frozen
class ObsoleteUse:
    """An assignment of a withdrawn const key in `local.py` (ignored)."""

    #: The key path (without `const.`).
    path: str
    #: The line in `local.py` (None if not known).
    line: Optional[int]
    #: Where the setting is now (`OBSOLETE` value).
    where: str


#: The withdrawn keys assigned in `local.py`, set by `const_done()`, shown by `lib.ff.control.show_local_obsolete()`.
local_obsolete: list[ObsoleteUse] = []


def _section_keys(section: object) -> tuple[str, ...]:
    """Return the key path of a const section (set by `_check_const_assignment()`; the root: empty)."""
    return section.__dict__.get('_const_keys', ())


def _obsolete_where(keys: Sequence[str]) -> str | None:
    """Return where the withdrawn key (or a key of a withdrawn section) is now, None if it is not withdrawn."""
    return next((OBSOLETE[path] for n in range(len(keys), 0, -1) if (path := '.'.join(keys[:n])) in OBSOLETE), None)


def _obsolete_section(keys: Sequence[str]) -> bool:
    """Return True if the key is withdrawn, of a withdrawn section or a removed section with withdrawn keys in it."""
    path = '.'.join(keys)
    return _obsolete_where(keys) is not None or any(withdrawn.startswith(f'{path}.') for withdrawn in OBSOLETE)


def _obsolete_use(load: _Load | None, keys: Sequence[str]) -> bool:
    """Record an assignment of the withdrawn key in `local.py` (while it is loaded); False if not withdrawn or not `local.py`."""
    import sys
    if load is None or load.path is None or (where := _obsolete_where(keys)) is None:
        return False
    frame = sys._getframe(1)
    while frame is not None and Path(frame.f_code.co_filename) != load.path:
        frame = frame.f_back
    load.obsolete.append(ObsoleteUse(path='.'.join(keys), line=frame and frame.f_lineno, where=where))
    return True


class _ObsoleteSection:
    """
    A withdrawn const section read in `local.py` (or a removed one with withdrawn keys): an assignment (or a call) of
    a withdrawn key is recorded and ignored, of another key it is an error (as of any unknown key).
    """

    def __init__(self, load: _Load, keys: tuple[str, ...]) -> None:
        """The withdrawn section of the key path, read in `local.py` of the load."""
        object.__setattr__(self, '_load', load)
        object.__setattr__(self, '_keys', keys)

    def __getattr__(self, key: str) -> Any:
        """Return a key of the section (withdrawn or a section with withdrawn keys), else an error."""
        if key.startswith('_') or not _obsolete_section(keys := (*self._keys, key)):
            raise AttributeError(f'No const attribute const.{".".join((*self._keys, key))}')
        return _ObsoleteSection(self._load, keys)

    def __setattr__(self, key: str, value: Any) -> None:
        """Record the assignment of the key (ignored)."""
        if not _obsolete_use(self._load, (*self._keys, key)):
            raise AttributeError(f'No const attribute const.{".".join(self._keys)}.{key}')

    def __setitem__(self, key: Any, value: Any) -> None:
        """Record the assignment of an item (ignored)."""
        if not _obsolete_use(self._load, self._keys):
            raise AttributeError(f'No const attribute const.{".".join(self._keys)}')

    def __getitem__(self, key: Any) -> Any:
        """Return the section itself (an item of a withdrawn value)."""
        return self

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Record a call (e.g. `.update()` of a withdrawn dict), ignored."""
        if not _obsolete_use(self._load, self._keys):
            raise AttributeError(f'No const attribute const.{".".join(self._keys)}')
        return self


class SettingsDescriptor(Generic[T]):
    """Helper to mark setting to be evaluated."""

    def __init__(self, expr: str | bool | None) -> None:
        self.expr = expr

    def __repr__(self) -> str:
        return f'SETTING({self.expr!r})'

    @overload
    def __get__(self: Self, instance: None, objtype: type[object] | None = None) -> Self: ...

    @overload
    def __get__(self: Self, instance: object, objtype: type[object] | None = None) -> T: ...

    def __get__(self: Self, instance: object | None, objtype: type[object] | None = None) -> Self | T:
        """Get descriptor value or instance."""
        # return descriptor
        if instance is None:
            return self
        if self.expr is None or self.expr is False or self.expr is True:
            return self.expr  # type: ignore[return-value]
        from lib.ff.settings import settings
        return settings.eval(self.expr)


class _SettingSlot:
    """The key of a section class given by a setting: the expression is of the section (`_settings`), not of the class."""

    def __init__(self, key: str) -> None:
        #: The key.
        self.key: str = key

    def __get__(self, instance: object | None, objtype: type[object] | None = None) -> Any:
        """Return the value of the setting of the section, AttributeError if the section has none (a plain value wins)."""
        if instance is None:
            return self
        try:
            descr = instance.__dict__['_settings'][self.key]
        except KeyError:
            raise AttributeError(self.key) from None
        return descr.__get__(instance, objtype)


def __getattr__(key: str) -> Any:
    """Return const settings directly as module value."""
    if key and key[0].islower():
        return getattr(const, key)
    raise AttributeError(f'Module {__name__} has o attribute {key!r}')


# dummy function
def setup_debugger():
    """Configure remote debugger. Override this in local.py."""
    from lib.ff.logs import fflog
    fflog('setup_debugger() is missing in local.py. Your debugger is not set.')


def run_debugger():
    """Run remote debugger connection."""
    if const.debugger.enabled:
        from lib.ff.logs import fflog_exc
        try:
            setup_debugger()
        except Exception:
            fflog_exc()


def _data_path() -> Path:
    """Returns plugin data folder path."""
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    return Path(translatePath(Addon().getAddonInfo('profile')))


def _check_const_assignment(const_obj: Any, *, obj: Any = None, keys: Sequence[str] = ()):
    """Check if all defined `class const` settings are assigned."""
    if obj is None:
        const_obj._refs = {}
        obj = const_obj
    object.__setattr__(obj, '_const_keys', tuple(keys))  # the path of the section (withdrawn keys, `OBSOLETE`)
    cls = type(obj)
    # attributrs
    elements = {k: v for k, v in vars(obj).items() if not k.startswith('_')}
    # settings (`SETTING()`)
    elements.update(vars(obj).get('_settings', {}))
    # check annotations
    if ann := getattr(cls, '__annotations__', None):
        if missing := ann.keys() - elements.keys():
            sets = ', '.join(sorted(missing))
            raise TypeError(f'{cls.__qualname__}: missing settings: {sets}')
    # for sub in elements.values():
    for key, sub in elements.items():
        if _has_const_ref(sub):
            const_obj._refs[(*keys, key)] = sub
        if getattr(sub, '_const_def', None):
            _check_const_assignment(const_obj=const_obj, obj=sub, keys=(*keys, key))


def _has_const_ref(value: Any) -> bool:
    """Return True if the value is a `CONST_REF` or has one (in a tuple, list, set or in values of a dict, nested)."""
    if isinstance(value, ConstRef):
        return True
    if isinstance(value, (tuple, list, set)):
        return any(_has_const_ref(e) for e in value)
    if isinstance(value, dict):
        return any(_has_const_ref(e) for e in value.values())
    return False


def _resolve_const_assignment(obj):
    """Check if all defined `class const` settings are assigned."""
    def xset(x: Any, keys: Sequence[str], value: Any) -> None:
        for key in keys[:-1]:
            x = getattr(x, key)
        setattr(x, keys[-1], value)

    def get(ref: ConstRef) -> ConstRef:
        visited: set[str] = {keys, ref._keys}
        while ref2 := refs.get(ref._keys):
            ref = ref2
            if ref._keys in visited:
                cycle = ', '.join('.'.join(('const', *keys)) for keys in visited)
                raise ValueError(f'Cycle const refernece: {cycle}')
            visited.add(ref._keys)
        return ref

    def resolve(value: Any) -> Any:
        if type(value) is ConstRef:
            target = obj  # by its keys in this tree (a tree loaded aside is not the one of the reference)
            for key in get(value)._keys:
                target = getattr(target, key)
            return target
        if isinstance(value, (tuple, list, set)):
            return type(value)(resolve(e) for e in value)
        if isinstance(value, dict):
            return type(value)((k, resolve(v)) for k, v in value.items())
        return value

    refs = getattr(obj, '_refs', {})
    for keys, ref in refs.items():
        xset(obj, keys, resolve(ref))


def _new_tree(section: T) -> T:
    """Return a new tree of the const sections of the section, without values (a reload builds it aside)."""
    obj = object.__new__(type(section))
    for key, value in vars(type(section)).items():
        if getattr(value, '_const_def', None):
            object.__setattr__(obj, key, _new_tree(value))
    return obj


def _sections(section: Any) -> Iterator[Any]:
    """Yield the section and all its subsections."""
    yield section
    for value in vars(section).values():
        if getattr(value, '_const_def', None):
            yield from _sections(value)


def _mark(root: Any, load: _Load | None) -> None:
    """Mark the sections of the tree as being loaded (open), None: loaded."""
    for section in _sections(root):
        if load is None:
            section.__dict__.pop('_load', None)
        else:
            object.__setattr__(section, '_load', load)


def _values(root: Any) -> dict[str, Any]:
    """Return the values of the tree (a setting: its descriptor) by their key paths."""
    return {'.'.join((*_section_keys(section), key)): section.__dict__.get(key, section.__dict__.get('_settings', {}).get(key))
            for section in _sections(root) for key in getattr(type(section), '__annotations__', {})}


def _changed(old: Any, new: Any) -> bool:
    """Return True if the value changed (some values compare by identity: then by their text)."""
    try:
        if old == new:
            return False
    except Exception:
        pass
    return repr(old) != repr(new)


def _imports(root: Any) -> dict[str, Any]:
    """
    Return the globals for `const.py` and `local.py` loaded into the tree aside: their imports of `cdefs` and `const` give
    the tree, the modules themselves (seen by every thread) are not changed.
    """
    tree_cdefs = ModuleType('cdefs')
    tree_cdefs.__dict__.update(globals())
    tree_cdefs.__dict__.update(const=root, CONST_REF=ConstRef(root), const_done=lambda: None)
    tree_const = ModuleType('const')
    modules = {'cdefs': tree_cdefs, 'const': tree_const}
    base_import = builtins.__import__

    def tree_import(name: str, globals: Any = None, locals: Any = None, fromlist: Any = (), level: int = 0) -> Any:
        """Import the module, `cdefs` and `const` of the tree."""
        if level == 0 and (module := modules.get(name)) is not None:
            return module
        return base_import(name, globals, locals, fromlist, level)

    return {'__builtins__': {**vars(builtins), '__import__': tree_import}, '_tree_modules': modules}


def _run_local(root: Any, path: Path, context: dict[str, Any]) -> tuple[LocalError | None, list[ObsoleteUse], dict[str, Any]]:
    """Run `local.py` into the tree: its error (the tree is changed then), the withdrawn keys, its own names."""
    opened: _Load | None = root.__dict__.get('_load')  # a tree built aside stays open
    _mark(root, load := _Load(path))
    try:
        local_globals = runpy.run_path(str(path), init_globals=context)
        _check_const_assignment(root)  # re-check after loading local settings, to handle CONT_REF removing
        _resolve_const_assignment(root)
    except Exception as exc:
        from lib.ff.logs import fflog_exc
        # internal=True: logging runs during const initialization, must not import lib.ff.threads
        # (threads imports const -> partially-initialized circular import). See logs._log().
        fflog_exc(internal=True)
        return LocalError.from_exception(exc, path), [], {}
    finally:
        _mark(root, opened)
    if load.obsolete:
        from lib.ff.logs import fflog
        for use in load.obsolete:
            fflog(f'local.py:{use.line}: withdrawn const.{use.path} ignored (now: {use.where})', internal=True)
    return None, load.obsolete, {k: v for k, v in local_globals.items() if not k.startswith('__') and context.get(k, ...) is not v}


def _build(path: Path | None) -> tuple[Any, LocalError | None, list[ObsoleteUse], dict[str, Any]]:
    """
    Return a new tree of `const.py` and `local.py` (None or a missing file: the defaults) loaded aside, its error (the
    defaults then), the withdrawn keys and the names of `local.py`.
    """
    root = _new_tree(const)
    context = _imports(root)
    _mark(root, _Load(None))  # open until it is built (`const` itself is locked)
    try:
        defaults = runpy.run_path(str(Path(__file__).with_name('const.py')), init_globals=context, run_name='const_defaults')
        tree_const: ModuleType = context['_tree_modules']['const']
        tree_const.__dict__.update((k, v) for k, v in defaults.items() if k == '__getattr__' or not k.startswith('__'))
        _check_const_assignment(root)
        error, obsolete, names = None, [], {}
        if path is not None and path.is_file():
            tree_cdefs: ModuleType = context['_tree_modules']['cdefs']
            error, obsolete, names = _run_local(root, path, {**context, **{k: v for k, v in vars(tree_cdefs).items() if not k.startswith('__')}})
            if error is not None:
                return (_build(None)[0], error, [], {})  # the whole file is ignored: the defaults (also of values changed in place)
        _check_const_assignment(root)
        _resolve_const_assignment(root)
    finally:
        _mark(root, None)
    return root, error, obsolete, names


def _publish(root: Any, error: LocalError | None, obsolete: list[ObsoleteUse], names: dict[str, Any]) -> None:
    """Make the tree the one of `const`: one assignment (a reader sees the old tree or the new one, never a part of either)."""
    global local_error, local_obsolete, _local_mtime
    if root is not const:
        object.__setattr__(const, '__dict__', root.__dict__)
    local_error, local_obsolete = error, obsolete
    globals().update(names)
    try:
        _local_mtime = local_path.stat().st_mtime if local_path is not None else None
    except OSError:
        _local_mtime = None


def local_changed() -> bool:
    """Return True if `local.py` changed (or appeared, or went) since it was loaded into `const`."""
    try:
        mtime = local_path.stat().st_mtime if local_path is not None else None
    except OSError:
        mtime = None
    return mtime != _local_mtime


def const_reload() -> list[str]:
    """
    Load `const.py` and `local.py` again (a long running interpreter, e.g. the service): the new tree is built aside and
    replaces the tree of `const` at once. Return the key paths with a changed value.
    """
    with _reload_lock:
        root, error, obsolete, names = _build(local_path)
        old = _values(const)
        _publish(root, error, obsolete, names)
        return [key for key, value in _values(const).items() if _changed(old.get(key), value)]


def const_done():
    """Load `local.py` (the local overrides) and lock `const`; on any error of the file it is ignored as a whole (`local_error`)."""

    global local_path
    if getattr(constdef, '_locked', False):
        return

    _check_const_assignment(const)  # pure const (without local) to check if all settings are set

    # --- must be on the bottom of the file

    local_path = _data_path() / 'local.py'
    if not local_path.exists():
        try:
            local_path.write_text(('"""Local const settings."""\n\nfrom cdefs import const, CONST_REF\n\n\n'
                                    '# --- Your custom settings\n\n# const.NAME = VALUE\n'), encoding='utf-8')
        except IOError as exc:
            from lib.ff.logs import fflog
            # internal=True: logging runs during const initialization, must not import lib.ff.threads
            # (threads imports const -> partially-initialized circular import). See logs._log().
            fflog(f'Creating local file {local_path} failed: {exc}', internal=True)
    root, error, obsolete, names = const, None, [], {}
    if local_path.is_file():
        # the first load: into `const` itself (nobody reads it yet)
        error, obsolete, names = _run_local(const, local_path, {k: v for k, v in globals().items() if not k.startswith('__')})
        if error is not None:
            # the whole file is ignored: the defaults of const.py (it assigns every key, see `_check_const_assignment()`),
            # also of values changed in place (dicts, lists)
            root = _build(None)[0]

    # resolve references
    _check_const_assignment(root)
    _resolve_const_assignment(root)
    _publish(root, error, obsolete, names)
    # end of const definitions
    constdef._locked = True  # type: ignore
