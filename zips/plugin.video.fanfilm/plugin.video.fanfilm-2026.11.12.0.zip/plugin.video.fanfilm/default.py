"""
    FanFilm Add-on
    Copyright (C) 2016 mrknow
    See more in lib/launch.py
"""
from lib.plugin_remote import remote_launch
if not remote_launch():  # a call of a handle runs in the FF service, if it runs the plugin calls
    from lib.launch import launch
    launch()
