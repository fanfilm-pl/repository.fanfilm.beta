"""
FanFilm const (low-level developer) settings.
Do NOT change if you don't know what you're doing.

Avoid imports here, please.
Supports `local.py` from plugin userdata folder. File is created if missing.

You can override settings in `local.py`.
Just in the same form as in section "CONST SETTINGS",
>>> const.name = value

To define new const settings check also cdefs.py.

Use const settings
------------------

And use in source code.
>>> from const import const
>>> if const.a.b.c == value: ...

When a change of `local.py` applies
-----------------------------------

A changed `local.py` is loaded again before the next plugin call (in the plugin and in the service) and in the cycle
of the service. A key is read at use, so its new value applies at once, unless its comment says otherwise in a line
>>> #. apply=service

- `service` - at the start of the FanFilm service (a Kodi restart, an update of the add-on, `const.debug.autoreload`),
- `server` - at the start of a server of the service (as `service`; the web server also by its setting off and on).

Code reading a key once (a module, a class body, a default argument, a decorator) needs the marker of the key (a test
checks it); better read the key at use (`CONST_REF`, `const_value()`).
"""

from cdefs import const, const_done, CONST_REF, SETTING
from cdefs import (
    PlayCancel, WidgetsReload, StateMode, MediaWatchedMode, StrmFilename, OwnListDef, AddToMenu, ListType, DirItemSource, SourceSearchProgressStyle,
    SourceSelector, SourceAttribute, SourceAttributeBadge, ProviderGroup, ProviderSection,
    RegEx, Expr, Glob, R, X,
    MINUTE, HOUR, DAY, MiB,
)
from lib.kolang import L  # semi-safe import
import cdefs as _cdefs


def __getattr__(name: str) -> object:
    """
    Any public name of `cdefs` (e.g. `SourcePattern`), also for `from const import ...` in `local.py`.

    `local.py` runs while this module is built (`const_done()` at the bottom), so it sees the names given here before
    the end; the names of `cdefs` are its globals anyway, this makes the explicit import work the same way.
    """
    if not name.startswith('_') and name in vars(_cdefs):
        return vars(_cdefs)[name]
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')


# ----------------------------------------------------------------------------- #
# -----                          SOME DOCUMENTATION                       ----- #
# ----------------------------------------------------------------------------- #
#
# `votes` – minmum number of votes
#  -  >= 0   - the number
#  -  == -1  - skip votes at all
#  -  None   - use default from user settings


# ----------------------------------------------------------------------------- #
# -----                          CONST SETTINGS                           ----- #
# ----------------------------------------------------------------------------- #

# --- Developing and debugging ---

# Use more logs. Useful with `grep -f LOG` on the Linux.
const.debug.enabled = True
# Use terminal seq (colors) in logs. Useful with `grep -f LOG` on the Linux.
const.debug.tty = False
# Add extra context menu item: CRASH, allows restart Python interpreter.
const.debug.crash_menu = False
# Add extra context menu item: RESTART, restarts the FanFilm service in a fresh interpreter.
const.debug.restart_menu = False
# Extra developer menu.
const.debug.dev_menu = False
# Auto-reload on a changed source of FanFilm (`lib/**` without `lib/3rd`, `*.py` of the add-on): the plugin call ends
# (the next one in a fresh interpreter), the service starts again in a fresh one - the add-on disabled and enabled (Kodi
# starts a service again only so); a Kodi crash just between them leaves FanFilm disabled (enable it in the add-ons).
# Not on a Kodi exit or an update of the add-on (Kodi starts its new service itself).
#. apply=service
const.debug.autoreload = False
# The quiet time after a change of the sources (no next change) before the service restarts (a checkout: one restart) [s].
const.debug.autoreload_quiet = 1.0
# Detailed service notification log.
const.debug.service_notifications = False
# Log xsleep jitter (shift in seconds). Zero means no log.
const.debug.log_xsleep_jitter = 0
# Log folder details.
const.debug.log_folders = False
# Show "logs" target in CM in "Add to" dialog.
const.debug.add_to_logs = False
# Detailed exception log (eg. in threads).
const.debug.log_exception = True
# Detailed GUI log.
const.debug.log_gui = False
# Log the number of HTTP requests (per host) of the plugin call (measurements, e.g. notes/tools/listing_timing.py).
const.debug.log_http = False
# Keys of the stored values (settings, account and provider stores) that tune the log line format (regex, any case, the last part
# of the key): the access data, also left out of a backup without them (`lib.ff.backup`).
const.debug.log_tune = r'token|auth|bearer|cookie|session|api_?key|at-main|password|username|login|email|secret|client_?key|^user$|^dev$'
# Developer logs ("Show developer logs" setting): the levels of the loggers, the `loggers` section of `logging.config.dictConfig()`;
# a level text is short for {'level': ...}, any case; '' is the root logger (other add-ons and libraries), 'lib' is FanFilm.
const.debug.logging = {'': 'WARNING', 'lib': 'DEBUG'}

#: Use remote debugger (debugpy, vscode, etc.). Function setup_debugger() in local.py must be declared.
const.debugger.enabled = False

#: Override IMDB API list page size, do not chenge it
const.dev.imdb.api_page_size = CONST_REF.indexer.page_size

# Override TMDB api_key for tests.
const.dev.tmdb.api_key = None
# Override TMDB session_id for tests.
const.dev.tmdb.session_id = None
# Override TMDB v4 read token for tests.
const.dev.tmdb.v4.bearer = None
# Override TMDB v4 access token for tests.
const.dev.tmdb.v4.access_token = None

# Override Trakt.tv client_id for tests.
const.dev.trakt.client = None
# Override Trakt.tv client_secret for tests.
const.dev.trakt.secret = None

# Override MDBList api_key for tests.
const.dev.mdblist.api_key = None

#: Echo all DB queries.
const.dev.db.echo = False
#: Do backup on DB update.
const.dev.db.backup = True
#: Fake source items prepend to found items in the source window.
const.dev.sources.prepend_fake_items = ()
#: Fake source items append to found items in the source window.
const.dev.sources.append_fake_items = ()
#: Detailed source provider exception log.
const.dev.sources.log_exception = True
#: Force all providers and skip source filtering (quality, size, language, codec). For debugging only.
const.dev.sources.force_all_sources = False

#: Force video database version (empty - autodetect).
const.dev.kodidb.ver = ''
#: Number of lines to search in Kodi MyVideo database version. Zero means all log lines.
const.dev.kodidb.number_or_log_lines = 1000

#: The inspector of the FF windows (lib/windows/inspector.py, docs/gui/windows.md): the page `http://<host>:<port>/` in a browser
#: (the widgets of the shown windows, their properties, a screenshot), served while an FF window is shown.
const.dev.inspector.enabled = False
#: The address of the inspector: 127.0.0.1 this device only; another one (e.g. '0.0.0.0': the network) needs the `token`.
const.dev.inspector.host = '127.0.0.1'
#: The port of the inspector.
const.dev.inspector.port = 8387
#: The access token of the inspector on a host other than this device (the page address `?token=…`); None: not started there.
const.dev.inspector.token = None
#: The Kodi action ID which saves the snapshot of the window to a file (`inspector/` in the add-on profile), e.g. `ACTION_PLAYER_DEBUG`; None: no key.
const.dev.inspector.key = None
#: The outline of the layout of the FF windows (lib/windows/outline.py): the frames of their widgets and controls, the margins, the spacing,
#: the free space, the grouplists and the grid cells drawn by Kodi over them (a developer view; the windows are generated again when it changes).
const.dev.outline.enabled = False
#: The paths of the widgets at their frames in the outline (a small text: unreadable in a dense window).
const.dev.outline.labels = False
#: The Kodi action ID which hides the outline of the open window and shows it again, the Kodi debug info with it (`Skin.ToggleDebug`),
#: e.g. `ACTION_PLAYER_PROCESS_INFO` (`codecinfo`); None: no key (the inspector page has the switch too).
const.dev.outline.key = None


# --- Global (independent) definitions ---

# Default language for the country.
const.global_defs.country_language = {
    'AD': 'ca', 'AE': 'ar', 'AL': 'sq', 'AM': 'hy', 'AO': 'pt', 'AR': 'es', 'AT': 'de', 'AZ': 'az', 'BB': 'en',
    'BD': 'bn', 'BE': 'de', 'BF': 'fr', 'BG': 'bg', 'BH': 'ar', 'BI': 'en', 'BJ': 'fr', 'BR': 'pt', 'BS': 'en',
    'BT': 'dz', 'BY': 'ru', 'BZ': 'en', 'CA': 'fr', 'CF': 'fr', 'CH': 'rm', 'CL': 'es', 'CM': 'en', 'CN': 'zh',
    'CO': 'es', 'CR': 'es', 'CU': 'es', 'CY': 'tr', 'DE': 'de', 'DJ': 'fr', 'DK': 'da', 'DM': 'en', 'DO': 'es',
    'EC': 'qu', 'EE': 'et', 'EG': 'ar', 'ER': 'ti', 'ES': 'es', 'ET': 'en', 'FI': 'sv', 'FJ': 'hi', 'FR': 'fr',
    'GA': 'fr', 'GB': 'en', 'GD': 'en', 'GE': 'ka', 'GH': 'en', 'GN': 'fr', 'GQ': 'es', 'GR': 'el', 'GT': 'es',
    'GY': 'en', 'HN': 'es', 'HR': 'hr', 'HU': 'hu', 'IE': 'ga', 'IL': 'he', 'IN': 'en', 'IQ': 'ar', 'IS': 'is',
    'IT': 'it', 'JM': 'en', 'JO': 'ar', 'JP': 'ja', 'KE': 'en', 'KG': 'ru', 'KH': 'km', 'KI': 'en', 'KM': 'fr',
    'KW': 'ar', 'KZ': 'ru', 'LB': 'ar', 'LI': 'de', 'LK': 'ta', 'LR': 'en', 'LS': 'en', 'LT': 'lt', 'LU': 'lb',
    'LV': 'lv', 'LY': 'ar', 'MC': 'fr', 'ME': 'sq', 'MG': 'mg', 'MH': 'en', 'MK': 'sq', 'ML': 'fr', 'MN': 'mn',
    'MR': 'ar', 'MT': 'en', 'MU': 'en', 'MX': 'es', 'MY': 'en', 'MZ': 'pt', 'NA': 'en', 'NE': 'fr', 'NG': 'en',
    'NI': 'es', 'NL': 'nl', 'NP': 'ne', 'OM': 'ar', 'PA': 'es', 'PE': 'qu', 'PK': 'ur', 'PL': 'pl', 'PT': 'pt',
    'QA': 'ar', 'RO': 'ro', 'RS': 'sr', 'RW': 'sw', 'SA': 'ar', 'SB': 'en', 'SD': 'en', 'SE': 'sv', 'SG': 'ta',
    'SK': 'sk', 'SL': 'en', 'SM': 'it', 'SN': 'fr', 'SO': 'ar', 'SR': 'nl', 'SS': 'en', 'SV': 'es', 'TD': 'fr',
    'TG': 'fr', 'TH': 'th', 'TN': 'fr', 'TO': 'to', 'TR': 'tr', 'TV': 'en', 'UA': 'uk', 'UG': 'sw', 'US': 'en',
    'UY': 'es', 'UZ': 'uz', 'VE': 'es', 'VU': 'fr', 'WS': 'en', 'YE': 'ar', 'ZA': 'zu', 'ZM': 'en'}


# --- Core ---

# Load a changed local.py again before the next call (the plugin and the service, also in the cycle of the service);
# False: local.py is read at the start of an interpreter only (a change needs a Kodi restart).
#. apply=service
const.core.const_reload = True
# Call garbage collector (GC) for every nth plugin calls.
const.core.gc_every_nth = 5
# Exit (close Python interpreter) for every nth plugin calls, 0: never (an emergency switch only).
# An exit makes the next FF call start cold (a new interpreter, all imports again: 0.7-1.4 s desktop, 0.9 s Android,
# 3.2 s Raspberry Pi 4) and adds memory instead of freeing it (Pi: +30-45 MB per exit; with 0 RSS stays flat after
# warm-up). An add-on update needs no exit: the start of the FF service ends the reused interpreter.
# Only the calls run in the plugin interpreter count: with `const.tune.service.remote_plugin` the calls of a handle
# (folders, widgets) run warm in the service and never exit, the plugin runs only the rest (a play, RunPlugin, no service).
# New code of those service calls needs a new service (a Kodi restart, or `const.debug.autoreload`).
const.core.exit_every_nth = 0
# Exit (close Python interpreter) for every nth plugin calls in widgets (and other calls outside a FF folder, e.g. a play
# from Home). None: as `exit_every_nth`.
const.core.widgets_exit_every_nth = None
# Reload Kodi widgets after a progress change known only to FF (a mark from the FF menu, an account sync): Kodi reloads
# them only on its own events. WidgetsReload says how (an empty `videolibrary.showunwatchedplots` list), None: never.
const.core.widgets_reload = WidgetsReload.TWICE
# Use service to keep volatile DBID (for seasons only at the moment).
const.core.volatile_ffid = True
# Use volatile FFID in all sesons. It allows to monitor kodi operations on seasons.
# const.core.volatile_ffid needs to be set to True.
const.core.volatile_seasons = True
# How to watch list-item changes, ex. set (un)watched.
const.core.media_watched_mode = MediaWatchedMode.WATCH_LISTITEM

# Use advancedsettings.xml to determine kodi MyVideo DB.
const.core.kodidb.advanced_settings = True

# Save [ff]info media cache.
const.core.info.save_cache = True
# Copy year in FFItem.copy_from(), eg. episode from season and/or from tv-show.
const.core.info.copy_year = False



# --- Media (general) ---

# Service to get media details (tmdb, trakt).
const.media.aliases_service = 'tmdb'
# Default media request info details, see ffinfo.get_items(): every level carries its own data, a season / the season of
# an episode comes without its other episodes (lists, the played item, sources; a view of the episodes of a season asks
# for them, see `const.indexer.tvshows.episodes_details`).
const.media.info_details = 'DEFAULT, -SEASON_EPISODES'

# Watching percent count as watched, unless advancedsettings.xml sets it (`video/playcountminimumpercent`): Kodi's default.
const.media.progress.as_watched = 90
# Progress of accounts merged: 'union' - every field by its rule (watched by any account, the max play count,
# the newest resume point), 'first' - the first account (in order of accounts) with the media.
const.media.progress.merge = 'union'
# Removals in the merged progress: the newest event of the media wins - an unwatch (gone from the watched list of an
# account, or sent) newer than the watch of every account makes it unwatched, a removed resume point newer than the pause
# drops it. False: watched by any account, the newest resume point (the times are stored anyway).
const.media.progress.removals = True
# The same progress state within these differences (an account sync with no visible change is no change; the library
# alignment): the resume point (percent: a percent placed in the duration of a file, the rounding of a service).
const.media.progress.tolerance.resume = 1.0
# ... and the times of the watch, pause and removals (seconds: Trakt keeps the minute only).
const.media.progress.tolerance.time = MINUTE

# Media cache freshness policy (declarative; consumed by ffinfo.compute_expires_at).
# TTL by node age (now - reference date): the entry with the greatest threshold <= age wins
# (first-hit); the None-threshold entry is the TTL ceiling (no infinite TTL).
const.media.cache.ttl = (
    (0,         '6 * HOUR'),
    (7 * DAY,   '1 * DAY'),
    (30 * DAY,  '7 * DAY'),
    (365 * DAY, '30 * DAY'),
    (None,      '180 * DAY'),
)
# Proportional vigilance toward a known future event (premiere-if-ahead or next air):
# expire after this fraction of the way to the event (clamped to [vigilance_min, base_ttl]).
const.media.cache.vigilance_frac = 0.5
const.media.cache.vigilance_min = '6 * HOUR'
# Returning-status floor: poll a returning show at least this often when no next air is known.
const.media.cache.returning_poll = '7 * DAY'
# Keep expired rows this long before the service removes them (`known_ids()` reads them with no freshness filter).
const.media.cache.cleanup_grace = 30 * DAY

# External IDs of media (`media.db#ids`): links kept permanently, corrected by TMDB (its external IDs win).
# An external ID found nowhere, or a title TMDB has not (404, a removed entry), is asked again after this time
# (e.g. an IMDb ID added to TMDB later). "Clear media cache" drops these markers, the links stay.
const.media.ids.missing_ttl = DAY
# Correct the links by the changes of TMDB (the service: changed titles of the ID map get their TMDB IDs again).
const.media.ids.tmdb_changes = True
# Interval of the TMDB changes check (TMDB keeps 14 days of changes; a longer pause starts from 14 days ago).
const.media.ids.tmdb_changes_interval = DAY
# A media row of a title changed in TMDB is expired at once (fresh data on the next view, no request now).
const.media.ids.expire_changed = True

# ----- Lists -----

# List cache (`lists.db`): user lists of accounts, whole. TTL zero (setting `listCache` off) = no cache.
# A list the alive account sync watches (e.g. Trakt `last_activities`) has no deadline: the sync marks it stale.
# TTL of a list without a change signal (a public account, a list out of the buckets; also when the sync stops): an own
# change marks it stale.
const.lists.cache.ttl = '1 * HOUR if {listCache} else 0'
# Max age of a list of an alive sync watching it by a fingerprint (not a time of the service), seconds.
# A list the alive sync watches by a fingerprint (TMDB, IMDb, JustWatch: the count and the newest item, not a time of the
# service) is fetched after this age anyway: a fingerprint misses rare changes (a changed rating, a new order).
const.lists.cache.fingerprint_ttl = DAY
# Items of a list stored at most (a longer list is stored cut, the rest is fetched every time).
const.lists.cache.limit = 5000
# Keep expired lists this long (not lists of an alive sync): when the service fails, the last stored list is shown.
const.lists.cache.cleanup_grace = 7 * DAY
# General lists (TMDB discover, Trakt trending, search, TV program, ...; no account): TTL by the kind of the list
# (the call gives it). A page of the service is an entry; small or composed lists (box office, JustWatch, HTTP) whole.
const.lists.cache.general = {
    # discover (best, popular etc.), awards
    'discover': '24 * HOUR if {listCache} else 0',
    # trending, popular people, box office
    'trending': '1 * HOUR if {listCache} else 0',
    # lists of other users (Trakt, MDBList), top lists
    'lists':    '1 * HOUR if {listCache} else 0',
    # search (media, lists)
    'search':   '15 * MINUTE if {listCache} else 0',
    # new on VOD (JustWatch)
    'vod':      '6 * HOUR if {listCache} else 0',
    # own lists from HTTP(S)
    'http':     '1 * HOUR if {listCache} else 0',
    # TMDB configuration (languages, countries), genres, providers, images (gallery)
    'art':      '7 * DAY if {listCache} else 0',
    # filmography of a person (TMDB movie / TV / combined credits)
    'credits':  '24 * HOUR if {listCache} else 0',
    # TV program (parsed, by the service and the day), filmweb title previews
    'tv':       '1 * HOUR if {listCache} else 0',
}
# Pages of a general list stored at most (a further page is fetched every time).
const.lists.cache.page_limit = 25

# ----- Sources -----

# Search progress dialog display mode (SourceSearchProgressStyle enum).
#  - SIMPLE    - Combined sources (no premium/normal distinction).
#  - EXTENDED  - Combined with premium count in parentheses.
#  - FULL      - Separate lines for premium and normal sources.
const.sources_dialog.searching.progress_style = SourceSearchProgressStyle.FULL

# Show empty source window (no sources).
const.sources_dialog.show_empty = True
# Rescan button open "edit source search".
const.sources_dialog.rescan_edit = False
# The button of a rescan stays disabled so long after the end of a search (seconds): it takes the place of the button which stops the search,
# an OK late by a moment would search again.
const.sources_dialog.rescan_guard = 1.0
# Show limit time progress.
const.sources_dialog.time_progress = True
# Define quality label for external sources
# Avaiable: 4K, 1440p, 1080p, 720p, SD
# In local.py use:
# const.sources_dialog.external_quality_label = {**const.sources_dialog.external_quality_label, 'servicename': quality}
const.sources_dialog.external_quality_label = {
    'Netflix': '1080p',
    'amazon prime': '1080p',
    'max': '1080p',
    'disney+': '1080p',
    'bbc iplayer': '1080p',
    'curiosity stream': '1080p',
    'hulu': '1080p',
    'paramount+': '1080p',
    'player pl': '1080p',
    'polsat box': '1080p',
    'viaplay': '1080p',
    'sky showtime': '1080p',
    'UPC TV Go': '1080p',
    }
# Define priority to sort language type
# The panel of the filter of the sources window (over its right column): how many pixels it covers of the rows of the list (0: it
# starts at their right edge, -2: a gap of 2 pixels), its scale (1.0; 0.9: the whole panel smaller - it shows more, its texts smaller).
const.sources_dialog.filters.overlap = -2
const.sources_dialog.filters.scale = 1.0
# The tree of the panel of the filter is made again so often while a search brings new sources (seconds; the panel open).
const.sources_dialog.filters.refresh_interval = 1.5
const.sources_dialog.language_type_priority = {
    "lektor": 0,
    "dubbing": 1,
    "multi": 2,
    "napisy": 3,
    }
# Remove disabled hosts from sources list - default empty (eg. {'wplik', 'gofile'} )
const.sources_dialog.disabled_hosts = {
    'booster',
    'mega',  # Not supported by ResolveURL
    'buzz remux',  # RIP?
    'fd',  # RIP?
    'iframely',  # Not supported by ResolveURL
    'goo',  # RIP
    'bit',  # RIP
    'upvid',  # RIP
    'jetload',  # RIP
    'clip',  # RIP
    'wrzucaj',  # RIP (wrzucaj.pl down 2026-10)
    'flashx',  # RIP
    'streamsilk',  # RIP
}
# Show DRM sources from cda scrapper
const.sources_dialog.cda_drm = True
# Sources dialog: movie title
const.sources_dialog.movie_title_format = '[B]{title} ({year})[/B]'
# Sources dialog: episode title
const.sources_dialog.episode_title_format = '[B]{show.title} ({show.year})[/B] – {season}x{episode:02}. [B]{title}[/B]'
# Sources dialog: episode title (with episode group set).
const.sources_dialog.episode_group_title_format = '[B]{show.title} ({show.year})[/B] – {season}x{episode:02}. [B]{title}[/B] [s{ref.season:02}e{ref.episode:02}]'
# Witch poster to show in episode searching dialog ('show' or 'season' or 'episode').
# Remember, the episode poster is often missing, then season is using. If season is missing, then show poster is using.
const.sources_dialog.episode_poster = 'episode'
# Upper-case the texts of the tag in the top right corner of a source (PREMIUM, the name of the debrid, a text badge of a rule), as the provider names.
const.sources_dialog.tag_uppercase = True
# The texts of a source row of a colour of its own (the setting "Readable row texts"): the ones of the other brightness (dark on a light
# colour) for the whole row when they read better than its own ones (WCAG 2 contrast of its worst part) and its own ones are below
# `minimum` or the other ones are `gain` times better - a small gain does not swap the texts.
const.sources_dialog.row_contrast.minimum = 3.0
const.sources_dialog.row_contrast.gain = 1.5
# The constant badges of a source row by the colour mode (the setting "Provider color"; '*' - every mode): name -> badge
# (`SourceAttributeBadge`), None - none. The badges of the mode are '*' updated by the mode's own (one name: the mode's wins, None
# removes it). They come after the badges of the rules (`order` by default after every rule badge): a badge of a rule in their
# place takes its slot first (`slot`: the slot of its place, else the first free one). A value of a badge:
#   '=expr'   - a FF expression (as `settings.eval()`) for every row: `accent` (the colour of the provider in the accent mode, else ''),
#               `color` (the colour of the provider), `source` (the source); nothing ('' / None) - the badge not shown,
#   '{token}' - a style token (or an expression of the style, e.g. 'alpha({color.text}, 50%)': the theme, its variant, the skin).
# The separator of the left and the right part of a row: a line V of their joint (the part 'split', the slot 1 the whole height, 2 -
# its default - shorter), its style 'plain' (in its colour), 'sunken' or 'raised' (the images `badges/line.<style>.split.v.png`, no colour).
# Examples (local.py, one of them): no separator; a plain one; the whole height; a bar of the provider colour in every mode.
#   const.sources_dialog.const_badges['accent']['separator'] = None
#   const.sources_dialog.const_badges['accent']['separator']['style'] = 'plain'
#   const.sources_dialog.const_badges['accent']['separator']['slot'] = 1
#   const.sources_dialog.const_badges['*']['bar'] = SourceAttributeBadge(type='bar', panel='item', place='W', color='=color')
const.sources_dialog.const_badges = {
    '*': {},
    'accent': {
        'bar': SourceAttributeBadge(type='bar', panel='item', place='W', color='=accent'),
        'separator': SourceAttributeBadge(type='line', panel='split', place='V', slot=2, color='{color.separator.row}', style='sunken'),
    },
}
# A row of the sources window has only the badge slots its badges may fill (the rules `const.sources.rules`, the constant badges
# of every colour mode above, the tag of the way which opens the source) and this many spare slots more in every used place
# (never more than the row declares: `BADGE_SLOTS` in cdefs.py); a new badge rule in local.py generates the window again.
const.sources_dialog.badge_spare_slots = 1

# Add "edit source search" to video (movie, episode) context-menu.
const.sources_dialog.edit_search.in_menu = False
# Add "edit source search" to sources dialog.
const.sources_dialog.edit_search.in_dialog = True
# Add "edit source search" to sidebar.
const.sources_dialog.edit_search.in_filters = False
# Cache search given modifications. Names are SourceSearchQuery keys (lib.ff.sources.EDIT_QUERY_KEYS). Or None for disable.
#  - 'local_title'     - Title in local (API) language
#  - 'english_title'   - English title
#  - 'original_title'  - Original title
#  - 'year'            - Year of release/airdate
#  - 'season'          - Season number (only if const.sources_dialog.edit_search.show_granularity is 'season' or 'episode')
#  - 'episode'         - Episode number (only if const.sources_dialog.edit_search.show_granularity is 'episode')
#  - 'premiered'       - Premiered date (only for episode)
#  - 'episode_group'   - Episode group (TMDB ID)
#  - 'episode_offset'  - Episode number offset in the season (of the episode group)
const.sources_dialog.edit_search.cache = {'local_title', 'english_title', 'original_title', 'year', 'episode_group', 'episode_offset'}
# The show granularity (show, season, episode) to remember search modifications.
const.sources_dialog.edit_search.show_granularity = 'show'

# ----- Folders -----

#: Use cacheToDisk in xbmcplugin.endOfDirectory().
const.folder.cache_to_disc = False
#: How long wait for HTTP server sync on directory refresh.
const.folder.lock_wait_timeout = 2.0
#: Extra delay if refresh is detected to allow service close the "folder-ready" semaphore.
const.folder.refresh_delay = 0.7
#: Maximum time between each plugin read in kodi scan process: fast enter into seasons on show set (un)watched.
const.folder.max_scan_step_interval = 1.5
#: Save folder info into DB (old way). Use HTTP /folder instead.
const.folder.db_save = False
# If FF is called as script (handler == -1) and directory is building, try to refresh container.
const.folder.script_autorefresh = True
# When show previous page item (except first page even if 'always'):
#   - `never`        - never show
#   - `always`       - on every page (except first page)
#   - `on_last_page` - only on last page (except first page)
const.folder.previous_page = 'on_last_page'
# Maximum page number to jump to.
const.folder.max_page_jump = 500
# Item fanart fallback (None, 'landscape', ...). If None or when art is missing, plugin fanart is used.
const.folder.fanart_fallback = 'landscape'
# Auto category, how many parent labels to show in the folder label.
const.folder.category = 2
# Auto category, how many parent labels to show in the folder label for given skin.
const.folder.category_by_skin = {
    'skin.estuary': 1,
}
# Date format of the roles: when a list entry was added, when a history item was played, ... (ISO sorts well).
const.folder.role_date_format = '%Y-%m-%d'
# Format for future item (unaired, non-premiered).
const.folder.separator_label = '———————'

# Format for future item (unaired, non-premiered).
const.folder.style.future = '[COLOR darkred][I]{}[/I][/COLOR]'
# Format for item with role.
const.folder.style.role = '{item.label} [COLOR gray][{item.role}][/COLOR]'
# Style of the list entry data (added, rank, note of the user) at the top of the description, None - not shown.
const.folder.style.list_entry = '[COLOR gray]{}[/COLOR]'
# Format for broken items (not found in TMDB, shown as their list gave them; None - no style, no TMDB note in the plot).
const.folder.style.broken = '{} [COLOR red]![/COLOR]'
# Format for top position item.
const.folder.style.section_label = '––– [B]{}[/B] –––'
# Format for top position item.
const.folder.style.top = '[B]{}[/B]'
# Format for bottom position item.
const.folder.style.bottom = '[B]{}[/B]'
# Format for separator line.
const.folder.style.separator = None

# ----- Indexes -----

# Default region.
const.indexer.region = 'PL'
# Default view for list of lists (eg. mine).
const.indexer.lists_view = 'sets'
# View for "My Movies" / "My TV Shows" root folder (Trakt/TMDB watchlist, favorites, etc.).
const.indexer.my_lists_view = 'sets'
# Show or hide empty folder message (no content to display). Enter custom message or set True for default one.
const.indexer.empty_folder_message = True
# Default page size.
const.indexer.page_size = 20
# Default limit for "Add to…" for general lists.
const.indexer.add_to_limit = 100
# Number of movies/tv-shows from Trakt/TMDB trending used in "library", "add to…" etc.
const.indexer.trending_scan_limit = CONST_REF.indexer.add_to_limit
# Default view for media items in directory(alone=True). (eg. force tvshows for seasons or episodes).
# Key is a media type, valuse is a kodi content type (view).
const.indexer.default_alone_view = {
    # 'MIXED': 'videos',
    # 'season': 'tvshows',
    # 'episode': 'tvshows',
}
# Default view for media items in directory (alone=False) when item types are mixed (eg. movies and tv-shows in one folder).
const.indexer.default_mixed_view = 'videos'

# Fake thumb: alias to landscape (for episode) and poster (for other).
const.indexer.art.fake_thumb = True

# Style to update description (plot). Single '{…}' means progress formatting, double '{{}}' means description formatting.
const.indexer.progressbar.style = '[B]{progressbar} {percent}%[/B]\n{{}}'
# General progress bar source mode:
#   - 'none'                 - do not show progressbar at all
#   - 'watching'             - show video percent progress (PERCENT) if video progress >0% and < 100% else show nothing
#   - 'watched'              - show only watched videos (movies and episodes progresses are skipped)
#   - 'percent'              - show video percent progress
#   - 'percent_and_watched'  - show video percent progress and watched in background (use const.indexer.progressbar.watched.*)
const.indexer.progressbar.mode = 'watched'
# Progress bar width (number of characters).
const.indexer.progressbar.width = 40
# Fill element (watched) color (kodi color eg. darkred, FFCC9900).
const.indexer.progressbar.fill.color = 'darkgreen'
# Fill element (watched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.fill.char = 'l'
# Partial filled element (watched & unwatched) color (kodi color eg. darkred, FFCC5500).
const.indexer.progressbar.partial.color = 'darkgreen'
# Partial filled element (watched & unwatched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.partial.char = 'ı'
# Empty element (unwatched) color (kodi color eg. darkred, gray, FF999999 or empty).
const.indexer.progressbar.empty.color = 'gray'
# Empty element (unwatched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.empty.char = 'ı'
# Already watched element on watching again color (kodi color eg. darkred, gray, FF999999 or empty).
const.indexer.progressbar.watched.color = 'white'
# Already watched element on watching again character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.watched.char = CONST_REF.indexer.progressbar.empty.char

# No directory content: show no-content item.
const.indexer.no_content.show_item = True
# No directory content: show no-content notification.
const.indexer.no_content.notification = True
# An unknown URL called without a handle (RunPlugin, a script; no folder to show): show an "unknown link" notification.
const.indexer.no_content.script_notification = CONST_REF.indexer.no_content.notification

# Content view type for search folder.
const.indexer.search.view = 'tags'
# Ask user if sure on history clear.
const.indexer.search.clear_if_sure = True
# When to show numeric dialog to enter year:
#   - never         - never show numeric dialog
#   - context-menu  - add context menu to "new search"
#   - entry         - add separate entry "new search with year"
#   - always        - always show numeric dialog in "new search"
const.indexer.search.year_dialog = 'entry'
# General pattern for search movie or tv-show by year.
const.indexer.search.year_pattern = r'\b(?:y(?:ear)?:([12]\d{3}))|\(([12]\d{3})\)'
# Color for search query option (eg. "y:1987").
const.indexer.search.query_option_format = '[COLOR gray]{}[/COLOR]'
# Show multi search entry if True.
const.indexer.search.multi_search = True
# Limit of search results (0 means no limit).
const.indexer.search.limit = 0
# Remember the external searches (EPG context menu, other add-ons, skins) in the search history.
const.indexer.search.ext_history = False

# Show CM: "add to..." anything :-)
# Empty AddToMenu uses const.dialog.add_to.lists.services.
# AddToMenu with service name uses const.dialog.add_to.lists.services[service].
# AddToMenu with service and list adds item to the list without dialog.
const.indexer.context_menu.add_to = (
    # AddToMenu(name=L('Add to own favorites'), enabled=True, service='own', list=':favorites'),
    AddToMenu(name=L(30307, 'Add to...')),  # const.indexer.context_menu.add_to equivalent
    # AddToMenu(name=L('Add to library'), enabled='enable_library', service='library'),
    # AddToMenu(name=L('Add to trakt'), service='trakt'),  # TEST
    # AddToMenu(name='Add to logs (debug)', enabled='const.debug.add_to_logs', service='logs'),  # TEST
)

# -- Directories: movies

# Default region for movies.
const.indexer.movies.region = CONST_REF.indexer.region
# Sort by `movies.sort` option index (popularity, year, ...) in movie discovery.
const.indexer.movies.discover_sort_by = (
    'popularity.desc',
    'primary_release_date.desc',
    'title.asc',
)
#: Time in seconds for movies / episodes without duration.
const.indexer.movies.missing_duration = 0
#: Means future (not premiered yet) movie if no date (None/null).
const.indexer.movies.future_if_no_date = True
#: Generate date from "year" (year-01-01) value if no movie date defined.
const.indexer.movies.date_from_year = False
#: Future (not premiered yet) movie can by played.
const.indexer.movies.future_playable = True
# Movies in progress ("Watching now") in pages of this size, 0 - one page.
const.indexer.movies.resume.page_size = CONST_REF.indexer.page_size
# Number of movies from TMDB discovery (or Trakt) used in "library", "add to…" etc.
const.indexer.movies.discovery_scan_limit = CONST_REF.indexer.add_to_limit
#: Override vote count for top-rated movies.
const.indexer.movies.top_rated.votes = 300
#: Override vote count for movies by genre.
const.indexer.movies.genre.votes = 50
#: Override vote count for movies by year.
const.indexer.movies.year.votes = 100
#: List of movie genres (main menu level).    NOT USED NOW !!!
# const.indexer.movies.genre.menu = {
#     12, 14, 16, 18, 27, 28, 35, 36, 37, 53, 80, 99, 878, 9648, 10402, 10749, 10751, 10752,
# }
#: This is just a joke, so treat it as an Easter egg. Show hundreds of thousands production_companies.
const.indexer.movies.joke.production_company = False
#: This is just a joke, so treat it as an Easter egg. Show hundreds of thousands keywords.
const.indexer.movies.joke.keyword = False
# Number of last days to see movies in cinema.
const.indexer.movies.cinema.last_days = 60
# Number of next days to see movies in cinema (ongoing).
const.indexer.movies.cinema.next_days = 4
# Filter cinema movies by selected region.
const.indexer.movies.cinema.use_region = False

# Default TV Movies page size with movies details (for list_mode: media. mixed).
const.indexer.movies.tv.media_page_size = 25
# Default TV Movies page size with movies stubs (for list_mode: folders. direct. direct_or_folder).
const.indexer.movies.tv.stub_page_size = 0
# Default Movies in TV service (filmweb, onet, teleman or sequence of them).
const.indexer.movies.tv.service = ('filmweb', 'teleman')
# Movies in TV (fanfilm) list mode :
#   - media             - all movies found (could be many for one tv item)
#   - mixed             - movie if single or folder if many
#   - folders           - folder always
#   - direct            - movie if item has media-ref else ignore TV item (works only with teleman)
#   - direct_or_folder  - movie if item has media-ref else folder
const.indexer.movies.tv.list_mode = 'direct_or_folder'
# Content view for TV services menu.
const.indexer.movies.tv.service_view = 'sets'
# Sort TV movies:
#   - ''           - no sort (default order from service)
#   - 'aired_date' - by aired date
#   - 'title'      - by title
const.indexer.movies.tv.sort_by = 'aired_date'
# Range of day offset to show movies in TV service. -1 means yesterday, +1 - tomorrow etc.
# Any range is safe, services have their own limits.
const.indexer.movies.tv.day_range = range(-1, 3)
# Enabled TV channels in all services, or None if all are enabled.
# Names must match exactly channel name. Exceptions are possible, ex. remove space before last number, add/remove HD etc.
# Order is important when multiple programs from different channels have the same time.
const.indexer.movies.tv.channels = (
    'TVP 1', 'TVP 2', 'Polsat', 'TVN', 'TVN Siedem', 'TV Puls', 'TV4', 'Puls 2', 'TV6', 'HBO', 'HBO 2', 'HBO 3', 'Cinemax', 'Cinemax 2',
    'CANAL+', 'CANAL+ Film', 'CANAL+ Seriale', 'CANAL+ Family', 'CANAL+ 1', 'CANAL+ Discovery', 'CANAL+ 4K Ultra HD',
    'AXN', 'AXN White', 'AXN Black', 'AXN Spin', 'FX', 'FX Comedy', 'Comedy Central', 'Polsat Comedy Central Extra', 'Kino Polska',
    'Warner TV', 'ale kino+', 'Sundance Channel', 'FilmBox Extra HD', 'FilmBox Action', 'FilmBox Arthouse', 'FilmBox Premium HD',
    'Film Cafe', 'Red Carpet TV', 'Sci Fi Universal',
)
# Hour of day (0-23) to start a day in show movies in TV service. E.g. 3 means that movies aired after 3:00 belong to the next day, and movies aired before 3:00 belong to the previous day.
# NOTE: No supported well yet.
const.indexer.movies.tv.day_first_hour = 3
# Show non-id movies in filmweb TV service (usually documentaries, reportages, etc).
const.indexer.movies.tv.filmweb.show_non_id = True
# Short program description to skip TV item in filmweb TV service.
const.indexer.movies.tv.filmweb.skip_items = {
    'film dokumentalny',
    'felieton',
}
# Number of channel pages to scan in onet TV service. Total pages are 9.
const.indexer.movies.tv.onet.channel_page_count = 6
# Number of worker threads to scan channels in onet TV service. Scraping all 9 pages hangs a little.
const.indexer.movies.tv.onet.channel_worker_count = 3
# Obtain more data pre each TV item in onet TV service. It allows to filter out more items, but it is much slower.
const.indexer.movies.tv.onet.more_details = False
# Number of pages to scan in teleman TV service. Should be enough to match whole day for performance reasons.
const.indexer.movies.tv.teleman.pages_to_scan = 8

# New movies votes.
const.indexer.movies.new.votes = 50

# Movie style to update description (plot). Single '{…}' means progress formating, double '{{}}' means description formating.
const.indexer.movies.progressbar.style = CONST_REF.indexer.progressbar.style
# Movie progress bar source mode:
#   - 'none'                 - do not show progressbar at all
#   - 'watching'             - show video percent progress (PERCENT) if video progress >0% and < 100% else show nothing
#   - 'watched'              - show only watched videos (movies and episodes progresses are skiped)
#   - 'percent'              - show video percent progress
#   - 'percent_and_watched'  - show video percent progress and watched in background (use const.indexer.progressbar.watched.*)
const.indexer.movies.progressbar.mode = 'percent'
#: Movie progress bar width (number of characters).
const.indexer.movies.progressbar.width = CONST_REF.indexer.progressbar.width
# Pattern for search movie by year.
const.indexer.movies.search.year_pattern = CONST_REF.indexer.search.year_pattern

const.indexer.movies.images.art_type_folder = True
const.indexer.movies.images.label_format = ''

# -- Directories: tv-shows

# Default region for tv-shows.
const.indexer.tvshows.region = CONST_REF.indexer.region
# Sort by `tvshows.sort` option index (popularity, year, ...) in tv-show discovery.
const.indexer.tvshows.discover_sort_by = (
    'popularity.desc',
    'first_air_date.desc',
    'name.asc',
)
#: Means future (not aired yet) tvshow if no date (None/null).
const.indexer.tvshows.future_if_no_date = True
#: Override vote count for top-rated tv-shows.
const.indexer.tvshows.top_rated.votes = 200
#: Override vote count for tvshow by genre.
const.indexer.tvshows.genre.votes = 50
#: Override vote count for tvshow by year.
const.indexer.tvshows.year.votes = 100
#: List of tvshow genres (main menu level).    NOT USED NOW !!!
# const.indexer.tvshows.genre.menu = {
#     16, 18, 35, 37, 80, 99, 9648, 10751, 10759, 10762, 10764, 10765, 10766, 10767, 10768,
# }
#: This is just a joke, so treat it as an Easter egg. Show hundreds of thousands production_companies.
const.indexer.tvshows.joke.production_company = False
# Minimal number of votes in tv-show premier (new tv-shows).
const.indexer.tvshows.premiere.votes = 20

# What to show in progress folder.
const.indexer.tvshows.progress.show = 'episode'
# What to show in progress folder.
#   - last      - episode are calculated using the last aired episode the user has watched.
#   - continued - episode are calculated using last watched episode (last activity).
#   - first     - episode are calculated using first unwatched episode.
#   - newest    - episode are calculated using the last aired episode at all.
const.indexer.tvshows.progress.next_policy = 'last'
# If True, show next episode as link to season folder
# if False, show next episode as playable video.
const.indexer.tvshows.progress.episode_folder = True
# Focus next episode on episodes list.
const.indexer.tvshows.progress.episode_focus = True
# Select next episode on episodes list (not all skins handle it).
const.indexer.tvshows.progress.episode_select = False
# Format next episode on episodes list ('{}' means title, '{item}' is FFItem).
const.indexer.tvshows.progress.episode_label_style = None
# Show 100% watched shows in progress folder.
const.indexer.tvshows.progress.show_full_watched = False
# Show the shows with a started episode only (none watched) in progress folder, as Kodi "In progress TV shows" does;
# False - a show is in progress with a watched episode (the started one is in the episodes in progress anyway).
const.indexer.tvshows.progress.show_watching = False
# Media details of the shows in progress: all of them to tell the ones below 100 % and the shows of a page to find their
# next episodes (the season sizes and the next episode to air, no episodes, see `FFItem.surrogate_episode_refs()`).
const.indexer.tvshows.progress.show_details = 'DEFAULT'
# Shows in progress in pages of this size.
const.indexer.tvshows.progress.page_size = CONST_REF.indexer.page_size
# Pages of the shows in progress the service warms up (after the first sync of accounts and every progress change), 0 - none.
const.indexer.tvshows.progress.warm_pages = 1
# Time (s) a plugin call waits for the shows in progress from the service (it joins a running computation), then computes them itself.
const.indexer.tvshows.progress.service_wait = 120

# Number of days to see tvshows in trakt calendar
# +3 - 3 days after today date, -10 - 10 days before todays date
# Range must be lower than 33 days
const.indexer.tvshows.calendar_range = (+3, -10)
# Number of tv-shows from TMDB discovery (or Trakt) used in "library", "add to…" etc.
const.indexer.tvshows.discovery_scan_limit = CONST_REF.indexer.add_to_limit
# Get all seasons with details (including episodes) on every tv-show load.
const.indexer.tvshows.season_details = 'DEFAULT, SEASON_EN'
# Media details of a view of the episodes of a season (a season, a flat show, an episode group): the season with all its episodes.
const.indexer.tvshows.episodes_details = 'DEFAULT, SEASON_EPISODES'

# Pattern for search movie by year.
const.indexer.tvshows.search.year_pattern = CONST_REF.indexer.search.year_pattern

# -- Directories: seasons

#: Season label format if no season title, selected by user setting `tvshow.season_label`.
#: Season FFItem is available as `item`.
const.indexer.seasons.no_title_labels = (
    '{locale.season} {season}',  # option: Season 1
    '{locale.season} {season}',  # option: Season 1 – Title
    '{locale.season} {season}',  # option: 1. Title
)
# Season label format if season has its own title, selected by user setting `tvshow.season_label`.
# Season FFItem is available as `item`. `title` could be in English if there is no in api language.
const.indexer.seasons.with_title_labels = (
    '{locale.season} {season}',            # option: Season 1
    '{locale.season} {season} – {title}',  # option: Season 1 – Title
    '{season}. {title}',                   # option: 1. Title
)
# Season label format for alone season (season in list of any media, need to show show title too).
# 'label' is generateed from const.indexer.seasons.with_title_labels or const.indexer.seasons.no_title_labels.
const.indexer.seasons.alone_label = '{show.title} – {label}'
#: Force override season title by generated label. Should be false.
const.indexer.seasons.override_title_by_label = False
#: Means future (not aired yet) season if no date (None/null).
const.indexer.seasons.future_if_no_date = True

# -- Directories: episodes

# Time in seconds for movies / episodes without duration.
const.indexer.episodes.missing_duration = 0
# Means future (not aired yet) episode if no date (None/null).
const.indexer.episodes.future_if_no_date = True
# Generate date from "year" (year-01-01) value if no episode date defined.
const.indexer.episodes.date_from_year = False
# Future (not aired yet) episode can by played.
const.indexer.episodes.future_playable = True
# Episode label format. `title` could be in English if there is no in api language.
const.indexer.episodes.label = '{season}x{episode:02d}. {title}'
# Episode label format for alone episode (episode in list of any media, need to show show title too).
# 'label' is generateed from const.indexer.episodes.label.
const.indexer.episodes.alone_label = '{show.title} – {label}'
# Episodes in progress in pages of this size, 0 - one page.
const.indexer.episodes.resume.page_size = CONST_REF.indexer.page_size
# Episode style to update description (plot). Single '{…}' means progress formatting, double '{{}}' means description formatting.
const.indexer.episodes.progressbar.style = CONST_REF.indexer.progressbar.style
# Episode progress bar source mode:
#   - 'none'                 - do not show progressbar at all
#   - 'watching'             - show video percent progress (PERCENT) if video progress >0% and < 100% else show nothing
#   - 'watched'              - show only watched videos (movies and episodes progresses are skiped)
#   - 'percent'              - show video percent progress
#   - 'percent_and_watched'  - show video percent progress and watched in background (use const.indexer.progressbar.watched.*)
const.indexer.episodes.progressbar.mode = 'percent'
#: Episode progress bar width (number of characters).
const.indexer.episodes.progressbar.width = CONST_REF.indexer.progressbar.width

# -- Directories: anime

# Default region for anime or None. If you want to use default region use CONST_REF.indexer.region
const.indexer.anime.region = None
# Number of last days to see aired shows.
const.indexer.anime.aired.last_days = 14

# -- Directories: persons

# Enable person directory.
const.indexer.persons.enabled = True
# Number of persons from TMDB discovery (or Trakt) used in "library", "add to…" etc.
const.indexer.persons.discovery_scan_limit = CONST_REF.indexer.add_to_limit
# Show tv-shows with persons role as "Self".
const.indexer.persons.show.include_self = False

const.indexer.persons.images.art_type_folder = True
const.indexer.persons.images.label_format = 'aa'

# -- Directories: details

# Media details in details folder (and its sub-folders: genres, languages, countries, companies, networks, keywords).
const.indexer.details.info_details = 'DEFAULT, EPISODE_GROUPS, FACETS'

# Content view type for videos in details folder.
const.indexer.details.videos.view = 'studios'

# Crew details in details folder (.../info). AGGREGATE_CREDITS fetches aggregate_credits for
# show/season and plain credits for movie/episode (see create_append_to_response()).
const.indexer.details.credits.info_details = 'INFO_LANG, COMMON_DETAILS, AGGREGATE_CREDITS, IMAGES, TRANSLATIONS'

# -- Directories: stump idexers

# Number of votes in stump directories (campanies, keywords).
const.indexer.stump.votes = 0

# Search "first N keywords" folders. In order.
const.indexer.stump.keywords.search_n_keywords = (5, 3, 2)
# Enable select keywords dialog in keyword folders.
const.indexer.stump.keywords.select = True

# -- Directories: lists

# - trakt

# Trakt my list (list of the lists) view.
const.indexer.trakt.mine.view = CONST_REF.indexer.lists_view
#: Default trakt.tv list sorting ('.asc' could be replaced with '.desc'):
#: - 'trakt'          - trakt.tv settings (trakt user sets in WWW)
#: - 'added.asc'      - added time
#: - 'collected.asc'  - collection added time
#: - 'rank.asc'       - rank
#: - 'released.asc'   - movie/show released
#: - 'title.asc'      - movie/show title
#: - 'runtime.asc'    - movie/show runtime (duration)
#: - 'votes.asc'      - number of votes
#: - 'popularity.asc' - fake popularity (ranking is used)
#: - 'random'         - random order
const.indexer.trakt.sort.default = 'trakt'
#: Trakt.tv watchlist sorting.
const.indexer.trakt.sort.watchlist = 'added.desc'
#: Trakt.tv collection sorting.
#: NOTE: Mixed collection does NOT support 'trakt' sorting.
const.indexer.trakt.sort.collections = 'collected.asc'
#: Fix trakt sort order (X-Sort-how) to make 'asc' really ascending.
const.indexer.trakt.sort.reverse_order = {
    'added': False,
    'collected': True,
    'rank': False,
    'released': False,
    'title': False,
    'runtime': False,
    'votes': False,
    'popularity': False,
}

# - tmdb

# TMDB my list (list of the lists) view.
const.indexer.tmdb.mine.view = CONST_REF.indexer.lists_view

# - imdb

#: IMDB media list page size (NOTE: using IMDB ID is slow).
const.indexer.imdb.page_size = CONST_REF.indexer.page_size
#: IMDB my list (list of the lists) view.
const.indexer.imdb.mine.view = CONST_REF.indexer.lists_view

# - mdblist lists

# MDBList enabled if true.
const.indexer.mdblist.enabled = True
# MDBList media list page size.
const.indexer.mdblist.page_size = CONST_REF.indexer.page_size
# MDBList list of lists page size (e.g. top lists). Up to 100. Zero means no pagination (all lists on one page).
const.indexer.mdblist.lists_page_size = 50
# MDBList my list (list of the lists) view.
const.indexer.mdblist.mine.view = CONST_REF.indexer.lists_view
# MDBList my list (list of the lists) view.
const.indexer.mdblist.top.view = CONST_REF.indexer.lists_view

# - menus of lists: the folders, the general lists and their places are the user settings (lib/ff/lists_config.py)

# - wetrakr general lists (the accounts: `const.accounts.wetrakr.enabled`)

# WeTrakr general lists (trending, popular, ...) enabled if true; they need a WeTrakr account (its token).
const.indexer.wetrakr.enabled = True
# WeTrakr media list page size.
const.indexer.wetrakr.page_size = CONST_REF.indexer.page_size

# - justwatch (vod) lists

# JustWatch general lists (new VOD) enabled if true (the user switches them in the menus: not in the lists by default).
const.indexer.justwatch.enabled = True
# New VoD titles (also of /movie, /show): time window (days); the VOD services are of the user (lists settings).
const.indexer.justwatch.new_vod.days = 3
# JustWatch media list page size.
const.indexer.justwatch.page_size = CONST_REF.indexer.page_size

# - floppy lists

# Floppy media list page size.
const.indexer.floppy.page_size = CONST_REF.indexer.page_size

# - user own lists

# Own media list page size.
const.indexer.own.page_size = CONST_REF.indexer.page_size
# Own my list (list of the lists) view.
const.indexer.own.mine.view = CONST_REF.indexer.lists_view
# Role for flat root lists if list is direct (media type, not items from flated list of lists).
# String or "{name}" or "" for no role.
const.indexer.own.mine.root_direct_role = ''
# Own custom lists.
const.indexer.own.lists = (
    OwnListDef('/', 'list', 'db://own/'),
    # XXX EXAMPLE – REMOVE IT
    # OwnListDef('Argentyńske seriale kryminalne z odcinkami poniżej 30 min', 'show',
    #            'tmdb://show?with_origin_country=AR&with_genres=80&sort_by=first_air_date.desc&with_runtime<30',
    #            icon='https://www.themoviedb.org/t/p/w600_and_h900_bestv2/dtfwJKDN3cinNpXw86r89TUpuc8.jpg'),
    # OwnListDef('Łubu dubu', 'list', 'profile://example-list_of_lists.csv',
    #            icon='https://png.pngtree.com/png-clipart/20191123/original/pngtree-list-icon-png-image_5194124.jpg'),
    # OwnListDef('Abc', 'person', 'profile://example-list_of_lists.csv'),
)

# - history

# Show watching videos (partial watched, even if not played) in history folder.
const.indexer.history.show_watching = False
# Role of played items (the history, watching now): `played_at` (local), `percent`, `play_count`, `pb`; `{date}` is
# `const.folder.role_date_format`. None - no role.
const.indexer.history.role = '{played_at:{date}}'
#: How many items get from hostory in "Add to...".
const.indexer.history.limit = CONST_REF.indexer.add_to_limit

# - continue watching (the movies and episodes with a resume point and the shows in progress, the latest touched first)

# View of the folder: one for every page, whatever media the page has (movies and episodes mixed).
const.indexer.progress.view = 'videos'
# If True, the next episode of a show is a link to its season folder; if False, it is played (as a resume point always is).
const.indexer.progress.episode_folder = CONST_REF.indexer.tvshows.progress.episode_folder
# The folder in pages of this size.
const.indexer.progress.page_size = CONST_REF.indexer.page_size

# - tools

# Content view type for tools folders.
const.indexer.tools.view = 'sets'
# Show "Select Theme" in tools menu.
const.indexer.tools.select_theme = True
# Show "External Addons" in tools menu.
const.indexer.tools.external_addons = True
# Show "Synchronize accounts" in tools menu (if any account syncs).
const.indexer.tools.sync_entry = True

# -- Genre menu

#: Fix TMDB genres translations [kodi-language][tmdb-genre-id].
const.indexer_group.genres.translations = {
    'pl-PL': {
        10762: 'Dla dzieci',
        10763: 'Informacje',
        10764: 'Reality TV',
        10766: 'Romans',
        10767: 'Talk Shows',
        10768: 'Wojna i polityka',
        10770: 'Filmy telewizyjne',
    },
}
# Genre icons active set (fanfilm, kodi).
const.indexer_group.genres.icons_set = 'fanfilm'
# Genre icons by TMDB genre ID (is active icons_set).
const.indexer_group.genres.icons = {
    'fanfilm': {
        12: 'genres/Adventure.png',
        14: 'genres/Fantasy.png',
        16: 'genres/Animation.png',
        18: 'genres/Drama.png',
        27: 'genres/Horror.png',
        28: 'genres/Action.png',
        35: 'genres/Comedy.png',
        36: 'genres/History.png',
        37: 'genres/Western.png',
        53: 'genres/Thriller.png',
        80: 'genres/Crime.png',
        99: 'genres/Documentary.png',
        878: 'genres/Sci-Fi.png',
        9648: 'genres/Mystery.png',
        10402: 'genres/Music.png',
        10749: 'genres/Romance.png',
        10751: 'genres/Family.png',
        10752: 'genres/War.png',
        10759: 'genres/Action_and_Adventure.png',
        10762: 'genres/Kids.png',
        10763: 'genres/News.png',
        10764: 'genres/Reality_show.png',
        10765: 'genres/Sci_fi_and_fantasy.png',
        10766: 'genres/Romance.png',
        10767: 'genres/Television.png',
        10768: 'genres/Historical.png',
        10770: 'genres/Television.png',
    },
    'kodi': {
        12: 'resource://resource.images.moviegenreicons.white/Adventure.jpg',
    }
}

# -- Language menu

#: Set of favorite languages.
const.indexer_group.languages.default = {
    'cs', 'de', 'en', 'es', 'fr', 'it', 'ja', 'ko', 'pl', 'sv', 'uk', 'zh',
}
#: Set of top languages from favorites. Current Kodi language will be on top too.
const.indexer_group.languages.top = {
    'pl',
}
#: Custom language groups. Use `|` for OR, `,` for AND.
const.indexer_group.languages.groups = (
    # DirItemSource('pl|lt|uk|be', "I Rzeczpospolita"),
)
#: Override vote count for media by language. None for use default.
const.indexer_group.languages.votes = 0

# -- Country menu

#: Set of favorite countries.
const.indexer_group.countries.default = {
    'GB', 'CN', 'CZ', 'DE', 'DK', 'ES', 'FR', 'IT', 'JP', 'KR', 'PL', 'SE', 'UK', 'US',
}
#: Set of top countries from favorites. Current Kodi region will be on top too.
const.indexer_group.countries.top = {
    'PL',
}
#: Custom country groups. Use `|` for OR, `,` for AND.
const.indexer_group.countries.groups = (
    DirItemSource('DK|FI|IS|NO|SE', L(30102, 'Scandinavian')),  # Scandinavian
)
#: Override vote count for media by country. None for use default.
const.indexer_group.countries.votes = 0


# ----- tmdb.org settings -----

# Total count of append_to_reposnse items is 20 (TMDB API).
const.tmdb.append_to_response_limit = 20
# Default languages used in `include_image_language` when info get with `append_to_response=images`.
# const.tmdb.image_languages = all_languages
# Mode of image getting:
#   - append       - use `append_to_response=images` with fixed `include_image_language`, no poster at all often
#   - append_en    - use `append_to_response=images` with fixed `include_image_language=en`
#   - append_lang  - use `append_to_response=images` with fixed `include_image_language={lang}`
#   - pull         - like `append` but get images in next request if fails (no images)
#   - full         - always make two requests, support all services (it is forced for non-tmdb services, e.g. fanart.tv)
#   - all          - use /images to get all images in concurrent request
const.tmdb.get_image_mode = 'append'
const.tmdb.include_nolang_images = False
# Langauge code aliases. Non-ISO-631-1 TMDB extensions.
const.tmdb.language_aliases = (
    ('zh', 'cn'),
)
# Maximum number of HTTP threads in TMDB skeleton.
const.tmdb.skel_max_threads = 10
# Discover items without keywords IDs.
const.tmdb.avoid_keywords = (
    155477,  # softcore
)

# API version (most endpoints uses v3 and v3 could be generated from v4).
const.tmdb.auth.api = 4
# API auth dialog - refresh interval in seconds (ask TMDB for token and update progress).
const.tmdb.auth.dialog_interval = 5
# API auth dialog - expiration time in seconds, max is 900 – TMDB remove token after 15 min.
const.tmdb.auth.dialog_expire = 300
# TMDB auth link QR-Code scale.
const.tmdb.auth.qrcode_size = 10

# Number of tries to send request to TMDB.
const.tmdb.connection.try_count = 3
# Number of seconds between TMDB connection tries.
const.tmdb.connection.try_delay = 1.0
# TMDB request timeout.
const.tmdb.connection.timeout = 15
# TMDB common request session (for all threads).
const.tmdb.connection.common_session = True
# The concurrent connections to TMDB: the requests of a map of many (details of a list, IDs, pages) in as many threads,
# the HTTP pool of the session and the limit of all the requests of a client (independent of `threads.count`, which is
# sized for the source scrapers).
const.tmdb.connection.max = 48


# ----- trakt.tv settings -----

#: How many items get from recomendations in "Add to...".
const.trakt.recommendations_limit = CONST_REF.indexer.add_to_limit
#: Page size (page limit) in trakt.tv for directory.
const.trakt.page.limit = 20
#: Page limit in scan all pages in trakt.tv. DO NOT edit.
const.trakt.scan.page.limit = 100
#: Max concurrent requests when scanning all pages in trakt.tv (independent of
#: threads.count, which is sized for scraper providers, not Trakt's rate limits).
const.trakt.scan.page.workers = 5
#: Default sync video -> trakt for alien video (plugins and all non-FF3 sources).
const.trakt.sync.alien.default = False
#: Tune alien video -> trakt URL schema sync: {schema: True/False}.
const.trakt.sync.alien.scheme = {
    # 'plugin': False,   # all plugins are not synced by default, you could stil filter by const.trakt.sync.alien.plugins
    # 'file': True,      # all local files are synced
}
#: Tune alien plugins video -> trakt sync: {plugin_id: True/False}.
const.trakt.sync.alien.plugins = {
    # 'plugin.video.my_super_extra_plugin': False,
    # 'plugin.video.nothing1': True,
}
#: Auto Trakt.tv auth. Register device every time if got 403.
const.trakt.auth.auto = False
#: Trakt.tv auth link QR-Code scale.
const.trakt.auth.qrcode.size = 20
#: Timeout in seconds of token refresh done by the service (plugin waits for it, refresh could wait for Retry-After up to 60s).
const.trakt.auth.service_timeout = 90

# Number of tries to send request to trakt.tv.
const.trakt.connection.try_count = 3
# Number of seconds between trakt.tv connection tries.
const.trakt.connection.try_delay = 1.0
# Trakt.tv request timeout.
const.trakt.connection.timeout = 15
# Trakt.tv close to token expire time in seconds to refresh access token.
const.trakt.connection.close_to_token_expire = 3600

# ----- mdblist.com settings -----

# Number of tries to send request to trakt.tv.
const.mdblist.connection.try_count = 3
# Number of seconds between trakt.tv connection tries.
const.mdblist.connection.try_delay = 1.0
# Trakt.tv request timeout.
const.mdblist.connection.timeout = 15
# Seconds before the access token (30 days) expires when it is refreshed.
const.mdblist.auth.refresh_before = 3 * DAY


# ----- account types -----

# Account types available if true. Low-level tuning for who does not want the accounts of a type at all: none can be
# added, the existing ones are hidden (their data stay). What an account does is set in the account (`/accounts` of `config.json`).
# General lists of a type: `const.indexer.<type>.enabled`. The local Kodi is always there.
const.accounts.trakt.enabled = True
const.accounts.tmdb.enabled = True
const.accounts.mdblist.enabled = True
# WeTrakr (the production key of the app: max(2000, 300 * users) requests a day, 300 per account).
const.accounts.wetrakr.enabled = True
# Floppy (self-hosted trackers, a server per account).
const.accounts.floppy.enabled = True
const.accounts.imdb.enabled = True
# FanFilm own lists (local).
const.accounts.own.enabled = True
# A change of an account not delivered to its service (no connection, a sign-in waited for) waits at most this long, then
# it is given up (logged, the bucket of the account synced again). It is sent again at every sync (`const.accounts.sync.interval`),
# the changes of the account in order: one not delivered stops the next ones.
const.accounts.pending.max_age = 30 * DAY
# A change the service does not take (a server error, an error of the client) is given up this long after its first failed
# delivery (as `max_age`), so the next changes of the account are not stopped for longer.
const.accounts.pending.max_retry = DAY
# The sync of accounts (Trakt, MDBList, WeTrakr: progress, watched, lists, ratings; TMDB, IMDb, JustWatch: fingerprints of
# the lists, ratings) in the service.
# The first one after the service starts (seconds).
const.accounts.sync.startup_interval = 3
# The cyclic one: a check of changes, a request per account (MDBList: 96 a day of the free 1000; WeTrakr: the interval its
# author advises). A sync asked for (the window of accounts, Tools) runs at once.
const.accounts.sync.interval = 15 * MINUTE
# While nobody uses Kodi (no input for the interval above and nothing plays, `lib.ff.kotools.idle_time()`) the cyclic
# one waits up to this long (seconds, 0: it does not wait); it runs at once when Kodi is used again.
const.accounts.sync.idle_interval = HOUR
# The cyclic one of the types with fingerprints of their lists (TMDB, IMDb, JustWatch: no activities, the fingerprints
# cost more requests); in the cycle above, when it is due.
const.accounts.sync.fingerprint_interval = 15 * MINUTE
# Delay of the notification of the sync in progress (hidden if the sync takes less).
const.accounts.sync.notification_delay = 3
# Timeout of waiting for the sync asked for (Tools: its result).
const.accounts.sync.wait_for_service_timeout = 180
# The delivery of the waiting changes waits for the end of a series of them (the library alignment, a native mark of a
# show: a change per episode): this quiet after the last one (seconds), at most this long since the first one; the rows of
# the accounts have the changes at once, only the sending waits. A sync asked for or the cyclic one does not wait.
const.accounts.sync.delivery_quiet = 2
const.accounts.sync.delivery_max_wait = 30
const.accounts.justwatch.enabled = True
# Remote kodi accounts (Kodi JSON-RPC) – NOT IMPLEMENTED YET.
const.accounts.kodi.enabled = False


# ----- wetrakr.com settings -----

# Number of tries of a wetrakr.com request (a connection error, 429, 5xx; `Retry-After` of the answer wins).
const.wetrakr.connection.try_count = 3
# Seconds between the tries.
const.wetrakr.connection.try_delay = 2.0
# Request timeout.
const.wetrakr.connection.timeout = 15
# Requests at once per account (the app limits of WeTrakr from 2026-10-18: 10 reads and 2 writes per user).
const.wetrakr.concurrency.read = 10
const.wetrakr.concurrency.write = 2
# Seconds before the access token (7 days) expires when it is refreshed.
const.wetrakr.auth.refresh_before = DAY


# ----- Floppy (self-hosted) settings -----

# Number of tries of a Floppy request (a connection error, 429, 5xx; `Retry-After` of the answer wins).
const.floppy.connection.try_count = 3
# Seconds between the tries.
const.floppy.connection.try_delay = 2.0
# Request timeout (a self-hosted server may be slow).
const.floppy.connection.timeout = 20
# Seconds before the access token (1 hour) expires when it is refreshed.
const.floppy.auth.refresh_before = 5 * MINUTE


# ----- justwatch.com settings -----

#: Max episodes in JustWatch requests
const.justwatch.episode_max_limit = 100
#: JustWatch request timeout.
const.justwatch.connection.timeout = 15

# All VoD services in PL (clearName / shortName), used in const.indexer.movies/tvshows:
#   'Amazon Prime Video' (prv)    'Amazon Video' (amz)
#   'Apple TV' (atp)              'Apple TV Store' (itu)
#   'Arte' (art)                  'CANAL+' (cpr)
#   'CDA Premium' (cda)           'CHILI' (chi)
#   'Cinema City' (cct)           'Cultpix' (ctx)
#   'Curiosity Stream' (cts)      'Disney Plus' (dnp)
#   'DocAlliance Films' (daf)     'DOCSVILLE' (dsv)
#   'FilmBox+' (flb)              'Filmzie' (fmz)
#   'HBO Max' (mxx)               'Helios' (hlo)
#   'MUBI' (mbi)                  'MultiKino' (mko)
#   'Netflix' (nfx)               'Pilot WP' (pwp)
#   'Player' (plp)                'Plex' (plx)
#   'Polsat Box Go' (pbg)         'Rakuten TV' (wki)
#   'SkyShowtime' (sst)           'True Story' (trs)
#   'TVP' (vtp)                   'Viaplay Amazon Channel' (vpy)


# ----- sources settings / tune -----

# All video duration ε, how big the video duration discrepancy can be (0.05 mens 5%).
const.sources.duration_epsilon = .08

# How long the subtitles downloaded by providers live (seconds, the temp folder of FanFilm): needed while the video plays.
const.sources.subtitles_max_age = DAY

# The keyword to detect whether we are dealing with anime
const.sources.check_anime = 'anime'

# List of keywords to exclude sources if found in description or link.
# const.sources.exclude_keywords = ["CAM", "TS", "HD-TS", "lektor AI"]
const.sources.exclude_keywords = ()

# The keys of the user filters and sorting of the sources (lib/ff/source_keys.py) left out: the frame height (the quality tells it), the
# frame rate (almost no source tells it).
const.sources.filters.skip_keys = ('video.height', 'video.fps')
# The ways a language is given in their default order (the localization of the sorting without its own order: the languages of
# `providers_lang`, then other ones, then unknown, each in these ways): a voice-over, a dubbing, unknown, the original audio,
# the subtitles, an audio description.
const.sources.filters.ways = ('lektor', 'dubbing', '', 'original', 'subtitles', 'audio_description')
# The simple view of the filter and the sort has no sets (the sets of the advanced view are of any filter, also in the configuration window).
const.sources.filters.simple_hides_sets = True
# The values of one source in the panel of the filter ("Change the filter…"): the name of the key only at the hosting and the provider
# (`Hosting: rapidgator.net`, `WEBRip`, `MKV`), False: at every value (`Release source: WEBRip`; a long one is cut in its row).
const.sources.filters.short_source_values = True

# Sources rules, color, order, play mode, etc.
# Order does matter, last rule is more important. Only defined attributes override previous one.
# Use `SourceSelector(): False` to disable the source at all.
# Default rules always should be applied. For update in `local.py` use:
# >>> const.sources.rules = {
# >>>     **const.sources.rules,  # IMPORTANT! Keep default rules, then add your own.
# >>>     SourceSelector(…): SourceAttribute(…),
# >>> }
# For color and order attributes description see SourceAttribute class in cdefs.py.
# All matched rules are applied, until the first with `final=True`. The rules are applied in the filter of every search
# (the source as it is then: its ways to open it, its facts), a later matching rule (not `False`) enables it again.
#
# == Pattern (see SourceSelector, RegEx, Glob, Expr from cdefs.py) ==
# Only used attributes are checked, e.g. SourceSelector(provider='tb7') check only provider, other attributes are ignored.
#   - addon    – source addon (full ID) with it's providers, e.g. 'plugin.video.fanfilm.tele'. Empty ("") means the FanFilm addon itself, None means any addon.
#   - provider – source provider, e.g. 'tb7', 'xt7', 'external', 'wizjacc', etc.
#   - platform – source platform, e.g. 'android', 'windows', etc.
#   - kodi     – [int] Kodi version (int or conditional expression with Kodi version, e.g. '>= 22').
#   - hosting  – source hosting, e.g. 'player', 'lulustream', etc.
#   - setting  – user setting, e.g. 'isa.enabled' (bool or conditional expression with settings, e.g. 'settings..image.quality > 1').
#   - m3u8     – [bool] source is m3u8 (True) or not (False).
#   - premium  – [bool] source is premium (True) or not (False). Taken from source meta['premium'].
#   - meta     – source meta, e.g. {'size': '1 KB'} one or more, only used keys are checked, e.g. other keys are ignored.
#   - size     – [int] source size in bytes (int or conditional expression with size, e.g. 'size > 1 * MB'). Calculated from source meta['size'].
#   - media    – real media type, e.g. 'movie', 'episode'.
#   - resolvability – the ways to open the source (Resolvability: routes, best, cached, debrid), e.g. {'cached': False}:
#                a torrent a debrid which tells it has not cached and no debrid has (True: one has it, None: none tells it).
#   - facts    – the facts of the source (given by the provider and parsed: video, audio, subtitles, release),
#                e.g. {'audio': {'lang': 'pl', 'kind': 'lektor'}}.
# All patterns are compared to value (str, int, bool) or one of patterns RegEx, Glob, Expr (any type) or range (if int).
# A dict pattern (meta, resolvability, facts) matches a dict by its keys or an object by its attributes, nested, only
# its keys are checked; a list value (audio tracks, ways, HDR formats) matches if one of its items matches. A None value
# is no condition: "not known" (e.g. cached None) by Expr('{} is None').
#   - RegEx is full mached regular expression, e.g. RegEx('tb7') or R('tb7|xt7|gb7').
#   - Glob is full mached glob pattern, e.g. Glob('tb*7') or G('tb?').
#   - Expr is conditional expression with variables,
#     - use `{}` for value, e.g. size=Expr('2*GB < {} < 3*GB')
#     - just use simple compare, e.g. kodi=Expr('< 22')
#     - you can use settings, e.g. Expr('settings.image.quality > 1') or Expr('settings.getBool("isa.enabled")'),
#       the names are these of `setting` (const, settings, units, e.g. Expr('{} > 2 * HOUR')).
#     - you can use the user configuration (config.json) by a JSON Pointer, e.g. Expr("{} < config('/a/b', 0) * GB")
#       or SourceSelector(setting="config('/a/b')"): config(pointer, default=None).
#
# == Attribute (see SourceAttribute from cdefs.py) ==
# Only used attributes are set, e.g. SourceAttribute(menu=('buy', 'play'))
#   - color – force source background item color, e.g. 'FF990000' (ARGB hex), over the color of the tree of the source providers.
#   - default_color – the color if no node of the branch of the source in the tree of the source providers has one.
#   - default_priority – the priority (0-10, bigger first) if no node of the branch of the source in the tree has one.
#   - order – force source order (the whole order, not the priority of the tree), bigger value are more important:
#     - +2001..+2006:  download, local, plex, jellyfin, external
#     - +1000:         account (already bought, in library, etc.)
#     - 0..999:        providers
#   - play – force play mode: 'auto', 'direct', 'isa'.
#   - menu – set menu items, sequence of 'direct', 'isa', 'play', 'buy'.
#   - meta – update source meta, e.g. {'info': 'zz', 'language': 'pl'} , only defined keys are set. Update is done on filtering beginning.
#   - final – if True, stop processing rules, no more rules will be applied after this one.
#
const.sources.rules = {
    # buy again CM
    SourceSelector(provider=R('tb7|xt7|gb7')): SourceAttribute(menu=('buy', 'play')),
    # default for m3u8 (url or filename) when setting is enabled
    SourceSelector(m3u8=True, setting='isa.enabled'): SourceAttribute(play='isa'),
    # default for non-m3u8 (another file or setting is disabled)
    SourceSelector(setting='not isa.enabled'): SourceAttribute(play='direct'),
    SourceSelector(m3u8=False): SourceAttribute(play='direct'),
    # some not-working ISA
    SourceSelector(hosting='player', platform='android'): SourceAttribute(play='direct'),
    SourceSelector(hosting='lulustream', platform=R('android|windows')): SourceAttribute(play='direct'),
    # default for external
    SourceSelector(provider='external'): SourceAttribute(play='direct', menu=()),
    # premium sources before the free ones (no priority in the tree of the source providers)
    SourceSelector(premium=True): SourceAttribute(default_priority=1),
    # providers on Kodi 22+
    # SourceSelector(provider='example_of_only_kodi_22_scraper', kodi=Expr('< 22')): False,
}

# Dictionary for franchise names to check in sources.
# Use example: "search phrase": ["franchise1", "franchise2"]
const.sources.franchise_names = {
    'JAG': ['JAG', 'Wojskowe Biuro Śledcze', 'Wojskowe Biuro Sledcze', 'J. A. G.'],
    # Star Wars seriale
    'Acolyte': ['Star Wars The Acolyte', 'Gwiezdne Wojny Akolita'],
    'Andor': ['Star Wars Andor', 'Gwiezdne Wojny Andor'],
    'Ahsoka': ['Star Wars Ahsoka', 'Gwiezdne Wojny Ahsoka'],
    'Mandalorian': ['Star Wars The Mandalorian', 'Gwiezdne Wojny Mandalorian'],
    'Boba Fett': ['Star Wars The Book of Boba Fett', 'Gwiezdne Wojny Księga Boby Fetta'],
    'Bad Batch': ['Star Wars The Bad Batch', 'Gwiezdne Wojny Zła Partia'],
    'Visions': ['Star Wars Visions', 'Gwiezdne Wojny Wizje'],
    # Star Wars filmy
    'Episode I': ['Star Wars Episode I The Phantom Menace', 'Star Wars I The Phantom Menace', 'Gwiezdne Wojny Mroczne Widmo', 'Gwiezdne Wojny Część I Mroczne Widmo'],
    'Episode II': ['Star Wars Episode II Attack of the Clones', 'Star Wars II Attack of the Clones', 'Gwiezdne Wojny Atak Klonów', 'Gwiezdne Wojny Część II Atak Klonów'],
    'Episode III': ['Star Wars Episode III Revenge of the Sith', 'Star Wars III Revenge of the Sith', 'Gwiezdne Wojny Zemsta Sithów', 'Gwiezdne Wojny Część III Zemsta Sithów'],
    'Episode IV': ['Star Wars Episode IV A New Hope', 'Star Wars IV A New Hope', 'Gwiezdne Wojny Nowa Nadzieja', 'Gwiezdne Wojny Część IV Nowa Nadzieja'],
    'Episode V': ['Star Wars Episode V The Empire Strikes Back', 'Star Wars V The Empire Strikes Back', 'Gwiezdne Wojny Imperium Kontratakuje', 'Gwiezdne Wojny Część V Imperium Kontratakuje'],
    'Episode VI': ['Star Wars Episode VI Return of the Jedi', 'Star Wars VI Return of the Jedi', 'Gwiezdne Wojny Powrót Jedi', 'Gwiezdne Wojny Część VI Powrót Jedi'],
    'Episode VII': ['Star Wars Episode VII The Force Awakens', 'Star Wars VII The Force Awakens', 'Gwiezdne Wojny Przebudzenie Mocy', 'Gwiezdne Wojny Część VII Przebudzenie Mocy'],
    'Episode VIII': ['Star Wars Episode VIII The Last Jedi', 'Star Wars VIII The Last Jedi', 'Gwiezdne Wojny Ostatni Jedi', 'Gwiezdne Wojny Część VIII Ostatni Jedi'],
    'Episode IX': ['Star Wars Episode IX The Rise of Skywalker', 'Star Wars IX The Rise of Skywalker', 'Gwiezdne Wojny Skywalker. Odrodzenie', 'Gwiezdne Wojny Część IX Skywalker. Odrodzenie'],
    'Rogue One': ['Rogue One A Star Wars Story', 'Łotr 1. Gwiezdne Wojny – Historia'],
    'Solo': ['Solo A Star Wars Story', 'Han Solo. Gwiezdne Wojny – Historie'],
    # Inne filmy
}
# Dictionary for franchise names seperator.
const.sources.franchise_names_sep = r'[ .]'
# List of supported source languages.
const.sources.language_order = (
    'pl',
    'mul',
    'multi',
    'en',
    'de',
    'fr',
    'it',
    'es',
    'pt',
    'ko',
    'ru',
    '-',
    '',
)
# Default timeout of provider (sources scraper) request in seconds.
const.sources.request_timeout = 15
# The User-Agent of a browser of the providers and the resolvers (`CHROME_UA`, `EDGE_UA`, `DEFAULT_UA` of `lib.ff.source_utils`):
# False - the fixed one of the code; True - a Chrome derived from the date (a service may exclude a single User-Agent, the fixed one
# all installations send): the version of `anchor` (version, its stable release day) plus one per `step` days (Google changed the
# cadence from 4 to 2 weeks at 153), minus a `margin` and on a system of `systems`, both chosen by the random number of the
# installation (kept in the provider data: cleared with them).
const.sources.user_agent.auto = False
const.sources.user_agent.anchor = (153, '2026-08-26')
const.sources.user_agent.step = 14
const.sources.user_agent.margin = (2, 3, 4)
const.sources.user_agent.systems = ('Windows NT 10.0; Win64; x64', 'X11; Linux x86_64', 'Macintosh; Intel Mac OS X 10_15_7')
# Use FanFilm's custom resolvers (lib/resolvers/) for hosts where we maintain
# our own implementation. When False every URL goes straight to upstream
# script.module.resolveurl. See lib/resolvers/__init__.py.
const.sources.local_resolvers = True
# External add-ons with FanFilm scrapers: the names reserved for FanFilm (any case, with a version too: "FanFilm 3", "FF3";
# not with more words: "FanFilm mod"); an add-on of such a name (addon.xml) or short name (of its ID) is named by its ID.
const.sources.addons.forbidden_names = ('fanfilm', 'ff')
# The native providers in the tab of the source providers: groups of their members (not of their folder), after the folder
# groups in this order; a provider of the group name is the group itself (its settings, its sub-sources as leaves).
const.sources.providers.groups = {
    'external': ProviderGroup(label=L(30639, 'Kodi add-ons'), members=('external', 'dramaqueen', 'jellyfin', 'jellyfin_direct', 'plex', 'stalkervod', 'giptv')),
}
# The labels of the folder groups of the native providers in their order (another folder: its name, after them alphabetically).
const.sources.providers.folder_labels = {
    'pl': L(30177, 'Polish', ctx='source provider group'),
    'en': L(30199, 'English', ctx='source provider group'),
    'xx': L(30211, 'General', ctx='source provider group'),
}
# The sections of a group (a folder or a group above): a provider of no section is in the first one; one section: no level.
const.sources.providers.sections = {
    'pl': (
        ProviderSection(key='websites', label=L(32730, 'PL Websites')),
        ProviderSection(key='premium', label=L(30301, 'Premium'), members=('ekinopremium', 'gb7', 'nopremium', 'rapideo', 'tb7', 'twojlimit', 'xt7')),
        ProviderSection(key='anime', label=L(30518, 'Anime'), members=('animezone', 'docchi', 'frixysubs', 'lycoris', 'miorosubs', 'shinden')),
    ),
    'external': (
        ProviderSection(key='streaming', label=L(30647, 'Streaming services')),
        ProviderSection(key='servers', label=L(30709, 'Media servers'), members=('jellyfin', 'jellyfin_direct', 'plex')),
        ProviderSection(key='iptv', label=L(30710, 'IPTV'), members=('stalkervod', 'giptv')),
    ),
}
# The native providers not searched without a choice of the user (every other one is searched).
const.sources.providers.default_off = ('adapterpl', 'cdahd', 'dahmermovies', 'download', 'dramaqueen', 'ekinopremium', 'filman', 'gb7', 'giptv',
                                       'jellyfin', 'm3u', 'netmirror', 'ninateka', 'nopremium', 'plex', 'rapideo', 'shinden', 'stalkervod', 'tb7',
                                       'twojlimit', 'xt7')
# A failed login of a native provider is not tried again with the same credentials for so long [s] (a service locks
# the account after repeated failures: rapideo for an hour); changed credentials are tried at once.
const.sources.providers.login_retry = HOUR

# The priority of the episodes on the nodes of the tree of the source providers: its row in the panel and its use in the sort.
# False: the row hidden, the episodes use the priority of the movies (the values already set stay, unused); the simple view too.
const.sources.providers.episode_priority = True
# The providers coloured automatically (the setting of the sources: no colour of their own - no node of the tree, no rule): a place in
# the list is a hue (the next step of the golden angle, the lightness and the chroma of the style: `palette.*`), a tuple one colour
# of a family (one service, its plans); the others the default colour. Append new ones; a withdrawn one stays in its place (a removal
# shifts the colours of the ones after it).
const.sources.providers.auto_colors = (
    ('tb7', 'xt7', 'gb7'), ('rapideo', 'twojlimit', 'nopremium'), 'cda', ('ekino', 'ekinopremium'), 'filman', 'zaluknijcc', 'obejrzyjto',
    'filmyonline', 'alefilmy', 'shinden', 'vodpl', 'tvpvod', 'moviebox', 'vixsrc', 'kisskh', 'webstreamr', 'rivestream', 'videasy',
    'fourkhdhub', 'streamhub', 'yesmovies', 'cdahd',
)
# Provider add-ons (with ff.providers.json) which are ours: in a tie of the rules (the same handler version, the same match)
# ours serve a scraper add-on before the others.
const.sources.xproviders.ours = ('script.fanfilm.provider.fenom', 'script.fanfilm.provider.ffork')
# A provider add-on without a choice of the user (Tools » External add-ons) is: 'never' - inactive (its code does not run until
# the user activates it), 'ours' - inactive, ours active, 'always' - active.
const.sources.xproviders.default_active = 'ours'
# The workers of the provider add-ons (the run mode `service`): the FanFilm service starts them this long after its start
# (Kodi has its own start to do), then checks them so often and starts a worker which ended (not at the Kodi exit).
const.sources.xproviders.start_delay = 5
const.sources.xproviders.watch_interval = 10
# A provider add-on ends its search this many seconds before the end of the search of FanFilm (its time limit is what is left
# less this): its last items still come in time (the found ones kept, the result not complete, not cached).
const.sources.xproviders.timeout_margin = 1.0
# Resolvability of a source: the ways FanFilm can open it now (the provider account, a direct link, a Kodi plugin, a debrid,
# a FanFilm resolver, a ResolveURL host resolver, the provider itself: a link no resolver knows, not a premium host), the
# best first by this order; a kind not listed is not used.
# The end of the search time (the setting of the search) stops the providers still searching; False: they go on until they finish or the user stops
# the search - at the end of the time the debrids are asked about the torrents found so far, about the later ones when all of them finish.
const.sources.stop_providers_at_max = True

const.sources.resolve.order = ('account', 'direct', 'plugin', 'debrid', 'ff', 'resolveurl', 'provider')
# A source no way can open: 'grey' (greyed out at the list end), 'hide', 'show' (as the others).
const.sources.resolve.unresolvable = 'grey'
# A chosen greyed-out source is tried anyway (the general resolve path), False: only a message.
const.sources.resolve.try_unresolvable = True
# A torrent a debrid has cached counts as premium for the rules (`SourceSelector(premium=True)`: e.g. the priority over the free sources).
const.sources.resolve.cached_premium = True
# The time limit of one request of the cache check of a debrid (seconds): the debrids which tell it (Premiumize, TorBox) are
# asked once a search for all torrent hashes, a cached torrent plays at once (marked in the source list).
const.sources.resolve.cache_timeout = 5.0
# Packs searched with an episode (scrapers of the Fenom family): 'season' packs, 'show' packs; each kind is one more
# query of most pack scrapers. A pack is opened by a debrid, the file of the episode chosen by its name.
const.sources.packs = ('season',)

# Sources cache (the static provider search results; the account state is never cached), see the provider SOURCES_TTL.
# Lifetime of a cached source list (seconds).
const.sources.cache.ttl = 30 * MINUTE
# Lifetime of a cached empty source list (seconds), shorter: a provider may have had a temporary problem.
const.sources.cache.empty_ttl = 15 * MINUTE
# Lifetime of a cached show token (seconds): a provider show page / data shared by the episodes, see provider SHOW_TTL.
const.sources.cache.show_ttl = DAY
# Max wait (seconds) for the results stored in the background at the end of play (before the playback), see sources_db.flush().
const.sources.cache.flush_timeout = 5.0

# Anime data (lib/api/kitsu.py: TMDB ID -> Kitsu / MAL / AniList IDs and Kitsu cours), kept in sources.db (`ff/kitsu`).
# Lifetime of the downloaded Fribb index (seconds), then it is downloaded again.
const.sources.kitsu.fribb_ttl = 7 * DAY
# How long the Fribb index is kept as a fallback if a download fails (seconds).
const.sources.kitsu.fribb_keep = 30 * DAY
# Lifetime of the anime IDs of a TMDB ID (ARM / Fribb mapping) (seconds).
const.sources.kitsu.ids_ttl = 7 * DAY
# Lifetime of no anime IDs of a TMDB ID (not an anime in ARM / Fribb) (seconds).
const.sources.kitsu.ids_empty_ttl = DAY
# Lifetime of Kitsu data of an ended anime (the end date is in the past) (seconds).
const.sources.kitsu.meta_ended_ttl = 30 * DAY
# Lifetime of Kitsu data of an airing anime or one without dates (seconds).
const.sources.kitsu.meta_ttl = DAY
# Max number of parallel Kitsu requests.
const.sources.kitsu.workers = 8

# Translations for providers names.
const.sources.translations.providers = {
    'pl-PL': {
        'library': 'Biblioteka',
        'download': 'Pobrane',
    }
}
# Translations for hostings names.
const.sources.translations.hostings = {
}


# Use fallback, show source links even if player.pl can not find video.
const.sources.external.playerpl.fallback = False


# CDA video duration ε, how big the video duration discrepancy can be (0.05 mens 5%).
const.sources.cda.duration_epsilon = CONST_REF.sources.duration_epsilon
# Looser ε for TV episodes – credits/intro cuts are common.
const.sources.cda.episode_duration_epsilon = .12
# Show CDA premium_free=true as given name. Default is empty (show nothing).
const.sources.cda.show_premium_free = ''
# Minimal file size in MB for CDA provider.
const.sources.cda.min_size_mb = 50

# GIPTV index max age in hours: the index of the giptv add-on is read (never written) while younger, the own copy (provider store) lives so long.
const.sources.giptv.index_max_age_h = 24

# Choose domain for ekino https://ekino.ws or https://ekino-tv.pl
const.sources.ekinotv.domain = "https://ekino.ws"

# ----- tb7 / xt7 / gb7 -----

# Separators placed between the show title and the episode marker, in priority order.
# '.' -> "office.s02e05" (xt7 word search), ' ' -> "office_s02e05%" (xt7 prefix search).
# The first one is used for every episode query; the next ones only fill the query
# budget left over (e.g. when the local title equals the original one).
const.sources.xtb7.episode_separators = (' ', '.')

# Max number of HTTP search queries for one episode, taken in this priority order
# (measured: each next one finds fewer new files):
#   original title + episode, local title + episode (skipped if PL == EN),
#   local title alone, the episode queries with the next separator(s),
#   original title alone, original / local title + season.
# Up to search_sessions queries run in parallel (one round, ~2 s); more add rounds.
const.sources.xtb7.max_show_search_queries = 3

# Reject a source when its filename is too similar to an already accepted one.
const.sources.xtb7.similarity_check = False
# Similarity above this value counts as a duplicate.
const.sources.xtb7.similarity_threshold = 0.94

# Search title replacements (lowercase title -> query title).
const.sources.xtb7.title_replacements = {
    "star wars new hope": "star wars",
}

# Number of logged-in sessions used to run search queries in parallel (1 = one by one).
# xt7 queues the requests of one session, so every parallel query needs its own login;
# the cookies are cached (14 days, re-login only when the server rejects the session).
const.sources.xtb7.search_sessions = 3


# Extra debug info for Rapideo / NoPremium / TwojLimit provider.
const.sources.rapideo.debug = False
# Extra debug info for CDA provider.
const.sources.cda.debug = False
# Extra debug info for tb7 / xt7 / gb7 provider.
const.sources.xtb7.debug = False
# Extra debug info for netmirror provider.
const.sources.netmirror.debug = False
# Number of hours netmirror token auto-refresh (on the service). If 0, no auto-refresh is done.
const.sources.netmirror.token_autorefresh_hours = 10


# Use the no_transfer function in source window
const.sources.premium.no_transfer = True


# ----- Player -----

#: True, if player should try to set Kodi DbId.
const.player.set_dbid = False
#: How to cancel playing video from the beginning.
#: Avoid PlayCancel.FALSE (a failed resolve): Kodi (K21, K22 CPlayListPlayer::Play) plays the next playlist item then
#: (e.g. "play next video automatically" opens the sources of the next episode) and shows "Playback failed"
#: if `playlisttimeout` (20 s) passed since the play was started, i.e. after a longer search.
#: Avoid a placeholder with a video stream (PlayCancel.TT430): Kodi switches the refresh rate and (K22) the full screen
#: video while opening it and a stop meanwhile can deadlock Kodi (1 of ~60 on Raspberry Pi 5); with no video stream
#: (PlayCancel.DATA) the black blink of the VideoPlayer start on GBM / DRM is the shortest too.
const.player.cancel_start = PlayCancel.DATA
#: How to cancel playing video from the resume point. Avoid PlayCancel.EMPTY, could set `watched`. See `cancel_start`.
const.player.cancel_resume = PlayCancel.DATA
#: Refresh the list after a cancel that changed the play state (Kodi saved the placeholder play: a resume, PlayCancel.TT430,
#: EMPTY; the item shows the placeholder state, e.g. 5% instead of 40%, and loses its plot and art; the state is put back):
#: the service does it this many seconds after the placeholder stops (the play script ends first, its interpreter
#: is reused), not if Kodi went to the full screen video (it reloads the list itself on return). None (or 0): no refresh.
const.player.refresh_on_cancel_resume = 0.5
#: Count `refresh_on_cancel_resume` from the end of the play script when it has ended before the placeholder stop
#: (PlayCancel.DATA: about 1 s before, the list is refreshed at once - a shorter blink of the item); False: from the stop.
const.player.refresh_on_cancel_from_call = True
#: Use (kodi default) or not HEAD request in player video.
const.player.head_lookup = False


# ----- Library -----

# Force always flat folder for shows (old format).
# If False new show folders uses season subfolders, existing old one uses flat structure.
# If True always use flat folder structure.
const.library.flat_show_folder = False
# The STRM file name for new movies and shows. Use another format if detected.
const.library.strm_filename = StrmFilename.TITLE_YEAR
# Language of title (and folder) in the library.
const.library.title_language = 'en-US'
# If True, use safe path for library items (replace more characters in title). If false use Kodi safe path (depends on platform).
const.library.safe_filename = True

# Seconds until an unreadable STRM file of the library (removed until Kodi cleans the library, a path of another device on
# a shared MySQL, an offline share) is read again; a read one keeps its URL.
const.library.strm.unreadable_ttl = 24 * 3600

# If True, sync Kodi library (update library) after each batch (but not a batch chunk).
# if False, sync Kodi library only if no another batch in the queue (sync after batches group).
const.library.service.sync_every_batch = False
# If True, wait for each Kodi library sync (library update).
# If False, start next batch immediately.
const.library.service.sync_wait = True
# Number of items in single chunk for library "add to" operations. Zero means no chunking.
const.library.service.chunk_size = 50
# Sleep time in seconds between library "add to" chunks.
const.library.service.chunk_sleep = 5
# Shows updated by the library sync ("Auto update TV Shows"): False - the shows in the FanFilm TV folder only, True - all
# shows of Kodi library (a show from another source gets the missing episodes as FanFilm files in the FanFilm TV folder).
const.library.service.update_all_shows = False
# The FF STRM files of Kodi library follow the FF progress (a mark in FF, an account sync, a play from an FF folder): the
# service sets their play count, last play and resume point (the parts the local Kodi account reads). False: never.
const.library.service.align = True


# ----- Dialogues -----

# Changelog dialog: color of the current addon version (readable on light and dark skins).
const.dialog.changelog.version_color = 'FFD81B60'
# Changelog after an update: seconds to wait (after the main menu is given to Kodi) until the GUI shows the menu, only
# then the changelog is shown; not shown (a JSON-RPC call, a widget, the GUI elsewhere) - the next entry from the GUI.
const.dialog.changelog.gui_timeout = 2.0
# Window of an ignored local.py: color of the line of the error (readable on light and dark skins).
const.dialog.local_error.line_color = CONST_REF.dialog.changelog.version_color

# -- Tree select (a list in a tree: nodes expand / collapse, leaves are selected) --

# Hide a password while it is typed in the configuration window (on a TV of its own: rather not; the list never shows it).
const.dialog.config.hide_passwords = False
# Levels of the indent (positions of a list item are fixed, a level is one animation of the window XML); a deeper
# row is shown at the last level.
const.dialog.tree.max_depth = 4
# Left in a tree: collapse the node, then go to the parent row (out of the tree from a collapsed root); False - out of the tree
# at once (to the tab of the configuration window, to OK of the tree select); a node collapses by OK / Info / 0 anyway.
const.dialog.tree.left_to_parent = False
# The state of a row in the choice of leaves (the multiselect; the color of the rows tells it anyway): 'button' - a button
# over the selected row (right, OK: check the row, a node - its whole branch), 'icon' - only the check column, '' - none.
# A tree of own states of nodes (the menus) has its check button always.
const.dialog.tree.check = 'button'
# The keys of a tree by their operations, Kodi actions (`ActionTranslator` names, as in the keymaps): Info (a remote, the key
# I, a gamepad), Number0-9 (an IR remote, the keyboard), ShowSubtitles, MiddleClick, the colors; () - off. Not ContextMenu:
# the user expects a context menu there.
# - toggle: select / unselect the whole branch of the row in the multiselect (Enter expands a node),
# - up / down: the previous / next node of the level of the row (a leaf: of its parent), around; 2 / 8 as the arrows of
#   a remote (the keypad of a keyboard has them the other way),
# - filter: the filter field above a tree with one (the source providers, the menus); Search: the search key of a keyboard
#   / a remote (not a Kodi action: its button code).
const.dialog.tree.keys = {
    'toggle': ('Info', 'Number0'),
    'up': ('Number2',),
    'down': ('Number8',),
    'filter': ('Number3', 'Search'),
}
# The counter of a node of a tree with a memory of its partial state (the source providers, the menus) tells the remembered
# too when the node is none or all: `0 / 88 · 68` (the check button and the context menu say "Restore (68 of 88)" anyway).
const.dialog.tree.count_remembered = False
# The filter of a tree (a part of a label, no case, no diacritics: "zrodla" matches "Źródła"): from this number of characters
# (fewer: all rows).
const.dialog.tree.filter.min_chars = 2

# -- Add to --

# Allowed media conversions in add-to dialog.
# Available conversions are limited by lib.ff.lists.ListConvertRules.
const.dialog.add_to.allowed_conversions = {
    'collection': ListType.MOVIE,
    'movie': ListType.COLLECTION,
    'show': ListType.SEASON | ListType.EPISODE,
    'season': ListType.SHOW | ListType.EPISODE,
    'episode': ListType.SHOW | ListType.SEASON,
}
# True if adding should be quiet (no notification).
const.dialog.add_to.quiet = False
# Add-to dialog: show absent (non-existing) media types.
const.dialog.add_to.media_type.absent_visible = ListType.MEDIA
# Type of media names in the "add to..." dialog header.
const.dialog.add_to.media_type.bar_mode = 'icons'
# The lists of the local group of the Add-to dialog (the library, the own lists of FanFilm, the logs).
const.dialog.add_to.lists.local = ('library', 'own:favorites', 'own:watchlist', 'own:user', 'logs')
# The Add-to dialog with a service name (left column: groups, central column: their lists), see: const.indexer.context_menu.add_to.
# Keys are the services without an account (`local`, `library`, `logs`) or account types; `{account}` - any other account
# (its group, `{account}` in the pointers is the account). Values: group label -> ListPointer names; `<type>:*` - all lists of
# the type, `*:<section>` - the section of all types.
const.dialog.add_to.lists.services = {
    'local':     {L(30355, 'Local'): CONST_REF.dialog.add_to.lists.local},
    'library':   {L(32541, 'Library'): ('library',)},
    '{account}': {'{account}': ('{account}:*',)},
    'logs':      {L(30359, 'Logs'): ('logs',)},
}
# The Add-to dialog with no service name (all groups), see: const.indexer.context_menu.add_to. The `{account}` group is a group
# per account (in order of accounts) with its lists not shown above; pointers as in `services`.
const.dialog.add_to.lists.default = {
    L(30355, 'Local'): CONST_REF.dialog.add_to.lists.local,
    '{account}': ('{account}:*',),
    L(30146, 'Favorites'): ('own:favorites', '*:favorites'),
}

# -- Ratings --

# Style of ratings dialog.
# - triple  - up to tree starts for one rating level (in single line)
# - lines   - one line per rating service
# - stars   - one line per rating service, stars up to the rating
const.dialog.ratings.style = 'stars'
# Show raw (service) rating value in dialog.
const.dialog.ratings.show_raw_rating = False
# Show notification after ratings are set.
const.dialog.ratings.notification = True
# Colors for ratings dialog services (used in cycle) in SERVICE_TYPES order.
const.dialog.ratings.colors = (
    'FFBB33FF',  # TMDB (purple)
    'FF0D9BE8',  # WeTrakr (blue)
    'FFB2B831',  # MDBList (yellow)
    'FF11BAC0',  # ... (cyan)
    'FFDD8C0E',
)
# Autoclose dialog after N seconds. 0 means no autoclose.
const.dialog.ratings.autoclose_timeout = 10


# ----- Ratings -----

# Enabled ratings services, if False, ratings dialog is disabled.
# If true, all available ratings services are used (trakt, tmdb, mdblist).
# Else, list of service names could be used to limit ratings services and set services order.
# Example: const.dratings.enabled = ('trakt', 'tmdb')
const.ratings.enabled = True
# Ask for rating after every watching video if True.
# Ask for rating only once for first time watching if False.
const.ratings.every_watched = False
# What rate show exactly means: sequence of 'show', 'season', 'episode' and 'show_finished', 'season_finished' (if all items are watched).
# Many values means many dialogs in sequence.
const.ratings.watched_show_mode = ('episode', 'season_finished', 'show_finished')
# Filter for ratings dialog. Default is True.
# Key is service name (trakt, tmdb, ... or '*') and actions name (context_menu, watched_movie, watched_episode or '*').
const.ratings.filter = {
    # ('tmdb', 'context_menu'): False,  # disable TMDB rating in context menu
    # ('trakt', 'watched_episode'): False,  # disable Trakt show rating after episode watched
}
# Show ratings in all folders (movies, shows etc.).
# - False   - do not show ratings in folders
# - 'min'   - show lowest rating from all services
# - 'max'   - show highest rating from all services
# - 'avg'   - show average rating from all services
# - 'first' - show first rating from defined services order (see: const.ratings.enabled)
# - service name - show rating from defined service only (e.g. 'trakt')
const.ratings.all_folders = 'avg'


# ----- Low level settings (don't change, you are warned) -----

# Interval of the Kodi monitor thread loop (x-monitor) in a plugin call. The thread ends within it after the call and Kodi
# reuses the interpreter only then (the next call gets a new one meanwhile). The service has its own, see below.
const.tune.sleep_step = 0.01
# Interval in internal threads.Event.wait() loop.
const.tune.event_step = 0.1
# Max workers for api.depagine().
const.tune.depagine_max_workers = None

#: Sqlite3 connection timeout (python default is 5.0).
const.tune.db.connection_timeout = 3.0
#: Interval of the service job removing expired DB cache rows (seconds, zero disables).
const.tune.db.cleanup_interval = HOUR
#: DB state.wait_for_value() reading interval.
const.tune.db.state_wait_read_interval = 0.2
#: Where keep state varibables by default.
const.tune.db.state_mode = StateMode.SERVICE
#: Tune state varibables.
const.tune.db.module_state_mode = {
    'service': StateMode.DB,
    'trakt': StateMode.DB,
}
#: Commit durability of the WAL databases (PRAGMA synchronous). NORMAL: a commit does not wait for fsync (it can wait seconds
#: on a busy disk, holding the write lock), the DB stays consistent, a power loss can drop the last commits (a Kodi crash can not).
const.tune.db.synchronous = 'NORMAL'
#: Databases with data the services do not have again (tokens, own lists, unwatched rows): FULL, a commit waits for fsync.
const.tune.db.db_synchronous = {
    'accounts': 'FULL',
    'ownlists': 'FULL',
    'playback': 'FULL',
}

# Number of kept settings backup files.
const.tune.settings.vacuum_files = 5
# A setting Kodi could not read (its settings file being written: Kodi writes it in place, every setSetting, any interpreter)
# is read again from a new Addon object: so many times, this pause (seconds) before each.
const.tune.settings.retries = 5
const.tune.settings.retry_delay = 0.1

#: Interval in internal sleep loop.
const.tune.service.check_interval = 3
# The step of the check of the state of Kodi a waiting task of the service makes: Kodi used again (the cyclic sync of accounts,
# `const.accounts.sync.idle_interval`), the end of a video (the maintenance works: the DB cleanup, the ID map, the auto lists...).
const.tune.service.wait_check_interval = 3
#: Interval in internal sleep loop.
const.tune.service.job_list_sleep = 1
#: Interval for group update (kodi notification for season or show).
const.tune.service.group_update_timeout = 5
#: Show busy dialog on group update (kodi notification for season or show).
const.tune.service.group_update_busy_dialog = True
# Delay to set item focus after plugin directory (plugin exit with 'focus' index).
const.tune.service.focus_item_delay = .5
#: How often the service checks the progress for the widgets reload (`const.core.widgets_reload`); changes within it reload once.
const.tune.service.widgets_reload_interval = 2
# Interval (seconds) of the check of the progress change for the alignment of Kodi library (`const.library.service.align`).
const.tune.service.library_align_interval = 5
# Extra hard dealy to start FF service.
#. apply=service
const.tune.service.startup_delay = 0
# The whole wait for the service in one plugin call (its URL in the state DB or its answer), seconds; no service then:
# the call goes on without it. Also the wait of the thin plugin for the service at Kodi start (a Pi: Python starts ~20 s
# after Kodi, the service ~3 s later).
const.tune.service.startup_timeout = 30
# The wait for the service in a plugin call after a call of the same (reused) interpreter found none, seconds (RAM only:
# a new interpreter waits `startup_timeout` again).
const.tune.service.retry_timeout = 2
# Timeout for service RPC call response.
const.tune.service.rpc_call_timeout = 3
# How often the HTTP / web servers of the service look for the stop request, seconds: their stop waits up to it (Kodi exit,
# a service restart); Python default 0.5 (two servers: 0.5-1 s of every Kodi exit).
#. apply=server
const.tune.service.server_poll_interval = .05
# Interval of the Kodi monitor thread loop (x-monitor) in the service: it lives the whole Kodi session, a short step costs CPU.
const.tune.service.sleep_step = 0.1
# Interval of the Kodi monitor thread loop (x-monitor) in the worker script (RunScript of the service, its interpreter is never
# reused): it sees the Kodi exit announcement within it; a short step takes the GIL from the generation of the windows.
const.tune.worker.sleep_step = 0.1

# The next try of the names of the countries / languages of a locale not got (no network, no such locale upstream) in the same
# process, seconds: no request and no wait before it (the callers take the names of the data meanwhile).
const.tune.locale.retry = 15 * MINUTE

# Port number for proxy HTTP server. Zero means take any free port.
#. apply=service
const.tune.service.http_server.port = 0
# Step of the state DB check for the service URL while waiting for the service, seconds.
const.tune.service.http_server.wait_for_url = .25
# How verbose should be http service server? 0 - off.
const.tune.service.http_server.verbose = 1

# The plugin calls of a handle (folders, widgets) run in the service (warm, no import of FanFilm in the thin plugin),
# a play and a call without a handle (RunPlugin) run in the plugin; read by the service only.
const.tune.service.remote_plugin.enabled = True
# Plugin calls run in the service at once, the next ones wait for a free one.
const.tune.service.remote_plugin.calls = 1
# A call of the service running longer (a dialog of the user, a hang) lets the waiting calls run in the plugin, seconds;
# a long queue alone does not (the plugin gains nothing: one GIL, the import of a cold interpreter).
const.tune.service.remote_plugin.call_timeout = 10
# The wait of the thin plugin for the end of a call aborted by Kodi, seconds (Kodi kills the plugin 5 s after its abort).
const.tune.service.remote_plugin.abort_wait = 4

# Port number for web HTTP server, fixed: the user script of the browser knows it (another one in `local.py`; CLI takes any free one).
#. apply=server
const.tune.service.web_server.port = 8663
# How verbose should be web http service server? 0 - off.
const.tune.service.web_server.verbose = 1
# Parse cookies from web server and convert them to settings, or to accounts: `account:<type>:<key>` (the sites of the native
# providers are in their declarations: `COOKIES`, `lib.sources.natives`).
const.tune.service.web_server.cookies = {
    # --- services ---
    'www.imdb.com': {  # private lists and modify list and watchlist in IMDB: the account of the cookie user (whoami)
        'at-main': 'account:imdb:at-main',
        ':user_agent': 'account:imdb:user_agent',
        # only present when the FanFilm panel's "Dodaj ... jako imdb.user" button was clicked on a
        # /user/p.xxx/ profile page - a public IMDb account of the user (the existing one is kept)
        ':imdb_user_id': 'account:imdb:public',
    },
}
# Notify if cookies are updated.
const.tune.service.web_server.update_notification = True

# Default QR-Code scale.
const.tune.misc.qrcode.size = 20

# Number of cached variants of a generated window/dialog XML (per window, different template data).
const.tune.gui.xml_variants = 5
# Generated XML of other Kodi instances (profiles) is removed after this time without use (seconds).
const.tune.gui.xml_foreign_ttl = 7 * 24 * 3600
# The update worker (the service starts it at once after a new FF version) prepares the windows (their XML of the environment
# of now) this long after its earlier jobs (Kodi has its own start to do), the service checks them this long after its start (a worker
# of the windows: it ends at once if they are prepared), seconds; 0: never (the first open of a window generates it).
const.tune.gui.xml_prepare_delay = 10
# How often the service checks the skin, its colours and the language: a change starts the worker of the windows (the first open of a
# window, mostly the sources of a play, finds its XML), seconds; 0: no check in a Kodi session (only at its start).
const.tune.gui.xml_check_interval = 60
# A window open (from the creation of the window to its show: its XML generated if there is no cached one of the environment of now,
# Kodi loads it; slow on a slow device) shows the Kodi busy dialog if it takes longer than this (no flash on a fast machine), seconds; 0: never.
const.tune.gui.xml_busy_delay = 0.4
# Kodi set XML element value lag (time to do not trust xml value right after set).
const.tune.gui.set_xml_value_lag = .25
# The digits typed into a spin box make one number while each one comes within this time of the previous one, seconds (as the letters
# typed into a Kodi list: 1 s).
const.tune.gui.number_typing_timeout = 1.0
# A list of a window follows the mouse: the row under the cursor is its current one (its help in the footer). Off: a move of the mouse is not
# read (a little less work at every move), the row changes by a key, a focus and a click.
const.tune.gui.list_follows_mouse = True
# A drop-down list with no room for all its rows on either side of its field (in a grouplist: the part of it surely shown) goes to the side
# of more room and shows as many rows as it holds there, scrolling the rest, but at least so many (out of the room, maybe clipped).
const.tune.gui.popup_min_rows = 3
# Font roles of the windows (`ff:style`), derived from the live skin fonts: role -> (size ratio to font13, bold).
# "normal" is always font13. A role gets the nearest font of the font13 family (weight first, then size), else font13.
const.tune.gui.font_roles = {'heading': (1.33, True), 'small': (.85, False), 'tiny': (.75, False)}
# Max distance of a role font size from the target size (fraction of the target).
const.tune.gui.font_role_tolerance = .25

# control.groupedInfoDialog(): seconds of silence before showing a collapsed notification.
const.tune.notify.debounce = 3.0
# control.groupedInfoDialog(): max seconds to wait since the first call in a burst.
const.tune.notify.max_wait = 15.0


# ----------------------------------------------------------------------------- #
# -----                              THE END                              ----- #
# ----------------------------------------------------------------------------- #

# --- must be on the bottom of the file
const_done()

# DEBUG: test if all settings are correct
# raise SystemExit(0)
