# -*- coding: utf-8 -*-
"""
FanFilm - źródło: download
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations

import os
import re
from collections import deque
from typing import ClassVar, TYPE_CHECKING
from urllib.parse import unquote

import xbmcvfs

from lib.ff import cleantitle, control, source_utils
from lib.ff.logs import fflog
from lib.ff.settings import settings
from lib.ff.threads import check_thread_cancel
from lib.kolang import L
from lib.sdk.facts import parse as parse_facts
from lib.sources import Provider

if TYPE_CHECKING:
    from typing import Callable, Iterator
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceSearchOverride


#: A group tag at the start of a file name.
RX_GROUP_TAG: re.Pattern[str] = re.compile(r'^\s*\[[^\]]*\][\s._-]*')
#: A folder of many titles: a collection word, a year range ("1996-2023"), a number range ("1-3").
RX_CONTAINER: re.Pattern[str] = re.compile(
    r'\b(kolekcja|collection|trylogia|trilogy|saga|pack|complete|komplet|box ?set|antologia|anthology)\b'
    r'|\b(?:19|20)\d{2}\s*-\s*(?:19|20)\d{2}\b|(?<![\w.])\d\s*-\s*\d(?![\w.])', re.I)
#: Containers in containers walked ("Marvel/Faza 1/"), deeper ones (the folders of a game, of a program) are not.
MAX_CONTAINER_LEVEL: int = 2
#: Seasons of one show ("S01-S03", "Sezon 1", "Season.2"): a release of that show, not a container.
RX_SEASONS: re.Pattern[str] = re.compile(r'\bS\d{1,2}\b|\b(?:sezon|season)\w*?[ ._-]*\d', re.I)


def _fix_surrogate(text: str) -> str:
    """Fix UTF-8 surrogates (Kodi may use a locale other than UTF-8)."""
    try:
        return os.fsencode(text).decode('utf-8')
    except (UnicodeDecodeError, UnicodeEncodeError):
        return text


def _normalize_name(name: str) -> str:
    """Normalize a name for a loose comparison (lowercase, no diacritics, no punctuation)."""
    result = cleantitle.normalize(cleantitle.getsearch(name)).lower()
    result = result.replace('.', ' ').replace('_', ' ')
    return re.sub(' {2,}', ' ', result).strip()


def _is_vfs_path(path: str) -> bool:
    """True for a Kodi VFS URL (davs://, smb://, nfs://...), which os.* cannot open."""
    return bool(re.match(r'[a-z][a-z0-9+.-]*://', path, flags=re.I))


def _hide_credentials(path: str) -> str:
    """Hide user and password of a VFS URL (for the log)."""
    return re.sub(r'://[^/@]*@', '://***@', path)


def _folder_exists(path: str) -> bool:
    """Check a folder, a local one or through Kodi VFS."""
    if _is_vfs_path(path):
        return bool(xbmcvfs.exists(path.rstrip('/') + '/'))
    return os.path.exists(path)


def _file_size(path: str) -> int:
    """Return the file size in bytes, 0 if unknown."""
    try:
        return xbmcvfs.Stat(path).st_size()
    except Exception:
        try:
            with xbmcvfs.File(path) as vfs_file:
                return vfs_file.size()
        except Exception:
            return 0


def _walk(path: str, wanted: list[str], found: Callable[[], bool]) -> Iterator[tuple[str, list[str]]]:
    """Walk a folder like os.walk() (root, files), a VFS one (WebDAV, SMB, NFS...) by xbmcvfs."""
    if not _is_vfs_path(path):
        for root, _dirs, files in os.walk(path):
            check_thread_cancel()
            yield root, files
        return
    yield from _walk_vfs(path, wanted, found)


def _is_release(name: str) -> bool:
    """A folder of one release (one torrent of one movie / show) by its name, not a container of many titles."""
    if RX_SEASONS.search(name):
        return True
    if RX_CONTAINER.search(name):
        return False
    facts = parse_facts(name)
    return bool(source_utils.RE_YEAR.search(name) or facts.get('video') or facts.get('release'))


def _walk_vfs(path: str, wanted: list[str], found: Callable[[], bool]) -> Iterator[tuple[str, list[str]]]:
    """
    Walk a VFS folder (one request per folder; WebDAV servers list one level only). Folders named like the title
    (and all inside them) go first; when they gave a file, the walk ends, else the containers follow (`Marvel/`,
    `Kolekcja…`, a bare name). A release folder of another title is skipped.
    """
    # (folder, inside a matching folder, level of containers)
    preferred: deque[tuple[str, bool, int]] = deque([(path.rstrip('/') + '/', False, 0)])
    containers: deque[tuple[str, bool, int]] = deque()
    skipped = 0
    while preferred or containers:
        if not preferred and found():
            break
        check_thread_cancel()
        folder, inside, level = (preferred or containers).popleft()
        try:
            dirs, files = xbmcvfs.listdir(folder)
        except Exception:
            fflog(f'cannot list folder: {_hide_credentials(folder)}')
            continue
        yield folder, files
        for name in dirs:
            decoded = unquote(_fix_surrogate(name))
            normalized = _normalize_name(decoded)
            if inside or any(title in normalized for title in wanted):
                preferred.append((f'{folder}{name}/', True, level))
            elif level < MAX_CONTAINER_LEVEL and not _is_release(decoded):
                containers.append((f'{folder}{name}/', False, level + 1))
            else:
                skipped += 1
    fflog(f'folders skipped (releases of other titles, too deep): {skipped}')


class _FileMatcher:
    """Match a file name to the searched title, year and episode (the shared filters of tb7 / rapideo)."""

    def __init__(self, titles: list[str], override: SourceSearchOverride, ffitem: FFItem) -> None:
        self.season: int | None = override['season']
        self.episode: int | None = override['episode']
        self.is_episode: bool = bool(self.season and self.episode)
        self.year: int = override['year'] or 0
        premiered = override['premiered']
        self.premiered: str | None = premiered.isoformat() if premiered else None
        self.absolute_episode: int | None = ffitem.absolute_episode_number() if self.is_episode else None
        self.episode_year: int = ffitem.date.year if self.is_episode and ffitem.date else 0
        year_in_title = next((match[0] for title in titles if (match := source_utils.RE_YEAR.search(title))), '')
        self.year_in_title: str = year_in_title
        self.title_filter, self.title_filter2 = source_utils.build_title_filters(titles, is_episode=self.is_episode)
        self.alias_cleans: set[str] = source_utils.build_alias_cleans(titles)

    def matches(self, filename: str) -> bool:
        """True if the file name is of the searched movie / episode."""
        # a leading group tag ("[ ELECTRO-TORRENT.d11] Title...") hides the title from the shared filters
        filename = RX_GROUP_TAG.sub('', filename)
        if not (self.title_filter.search(filename)
                or (self.title_filter2 and self.title_filter2.search(filename))
                or source_utils.match_filename_title_parsed(filename, self.alias_cleans)):
            return False
        if self.is_episode:
            if not source_utils.filename_passes_episode(filename, self.season, self.episode, self.absolute_episode):
                return False
            return source_utils.check_year_in_filename(filename, self.year, self.premiered, self.year_in_title,
                                                       episode_year=self.episode_year) is not False
        year_text = str(self.year) if self.year else ''
        # an episode marker of a movie file is a part of its title only with the right year
        if source_utils.is_episode_filename(filename) and not (year_text and re.search(rf'\b{year_text}\b', filename)):
            return False
        file_years = source_utils.RE_YEAR.findall(filename.replace(self.year_in_title, '', 1) if self.year_in_title else filename)
        return not (year_text and file_years and year_text not in file_years)


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    """Downloaded files: the download folders of FanFilm and an additional folder (local or Kodi VFS: WebDAV, SMB...)."""

    LABEL: ClassVar[str] = L(30306, 'Downloaded')
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('pl', 'en')
    PREMIUM = True
    #: The folder content changes (a new download, a removed file): never cached.
    SOURCES_TTL = 0

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        is_episode = bool(override['season'] and override['episode'])
        paths: list[str] = []
        if base_path := settings.getString('tv.download.path' if is_episode else 'movie.download.path'):
            paths.append(control.transPath(base_path))
        if settings.getBool('download.other_folder') and (other_path := settings.getString('download.other_folder_path')):
            if (other_path := control.transPath(other_path)) not in paths:
                paths.append(other_path)
        if not paths:
            return []

        titles = source_utils.build_alias_list(override['english_title'], override['local_title'],
                                               override.get('aliases') or [], override['year'] or 0)
        titles = source_utils.add_colon_reversed_titles(list(dict.fromkeys(filter(None, [*titles, override['original_title']]))))
        matcher = _FileMatcher(titles, override, ffitem)
        folder_titles = [normalized for normalized in dict.fromkeys(_normalize_name(title) for title in titles) if len(normalized) >= 3]
        extensions = tuple(ext.lower() for ext in source_utils.supported_video_extensions())

        found_files: list[tuple[str, str]] = []  # (path, file name)
        for path in paths:
            if not _folder_exists(path):
                fflog(f'folder does not exist: {_hide_credentials(path)}')
                continue
            for root, files in _walk(path, folder_titles, lambda: bool(found_files)):
                vfs = _is_vfs_path(root)
                if not vfs:
                    root = _fix_surrogate(root)
                for raw_filename in files:
                    filename = _fix_surrogate(raw_filename)
                    if vfs:
                        filename = unquote(filename)  # VFS (WebDAV) gives URL-encoded names
                    if filename.lower().endswith(extensions) and matcher.matches(filename):
                        found_files.append((os.path.join(root, raw_filename if vfs else filename), filename))

        sources: list[SourceItem] = []
        for file_path, filename in found_files:
            quality, language, info = source_utils.parse_source_quality_lang(filename)
            sources.append({
                'hosting': '',
                'quality': quality,
                'language': language,
                'url': file_path,
                'info': info,
                'filesize': _file_size(file_path),
                'direct': True,
                'debridonly': False,
                'filename': filename,
                'local': True,
                'premium': True,
            })
        fflog(f'sources: {len(sources)}')
        return sources
