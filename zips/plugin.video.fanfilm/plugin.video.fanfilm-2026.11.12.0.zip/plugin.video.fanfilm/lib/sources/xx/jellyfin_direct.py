"""
FanFilm - source: Jellyfin, direct (no Jellyfin add-on needed)

Signs in to the Jellyfin server itself (its address, login, password), matches the items by their IMDb / TMDB IDs
and plays the original file of the server (`/Videos/{id}/stream?static=true`, no transcoding). The `jellyfin` source
does the same through the jellycon / jellyfin add-on (their sign-in and player).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, ClassVar
from typing_extensions import NotRequired, TypedDict
from urllib.parse import parse_qs, quote, urlencode
from uuid import uuid4

from lib.ff import requests
from lib.ff.logs import fflog, log_exc
from lib.kolang import L
from lib.sources.natives import LOGIN, ProviderSetting, provider_value, set_provider_value
from lib.sources.xx.jellyfin import (
    JellyServer, MediaSource, source as AddonSource,
)

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias

#: The provider name (its settings).
NAME: str = 'jellyfin_direct'
#: The timeout of a request to the server, seconds.
TIMEOUT: float = 10


class LibraryItem(TypedDict):           # /Users/{user}/Items → Items[]
    Id: str
    Name: NotRequired[str]
    ProductionYear: NotRequired[int]
    ProviderIds: NotRequired[dict[str, str]]


class EpisodeItem(TypedDict):           # /Shows/{id}/Episodes → Items[]
    Id: str
    IndexNumber: NotRequired[int]
    IndexNumberEnd: NotRequired[int]
    MediaSources: NotRequired[list[MediaSource]]


class SavedAuth(TypedDict):             # the sign-in kept in the provider settings
    server: str
    username: str
    token: str
    user_id: str
    server_name: str


class source(AddonSource):
    LABEL: ClassVar[str] = 'Jellyfin'
    REQUIRES: ClassVar[tuple[str, ...]] = ()
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = (
        ProviderSetting(key='server', kind='text', label=L(30644, 'Jellyfin server address'), help=L(30645, 'e.g. https://jellyfin.example.com')),
        *LOGIN,
    )

    def __init__(self) -> None:
        super().__init__()
        self.auth: SavedAuth | None = None

    # ── public api ─────────────────────────────────────────────────────────

    def init(self) -> None:
        """Sign in (the saved token of the same server and user, else a new sign-in)."""
        if self.cache_status:
            return
        try:
            self.auth = self.sign_in()
        except Exception:
            fflog('Jellyfin Direct: sign-in failed')
            log_exc()
            self.auth = None
        self.cache_status = self.auth is not None

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None:
        self.init()
        if not self.cache_status:
            return None
        return urlencode({'imdb': imdb, 'tmdb': self.ffitem.tmdb_id or '', 'title': title, 'localtitle': localtitle, 'year': year})

    def sources(self, url: str | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:
        self.init()
        if url is None or self.auth is None:
            return []
        query = {key: values[0] for key, values in parse_qs(url).items() if values}
        try:
            try:
                found = self.find_sources(query)
            except requests.HTTPError as exc:
                if exc.response is None or exc.response.status_code != 401:
                    raise
                fflog('Jellyfin Direct: token rejected, sign in again')
                set_provider_value(NAME, 'auth', None)
                self.cache_status = False
                self.init()
                found = self.find_sources(query) if self.auth else []
        except Exception:
            fflog('Jellyfin Direct: search failed')
            log_exc()
            return []
        fflog(f'sources: {len(found)}')
        return found

    def resolve(self, url: str) -> str | None:
        """Add the token to the stream URL only now: not kept in the source lists, their cache and their logs."""
        self.init()
        if self.auth is None:
            return None
        return f'{url}&api_key={self.auth["token"]}'

    # ── sign-in ────────────────────────────────────────────────────────────

    def sign_in(self) -> SavedAuth | None:
        """Return the sign-in to the server of the settings (kept until the server or the user changes), None if not set."""
        server = (provider_value(NAME, 'server') or '').strip().rstrip('/')
        username = (provider_value(NAME, 'username') or '').strip()
        if not server or not username:
            return None
        if not re.match(r'https?://', server):
            server = f'http://{server}'
        saved: SavedAuth | None = provider_value(NAME, 'auth') or None
        if saved and saved.get('server') == server and saved.get('username') == username and saved.get('token'):
            return saved
        resp = self.session.post(f'{server}/Users/AuthenticateByName', json={'Username': username, 'Pw': provider_value(NAME, 'password') or ''},
                                 headers=self.client_headers(), timeout=TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        info = self.session.get(f'{server}/System/Info/Public', timeout=TIMEOUT).json()
        auth: SavedAuth = {'server': server, 'username': username, 'token': data['AccessToken'], 'user_id': data['User']['Id'],
                           'server_name': info.get('ServerName') or 'Jellyfin'}
        set_provider_value(NAME, 'auth', auth)
        fflog(f'Jellyfin Direct: signed in to {auth["server_name"]!r}')
        return auth

    def client_headers(self, token: str = '') -> dict[str, str]:
        """Return the client header of FanFilm (its own device: a sign-in does not end the session of another app)."""
        if not (device_id := provider_value(NAME, 'device_id')):
            device_id = f'fanfilm-{uuid4().hex[:12]}'
            set_provider_value(NAME, 'device_id', device_id)
        token_part = f', Token="{token}"' if token else ''
        return {'Authorization': f'MediaBrowser Client="FanFilm", Device="Kodi", DeviceId="{device_id}", Version="1"{token_part}'}

    # ── search ─────────────────────────────────────────────────────────────

    def get(self, path: str, **params: str | int) -> dict:
        """Return the JSON answer of the server (raises on an HTTP error)."""
        assert self.auth is not None
        resp = self.session.get(f'{self.auth["server"]}{path}', params=params, headers=self.client_headers(self.auth['token']), timeout=TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def library(self, kind: str) -> list[LibraryItem]:
        """Return all the items of the kind (`Movie`, `Series`) of the user with their IDs (the filter of the IDs is ignored by the server)."""
        assert self.auth is not None
        return self.get(f'/Users/{self.auth["user_id"]}/Items', IncludeItemTypes=kind, Recursive='true', Fields='ProviderIds,ProductionYear',
                        EnableImages='false', EnableUserData='false').get('Items') or []

    @staticmethod
    def match(items: list[LibraryItem], query: dict[str, str], titles: list[str]) -> list[LibraryItem]:
        """Return the items of the IMDb / TMDB ID of the query, else (no ID match) the items of a title and the year (±1)."""
        imdb, tmdb = query.get('imdb', ''), str(query.get('tmdb', ''))
        found = [item for item in items if (imdb and (item.get('ProviderIds') or {}).get('Imdb') == imdb)
                 or (tmdb and (item.get('ProviderIds') or {}).get('Tmdb') == tmdb)]
        if found:
            return found
        names = {title.casefold() for title in titles if title}
        year = int(query['year']) if (query.get('year') or '').isdigit() else 0
        return [item for item in items if (item.get('Name') or '').casefold() in names
                and (not year or abs((item.get('ProductionYear') or year) - year) <= 1)]

    def find_sources(self, query: dict[str, str]) -> list[SourceItem]:
        """Return the sources of all the versions (media sources) of the matched movie or episode."""
        assert self.auth is not None
        server: JellyServer = {'server_address': self.auth['server'], 'token': self.auth['token'], 'user_id': self.auth['user_id'],
                               'server_name': self.auth['server_name'], 'pattern': ''}
        found: list[SourceItem] = []
        if 'tvshowtitle' in query:
            season, episode = int(query['season']), int(query['episode'])
            for show in self.match(self.library('Series'), query, [query.get('tvshowtitle', ''), query.get('localtvshowtitle', '')]):
                episodes: list[EpisodeItem] = self.get(f'/Shows/{show["Id"]}/Episodes', userId=self.auth['user_id'], season=season,
                                                       Fields='MediaSources').get('Items') or []
                for item in episodes:
                    first = item.get('IndexNumber')
                    if first is not None and first <= episode <= (item.get('IndexNumberEnd') or first):
                        found.extend(self.build_source(server, media, item['Id']) for media in item.get('MediaSources') or ())
        else:
            for movie in self.match(self.library('Movie'), query, [query.get('title', ''), query.get('localtitle', '')]):
                item = self.get(f'/Users/{self.auth["user_id"]}/Items/{movie["Id"]}')
                found.extend(self.build_source(server, media, movie['Id']) for media in item.get('MediaSources') or ())
        return found

    def build_source(self, server: JellyServer, media_source: MediaSource, item_id: str) -> SourceItem:
        """The source of the `jellyfin` source, played directly: the original file of this version (no add-on, no transcoding)."""
        item = super().build_source(server, media_source, item_id)
        item['url'] = f'{server["server_address"]}/Videos/{item_id}/stream?static=true&MediaSourceId={quote(media_source.get("Id") or "")}'
        item.pop('icon', None)  # the icon of the jellycon / jellyfin add-on
        return item
