"""
    FanFilm Add-on
    Copyright (C) 2017 FanFilm

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import re
from collections import Counter
from html import unescape
from urllib.parse import unquote, urlsplit
from pathlib import Path
from pkgutil import iter_modules
from importlib import import_module
from typing import Union, Any, Mapping, Sequence, Callable, ClassVar, Generator, overload, TYPE_CHECKING
from typing_extensions import Literal, Protocol, TypedDict, NotRequired, Unpack, ParamSpec, TypeVar, Self
from functools import wraps
from contextlib import contextmanager
from threading import local
from attrs import frozen, define, field, evolve, asdict, fields, filters
from xbmcvfs import translatePath
from ..ff.logs import log, fflog_exc, log_submodule
from ..ff.threads import check_thread_cancel
from ..ff.tricks import MISSING
from ..ff.utils import strip_label_tags
from ..ff.db.sources import ProviderStore, provider_store
from ..ff.debrid import debrid_short_name
from ..ff.debug.timing import logtime  # TODO: remove, only for testing
from ..sdk.facts import parse, complete, Container, ReleaseSource
from ..sdk.facts.types import VideoFacts, AudioTrack, SubtitleTrack, ReleaseFacts
from ..sdk.protocol import ResolveResult, Item, kodi_url, item_from_legacy
from ..sdk.protocol.item import FACT_GROUPS, DYNAMIC_KEYS, ItemDynamic, quality_label, quality_of_resolution, size_bytes
from ..sdk.protocol.query import Query, QueryIds
from ..sdk.dialects import ff as ff_dialect
from ..sdk.addons.paths import addon_paths  # noqa: F401  (FanFilm uses it here)
from cdefs import SourceAttribute, RegEx, Expr, match_value, source_attribute_badge_key
from const import const
if TYPE_CHECKING:
    from typing_extensions import KeysView, Pattern, Iterator, Iterable, Collection, TypeAlias, TypeGuard
    from types import ModuleType
    from datetime import date as dt_date
    from attrs import Attribute
    from cdefs import AddonSelector, ProviderSelector, SourceSelector, SourceRuleValue, PlayMode, SourceAction, SourceAttributeBadge, ResolveKind, PackKind
    from ..defs import MediaCategory, MediaType
    from ..ff.item import FFItem
    from ..ff.types import JsonData
    from ..sdk.facts import Facts
    from .natives import ProviderSetting, SubSource, SiteCookies


T = TypeVar('T')
R = TypeVar('R')
P = ParamSpec('P')


# Shared optional data fields.
# Optional in both the provider result and the source item.
# The account state (`ItemDynamic`: on_account, on_account_link, on_account_expires, no_transfer) is DYNAMIC.
class SourceOptionalData(ItemDynamic):
    size: NotRequired[str]
    filesize: NotRequired[int]  # in bytes
    filename: NotRequired[str]
    color_identify: NotRequired[str]
    icon: NotRequired[str]
    debridonly: NotRequired[bool]
    direct: NotRequired[bool]
    # True, if file is on local (or locally mounted) storage. Set by provider.
    local: NotRequired[bool]
    premium: NotRequired[bool]
    # A torrent pack of the season / the show (the file of the episode is chosen when it is opened).
    pack: NotRequired[PackKind]
    # The size of the whole pack (bytes).
    pack_size: NotRequired[int]
    # The torrent info hash (hex, lower case).
    hash: NotRequired[str]
    # Torrent seeders.
    seeders: NotRequired[int]
    # Private data of the provider (JSON), given back to its `resolve(url, data=...)`.
    data: NotRequired[Any]
    # The sub-source of the provider of the source (its `SUBSOURCES` ID): its leaf in the tree of the source providers.
    sub: NotRequired[str]
    # The facts given by the provider (the groups of `lib.sdk.facts`), completed by the parsed ones.
    video: NotRequired[VideoFacts]
    audio: NotRequired[list[AudioTrack]]
    subtitles: NotRequired[list[SubtitleTrack]]
    release: NotRequired[ReleaseFacts]
    # --- DEBUG ---
    fake: NotRequired[bool]
    resolve_to: NotRequired[Union[None, str, Path]]


# Type descriptor for a position element reported by the provider (scraper) — effectively a dict.
# This is the dict returned by providers.
class SourceItem(SourceOptionalData):
    # source is de facto hosting name
    hosting: NotRequired[str]  # NOTE: old name "source" is OBSOLETE, but still supported for backward compatibility
    info: NotRequired[str]
    info2: NotRequired[str]
    url: str
    language: NotRequired[str]
    quality: NotRequired[str]
    debrid: NotRequired[str]


if TYPE_CHECKING:
    class SourceItemPattern(SourceOptionalData):
        """SourceItem but all not required, for matching source meta with pattern in SourceSelector.meta."""
        info: NotRequired[str]
        info2: NotRequired[str]
        url: NotRequired[str]
        language: NotRequired[str]
        quality: NotRequired[str]
        debrid: NotRequired[str]


# Type descriptor for a position element — effectively a dict.
# To są metadane źródła już po obróbce i teki lecą do okna źródeł. Dokładnie to co w source.meta.
class SourceMeta(SourceOptionalData):
    label: NotRequired[str]  # the text of an item of an external add-on (not shown)
    info: str
    info2: str
    language: str
    quality: str
    debrid: str


# DEBUG source meta with extra fields for const prepend and append, not used in providers, but useful for testing and const data.
class SourceXMeta(SourceMeta):
    addon: NotRequired[str]  # external provider's addon, '' means FanFilm itself
    provider: str
    hosting: str             # old "source" from provider item
    url: str


# Extra arguments of `resolve()`: from the sources window as `for_resolve`, the private data of the item (if it has one).
class SourceResolveKwargs(TypedDict):
    buy_anyway: NotRequired[bool]
    data: NotRequired[Any]


# Because Python is still missing Introsection or KeyType we have to copy all SourceMeta keys explicit.
SourceMetaRequiredKey = Literal['provider', 'hosting', 'info', 'url', 'language', 'quality', 'debrid']
SourceMetaOptionalStrKey = Literal['label', 'size', 'filename', 'color_identify', 'icon', 'info2', 'on_account_link', 'on_account_expires', 'resolve_to', 'no_transfer',
                                   'pack']
SourceMetaOptionalBoolKey = Literal['debridonly', 'direct', 'local', 'premium', 'on_account', 'fake']
SourceMetaOptionalIntKey = Literal['filesize']
SourceMetaOptionalKey: TypeAlias = 'SourceMetaOptionalStrKey | SourceMetaOptionalIntKey | SourceMetaOptionalBoolKey'
SourceMetaKey: TypeAlias = 'SourceMetaRequiredKey | SourceMetaOptionalKey'


class IncompleteResult(Exception):
    """
    The search of a provider did not end (a time limit, an error after some items): its items found so far, shown but
    not cached (the result is not complete).
    """

    def __init__(self, items: Sequence[SourceItem], reason: str = '') -> None:
        """Keep the items found so far and the reason."""
        super().__init__(reason)
        #: The items found so far.
        self.items: Sequence[SourceItem] = items


@frozen(kw_only=True)
class SearchCache:
    """
    The cache policy of a provider search (`get_provider_sources()`), for the caches of the provider itself (a provider
    add-on gets it as the context `cache`).
    """

    #: The user asked a fresh search: the caches are not read (a fresh value replaces them).
    refresh: bool = False
    #: Lifetime of the show level of an episode search (the show token, seconds, 0: not cached).
    show_ttl: int = 0
    #: Lifetime of an empty result (seconds).
    empty_ttl: int = 0


#: The cache policy of the provider search running in the thread.
_search_cache = local()


@contextmanager
def search_cache(cache: SearchCache) -> Generator[None, None, None]:
    """Set the cache policy of the provider search of the thread (see `current_search_cache()`)."""
    old = getattr(_search_cache, 'cache', None)
    _search_cache.cache = cache
    try:
        yield
    finally:
        _search_cache.cache = old


def current_search_cache() -> SearchCache | None:
    """Return the cache policy of the provider search running in the thread, None out of a search."""
    return getattr(_search_cache, 'cache', None)


class SourceSearchOverride(TypedDict):
    """Base data for source search query, used for type hints and overrides in edit dialog."""
    local_title: str     # Local (movie or show) title (in current api language, eg. PL)
    english_title: str   # English (movie or show) title
    original_title: str  # Original (movie or show) title
    year: int
    premiered: dt_date | None  # date of movie release or show aired if known (datetime.date or None)
    season: int | None   # not None for episode search
    episode: int | None  # not None for episode search
    aliases: NotRequired[list[SourceTitleAlias]]  # title aliases, the original title first (set by the search)
    query: NotRequired[Query]  # the protocol query (set by the search)


def _make_source_meta(meta: SourceMeta | None = None) -> SourceMeta:
    """Make SourceMeta with default values for missing keys."""
    required = SourceMeta.__annotations__.keys() - SourceOptionalData.__annotations__.keys()
    if meta is None:
        return {k: '' for k in required}  # type: ignore
    if (size := meta.get('filesize') or meta.get('pack_size')) and 'size' not in meta:  # the size of a pack shown as before
        from ..ff.source_utils import human_readable_size
        meta['size'] = human_readable_size(size)
    return {**{k: '' for k in required}, **meta}  # type: ignore


@frozen(kw_only=True)
class ResolveRoute:
    """One way FanFilm opens a source."""

    #: Kind of the way.
    kind: ResolveKind
    #: Its name: the provider (an account), the add-on ID (a plugin), the debrid ("Real-Debrid"), the resolver.
    name: str = ''
    #: A debrid has the torrent cached (plays at once), None: not known (the debrid does not tell, not a torrent).
    cached: bool | None = None


@frozen(kw_only=True)
class Resolvability:
    """The ways FanFilm can open a source now (accounts, debrids, resolvers, add-ons of the user), the best first."""

    #: The ways in the preference order (`const.sources.resolve.order`), none: no way opens the source.
    routes: tuple[ResolveRoute, ...] = ()

    #: Names of the kinds of ways named by their kind in the texts (the others by the name of the way).
    KIND_NAMES: ClassVar[dict[str, str]] = {'resolveurl': 'ResolveURL', 'ff': 'FanFilm'}

    @property
    def resolvable(self) -> bool:
        """Return True if some way opens the source."""
        return bool(self.routes)

    @property
    def best(self) -> ResolveRoute | None:
        """Return the preferred way, None if there is none."""
        return self.routes[0] if self.routes else None

    @property
    def cached(self) -> bool | None:
        """
        Return the cache state of the torrent on the debrids (`ResolveRoute.cached` of all of them): True - a debrid has it,
        False - a debrid which tells it has not and none has it, None - no debrid tells it (not a torrent).
        """
        states = {route.cached for route in self.routes}
        return True if True in states else False if False in states else None

    @property
    def debrid(self) -> str:
        """Return the short name of the debrid which opens the source by the best way, '' if the best way is not a debrid."""
        if (best := self.best) is None or best.kind != 'debrid':
            return ''
        return self.label(best)

    @classmethod
    def label(cls, route: ResolveRoute) -> str:
        """Return the short name of the way in the texts: a debrid by its short name (`AD`), a resolver by its kind, else its name."""
        if route.kind == 'debrid':
            return debrid_short_name(route.name)
        return cls.KIND_NAMES.get(route.kind) or route.name

    def labels(self) -> list[str]:
        """Return the short names of the ways (once each, in their order)."""
        return list(dict.fromkeys(self.label(route) for route in self.routes))

    def first(self, kind: ResolveKind) -> ResolveRoute | None:
        """Return the first way of the kind, None if there is none."""
        return next((route for route in self.routes if route.kind == kind), None)


@define(kw_only=True)
class Source:
    url: str
    addon: str = ''
    provider: str
    hosting: str
    ffitem: FFItem
    attr: SourceAttribute = field(factory=SourceAttribute)
    meta: SourceMeta = field(factory=_make_source_meta, converter=_make_source_meta)
    #: The resolve result: the stream to play (DYNAMIC, never stored), None: not resolved.
    stream: ResolveResult | None = None
    enabled: bool = True
    #: The ways to open it now (DYNAMIC: the user's accounts, debrids, add-ons; never stored), None: not derived yet.
    resolvability: Resolvability | None = None
    _size: int | None = field(init=False, repr=False, default=None)
    #: The facts (from `file_name` and the info texts), None: not parsed yet.
    _facts: Facts | None = field(init=False, repr=False, default=None)

    #: The sources of a release which are cinema copies (the quality `CAM` / `SCR` of a provider is right for them).
    CINEMA_SOURCES: ClassVar[frozenset[ReleaseSource]] = frozenset((ReleaseSource.CAM, ReleaseSource.TELESYNC, ReleaseSource.TELECINE,
                                                                    ReleaseSource.SCREENER))

    def __attrs_post_init__(self) -> None:
        """
        Set the quality of the vocabulary (`QUALITIES` of the protocol): an alias, unknown - of the frame height of the facts,
        else `SD`. A `CAM` / `SCR` of the provider which the facts deny (a known release source, not a cinema copy, and a frame
        height: `….WEB-DL….mkv.ts`, the extension read as a telesync) is of the frame height too.
        """
        quality = quality_label(self.meta.get('quality') or '')
        height = (self.facts.get('video') or {}).get('height') or 0
        source = (self.facts.get('release') or {}).get('source')
        if quality in ('CAM', 'SCR') and height and source is not None and source not in self.CINEMA_SOURCES:
            quality = None
        self.meta['quality'] = quality or quality_of_resolution(height=height)

    RX_M38U: ClassVar[Pattern[str]] = re.compile(r'^https?://.*\.m3u8\b')
    RX_NOT_M38U: ClassVar[Pattern[str]] = re.compile(r'\.(?:avi|mkv|mp4|ts|mpg)\b')
    #: Page suffixes of a file name in a URL (`movie.mkv.html`).
    RX_PAGE: ClassVar[Pattern[str]] = re.compile(r'(\.(html?|php))+$', re.IGNORECASE)

    @property
    def unresolvable(self) -> bool:
        """Return True if the resolvability is derived and no way opens the source now."""
        return self.resolvability is not None and not self.resolvability.resolvable

    @property
    def transfer_short(self) -> bool:
        """
        Return True if the provider account has too little transfer for the source (`no_transfer`, not on the account) and no other way
        opens it: the account was its way (the resolvability not derived: as the provider says).
        """
        return bool(self.get('no_transfer')) and not self.get('on_account') and not (self.resolvability and self.resolvability.resolvable)

    @property
    def rule_premium(self) -> bool:
        """Return True if the rules take the source for a premium one: `premium`, a torrent a debrid has cached (`const.sources.resolve.cached_premium`)."""
        cached = const.sources.resolve.cached_premium and self.resolvability is not None and self.resolvability.cached is True
        return bool(self.meta.get('premium', False) or cached)

    def match(self, pat: SourceSelector) -> bool:
        """Check if source match given pattern (every field by `match_value()`)."""
        matched = match_value
        if pat.addon is not None and not matched(self.addon, pat.addon):
            return False
        if pat.provider and not matched(self.provider, pat.provider):
            return False
        if pat.hosting and not matched(self.hosting, pat.hosting):
            return False
        if pat.platform is not None:
            from ..ff.kotools import get_platform
            platform = get_platform()
            if not matched(platform, pat.platform):
                return False
        if pat.m3u8 is not None and ((m3u8 := self.is_m3u8()) is None or not matched(m3u8, pat.m3u8)):  # XXX
            return False
        if pat.setting:
            from ..ff.settings import settings
            if not settings.eval(pat.setting):
                return False
        if pat.kodi is not None:
            from ..kodi import KODI
            if isinstance(pat.kodi, int):
                if KODI >= pat.kodi:
                    return False
            elif not matched(KODI, pat.kodi):
                return False
        if pat.premium is not None and not matched(self.rule_premium, pat.premium):
            return False
        if pat.meta is not None and not matched(self.meta, pat.meta):
            return False
        if pat.size is not None and pat.size != self.size:
            return False
        if pat.media is not None and not matched(self.ffitem.ref.real_type, pat.media):
            return False
        if pat.resolvability is not None and not matched(self.resolvability, pat.resolvability):  # known in the filter (`filter_sources()`)
            return False
        if pat.facts is not None and not matched(self.facts, pat.facts):
            return False
        return True

    def apply_rules(self, rules: dict[SourceSelector, SourceRuleValue] | None = None, *, update_meta: bool = True) -> bool:
        """Apply all mathing rules, return True if attr changed."""
        if rules is None:
            rules = const.sources.rules
        # old attrs
        attr_dict = asdict(self.attr)
        # lookup
        enabled = True
        changed = False
        ff: Sequence[Attribute] = fields(SourceAttribute)
        for sel, attr in rules.items():
            if attr is not None and self.match(sel):
                enabled = attr is not False
                if attr is not False and attr is not True:
                    # update attrs, only if new value is not None and value changed
                    for f in ff:
                        val = getattr(attr, f.name)
                        if val is not None and getattr(self.attr, f.name) is None and val != attr_dict[f.name]:
                            if f.name == 'meta':
                                attr_dict[f.name] = merged_meta(attr_dict[f.name] or {}, val)
                            elif f.name == 'badge':
                                old = {source_attribute_badge_key(b): b for b in attr_dict[f.name] or ()}
                                new = {source_attribute_badge_key(b): b for b in val or ()}
                                attr_dict[f.name] = tuple({**old, **new}.values())
                            else:
                                attr_dict[f.name] = val
                            changed = True
                    if update_meta and attr.meta:
                        self.meta = merged_meta(self.meta, attr.meta)  # type: ignore[assignment]  # a SourceMeta still
                        if FACT_GROUPS & attr.meta.keys() or {'info', 'info2', 'filename', 'language'} & attr.meta.keys():
                            self._facts = None  # the facts again, from the new meta
                    if attr.final:
                        break
        self.enabled = enabled
        if changed:
            self.attr = SourceAttribute(**attr_dict)
        return changed

    def attr_update(self, rules: dict[SourceSelector, SourceRuleValue] | None = None) -> bool:
        """Apply all mathing rules (do not update Source.meta), return True if attr changed."""
        return self.apply_rules(rules, update_meta=False)

    def is_enabled_by_applied_rules(self) -> bool:
        """Apply all mathing rules and return True if source is enabled."""
        self.apply_rules()
        return self.enabled

    @property
    def resolved(self) -> bool:
        """Return True if the source is resolved (its `url` is the stream to play)."""
        return self.stream is not None

    def with_stream(self, stream: ResolveResult) -> Self:
        """Return the source resolved to the `stream` (its `url` the Kodi path of the stream)."""
        return evolve(self, url=kodi_url(stream), meta=self.meta.copy(), stream=stream)

    @property
    def resolved_url(self) -> str:
        """Return URL after resolve or empty string."""
        return self.url if self.resolved else ''

    def is_m3u8(self) -> bool | None:
        """Determine if is m3u8 file. Return None if unknown."""
        # stream URL is known
        if self.resolved:
            return bool(self.RX_M38U.search(self.url))
        # link is not resolved, the name could be ok or not, then...
        # ... it's m3u8
        if self.RX_M38U.search(self.url):
            return True
        # ... it's another file
        if self.RX_NOT_M38U.search(self.url):
            return False
        # ... we ca not determine
        return None

    def set_play_mode(self, play: PlayMode) -> None:
        self.attr = evolve(self.attr, play=play)

    def menu_actions(self) -> Iterator[SourceAction]:
        """Iterate over avaliable contex-menu actions (like play-modes). Action `play` is replaced with `direct or `isa`."""
        actions = self.attr.menu
        if actions is None:
            actions = ('play', )
        for act in actions:
            if act == 'play':
                if self.attr.play != 'direct':
                    yield 'direct'
                # ISA is not a default and m3u8 is not false (means is true or none/unknown)
                if self.attr.play != 'isa' and self.is_m3u8() is not False:
                    yield 'isa'
            else:
                yield act

    @property
    def size(self) -> int:
        """Return the size in bytes: `filesize`, else of the size text (`12.3 GB`), else of the last part of `info`; 0 if unknown."""
        if self._size is None:
            size = self.meta.get('filesize')
            if not isinstance(size, int):
                size = size_bytes(self.meta.get('size') or '') or size_bytes((self.meta.get('info') or '').rpartition('|')[2]) or 0
            self._size = size
        return self._size

    @property
    def file_name(self) -> str:
        """
        Return the file name: the one of the provider, else the last part of the URL path or `info2` if it is a file name
        (its extension is a known container), else empty.
        """
        if name := self.meta.get('filename'):
            return unescape(unquote(name))
        path = urlsplit(self.url).path.replace(' / ', ' ').replace('_/_', '_').rstrip('/').rpartition('/')[2]
        for text in (path.rstrip('\\').rpartition('\\')[2], self.meta.get('info2') or ''):  # a local file of Windows too
            text = unescape(unquote(self.RX_PAGE.sub('', text)))
            if '.' in text and Container.find(text.rpartition('.')[2]):
                return text
        """
        # to raczej nie będzie już wykorzystywane, bo okazało się, że info może mieć juz swoje oznaczenia, więc mogą się dublować
        text = self.meta.get('info') or ''
        # próba odfiltrowania nazwy
        return text.split('|')[-1].strip().lstrip('(').rstrip(')')
        """
        return ''

    @property
    def facts(self) -> Facts:
        """Return the facts of the source (video, audio, subtitles, release) from its file name and info texts."""
        if self._facts is None:
            texts = (self.file_name, self.meta.get('info') or '', self.meta.get('info2') or '')
            self._facts = parse(' | '.join(text for text in texts if text), language=(self.meta.get('language') or '').lower() or None)
            if given := {group: self.meta[group] for group in FACT_GROUPS if group in self.meta}:  # type: ignore[literal-required]
                self._facts = complete(given, self._facts)  # type: ignore[arg-type]
        return self._facts

    def as_json(self, *, dynamic: bool = True) -> JsonData:
        """
        Return JSON data without FFItem. Without `dynamic` (the cache of the results) the account state (`DYNAMIC_KEYS`) is
        skipped and what the rules give (`attr`, `enabled`: set in the filter of every search, `apply_rules()`).
        """
        data = asdict(self, recurse=True, filter=filters.exclude('ffitem', '_size', '_facts', 'resolvability', 'stream'))
        if not dynamic:
            data['meta'] = {key: val for key, val in data['meta'].items() if key not in DYNAMIC_KEYS}
            del data['attr'], data['enabled']
        return data

    @classmethod
    def from_json(cls, data: JsonData, *, ffitem: FFItem) -> Self:
        """Return source from JSON data with FFItem."""
        data = dict(data)
        data.pop('resolved', None)  # a cache row of an older version
        data.pop('attr', None)  # the rules give them in the filter: a cache row of an older version had them
        data.pop('enabled', None)
        return cls(ffitem=ffitem, **data)

    @classmethod
    def from_provider_dict(cls, *, addon: str = '', provider: str, ffitem: FFItem, item: SourceItem) -> Self:
        """Create instance from provider's meta-item-dict."""
        meta: SourceMeta = dict(item)  # type: ignore[reportGeneralTypeIssues]
        if addon:
            for key in ADDON_TEXT_KEYS:
                if isinstance(text := meta.get(key), str):
                    meta[key] = addon_text(text)  # type: ignore[literal-required]  # the keys of the texts
        url: str = meta.pop('url', '')  # type: ignore[reportGeneralTypeIssues]
        hosting: str = meta.pop('hosting', '') or meta.pop('source', '').lower()  # type: ignore[reportGeneralTypeIssues]
        return cls(url=url, addon=addon, provider=provider, hosting=hosting, ffitem=ffitem, meta=meta)  # the rules: in the filter

    @classmethod
    def from_meta(cls, *, ffitem: FFItem, meta: SourceXMeta) -> Self:
        """DEBUG. Create instance from already updated meta-dict. Useful for const prepend and append."""
        attr = SourceAttribute()
        meta = SourceXMeta(meta)
        # Type ignore, because .get() works, .pop() not, false positive, pop() returns object|DEFAULT for required keys,
        # but we know they are there, because of SourceXMeta type.
        # After pop() SourceXMeta became SourceMeta and it's correct Source `meta` argument.
        url: str = meta.pop('url', '')  # type: ignore
        addon: str = meta.pop('addon', '')
        provider: str = meta.pop('provider', '')  # type: ignore
        hosting: str = meta.pop('hosting', '') or meta.pop('source', '')  # type: ignore
        src = cls(url=url, addon=addon, provider=provider, hosting=hosting.lower(), ffitem=ffitem, attr=attr, meta=meta)
        src.apply_rules()
        return src

    @classmethod
    def action_label(cls, action: SourceAction) -> str:
        from ..kolang import L
        if action == 'direct':
            return L(30311, 'Play direct')
        elif action == 'isa':
            return L(30310, 'Play via InputStream')
        elif action == 'buy':
            return L(30116, 'Buy it again')
        return ''

    # --- dict-like infterface (readonly) ---

    def __contains__(self, key: Any) -> bool:
        return key in self.meta

    def __getitem__(self, key: SourceMetaRequiredKey) -> str:
        if key == 'provider':
            return self.provider
        if key == 'hosting':
            return self.hosting
        if key == 'url':
            return self.url
        return self.meta[key]

    @overload
    def get(self, key: SourceMetaRequiredKey, default: Any = None) -> str: ...

    @overload
    def get(self, key: SourceMetaOptionalStrKey, default: T = None) -> str | T: ...

    @overload
    def get(self, key: SourceMetaOptionalIntKey, default: T = None) -> int | T: ...

    @overload
    def get(self, key: SourceMetaOptionalBoolKey, default: T = None) -> bool | T: ...

    @overload
    def get(self, key: Any, default: T = None) -> T: ...

    def get(self, key: Any, default: T = None) -> Union[str, int, bool, T]:
        if key == 'provider':
            return self.provider
        if key == 'hosting':
            return self.hosting
        if key == 'url':
            return self.url
        return self.meta.get(key, default)

    def keys(self) -> KeysView[str]:
        return self.meta.keys()

    def values(self):  # -> ValuesView[Union[int, bool]]:
        return self.meta.values()

    def items(self):  # -> ItemsView[str, Union[int, bool]]:
        return self.meta.items()

    # --- dict-like infterface (write) ---  TODO: think it's really necesery

    @overload
    def __setitem__(self, key: Union[SourceMetaRequiredKey, SourceMetaOptionalStrKey], value: str) -> None: ...

    @overload
    def __setitem__(self, key: SourceMetaOptionalBoolKey, value: bool) -> None: ...

    def __setitem__(self, key: str, value: Union[str, bool]) -> None:
        if key in ('provider', 'hosting', 'url'):
            log.error(f'Set Source[{key:r}] is not allowed')
        self.meta[key] = value

    def update(self, data: dict[SourceMetaKey, Any], /):
        if wrong := ({'provider', 'hosting', 'url'} & data.keys()):
            log.error(f'Source.update() for {", ".join(map(repr, wrong))} is not allowed')
        self.meta.update(data)  # type: ignore[reportCallIssue]  # there is no Partial[SourceMeta] yet

    def badge_update(self, badge: Sequence[SourceAttributeBadge] | None) -> None:
        """Update source badge."""
        if badge is None:
            return
        if self.attr.badge is not None:
            # badge = tuple(set(self.attr.badge) | set(badge))
            badge = tuple((*self.attr.badge, *badge))
        self.attr = evolve(self.attr, badge=badge)


class SourceTitleAlias(TypedDict):
    """Alias for title, used in provider protocol. Like FFTitleAlias but as dict."""
    title: str
    country: str


#: "class source" type.
class ProviderOldProtocol(Protocol):
    """Source provider class protocol (api)."""

    #: True, if __init__ accepts ffitem.
    # INIT_WITH_FFITEM: ClassVar[bool] = False

    # -- old "sources" api (still used) ---
    priority: ClassVar[int] = 1
    language: ClassVar[Collection[str]] = ()
    # "domains" is not used

    # --- those settings are parsed but not required, see Provider class ---
    # has_sort_order: ClassVar[bool] = False
    # has_color_identify2: ClassVar[bool] = False
    # has_library_color_identify2: ClassVar[bool] = False
    # use_premium_color: ClassVar[bool] = False
    # CATEGORIES: ClassVar[Collection[MediaCategory] | None] = None

    # --- provider instance data, set in sources.py ---
    canceled: bool
    ffitem: FFItem   # set in ff/sources.py at that moment

    # def __init__(self, *, ffitem: FFItem) -> None: ...

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None: ...

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> Any: ...

    def episode(self, url: str, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> str | None: ...

    def sources(self, url: str, host_list: Sequence[str], pr_host_list: Sequence[str], /) -> Sequence[SourceItem]: ...

    def resolve(self, url: str, **kwargs: Unpack[SourceResolveKwargs]) -> str | ResolveResult | None: ...


#: new provider class type.
class ProviderNewProtocol(Protocol):
    """Source provider class protocol (api)."""

    #: True, if __init__ accepts ffitem.
    # INIT_WITH_FFITEM: ClassVar[bool] = False

    PRIORITY: ClassVar[int] = 1
    LANGUAGES: ClassVar[Collection[str]] = ()
    CATEGORIES: ClassVar[Collection[MediaCategory] | None] = None

    # --- those settings are parsed but not required, see Provider class ---
    # has_sort_order: ClassVar[bool] = False
    # has_color_identify2: ClassVar[bool] = False
    # has_library_color_identify2: bool = False
    # use_premium_color: ClassVar[bool] = False

    # --- not required ---
    # MEDIA: ClassVar[Collection[MediaType] | None] = None   # searched media types, None means all
    # def find_show(self, *, ffitem: FFItem, override: SourceSearchOverride) -> JsonData: ...  # show token for find()

    # --- provider instance data, set in sources.py ---
    canceled: bool
    ffitem: FFItem   # set in ff/sources.py at that moment

    def find(self, *,
             ffitem: FFItem,
             override: SourceSearchOverride,
             **kwargs: Any,   # show: the show token from find_show() (only if the provider has find_show())
             ) -> Iterable[SourceItem]: ...

    def resolve(self, url: str, **kwargs: Unpack[SourceResolveKwargs]) -> str | ResolveResult | None: ...


#: module/multi provider class type.
# class ProviderAddonProtocol(ProviderNewProtocol):
class ProviderAddonProtocol(Protocol):
    """Module/multi/addon provider protocol, supports aPI for grab addons and providers."""

    PRIORITY: ClassVar[int] = 1
    LANGUAGES: ClassVar[Collection[str]] = ()
    CATEGORIES: ClassVar[Collection[MediaCategory] | None] = None

    def scan_addons(self) -> Iterable[SourceAddonInfo]: ...
    def get_addon(self, addon: SourceAddonInfo, /, *, ffitem: FFItem) -> SourceAddonModule: ...
    def get_providers(self, *, ffitem: FFItem, override: SourceSearchOverride) -> Iterable[ProviderModule]: ...


ProviderProtocol: TypeAlias = 'ProviderOldProtocol | ProviderNewProtocol'


def is_scan_addon_protocol(provider: ProviderProtocol) -> TypeGuard[ProviderAddonProtocol]:
    """Check if provider is addon protocol by presence of scan_addons() method."""
    return callable(getattr(provider, 'scan_addons', None))


def is_provider_addon_protocol(provider: ProviderProtocol) -> TypeGuard[ProviderAddonProtocol]:
    """Check if provider is addon protocol by presence of scan_addons() method."""
    return callable(getattr(provider, 'get_addon', None)) and callable(getattr(provider, 'get_providers', None))


def is_provider_new_protocol(provider: ProviderProtocol) -> TypeGuard[ProviderNewProtocol]:
    """Check if provider is new protocol by presence of find() method."""
    return callable(getattr(provider, 'find', None))


class ProviderDynamicProtocol(Protocol):
    """Optional provider capability: apply the DYNAMIC data (account state) to the static sources."""

    def apply_dynamic(self, *,
                      ffitem: FFItem,
                      override: SourceSearchOverride,
                      sources: list[Source],
                      ) -> Iterable[Source | SourceItem]:
        """
        Turn the static sources (a fresh search or the cache) into the final list of valid sources.

        Called on every search. It may mark sources (`on_account`, `no_transfer`, ...), replace them, add new ones
        (e.g. files from the account library) or remove them. Its result is never cached.
        """
        ...


def has_apply_dynamic(provider: ProviderProtocol) -> TypeGuard[ProviderDynamicProtocol]:
    """Check if provider supports apply_dynamic() capability."""
    return callable(getattr(provider, 'apply_dynamic', None))


def is_provider_old_protocol(provider: ProviderProtocol) -> TypeGuard[ProviderOldProtocol]:
    """Check if provider is new protocol by presence of find() method."""
    return ((callable(getattr(provider, 'movie', None)) or callable(getattr(provider, 'episode', None)))
            and callable(getattr(provider, 'sources', None)))


class ProviderOptions:
    """Default Provider and Addon-Provider class options."""

    #: True, if __init__ accepts ffitem.
    INIT_WITH_FFITEM: ClassVar[bool] = False

    #: Provider priority, lower is higher priority. Used for sorting providers BEFORE sorting sources.
    PRIORITY: ClassVar[int] = 1
    #: Supported languages, empty means all. Used for prefiltering providers before searching sources.
    LANGUAGES: ClassVar[Collection[str]] = ()
    #: Supported media categories, None means all. Used for prefiltering providers before searching sources.
    CATEGORIES: ClassVar[Collection[MediaCategory] | None] = None
    #: True, if the provider returns premium services (the `premium` meta key), False – never, None – unknown (the providers of the
    #: external add-ons, the xproviders), (True, False) – some of them (`ProviderModule.premium_mixed`).
    PREMIUM: ClassVar[bool | Collection[bool] | None] = None

    has_library_color_identify2: ClassVar[bool] = False

    #: Searched media types ('movie', 'show'), None means all. Used for prefiltering providers before searching sources.
    MEDIA: ClassVar[Collection[MediaType] | None] = None

    #: Lifetime of the cached source list in seconds, zero = do not cache, None = default (const.sources.cache).
    SOURCES_TTL: ClassVar[int | None] = None
    #: Lifetime of the cached show token (`find_show()`) in seconds, zero = do not cache, None = default.
    SHOW_TTL: ClassVar[int | None] = None

    # --- the declaration for the choice of the user (`lib.sources.natives`; the old API classes have the same attributes) ---
    #: The label of the provider in the choice, '' - its name.
    LABEL: ClassVar[str] = ''
    #: Its own settings (after the ones of the `has_*` flags; the same key replaces a flag one).
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = ()
    #: The Kodi add-ons it needs (one of them enabled), empty - none.
    REQUIRES: ClassVar[tuple[str, ...]] = ()
    #: The services it delegates to (the leaves under it in the choice).
    SUBSOURCES: ClassVar[tuple[SubSource, ...]] = ()
    #: The sites of its cookies (the FanFilm web interface writes them to its settings).
    COOKIES: ClassVar[tuple[SiteCookies, ...]] = ()


class Provider(ProviderOptions):
    """Base provider class."""

    # --- provider instance data, set in sources.py ---
    ffitem: FFItem   # set in ff/sources.py at that moment
    # canceled: bool

    # --- explicit __init__ with ffitem  ---

    #: True, if __init__ accepts ffitem.
    INIT_WITH_FFITEM: ClassVar[bool] = True

    def __init__(self, *, ffitem: FFItem) -> None:
        self.ffitem = ffitem
        self.canceled = False  # TODO: check id needed

    # --- framework data, set by bind_provider() (also on protocol-only providers, without the base class) ---
    #: Provider (module) name.
    name: str
    #: Provider data (sessions, tokens), also `provider_store(name)` where there is no instance (e.g. in `__init__`).
    store: ProviderStore

    # --- search: the new API (find, optional find_show) or the old one (movie / tvshow / episode / sources) ---

    def resolve(self, url: str, **kwargs: Unpack[SourceResolveKwargs]) -> str | ResolveResult | None:
        """Resolve source URL: return the resolved URL (a text, `url|headers`...) or the resolve result dict, None if dead."""
        return url


def source_item(item: Item) -> SourceItem:
    """Return the FanFilm source item of a protocol item: the account state (`dynamic`) flat in the item."""
    result: dict[str, Any] = dict(item)
    result.update(result.pop('dynamic', None) or {})
    return result  # type: ignore[return-value]


def protocol_item(source: Source) -> Item:
    """Return the protocol item of a FanFilm source (the opposite of `source_item()`): its hosting, link and meta."""
    return item_from_legacy({**source.meta, 'url': source.url, 'source': source.hosting})


def title_aliases(ffitem: FFItem, original_title: str) -> list[SourceTitleAlias]:
    """Return the title aliases of the search: of the movie or of the show for an episode, the original title first."""
    item = ffitem.show_item or ffitem
    aliases: list[SourceTitleAlias] = [{'title': a.title, 'country': a.country} for a in item.aliases_info]
    if original_title:
        aliases.insert(0, {'title': original_title, 'country': 'original'})
    return aliases


#: The external IDs of the query (the keys of `QueryIds`).
QUERY_ID_KEYS: tuple[str, ...] = tuple(QueryIds.__annotations__)


def _query_ids(item: FFItem) -> QueryIds:
    """Return the external IDs of the item for the query."""
    return {key: val for key in QUERY_ID_KEYS if (val := item.get_id(key))}  # type: ignore[return-value]


def search_query(ffitem: FFItem, override: SourceSearchOverride, *, lang: str = '') -> Query:
    """
    Return the protocol query of the search: the titles, the year, the date, the season and the episode of `override`
    (the user can edit them), the rest of the item (the movie, or the show of an episode).
    """
    ov = override
    episode = ffitem.ref.type != 'movie'
    item = ffitem.show_item if episode and ffitem.show_item is not None else ffitem
    aliases = ov.get('aliases')
    query: Query = {
        'type': 'episode' if episode else 'movie',
        'ids': _query_ids(item),
        'title': {'local': ov['local_title'], 'english': ov['english_title'], 'original': ov['original_title']},
        'aliases': list(aliases) if aliases is not None else title_aliases(ffitem, ov['original_title']),
        'year': ov['year'],
        'premiered': None if ov['premiered'] is None else str(ov['premiered']),
    }
    if lang:
        query['lang'] = lang
    if countries := item.vtag.getCountryCodes():
        query['countries'] = countries
    if languages := item.vtag.getLanguageCodes():
        query['original_languages'] = languages
    if duration := ffitem.vtag.getDuration():
        query['duration'] = duration
    if (anime := ffitem.anime_info or item.anime_info) is not None and anime.cours:
        query['anime'] = anime.__to_json__()  # type: ignore[typeddict-item]  # the same JSON form
    if episode:
        if ov['season'] is not None:
            query['season'] = ov['season']
            if season_episodes := item.season_episode_count(ov['season']):
                query['season_episodes'] = season_episodes
        if ov['episode'] is not None:
            query['episode'] = ov['episode']
        query['episode_ids'] = _query_ids(ffitem)
        query['episode_title'] = ffitem.title
        if (aired := ffitem.date) is not None:
            query['episode_aired'] = aired.isoformat()
        if item.children_count is not None:
            query['total_seasons'] = item.children_count
        if (absolute := ffitem.absolute_episode_number()) is not None:
            query['absolute_episode'] = absolute
    return query


def provider_query(ffitem: FFItem, override: SourceSearchOverride) -> Query:
    """Return the protocol query of the search (made once by the search, made here if the caller gives none)."""
    if (query := override.get('query')) is not None:
        return query
    return search_query(ffitem, override)


def old_api_find_show(provider: ProviderOldProtocol, *, ffitem: FFItem, override: SourceSearchOverride) -> Any:
    """Return the show token of an old API provider (its `tvshow()` result)."""
    return ff_dialect.old_api_find_show(provider, provider_query(ffitem, override))


def old_api_find(provider: ProviderOldProtocol, *, ffitem: FFItem, override: SourceSearchOverride, show: Any = MISSING,
                 ) -> Sequence[SourceItem]:
    """
    Search sources with an old API provider: `movie()` or [`tvshow()`] + `episode()`, then `sources()`.

    `show` is the show token (cached by the framework); without it `tvshow()` is called here.
    """
    from ..ff.sources import supported_hosts, PREMIUM_HOSTS
    return ff_dialect.old_api_find(provider, provider_query(ffitem, override), hosts=supported_hosts(), premium_hosts=PREMIUM_HOSTS,
                                   show=show)  # type: ignore[return-value]


class OldProviderAdapter:
    """
    New API (`find`, `find_show`) of an old API provider (`movie`, `tvshow`, `episode`, `sources`).

    Any other attribute (`resolve`, `apply_dynamic`, class options, ...) is the wrapped provider's one.
    """

    def __init__(self, provider: ProviderOldProtocol) -> None:
        object.__setattr__(self, 'provider', provider)

    def __getattr__(self, name: str) -> Any:
        if name == 'find_show' and callable(getattr(self.provider, 'tvshow', None)):
            return self._find_show
        return getattr(self.provider, name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self.provider, name, value)

    def __repr__(self) -> str:
        return f'OldProviderAdapter({self.provider!r})'

    @property
    def MEDIA(self) -> tuple[MediaType, ...]:
        """Searched media types, by the old API methods."""
        return tuple(media for media, method in (('movie', 'movie'), ('show', 'episode')) if callable(getattr(self.provider, method, None)))

    def _find_show(self, *, ffitem: FFItem, override: SourceSearchOverride) -> Any:
        """Return the show token (the `tvshow()` result)."""
        return old_api_find_show(self.provider, ffitem=ffitem, override=override)

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride, show: Any = MISSING, **kwargs: Any) -> Sequence[SourceItem]:
        """Search sources by the old API."""
        return old_api_find(self.provider, ffitem=ffitem, override=override, show=show)


def unwrap_provider(provider: ProviderProtocol) -> ProviderProtocol:
    """Return the provider itself (not its old API adapter)."""
    return provider.provider if isinstance(provider, OldProviderAdapter) else provider


def provider_supports(provider: ProviderProtocol, media: MediaType) -> bool:
    """Check if the provider (the new API or an adapted old one) searches the `media` type."""
    return callable(getattr(provider, 'find', None)) and (not (medias := getattr(provider, 'MEDIA', None)) or media in medias)


def bind_provider(srcmod: ProviderModule, *, ffitem: FFItem) -> ProviderModule:
    """Set the framework data of a provider instance (inherited or protocol-only), adapt the old API to the new one."""
    provider = srcmod.provider
    provider.name = srcmod.name
    provider.store = provider_store(srcmod.name)
    provider.ffitem = ffitem   # the old API reads it (an instance is created for each search)
    if not is_provider_new_protocol(provider) and is_provider_old_protocol(provider):
        srcmod = evolve(srcmod, provider=OldProviderAdapter(provider))
    return srcmod


@frozen(kw_only=True)
class SourceAddonInfo:
    """Providers addon proxy."""
    #: Addon (kodi) ID.
    addon: str
    #: Addon short name (lowercase).
    name: str = ''
    #: Human readable addon name.
    title: str = ''
    #: Addon provider internal data. Should by JSON-able.
    data: Any = None
    #: Addon (kodi) ID.
    path: Path = field(default=None)

    def __attrs_post_init__(self):
        if not self.name:
            object.__setattr__(self, 'name', safe_addon_name(self.addon.rpartition('.')[2].replace('_', ' ').lower(), self.addon))
        if not self.title:
            object.__setattr__(self, 'title', safe_addon_name(self.addon.rpartition('.')[2].replace('_', ' ').title(), self.addon))
        if not self.path:
            path = Path(translatePath('special://home/addons')) / self.addon
            object.__setattr__(self, 'path', path)

    def create_module(self, provider: ProviderAddonProtocol) -> SourceAddonModule:
        """Create addon module from addon info and provider."""
        return SourceAddonModule(info=self, provider=provider)


def merged_meta(meta: Mapping[str, Any], update: Mapping[str, Any]) -> dict[str, Any]:
    """Return the meta updated (a rule, `SourceAttribute.meta`): a mapping merged into a mapping (nested), another value (a list too) replaced."""
    result = dict(meta)
    for key, value in update.items():
        result[key] = merged_meta(old, value) if isinstance(value, Mapping) and isinstance(old := result.get(key), Mapping) else value
    return result


def enabled_by_rules(match: Callable[[SourceSelector], bool], rules: Mapping[SourceSelector, SourceRuleValue] | None = None) -> bool:
    """Check if an add-on / a provider (its `match`) is enabled by `rules` (default `const.sources.rules`), False: disabled at all."""
    if rules is None:
        rules = const.sources.rules
    enabled: bool = True
    for pat, attr in rules.items():
        if attr is False:  # disabled
            # no source condition means disable provider
            if match(pat) and not pat.has_source_condition():
                enabled = False
        elif enabled is False:
            # currently disabled, check for re-enable
            enabled = match(pat)
    return enabled


#: The texts of a source of an external add-on shown in the sources window (the layout tags are removed, `addon_text()`).
ADDON_TEXT_KEYS: tuple[str, ...] = ('label', 'info', 'info2')
#: Kodi label tags of the layout (a new line, tabs): an external add-on does not know the rows of the FanFilm windows.
RX_LAYOUT_TAG = re.compile(r'\[CR\]|\[TABS\]\d*\[/TABS\]')


def addon_text(text: str) -> str:
    """Return a text of a source of an external add-on without the layout tags: a new line is ` | `, tabs a space."""
    return RX_LAYOUT_TAG.sub(lambda mch: ' | ' if mch[0] == '[CR]' else ' ', text)


def forbidden_words() -> str:
    """Return the regex alternatives of the names reserved for FanFilm (`const.sources.addons.forbidden_names`)."""
    return '|'.join(map(re.escape, const.sources.addons.forbidden_names))


def forbidden_addon_name(name: str) -> bool:
    """Return True if the name of an external add-on is reserved for FanFilm (`const.sources.addons.forbidden_names`, a version too)."""
    return re.fullmatch(rf'(?:{forbidden_words()})\W*(?:\d+(?:\.\d+)*)?', strip_label_tags(name).strip(), re.IGNORECASE) is not None


def addon_id_name(addon_id: str) -> str:
    """
    Return the name of an external add-on from its ID: the ID without `plugin.video.<forbidden name>.` (else `-`),
    e.g. `plugin.video.fanfilm.tele` -> `tele`; the whole ID if nothing (or a forbidden name) is left.
    """
    for sep in '.-':
        if (mch := re.fullmatch(rf'plugin\.video\.(?:{forbidden_words()})\d*{re.escape(sep)}(.+)', addon_id, re.IGNORECASE)) and not forbidden_addon_name(mch[1]):
            return mch[1]
    return addon_id


def safe_addon_name(name: str, addon_id: str) -> str:
    """Return the name of an external add-on, its name from its ID if the name is reserved for FanFilm (`forbidden_addon_name()`)."""
    return addon_id_name(addon_id) if forbidden_addon_name(name) else name


def addon_title(path: Path) -> str:
    """Return the human readable name of an external add-on in the folder (`addon.xml`, not a name reserved for FanFilm)."""
    from ..ff.kotools import addon_name
    return safe_addon_name(addon_name(path), path.name)


#: The last words of an add-on name which tell its kind, not its name (dropped in its short name: `addon_short_name()`).
ADDON_KIND_WORDS: tuple[str, ...] = ('Module', 'Script')


def addon_short_name(path: Path) -> str:
    """
    Return the short name of an external add-on in the folder (over the provider of its source): the one of its manifest
    (`Manifest.short_name`), else its name (`addon_title()`) without its category (`addon_name_parts()`) and its kind as the last
    word (`ADDON_KIND_WORDS`), e.g. `CocoScrapers Module` -> `CocoScrapers`; never a name reserved for FanFilm.
    """
    from ..sdk.manifest import read_manifest
    if (manifest := read_manifest(path)) is not None and manifest.short_name.strip():
        return safe_addon_name(manifest.short_name.strip(), path.name)
    name = addon_name_parts(addon_title(path))[1]
    rest, _, last = name.rpartition(' ')
    return rest.strip() if rest.strip() and last in ADDON_KIND_WORDS else name


def addon_name_parts(name: str) -> tuple[str, str]:
    """Return the category and the name of an add-on name in the Kodi way `Category: Name` (without a category: '' and the name)."""
    category, sep, rest = name.partition(':')
    if sep and category.strip() and rest.strip():
        return category.strip(), rest.strip()
    return '', name


def addon_prefixes(infos: Iterable[SourceAddonInfo]) -> dict[str, str]:
    """
    Return the provider name prefixes of the add-ons by add-on ID (`<prefix>:<provider>`): the short name, or the full
    ID if more add-ons have the same short name (they would share the cache, the provider store and the settings).
    """
    infos = list(infos)
    count = Counter(info.name for info in infos)
    return {info.addon: info.name if count[info.name] == 1 else info.addon for info in infos}


@frozen(kw_only=True)
class SourceAddonModule:
    """Providers addon proxy."""
    #: Info.
    info: SourceAddonInfo
    #: Addon provider.
    provider: ProviderAddonProtocol
    # #: Providers from the addon.
    # providers: Sequence[ProviderModule] = field(factory=tuple)

    @property
    def addon(self) -> str:
        """Return addon ID."""
        return self.info.addon

    @property
    def name(self) -> str:
        """Return addon name."""
        return self.info.name

    @property
    def title(self) -> str:
        """Return addon title."""
        return self.info.title

    def match(self, pat: AddonSelector) -> bool:
        """Check if source match given providers addon pattern (only addon level) for prefiltering."""
        return pat.addon is None or match_value(self.info.addon, pat.addon)

    def is_enabled_by_rules(self, rules: Mapping[SourceSelector, SourceRuleValue] | None = None) -> bool:
        """Check if addon is enabled by given rules. False means the addon is disabled at all (any source will not match)."""
        return enabled_by_rules(self.match, rules)

    def get_addon_paths(self) -> tuple[list[Path], list[Path]]:
        """Return the import paths of the add-on: its own and of its required imports, see `addon_paths()`."""
        return addon_paths(self.info.addon, path=self.info.path)


@frozen(kw_only=True)
class ProviderModule:
    """Tuple from load source/*/* modules, provider proxy."""
    #: Module name.
    name: str
    #: Module source object.
    provider: ProviderProtocol
    #: Group of the sources (eg. language like "en", "pl").
    group: str = ''
    #: Addon ID if provider is from addon, empty string otherwise (FanFilm itself).
    addon: str = ''

    def class_get(self, *keys: str, default: T) -> T:
        """Get provider class attribute by keys, return default if not found."""
        for key in keys:
            try:
                return getattr(self.provider, key)
            except AttributeError:
                pass
        return default

    @property
    def premium_mixed(self) -> bool:
        """Return True if the provider returns premium sources among free ones (`ProviderOptions.PREMIUM` of both values)."""
        premium = self.class_get('PREMIUM', default=None)
        return premium is not None and not isinstance(premium, bool) and len(set(premium)) > 1

    def match(self, pat: ProviderSelector) -> bool:
        """Check if source match given provider pattern (only provder level: addon, provider, platform, kodi) for prefiltering."""
        if pat.addon is not None and not match_value(self.addon, pat.addon):
            return False
        if pat.provider and not match_value(self.name, pat.provider):
            return False
        if pat.platform is not None:
            from ..ff.kotools import get_platform
            if not match_value(get_platform(), pat.platform):
                return False
        if pat.kodi is not None:
            from ..kodi import KODI
            if isinstance(pat.kodi, int):
                if KODI >= pat.kodi:
                    return False
            elif isinstance(pat.kodi, (str, RegEx, Expr)):
                if pat.kodi != KODI:
                    return False
            elif KODI not in pat.kodi:
                return False
        return True

    def is_enabled_by_rules(self, rules: Mapping[SourceSelector, SourceRuleValue] | None = None) -> bool:
        """Check if provider is enabled by given rules. False means the provider is disabled at all (any source will not match)."""
        return enabled_by_rules(self.match, rules)


@frozen
class SourcePythonModule:
    """Python module from load source/*/*."""
    #: Module name.
    name: str
    #: Module python object.
    module: ModuleType
    #: Group of the sources (eg. language like "en", "pl").
    group: str = ''

    def load_providers(self, *, ffitem: FFItem) -> Iterable[ProviderModule]:
        """Load providers form python module."""
        with logtime(name=f'Create providers from {self.name}', fflog=log.DEBUG):
            try:
                if register := getattr(self.module, 'register', None):
                    sources: list[ProviderModule] = []
                    register(sources, group=self.group)
                    for srcmod in sources:
                        yield bind_provider(srcmod, ffitem=ffitem)
                else:
                    try:
                        provider_class = self.module.source
                    except AttributeError:
                        log.warning(f'Provider class not found in module - {self.name!r} - ignoring module')
                        return
                    if getattr(provider_class, 'INIT_WITH_FFITEM', False):
                        provider = provider_class(ffitem=ffitem)
                    else:
                        provider = provider_class()
                    yield bind_provider(ProviderModule(name=self.name, provider=provider, group=self.group), ffitem=ffitem)
            except Exception as e:
                log.warning(f'Provider creating Error - {self.name!r}: {e}')
                fflog_exc()


def scan_source_modules(*, ffitem: FFItem) -> list[SourcePythonModule]:
    """Scan source/*/*.py and load modules."""

    def iter_public_modules(search_paths: Sequence[str], prefix: str) -> Iterator[tuple[str, bool]]:
        """Yield (full_dotted_name, ispkg). Skip private and hidden modules and packages (starting with _ or .)."""
        for info in iter_modules(search_paths):
            # skip private and hidden modules and packages
            if info.name.startswith(('_', '.')):
                continue
            full = f'{prefix}{info.name}'
            yield full, info.ispkg
            if info.ispkg:
                # recurse into package
                sub_paths = [str(Path(p) / info.name) for p in search_paths]
                yield from iter_public_modules(sub_paths, f'{full}.')

    source_modules = []
    # try:
    #     # real absolute path
    #     path = Path(__file__).parent.resolve()
    # except PermissionError:
    #     # fallback for restricted systems (like XBox)
    #     path = Path(__file__).parent
    # do not resolve path to handle symbolic links to FF (useful in development and for portable versions) and restricted systems (like XBox)
    path = Path(__file__).parent
    if __package__ is None:
        raise RuntimeError('Cannot determine package name for sources modules')
    for full_name, is_pkg in iter_public_modules([str(path)], f'{__package__}.'):
        if is_pkg:
            continue
        check_thread_cancel()  # the scan in a stopped thread (e.g. sources init after the window is closed) ends here
        rel_name = full_name[len(__package__)+1:]
        if '.' not in rel_name:
            continue  # a module of lib/sources itself (natives, source_settings): no provider, providers are in their group folders
        with log_submodule(f'loading:{rel_name}'):
            with logtime(name=f'Load module {rel_name}', fflog=log.DEBUG):
                try:
                    module = import_module(full_name)
                    if module.__file__:
                        group = str(Path(module.__file__).parent.relative_to(path))
                    else:
                        group = ''
                    provider_name = rel_name.partition('.')[2]
                    source_modules.append(SourcePythonModule(name=provider_name, module=module, group=group))
                except Exception as e:
                    log.warning(f'Provider loading Error - {full_name!r}: {e}')
                    fflog_exc()
    return source_modules


def scan_providers(*, ffitem: FFItem) -> list[ProviderModule]:
    """Scan source/*/*.py and load modules."""
    source_modules = scan_source_modules(ffitem=ffitem)
    return [src for mod in source_modules for src in mod.load_providers(ffitem=ffitem)]


def clear_source_modules() -> None:
    """Clean source modules, destroy provider objects."""


def class_single_call(method: Callable[P, R], /) -> Callable[P, R]:
    """Decorator for single call method. Once per class not per instance!"""
    @wraps(method)
    def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
        nonlocal result
        if result is ...:
            result = method(*args, **kwargs)
        return result
    result = ...
    return wrapped


def single_call(method: Callable[P, R], /) -> Callable[P, R]:
    """Decorator for single call a method, ex. init(), per instance."""
    @wraps(method)
    def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
        if not args:
            return method(*args, **kwargs)
        self = args[0]
        key = f'_single_call_result_{method.__name__}'
        result = getattr(self, key, ...)
        if result is ...:
            result = method(*args, **kwargs)
            setattr(self, key, result)
        return result
    return wrapped
