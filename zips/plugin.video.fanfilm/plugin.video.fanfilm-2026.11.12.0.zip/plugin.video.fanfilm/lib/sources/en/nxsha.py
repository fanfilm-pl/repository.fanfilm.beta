# -*- coding: utf-8 -*-
"""
FanFilm - source: Nxsha (nxsha.space)

Dystrybuowane na licencji MIT <https://mit-license.org>

nxsha.space is a multi-scraper frontend with its own JSON API. Every request
and response is CryptoJS-style AES-256-CBC: a passphrase hardcoded in the
site's public JS bundle, OpenSSL EVP_BytesToKey (MD5) key/IV derivation and a
"Salted__" + salt + ciphertext payload, base64url-encoded:

    GET https://nxsha.space/api/servers?q=<enc {tmdbId, imdb_id, type, season, episode}>
    GET https://nxsha.space/api/sources?q=<enc {provider, ex_lang, tmdbId, ...}>
    -> {"_hash": "<enc {...}>"}

api/servers lists ~30 scrapers; only the ones with web_support are usable.
api/sources answers per scraper in well under a second, each source having a
stable id ("nitro-0"), url, type (m3u8/hls/mp4), headers and a free-text label
carrying quality and audio languages ("hguider | 1080P | Hindi | English").

Several links are signed with a short expiry, so sources() stores
(server, source id) and resolve() asks that one scraper again right before
playback, same pattern as filmu.py.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import ClassVar, TYPE_CHECKING, cast
from urllib.parse import urlencode, parse_qs

from pyaes.aes import AESModeOfOperationCBC  # lib/3rd/pyaes - pure-Python AES
from pyaes.blockfeeder import Decrypter, Encrypter

from lib.ff import requests
from lib.ff.source_utils import append_headers
from lib.ff.logs import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias

_BASE: str = 'https://nxsha.space'
_PASSPHRASE: bytes = b'f4488ab4da401203d23baa129fc546153898162524635d6776826d0c867ccaa3'
_HEADERS: dict[str, str] = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Origin': _BASE,
    'Referer': f'{_BASE}/',
}
_SCHEME: str = 'nxsha://'
_ITEM_SCHEME: str = 'nxsha_item://'
_TIMEOUT: int = 8
_TOTAL_TIMEOUT: int = 20
_PLAYABLE_TYPES: frozenset[str] = frozenset({'m3u8', 'hls', 'mp4', 'mkv', 'webm'})

# awsind: one placeholder stream (same hash) for every title; ophim: Vietnamese
# hardsubs only; em-8: embed only; showbox-online: needs a FebBox cookie
_EXCLUDED: frozenset[str] = frozenset({'awsind', 'ophim', 'em-8', 'showbox-online'})

_session: requests.Session = requests.Session()
_session.headers.update(_HEADERS)

_RE_HEIGHT: re.Pattern[str] = re.compile(r'\b(\d{3,4})p\b', re.IGNORECASE)
_RE_NAME_JUNK: re.Pattern[str] = re.compile(r'\s*-?\s*\[.*$')

# audio language names seen in labels -> display name; 'english' and 'polish'
# are handled separately
_LANG_NAMES: dict[str, str] = {
    'english': 'English', 'polish': 'Polish', 'polski': 'Polish',
    'hindi': 'Hindi', 'tamil': 'Tamil', 'telugu': 'Telugu', 'bengali': 'Bengali',
    'malayalam': 'Malayalam', 'kannada': 'Kannada', 'french': 'French', 'français': 'French',
    'german': 'German', 'deutsch': 'German', 'spanish': 'Spanish', 'español': 'Spanish',
    'italian': 'Italian', 'italiano': 'Italian', 'japanese': 'Japanese', '日本語': 'Japanese',
    'korean': 'Korean', '普通话': 'Chinese', 'chinese': 'Chinese', 'russian': 'Russian',
}


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'Nxsha'
    priority: ClassVar[int] = 1
    language: ClassVar[list[str]] = ['en']

    ffitem: FFItem

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: list[SourceTitleAlias], year: str) -> str | None:
        tmdb = str(self.ffitem.tmdb_id or '')
        return _SCHEME + urlencode({'type': 'movie', 'tmdb': tmdb}) if tmdb else None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: list[SourceTitleAlias], year: str) -> str | None:
        show_item = getattr(self.ffitem, 'show_item', None)
        tmdb = str((show_item.tmdb_id if show_item else None) or self.ffitem.tmdb_id or '')
        return _SCHEME + urlencode({'type': 'tv', 'tmdb': tmdb}) if tmdb else None

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> str | None:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: str | None, hostDict: list[str],
                hostprDict: list[str]) -> list[SourceItem]:
        result: list[SourceItem] = []
        params = _decode(url or '', _SCHEME)
        if not params.get('tmdb'):
            return result

        try:
            servers_doc = _call('api/servers', _query(params))
        except Exception:
            fflog_exc()
            return result
        servers: dict[str, str] = {
            server['scraper']: server.get('name') or server['scraper']
            for server in (servers_doc.get('servers') or [])
            if server.get('scraper') and server.get('web_support') is not False
            and server['scraper'] not in _EXCLUDED
        }
        fflog(f'servers: {len(servers)} usable')
        if not servers:
            return result

        executor = ThreadPoolExecutor(max_workers=len(servers))
        try:
            futures = {executor.submit(_fetch_server, scraper, params): scraper for scraper in servers}
            for future in as_completed(futures, timeout=_TOTAL_TIMEOUT):
                scraper = futures[future]
                for raw in future.result():
                    item = _to_source(raw, scraper, servers[scraper], params)
                    if item:
                        result.append(item)
        except TimeoutError:
            fflog('parallel fetch timeout')
        except Exception:
            fflog_exc()
        finally:
            executor.shutdown(wait=False)

        fflog(f'sources: {len(result)}')
        return result

    def resolve(self, url: str) -> str | None:
        params = _decode(url, _ITEM_SCHEME)
        scraper = params.get('server', '')
        source_id = params.get('id', '')
        if not scraper or not source_id:
            return None
        for raw in _fetch_server(scraper, params):
            if raw.get('id') == source_id:
                return _play_url(raw)
        fflog(f'resolve: {source_id!r} no longer returned by {scraper!r}')
        return None


# ── helpers ────────────────────────────────────────────────────────────────

def _evp_kdf(salt: bytes) -> tuple[bytes, bytes]:
    """OpenSSL EVP_BytesToKey with MD5 (what CryptoJS uses for a passphrase): 32-byte key + 16-byte IV."""
    derived = block = b''
    while len(derived) < 48:
        block = hashlib.md5(block + _PASSPHRASE + salt).digest()
        derived += block
    return derived[:32], derived[32:48]


def _encrypt(payload: dict) -> str:
    body = dict(payload, _req_ts=int(time.time() * 1000), _req_salt=secrets.token_hex(5))
    salt = os.urandom(8)
    key, iv = _evp_kdf(salt)
    encrypter = Encrypter(AESModeOfOperationCBC(key, iv))
    # pyaes is untyped (py2/py3 code), feed() returns bytes on py3
    ciphertext = cast(bytes, encrypter.feed(json.dumps(body, separators=(',', ':')).encode()) + encrypter.feed())
    return base64.urlsafe_b64encode(b'Salted__' + salt + ciphertext).decode().rstrip('=')


def _decrypt(token: str) -> dict:
    raw = base64.urlsafe_b64decode(token + '=' * (-len(token) % 4))
    if raw[:8] != b'Salted__':
        return {}
    key, iv = _evp_kdf(raw[8:16])
    decrypter = Decrypter(AESModeOfOperationCBC(key, iv))
    return json.loads(decrypter.feed(raw[16:]) + decrypter.feed())


def _call(endpoint: str, payload: dict) -> dict:
    resp = _session.get(f'{_BASE}/{endpoint}', params={'q': _encrypt(payload)}, timeout=_TIMEOUT)
    if resp.status_code != 200:
        fflog(f'{endpoint}: HTTP {resp.status_code}')
        return {}
    token = resp.json().get('_hash')
    return _decrypt(token) if token else {}


def _query(params: dict[str, str]) -> dict:
    is_tv = params.get('type') == 'tv'
    return {
        'tmdbId': int(params['tmdb']),
        'imdb_id': '',
        'type': 'tv' if is_tv else 'movie',
        'season': int(params['s']) if is_tv and params.get('s') else None,
        'episode': int(params['e']) if is_tv and params.get('e') else None,
    }


def _fetch_server(scraper: str, params: dict[str, str]) -> list[dict]:
    """Return the playable raw sources of one scraper ([] on any error)."""
    try:
        doc = _call('api/sources', {'ex_lang': False, 'provider': scraper, **_query(params)})
    except Exception:
        fflog(f'server {scraper!r} failed, continuing')
        return []
    if doc.get('error'):
        fflog(f'server {scraper!r}: {doc["error"]}')
    return [raw for raw in (doc.get('sources') or [])
            if not raw.get('isEmbed') and str(raw.get('url', '')).startswith('http')
            and str(raw.get('type', '')).lower() in _PLAYABLE_TYPES]


def _to_source(raw: dict, scraper: str, server_name: str, params: dict[str, str]) -> SourceItem | None:
    label = str(raw.get('label') or raw.get('quality') or '')
    quality = _quality(label)
    language, info = _language(label)
    item_url = _ITEM_SCHEME + urlencode({**params, 'server': scraper, 'id': raw.get('id', '')})
    return {
        'hosting': _RE_NAME_JUNK.sub('', server_name).strip() or scraper,
        'url': item_url,
        'quality': quality,
        'language': language,
        'info': info,
        'direct': True,
        'debridonly': False,
    }


def _play_url(raw: dict) -> str:
    url = raw['url']
    headers = raw.get('headers') or {}
    if headers:
        url += append_headers(headers)
    is_hls = str(raw.get('type', '')).lower() in ('m3u8', 'hls')
    return f'isa+{url}' if is_hls else url


def _quality(label: str) -> str:
    low = label.lower()
    if '2160' in low or '4k' in low:
        return '4K'
    match = _RE_HEIGHT.search(label)
    if not match:
        return 'HD'  # "Auto", "Bluray", bare server name - quality not given
    height = int(match.group(1))
    if height >= 1080:
        return '1080p'
    if height >= 720:
        return '720p'
    return 'SD'


def _language(label: str) -> tuple[str, str]:
    """Return (FanFilm language, info) from the audio languages named in the label."""
    low = label.lower()
    if 'multi' in low.split() or ' multi' in low:
        return 'multi', ''
    found = list(dict.fromkeys(name for key, name in _LANG_NAMES.items() if key in low))
    if 'Polish' in found:
        return 'pl', ''
    others = [name for name in found if name != 'English']
    if 'English' in found and others:
        return 'multi', ', '.join(others)
    return 'en', ', '.join(others)


def _decode(url: str, scheme: str) -> dict[str, str]:
    if not url.startswith(scheme):
        return {}
    parsed = parse_qs(url[len(scheme):], keep_blank_values=True)
    return {key: values[0] for key, values in parsed.items()}


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test Nxsha source provider')
    parser.add_argument('tmdb_id', help='TMDB ID')
    parser.add_argument('--type', default='movie', choices=['movie', 'tv'])
    parser.add_argument('--season', type=int, default=None)
    parser.add_argument('--episode', type=int, default=None)
    parser.add_argument('--resolve', action='store_true', help='resolve every source too')
    args = parser.parse_args()

    src = source()
    url = _SCHEME + urlencode({'type': args.type, 'tmdb': args.tmdb_id})
    if args.type == 'tv':
        url = f'{url}&s={args.season}&e={args.episode}'
    started = time.time()
    items = src.sources(url, [], [])
    print(f'{len(items)} sources in {time.time() - started:.1f}s')
    for item in items:
        print(f"  {item.get('hosting', ''):20} {item.get('quality', ''):6} {item.get('language', ''):5} {item.get('info', ''):20}",
              (src.resolve(item['url']) or '-')[:90] if args.resolve else '')
