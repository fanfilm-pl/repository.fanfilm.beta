"""
The native providers of FanFilm (`lib/sources/{pl,en,xx}`) for the choice of the user: what a provider class declares
about itself (its label, its settings, the Kodi add-ons it needs, its sub-sources, the sites of its cookies) and the
catalog of all of them - the catalog of "FanFilm (built-in)" in the shape of the catalogs of the provider add-ons.

The catalog is built from the provider classes (an import of every module, so once: by the update worker, by a search,
which has them imported already, or by the first reader) and stored with its stamp (the FanFilm version, the provider files, the Kodi
language of the labels) and the modules whose import failed (`stored_catalog()`); later it is read from the store. The service only
reads it (also a stale one).
"""

from __future__ import annotations
import sys
from hashlib import sha1
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, NotRequired, TypeAlias, TypedDict
from attrs import frozen, field
from ..kolang import L
from ..sdk.protocol.catalog import Catalog, CatalogAddon, CatalogProvider
if TYPE_CHECKING:
    from . import ProviderModule

#: The kind of a setting (its editor): a switch, a text, a password (never shown, typed openly unless `const.dialog.config.hide_passwords`),
#: a number (`minimum` .. `maximum`), one of the `options`, a color (AARRGGBB), a file path, an action (`action` runs),
#: a state (read only, written by the provider).
SettingKind: TypeAlias = Literal['bool', 'text', 'password', 'int', 'range', 'scale', 'select', 'color', 'path', 'action', 'state']


@frozen(kw_only=True)
class SettingOption:
    """An option of a `select` setting."""

    #: The stored value (None: nothing stored, the option of no value of its own).
    value: str | int | None
    #: Its label.
    label: str


@frozen(kw_only=True)
class ProviderSetting:
    """A setting of a provider (or of a node: a provider which is a group), stored in its configuration under `key`."""

    #: The key in the configuration of the provider (`username`, `color.identify2`).
    key: str
    #: The kind (its editor).
    kind: SettingKind
    #: The label.
    label: str
    #: The default value.
    default: Any = ''
    #: The help of the row.
    help: str = ''
    #: The options of a `select` setting.
    options: tuple[SettingOption, ...] = ()
    #: The range of an `int` setting.
    minimum: int | None = None
    maximum: int | None = None
    #: The scale of a `range` setting (`lib.windows.scale.Scale`, its value the pair of its knobs) or a `scale` one (one knob, its value a number).
    scale: Any = None
    #: The Kodi builtin of the row (`RunPlugin(...)`): OK runs it instead of the editor of the kind.
    action: str = ''
    #: The row is shown if every key has one of its values (`{'source_type': (1, 2)}`), empty: always.
    when: Mapping[str, Sequence[Any]] = field(factory=dict)
    #: A switch which blocks: off (red) the sources of it are hidden, on (gray) it does not matter.
    negative: bool = False
    #: The row is usable if one of these Kodi add-ons is enabled (else grayed), empty: always.
    requires: tuple[str, ...] = ()
    #: The setting ID of the old `settings.xml` (`{name}`: the provider name, `{key}`: the key), the migration reads it.
    legacy: str = '{name}.{key}'
    #: Its value tunes the log format whatever its key (e.g. a key of an API, an URL with a token); a password always (its kind).
    tune: bool = False


@frozen(kw_only=True)
class SubSource:
    """A sub-source of a provider (a service it delegates to): a leaf of the tree of the choice under the provider."""

    #: Its ID (the key of the choice: `<provider>/<id>`).
    id: str
    #: Its label.
    label: str
    #: The Kodi add-ons it needs (one of them enabled).
    requires: tuple[str, ...] = ()
    #: Searched without a choice of the user.
    default_enabled: bool = True
    #: The switch of the old `settings.xml` (`{name}`: the provider name, `{id}`: its ID), the migration reads it.
    legacy: str = '{name}.enable.{id}'


@frozen(kw_only=True)
class SiteCookies:
    """What the FanFilm web interface (the user script in a browser) takes from a site for the provider settings."""

    #: The host of the site.
    host: str
    #: The cookie name (`:user_agent` - the browser user agent, `:<name>` - a value of the page) -> the setting key.
    values: Mapping[str, str]


#: A login and a password of a service account.
LOGIN: tuple[ProviderSetting, ...] = (
    ProviderSetting(key='username', kind='text', label=L(32647, 'Login')),
    ProviderSetting(key='password', kind='password', label=L(32648, 'Password')),
)

#: The Cloudflare cookie of a site and the user agent of the browser which got it (`cf_cookies()`: their site).
CF_COOKIE: tuple[ProviderSetting, ...] = (
    ProviderSetting(key='cookies_cf', kind='text', label=L(30459, 'CF Cookie')),
    ProviderSetting(key='user_agent', kind='text', label=L(30353, 'User agent')),
)


def cf_cookies(host: str) -> SiteCookies:
    """Return the site of the Cloudflare cookie (`CF_COOKIE`)."""
    return SiteCookies(host=host, values={'cf_clearance': 'cookies_cf', ':user_agent': 'user_agent'})


#: The settings given by the flags of a provider class (`ProviderOptions.has_*`), before its own `SETTINGS` (the highlight color and the
#: priority are of every node of the tree of the source providers: `lib.sources.addons.external.NODES_CONFIG`).
FLAG_SETTINGS: Mapping[str, ProviderSetting] = {
    'has_library_color_identify2': ProviderSetting(key='library.color.identify2', kind='color', label=L(32650, 'Highlight color for account items')),
}
#: The old settings of a provider moved to its node of the tree (`node_from_old()`): the highlight color, the list order.
OLD_NODE_SETTINGS: tuple[str, str] = ('color.identify2', 'sort.order')
#: The old default highlight colors of the providers (`settings.xml` keeps the defaults too): not moved to their nodes.
OLD_DEFAULT_COLORS: Mapping[str, str] = {name: 'FF00FF00' for name in ('dramaqueen', 'giptv', 'm3u', 'stalkervod')}
#: The old defaults of the color settings of Kodi changed since (removed once: the migration of `config.json` to its version 6): Kodi keeps
#: the old default of an add-on setting (its value of the user file is loaded again after the `default="true"` reset), its next write
#: drops the mark.
OLD_SETTING_COLORS: Mapping[str, str] = {'default.color.identify2': 'FF57A4CB'}


def old_default_color(value: Any) -> bool:
    """Return True if a color value is the default color of an old FanFilm (`0`, `00000000`; now '', then `00000000` is a color)."""
    return isinstance(value, str) and bool(value) and not value.strip('0')


def node_from_old(color: Any, order: Any) -> dict[str, Any]:
    """
    Return the values of the node of a provider from its old settings (`OLD_NODE_SETTINGS`): the color if not the default
    one, the priority from the list order (1 first ... 10: the priority 10 ... 1, bigger first; 0: none).
    """
    node: dict[str, Any] = {}
    if isinstance(color, str) and color.strip('0'):
        node['color'] = color
    try:
        if 1 <= (order := int(order)) <= 10:
            node['priority'] = 11 - order
    except (TypeError, ValueError):
        pass
    return node

#: The ID of the add-on of the native providers in the choice (the add-on serving itself).
NATIVES_ID: str = 'plugin.video.fanfilm'


def provider_settings(cls: type) -> tuple[ProviderSetting, ...]:
    """Return the settings of a provider class: from its flags (`FLAG_SETTINGS`), then its `SETTINGS` (the same key replaces a flag one in place)."""
    own = {setting.key: setting for setting in getattr(cls, 'SETTINGS', ())}
    flags = [own.pop(setting.key, setting) for flag, setting in FLAG_SETTINGS.items() if getattr(cls, flag, False)]
    return (*flags, *own.values())


# --- the catalog ---

class CatalogSetting(TypedDict):
    """A setting in the catalog (the fields of `ProviderSetting`, an optional one only if set)."""

    #: The key in the configuration of the provider.
    key: str
    #: The kind (its editor).
    kind: SettingKind
    #: The label (the Kodi language of the catalog).
    label: str
    #: The default value.
    default: Any
    #: The help of the row.
    help: NotRequired[str]
    #: The options of a `select` setting: `{"value": ..., "label": ...}`.
    options: NotRequired[list[dict[str, Any]]]
    #: The range of an `int` setting.
    minimum: NotRequired[int]
    maximum: NotRequired[int]
    #: The scale of a `range` setting.
    scale: NotRequired[Any]
    #: The Kodi builtin of the row.
    action: NotRequired[str]
    #: The row is shown if every key has one of its values.
    when: NotRequired[dict[str, list[Any]]]
    #: A switch which blocks (`ProviderSetting.negative`).
    negative: NotRequired[bool]
    #: The row is usable if one of these Kodi add-ons is enabled.
    requires: NotRequired[list[str]]
    #: The setting ID of the old `settings.xml` (`{name}`, `{key}`).
    legacy: str
    #: Its value tunes the log format whatever its key (`ProviderSetting.tune`, a password).
    tune: NotRequired[bool]


class CatalogSubSource(TypedDict):
    """A sub-source in the catalog (`SubSource`)."""

    #: Its ID.
    id: str
    #: Its label.
    name: str
    #: The Kodi add-ons it needs (one of them enabled).
    requires: list[str]
    #: Searched without a choice of the user.
    default_enabled: bool
    #: The switch of the old `settings.xml` (`{name}`, `{id}`).
    legacy: str


class NativeProvider(CatalogProvider):
    """A native provider in the catalog: a provider of a catalog with what it declares."""

    #: Its settings.
    settings: NotRequired[list[CatalogSetting]]
    #: The Kodi add-ons it needs (one of them enabled).
    requires: NotRequired[list[str]]
    #: Its sub-sources.
    subsources: NotRequired[list[CatalogSubSource]]
    #: The sites of its cookies: the host -> {the cookie name -> the setting key}.
    cookies: NotRequired[dict[str, dict[str, str]]]


#: No entry given (`native_searched()`: read it).
MISSING_ENTRY: Any = object()
#: The provider folders of the catalog (the groups).
GROUPS: tuple[str, ...] = ('pl', 'en', 'xx')
#: The store of the native catalog (its own namespace: the store of the catalogs of the provider add-ons drops the ones not installed).
CATALOG_STORE: str = 'ff/natives'
#: The key of the native catalog in its store.
STORE_KEY: str = 'catalog'


class CatalogEntry(TypedDict):
    """The stored native catalog."""

    #: Its stamp (`catalog_stamp()`).
    stamp: str
    #: The catalog.
    catalog: Catalog
    #: The provider modules not imported by its build (`failed_modules()`): the catalog lacks their providers; none: complete.
    failed: NotRequired[list[str]]


def catalog_setting(setting: ProviderSetting) -> CatalogSetting:
    """Return the catalog entry of a setting (only what is set)."""
    entry: CatalogSetting = {'key': setting.key, 'kind': setting.kind, 'label': setting.label, 'default': setting.default, 'legacy': setting.legacy}
    if setting.help:
        entry['help'] = setting.help
    if setting.options:
        entry['options'] = [{'value': opt.value, 'label': opt.label} for opt in setting.options]
    if setting.minimum is not None:
        entry['minimum'] = setting.minimum
    if setting.maximum is not None:
        entry['maximum'] = setting.maximum
    if setting.scale is not None:
        entry['scale'] = setting.scale
    if setting.action:
        entry['action'] = setting.action
    if setting.negative:
        entry['negative'] = True
    if setting.when:
        entry['when'] = {key: list(values) for key, values in setting.when.items()}
    if setting.requires:
        entry['requires'] = list(setting.requires)
    if setting.tune or setting.kind == 'password':
        entry['tune'] = True
    return entry


def catalog_provider(name: str, group: str, cls: type) -> NativeProvider:
    """Return the catalog entry of a native provider class."""
    entry: NativeProvider = {'id': name, 'group': group, 'name': getattr(cls, 'LABEL', '') or name}  # a flat ID: the names are unique
    if settings := provider_settings(cls):
        entry['settings'] = [catalog_setting(setting) for setting in settings]
    if requires := getattr(cls, 'REQUIRES', ()):
        entry['requires'] = list(requires)
    if subsources := getattr(cls, 'SUBSOURCES', ()):
        entry['subsources'] = [{'id': sub.id, 'name': sub.label, 'requires': list(sub.requires), 'default_enabled': sub.default_enabled,
                                'legacy': sub.legacy} for sub in subsources]
    if cookies := getattr(cls, 'COOKIES', ()):
        entry['cookies'] = {site.host: dict(site.values) for site in cookies}
    return entry


def native_classes(mods: Iterable[ProviderModule]) -> list[tuple[str, str, type]]:
    """Return the native providers (name, group, class) of the provider modules (not the add-on ones, not the scan of the add-ons)."""
    from . import unwrap_provider, is_scan_addon_protocol
    found: list[tuple[str, str, type]] = []
    for mod in mods:
        provider = unwrap_provider(mod.provider)
        if not mod.addon and mod.group in GROUPS and not is_scan_addon_protocol(provider):
            found.append((mod.name, mod.group, type(provider)))
    return found


def scan_classes() -> list[tuple[str, str, type]]:
    """Import the provider modules, return the native providers (name, group, class); no instance with a media item."""
    from . import scan_source_modules, ProviderModule
    found: list[ProviderModule] = []
    for mod in scan_source_modules(ffitem=None):  # type: ignore[arg-type]  # the scan only imports
        if (register := getattr(mod.module, 'register', None)) is not None:
            try:
                register(found, group=mod.group)
            except Exception:
                from ..ff.logs import fflog_exc
                fflog_exc()
        elif (cls := getattr(mod.module, 'source', None)) is not None:
            found.append(ProviderModule(name=mod.name, provider=cls, group=mod.group))  # type: ignore[arg-type]  # the class only
    return [(srcmod.name, srcmod.group, srcmod.provider if isinstance(srcmod.provider, type) else type(srcmod.provider))
            for srcmod in found if srcmod.group in GROUPS]


def build_catalog(classes: Iterable[tuple[str, str, type]]) -> Catalog:
    """Return the catalog of the native providers (one add-on: FanFilm itself, its providers sorted by group and name)."""
    from ..sdk.protocol import PROTOCOL_VERSION
    from ..ff.control import addonInfo
    providers = [catalog_provider(name, group, cls) for name, group, cls in sorted(classes, key=lambda found: (found[1], found[0]))]
    addon: CatalogAddon = {'id': NATIVES_ID, 'name': 'FanFilm', 'version': addonInfo('version'), 'handler': '', 'match': 'id',
                           'providers': providers}  # type: ignore[typeddict-item]  # native providers
    return {'protocol': PROTOCOL_VERSION, 'sdk': '', 'handlers': [], 'addons': [addon]}


def catalog_stamp() -> str:
    """Return the stamp of the native catalog: the FanFilm version, the provider files (names, sizes, times) and the Kodi language."""
    from ..ff.control import addonInfo
    from ..kolang import kodi_locale
    root = Path(__file__).parent
    digest = sha1()
    for group in GROUPS:
        for path in sorted((root / group).glob('*.py')):
            try:
                st = path.stat()
            except OSError:
                continue
            digest.update(f'{group}/{path.name}:{st.st_size}:{st.st_mtime_ns};'.encode())
    return f'{addonInfo("version")}:{kodi_locale()}:{digest.hexdigest()}'


def module_name(module: str) -> str:
    """Return the Python name of a provider module (`<group>/<name>`)."""
    return f'{__package__}.{module.replace("/", ".")}'


def failed_modules() -> list[str]:
    """
    Return the provider modules (`<group>/<name>`: the files of the stamp, not the private ones) not imported in this process: after
    an import of every module (`scan_source_modules()`) the ones whose import failed (a failed import leaves no module in `sys.modules`).
    """
    root = Path(__file__).parent
    return [module for group in GROUPS for path in sorted((root / group).glob('*.py')) if not path.name.startswith(('_', '.'))
            if module_name(module := f'{group}/{path.stem}') not in sys.modules]


def stored_catalog(*, mods: Iterable[ProviderModule] | None = None, build: bool = True) -> CatalogEntry | None:
    """
    Return the stored native catalog: the one of the current stamp, else built - from `mods` (a search, the modules imported
    already) or by an import of every module (`build`) - and stored with the modules not imported (`failed_modules()`); one with
    such modules is built again only from `mods` with one of them imported now (a passing error: the next search; a lasting one
    costs nothing). `build=False` (the service): the stored one even if stale, None if none.
    """
    from ..ff.db.sources import provider_store
    store = provider_store(CATALOG_STORE)
    stored = store.get(STORE_KEY)
    entry: CatalogEntry | None = stored if isinstance(stored, dict) and stored.get('catalog') is not None else None  # type: ignore[assignment]  # stored
    if not build:
        return entry
    current = catalog_stamp()
    if entry is not None and entry.get('stamp') == current:
        if mods is None or not any(module_name(module) in sys.modules for module in entry.get('failed', ())):
            return entry
    entry = {'stamp': current, 'catalog': build_catalog(native_classes(mods) if mods is not None else scan_classes())}
    if failed := failed_modules():
        from ..ff.logs import fflog
        entry['failed'] = failed
        fflog(f'[SOURCES] native catalog without the modules not imported: {", ".join(failed)}')
    store.set(STORE_KEY, entry, ttl=None)  # valid until the stamp changes
    global _settings
    _settings = None
    return entry


def native_catalog(*, mods: Iterable[ProviderModule] | None = None, build: bool = True) -> Catalog | None:
    """Return the catalog of the native providers (`stored_catalog()`), None if none."""
    return entry['catalog'] if (entry := stored_catalog(mods=mods, build=build)) is not None else None


def catalog_providers(catalog: Catalog | None) -> list[NativeProvider]:
    """Return the native providers of the catalog (none: none)."""
    return [prov for addon in (catalog or {}).get('addons', ()) for prov in addon.get('providers', ())]  # type: ignore[misc]  # native ones


# --- the values of the settings and the choice (the user configuration) ---

#: The values of the settings of the native providers in the user configuration: `{<provider>: {<key>: value}}`, only
#: the changed ones (a missing one: the default of its declaration).
PROVIDERS_CONFIG: str = '/sources/providers'
#: The old settings (`settings.xml`) of the native providers are moved to the configuration (`migrate_settings()`).
MIGRATED_CONFIG: str = '/sources/providers_migrated'
#: The switch of a provider in the old `settings.xml` (`{name}`: its name).
LEGACY_SWITCH: str = 'provider.{name}'

#: The declared settings (provider -> key -> its catalog entry), from the stored catalog; None: not read yet.
_settings: dict[str, dict[str, CatalogSetting]] | None = None
#: The migration of the old settings was tried in this process (also the guard of its recursion: the catalog creates providers).
_migrated: bool = False


def value_pointer(name: str, key: str) -> str:
    """Return the configuration pointer of a setting of a provider."""
    from ..ff.config import escape_key
    return f'{PROVIDERS_CONFIG}/{escape_key(name)}/{escape_key(key)}'


def declared_setting(name: str, key: str) -> CatalogSetting | None:
    """Return the declaration of a setting of a provider (the stored catalog, no build), None if unknown (no catalog yet: read again later)."""
    global _settings
    if _settings is None:
        if (catalog := native_catalog(build=False)) is None:
            return None  # the service after an update from an old version: the update worker stores the catalog
        _settings = {prov['id']: {setting['key']: setting for setting in prov.get('settings', ())} for prov in catalog_providers(catalog)}
    return _settings.get(name, {}).get(key)


def provider_default(name: str, key: str) -> Any:
    """Return the default of a declared setting of a provider (`declared_setting()`), '' if unknown."""
    return setting['default'] if (setting := declared_setting(name, key)) is not None else ''


def tuned_setting(name: str, key: str) -> bool:
    """Return True if the value of a setting of a provider is access data: declared so (`ProviderSetting.tune`, a password) or by its key."""
    from ..ff.logs import log
    setting = declared_setting(name, key)
    return bool(setting is not None and setting.get('tune')) or log.format.tunes(key)


def tune_log(name: str, key: str, value: Any) -> None:
    """Tune the log format by a value of a setting of a provider: by its key, any key if declared so (`ProviderSetting.tune`)."""
    from ..ff.logs import log
    setting = declared_setting(name, key)
    log.format.tune(key, value, any_key=bool(setting is not None and setting.get('tune')))  # e.g. a password or a token: `***` in the logs


def provider_value(name: str, key: str) -> Any:
    """Return a setting of a native provider: its value in the configuration, else its declared default (it tunes the log format)."""
    from ..ff.config import config
    from ..ff.tricks import MISSING
    migrate_settings()
    value = config.get(value_pointer(name, key), MISSING)
    value = provider_default(name, key) if value is MISSING else value
    tune_log(name, key, value)
    return value


def set_provider_value(name: str, key: str, value: Any) -> None:
    """Set a setting of a native provider (its declared default: removed, only the changes are stored; it tunes the log format)."""
    from ..ff.config import config
    migrate_settings()
    tune_log(name, key, value)
    config.set(value_pointer(name, key), value, default=provider_default(name, key))


def native_entry() -> Any:
    """Return the choice of the native providers (their entry of `ADDONS_CONFIG`, see `addons_choice()`), None if none."""
    from ..ff.config import config
    from .addons.external import ADDONS_CONFIG
    migrate_settings()
    return (config.get(ADDONS_CONFIG) or {}).get(NATIVES_ID)


def native_searched(key: str, default: bool, *, entry: Any = MISSING_ENTRY) -> bool:
    """Return True if the native key of the choice (a provider name, `<provider>/<sub-source>`) is searched (no choice: `default`)."""
    from .addons.external import searched_scrapers
    if entry is MISSING_ENTRY:
        entry = native_entry()
    if not isinstance(entry, dict):  # no choice (a new installation, the defaults restored): the default
        return default
    if not entry.get('active', True):
        return False
    return bool(searched_scrapers([key], entry, lambda: (key,) if default else ()))


def provider_searched(name: str, subsources: Iterable[SubSource] = ()) -> bool:
    """Return True if a native provider is searched: chosen (default: not in `const.sources.providers.default_off`); one with sub-sources: one of them."""
    from const import const
    entry = native_entry()
    if subs := list(subsources):
        return any(native_searched(f'{name}/{sub.id}', sub.default_enabled, entry=entry) for sub in subs)
    return native_searched(name, name not in const.sources.providers.default_off, entry=entry)


def module_searched(srcmod: ProviderModule) -> bool:
    """Return True if the provider module is searched by the choice of the user (a native provider; others have their own choice)."""
    from . import unwrap_provider
    if srcmod.addon or srcmod.group not in GROUPS:
        return True
    return provider_searched(srcmod.name, getattr(type(unwrap_provider(srcmod.provider)), 'SUBSOURCES', ()))


# --- the migration of the old settings ---

def old_value(setting: CatalogSetting, raw: str) -> Any:
    """
    Return the value of an old setting (a text of `settings.xml`) by its kind, MISSING if none (an action, empty, the old default color
    `0` / `00000000`: now '', wrong).
    """
    from ..ff.tricks import MISSING
    kind = setting['kind']
    if kind == 'action' or raw == '' or (kind == 'color' and old_default_color(raw)):
        return MISSING
    if kind == 'bool':
        return raw.strip().lower() == 'true'
    if kind == 'range':  # an old single number: the maximum
        try:
            return [setting['default'][0], int(raw)]
        except ValueError:
            return MISSING
    if kind == 'int' or (kind == 'select' and isinstance(setting['default'], int)):
        try:
            return int(raw)
        except ValueError:
            return MISSING
    return raw


def migrate_settings() -> None:
    """
    Move the old settings of the native providers (`settings.xml`, no definitions: read as texts) to the configuration
    once: the values (only the changed ones, a value written already is kept: e.g. by the web interface) and the switches
    to the choice (if there is none), then the old ones are removed (`settings.xml` backed up). The worker script moves
    them after a FanFilm update (it builds the catalog: an import of the providers, out of the service), the first reader
    otherwise; a lock keeps one process at it (a reader waits for the worker); the service moves them only with a stored
    catalog (no import of the providers), it reads the defaults until then. A catalog without some providers (`stored_catalog()`:
    their modules not imported) moves nothing (they would keep their old values for ever): a next process tries with a complete one.
    """
    global _migrated
    if _migrated:
        return
    _migrated = True
    from ..ff.config import config
    if config.get(MIGRATED_CONFIG):
        return
    from .. import service
    if (entry := stored_catalog(build=not service.SERVICE)) is None:
        _migrated = False  # later, with a catalog
        return
    if failed := entry.get('failed'):
        from ..ff.logs import fflog
        fflog(f'[SOURCES] no migration of the native provider settings: the catalog without the modules not imported ({", ".join(failed)})')
        return
    from ..ff.account_migration import MigrationLock
    path = config.path()
    with MigrationLock(path.with_name(f'{path.name}.providers.lock')) as owner:
        if owner and not config.get(MIGRATED_CONFIG):
            _migrate(catalog_providers(entry['catalog']))


def migrate_default_colors() -> None:
    """
    Write the default color of an old FanFilm (`0`, `00000000`) as the one of now (''): the color settings of Kodi (`*.color.identify2`
    removed from the user settings by one write of the file: the default of their definition), the colors of the native providers and
    of the nodes of the tree of the source providers (removed: their default ''). None of these places keeps a transparency (its colors
    are opaque), so an old default is never a color there: the worker script runs it after every FanFilm update (after `migrate_settings()`).
    """
    from ..ff.config import config, escape_key
    from ..ff.settings import settings
    from .addons.external import NODES_CONFIG
    pointers = [f'{pointer}/{escape_key(name)}/{escape_key(key)}' for pointer in (PROVIDERS_CONFIG, NODES_CONFIG)
                for name, values in (config.get(pointer) or {}).items() if isinstance(values, dict)
                for key, value in values.items() if 'color' in key and old_default_color(value)]
    if pointers:
        config.remove(*pointers)
    if old := [sid for sid, value in settings.user_values().items()
               if sid.endswith('.color.identify2') and old_default_color(value)]:
        settings.clear_moved_settings(old)


def _migrate(providers: Sequence[NativeProvider]) -> None:
    """Migrate the old settings of the `providers` (see `migrate_settings()`)."""
    from ..ff.config import config
    from ..ff.logs import fflog, fflog_exc
    from ..ff.settings import settings
    from ..ff.tricks import MISSING
    from .addons.external import ADDONS_CONFIG
    from const import const
    fflog('[SOURCES] migration of the native provider settings out of the settings')
    try:
        settings.make_backup()
    except Exception:
        fflog_exc()
    from .addons.external import NODES_CONFIG
    old_settings = settings.user_values()  # one read of the file for every old setting
    values: dict[str, dict[str, Any]] = config.get(PROVIDERS_CONFIG) or {}
    nodes: dict[str, dict[str, Any]] = config.get(NODES_CONFIG) or {}
    moved: list[str] = []
    keys: list[str] = []
    disabled: list[str] = []
    for prov in providers:
        name = prov['id']
        for setting in prov.get('settings', ()):
            sid = setting['legacy'].format(name=name, key=setting['key'])
            moved.append(sid)
            value = old_value(setting, old_settings.get(sid, ''))
            if value is not MISSING and value != setting['default'] and setting['key'] not in values.get(name, {}):
                values.setdefault(name, {})[setting['key']] = value
        old: list[str] = []
        for key in OLD_NODE_SETTINGS:
            moved.append(sid := f'{name}.{key}')
            old.append(old_settings.get(sid, ''))
        if old[0] == OLD_DEFAULT_COLORS.get(name):
            old[0] = ''
        if name not in nodes and (node := node_from_old(*old)):
            nodes[name] = node
        switch = LEGACY_SWITCH.format(name=name)
        moved.append(switch)
        on = old_value({'kind': 'bool', 'default': False}, old_settings.get(switch, ''))  # type: ignore[typeddict-item]  # a switch
        if subs := prov.get('subsources'):
            for sub in subs:
                sid = sub['legacy'].format(name=name, id=sub['id'])
                moved.append(sid)
                sub_on = old_value({'kind': 'bool', 'default': False}, old_settings.get(sid, ''))  # type: ignore[typeddict-item]  # a switch
                keys.append(key := f'{name}/{sub["id"]}')
                if on is False or (sub_on is not MISSING and not sub_on) or (sub_on is MISSING and not sub['default_enabled']):
                    disabled.append(key)
        else:
            keys.append(name)
            if on is False or (on is MISSING and name in const.sources.providers.default_off):
                disabled.append(name)
    with config.batch():  # one write: all of it or nothing
        if values:
            config.set(PROVIDERS_CONFIG, values)
        if nodes:
            config.set(NODES_CONFIG, nodes)
        chosen = config.get(ADDONS_CONFIG) or {}
        if NATIVES_ID not in chosen:
            config.set(ADDONS_CONFIG, {**chosen, NATIVES_ID: {'active': True, 'disabled': disabled, 'known': keys}})
        config.set(MIGRATED_CONFIG, True)
    settings.clear_moved_settings(moved)
    global _settings
    _settings = None
