# -*- coding: utf-8 -*-
"""
FanFilm ‑ źródło: ninateka.pl
Copyright (C) 2026 :)

Dystrybuowane na licencji GPL‑3.0.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING, ClassVar
from lib.ff import requests
from lib.ff import cleantitle
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA, get_quality_from_filename
from lib.ff.logs import fflog
from lib.ff.resolve_utils import build_drmff

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'Ninateka'
    ffitem: FFItem  # assigned dynamically by FanFilm

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self):
        self.base_url = 'https://ninateka.pl'
        self.api_url = self.base_url + '/api/'
        self.platform = 'BROWSER'
        self.session = requests.Session()

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> list[SourceItem]:
        # fflog(f"searching for {localtitle} ({year})")
        # Skip if Poland is not in the country list
        if 'PL' not in self.ffitem.vtag.getCountryCodes():
            fflog('not a Polish film, skip')
            return []
        search_url = self.api_url + 'products/vods/search/VOD'
        params = self._make_params()
        params['keyword'] = cleantitle.geturl(localtitle)

        try:
            fflog(f'query: {params["keyword"]!r}')
            response = self.session.get(search_url, headers=self._make_headers(), params=params)
            if response.status_code != 200:
                return []

            results = response.json().get('items', [])
            fflog(f'search: {len(results)} results')

            norm_localtitle = cleantitle.normalize(localtitle).lower()
            search_year = int(year)

            sources = []
            for item in results:
                if item.get('type') != 'VOD':
                    continue

                normalized_item_title = cleantitle.normalize(item['title']).lower()
                if norm_localtitle not in normalized_item_title:
                    continue

                eid = item['id']

                # search results no longer carry 'year' / 'tenant' -> fetch year from product detail
                detail_response = self.session.get(
                    self.api_url + f'products/{eid}', headers=self._make_headers(), params=self._make_params()
                )
                item_year = 0
                if detail_response.status_code == 200:
                    item_year = int(detail_response.json().get('year', 0) or 0)
                if item_year and abs(item_year - search_year) > 1:
                    continue

                # fflog(f"match: {item['title']} ({item_year})")
                is_audiodescription = 'audiodeskrypcja' in item['title'].lower()

                play_url = self.api_url + f'products/{eid}/videos/playlist'
                playlist_params = {
                    'videoType': 'MOVIE',
                    'platform': self.platform,
                }
                playlist_response = self.session.get(play_url, headers=self._make_headers(), params=playlist_params)
                if playlist_response.status_code != 200:
                    continue

                playlist_data = playlist_response.json()
                dash_streams = (playlist_data.get('sources') or {}).get('DASH') or []
                for stream in dash_streams:
                    stream_url = stream['src']
                    if stream_url.startswith('//'):
                        stream_url = 'https:' + stream_url

                    quality = get_quality_from_filename(stream_url) or 'SD'

                    info = 'Lektor'
                    if is_audiodescription:
                        info += ' - Audiodeskrypcja'

                    source_info: SourceItem = {
                        'hosting': 'Ninateka',
                        'quality': quality,
                        'language': 'pl',
                        'url': f"DRMFF|{eid}",
                        'info': info,
                        'direct': False,  # needs resolving
                        'debridonly': False
                    }
                    sources.append(source_info)
            fflog(f'sources: {len(sources)}')
            return sources
        except Exception as e:
            fflog(f'exception during search: {e}')
            return []

    def sources(self, url: Optional[list[SourceItem]], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        return url or []

    def resolve(self, url: str) -> Optional[str]:
        # fflog(f"resolving url: {url}")
        if url.startswith('DRMFF|'):
            try:
                eid = url.split('|')[1]

                play_url = self.api_url + f'products/{eid}/videos/playlist'
                params = {
                    'videoType': 'MOVIE',
                    'platform': self.platform,
                }

                response = self.session.get(play_url, headers=self._make_headers(), params=params)
                if response.status_code != 200:
                    fflog(f"resolve: request failed, status {response.status_code}")
                    return None

                data = response.json()

                if 'sources' in data and 'DASH' in data['sources'] and data['sources']['DASH']:
                    stream_url = data['sources']['DASH'][0]['src']
                    if stream_url.startswith('//'):
                        stream_url = 'https:' + stream_url

                    widevine = (data.get('drm') or {}).get('WIDEVINE')
                    return build_drmff(
                        stream_url,
                        widevine_url=widevine['src'] if widevine else None,
                        lic_referer=self.base_url,
                    )
                else:
                    # fflog("no DASH source found in response")
                    return None
            except Exception as e:
                # fflog(f"exception during resolve: {e}")
                return None
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _make_headers(self):
        h = {
            'User-Agent': DEFAULT_UA,
            'Referer': self.base_url,
            'Accept': 'application/json, text/plain, */*'
        }
        return h

    def _make_params(self):
        p = {
            'lang': 'POL',
            'platform': self.platform
        }
        return p
