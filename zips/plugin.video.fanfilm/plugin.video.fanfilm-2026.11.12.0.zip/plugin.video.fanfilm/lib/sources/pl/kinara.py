# -*- coding: utf-8 -*-
"""
FanFilm - source: Kinara (kinara.cc)

Dystrybuowane na licencji MIT <https://mit-license.org>

One JSON call by the TMDB id gives every video of a movie or an episode:

    /api/route?tmdbId=<id>&kind=movie|tv&season=<n|-1>&episode=<n|-1>&audio=…&subs=…&device=desktop
        {"videos": [{"platform", "embed_url", "audio_type", "subtitle_languages", "quality", "label"}, ...]}

The audio / subs preferences only pick the "selected" video, the list is the same.
Platforms: "vidneo" (a plain HLS master, no token), "ppltv-licensed" (an AES-128 HLS relayed by
kinara: /api/ppltv-vod-stream, Polish audio), "vidara-direct" (HLS with an expired token bound to
the IP of the kinara server - dead), "obejrzyj" (YouTube trailers) and embed hostings (voe...).
The list is live: kinara drops a video whose upstream died (a ppltv relay answers 404 / 502 then).
"subtitle_languages" is not playable: no subtitles in the stream, not burned, no vidneo page.

Kinara gives no stream details (the audio channels differ file by file), so a vidneo master is
probed: its variant gives the frame size, fps, video codec and bitrate, the first 32 KB of the
first segment the AAC channels. The ppltv relay is not probed: each request makes kinara fetch
the upstream playlist (slow, a load on their server); resolve() checks it is alive.
"""

from __future__ import annotations

import re
from typing import ClassVar, TYPE_CHECKING
from urllib.parse import urljoin, urlparse

from cdefs import MINUTE
from lib.ff import requests
from lib.ff.logs import fflog
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.threads import Thread
from lib.sdk.facts.vocab import AudioCodec, TrackKind, VideoCodec
from lib.sdk.protocol.item import quality_of_resolution
from lib.sources import Provider

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sdk.facts.types import AudioTrack, VideoFacts
    from lib.sources import SourceItem, SourceSearchOverride

_BASE: str = 'https://kinara.cc'
_TIMEOUT: int = 15
_RELAY_PATH: str = '/api/ppltv-vod-stream'

# obejrzyj: YouTube trailers; vidara-direct: the token is expired and bound to the IP of the kinara server
_SKIPPED_PLATFORMS: tuple[str, ...] = ('obejrzyj', 'vidara-direct')
_SKIPPED_HOSTS: tuple[str, ...] = ('youtube.', 'youtu.be')

_HOSTINGS: dict[str, str] = {'ppltv-licensed': 'ppltv'}

# (language, info, track kind) of the audio type of kinara
_AUDIO_TYPES: dict[str, tuple[str, str, TrackKind]] = {
    'lector': ('pl', 'Lektor', TrackKind.LEKTOR),
    'dubbing': ('pl', 'Dubbing', TrackKind.DUBBING),
    'ai-lector': ('pl', 'Lektor AI', TrackKind.LEKTOR),
}

#: Probes at once (one search, all sources): spare the server.
_PROBE_WORKERS: int = 2
#: The start of the first segment probed (16 KB was enough in tests).
_PROBE_BYTES: int = 32 * 1024
_PROBE_TIMEOUT: int = 8

_VIDEO_CODECS: dict[str, VideoCodec] = {'avc1': VideoCodec.H264, 'hvc1': VideoCodec.HEVC, 'hev1': VideoCodec.HEVC}
_AAC_CHANNELS: dict[int, str] = {1: '1.0', 2: '2.0', 3: '3.0', 4: '4.0', 5: '5.0', 6: '5.1', 7: '7.1'}
_RX_ATTR = re.compile(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)')


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    LABEL: ClassVar[str] = 'Kinara'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('pl',)
    PREMIUM = False
    #: The list is live (dead upstreams dropped), keep it short.
    SOURCES_TTL = 10 * MINUTE

    def __init__(self, *, ffitem: FFItem) -> None:
        super().__init__(ffitem=ffitem)
        self.session: requests.Session = requests.ProviderSession()
        self.session.headers.update({'User-Agent': DEFAULT_UA, 'Referer': f'{_BASE}/'})

    # ── public api ─────────────────────────────────────────────────────────

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        season, episode = override['season'], override['episode']
        is_episode = bool(season and episode)
        item = ffitem.show_item if is_episode else ffitem
        tmdb_id = item.tmdb_id if item is not None else None
        if not tmdb_id:
            fflog(f'no tmdb id: {ffitem}')
            return []

        resp = self.session.get(f'{_BASE}/api/route', timeout=_TIMEOUT, headers={'Accept': 'application/json'}, params={
            'tmdbId': tmdb_id,
            'kind': 'tv' if is_episode else 'movie',
            'audio': 'polish-lector',
            'subs': 'auto-polish',
            'device': 'desktop',
            'season': season if is_episode else -1,
            'episode': episode if is_episode else -1,
            'title': '',
            'year': '',
        })
        resp.raise_for_status()
        videos: list[dict] = resp.json().get('videos') or []

        result: list[SourceItem] = []
        seen: set[str] = set()
        for video in videos:
            platform = str(video.get('platform') or '').lower()
            link = urljoin(f'{_BASE}/', str(video.get('embed_url') or video.get('remote_url') or ''))
            host = urlparse(link).netloc
            if (platform in _SKIPPED_PLATFORMS or not host or any(skipped in host for skipped in _SKIPPED_HOSTS)
                    or link in seen):
                continue
            seen.add(link)
            language, info, track = _language(video)
            result.append({
                'hosting': _HOSTINGS.get(platform) or platform or host.split('.')[-2],
                'url': link,
                'quality': _quality(video),
                'language': language,
                'info': info,
                'audio': [track],
                'direct': _is_stream(link),
                'debridonly': False,
            })

        self._probe_all([item for item in result if item.get('hosting') == 'vidneo'])
        fflog(f'sources: {len(result)} (videos {len(videos)}) for tmdb={tmdb_id} {season=} {episode=}')
        return result

    def resolve(self, url: str, **kwargs) -> str | None:
        if urlparse(url).path != _RELAY_PATH:
            return url
        # the relay answers 404 / 502 (or nothing) when its upstream is down
        try:
            resp = self.session.get(url, timeout=_TIMEOUT)
        except requests.RequestException as exc:
            fflog(f'relay dead: {exc!r} {url}')
            return None
        if resp.status_code != 200 or not resp.text.startswith('#EXTM3U'):
            fflog(f'relay dead: HTTP {resp.status_code} {url}')
            return None
        return f'{url}|User-Agent={DEFAULT_UA}'

    # ── helpers ────────────────────────────────────────────────────────────

    def _probe_all(self, items: list[SourceItem]) -> None:
        """Complete the items with the stream facts, at most `_PROBE_WORKERS` at once."""
        pending = list(items)

        def worker() -> None:
            while pending:
                item = pending.pop()
                try:
                    _probe(self.session, item)
                except (requests.RequestException, ValueError) as exc:
                    fflog(f'probe failed: {exc!r} {item["url"]}')

        threads = [Thread(target=worker, name='kinara probe') for _ in range(min(_PROBE_WORKERS, len(pending)))]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()


def _language(video: dict) -> tuple[str, str, AudioTrack]:
    """Return (language, info, audio track) of a video: the Polish audio type, else the original."""
    audio_type = str(video.get('audio_type') or '').lower()
    if audio_type in _AUDIO_TYPES:
        language, info, kind = _AUDIO_TYPES[audio_type]
        return language, info, {'lang': language, 'kind': kind}
    if audio_type == 'original':
        return 'en', '', {'kind': TrackKind.ORIGINAL}
    return 'pl', '', {'lang': 'pl'}  # not marked (ppltv): Polish audio (checked by speech recognition)


def _quality(video: dict) -> str:
    """Return the quality of a video: given by kinara, else "HD" of the label, else SD."""
    if quality := str(video.get('quality') or ''):
        return quality
    return 'HD' if str(video.get('label') or '').upper().startswith('HD ') else 'SD'


def _is_stream(link: str) -> bool:
    path = urlparse(link).path.lower()
    return path == _RELAY_PATH or path.endswith(('.m3u8', '.mp4'))


def _probe(session: requests.Session, item: SourceItem) -> None:
    """Complete the item with the facts of its HLS master: the best variant and the AAC channels."""
    url = item['url']
    resp = session.get(url, timeout=_PROBE_TIMEOUT)
    resp.raise_for_status()
    variants: list[tuple[int, int, int, dict[str, str], str]] = []
    lines = resp.text.splitlines()
    for line, uri in zip(lines, lines[1:]):
        if line.startswith('#EXT-X-STREAM-INF:'):
            attrs = {key: value.strip('"') for key, value in _RX_ATTR.findall(line.partition(':')[2])}
            width, _, height = attrs.get('RESOLUTION', '0x0').partition('x')
            variants.append((int(width or 0), int(height or 0), int(attrs.get('BANDWIDTH') or 0), attrs, uri.strip()))
    if not variants:
        return
    width, height, bandwidth, attrs, uri = max(variants, key=lambda variant: variant[:3])

    video: VideoFacts = {}
    if codec := _VIDEO_CODECS.get(attrs.get('CODECS', '').partition('.')[0]):
        video['codec'] = codec
    if height:
        video['height'] = height
        item['quality'] = quality_of_resolution(width, height)
    if fps := attrs.get('FRAME-RATE'):
        video['fps'] = round(float(fps))
    item['video'] = video

    url = urljoin(url, uri)
    resp = session.get(url, timeout=_PROBE_TIMEOUT)
    resp.raise_for_status()
    playlist = resp.text
    if bandwidth and (duration := sum(float(value) for value in re.findall(r'#EXTINF:([\d.]+)', playlist))):
        item['filesize'] = int(bandwidth * duration / 8)
    if 'mp4a' not in attrs.get('CODECS', 'mp4a') or '#EXT-X-KEY' in playlist:
        return  # only a plain MPEG-TS with AAC
    segment = next((line.strip() for line in playlist.splitlines() if line.strip() and not line.startswith('#')), '')
    if not segment:
        return
    resp = session.get(urljoin(url, segment), timeout=_PROBE_TIMEOUT, headers={'Range': f'bytes=0-{_PROBE_BYTES - 1}'})
    resp.raise_for_status()
    if channels := _aac_channels(resp.content[:_PROBE_BYTES]):
        track: AudioTrack = {**item.get('audio', [{}])[0], 'codec': AudioCodec.AAC, 'channels': channels}
        item['audio'] = [track]


def _aac_channels(data: bytes) -> str | None:
    """Return the channels of the AAC (ADTS) stream in the start of an MPEG-TS segment."""
    streams: dict[int, bytearray] = {}
    for pos in range(data.find(b'\x47'), len(data) - 187, 188):
        packet = data[pos:pos + 188]
        if packet[0] != 0x47 or not packet[3] & 0x10:  # lost sync, no payload
            continue
        offset = 5 + packet[4] if packet[3] & 0x20 else 4  # skip the adaptation field
        streams.setdefault(((packet[1] & 0x1F) << 8) | packet[2], bytearray()).extend(packet[offset:])
    for stream in streams.values():
        pos = 0
        while (pos := stream.find(b'\xff', pos)) >= 0 and pos + 7 <= len(stream):
            # an ADTS header whose frame length leads to the next one
            if stream[pos + 1] & 0xF6 == 0xF0:
                length = ((stream[pos + 3] & 0x3) << 11) | (stream[pos + 4] << 3) | (stream[pos + 5] >> 5)
                following = stream[pos + length:pos + length + 2]
                if 7 < length and len(following) == 2 and following[0] == 0xFF and following[1] & 0xF6 == 0xF0:
                    return _AAC_CHANNELS.get(((stream[pos + 2] & 0x1) << 2) | (stream[pos + 3] >> 6))
            pos += 1
    return None
