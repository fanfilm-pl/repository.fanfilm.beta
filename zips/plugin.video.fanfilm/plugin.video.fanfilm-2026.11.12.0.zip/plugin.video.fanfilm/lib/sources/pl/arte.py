# -*- coding: utf-8 -*-
"""
FanFilm - source: ARTE (arte.tv/pl)

Dystrybuowane na licencji MIT <https://mit-license.org>

ARTE's Polish edition: European arthouse films (and documentaries) with
Polish subtitles, free and legal, HLS up to 1080p. Public JSON API, no key:

    search: https://api.arte.tv/api/emac/v4/pl/web/zones/<listing_SEARCH zone>/content?query=<q>
            -> value.data[]: {programId, title, subtitle, duration (s), kind.code}
    player: https://api.arte.tv/api/player/v2/config/pl/<programId>
            -> data.attributes.streams[]: {url (HLS), mainQuality.code (XQ = 1080p, its label is wrong),
                                           versions[]: {label, audioLanguage, subtitleLanguage}}

Search results carry no year, so a film matches on its exact title (original,
Polish or alias) plus its runtime. A stand-alone film has a "-000-A" program
id. The manifest URLs are generated per request, so resolve() asks the player
API again.
"""

from __future__ import annotations

import re
import unicodedata
from typing import ClassVar, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs

from lib.ff import requests
from lib.ff.source_utils import DEFAULT_UA, get_original_title
from lib.ff.logs import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias

_SEARCH_URL: str = 'https://api.arte.tv/api/emac/v4/pl/web/zones/74b64f6e-bf88-45fe-9d56-e824c1655e1c/content'
_PLAYER_URL: str = 'https://api.arte.tv/api/player/v2/config/pl/{}'
_HEADERS: dict[str, str] = {'User-Agent': DEFAULT_UA, 'Accept': 'application/json'}
_TIMEOUT: int = 15
_QUALITY: dict[str, str] = {'XQ': '1080p', 'HQ': '720p', 'SQ': 'SD', 'EQ': 'SD'}
_MIN_DURATION: int = 40 * 60
_DURATION_TOLERANCE: int = 15 * 60

_session: requests.Session = requests.Session()
_session.headers.update(_HEADERS)


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'Arte'
    priority: ClassVar[int] = 1
    language: ClassVar[list[str]] = ['pl']

    ffitem: FFItem

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: list[SourceTitleAlias], year: str) -> str | None:
        titles = [title, localtitle, *(alias['title'] for alias in aliases)]
        wanted = {cleaned for cleaned in (_clean(name) for name in titles if name) if cleaned}
        duration = self.ffitem.duration or 0
        for query in dict.fromkeys(name for name in (localtitle, title, get_original_title(aliases)) if name):
            for item in _search(query):
                program_id = str(item.get('programId') or '')
                item_duration = int(item.get('duration') or 0)
                if (not program_id.endswith('-000-A') or item_duration < _MIN_DURATION
                        or _clean(item.get('title') or '') not in wanted):
                    continue
                if duration and abs(duration - item_duration) > _DURATION_TOLERANCE:
                    fflog(f'skip {program_id} {item.get("title")!r}: {item_duration}s vs {duration}s')
                    continue
                fflog(f'found {program_id} {item.get("title")!r}')
                return urlencode({'id': program_id})
        return None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: list[SourceTitleAlias], year: str) -> str | None:
        return None  # films only - ARTE's Polish series are documentary programmes

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> str | None:
        return None

    def sources(self, url: str | None, hostDict: list[str],
                hostprDict: list[str]) -> list[SourceItem]:
        result: list[SourceItem] = []
        program_id = (parse_qs(url or '').get('id') or [''])[0]
        if not program_id:
            return result
        stream = _polish_stream(program_id)
        if stream:
            audio = next((version.get('audioLanguage') for version in stream.get('versions') or []
                          if version.get('audioLanguage')), '')
            result.append({
                'hosting': 'ARTE',
                'url': urlencode({'id': program_id}),
                'quality': _QUALITY.get((stream.get('mainQuality') or {}).get('code', ''), 'SD'),
                'language': audio,  # the original audio, Polish only as subtitles
                'info': 'napisy PL',
                'direct': True,
                'debridonly': False,
            })
        fflog(f'sources: {len(result)} for {program_id}')
        return result

    def resolve(self, url: str) -> str | None:
        program_id = (parse_qs(url).get('id') or [''])[0]
        stream = _polish_stream(program_id) if program_id else None
        return f"isa+{stream['url']}" if stream else None


def _search(query: str) -> list[dict]:
    try:
        resp = _session.get(_SEARCH_URL, params={'query': query, 'page': 1, 'limit': 20}, timeout=_TIMEOUT)
        if resp.status_code != 200:
            fflog(f'search {query!r}: HTTP {resp.status_code}')
            return []
        data = resp.json()
        return (data.get('value') or data).get('data') or []
    except Exception:
        fflog_exc()
        return []


def _polish_stream(program_id: str) -> dict | None:
    """Return the HLS stream with a Polish version (subtitles for the hearing-impaired last), None if there is none."""
    try:
        resp = _session.get(_PLAYER_URL.format(program_id), timeout=_TIMEOUT)
        if resp.status_code != 200:
            fflog(f'player {program_id}: HTTP {resp.status_code}')
            return None
        streams: list[dict] = resp.json()['data']['attributes'].get('streams') or []
    except Exception:
        fflog_exc()
        return None
    polish = [stream for stream in streams if stream.get('url') and any(
        'polski' in (version.get('label') or '').lower() for version in stream.get('versions') or [])]
    polish.sort(key=lambda stream: any(
        'niesłyszących' in (version.get('label') or '').lower() for version in stream.get('versions') or []))
    return polish[0] if polish else None


def _clean(title: str) -> str:
    """Lower-case letters and digits only, accents folded."""
    folded = unicodedata.normalize('NFKD', title.lower().replace('ł', 'l').replace('œ', 'oe').replace('æ', 'ae'))
    return re.sub(r'[^0-9a-z]+', '', ''.join(char for char in folded if not unicodedata.combining(char)))


if __name__ == '__main__':
    from types import SimpleNamespace
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test Arte source provider')
    parser.add_argument('title', help='original title')
    parser.add_argument('localtitle', nargs='?', default='')
    parser.add_argument('minutes', nargs='?', type=int, default=0, help='runtime')
    args = parser.parse_args()

    src = source()
    src.ffitem = SimpleNamespace(duration=args.minutes * 60)  # type: ignore[assignment]
    found = src.movie('', args.title, args.localtitle, [], '')
    print('found:', found)
    for item in src.sources(found, [], []):
        print(' ', item, '\n  ->', (src.resolve(item['url']) or '')[:120])
