# -*- coding: utf-8 -*-
"""
FanFilm ‑ źródło: obejrzyj.to, filmyonline.cc, premiumsmart.eu
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
from typing import Optional, Union, Sequence, Iterator, ClassVar, List, Dict, TYPE_CHECKING
from typing_extensions import Literal
from urllib.parse import urlparse, quote, unquote
import re
import json
import hashlib
from json import JSONDecodeError
from base64 import b64encode
from lib.ff import control, requests
from lib.ff.logs import fflog, fflog_exc
from lib.ff.source_utils import sources_with_links, provider_cookie, DEFAULT_UA, get_lang_by_type
from lib.kolang import L
from lib.sources import Provider
from lib.sources.natives import CF_COOKIE, LOGIN, ProviderSetting, SiteCookies, cf_cookies
from lib.sources.natives import provider_value
from const import const
if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.ff.types import JsonData
    from lib.ff.sources import SourceItem
    from lib.sources import ProviderModule, SourceTitleAlias


# ─── _source ─────────────────────────────────────────────────────────────────────

class _source(Provider):
    """Base scraper for sites like obejrzyj.to, filmyonline.cc, etc."""
    PREMIUM: ClassVar[bool] = False

    # --- scraper api ---
    priority: ClassVar[int] = 1
    language: ClassVar[Sequence[str]] = ['pl']

    # --- internal ---
    PROVIDER: ClassVar[str]
    URL: ClassVar[str]
    HAS_TMDB_SUPPORT: ClassVar[bool] = True

    def __init__(self) -> None:
        self._session: Optional[requests.Session] = None
        self._found: JsonData = {}

    @property
    def session(self) -> requests.Session:
        """Return request session."""
        if self._session is None:
            self._session = requests.Session()
            self._session.get(self.URL, timeout=15)  # to get session "active" (cookies)
        return self._session

    def request(self, url: str) -> JsonData:
        """Site get request."""
        resp = self.session.get(url, timeout=15, headers={
            'accept': 'application/json',
            'referer': self.URL,
        })
        fflog.debug(f'[{self.PROVIDER.upper()}] request: {url} -> {resp.status_code}')
        if resp.status_code == 200:
            return resp.json()
        return {}

    def make_id(self, tid: Union[int, str],
                *,
                type: Optional[Literal['movie', 'series', 'person']] = None,
                service: Optional[Literal['tmdb', 'imdb']] = None,
                ) -> str:
        """Make tmdb/imdb id/"""
        if type and service:
            tid = b64encode(f'{service}|{type}|{tid}'.encode()).decode('ascii')
        return str(tid)

    def source_name(self, item: JsonData) -> str:
        """Retrun source (service) name from video JSON."""
        return urlparse(item['src']).hostname or ''

    def video_language(self, item: JsonData) -> str:
        """Retrun video language from video JSON."""
        return item.get('language', 'pl').lower()

    # ── public api ─────────────────────────────────────────────────────────

    @fflog_exc
    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        ids = self.ffitem.ids
        # get movie details
        if data := self._obtain_media(self.ffitem):
            self._found = {
                'id': data['id'],
                'titles': [v for k in ('name', 'original_title') if (v := data.get(k))],
                'videos': [v for v in data['videos'] if v.get('category') == 'full'],
            }
            # return json.dumps(self._found)
            return data['id']
        fflog(f'[{self.PROVIDER.upper()}] movie {self.ffitem} not found')
        return None  # movie not found

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        return '_'  # not needed, search episode is enough

    @fflog_exc
    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        ref = self.ffitem.ref
        if (show_item := self.ffitem.show_item) is None:
            return None
        titles = []

        # only movie and series work with tmbd/imdb; for episode we have to get internal show id first
        if data := self._obtain_media(show_item):
            media_id = data['id']
            titles = [v for k in ('name', 'original_title') if (v := data.get(k))]
        else:
            fflog(f'[{self.PROVIDER.upper()}] show {self.ffitem} not found')
            return None  # show not found

        # get episode details
        ep_data = self._get_episode_data(media_id, ref.season, ref.episode)
        if ep_data:
            if name := ep_data.get('name'):
                titles.append(name)
            self._found = {
                'id': media_id,
                'titles': titles,
                'videos': [v for v in ep_data['videos'] if v.get('category') == 'full']
            }
            return media_id
        fflog(f'[{self.PROVIDER.upper()}] episode {self.ffitem} / {ref.season} / {ref.episode} not found')
        return None  # episode not found

    def _get_episode_data(self, media_id: str, season: str, episode: str) -> 'JsonData':
        """Return episode JSON dict or {} if not found."""
        resp = self.request(f'{self.URL}api/v1/titles/{media_id}/seasons/{season}/episodes/{episode}?loader=episodePage')
        return resp.get('episode', {})

    def sources(self, url: str, hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        result = list(sources_with_links(self._videos({})))
        fflog(f'sources: {len(result)}')
        return result

    def resolve(self, url: str, **kwargs) -> str:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _query(self, title: str) -> str:
        """Prepare title to search."""
        title = re.sub(r'(?:^|(?<=\s))(?:I{1,3}[VX]?|[VX]I{0,3}|\d+)(?:(?=\s|$))',
                       '', title)  # remove numbers (digits and roman)
        title = re.sub(r'\b\w\b', '', title)  # remove single letters
        title = re.sub(r'\s+', ' ', title).strip()  # clear spaces
        if '/' in title:  # '/' is not sopported by site at all
            title = max(title.split('/'), key=lambda t: len(t.strip()))  # the longest word to search
        return title.strip()

    def _search(self, query: str, *, tmdb: int | str | None = None, imdb: str | None = None) -> list[JsonData]:
        fflog(f'query: {query!r}')
        try:
            data = self.request(f"{self.URL}api/v1/search/{quote(query, safe='')}?loader=searchPage")
        except JSONDecodeError:
            fflog(f'[{self.PROVIDER.upper()}] JSON error for query={query!r}')
            return []
        if (raw := data.get('results')) is None:
            fflog(f'[{self.PROVIDER.upper()}] search: unexpected response keys={list(data.keys())} for query={query!r}')
            return []
        fflog(f'search: {len(raw)} results')
        if tmdb:
            tmdb = int(tmdb)
        if tmdb or imdb:
            return [item for item in raw
                    if (not tmdb or tmdb == item['tmdb_id']) and (not imdb or imdb == item['imdb_id'])]
        return raw

    def _obtain_media(self, ffitem: FFItem) -> JsonData:
        """Return media details JSON."""
        ids = ffitem.ids
        mtype = ffitem.ref.type
        if mtype == 'movie':
            pass
        elif mtype == 'show':
            mtype = 'series'
        else:
            return {}
        # get movie details by tmdb/imdb id if service support it
        if self.HAS_TMDB_SUPPORT:
            for meta_service in ('tmdb', 'imdb'):
                if meta_id := ids.get(meta_service):
                    media_id = self.make_id(meta_id, type=mtype, service=meta_service)
                    try:
                        if data := self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage'):
                            return data['title']
                    except JSONDecodeError:
                        fflog(f'[{self.PROVIDER.upper()}] JSON error for {self.ffitem} id={media_id!r}')
                        break
        # IDs not supported by site or not found
        # When HAS_TMDB_SUPPORT=False there is no ID filtering — use the full title
        # so sequel numbers (e.g. "Pirates 3") are preserved for disambiguation.
        query = ffitem.title if (mtype == 'series' or not self.HAS_TMDB_SUPPORT) else self._query(ffitem.title)
        id_filter = ids if self.HAS_TMDB_SUPPORT else {}
        if found := self._search(query, tmdb=id_filter.get('tmdb'), imdb=id_filter.get('imdb')):
            fflog(f'[{self.PROVIDER.upper()}] {ffitem} found by search: {len(found)} item(s)')
            for media_data in found:
                media_id = media_data['id']
                try:
                    if data := self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage'):
                        return data['title']
                except JSONDecodeError:
                    pass
        # not found
        return {}

    @fflog_exc
    def _videos(self, data: JsonData) -> Iterator[SourceItem]:
        """Retrun list of found videos in movie() or episode(), agruments don't matter."""
        data = self._found
        if not data:
            data = {}
        media_id = data.get('id')
        videos = data.get('videos', ())
        fflog(f'[{self.PROVIDER.upper()}] {media_id=}, process {len(videos)} video(s)')
        if not videos:
            return
        # vtag = self.ffitem.vtag
        # titles = '|'.join(re.escape(t) for t in (self.ffitem.title, vtag.getEnglishTitle(), vtag.getOriginalTitle(),
        #                                          *data.get('titles', ())) if t)
        # rx_title = re.compile(fr'^({titles})\s*', flags=re.IGNORECASE)
        # known_sources = 'booster'  # '|'-separated list of well known sources
        for item in videos:
            # fflog(f'[{self.PROVIDER}][VIDEO]  video = {json.dumps(item, indent=2)}')
            if item.get('category') == 'full':
                name: str = item['name']
                quality: str = item.get('quality') or '1080p'
                lang: str = self.video_language(item)
                src: str = item['src']
                if not src.startswith(('http://', 'https://')):
                    match = re.search(r'https?://', src)
                    if not match:
                        fflog(f'[{self.PROVIDER.upper()}] id={media_id} invalid src={src!r}, skipping')
                        continue
                    src = src[match.start():]
                # the language type of the video name (its facts; a CAM video: sources.py adds it itself)
                info = get_lang_by_type(f"{name} {item.get('language_type', '')}")[1]
                fflog(f'[{self.PROVIDER.upper()}] id={media_id} video={src!r}, {info=}')
                yield {
                    'hosting': urlparse(src).hostname or self.source_name(item) or '?',
                    'quality': quality.lower() if quality[:3].isdigit() else quality.upper(),  # 1080p.. but 4K, HD...
                    'language': lang,
                    'url': src,
                    # 'info': re.sub(fr'\b(?:((?:lektor|dubb?ing|napisy)\s?)?{lang})\b', r'\1', rx_title.sub('', name), flags=re.IGNORECASE).split(None, 1)[-1],
                    'info': info,
                    'direct': False,
                    'debridonly': False,
                    'filename': '',  # name
                    'premium': False,
                }


# ─── ObejrzyjTo ──────────────────────────────────────────────────────────────────

class ObejrzyjTo(_source):
    """Scraper for obejrzyj.to."""
    PROVIDER: ClassVar[str] = 'obejrzyjto'
    LABEL: ClassVar[str] = 'Obejrzyj.to'
    URL: ClassVar[str] = 'https://obejrzyj.to/'

    # def source_name(self, item: JsonData) -> str:
    #     """Retrun source (service) name from video JSON."""
    #     return item['name'].split(None, 1)[0] or super().source_name(item)


# ─── FilmyOnlineCc ───────────────────────────────────────────────────────────────

class FilmyOnlineCc(_source):
    """Scraper for filmyonline.cc."""
    PROVIDER: ClassVar[str] = 'filmyonline'
    LABEL: ClassVar[str] = 'Filmyonline.cc'
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = CF_COOKIE
    COOKIES: ClassVar[tuple[SiteCookies, ...]] = (cf_cookies('filmyonline.cc'),)
    URL: ClassVar[str] = 'https://filmyonline.cc/'
    HAS_TMDB_SUPPORT: ClassVar[bool] = False

    def __init__(self) -> None:
        super().__init__()
        self._csrf_token: Optional[str] = None

    @property
    def session(self) -> requests.Session:
        """Return request session with cf_clearance cookie and XSRF extracted from home page."""
        if self._session is None:
            self._session = requests.Session()
            ua = provider_value('filmyonline', 'user_agent').strip(' "\'') or DEFAULT_UA
            self._session.headers.update({
                'User-Agent': ua,
                'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            })
            cf_clearance = provider_cookie('filmyonline', 'cf_clearance')
            if cf_clearance:
                self._session.cookies.set('cf_clearance', cf_clearance, domain='filmyonline.cc')
            resp = self._session.get(self.URL, timeout=15)
            if resp.status_code == 200:
                xsrf = self._session.cookies.get('XSRF-TOKEN')
                if xsrf:
                    self._csrf_token = unquote(xsrf)
                fflog.debug(f'[{self.PROVIDER.upper()}] session OK, CSRF: {"found" if self._csrf_token else "not found"}')
            else:
                fflog(f'[{self.PROVIDER.upper()}] home page returned {resp.status_code}')
                if resp.status_code in (401, 403):
                    control.groupedInfoDialog('filmyonline_cf_expired', L(32848, 'Refresh cookies'), heading='filmyonline.cc', icon='ERROR')
        return self._session

    def request(self, url: str) -> JsonData:
        """Site get request with CSRF token."""
        session = self.session
        headers: Dict[str, str] = {
            'accept': 'application/json',
            'referer': self.URL,
        }
        if self._csrf_token:
            headers['X-XSRF-TOKEN'] = self._csrf_token
        resp = session.get(url, timeout=15, headers=headers)
        fflog.debug(f'[{self.PROVIDER.upper()}] request: {url} -> {resp.status_code}')
        if resp.status_code == 200:
            try:
                return resp.json()
            except JSONDecodeError:
                return {}
        if resp.status_code in (401, 403):
            control.groupedInfoDialog('filmyonline_cf_expired', L(32848, 'Refresh cookies'), heading='filmyonline.cc', icon='ERROR')
        return {}

    def _get_episode_data(self, media_id: str, season: str, episode: str) -> 'JsonData':
        """Try episode page, season page, then title-level videos as last resort."""
        resp = self.request(f'{self.URL}api/v1/titles/{media_id}/seasons/{season}/episodes/{episode}?loader=episodePage')
        if ep_data := resp.get('episode'):
            return ep_data
        # Season page fallback
        season_resp = self.request(f'{self.URL}api/v1/titles/{media_id}/seasons/{season}?loader=seasonPage')
        episodes: list = season_resp.get('episodes') or season_resp.get('season', {}).get('episodes', [])
        ep_num = int(episode)
        for ep_item in episodes:
            if ep_item.get('episode_number') == ep_num or ep_item.get('number') == ep_num:
                return ep_item
        # Title-level videos fallback: site may store episode videos at title level without episode numbering
        title_resp = self.request(f'{self.URL}api/v1/titles/{media_id}?loader=titlePage')
        title_videos = title_resp.get('title', {}).get('videos', [])
        fflog.debug(f'[{self.PROVIDER.upper()}] title-level fallback: {len(title_videos)} video(s)')
        if title_videos:
            return {'videos': title_videos}
        return {}


# ─── PremiumsmartEu ──────────────────────────────────────────────────────────────

class PremiumsmartEu(_source):
    """Scraper for premiumsmart.eu.

    Works as a guest (the guest role already has ``videos.play``). Login is
    optional: with credentials in the settings, the session carries a Bearer
    token so the scraper keeps working should the site start gating content
    behind an account. The login is the plain e-mail/password one (``POST
    /api/v1/auth/login``), not the TV pairing code — only a password login can
    silently re-authenticate when the token expires (a code needs a human).
    """
    PROVIDER: ClassVar[str] = 'premiumsmart'
    LABEL: ClassVar[str] = 'Premiumsmart'
    URL: ClassVar[str] = 'https://premiumsmart.eu/'
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = (*LOGIN,)
    #: A fresh login token is good for a week; an earlier expiry is handled by the 401 retry.
    TOKEN_TTL: ClassVar[int] = 7 * 24 * 3600

    def __init__(self) -> None:
        super().__init__()
        self._csrf_token: Optional[str] = None
        self.user_name: str = provider_value(self.PROVIDER, 'username') or ''
        self.user_pass: str = provider_value(self.PROVIDER, 'password') or ''
        pass_hash = hashlib.md5(self.user_pass.encode()).hexdigest()[:8]
        self._auth_cache_key = f'authtoken_{self.user_name}_{pass_hash}'

    def _login(self) -> Optional[str]:
        """Return a Bearer token (cached or fresh), or None when no credentials / login failed.

        No credentials means "stay a guest" — no dialog, since the guest role can
        still play. A rejected login is remembered (``refuse_login``) so the same
        wrong credentials are not retried until the TTL, and the user is told once.
        """
        if not (self.user_name and self.user_pass):
            return None
        if token := self.store.get(self._auth_cache_key):   # an expired token is not there
            return token
        if self.store.login_refused(self.user_name, self.user_pass):
            fflog(f'[{self.PROVIDER.upper()}] login: failed lately, not tried again with the same credentials')
            return None
        if self._session is None:  # called from the session property, where it is set — guard for the type checker
            return None
        # Stateful (Sanctum) login: the session already holds the XSRF-TOKEN cookie, so the
        # CSRF header must carry its value; the bootstrap csrf_token works as well. Without
        # the cookie the endpoint is rate-limited by IP ("Too Many Attempts", 429).
        xsrf = self._csrf_token
        if self._session.cookies.get('XSRF-TOKEN'):
            xsrf = unquote(self._session.cookies['XSRF-TOKEN'])
        status = 0
        data: JsonData = {}
        try:
            resp = self._session.post(f'{self.URL}api/v1/auth/login', timeout=15, headers={
                'accept': 'application/json',
                'referer': self.URL,
                **({'X-XSRF-TOKEN': xsrf} if xsrf else {}),
            }, json={'email': self.user_name, 'password': self.user_pass, 'token_name': 'FanFilm'})
            status = resp.status_code
            if status == 200 and isinstance(body := resp.json(), dict):
                data = body
        except (JSONDecodeError, OSError):
            pass
        if token := (data.get('user') or {}).get('access_token'):
            self.store.set(self._auth_cache_key, token, ttl=self.TOKEN_TTL)
            fflog(f'[{self.PROVIDER.upper()}] login OK')
            return token
        message = data.get('message', '')
        fflog(f'[{self.PROVIDER.upper()}] login failed (HTTP {status}): {message or "no token in response"}')
        # Only wrong credentials (401/422) are remembered and shown — a transient refusal
        # (429 rate limit, 5xx, network) must not lock the account out or nag; stay a guest.
        if status in (401, 422):
            self.store.refuse_login(self.user_name, self.user_pass, ttl=const.sources.providers.login_retry)
            control.groupedInfoDialog(f'{self.PROVIDER}_login_failed', message or L(32849, 'Login failed'),
                                      heading=self.LABEL, icon='ERROR')
        return None

    @property
    def session(self) -> requests.Session:
        """Return request session with CSRF token (and a Bearer token when logged in)."""
        if self._session is None:
            self._session = requests.Session()
            self._session.headers.update({
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
                'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                'DNT': '1',
                'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Linux"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
            })

            # Fetch the home page to get cookies and CSRF token
            resp = self._session.get(self.URL, timeout=15)
            if resp.status_code == 200:
                # Extract CSRF token from bootstrapData
                match = re.search(r'window\.bootstrapData\s*=\s*({.*});', resp.text, re.S)
                if match:
                    try:
                        data = json.loads(match.group(1))
                        self._csrf_token = data.get('csrf_token')
                        fflog.debug(f'[{self.PROVIDER.upper()}] CSRF token obtained from bootstrapData object')
                    except JSONDecodeError:
                        fflog.debug(f'[{self.PROVIDER.upper()}] Could not parse bootstrapData, falling back to regex')

                if not self._csrf_token:
                    match = re.search(r'"csrf_token"\s*:\s*"([^"]+)"', resp.text)
                    if match:
                        self._csrf_token = match.group(1)
                        fflog.debug(f'[{self.PROVIDER.upper()}] CSRF token obtained via regex')
                    else:
                        fflog(f'[{self.PROVIDER.upper()}] failed to extract CSRF token from HTML')

                # Alternatively from cookie (it is URL-encoded)
                if not self._csrf_token and 'XSRF-TOKEN' in self._session.cookies:
                    self._csrf_token = unquote(self._session.cookies['XSRF-TOKEN'])
                    fflog.debug(f'[{self.PROVIDER.upper()}] CSRF token from cookie')
            else:
                fflog(f'[{self.PROVIDER.upper()}] failed to get homepage: {resp.status_code}')

            # Optional account login: attach the Bearer token for the whole session.
            if token := self._login():
                self._session.headers['Authorization'] = f'Bearer {token}'

        return self._session

    def request(self, url: str, _retried: bool = False) -> JsonData:
        """Site get request with CSRF token and retry on auth failure."""
        headers = {
            'accept': 'application/json',
            'referer': self.URL,
        }

        # The sess property will create the session and get the token on the first run.
        session = self.session

        if self._csrf_token:
            headers['X-XSRF-TOKEN'] = self._csrf_token
        else:
            # The token might not be found on the initial page load.
            fflog(f'[{self.PROVIDER.upper()}] no CSRF token after session init: {url}')

        resp = session.get(url, timeout=15, headers=headers)
        fflog.debug(f'[{self.PROVIDER.upper()}] request: {url} -> {resp.status_code}')

        if resp.status_code == 200:
            try:
                return resp.json()
            except JSONDecodeError as e:
                fflog(f'[{self.PROVIDER.upper()}] JSON decode error: {e}')
                return {}

        # If there's an auth error and we haven't retried, reset session and retry once.
        if resp.status_code in (401, 403, 419) and not _retried:
            fflog.debug(f'[{self.PROVIDER.upper()}] Auth error ({resp.status_code}). Assuming expired token, retrying.')
            self._session = None
            self._csrf_token = None
            self.store.delete(self._auth_cache_key)  # drop the (possibly expired) token so the retry re-logs in
            return self.request(url, _retried=True)

        elif resp.status_code == 401:
            fflog(f'[{self.PROVIDER.upper()}] 401 unauthorized - missing or invalid CSRF token')
        elif resp.status_code == 403:
            fflog(f'[{self.PROVIDER.upper()}] 403 forbidden - check headers/cookies')
        else:
            fflog(f'[{self.PROVIDER.upper()}] unexpected status: {resp.status_code}')

        return {}

    def video_language(self, item: JsonData) -> str:
        """Return the video language from its language type (its facts), Polish if it says nothing."""
        return get_lang_by_type(item.get('language_type') or '')[0] or 'pl'


def register(sources: List[ProviderModule], group: str) -> None:
    """Register all scrapers."""
    from lib.sources import ProviderModule
    for src in (ObejrzyjTo, FilmyOnlineCc, PremiumsmartEu):
        sources.append(ProviderModule(name=src.PROVIDER, provider=src(), group=group))
