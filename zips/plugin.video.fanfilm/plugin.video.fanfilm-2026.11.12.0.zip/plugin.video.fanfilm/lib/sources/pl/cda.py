# -*- coding: utf-8 -*-
"""
FanFilm - source: cda.pl (the API of the CDA Android app)
Copyright (C) 2026 :)

Distributed under the MIT license <https://mit-license.org>
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
from ast import literal_eval
from typing import TYPE_CHECKING, Any
from urllib.parse import urlencode, urlsplit

from attrs import evolve

from cdefs import DAY
from const import const
from lib.ff import cleantitle, control, requests, source_utils
from lib.ff.item import FFItem
from lib.ff.logs import fflog, fflog_exc
from lib.ff.source_utils import CHROME_UA, ShowData, ShowDataDict, convert_size, show_data_asdict
from lib.kolang import L
from lib.sources import IncompleteResult
from lib.sources.natives import LOGIN, ProviderSetting, provider_value

if TYPE_CHECKING:
    from typing import Collection, ClassVar
    from lib.ff.db.sources import ProviderStore
    from lib.sources import SourceItem, SourceTitleAlias


USER_AGENT: str = CHROME_UA
HASH_SALT: bytes = b'NpmMLBWRgtEX8vp3Kf3d0tasBpFt0tuGswL9hR0qt7bQdaxuvDGoczFGeqd68Nj2'
BASIC_AUTH: str = (
    'Basic NzdjMGYzYzUtMzZhMC00YzNkLWIwZDQtMGM0ZGZiZmQ1NmQ1Ok5wbU1MQldSZ3RFWDh2'
    'cDNLZjNkMHRhc0JwRnQwdHVHc3dMOWhSMHF0N2JRZGF4dXZER29jekZHZXFkNjhOajI='
)
BASE_LINK: str = 'https://api.cda.pl'
#: Lifetime of the account token in the provider store.
TOKEN_TTL: int = 7 * DAY
#: Lifetime of the DRM data of a source (longer than the source list in the sources cache).
DRM_DATA_TTL: int = DAY
SEARCH_LINK: str = f'{BASE_LINK}/video/search'
#: Search results of one query (the API takes `limit` well over 100, the app's `count` stops at 20).
SEARCH_LIMIT: int = 100
#: Search results of a bare title query (no year / episode marker) - broad, the wanted video is often past 100.
SEARCH_BARE_LIMIT: int = 300

TITLE_STOPWORDS: set[str] = {
    'dubbing',
    'napisy',
    'zwiastun',
    'trailer',
    'recenzja',
    'omowienie',
    'podsumowanie',
    'gameplay',
    'nazywo',
    'walktrough',
    'stream',
    'opis',
    'newsy',
    # uploader filler that carries no title info (e.g. "Wiedźmin (2001) Cały film PL"
    # would otherwise dilute _all_words_match coverage below min_coverage)
    'caly',
    'cala',
    'cale',
    'film',
    'wersja',
}
TITLE_EXCLUDE_WORDS: set[str] = {
    'cały sezon',
    'kolekcja',
    'box',
    'antologia',
    'zwiastun',
    'trailer',
    'recenzja',
    'omowienie',
    'podsumowanie',
    'omówienie',
    'gameplay',
    'nazywo',
    'walktrough',
    'stream',
    'opis',
    'newsy',
    'playstation',
    'xbox',
    'ps3',
    'ps4',
    'ps5',
    'xbox360',
    'xboxone',
    'xboxone s',
    'xboxone x',
    'xbox series s',
    'xbox series x',
    'nintendo',
    'switch',
    'soundtrack',
}
EPISODE_RE: re.Pattern[str] = re.compile(r'\bs\d{1,2}e\d{2,4}\b', re.I)
# Non-standard episode markers used on cda.pl titles (e.g. "Cuda (1) - subtitle")
_NXM_EP_RE: re.Pattern[str] = re.compile(r'\b\d{1,2}x\d{1,4}\b')
_NAMED_EP_RE: re.Pattern[str] = re.compile(r'\b(?:odcinek|odc|episode|ep)\s*\.?\s*\d+\b', re.I)
_BARE_EP_RE: re.Pattern[str] = re.compile(r'\(\s*\d{1,3}\s*\)')
SEQUEL_REGEX: re.Pattern[str] = re.compile(r'\b([2-9]|[1-9][0-9])\b')
# Roman numerals used in sequel titles (I excluded - too common as standalone word)
_ROMAN_SEQUEL_RE: re.Pattern[str] = re.compile(r'\b(ii|iii|iv|vi|vii|viii|ix|xi|xii)\b', re.I)
# Words appended to video titles that don't identify the film (audio/quality tags)
_TITLE_QUALIFIERS: frozenset[str] = frozenset({
    'lektor', 'lector', 'hdtv', 'bluray', 'bdrip', 'dvdrip', 'dvd',
    'webrip', 'xvid', 'x264', 'x265', 'hevc', 'avc', '1080p', '720p',
    '480p', '4k', 'uhd', 'fhd', 'mkv', 'avi', 'mp4', 'scr', 'cam',
    'proper', 'repack', 'extended', 'unrated', 'remastered',
    'napisy', 'subbed', 'dubbing', 'pllek', 'plsub', 'pldub', 'multi',
})

# bhole* direct-file hosts sometimes hit a cert outage while the rest of CDA works fine
_FLAKY_DIRECT_HOST_RE: re.Pattern[str] = re.compile(r'^bhole\d*\.cda\.pl$', re.I)


# ─── source ──────────────────────────────────────────────────────────────────────

class source:  # noqa: N801
    """cda.pl provider (search, direct files and DASH / Widevine streams)."""

    LABEL: ClassVar[str] = 'CDAPL'
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = (
        evolve(LOGIN[0], label=L(32651, 'E-mail (login)')), LOGIN[1],
    )
    PREMIUM: ClassVar[bool | Collection[bool] | None] = (False, True)

    ffitem: FFItem
    store: ProviderStore

    def __init__(self) -> None:
        """Read the account settings and prepare the HTTP session."""
        self.priority: int = 1
        self.language: list[str] = ['pl']
        self.domains: list[str] = ['cda.pl']
        self.debug: bool = const.sources.cda.debug

        self.email: str = provider_value('cda', 'username')
        passwd_ctrl: str = provider_value('cda', 'password')
        self.passwd: str = self._hash_password(passwd_ctrl)
        email_hash: str = hashlib.md5(self.email.encode()).hexdigest()[:8]
        self._token_cache_key: str = f'cda_token_{email_hash}'

        self.session: requests.Session = requests.ProviderSession()
        self.headers: dict[str, str] = {
            'User-Agent': USER_AGENT,
            'Accept': 'application/vnd.cda.public+json',
        }
        self.headers_basic: dict[str, str] = {'Authorization': BASIC_AUTH}
        self.token: str | None = None  # from the store on the first request (self.store is bound after __init__)

        self.year: int = 0
        self._is_episode: bool = False
        self._episode_year: int = 0

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> list[str]:
        """Search a movie, return candidate video ids."""
        return self._search(title, localtitle, int(year or 0), aliases)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict:
        """Return the show token (titles, aliases, year)."""
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, int(year)))

    def episode(self, url: dict[str, Any], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> list[str]:
        """Search an episode, return candidate video ids."""
        data: ShowData = ShowData(**url)
        self.year = data.year
        self._is_episode = True
        self._episode_year = int(premiered[:4]) if premiered[:4].isdigit() else 0
        ep_no: str = f's{season.zfill(2)}e{episode.zfill(2)}'
        return self._search_episode(data.title, data.local_title, self.year, ep_no, data.aliases)

    def sources(self, ids: list[str] | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:  # noqa: N803
        """Fetch the video details of the candidates and build the direct and DRM sources."""
        sources: list[SourceItem] = []
        if not ids:
            return sources

        fflog(f'processing {len(ids)} candidates')
        # DRM sources are added at the end of the list
        drm_sources: list[dict[str, Any]] = []
        failed: int = 0

        for index, video_id in enumerate(ids):
            fflog(f'candidate {index + 1}/{len(ids)} (id: {video_id})')
            try:
                query: dict[str, Any] = self._api_get(f'{BASE_LINK}/video/{video_id}').json()
            except Exception:
                fflog_exc()
                failed += 1
                continue

            if query.get('error'):
                if self.debug:
                    fflog(f"skip (api error): id={video_id} ({query.get('error')})")
                continue

            video: dict[str, Any] = query.get('video') or {}
            if not self._compare_duration(self.ffitem.vtag.getDuration(), video.get('duration')):
                if self.debug:
                    expected: int = self.ffitem.vtag.getDuration()
                    cda_duration: int = video.get('duration') or 0
                    diff: int = abs(expected - cda_duration)
                    ratio: float = diff / expected if expected else 0
                    fflog(f"skip (duration mismatch): '{video['title']}' (cda={cda_duration}s, expected={expected}s, diff={diff}s,"
                          f' ε_needed={ratio:.3f}, ε_set={const.sources.cda.duration_epsilon})')
                continue

            # LEKTOR, NAPISY, DUBBING... - the language type of the title (its facts: 'bez lektora' is none)
            title: str = video['title']
            info_parts: list[str] = [source_utils.get_lang_by_type(title)[1].upper()]
            if video.get('premium'):
                info_parts.append(const.sources.cda.show_premium_free if video.get('premium_free') else 'Premium')
            if video.get('audio_51'):
                info_parts.append('5.1')
            info: str = ' | '.join(part for part in info_parts if part)
            premium: bool = 'premium' in info.lower()

            if const.sources_dialog.cda_drm:
                adaptive_data: dict[str, Any] | None = video.get('quality_adaptive')
                if adaptive_data:
                    highest_quality: str = self._get_highest_quality_direct(video)
                    if self.debug:
                        fflog(f"DRM candidate: '{title}' (quality={highest_quality}, manifest={adaptive_data.get('manifest')})")
                    drm_sources.append({
                        'adaptive_data': adaptive_data,
                        'video_info': {
                            'title': title,
                            'quality': highest_quality,
                            'adaptive_quality': source_utils.get_quality(highest_quality),
                            'info': info,
                            'premium': premium,
                            'url': video_id,
                        },
                    })

            # regular direct sources
            min_size_bytes: int = const.sources.cda.min_size_mb * 1024 * 1024
            for variant in video['qualities']:
                if not variant.get('file'):
                    if self.debug:
                        fflog(f"skip (no link): '{title}' {variant.get('name')} - not logged in or Premium")
                    continue
                size_in_bytes: int = variant.get('length', 0)
                if size_in_bytes < min_size_bytes:
                    if self.debug:
                        fflog(f"skip (too small): '{title}' ({convert_size(size_in_bytes)})")
                    continue
                sources.append({
                    'hosting': 'CDA',
                    'quality': variant['name'] if variant['name'] in ('1080p', '720p') else 'SD',
                    'language': 'pl',
                    'url': f"DRMFF|{video_id}|{variant['name']}",
                    'info': info,
                    'filename': title,
                    'direct': True,
                    'debridonly': False,
                    'size': convert_size(size_in_bytes),
                    'premium': premium,
                })

        if const.sources_dialog.cda_drm and drm_sources:
            if self.debug:
                fflog(f'adding {len(drm_sources)} DRM sources')
            for index, drm_source in enumerate(drm_sources):
                video_info: dict[str, Any] = drm_source['video_info']
                if self.debug:
                    fflog(f"adding DRM source #{index + 1}: {video_info['quality']}")
                # unique cache key for each DRM source
                cache_key: str = f"DRMFF_{video_info['url']}_{index}"
                self.store.set(cache_key, drm_source['adaptive_data'], ttl=DRM_DATA_TTL)
                sources.append({
                    'hosting': 'CDA',
                    'quality': video_info['adaptive_quality'],
                    'language': 'pl',
                    'url': f"{cache_key}|{video_info['url']}",
                    'info': f"{video_info['info']} | DRM" if video_info['info'] else 'DRM',
                    'filename': video_info['title'],
                    'direct': True,
                    'debridonly': False,
                    'premium': video_info['premium'],
                })

        fflog(f'sources: {len(sources)}')
        if failed:
            raise IncompleteResult(sources, f'{failed} of {len(ids)} candidates failed')
        return sources

    def resolve(self, url: str) -> str | None:
        """Return a direct file link or the DASH / Widevine data (DRMFF|{...}) for InputStream Adaptive."""
        # InputStream old properties - deprecated (Kodi 18-22).
        # See: https://github.com/xbmc/inputstream.adaptive/wiki/Integration-DRM
        from lib.service.client import service_client

        url_parts: list[str] = url.split('|')
        adaptive: dict[str, Any] | None
        if len(url_parts) == 3:  # new format: DRMFF|{video_id}|{quality}
            video_id: str = url_parts[1]
            requested_quality: str = url_parts[2]
            if self.debug:
                fflog(f'resolving forced DRM for video_id: {video_id}, quality: {requested_quality}')

            query: dict[str, Any] = self._api_get(f'{BASE_LINK}/video/{video_id}').json()
            if query.get('error'):
                fflog(f"error fetching video info for {video_id}: {query.get('error')}")
                raise ValueError(f"Error fetching video info for {video_id}: {query.get('error')}")
            video: dict[str, Any] | None = query.get('video')
            if not video:
                fflog(f'no video data for video_id: {video_id}')
                raise ValueError(f'No video data found for video_id: {video_id}')

            adaptive = video.get('quality_adaptive')
            # Try the quality-specific direct file first so the requested quality is
            # actually honoured instead of always falling back to the adaptive stream.
            file_url: str | None = self._direct_quality_url(video, requested_quality)
            if file_url:
                header_string: str = urlencode({'User-Agent': USER_AGENT})
                if self.debug:
                    fflog(f'using direct link for quality {requested_quality}: {file_url}|{header_string}')
                return f'{file_url}|{header_string}'
            if not adaptive:
                if self.debug:
                    fflog(f'no direct link and no adaptive stream for video_id: {video_id}, quality: {requested_quality}')
                raise ValueError(f'No playable stream found for video_id: {video_id}')
            if self.debug:
                fflog(f'direct link unavailable for {requested_quality}, using adaptive stream instead')
        elif len(url_parts) > 1:  # old format: DRMFF|{cache_key}
            cache_key: str = url_parts[0]
            adaptive = self.store.get(cache_key)
            if not isinstance(adaptive, dict):
                fflog(f'DRM failed: no {cache_key}')
                raise ValueError(f'DRM failed: no {cache_key}')
            if self.debug:
                fflog(f'DRM resolve: {adaptive=}')
        else:
            fflog(f'unexpected DRMFF URL format: {url}')
            raise ValueError(f'Unexpected DRMFF URL format: {url}')

        if not adaptive.get('manifest'):
            fflog('DRM failed: no manifest URL')
            raise ValueError('DRM failed: no manifest URL')

        manifest_url: str = adaptive.get('manifest_h264') or adaptive['manifest']
        if self.debug and adaptive.get('manifest_h264'):
            fflog('using H264 manifest for higher quality')

        drm_header: dict[str, str] = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62',
            'X-Dt-Custom-Data': adaptive.get('drm_header_value') or '',
            'Content-Type': 'application/octet-stream',
        }

        lic_url: str | None = adaptive.get('widevine_license')
        if lic_url:
            lic_url = f'{service_client.url}drm={lic_url}'
        elif self.debug:
            fflog('no license URL found - unencrypted DASH, skipping Widevine')

        adaptive_data: dict[str, Any] = {
            'protocol': 'mpd',
            # Most CDA content has no widevine_license at all (plain DASH). Advertising
            # Widevine with an empty licence_url makes ISA try to start a DRM session
            # that can't succeed, so only claim it when we actually have a licence.
            'licence_type': 'com.widevine.alpha' if lic_url else '',
            'mimetype': 'application/dash+xml',
            'manifest': manifest_url,
            'licence_url': lic_url or '',
            'licence_header': urlencode(drm_header) if lic_url else '',
            'post_data': 'R{SSM}' if lic_url else '',
            'response_data': '',
            # X-Dt-Custom-Data/Content-Type are only meaningful for the licence request;
            # sending them on every segment fetch is pointless and, with no lic_url,
            # X-Dt-Custom-Data would be a literal 'None' string.
            'stream_headers': {'User-Agent': USER_AGENT} if not lic_url else drm_header,
        }

        link: str = f'DRMFF|{repr(adaptive_data)}'
        try:
            checked: dict[str, Any] = literal_eval(link.split('|')[-1])
            if self.debug:
                fflog(f"DRM data validation successful: manifest={checked.get('manifest')}")
        except Exception as exc:
            fflog(f'DRM data validation failed: {exc}')
        return link

    # ── helpers ────────────────────────────────────────────────────────────

    def oauth(self, email: str, passwd: str) -> bool:  # name required
        """Obtain the access token and store it."""
        self.headers.update(self.headers_basic)
        if self.store.login_refused(email, passwd):
            fflog('login: failed lately, not tried again with the same credentials')
            return False
        if not self._check_email(email):
            fflog('email check failed')
            return False

        payload: dict[str, str] = {'grant_type': 'password', 'login': email, 'password': passwd}
        response: requests.Response = self.session.post(f'{BASE_LINK}/oauth/token', params=payload, headers=self.headers)
        try:
            user: dict[str, Any] = response.json()
        except ValueError:
            fflog(f'login: bad response {response.status_code}')
            return False

        if user.get('access_token') and user.get('refresh_token'):
            self.token = user['access_token']
            self.store.set(self._token_cache_key, self.token, ttl=TOKEN_TTL)
            fflog('login: ok')
            return True
        fflog(f'login: failed - {user}')
        self.store.refuse_login(email, passwd, ttl=const.sources.providers.login_retry)
        control.groupedInfoDialog('cda_login_failed', L(32849, 'Login failed'), heading='CDA', icon='ERROR')
        return False

    @staticmethod
    def _hash_password(passwd: str) -> str:
        """Hash the password as the CDA API login expects (HMAC-SHA256 of its MD5, url-safe base64)."""
        md5: bytes = hashlib.md5(passwd.encode('utf-8')).hexdigest().encode('utf-8')
        digest: bytes = hmac.new(HASH_SALT, md5, hashlib.sha256).digest()
        return base64.b64encode(digest).decode('utf-8').replace('/', '_').replace('+', '-').replace('=', '')

    def _direct_quality_url(self, video: dict[str, Any], requested_quality: str) -> str | None:
        """Return the direct file URL for requested_quality, or None if missing/unreachable."""
        file_url: str | None = next(
            (variant.get('file') for variant in video.get('qualities', []) if variant.get('name') == requested_quality),
            None,
        )
        if not file_url:
            return None
        host: str = urlsplit(file_url).hostname or ''
        # probe only when there is a DASH stream to fall back to - otherwise the direct link is the only chance
        has_adaptive: bool = bool((video.get('quality_adaptive') or {}).get('manifest'))
        if _FLAKY_DIRECT_HOST_RE.fullmatch(host) and has_adaptive and not self._probe_direct_host(file_url):
            return None
        return file_url

    def _probe_direct_host(self, file_url: str) -> bool:
        """Check that a direct file host answers (a 1-byte range request)."""
        try:
            resp: requests.Response = self.session.get(
                file_url, headers={'User-Agent': USER_AGENT, 'Range': 'bytes=0-0'},
                timeout=(2.5, 4.0), stream=True,
            )
            resp.close()
            return resp.status_code in (200, 206)
        except Exception:
            if self.debug:
                fflog_exc()
            return False

    def _normalize_title(self, txt: str) -> str:
        """Lowercase, remove stopwords and bracketed year."""
        if not txt:
            return ''
        txt = cleantitle.normalize(txt)
        txt = re.sub(r'[\(\[]\s*\d{4}\s*[\)\]]', '', txt)
        txt = re.sub(r'\bpl\b', '', txt, flags=re.I)
        txt = re.sub(r'[^0-9a-ząćęłńóśźż]+', ' ', txt.lower())
        txt = re.sub(
            r'\b([a-ząćęłńóśźż])\b(?: \b[a-ząćęłńóśźż]\b)+',
            lambda match: match.group(0).replace(' ', ''),
            txt,
        )
        return ' '.join(word for word in txt.split() if word and word not in TITLE_STOPWORDS)

    def _all_words_match(
        self,
        expected: str,
        candidate: str,
        *,
        rel_tol: float = 0.25,
        abs_tol_short: int = 1,
        abs_tol_long: int = 2,
        min_coverage: float = 0.40,
    ) -> bool:
        """Check that every expected word is in the candidate (typo-tolerant) and the candidate is covered enough."""
        exp_words: list[str] = self._normalize_title(expected).split()
        cand_words: list[str] = self._normalize_title(candidate).split()
        if not exp_words or not cand_words:
            return False

        # 1. every expected word must match (typo-tolerant)
        for exp_word in exp_words:
            if len(exp_word) <= 2:
                continue
            if not any(self._words_similar(exp_word, cand_word, rel_tol, abs_tol_short, abs_tol_long) for cand_word in cand_words):
                return False

        # 2. coverage - fraction of candidate words matched
        matched: int = sum(
            1
            for cand_word in cand_words
            if any(self._words_similar(exp_word, cand_word, rel_tol, abs_tol_short, abs_tol_long) for exp_word in exp_words)
        )
        return matched / len(cand_words) >= min_coverage

    def _words_similar(self, exp_word: str, cand_word: str, rel_tol: float, abs_tol_short: int, abs_tol_long: int) -> bool:
        """Compare two words by the Levenshtein distance (absolute and relative tolerance)."""
        dist: int = source_utils._levenshtein(exp_word, cand_word)
        if (len(exp_word) <= 4 and dist <= abs_tol_short) or (len(exp_word) > 4 and dist <= abs_tol_long):
            return True
        return dist / max(len(exp_word), len(cand_word)) <= rel_tol

    def _matches_episode_marker(self, cand_title: str, ep_no: str) -> bool:
        """Check if cand_title contains episode marker matching ep_no ('sNNeNN' format).

        Accepts: SnEn, NxN, 'odcinek N' / 'odc N' / 'episode N' / 'ep N',
        and '(N)' (only for season 1, to avoid matching standalone numbers).
        """
        parsed: re.Match[str] | None = re.match(r's(\d+)e(\d+)', ep_no, re.I)
        if not parsed:
            return ep_no in cand_title.lower().replace(' ', '')
        season: int = int(parsed.group(1))
        episode: int = int(parsed.group(2))
        title_lower: str = cand_title.lower()

        if re.search(rf'\bs0*{season}e0*{episode}\b', title_lower):
            return True
        if re.search(rf'\b0*{season}x0*{episode}\b', title_lower):
            return True
        if re.search(rf'\b(?:odcinek|odc|episode|ep)\s*\.?\s*0*{episode}\b', title_lower):
            return True
        # "(N)" - only for season 1 to avoid false positives from standalone numbers
        return season == 1 and bool(re.search(rf'\(\s*0*{episode}\s*\)', cand_title))

    def _strip_episode_part(self, text: str) -> str:
        """Strip earliest episode marker and everything after it.

        Used to isolate show-title portion from candidate (and search term) for
        title matching. Handles SnEn, NxN, 'odcinek N', '(N)'.
        """
        earliest: int | None = None
        for pattern in (EPISODE_RE, _NXM_EP_RE, _NAMED_EP_RE, _BARE_EP_RE):
            match: re.Match[str] | None = pattern.search(text)
            if match and (earliest is None or match.start() < earliest):
                earliest = match.start()
        return text[:earliest].strip() if earliest is not None else text

    @staticmethod
    def _sequel_numbers(normalized: str) -> set[int]:
        """Extract sequel numbers from a normalized title - both Arabic and Roman."""
        nums: set[int] = {int(number) for number in SEQUEL_REGEX.findall(normalized)}
        for match in _ROMAN_SEQUEL_RE.finditer(normalized):
            nums.add(source_utils.roman_to_int(match.group()))
        return nums

    def _check_email(self, email: str) -> bool:
        """Check that the e-mail is a registered account (an unclear answer lets the login go on)."""
        self.headers.update(self.headers_basic)
        resp: requests.Response = self.session.post(f'{BASE_LINK}/register/check-email', data={'email': email}, headers=self.headers)
        try:
            return bool(resp.json())
        except ValueError:
            fflog(f'email check error {resp.status_code}: {resp.text}')
            return True  # NOTE: allow login attempt to proceed

    def _api_get(self, url: str, **kwargs: Any) -> requests.Response:
        """GET an API URL with the account token (login on the first use, relogin on an auth error)."""
        kwargs.setdefault('headers', self.headers)
        kwargs['headers'] = dict(kwargs['headers'])

        # the store first (an expired token is not there), then a login
        if not self.token and self.email:
            if token := self.store.get(self._token_cache_key):
                self.token = token
            else:
                self.oauth(self.email, self.passwd)
        token: str | None = self.token
        if token:
            kwargs['headers']['Authorization'] = f'Bearer {token}'

        response: requests.Response = self.session.get(url, **kwargs)

        # relogin on an auth error
        if response.status_code in (400, 401, 403) and self.email and token:
            fflog(f'auth error {response.status_code}, attempting relogin')
            self.token = None
            self.store.delete(self._token_cache_key)
            if self.oauth(self.email, self.passwd) and self.token:
                kwargs['headers']['Authorization'] = f'Bearer {self.token}'
                response = self.session.get(url, **kwargs)
            else:
                fflog('relogin: failed')
        return response

    def _search(self, title: str, localtitle: str, year: int, aliases: list[SourceTitleAlias] | None = None) -> list[str]:
        """Search a movie by its title variants, return candidate video ids."""
        pl_title: str = cleantitle.normalize(cleantitle.getsearch(localtitle))
        en_title: str = cleantitle.normalize(cleantitle.getsearch(title))

        short_pl_title: str = ''
        if localtitle and ':' in localtitle:
            short_pl_title = cleantitle.normalize(cleantitle.getsearch(localtitle.split(':', 1)[0].strip()))

        short_en_title: str = ''
        if title and ':' in title:
            short_en_title = cleantitle.normalize(cleantitle.getsearch(title.split(':', 1)[0].strip()))

        titles_differ: bool = pl_title != en_title
        search_variants: list[str] = []

        # primary: Polish title with year
        if pl_title:
            search_variants.append(f'{pl_title} {year}')

        # short PL variant (title with ":")
        if short_pl_title:
            search_variants.append(f'{short_pl_title} {year}')

        # English variant with year
        if en_title and titles_differ:
            search_variants.append(f'{en_title} {year}')

        # short EN variant
        if short_en_title and short_en_title != short_pl_title:
            search_variants.append(f'{short_en_title} {year}')

        # Production-country original title (e.g. "Supercondriaque" for the French
        # "Superchondriac" / "Przychodzi facet do lekarza") - only when it differs
        # from PL and EN variants we already query.
        if aliases:
            original_title: str | None = next((entry.get('originalname') for entry in aliases if entry.get('originalname')), None)
            if original_title:
                original_clean: str = cleantitle.normalize(cleantitle.getsearch(original_title))
                if original_clean and original_clean not in (pl_title, en_title, short_pl_title, short_en_title):
                    search_variants.append(f'{original_clean} {year}')

        # Bare Polish title without the year token - some uploads obfuscate the
        # name or drop the year (e.g. "M4trix PL" for The Matrix) and surface only
        # on a plain title query. Year filtering still runs per candidate.
        if pl_title:
            search_variants.append(pl_title)

        return self._aggregate_candidates(search_variants, year)

    def _aggregate_candidates(self, variants: list[str], year: int, **search_kwargs: Any) -> list[str]:
        """Run each unique (case-insensitive) variant and collect deduplicated ids."""
        seen_variants: set[str] = set()
        seen_ids: set[str] = set()
        all_results: list[str] = []
        for variant in variants:
            if variant.lower() in seen_variants:
                continue
            seen_variants.add(variant.lower())
            for video_id in self._search_single_term(variant, year, **search_kwargs):
                if video_id not in seen_ids:
                    seen_ids.add(video_id)
                    all_results.append(video_id)

        if all_results:
            fflog(f'total {len(all_results)} unique candidates')
        else:
            fflog('no match')
        return all_results

    def _fetch_search(self, query: str, *, episode: bool, limit: int) -> list[dict[str, Any]]:
        """Fetch one page of API search results."""
        params: dict[str, Any] = {
            'query': query,
            'limit': limit,
            'page': 1,
            'sort': 'best',
        }
        # 'medium' means >= ~20 min, which drops sitcom/cartoon episodes (e.g. 19:41);
        # 'short' is <= 5 min and nothing covers 5-20 min, so episodes go unfiltered
        # (sources() rejects wrong lengths via _compare_duration anyway)
        if not episode:
            params['duration'] = 'medium'
        return self._api_get(SEARCH_LINK, params=params).json().get('data') or []

    def _year_ok(self, cand_title: str, year: int) -> bool:
        """Check years in a candidate title (movie: year +-1; episode: show start-1 .. episode air year+1)."""
        if not self._is_episode or not self._episode_year:
            return source_utils.year_matches(cand_title, year)
        if not year:
            return True
        found_years: list[int] = [int(found) for found in source_utils.RE_YEAR.findall(cand_title)]
        if not found_years:
            return True
        return any(year - 1 <= found <= self._episode_year + 1 for found in found_years)

    def _search_single_term(
        self,
        term: str,
        year: int,
        ep_no: str | None = None,
        cc_titles: list[str] | None = None,
        franchise_patterns: dict[str, list[str]] | None = None,
    ) -> list[str]:
        """Run one search query and return the ids of the matching candidates."""
        fflog(f"query: '{term}'")
        q_term: str = term.replace("'", '').replace(':', '').replace('-', ' ').lower()
        # bare title queries (no year, no episode marker) are broad - fetch more results
        is_bare: bool = str(year) not in term and not EPISODE_RE.search(term)
        search_items: list[dict[str, Any]] = self._fetch_search(q_term, episode=bool(ep_no), limit=SEARCH_BARE_LIMIT if is_bare else SEARCH_LIMIT)

        # strip year - checked separately
        term_for_matching: str = term.replace(str(year), '').strip()
        # sequel numbers of the search term (the same for every candidate)
        exp_seq: set[int] = self._sequel_numbers(self._normalize_title(term_for_matching))

        results: list[str] = []
        fflog(f'search: {len(search_items)} results')
        for item in search_items:
            cand_title: str = item['title']

            # episode marker check (multiple formats: SnEn, NxN, "odcinek N", "(N)" for S1)
            if ep_no and not self._matches_episode_marker(cand_title, ep_no):
                if self.debug:
                    fflog(f"skip (episode mismatch): '{cand_title}' (expected: {ep_no})")
                continue

            excluded_word: str | None = next((word for word in TITLE_EXCLUDE_WORDS if word in cand_title.lower()), None)
            if excluded_word:
                if self.debug:
                    fflog(f"skip (excluded keyword): '{cand_title}' (word: {excluded_word})")
                continue

            # Reject candidates that contain a sequel number not present in the search term
            # e.g. searching "Krzyk" must not match "Krzyk 3", searching "Krzyk 2" must not match "Krzyk 3"
            cand_for_seq: str = cand_title
            if ep_no:
                # strip episode references so "Odcinek 2" / "S01E02" isn't mistaken for a sequel number
                cand_for_seq = EPISODE_RE.sub(' ', cand_for_seq)
                cand_for_seq = re.sub(r'\b(?:odcinek|odc|episode|ep|sezon|season)\s*\.?\s*\d+\b', ' ', cand_for_seq, flags=re.I)
                # strip "(N)" episode markers (cda non-standard) so they aren't read as sequels
                cand_for_seq = _BARE_EP_RE.sub(' ', cand_for_seq)
            cand_seq: set[int] = self._sequel_numbers(self._normalize_title(cand_for_seq))
            if cand_seq - exp_seq:
                if self.debug:
                    fflog(f"skip (sequel mismatch): '{cand_title}' (expected {exp_seq or 'none'}, got {cand_seq})")
                continue

            # country variant check (e.g. Biuro vs Biuro US vs Biuro UK)
            if ep_no and cc_titles:
                cand_norm_all: list[str] = re.sub(r'[^0-9a-z]+', ' ', cand_title.lower()).split()
                if conflict_cc := source_utils.detect_country_variant_conflict(cand_norm_all, cc_titles):
                    if self.debug:
                        fflog(f"skip (country variant {conflict_cc}): '{cand_title}'")
                    continue

            # For episode searches, strip the episode marker from both sides so
            # subtitle/quality tags after the marker don't dilute coverage
            term_for_match: str = self._strip_episode_part(term_for_matching) if ep_no else term_for_matching
            title_for_match: str = self._strip_episode_part(cand_title) if ep_no else cand_title

            franchise_match: bool = False
            if not self._all_words_match(term_for_match, title_for_match):
                # if direct match fails, try franchise patterns
                franchise_match = bool(franchise_patterns) and any(
                    re.search(pattern, cand_title, re.I)
                    for pattern_list in (franchise_patterns or {}).values()
                    for pattern in pattern_list
                )
                if not franchise_match:
                    if self.debug:
                        fflog(f"skip (title mismatch): '{cand_title}' (searched: '{term_for_matching}')")
                    continue

            # When search term is <=2 content words, reject candidates with extra
            # non-qualifier words in the show title portion - e.g. "Krzyk" must not match "Krzyk gory"
            exp_norm: list[str] = self._normalize_title(term_for_matching).split()
            content_words: list[str] = [
                word for word in exp_norm
                if len(word) > 3
                and word not in _TITLE_QUALIFIERS
                and not re.fullmatch(r's\d{1,2}e\d{1,4}', word, re.I)
            ]
            if not franchise_match and len(content_words) <= 2:
                # isolate the show-title part by stripping the earliest episode marker
                show_title_part: str = self._strip_episode_part(cand_title) if ep_no else cand_title
                cand_norm: list[str] = self._normalize_title(show_title_part).split()
                extra: list[str] = [
                    word for word in cand_norm
                    if len(word) > 3
                    and word not in _TITLE_QUALIFIERS
                    and not re.match(r'^(?:19|20)\d{2}$', word)
                    and not any(self._words_similar(exp_word, word, 0.25, 1, 2) for exp_word in exp_norm if len(exp_word) > 3)
                ]
                # Allow extra words that are valid 2-letter country codes -
                # they passed detect_country_variant_conflict above so they're expected.
                if ep_no:
                    extra = [word for word in extra if word not in source_utils.FRANCHISE_CC]
                if extra:
                    if self.debug:
                        fflog(f"skip (extra words in title): '{cand_title}' (extra: {extra})")
                    continue

            if not self._year_ok(cand_title, int(year)):
                if self.debug:
                    fflog(f"skip (year mismatch): '{cand_title}' (expected: {year})")
                continue

            if self.debug:
                fflog(f"accept: '{cand_title}'")
            results.append(item['id'])

        fflog(f"found {len(results)} candidates for '{term}'")
        return results

    def _search_episode(self, title: str, localtitle: str, year: int, ep_no: str, aliases: list[SourceTitleAlias]) -> list[str]:
        """Search an episode by its show title variants, return candidate video ids."""
        fflog(f"searching episode: '{localtitle}' {ep_no} ({year})")
        pl_title: str = cleantitle.normalize(cleantitle.getsearch(localtitle))
        en_title: str = cleantitle.normalize(cleantitle.getsearch(title))
        titles_differ: bool = pl_title != en_title

        search_variants: list[str] = [f'{pl_title} {ep_no}']

        # EN variant only if EN<>PL
        if en_title and titles_differ:
            search_variants.append(f'{en_title} {ep_no}')

        # aliases, at most 3 extra variants
        prep_aliases: list[str] = source_utils.prepare_alias_search_list(aliases, str(year)) if aliases else []
        for alias in prep_aliases[:3]:
            alias_clean: str = cleantitle.normalize(cleantitle.getsearch(alias))
            search_variants.append(f'{alias_clean} {ep_no}')

        # short variant (often works better on CDA for some shows like JAG)
        if len(en_title) <= 5 or len(pl_title) <= 5:
            short_title: str = en_title if len(en_title) <= len(pl_title) else pl_title
            search_variants.append(f'{short_title} {ep_no}')

        # Fallback: bare title - some series use non-standard episode markers
        # (e.g. "Cuda (1) - subtitle") that won't appear in s##e## search results
        if pl_title:
            search_variants.append(pl_title)
        if en_title and titles_differ:
            search_variants.append(en_title)

        # titles for CC conflict detection and franchise matching
        all_titles: list[str] = [title, localtitle, *prep_aliases]
        franchise_names: dict[str, list[str]] = {name: list(patterns) for name, patterns in const.sources.franchise_names.items()}
        franchise_patterns: dict[str, list[str]] = source_utils.build_relevant_franchises(
            all_titles, franchise_names, const.sources.franchise_names_sep
        )

        return self._aggregate_candidates(search_variants, year, ep_no=ep_no, cc_titles=all_titles, franchise_patterns=franchise_patterns)

    def _compare_duration(self, ffduration: int, duration: int | None) -> bool:
        """Check the video length against the item length (unknown length passes)."""
        duration = duration or 0
        if not ffduration or not duration:
            return True
        epsilon: float = const.sources.cda.episode_duration_epsilon if self._is_episode else const.sources.cda.duration_epsilon
        return abs(ffduration - duration) <= ffduration * epsilon

    def _get_highest_quality_direct(self, video: dict[str, Any]) -> str:
        """Return highest available quality based on video dimensions and variants."""
        height: int = video.get('height', 0)
        width: int = video.get('width', 0)
        available_qualities: set[str] = {variant['name'] for variant in video.get('qualities', []) if variant.get('name')}

        if self.debug:
            fflog(f'video dimensions: {width}x{height}, available: {available_qualities}')
        if height >= 1080 or width >= 1920:
            if '1080p' in available_qualities:
                return '1080p'
        elif height >= 720 or width >= 1280:
            if '720p' in available_qualities:
                return '720p'

        for quality in ('1080p', '720p', '480p', '360p'):
            if quality in available_qualities:
                if self.debug:
                    fflog(f'selected quality by priority: {quality}')
                return quality

        fallback: str = video.get('quality', '480p')
        if self.debug:
            fflog(f'using fallback quality: {fallback}')
        return fallback
