# -*- coding: utf-8 -*-
"""
FanFilm - źródło: shinden
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations

from datetime import datetime
from html import unescape
from urllib.parse import quote_plus
import json
from typing import List, Optional, Tuple, TYPE_CHECKING
import re

from lib.ff import requests, cleantitle, client, control, source_utils
from lib.ff.source_utils import DEFAULT_UA, ShowData, show_data_asdict, ShowDataDict, get_original_title
from lib.ff.logs import fflog, fflog_exc
from lib.ff.threads import xsleep
from lib.kolang import L
from lib.ff.item import FFItem
from lib.api import kitsu as kitsu_api
from lib.sources.natives import LOGIN, ProviderSetting
from lib.sources.natives import provider_value
from const import const
if TYPE_CHECKING:
    from typing import Collection, ClassVar
    from lib.defs import MediaCategory
    from lib.sources import SourceItem, SourceTitleAlias
    from lib.ff.db.sources import ProviderStore


HEADERS = {
    'User-Agent': DEFAULT_UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    # Required: without "pl" in Accept-Language the site hides all fansub players (only legal link-outs remain)
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
}

# Link-outs to paid streaming services, not playable embeds
EXTERNAL_PLAYERS: set[str] = {'crunchyroll', 'netflix'}

LANG_NAMES: dict[str, str] = {'pl': 'Polskie', 'en': 'Angielskie', 'jp': 'Japońskie', 'de': 'Niemieckie'}

EPISODES_PER_PAGE: int = 100

# The site's "remember me" (autologin) cookie lasts 14 days
SESSION_TTL: int = 7 * 24 * 3600


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'Shinden'
    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = LOGIN
    ffitem: FFItem
    store: ProviderStore

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']
    CATEGORIES: ClassVar[Collection[MediaCategory]] = {'anime'}

    def __init__(self):
        self.domains = ['shinden.pl']
        self.base_link = 'https://shinden.pl'
        self.search_link = self.base_link + '/series?search=%s'
        self.user_name = provider_value('shinden', 'username')
        self.user_pass = provider_value('shinden', 'password')
        self.session = requests.Session()  # keeps login and anti-bot (_rnd) cookies
        self.logged_in = False

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[Tuple[str, str]]:
        """Search for anime movie"""
        if self.ffitem.anime_info is None:
            return None

        movie_info = self.ffitem.anime_info.movie
        if movie_info:
            titles = (movie_info['title'], title, localtitle)
            fflog(f"searching (kitsu): {movie_info['title']!r}")
        else:
            titles = (title, localtitle)

        premiered = self.ffitem.vtag.getPremieredAsW3C()
        return self._search(titles, None, None, None, year, premiered, aliases)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict:
        """Returns show data for later use in episode()"""
        tmdb = self.ffitem.show_item.tmdb_id
        # Store tmdb — needed in episode() for Kitsu lookup
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, int(year), str(tmdb) if tmdb else None))

    def episode(self, url: ShowDataDict, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[Tuple[str, str]]:
        """Search for anime series episode"""
        if self.ffitem.show_item is None or self.ffitem.anime_info is None:
            return None

        tmdb = self.ffitem.show_item.tmdb_id
        premiered = self.ffitem.vtag.getFirstAiredAsW3C()
        data = ShowData(**url)
        # tmdb from ShowData (from tvshow) or fetched directly from ffitem
        tmdb_id = data.tmdb or (str(tmdb) if tmdb else None)
        return self._search((data.title, data.local_title), season, episode, tmdb_id, data.year, premiered, data.aliases)

    def sources(self, url: Optional[Tuple[str, str]], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        """Fetch playback sources for a given URL"""
        if not url:
            return []

        episode_title = ''
        if isinstance(url, tuple):
            url, episode_title = url

        try:
            content = self.session.get(url, headers=HEADERS)
            if not content:
                return []

            # Player list is embedded as JSON; the hidden "pulapka" id is a honeypot — never request it
            players_json = re.search(r'id="episode-players-data">(.*?)</script>', content.text, re.S)
            auth = re.search(r"""_Storage\.basic\s*=\s*'([^']+)'""", content.text)
            if not players_json or not auth:
                fflog('no players data or auth token on episode page')
                return []
            players_data = json.loads(players_json.group(1))
            players = players_data.get('players') or []
            if self.logged_in and players_data.get('zalogowany') is False:
                # Stored session expired on the site side — log in again next time
                fflog('stored session no longer logged in, dropping it')
                self.store.delete('session')

            sources = []
            for player in players:
                try:
                    src = self._parse_player(player, auth.group(1), episode_title)
                    if src:
                        sources.append(src)
                except Exception:
                    fflog_exc()

            fflog(f'sources: {len(sources)}')
            return sources
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url: str) -> Optional[str]:
        """Resolve API URL to final video link"""
        if url.startswith('//'):
            url = 'https:' + url

        # player_load sets the session cookie player_show needs and returns the wait time in seconds
        session = requests.Session()
        headers = {**HEADERS, 'Referer': self.base_link + '/'}
        response = session.get(url, headers=headers)
        if response.status_code != 200:
            fflog(f'player_load failed: {response.status_code} {response.text[:200]!r}')
            return None
        wait = response.text.strip()
        xsleep(int(wait) if wait.isdigit() else 5)

        video_url = url.replace('player_load', 'player_show') + '&width=800&height=-1'
        page = session.get(video_url, headers=headers).text
        # regex, not parseDOM: it misses src after a valueless attribute (e.g. Dailymotion's "allowfullscreen")
        iframes = re.findall(r'<iframe\b[^>]*?\ssrc="([^"]+)"', page)
        if not iframes:
            fflog(f'no iframe in player_show: {page[:200]!r}')
            return None
        video = unescape(iframes[0])

        if video.startswith('//'):
            video = 'https:' + video

        return str(video)

    # ── helpers ────────────────────────────────────────────────────────────

    def login(self) -> bool:
        """Login to shinden.pl"""
        if self.logged_in:
            return True

        if not self.user_name or not self.user_pass:
            return False

        # Reuse the stored session — a new instance is created for every search,
        # logging in each time could get the account blocked
        cached = self.store.get('session')
        if cached and cached.get('user') == self.user_name:
            self.session.cookies.update(cached.get('cookies') or {})
            self.logged_in = True
            fflog('login: session restored from the store')
            return True
        if self.store.login_refused(self.user_name, self.user_pass):
            fflog('login: failed lately, not tried again with the same credentials')
            return False

        try:
            # Plain no-JS login form (the main one is a JS widget with Turnstile)
            login_url = self.base_link + '/login/haslo'
            form_page = self.session.get(login_url + '?return=%2F', headers=HEADERS)
            csrf = re.search(r'name="csrf" value="([^"]+)"', form_page.text)
            if not csrf:
                fflog('login: no csrf token on login page')
                return False

            data = {
                'csrf': csrf.group(1),
                'return': '/',
                'username': self.user_name,
                'password': self.user_pass,
                'remember': '1',
            }
            headers = {**HEADERS, 'Origin': self.base_link, 'Referer': login_url + '?return=%2F'}
            self.session.post(login_url, headers=headers, data=data)

            if self.session.cookies.get('sh_logged'):
                self.logged_in = True
                self.store.set('session', {'user': self.user_name, 'cookies': self.session.cookies.get_dict()}, ttl=SESSION_TTL)
                fflog('login: ok, session stored')
                return True

            fflog('login: failed — no sh_logged cookie')
            self.store.refuse_login(self.user_name, self.user_pass, ttl=const.sources.providers.login_retry)
            control.groupedInfoDialog('shinden_login_failed', L(32849, 'Login failed'), heading='Shinden', icon='ERROR')
            return False

        except Exception:
            fflog_exc()
            return False

    def _search(self, titles, season: Optional[str], episode: Optional[str], tmdb: Optional[str], year, premiered, aliases: list[SourceTitleAlias] | None) -> Optional[Tuple[str, str]]:
        """Unified search for movies and episodes"""
        if not titles:
            return None

        headers = HEADERS.copy()

        is_episode = season is not None and episode is not None

        # ── KITSU PATH (series) ──────────────────────────────────────────────
        if is_episode and tmdb:
            assert season is not None
            assert episode is not None
            return self._search_with_kitsu(titles, season, episode, tmdb, premiered, aliases, headers, year)

        # ── MOVIES ───────────────────────────────────────────────────────────
        if not is_episode:
            try:
                results = self._get_search_results(titles, headers, aliases, is_episode)
            except Exception:
                fflog_exc()
                return None

            if not results:
                return None

            alias_cleans = self._build_alias_cleans(titles, aliases)

            self.login()

            air_date = None
            if premiered:
                try:
                    air_date = datetime.strptime(str(premiered), '%Y-%m-%d').date()
                except (ValueError, TypeError):
                    pass

            for link, title, raw_html in results:
                normalized = cleantitle.normalize(title)
                if any(all(word in normalized for word in mt.split()) for mt in alias_cleans):
                    title_clean = re.sub(r'<[^>]+>', '', title).strip()
                    fflog(f'movie: found {title_clean!r}, looking for ep 1')
                    return self._find_episode_in_series(link, 1, air_date)

        return None

    def _search_with_kitsu(self, titles, season: str, episode: str, tmdb: str, premiered, aliases: list[SourceTitleAlias] | None,
                           headers: dict[str, str], year) -> Optional[Tuple[str, str]]:
        """
        Fetches cour structure from Kitsu, maps abs_ep to local number,
        then searches shinden by en_jp title from Kitsu.
        """
        if self.ffitem.anime_info is None or not (cours := self.ffitem.anime_info.cours):
            fflog(f'shinden/kitsu: no data for tmdb={tmdb}')
            return None

        cour, local_ep = kitsu_api.resolve_cour(cours, self.ffitem)
        if not cour:
            fflog(f'shinden/kitsu: cour not found for tmdb={tmdb} S{season}E{episode}')
            return None

        fflog(f'shinden/kitsu: cour="{cour["title"]}" local_ep={local_ep}')

        # Search shinden ONLY by Kitsu title (en_jp)
        kitsu_title = cour['title']
        kitsu_norm = self._normalize_title(kitsu_title)
        fflog(f'kitsu: searching series {kitsu_title!r} (norm: {kitsu_norm!r})')

        try:
            results = self._get_search_results([kitsu_title], headers, aliases, is_episode=True)
        except Exception:
            fflog_exc()
            return None

        if not results:
            return None

        # Build list of titles to compare (Kitsu + TMDB + Aliases)
        all_alias_cleans = {kitsu_norm}
        # A sequel cour is matched by its Kitsu title only — show-level titles/aliases point at season 1
        is_sequel = cour['kitsu_id'] != cours[0]['kitsu_id']
        for t in [] if is_sequel else list(titles) + [a.get('title') for a in aliases or [] if a.get('title')]:
            if t:
                all_alias_cleans.add(self._normalize_title(t))

        # Find best match
        candidates = []
        kitsu_words = set(kitsu_norm.split())

        for link, title, raw_html in results:
            title_clean = re.sub(r'<[^>]+>', '', title).strip()
            title_norm = self._normalize_title(title_clean)

            # Extract year (separate field in search results, fallback: "(YYYY)" in title)
            year_match = re.search(r'sh-tagi-rok">(\d{4})', raw_html) or re.search(r'\((\d{4})\)', title_clean)
            res_year = year_match.group(1) if year_match else None

            # Skip if year does not match (string comparison)
            if res_year and year and res_year != str(year):
                continue

            # 1. PRIORITY: Exact match against Kitsu title (not aliases — too broad)
            if title_norm == kitsu_norm:
                fflog(f'kitsu: series matched (exact): {title_clean!r}')
                return self._find_local_episode_in_series([(link, title_clean)], local_ep, premiered)

            title_words = set(title_norm.split())
            if res_year and res_year in title_words:
                title_words.remove(res_year)

            for mt in all_alias_cleans:
                mt_words = set(mt.split())
                if not mt_words:
                    continue
                if mt_words.issubset(title_words) or (not is_sequel and title_words.issubset(mt_words)):
                    # How many kitsu_norm words overlap with Shinden — more = better match
                    overlap = len(kitsu_words & title_words)
                    # Bonus when Shinden title year matches series year (e.g. "JoJo (2012)" vs "(TV)")
                    year_bonus = 1 if (res_year and year and res_year == str(year)) else 0
                    candidates.append((link, title_clean, len(title_words), overlap, year_bonus))
                    break

        if candidates:
            # Sort: year match > overlap > shorter title
            candidates.sort(key=lambda x: (-x[4], -x[3], x[2]))
            best_link, best_title, _, _, _ = candidates[0]
            fflog(f'kitsu: series matched (subset): {best_title!r}')
            return self._find_local_episode_in_series([(best_link, best_title)], local_ep, premiered)

        fflog(f'kitsu: no match for {kitsu_title!r}')
        # Log what was in results
        for link, title, raw_html in results:
            fflog(f'  result: "{self._normalize_title(title)}" (orig: {re.sub(r"<[^>]+>", "", title)})')
        return None

    def _find_local_episode_in_series(self, matching_series: List[Tuple[str, str]], local_ep: int, premiered) -> Optional[Tuple[str, str]]:
        """
        Searches for a specific local episode number within a series.
        Does not do cumulative mapping — local_ep is already resolved by Kitsu.
        """
        air_date = None
        if premiered:
            try:
                air_date = datetime.strptime(premiered, '%Y-%m-%d').date()
            except Exception:
                pass

        self.login()

        skip_keywords = ['official pv', 'trailer', 'zwiastun', 'preview', 'promo']

        for link, title in matching_series:
            title_clean = re.sub(r'<[^>]+>', '', title).strip()
            title_lower = title_clean.lower()
            if any(kw in title_lower for kw in skip_keywords):
                fflog(f'kitsu: skip (keyword): {title_clean!r}')
                continue

            fflog(f'kitsu: searching ep {local_ep} in {title_clean!r} -> {link}')
            try:
                result = self._find_episode_in_series(link, local_ep, air_date)
                if result:
                    fflog(f'shinden/kitsu: found ep {local_ep} in "{title_clean}" → {result[0]}')
                    return result
                else:
                    fflog(f'shinden/kitsu: ep {local_ep} not found in "{title_clean}"')
            except Exception:
                fflog_exc()
                continue

        return None

    @staticmethod
    def _normalize_title(title: str) -> str:
        """Normalize title: strip HTML, macrons→double vowels, punctuation, whitespace, lowercase."""
        title = re.sub(r'<[^>]+>', '', title)       # strip HTML tags
        return kitsu_api.normalize_series_title(title)

    def _build_alias_cleans(self, titles, aliases: list[SourceTitleAlias] | None) -> set[str]:
        """Builds a set of normalized titles for matching against search results."""
        return cleantitle.normalize_titles(titles=titles, aliases=aliases)

    def _get_search_results(self, titles, headers: dict[str, str], aliases, is_episode: bool) -> List[Tuple[str, str, str]]:
        """Fetch search results"""
        results = []
        search_titles = self._prepare_search_titles(titles, aliases)

        for title in search_titles:
            if isinstance(title, str):
                normalized = cleantitle.normalize(title).replace(' ', '+').replace('shippuden', 'shippuuden')
                filters = '&series_type[0]=TV&series_type[1]=ONA&series_type[2]=OVA' if is_episode else '&series_type[0]=Movie'
                filters += '&series_status[0]=Currently+Airing&series_status[1]=Finished+Airing'
                url = self.search_link % normalized + quote_plus(filters, '&=')
            else:
                url = title[0]

            if isinstance(title, str):
                fflog(f'query: {normalized!r}')
            response = self.session.get(url, headers=headers)
            if not response:
                continue

            items = client.parseDOM(response.text, 'li', attrs={'class': 'sh-tagi-wynik'})
            found = 0
            for item in items:
                links = client.parseDOM(item, 'a', ret='href')
                names = client.parseDOM(item, 'span', attrs={'class': 'sh-tagi-nazwa'})
                if links and names and ('/series/' in links[0] or '/titles/' in links[0]):
                    results.append((links[0], unescape(names[0]).strip(), item))
                    found += 1
            if isinstance(title, str):
                fflog(f'search: {found} results')

            # Pagination (first extra page)
            next_page = re.search(r'<a href="([^"]+)" rel="next"', response.text)
            if next_page and len(search_titles) == 1:
                next_url = self.base_link + unescape(next_page.group(1))
                results += self._get_search_results([(next_url,)], headers, '', is_episode)

        return results

    def _prepare_search_titles(self, titles, aliases: list[SourceTitleAlias] | None) -> List[str]:
        """Prepares list of titles for searching"""
        if not aliases:
            return [titles[0]] if titles else []

        jp_titles = [a['title'] for a in aliases if a.get('country') == 'jp']
        jp_title = jp_titles[0] if jp_titles else None
        en_title = titles[0] if titles else None
        original = get_original_title(aliases)

        combined = [jp_title, en_title, original]
        combined = [t.lower() for t in combined if t]
        combined = list(dict.fromkeys(combined))

        return combined

    def _get_episode_rows(self, series_url: str, local_episode_num: int) -> list[tuple[int, str | None, str, str]]:
        """Fetch the episode-list page holding the given episode; rows are (number, url or None, title, YYYY-MM-DD)"""
        def fetch(page: int) -> str:
            url = f'{self.base_link}{series_url}/episodes?na_stronie={EPISODES_PER_PAGE}'
            if page > 1:
                url += f'&strona={page}'
            return self.session.get(url, headers=HEADERS).text

        html = fetch(1)
        # List is sorted newest-first, EPISODES_PER_PAGE per page
        count_match = re.search(r'ep-list__count">(\d+)', html)
        count = int(count_match.group(1)) if count_match else 0
        if count > EPISODES_PER_PAGE and local_episode_num <= count:
            page = (count - local_episode_num) // EPISODES_PER_PAGE + 1
            if page > 1:
                html = fetch(page)

        rows: list[tuple[int, str | None, str, str]] = []
        for row in re.findall(r'<li class="ep-row[" ].*?</li>', html, re.S):
            number = re.search(r'ep-row__no">\s*(\d+)', row)
            if not number:
                continue
            # Rows without players have no link (<span class="ep-row__link">)
            link = re.search(r'<a class="ep-row__link" href="([^"]+)"', row)
            title = re.search(r'ep-row__title">([^<]*)', row)
            date = re.search(r'datetime="(\d{4}-\d{2}-\d{2})"', row)
            rows.append((int(number.group(1)),
                         self.base_link + link.group(1) if link else None,
                         unescape(title.group(1)).strip() if title else '',
                         date.group(1) if date else ''))
        return rows

    def _find_episode_in_series(self, series_url: str, local_episode_num: int, air_date) -> tuple[str, str] | None:
        """Find a specific local episode within a given series"""
        try:
            episode_rows = self._get_episode_rows(series_url, local_episode_num)
            if not episode_rows:
                fflog(f'no episodes in {series_url}')
                return None

            fflog(f'{len(episode_rows)} episodes, searching ep {local_episode_num}')

            def parse_date(date_str: str):
                try:
                    return datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else None
                except (ValueError, TypeError):
                    return None

            # Date gap still explained by a broadcast hiatus, not a wrong cour/local-ep match.
            _MAX_HIATUS_DAYS = 21

            # Direct match by episode number (with ±1 tolerance). Trust an exact ep_num hit
            # even on a hiatus-sized date mismatch; only defer to date-fallback below when
            # the gap is too large to be a hiatus (likely wrong number match).
            suspicious_candidate: tuple[str, str] | None = None
            for offset in [0, 1, -1]:
                target_num = local_episode_num + offset
                for ep_num, ep_url, ep_title, ep_date_str in episode_rows:
                    if ep_num != target_num:
                        continue
                    if not ep_url:
                        if offset == 0:
                            ep_date = parse_date(ep_date_str)
                            # Exact, date-consistent hit without players — don't fall back to a neighbour episode
                            if not air_date or not ep_date or abs((ep_date - air_date).days) <= _MAX_HIATUS_DAYS:
                                fflog(f'ep {ep_num} found, but it has no players')
                                return None
                        continue
                    match = (ep_url, ep_title or f'Odcinek {ep_num}')
                    if offset == 0 and air_date:
                        ep_date = parse_date(ep_date_str)
                        if ep_date and ep_date != air_date:
                            gap = abs((ep_date - air_date).days)
                            if gap > _MAX_HIATUS_DAYS:
                                fflog(
                                    f'ep {ep_num} found by number, but date {ep_date} != {air_date} '
                                    f'(gap={gap}d) — too large for a hiatus, trying date-fallback first')
                                suspicious_candidate = match
                                break
                            fflog(
                                f'ep {ep_num} found by number, date {ep_date} != {air_date} '
                                f'(gap={gap}d, hiatus?) — keeping number match')
                    if suspicious_candidate is None:
                        return match
                if suspicious_candidate is not None:
                    break

            # Fallback: match by air date
            if air_date:
                for ep_num, ep_url, ep_title, ep_date_str in episode_rows:
                    if ep_url and parse_date(ep_date_str) == air_date:
                        return (ep_url, ep_title or f'Odcinek {ep_num}')

            if suspicious_candidate is not None:
                fflog(f'date-fallback found nothing better — using suspicious number match {suspicious_candidate}')
                return suspicious_candidate

            return None

        except Exception:
            fflog_exc()
            return None

    def _parse_player(self, player: dict, auth: str, episode_title: str = '') -> SourceItem | None:
        """Build a source from one entry of the episode-players-data JSON"""
        name: str = player.get('player') or ''
        online_id = player.get('online_id')
        if not name or not online_id or name.lower() in EXTERNAL_PLAYERS:
            return None

        host = 'VIDOZA' if 'vidoza' in name.lower() else name
        res = player.get('res')
        quality = source_utils.check_sd_url(f'{res}p' if res else '')

        audio: str = player.get('audio') or ''
        sub: str = player.get('sub') or ''
        is_polish = audio == 'pl'
        language = 'pl' if is_polish else ''

        if is_polish:
            info = 'Polskie Audio'
        elif sub:
            # 'ipl' = machine-translated Polish subtitles
            info = f"{LANG_NAMES.get('pl' if sub == 'ipl' else sub, sub.upper())} Napisy"
            if sub == 'ipl' or player.get('machine'):
                info += ' (maszynowe)'
        else:
            info = ''

        video_link = f"{self.base_link}/xhr/{online_id}/player_load?auth={quote_plus(auth)}"
        filename = episode_title if episode_title else ''

        return {
            'source': host,
            'quality': quality,
            'language': language,
            'url': video_link,
            'info': info,
            'filename': filename,
            'direct': False,
            'debridonly': False,
            'premium': False,
        }
