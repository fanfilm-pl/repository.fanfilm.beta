# -*- coding: utf-8 -*-
"""
FanFilm - source: Streamhub (streamhub.m-dev.pl)

Dystrybuowane na licencji MIT <https://mit-license.org>

Streamhub publishes its whole library (made for its CloudStream plugin) as
static JSON - no search, no session, no scraping:

    <base>/search_catalog.json  {"list": [{"id", "type": movie|tv, "name", "year", ...}]}  ~17k titles, ~2 MB
    <base>/hosts.json           {"hosts": [{"i": 4, "t": "https://voe.sx/e/{hashid}"}, ...]}
    <base>/data/<id>.json       movie: {"sources": [{"i", "h", "l"}]}
                                tv:    {"seasons": [{"number", "episodes": [{"number", "sources": [...]}]}]}

"name" is the TMDB English title, "l" the audio/subtitle language ("pl" or
"en", no lektor/napisy split), "i" the host id, "h" the file id on that host.
The data files answer 403 to a non-browser User-Agent.

The catalog is reduced to a (type, title, year) -> id index kept in the
provider store for a few hours.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any, ClassVar, TYPE_CHECKING
from urllib.parse import urlencode, parse_qs, urlparse

from cdefs import HOUR, DAY
from lib.ff import requests
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.logs import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.ff.db.sources import ProviderStore
    from lib.sources import SourceItem, SourceTitleAlias

_BASE: str = 'https://streamhub.m-dev.pl/storage/github'
_HEADERS: dict[str, str] = {'User-Agent': DEFAULT_UA, 'Accept': 'application/json'}
_TIMEOUT: int = 15
_INDEX_KEY: str = 'index'
_INDEX_AGE: int = 6 * HOUR
_HOSTS_KEY: str = 'hosts'
_HOSTS_AGE: int = DAY

# byse.sx / strmup.to: scam-redirect hosts; youtube / dailymotion: trailers
_SKIPPED_HOSTS: tuple[str, ...] = ('byse.', 'strmup.', 'youtube.', 'dailymotion.')

_session: requests.Session = requests.Session()
_session.headers.update(_HEADERS)


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    PREMIUM: ClassVar[bool] = False
    LABEL: ClassVar[str] = 'Streamhub'
    priority: ClassVar[int] = 1
    language: ClassVar[list[str]] = ['pl']

    ffitem: FFItem
    store: ProviderStore

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str,
              aliases: list[SourceTitleAlias], year: str) -> str | None:
        title_id = self._find('movie', [title, localtitle, *(alias['title'] for alias in aliases)], year)
        return urlencode({'id': title_id}) if title_id else None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: list[SourceTitleAlias], year: str) -> str | None:
        title_id = self._find('tv', [tvshowtitle, localtvshowtitle, *(alias['title'] for alias in aliases)], year)
        return urlencode({'id': title_id}) if title_id else None

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> str | None:
        if not url:
            return None
        return f'{url}&s={int(season)}&e={int(episode)}'

    def sources(self, url: str | None, hostDict: list[str],
                hostprDict: list[str]) -> list[SourceItem]:
        result: list[SourceItem] = []
        params = {key: values[0] for key, values in parse_qs(url or '').items()}
        if not params.get('id'):
            return result
        try:
            resp = _session.get(f"{_BASE}/data/{params['id']}.json", timeout=_TIMEOUT)
            if resp.status_code != 200:
                fflog(f"data {params['id']}: HTTP {resp.status_code}")
                return result
            data: dict = resp.json()
        except Exception:
            fflog_exc()
            return result

        if params.get('s'):
            raw_sources = _episode_sources(data, int(params['s']), int(params.get('e', 0)))
        else:
            raw_sources = data.get('sources') or []
        hosts = self._hosts()

        seen: set[str] = set()
        for raw in raw_sources:
            link = _link(hosts, raw)
            if not link or link in seen:
                continue
            seen.add(link)
            result.append({
                'hosting': urlparse(link).netloc.split('.')[-2],
                'url': link,
                'quality': 'HD',  # not given by the catalog
                'language': 'pl' if raw.get('l') == 'pl' else 'en',
                'info': '',
                'direct': False,
                'debridonly': False,
            })

        fflog(f"sources: {len(result)} (raw {len(raw_sources)}) for id={params['id']}")
        return result

    def resolve(self, url: str) -> str | None:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _store(self) -> ProviderStore | None:
        return getattr(self, 'store', None)  # not set when run from the command line

    def _cached(self, key: str, max_age: int, fetch: Any) -> Any:
        """Return the stored value younger than `max_age`, else fetch and store it (a stale one if fetching fails)."""
        store = self._store()
        if store is not None and (value := store.get(key, max_age=max_age)) is not None:
            return value
        try:
            value = fetch()
        except Exception:
            fflog_exc()
            return store.get(key) if store is not None else None
        if store is not None:
            store.set(key, value, ttl=4 * max_age)
        return value

    def _hosts(self) -> dict[str, str]:
        def fetch() -> dict[str, str]:
            resp = _session.get(f'{_BASE}/hosts.json', timeout=_TIMEOUT)
            resp.raise_for_status()
            return {str(host['i']): host.get('t') or '' for host in resp.json().get('hosts') or []}
        return self._cached(_HOSTS_KEY, _HOSTS_AGE, fetch) or {}

    def _index(self) -> dict[str, list[list[int]]]:
        def fetch() -> dict[str, list[list[int]]]:
            resp = _session.get(f'{_BASE}/search_catalog.json', timeout=_TIMEOUT)
            resp.raise_for_status()
            index: dict[str, list[list[int]]] = {}
            for item in resp.json().get('list') or []:
                name = _clean(item.get('name') or '')
                if name and item.get('id'):
                    year = int(item['year']) if str(item.get('year') or '').isdigit() else 0
                    index.setdefault(f"{item.get('type')}|{name}", []).append([year, int(item['id'])])
            fflog(f'catalog: {len(index)} titles indexed')
            return index
        return self._cached(_INDEX_KEY, _INDEX_AGE, fetch) or {}

    def _find(self, media_type: str, titles: list[str], year: str) -> int | None:
        index = self._index()
        wanted = int(year) if str(year).isdigit() else 0
        for title in dict.fromkeys(_clean(title) for title in titles if title):
            entries = index.get(f'{media_type}|{title}') or []
            for tolerance in (0, 1):
                matches = [title_id for entry_year, title_id in entries
                           if not wanted or abs(entry_year - wanted) <= tolerance]
                if matches:
                    fflog(f'found {media_type} {title!r} {year} -> id={matches[0]}')
                    return matches[0]
        fflog(f'not found: {media_type} {titles[:2]} {year}')
        return None


def _episode_sources(data: dict, season: int, episode: int) -> list[dict]:
    for season_item in data.get('seasons') or []:
        if season_item.get('number') == season:
            for episode_item in season_item.get('episodes') or []:
                if episode_item.get('number') == episode:
                    return episode_item.get('sources') or []
    return []


def _link(hosts: dict[str, str], raw: dict) -> str | None:
    template = hosts.get(str(raw.get('i')), '')
    file_id = str(raw.get('h') or '')
    if '{hashid}' not in template or not file_id or any(host in template for host in _SKIPPED_HOSTS):
        return None
    # DoodStream ids are 12 chars; the catalog often stores them with an extra
    # leading "e" (13 chars) - "Video not found" as is, the real file without it
    if 'doodstream.' in template and len(file_id) == 13 and file_id.startswith('e'):
        file_id = file_id[1:]
    return template.replace('{hashid}', file_id)


def _clean(title: str) -> str:
    """Lower-case letters and digits only, accents folded ("Amélie: Part 2" -> "ameliepart2")."""
    folded = unicodedata.normalize('NFKD', title.lower().replace('ł', 'l'))
    return re.sub(r'[^0-9a-z]+', '', ''.join(char for char in folded if not unicodedata.combining(char)))


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test Streamhub source provider')
    parser.add_argument('title', help='English title')
    parser.add_argument('year')
    parser.add_argument('--season', type=int, default=None)
    parser.add_argument('--episode', type=int, default=None)
    args = parser.parse_args()

    src = source()
    if args.season:
        found = src.tvshow('', '', args.title, '', [], args.year)
        found = src.episode(found, '', '', '', '', str(args.season), str(args.episode or 1))
    else:
        found = src.movie('', args.title, '', [], args.year)
    for item in src.sources(found, [], []):
        print(f"  {item.get('hosting', ''):12} {item.get('language', ''):3} {item['url']}")
