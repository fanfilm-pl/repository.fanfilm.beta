# -*- coding: utf-8 -*-
"""
FanFilm - source: bajeczki24.pl (Meilisearch API + embedded hosting players)
Copyright (C) 2026 :)

Distributed under the MIT license <https://mit-license.org>
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, ClassVar

from lib.ff import cleantitle, requests
from lib.ff.item import FFItem
from lib.ff.logs import fflog
from lib.ff.source_utils import DEFAULT_UA, ShowData, ShowDataDict, show_data_asdict

if TYPE_CHECKING:
    from typing import Collection
    from lib.ff.db.sources import ProviderStore
    from lib.sources import SourceItem, SourceTitleAlias


BASE_LINK: str = 'https://bajeczki24.pl'
SEARCH_URL: str = 'https://api.bajeczki24.pl/radar/v1/multi-search'
#: Public search key of the site (from its Search bundle).
SEARCH_KEY: str = '118b6cd0fd246c02d4fe6465a1e5c16d7ce09fb67935180da44a060db68855c2'
IDX_MOVIES: str = 'movies-v2'
IDX_SHOWS: str = 'tv-shows-v2'
SEARCH_LIMIT: int = 10

_IFRAME_RE: re.Pattern[str] = re.compile(r'<iframe[^>]*?\ssrc="([^"]+)"')
_HOST_RE: re.Pattern[str] = re.compile(r'https?://(?:www\.)?([^./]+)')


# ─── source ──────────────────────────────────────────────────────────────────────

class source:  # noqa: N801
    """bajeczki24.pl provider (movies and shows with Polish audio, one embedded player per page)."""

    LABEL: ClassVar[str] = 'Bajeczki24'
    PREMIUM: ClassVar[bool] = False
    PRIORITY: ClassVar[int] = 1
    LANGUAGES: ClassVar[Collection[str]] = ('pl',)

    ffitem: FFItem
    store: ProviderStore

    def __init__(self) -> None:
        """Prepare the HTTP session."""
        self.session: requests.Session = requests.ProviderSession()
        self.headers: dict[str, str] = {
            'Referer': BASE_LINK,
            'User-Agent': DEFAULT_UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        }
        self.api_headers: dict[str, str] = {
            'Authorization': f'Bearer {SEARCH_KEY}',
            'Content-Type': 'application/json',
            'User-Agent': DEFAULT_UA,
        }

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None:
        """Return the movie page URL."""
        hit: dict[str, Any] | None = self._find_title(IDX_MOVIES, (localtitle, title), year)
        return BASE_LINK + hit['path'] if hit else None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict:
        """Return the show token (titles, aliases, year)."""
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, int(year or 0)))

    def episode(self, url: dict[str, Any] | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> str | None:
        """Return the episode page URL (the site has a fixed /<season>/<episode>/ path under the show)."""
        if not url:
            return None
        data: ShowData = ShowData(**url)
        hit: dict[str, Any] | None = self._find_title(IDX_SHOWS, (data.local_title, data.title), str(data.year or ''))
        if not hit:
            fflog(f'show not found: {data.local_title!r} / {data.title!r}')
            return None
        return f"{BASE_LINK}{hit['path']}{int(season)}/{int(episode)}/"

    def sources(self, url: str | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:  # noqa: N803
        """Return the embedded player of the page."""
        if not url:
            return []
        resp: requests.Response = self.session.get(url, headers=self.headers, timeout=30)
        if resp.status_code == 404:  # e.g. an episode the site does not have
            fflog(f'no page: {url}')
            return []
        resp.raise_for_status()

        match: re.Match[str] | None = _IFRAME_RE.search(resp.text)
        if not match:
            fflog(f'no player on {url}')
            return []
        frame: str = match.group(1)
        host_match: re.Match[str] | None = _HOST_RE.search(frame)
        return [{
            'hosting': host_match.group(1) if host_match else frame,
            'quality': '1080p',
            'language': 'pl',
            'url': frame,
            'info': '',
            'direct': False,
            'debridonly': False,
            'premium': False,
        }]

    def resolve(self, url: str) -> str:
        """Return the hosting player URL (opened by a resolver)."""
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _find_title(self, index: str, titles: tuple[str, ...], year: str) -> dict[str, Any] | None:
        """Search the titles in turn, return the first hit with the same title (and year, if known)."""
        searched: set[str] = set()
        for title in titles:
            if not title or title.lower() in searched:
                continue
            searched.add(title.lower())
            hit: dict[str, Any] | None = self._find_hit(title, index, year)
            if hit:
                return hit
        return None

    def _find_hit(self, query: str, index: str, year: str) -> dict[str, Any] | None:
        """Return the hit matching the query title (and year, if known)."""
        hits: list[dict[str, Any]] = self._search_api(query, index)
        fflog(f'search {index!r} q={query!r}: {len(hits)} hits')
        wanted: str = cleantitle.get(query) or ''
        year_int: int = int(year) if year.isdigit() else 0
        for hit in hits:
            if (cleantitle.get(hit.get('title') or '') or '') != wanted:
                continue
            if year_int and hit.get('releaseYear') and hit['releaseYear'] != year_int:
                continue
            return hit
        return None

    def _search_api(self, query: str, index: str) -> list[dict[str, Any]]:
        """Search one index of the site (the per-index /indexes/<index>/search is blocked by Cloudflare, 403)."""
        payload: dict[str, Any] = {
            'queries': [{'indexUid': index, 'q': query}],
            'federation': {'offset': 0, 'limit': SEARCH_LIMIT},
        }
        resp: requests.Response = self.session.post(SEARCH_URL, headers=self.api_headers, json=payload, timeout=15)
        resp.raise_for_status()
        return resp.json().get('hits') or []
