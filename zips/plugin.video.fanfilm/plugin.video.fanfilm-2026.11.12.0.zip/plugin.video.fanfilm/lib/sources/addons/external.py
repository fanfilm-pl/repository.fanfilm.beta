"""
The external add-ons with scrapers, searched by their provider add-ons (xdostawcy, `lib.ff.xproviders`): FanFilm knows no
scraper dialect, the add-ons and their providers are what the catalogs of the active provider add-ons give (one add-on is
served by one of them, `owner()`); a provider of an add-on is a proxy of the protocol (`XProviderProxy`).

Tools » Source providers: the native providers of FanFilm (the add-on serving itself: its groups, sections and providers,
`lib.sources.natives`) and the provider add-ons, their add-ons, groups and scrapers (`found_xproviders()`, `addons_tree()`),
the choice of the user (`XPROVIDERS_CONFIG`: a provider add-on active, `ADDONS_CONFIG`: the searched scrapers, also the
native ones).
"""

from __future__ import annotations
from typing import Any, Mapping, cast, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from time import monotonic
from attrs import frozen
from lib.sources import SourceAddonInfo, SourceItem, addon_title, addon_name_parts, safe_addon_name, ProviderModule, ProviderOptions, Provider
from lib.sources import provider_query, source_item, protocol_item, IncompleteResult, current_search_cache
from lib.sdk.protocol import ResolveResult
from lib.sdk.protocol import Context, PROTOCOL_VERSION
from lib.sdk.xprovider import provider_key
from lib.ff.xproviders import XProviderError, XProviderApi, owner, installed_manifests, is_active, catalog, addons_path
from lib.ff.tricks import MISSING
from lib.ff.logs import fflog
from lib.ff.kotools import addon_enabled_in_kodi, addon_icon
from const import const
if TYPE_CHECKING:
    from typing import Callable, Sequence, Iterable, Iterator, ClassVar, Collection
    from lib.sdk.protocol.catalog import CatalogAddon
    from lib.sources.natives import NativeProvider
    from lib.sources import Source, SourceAddonModule, SourceSearchOverride
    from lib.ff.item import FFItem


#: A value of a node of the tree of the choice (`NODES_CONFIG`): its highlight color, its priority (bigger first), its priority of the episodes.
NodeValue: TypeAlias = Literal['color', 'priority', 'episode_priority']
#: The external add-ons in the user configuration: `{<add-on ID>: {"active": bool, "disabled": [<scraper>, ...], "known":
#: [<scraper>, ...]}}` (every add-on of the tree, see `addons_choice()`); `disabled`: the scrapers (their provider IDs in the
#: catalog) of an active add-on not searched; `known`: the scrapers of the last choice, a new one (not known) is searched
#: if it is by default (`default_enabled` of the catalog); without `known` (an older choice) every scraper is known.
ADDONS_CONFIG: str = '/sources/addons'
#: The highlight color and the priority of the nodes of the tree of the choice: `{<node key>: {"color": "AARRGGBB",
#: "priority": 0-10, "episode_priority": 0-10}}` (`TreeEntry.node_key`); a source takes them from its branch, its leaf first (`native_chain()`,
#: `scraper_chain()`; none set: the rules, `SourceAttribute.default_*`).
NODES_CONFIG: str = '/sources/nodes'
#: The value of a node when it has none (it inherits): the highlight color, the priorities (0 is a value of its own).
NODE_DEFAULTS: Mapping[NodeValue, Any] = {'color': '', 'priority': None, 'episode_priority': None}


def catalog_addon_name(entry: CatalogAddon) -> str:
    """Return the name of an add-on of a catalog (its `addon.xml` if installed, else of the catalog; not a name reserved for FanFilm)."""
    if (path := addons_path() / entry['id']).is_dir():
        return addon_title(path)
    return safe_addon_name(entry.get('name') or entry['id'], entry['id'])


@frozen(kw_only=True)
class AddonProvider:
    """A provider (scraper) of an external add-on (its catalog entry)."""

    #: The provider ID in the add-on (`<group>/<name>`: the key of the choice).
    id: str
    #: Its group (`pl`, `torrents`...), may be empty.
    group: str
    #: Its name.
    name: str


@frozen(kw_only=True)
class ExternalAddon:
    """An add-on served by a provider add-on (its catalog entry), for the choice of the user."""

    #: Add-on ID.
    id: str
    #: Its name (not a name reserved for FanFilm).
    name: str
    #: The provider add-on serving it.
    xprovider: str
    #: Its providers, in the order of the catalog.
    providers: tuple[AddonProvider, ...]
    #: Its providers searched by default (`default_enabled` of the catalog, none given: all).
    defaults: frozenset[str] = frozenset()
    #: True if it is enabled in Kodi (a disabled one is searched too: its service off, no updates).
    enabled_in_kodi: bool = True
    #: Its icon (if any).
    icon: str | None = None

    @property
    def scrapers(self) -> tuple[str, ...]:
        """Return the provider IDs (the keys of the choice)."""
        return tuple(prov.id for prov in self.providers)

    @classmethod
    def of(cls, entry: CatalogAddon, xprovider: str) -> ExternalAddon:
        """Return the add-on of its catalog entry."""
        path = addons_path() / entry['id']
        name = catalog_addon_name(entry)
        providers = tuple(AddonProvider(id=prov['id'], group=prov.get('group', ''), name=prov.get('name') or prov['id']) for prov in entry.get('providers', ()))
        defaults = frozenset(prov['id'] for prov in entry.get('providers', ()) if prov.get('default_enabled', True))
        return cls(id=entry['id'], name=name, xprovider=xprovider, providers=providers, defaults=defaults, enabled_in_kodi=addon_enabled_in_kodi(entry['id']),
                   icon=addon_icon(path) or None)


@frozen(kw_only=True)
class FoundXProvider:
    """An installed provider add-on and the add-ons it serves (for the choice of the user)."""

    #: Its ID.
    id: str
    #: Its name.
    name: str
    #: Its icon (if any).
    icon: str | None = None
    #: True if it is enabled in Kodi.
    enabled_in_kodi: bool = True
    #: True if it is active (`is_active()`): it runs, its catalog is read.
    active: bool = False
    #: Active, its catalog is not there yet (its worker starts).
    loading: bool = False
    #: The add-ons it serves (the ones another provider add-on serves are there).
    addons: tuple[ExternalAddon, ...] = ()
    #: The native providers of FanFilm (their catalog entries), only for the native ones (FanFilm serving itself).
    natives: tuple[NativeProvider, ...] = ()

    @property
    def short_name(self) -> str:
        """Return its name without the category (`FanFilm Providers: Fenom` -> `Fenom`, the tree)."""
        _, name = addon_name_parts(self.name)
        return name


def native_xprovider() -> FoundXProvider | None:
    """Return the native providers of FanFilm as a provider add-on serving itself (its catalog, `native_catalog()`), None if no catalog."""
    from lib.kolang import L
    from lib.sources.natives import NATIVES_ID, catalog_providers, migrate_settings, native_catalog
    from lib.ff.control import plugin_id
    if not (providers := catalog_providers(native_catalog())):
        return None
    migrate_settings()  # the old settings: also the choice of the native providers (read after this)
    path = addons_path() / plugin_id
    keys = [f'{prov["id"]}/{sub["id"]}' for prov in providers for sub in prov.get('subsources', ())]
    keys += [prov['id'] for prov in providers if not prov.get('subsources')]
    defaults = {key for key in keys if key not in const.sources.providers.default_off}
    defaults -= {f'{prov["id"]}/{sub["id"]}' for prov in providers for sub in prov.get('subsources', ()) if not sub['default_enabled']}
    icon = addon_icon(path) or None
    addon = ExternalAddon(id=NATIVES_ID, name='FanFilm', xprovider=NATIVES_ID, providers=tuple(AddonProvider(id=key, group='', name=key) for key in keys),
                          defaults=frozenset(defaults), icon=icon)
    return FoundXProvider(id=NATIVES_ID, name=L(30711, 'FanFilm (built-in)'), icon=icon, active=True, addons=(addon,), natives=tuple(providers))


def found_xproviders() -> list[FoundXProvider]:
    """
    Return the native providers of FanFilm (first, `native_xprovider()`) and the installed provider add-ons with the add-ons
    they serve: the catalog of an active one enabled in Kodi (an inactive one does not run: no catalog), an add-on under
    its owner only (`owner()`).
    """
    found: list[FoundXProvider] = []
    for manifest in installed_manifests():
        path = manifest.path
        enabled = addon_enabled_in_kodi(manifest.id)
        active = is_active(manifest.id)
        addons: list[ExternalAddon] = []
        loading = False
        if enabled and active:
            if (data := catalog(manifest)) is None:
                loading = True
            else:
                for entry in data.get('addons', ()):
                    if (claim := owner(entry['id'])) is not None and claim.xprovider == manifest.id:
                        addons.append(ExternalAddon.of(entry, manifest.id))
        found.append(FoundXProvider(id=manifest.id, name=addon_title(path), icon=addon_icon(path) or None,
                                    enabled_in_kodi=enabled, active=active, loading=loading,
                                    addons=tuple(sorted(addons, key=lambda addon: addon.name.lower()))))
    natives = native_xprovider()
    return [*((natives,) if natives is not None else ()), *sorted(found, key=lambda xp: xp.short_name.lower())]


def addons_choice(found: Iterable[ExternalAddon], chosen: dict[str, Any], selected: Mapping[str, Collection[str]]) -> dict[str, Any]:
    """
    Return the new `ADDONS_CONFIG` value from the `selected` scrapers by the add-on ID: an add-on with a selected scraper is
    active, its other scrapers are `disabled`, all its scrapers `known`; the first activation of a whole add-on (never
    chosen: no `known`) takes its scrapers searched by default; an inactive add-on keeps its `disabled` (and every add-on
    its other fields); entries of add-ons not found (not served now) are kept as they are.
    """
    result = dict(chosen)
    for addon in found:
        entry = dict(old) if isinstance(old := chosen.get(addon.id), dict) else {}
        if on := set(selected.get(addon.id) or ()):
            if on == set(addon.scrapers) and 'known' not in entry and not entry.get('active') and addon.defaults:
                on = set(addon.defaults)
            entry.pop('disabled', None)
            if disabled := [key for key in addon.scrapers if key not in on]:
                entry['disabled'] = disabled
            entry['known'] = list(addon.scrapers)
        result[addon.id] = {**entry, 'active': bool(on)}
    return result


def searched_scrapers(keys: Iterable[str], entry: Any, defaults: Callable[[], Collection[str]]) -> list[str]:
    """
    Return the searched scrapers of the `keys` of an add-on by its `ADDONS_CONFIG` entry (no entry: all): all but
    `disabled`, a new one (not `known`) if it is in its `defaults` (asked only then).
    """
    if not isinstance(entry, dict):
        return list(keys)
    keys = [key for key in keys if key not in set(entry.get('disabled') or ())]
    if (known := entry.get('known')) is None or all(key in known for key in keys):
        return keys
    on = defaults()
    return [key for key in keys if key in known or key in on]


def addon_scrapers_selected(addon: ExternalAddon, chosen: dict[str, Any]) -> list[str]:
    """Return the selected scrapers of the add-on (an active one: `searched_scrapers()`; an inactive one: none)."""
    if not isinstance(entry := chosen.get(addon.id), dict) or not entry.get('active'):
        return []
    return searched_scrapers(addon.scrapers, entry, lambda: addon.defaults)


def search_timeout() -> float:
    """
    Return the time limit (seconds) of a request of an external scraper: what is left of the search (the deadline of the
    scope of the thread) less the margin of the transfer of its last items, the setting out of a search (no deadline).
    """
    from lib.ff.threads import current_scope
    from ..source_settings import search_limits
    if (scope := current_scope()) is None or scope.deadline is None:
        return search_limits().end
    return max(scope.deadline - monotonic() - const.sources.xproviders.timeout_margin, 0)


def host_context(**extra: Any) -> Context:
    """Return the host context of a request of an external scraper (the hostings, the packs, the time limit of the search) with `extra`."""
    from lib.ff.sources import supported_hosts, PREMIUM_HOSTS
    return {'hosts': supported_hosts(), 'premium_hosts': list(PREMIUM_HOSTS), 'packs': list(const.sources.packs),
            'timeout': search_timeout(), **extra}  # type: ignore[typeddict-item]


@frozen
class TreeEntry:
    """What an item of the tree of the choice is: a provider add-on, an add-on (`addon`), a scraper (`key` too)."""

    #: The provider add-on.
    xprovider: str
    #: The add-on ('' - the provider add-on itself).
    addon: str = ''
    #: The scraper key ('' - a node).
    key: str = ''
    #: The native provider of the row (its settings in the panel; a node: the group which is the provider itself), '' - none.
    provider: str = ''
    #: The sub-source of the native provider of the row (a leaf), '' - none.
    sub: str = ''
    #: The node key of a group or a section (`group:<group>`, `section:<group>/<section>`, `<add-on>/<group>`), '' - none.
    node: str = ''

    @property
    def node_key(self) -> str:
        """
        Return the key of the item (its color and priority, `NODES_CONFIG`; its key in the tree, `TreeModel(key=...)`): a
        scraper `<add-on>:<key>` (a native one: its key, the add-on serving itself), a native provider, a group / section
        node, an add-on, a provider add-on; the same as the branches of the sources (`native_chain()`, `scraper_chain()`).
        """
        if self.key:
            return self.key if self.addon == self.xprovider else provider_key(self.addon, self.key)
        return self.provider or self.node or self.addon or self.xprovider


def tree_keys(entries: Mapping[int, TreeEntry]) -> Callable[[FFItem], str]:
    """Return the keys of the items of the tree of the choice (`TreeEntry.node_key`)."""
    return lambda item: entries[id(item)].node_key


def node_value(key: str, name: NodeValue) -> Any:
    """Return a value of the node `key` (its own; none: `NODE_DEFAULTS`)."""
    from lib.ff.config import config, escape_key
    return config.get(f'{NODES_CONFIG}/{escape_key(key)}/{name}', NODE_DEFAULTS[name])


def set_node_value(key: str, name: NodeValue, value: Any) -> None:
    """Set a value of the node `key` (its default: removed, the node inherits it)."""
    from lib.ff.config import config, escape_key
    config.set(f'{NODES_CONFIG}/{escape_key(key)}/{name}', value, default=NODE_DEFAULTS[name])


def clear_node(key: str) -> None:
    """Remove the values in use of the node `key` (it inherits them; the ones not in use stay: `node_values()`)."""
    from lib.ff.config import config, escape_key
    path = f'{NODES_CONFIG}/{escape_key(key)}'
    used = node_values()
    config.set(path, {name: value for name, value in (config.get(path) or {}).items() if name not in used}, default={})


def node_has(value: Any) -> bool:
    """Return True if a value of a node is its own (not inherited): a color (not the default one ''), a priority (0 too)."""
    return value not in (None, '')


def node_values() -> tuple[NodeValue, ...]:
    """Return the values of a node in use (the priority of the episodes: `const.sources.providers.episode_priority`, not in the simple view)."""
    from lib.ff.source_filters import simple_view
    episodes = const.sources.providers.episode_priority and not simple_view('show')
    return tuple(name for name in NODE_DEFAULTS if name != 'episode_priority' or episodes)


def native_place(name: str, folder: str) -> tuple[str, str]:
    """
    Return the group of a native provider in the tree (a group of `const.sources.providers.groups` by its members, else its
    folder) and its section (its key; a provider in no section: the first one; one section: '', no level).
    """
    group = next((key for key, grp in const.sources.providers.groups.items() if name in grp.members), folder)
    sections = const.sources.providers.sections.get(group, ())
    if len(sections) < 2:
        return group, ''
    return group, next((section.key for section in sections if name in section.members), sections[0].key)


def native_chain(name: str, folder: str, sub: str = '') -> tuple[str, ...]:
    """
    Return the branch of a native provider (`name`, its `folder` group) from its leaf (the sub-source `sub`) to the root:
    the node keys (`TreeEntry.node_key`): the sub-source, the provider, its section, its group (a group which is the
    provider itself: the provider), FanFilm.
    """
    from lib.sources.natives import NATIVES_ID
    group, section = native_place(name, folder)
    grp = const.sources.providers.groups.get(group)
    node = group if grp is not None and group in grp.members else f'group:{group}'  # a group which is a provider: the provider
    return (*((f'{name}/{sub}',) if sub else ()), *(() if name == node else (name,)), *((f'section:{group}/{section}',) if section else ()),
            node, NATIVES_ID)


def scraper_chain(xprovider: str, addon: str, key: str, group: str, *, one_group: bool) -> tuple[str, ...]:
    """
    Return the branch of a scraper (`key` of the `addon` in its `group`, served by `xprovider`) from its leaf to the root:
    the node keys (`TreeEntry.node_key`): the scraper, its group (none if the add-on has one), the add-on, the provider add-on.
    """
    return (provider_key(addon, key), *(() if one_group else (f'{addon}/{group}',)), addon, xprovider)


def default_leaves(xproviders: Sequence[FoundXProvider], roots: Sequence[FFItem], entries: Mapping[int, TreeEntry]) -> list[FFItem]:
    """Return the leaves of the tree of the choice searched by default (`ExternalAddon.defaults`: as the first activation of an add-on)."""
    defaults = {addon.id: addon.defaults for xp in xproviders for addon in xp.addons}

    def walk(items: Sequence[FFItem]) -> Iterator[FFItem]:
        for item in items:
            if item.children_items is not None:
                yield from walk(item.children_items)
            elif (entry := entries.get(id(item))) is not None and entry.key in defaults.get(entry.addon, ()):
                yield item

    return list(walk(roots))


def addons_tree(xproviders: Sequence[FoundXProvider], chosen: dict[str, Any]) -> tuple[list[FFItem], dict[int, TreeEntry], list[FFItem]]:
    """
    Return the tree of the choice (the tab of the external add-ons): a provider add-on, its add-ons, their groups (`pl`,
    `en`...; none if one), their scrapers; what every item is (by `id()`, `TreeEntry`) and the selected leaves
    (`addon_scrapers_selected()`). The IDs, the states are in the panel of the tab, not in the tree.
    """
    from lib.ff.item import FFItem, FMode

    def node(label: str, icon: str | None) -> FFItem:
        item = FFItem(label, mode=FMode.Folder)
        if icon:
            item.setArt({'icon': icon, 'thumb': icon})
        item.children_items = []
        return item

    roots: list[FFItem] = []
    entries: dict[int, TreeEntry] = {}
    selected: list[FFItem] = []
    for xp in xproviders:
        xnode = node(xp.short_name, xp.icon)
        roots.append(xnode)
        entries[id(xnode)] = TreeEntry(xp.id)
        if xp.natives:  # the add-on serving itself: no level of the add-on; no choice: its defaults (as `native_searched()`)
            natives = xp.addons[0]
            on = set(addon_scrapers_selected(natives, chosen) if isinstance(chosen.get(natives.id), dict) else natives.defaults)
            native_nodes(xnode, xp, on, node=node, entries=entries, selected=selected)
            continue
        for addon in xp.addons:
            root = node(addon.name, addon.icon)
            cast('list[FFItem]', xnode.children_items).append(root)
            entries[id(root)] = TreeEntry(xp.id, addon.id)
            groups: dict[str, FFItem] = {}
            on = set(addon_scrapers_selected(addon, chosen))
            one_group = len({prov.group for prov in addon.providers}) == 1
            for prov in sorted(addon.providers, key=lambda prov: (prov.group.lower(), prov.name.lower())):
                if one_group:
                    parent = root
                elif (parent := groups.get(prov.group)) is None:
                    parent = groups[prov.group] = node(prov.group, addon.icon)
                    cast('list[FFItem]', root.children_items).append(parent)
                    entries[id(parent)] = TreeEntry(xp.id, addon.id, node=f'{addon.id}/{prov.group}')
                leaf = FFItem(prov.name)
                cast('list[FFItem]', parent.children_items).append(leaf)
                entries[id(leaf)] = TreeEntry(xp.id, addon.id, prov.id)
                if prov.id in on:
                    selected.append(leaf)
    return roots, entries, selected


def native_nodes(parent: FFItem, xp: FoundXProvider, on: Collection[str], *, node: Callable[[str, str | None], FFItem],
                 entries: dict[int, TreeEntry], selected: list[FFItem]) -> None:
    """
    Add the native providers to the tree (under `parent`): the groups of their folders (in the order of
    `const.sources.providers.folder_labels`, others alphabetically after them), the groups of
    `const.sources.providers.groups` (in its order); a group: its sections (`const.sources.providers.sections`, a provider
    of no section in the first one, one section: no level), the providers alphabetically; a provider of the group name is
    the group itself (its sub-sources are leaves of its first section), another one with sub-sources is a node of them.
    `on`: the selected keys.
    """
    from lib.ff.item import FFItem
    natives = xp.addons[0].id
    by_name = {prov['id']: prov for prov in xp.natives}
    moved = {name for grp in const.sources.providers.groups.values() for name in grp.members}
    labels = const.sources.providers.folder_labels
    order = list(labels)
    groups: list[tuple[str, str, list[NativeProvider]]] = [
        (group, labels.get(group, group), [prov for prov in xp.natives if prov['group'] == group and prov['id'] not in moved])
        for group in sorted({prov['group'] for prov in xp.natives if prov['id'] not in moved},
                            key=lambda group: (order.index(group) if group in order else len(order), group))]
    groups += [(key, grp.label, [by_name[name] for name in grp.members if name in by_name]) for key, grp in const.sources.providers.groups.items()]

    def leaf(label: str, key: str, provider: str, sub: str, under: FFItem) -> None:
        """Add a leaf of the choice (`key`) under the node `under`."""
        item = FFItem(label)
        cast('list[FFItem]', under.children_items).append(item)
        entries[id(item)] = TreeEntry(xp.id, natives, key, provider=provider, sub=sub)
        if key in on:
            selected.append(item)

    for key, label, members in groups:
        if not members:
            continue
        itself = by_name[key] if key in by_name and key in const.sources.providers.groups else None  # the group is this provider
        gnode = node(label, xp.icon)
        cast('list[FFItem]', parent.children_items).append(gnode)
        entries[id(gnode)] = TreeEntry(xp.id, natives, provider=itself['id'] if itself else '', node=f'group:{key}')
        sections = const.sources.providers.sections.get(key, ())
        index = {section.key: n for n, section in enumerate(sections)}
        rows: list[list[tuple[str, NativeProvider, Any]]] = [[] for _ in range(max(len(sections), 1))]
        for prov in members:
            row = rows[index.get(native_place(prov['id'], prov['group'])[1], 0)]  # the section (the sub-sources of the group itself: the first one)
            if prov is itself:
                row.extend((sub['name'], prov, sub) for sub in prov.get('subsources', ()))
            else:
                row.append((prov['name'], prov, None))
        for n, row in enumerate(rows):
            if not row:
                continue
            if len(sections) > 1:
                under = node(sections[n].label, xp.icon)
                cast('list[FFItem]', gnode.children_items).append(under)
                entries[id(under)] = TreeEntry(xp.id, natives, node=f'section:{key}/{sections[n].key}')
            else:
                under = gnode
            for name, prov, sub in sorted(row, key=lambda found: found[0].lower()):
                if sub is not None:
                    leaf(name, f'{prov["id"]}/{sub["id"]}', prov['id'], sub['id'], under)
                elif subs := prov.get('subsources'):
                    pnode = node(name, xp.icon)
                    cast('list[FFItem]', under.children_items).append(pnode)
                    entries[id(pnode)] = TreeEntry(xp.id, natives, provider=prov['id'])
                    for item in sorted(subs, key=lambda found: found['name'].lower()):
                        leaf(item['name'], f'{prov["id"]}/{item["id"]}', prov['id'], item['id'], pnode)
                else:
                    leaf(name, prov['id'], prov['id'], '', under)


class ExternalAddons(ProviderOptions):
    """The source module of the external add-ons: the chosen ones (`ADDONS_CONFIG`), their providers as proxies of their provider add-ons."""

    def __init__(self, *, addon: str = '') -> None:
        """Create the module; `addon` is the add-on ID (set per add-on in `get_addon()`)."""
        self.addon = addon

    def scan_addons(self) -> Iterable[SourceAddonInfo]:
        """
        Yield the add-ons the user chose (`ADDONS_CONFIG`) and an active provider add-on serves, enabled in Kodi or not: the
        choice of FanFilm is what searches the scrapers, Kodi runs the add-on itself (its service, its updates).
        """
        from lib.ff.config import config
        for addon_id, entry in (config.get(ADDONS_CONFIG) or {}).items():
            if isinstance(entry, dict) and entry.get('active') and (claim := owner(addon_id)) is not None:
                yield SourceAddonInfo(addon=addon_id, title=catalog_addon_name(claim.addon))

    def get_addon(self, addon: SourceAddonInfo, /, *, ffitem: FFItem) -> SourceAddonModule:
        """Create an addon module bound to the add-on."""
        return addon.create_module(self.__class__(addon=addon.addon))

    def get_providers(self, *, ffitem: FFItem, override: SourceSearchOverride) -> Iterable[ProviderModule]:
        """
        Enumerate the providers of the provider add-on serving the add-on as proxies (nothing imported here), none if nobody
        serves it (`owner()`).
        """
        if not (addon_id := self.addon) or (claim := owner(addon_id)) is None:
            return
        from lib.ff.config import config
        entry = (config.get(ADDONS_CONFIG) or {}).get(addon_id)
        providers = claim.addon.get('providers', ())
        defaults = {prov['id'] for prov in providers if prov.get('default_enabled', True)}
        on = set(searched_scrapers([prov['id'] for prov in providers], entry, lambda: defaults))
        one_group = len({prov.get('group', '') for prov in providers}) == 1
        for prov in providers:
            if prov['id'] in on:
                nodes = scraper_chain(claim.xprovider, addon_id, prov['id'], prov.get('group', ''), one_group=one_group)
                yield ProviderModule(name=prov['name'], provider=XProviderProxy(xprovider=claim.xprovider, key=provider_key(addon_id, prov['id']),
                                                                                sources_ttl=prov.get('sources_ttl'), dynamic=bool(prov.get('dynamic')),
                                                                                nodes=nodes))


class XProviderProxy(Provider):
    """
    Proxy provider of one provider of a provider add-on (xdostawca): a protocol request of this provider (the query of
    the search, the host context), its items as FanFilm source items; a provider with an account step (`dynamic` of its
    catalog entry) has `apply_dynamic()`: the items of its fresh search have the account state, a cached result asks it.
    """

    #: This proxy needs no ffitem in __init__.
    INIT_WITH_FFITEM: ClassVar[bool] = False

    def __init__(self, *, xprovider: str, key: str, sources_ttl: int | None = None, dynamic: bool = False, nodes: Sequence[str] = ()) -> None:
        """
        Create the proxy of the provider `key` (`<add-on>:<provider>`) of the provider add-on `xprovider`, `sources_ttl`
        and `dynamic` of its catalog entry, `nodes`: its branch in the tree of the choice (`scraper_chain()`).
        """
        self.xprovider = xprovider
        self.key = key
        #: Its branch in the tree of the choice from its leaf (the color and the priority of its sources, `NODES_CONFIG`).
        self.nodes: tuple[str, ...] = tuple(nodes)
        #: It has an account step (`apply_dynamic()`).
        self._dynamic: bool = dynamic
        #: The sources of its last fresh search have the account state already (no request of `dynamic` for them).
        self._fresh: bool = False
        #: Lifetime of its cached result: of the catalog, then of the `done` of its last search (None: the default).
        self._sources_ttl: int | None = sources_ttl

    @property
    def SOURCES_TTL(self) -> int | None:  # type: ignore[override]  # an instance property instead of the class option
        """Lifetime of the cached result: of the provider add-on (its catalog, the `done` of the last search), None: the default."""
        return self._sources_ttl

    def __getattr__(self, name: str) -> Any:
        """The capability of a provider with an account step: `apply_dynamic()`."""
        if name == 'apply_dynamic' and self.__dict__.get('_dynamic'):
            return self._apply_dynamic
        raise AttributeError(name)

    def _apply_dynamic(self, *, ffitem: FFItem, override: SourceSearchOverride, sources: list[Source]) -> list[Source | SourceItem]:
        """
        Return the sources with the account state: of a fresh search as they are (its items have it), of a cached result
        by the request `dynamic` of the provider add-on.
        """
        if self._fresh or not sources:
            self._fresh = False
            return list(sources)
        from lib.info import exec_id
        context = host_context(providers=[self.key], request_id=exec_id(), protocol=PROTOCOL_VERSION)
        items = self._xprovider().dynamic(self.key, provider_query(ffitem, override), context, [protocol_item(src) for src in sources])
        return [source_item(item) for item in items]

    def _xprovider(self) -> XProviderApi:
        """Return the provider add-on (its worker, or imported once an interpreter)."""
        from lib.ff.xproviders import xprovider
        if (xp := xprovider(self.xprovider)) is None:
            raise XProviderError(f'{self.xprovider}: the provider add-on is starting or not available')
        return xp

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride, show: Any = MISSING, **kwargs: Any) -> Iterable[SourceItem]:
        """
        Search with the provider: its items; a search that did not end (a time limit, an error of the provider) gives
        the items found so far as an incomplete result (not cached), a cancel is a stopped thread.
        """
        from lib.ff.threads import current_scope, ThreadCanceled
        from lib.info import exec_id
        xprovider = self._xprovider()  # first: loading it (the run mode `import`) takes the time of the search too
        self._fresh = True  # its items (also of an incomplete result) have the account state: `apply_dynamic()` asks nothing for them
        context = host_context(providers=[self.key], request_id=exec_id(), protocol=PROTOCOL_VERSION)
        if (cache := current_search_cache()) is not None:
            context['cache'] = {'refresh': cache.refresh, 'ttl': {'show': cache.show_ttl, 'empty': cache.empty_ttl}}
        scope = current_scope()
        items: list[SourceItem] = []
        for event in xprovider.find(provider_query(ffitem, override), context, canceled=lambda: scope is not None and scope.is_set()):
            if event['event'] == 'items':
                items.extend(source_item(item) for item in event['items'])
                continue
            if stats := event.get('stats'):
                fflog(f'[XPROVIDERS] {self.key}: {stats.get("count", 0)} items in {stats.get("elapsed", 0):.2f} s')
            if (sources_ttl := event.get('sources_ttl')) is not None:
                self._sources_ttl = sources_ttl
            if (error := event.get('error')) is not None:
                if error.get('kind') == 'canceled':
                    raise ThreadCanceled()
                raise IncompleteResult(items, f'{self.key}: {error.get("kind")} {error.get("message", "")}'.rstrip())
        return items

    def resolve(self, url: str, *, data: Any = MISSING, **kwargs: Any) -> str | ResolveResult | None:
        """Return the stream of the link (the provider add-on resolves it), the private `data` of the item back to it."""
        item: dict[str, Any] = {'url': url} if data is MISSING else {'url': url, 'data': data}
        return self._xprovider().resolve(self.key, item, dict(kwargs))



source = ExternalAddons
