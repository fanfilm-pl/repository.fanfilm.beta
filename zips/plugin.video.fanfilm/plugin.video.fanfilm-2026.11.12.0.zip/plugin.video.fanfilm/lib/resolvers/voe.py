# -*- coding: utf-8 -*-
"""
FanFilm's wrapper over the resolveurl VOE resolver.

A fresh VOE HLS link (CDN ugc-cdn-caching-*.cloudwindow-route.com) sometimes gives its variant playlist with the
segments without the token at the first fetch: every segment then gets HTTP 403 and Kodi gives up after ~25 s
("Error creating demuxer"). A fetch again gives them right, so the playlist is fetched here before Kodi opens it.
Only HLS results are touched, MP4 ones (resolveurl's default, ``prefer_hls`` off) are returned as they are.
"""

from __future__ import annotations

from time import sleep
from urllib.parse import parse_qsl, urljoin

from resolveurl.plugins.voesx import VoeResolver as _VoeResolver

from lib.ff import requests
from lib.ff.logs import fflog

#: How many times the playlist is fetched until its segments have the token.
_WARM_ATTEMPTS = 3


def _media_lines(text: str) -> list[str]:
    """Return the URI lines of a playlist (variants of a master one, segments of a media one)."""
    return [line for line in text.splitlines() if line and not line.startswith('#')]


def _warm_hls(stream_url: str) -> None:
    """Fetch the HLS playlist (its first variant too) until its segments have the token of the link."""
    url, _, header_text = stream_url.partition('|')
    if '?' not in url:
        return  # no token in the link, nothing to lose in the segments
    headers = dict(parse_qsl(header_text))
    verify = headers.pop('verifypeer', 'true').lower() != 'false'
    try:
        for attempt in range(1, _WARM_ATTEMPTS + 1):
            text = requests.get(url, headers=headers, verify=verify, timeout=5).text
            lines = _media_lines(text)
            if lines and '#EXT-X-STREAM-INF' in text:  # a master playlist: its first variant has the segments
                text = requests.get(urljoin(url, lines[0]), headers=headers, verify=verify, timeout=5).text
                lines = _media_lines(text)
            if not lines or all('?' in line for line in lines[:3]):
                fflog(f'[VOE] HLS playlist ok (attempt {attempt}, {len(lines)} segments)')
                return
            fflog.warning(f'[VOE] HLS segments without the token (attempt {attempt}): {lines[0][:80]!r}')
            sleep(1)
    except Exception as exc:
        fflog.warning(f'[VOE] HLS playlist check failed: {exc!r}')


class VoeResolver(_VoeResolver):
    # The same class name as the resolveurl one: its settings (``VoeResolver_prefer_hls``) are read by the class name.

    def get_media_url(self, host, media_id, subs=False):
        stream = super().get_media_url(host, media_id, subs=subs)
        stream_url = stream[0] if isinstance(stream, tuple) else stream
        if stream_url and '.m3u8' in stream_url.partition('|')[0]:
            _warm_hls(stream_url)
        return stream
