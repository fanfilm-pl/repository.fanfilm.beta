from typing import List
from . import ServiceLists, account_api
from .menu import AccountEntry, media_kw
from ...ff.routing import route, info_for, url_for, PathArg
from ..folder import Folder, item_folder_route, list_directory
from const import const
from ...defs import MainMediaType


class FloppyLists(ServiceLists):
    """Floppy: the lists of accounts (the base), the calendar, the Discover rows and the Home rows of the account."""

    TYPE = 'floppy'

    def type_entries(self, account: str) -> List['AccountEntry']:
        """Return the entries of Floppy itself: the calendar of the tracked titles, the Discover rows, the Home rows (set in Floppy)."""
        return [
            AccountEntry('calendar', lambda v: info_for(self.calendar, account=account, **media_kw(v)), ('movie', 'show')),
            AccountEntry('recommendations', lambda v: url_for(self.rows, account=account, source='discover', **media_kw(v)), ('movie', 'show')),
            AccountEntry('home', lambda v: url_for(self.rows, account=account, source='home', **media_kw(v)), ('movie', 'show')),
        ]

    @item_folder_route('/calendar/{media}')
    def calendar(self, *, media: MainMediaType, page: PathArg[int] = 1, account: str = 'floppy') -> 'Folder':
        """The calendar of the tracked titles of the account: movies or episodes with their days."""
        from ...ff.calendar import day_label
        api = account_api(account, 'floppy')
        items = [] if api is None else api.calendar(media)
        days = dict(items)
        return Folder([ref for ref, _ in items], page=page or 1, limit=const.indexer.floppy.page_size,
                      role_format=lambda it, index: day_label(days.get(it.ref) or it.date, week_without_date=False))

    def _rows(self, account: str, source: str, media: MainMediaType) -> list:
        """Return the rows (`title`, `refs`) of the Discover / the Home of the account of the media ([] without a client)."""
        if (api := account_api(account, 'floppy')) is None:
            return []
        return api.discover_rows(media) if source == 'discover' else api.home_rows(media)

    @route('/rows/{source}/{media}')
    def rows(self, *, source: str, media: MainMediaType, account: str = 'floppy') -> None:
        """The Discover / the Home rows of the account (folders of their titles)."""
        thumb = self._thumb('featured' if source == 'discover' else 'main')
        with list_directory(view=const.indexer.lists_view) as kdir:
            for index, row in enumerate(self._rows(account, source, media)):
                kdir.folder(row['title'], info_for(self.row, account=account, source=source, media=media, index=index), thumb=thumb)

    @item_folder_route('/rows/{source}/{media}/{index}')
    def row(self, *, source: str, media: MainMediaType, index: int, page: PathArg[int] = 1, account: str = 'floppy') -> 'Folder':
        """The titles of a Discover / Home row of the account (its order)."""
        rows = self._rows(account, source, media)
        return Folder(rows[index]['refs'] if 0 <= index < len(rows) else [], page=page or 1, limit=const.indexer.floppy.page_size)
