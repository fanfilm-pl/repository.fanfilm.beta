from typing import Optional, Union, Sequence, ClassVar, TYPE_CHECKING
from ...ff.routing import route, info_for, EnumName
from ...defs import FFRef
from ...ff.item import FFItem
from ...ff.ownlists import OwnList
from ...ff.lists import show_list_image
from ..folder import item_folder_route, pagination, FolderRequest, list_directory
from . import ServiceLists
from ...kolang import L
from ...ff.logs import fflog
from const import const, CONST_REF
from cdefs import ListType, OwnListDef, When
if TYPE_CHECKING:
    from ...ff.menu import KodiDirectory


def _media_name(media: Optional[ListType]) -> Optional[str]:
    """Return the name of a single media of the flags (`movie`, `show`, `person`, `collection`), None for more or none."""
    if media is None:
        return None
    media &= ~ListType.LIST
    return next((name for name in ('movie', 'show', 'person', 'collection') if ListType.new(name) == media), None)


class OwnLists(ServiceLists):
    """
    The lists of FanFilm (the type `own`, one local account): the favorites, the watchlist and the own lists of
    `ownlists.db` by the client of lists (`lib.ff.ownlists.OwnListsClient`) like the lists of the account types.

    Only FanFilm has the lists defined by an address (`const.indexer.own.lists`): a list of lists (`list`) shown as
    folders, a list read from a file or a link (CSV, JSON).

    JSON format:
    >>> {
    >>>   "name": "LIST NAME",
    >>>   "type": "CONTENT_TYPE",
    >>>   "translations": {
    >>>     "pl": "PL NAME"
    >>>   },
    >>>   "items": [
    >>>     {
    >>>       "type": "MEDIA_TYPE(movie/show)",
    >>>       "tmdb": "TMDB_ID",
    >>>     },
    >>>     {
    >>>       "type": "list",
    >>>       "label": "Sub-list NAME",
    >>>       "url": "URL to the sub-list"
    >>>       "icon": "optional_icon_url",
    >>>     }, ...
    >>>   ]
    >>> }
    """

    TYPE: ClassVar[str] = 'own'
    CATEGORY: ClassVar[str] = L(30327, 'My Own Lists')

    # --- "My lists": the lists defined by an address (a list of lists expanded), not only the lists of the client ---

    @route('mine/{__media}')
    def mine(self, *, media: EnumName[ListType] = ListType.MIXED, account: str = '') -> None:
        """Show the own lists (of the `media`)."""
        with list_directory(view=const.indexer.own.mine.view) as kdir:
            self.add_mine(kdir, media=media or ListType.MIXED)

    def _add_mine(self, kdir: 'KodiDirectory', *, media: Optional[str] = None, account: str = '', role: str = '') -> None:
        """Add the own lists in a menu of lists (the definitions of `const.indexer.own.lists`)."""
        self.add_mine(kdir, media=ListType.new(media) if media else ListType.MIXED)

    def add_mine(self, kdir: 'KodiDirectory', *, media: ListType = ListType.MIXED) -> None:
        """
        Add the own lists of the `media`: the definitions; a list of lists - a folder or its lists in place
        (the folder point `own.sublists`), the list names as roles in place (the folder point `own.list_name`).
        """
        from ...ff.lists_config import folder_when
        media |= ListType.LIST  # always show lists
        own_lists = [lst for lst in const.indexer.own.lists if lst.match(media)]
        when = folder_when('own.sublists')
        show_role = when is not When.ALWAYS and folder_when('own.list_name')(len(own_lists))  # no lists in place: no roles
        for lst in own_lists:
            role = lst.title if show_role else None
            if lst.type is ListType.LIST:
                kdir.group(lst.title, info_for(self.list_list, url=lst.url, media=media), when=when,
                           add=lambda group, lst=lst, role=role: self._add_list_list(group, url=lst.url, media=media, role=role),
                           thumb=lst.icon or self._default_icon(lst.type))
            elif lst.match(media):
                if role is not None:
                    role = const.indexer.own.mine.root_direct_role.format(name=lst.title, type=lst.type)
                self._add_list_def(kdir, lst, media=media, role=role)

    @staticmethod
    def _default_icon(type: Union[ListType, str]) -> str:
        """Return the icon of a list of the media `type`."""
        if type == 'list':
            return 'services/own/lists.png'
        if type == 'show':
            return 'services/own/tvshows.png'
        if type == 'person':
            return 'services/own/persons.png'
        return 'services/own/movies.png'

    def _add_list_def(self, kdir: 'KodiDirectory', lst: OwnListDef, media: Optional[ListType] = None, *, role: Optional[str] = None) -> None:
        """Add a list definition: a list of lists or a list of media (of the `media`)."""
        if lst.type is ListType.LIST:
            kdir.folder(lst.title, info_for(self.list_list, url=lst.url, media=media), thumb=lst.icon or self._default_icon(lst.type), role=role)
        elif OwnListDef.type_match(lst.type, media):
            kdir.folder(lst.title, info_for(self.item_list, url=lst.url, type=lst.type or ListType.MIXED, media=media),
                        thumb=lst.icon or self._default_icon(lst.type), role=role)

    def _add_list_list(self, kdir: 'KodiDirectory', *, type: ListType = ListType.LIST, url: str, media: Optional[EnumName[ListType]] = None,
                       role: Optional[str] = None) -> None:
        """Add the lists of a list of lists (the lists of `ownlists.db` by the client route `list/{list_id}`)."""
        for it in OwnList(type=type, url=url).load():
            if isinstance(it, FFItem):
                it_url = it.vtag.getUniqueID('list-url')
                it_type = ListType.new(it.vtag.getUniqueID('list-type'))
                if it_type == 'list':
                    kdir.add(it, url=info_for(self.list_list, type=it_type, url=it_url, media=media), role=role, thumb='services/own/lists.png')
                elif OwnListDef.type_match(it_type, media):
                    if media is ListType.ALL:
                        media = None
                    if it_url.startswith('db://own/'):
                        show_list_image(it, self.TYPE, it_url[9:])
                        kwargs = {'media': name} if (name := _media_name(media)) else {}
                        kdir.add(it, url=info_for(self.user_list, list_id=it_url[9:], account=self.TYPE, **kwargs), role=role,
                                 thumb='services/own/lists.png')
                    else:
                        kdir.add(it, url=info_for(self.item_list, type=it_type, url=it_url, media=media), role=role, thumb='services/own/lists.png')

    @route('/list')
    def list_list(self, *, type: ListType = ListType.LIST, url: str, media: Optional[EnumName[ListType]] = None, account: str = '') -> None:
        """Show a list of lists defined by its address."""
        fflog(f'own list {media=}: {url=}')
        with list_directory(view=const.indexer.own.mine.view) as kdir:
            self._add_list_list(kdir, type=type, url=url, media=media)

    @item_folder_route('/list/type/{type}')
    @pagination(CONST_REF.indexer.own.page_size)
    def item_list(self, req: FolderRequest, /, *, type: EnumName[ListType], url: str, media: Optional[EnumName[ListType]] = None,
                  page: int = 1, account: str = '') -> Sequence[FFRef]:
        """Show a list of media defined by its address (a file, a link, a TMDB query)."""
        fflog(f'own media {type=}: {url=}')
        return OwnList(type=type or ListType.MIXED, url=url).load(page=page, media=media)
