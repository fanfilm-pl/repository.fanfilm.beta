"""
Menus of lists: `/lists` and the type menus, "My Movies / TV Shows / Persons", `/history` - one builder.

The entries of the accounts (`AccountEntry`, `entries(account)` of a type: derived from the client of the account) and the general lists of the
types are grouped by the ordered levels of the menu (`MenuDef.levels`: the kind of a list, the service type, the
account), a level is a folder by its `When`. A level shown by a folder above (or told by the menu itself) is not
repeated in the labels. One level is built at a time: a folder is the group route with its scope.
"""

from __future__ import annotations
from typing import Callable, Iterable, Sequence, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from attrs import frozen
from cdefs import ListKind, MenuLevel, When
from const import const
from ...ff.accounts import Account, ListMenuId, SERVICE_TYPES, accounts, account_in_menu, general_available
from ...ff.lists_config import folder_when, general_switched
from ...kolang import L
if TYPE_CHECKING:
    from ...ff.accounts import GeneralList
    from ...ff.menu import KodiDirectory, Target
    from ...defs import MediaOrPersonType

#: A media variant of an entry (`mixed` - all media together; `season`, `episode` - only without a media filter).
MediaVariant: TypeAlias = Literal['mixed', 'movie', 'show', 'season', 'episode', 'person', 'collection']

#: Thumb names of the kinds (`services/<type>/<name>.png`), the kind name if not here.
KIND_THUMBS: dict[str, str] = {'recommendations': 'featured', 'home': 'main', 'mylists': 'lists', 'general': 'main', 'upnext': 'progress'}


@frozen
class AccountEntry:
    """An entry of an account in the menus of lists: its kind (the label, thumb and order come from it) and targets."""

    #: The kind of the list.
    kind: ListKind
    #: The target of a media variant (None - the entry without variants; user lists: the media of the menu).
    target: Callable[[MediaVariant | None], Target]
    #: The media variants (empty - one target without media).
    variants: tuple[MediaVariant, ...] = ()
    #: User lists (`mylists`) only: the media the lists can have (a menu of another media does not show them).
    media: tuple[MediaOrPersonType, ...] = ()
    #: User lists only: add the lists of the account to the directory with the role (where they are from; flattened by the
    #: folder point `<type>.mine`, else `lists.mine`), None - a folder.
    inline: Callable[[KodiDirectory, MediaOrPersonType | None, str], None] | None = None


@frozen
class GeneralEntry:
    """
    A general list of a service type (no account, `ServiceLists.general_entries()`: its declaration, `ServiceType.general_lists`,
    with its targets): its key (the user switches, `lib.ff.lists_config`), label, targets of its media variants and the menus
    it is shown in by default.
    """

    #: The key of the list in the type (stable: the user switches are stored by it).
    key: str
    #: The label.
    label: str
    #: The target of a media variant (None - the list without variants).
    target: Callable[[MediaVariant | None], Target]
    #: The media variants (empty - one target without media, e.g. lists of lists: the menus without a media only).
    variants: tuple[MediaVariant, ...] = ()
    #: The thumb ('' - the one of the kind).
    thumb: str = ''
    #: The menus it is shown in by default (`ListMenuId`; the user switches, `lists_config.general_switched()`): none - the
    #: defaults are silent, the user switches a list on in the tab of general lists.
    places: tuple[ListMenuId, ...] = ()
    #: The target of the folder of its variants (None - the variants in place).
    folder: Target = None


@frozen
class MenuDef:
    """
    A menu of lists: its ID (`menu.<id>` switches of the accounts, the place of the general lists), its levels, kinds,
    media filter and the order of the types.
    """

    #: The menu ID.
    id: ListMenuId
    #: The ordered levels: the order groups and sorts the entries (kind: the entries of the kind, type: the service types
    #: side by side, account: the accounts of the type); a level is a folder by its `When` (`folder_when('<points>.<level>')`).
    levels: tuple[MenuLevel, ...]
    #: The kinds of lists shown, ordered (the order of the entries also inside an account); a missing kind is not shown.
    kinds: tuple[ListKind, ...]
    #: The prefix of the folder points of the levels (`lib.ff.lists_config.FOLDER_POINTS`).
    points: str
    #: The media of the menu (its entries of this media only), None - all.
    media: MediaOrPersonType | None = None
    #: The service types order; an unlisted type goes after the listed ones, in the registry order.
    types: tuple[str, ...] = ()

    def level_whens(self) -> list[tuple[MenuLevel, When]]:
        """Return the levels with their `When` (the user settings of the folders)."""
        return [(level, folder_when(f'{self.points}.{level}')) for level in self.levels]


#: The levels of the menus of lists.
LEVELS: tuple[MenuLevel, ...] = ('type', 'account', 'kind')
#: The kinds of the menus of lists in their order.
KINDS: tuple[ListKind, ...] = ('watchlist', 'favorites', 'collection', 'history', 'progress', 'upnext', 'calendar', 'recommendations',
                               'home', 'ratings', 'likes', 'mylists', 'general')

#: The menus of lists.
MENUS: dict[ListMenuId, MenuDef] = {menu.id: menu for menu in (
    MenuDef('lists', LEVELS, KINDS, 'lists'),
    MenuDef('movies', LEVELS, KINDS, 'my', media='movie'),
    MenuDef('shows', LEVELS, KINDS, 'my', media='show'),
    MenuDef('persons', LEVELS, KINDS, 'my', media='person'),
    MenuDef('history', LEVELS, ('history',), 'history'),
)}


@frozen
class MenuScope:
    """
    The folder of a menu: the values of the levels shown by the folders above. The kind in an account is the folder of the
    entry of the account (its media variants). In a URL it is a pointer `<account|type|*>[:<kind>]` (`scope_pointer()`).
    """

    #: The kind of lists of the folder ('' - any).
    kind: str = ''
    #: The service type of the folder ('' - any).
    type: str = ''
    #: The account of the folder ('' - any).
    account: str = ''


def scope_pointer(scope: MenuScope) -> str:
    """Return the pointer of the scope in a URL: `<account|type|*>[:<kind>]` ('' - the menu itself)."""
    service = scope.account or scope.type
    if not scope.kind:
        return service
    return f'{service or "*"}:{scope.kind}'


def pointer_scope(pointer: str) -> MenuScope:
    """Return the scope of the pointer of a URL (`scope_pointer()`; `:<kind>` too): a type name is the type (all its accounts)."""
    from ...ff.accounts import get_account
    service, _, kind = pointer.partition(':')
    if service in ('', '*'):
        return MenuScope(kind=kind)
    if service in SERVICE_TYPES:
        return MenuScope(kind=kind, type=service)
    acc = get_account(service)
    return MenuScope(kind=kind, type=acc.type.name if acc is not None else service.partition('.')[0], account=service)


@frozen
class MenuItem:
    """An entry of the menu: of an account (`entry`) or a general list of a type (`general`)."""

    #: The kind of the list.
    kind: ListKind
    #: The service type name.
    type_name: str
    #: The account (None - a general list).
    account: Account | None = None
    #: The entry of the account.
    entry: AccountEntry | None = None
    #: The general list (label, target, thumb).
    general: GeneralEntry | None = None


@frozen
class MenuNode:
    """A directory item of a menu level: a folder / a list, or lists added in place (`inline`)."""

    #: The label.
    label: str = ''
    #: The target.
    target: Target = None
    #: The thumb.
    thumb: str = ''
    #: The description (the nick of the account).
    descr: str = ''
    #: The role: where the entry is from (the service, the nick), shown by `const.folder.style.role`.
    role: str = ''
    #: Adds the items itself (flattened user lists).
    inline: Callable[[KodiDirectory], None] | None = None


def media_kw(variant: MediaVariant | MediaOrPersonType | None, *, mixed: object = None) -> dict[str, object]:
    """Return the `media` argument of a route for the variant: none for the mixed one (or `mixed` if given)."""
    if variant is None or variant == 'mixed':
        return {} if mixed is None else {'media': mixed}
    return {'media': variant}


def kind_label(kind: str) -> str:
    """Return the label of the kind of lists."""
    return {
        'watchlist': L(32033, 'Watchlist'), 'favorites': L(30146, 'Favorites'), 'collection': L(32032, 'Collection'),
        'history': L(32036, 'History'), 'progress': L(32883, 'Progress'), 'upnext': L(30640, 'Next episodes'), 'calendar': L(30626, 'Calendar'),
        'recommendations': L(30131, 'Recommendations'), 'home': L(30298, 'Home rows'), 'ratings': L(30546, 'Ratings'), 'likes': L(30144, 'Likes'),
        'mylists': L(30149, 'My Lists'), 'general': L(30628, 'General lists'),
    }.get(kind, kind)


def variant_label(variant: str) -> str:
    """Return the label of the media variant."""
    return {
        'mixed': L(30655, 'Mixed'), 'movie': L(32001, 'Movies'), 'show': L(32002, 'TV Shows'), 'season': L(30302, 'Seasons'),
        'episode': L(30303, 'Episodes'), 'person': L(30175, 'Persons'), 'collection': L(30145, 'Collections'),
    }.get(variant, variant)


def type_indexer(type_name: str) -> object | None:
    """Return the menu indexer of the service type (`nav.trakt`, ...), None if it has none."""
    from ..navigator import nav
    return getattr(nav, type_name, None) if type_name in SERVICE_TYPES else None


def type_order(types: Iterable[str]) -> list[str]:
    """Return the type names of the menus: the listed ones in their order, then the rest in the registry order."""
    listed = [name for name in types if name in SERVICE_TYPES]
    return [*listed, *(name for name in SERVICE_TYPES if name not in listed)]


def entry_media_match(entry: AccountEntry | GeneralEntry | GeneralList, media: MediaOrPersonType | None) -> bool:
    """Return True if the entry has something for the media of the menu (None - any)."""
    if media is None:
        return True
    if isinstance(entry, AccountEntry) and entry.media:
        return media in entry.media
    return media in entry.variants


def general_in_menu(type_name: str, entry: GeneralEntry, menu: MenuDef) -> bool:
    """Return True if the general list of the type is in the menu: it has something for its media and the user switches are on."""
    return entry_media_match(entry, menu.media) and general_switched(type_name, entry.key, menu.id, menu.id in entry.places)


def menu_items(menu: MenuDef, scope: MenuScope = MenuScope()) -> tuple[list[MenuItem], list[ListKind]]:
    """Return the items of the menu in the scope (sorted by the levels) and the kinds of the menu in their order."""
    kinds: list[ListKind] = list(menu.kinds)
    order = type_order(menu.types)
    acc_order = {acc.id: i for i, acc in enumerate(accounts())}
    items: list[MenuItem] = []
    for type_name in order:
        if scope.type and type_name != scope.type:
            continue
        if (indexer := type_indexer(type_name)) is None or not hasattr(indexer, 'entries'):
            continue
        for acc in accounts():
            if acc.type.name != type_name or not acc.active or not account_in_menu(acc, menu.id):  # a suspended account affects nothing
                continue
            if scope.account and acc.id != scope.account:
                continue
            for entry in indexer.entries(acc.id):  # type: ignore[attr-defined]
                if entry.kind in kinds and entry_media_match(entry, menu.media) and (not scope.kind or entry.kind == scope.kind):
                    items.append(MenuItem(entry.kind, type_name, acc, entry=entry))
        if ('general' in kinds and not scope.account and scope.kind in ('', 'general') and hasattr(indexer, 'general_entries')
                and general_available(type_name)):
            items.extend(MenuItem('general', type_name, general=gen) for gen in indexer.general_entries()  # type: ignore[attr-defined]
                         if general_in_menu(type_name, gen, menu))

    def key(item: MenuItem) -> tuple[int, ...]:
        values = {'kind': kinds.index(item.kind), 'type': order.index(item.type_name),
                  'account': acc_order.get(item.account.id, -1) if item.account else len(acc_order)}
        return tuple(values[level] for level in menu.levels)

    items.sort(key=key)  # stable: the order of the entries of a type stays for the same keys
    return items, kinds


class MenuBuilder:
    """Builds one level of a menu: the folders of the groups and the entries (labels by the shown levels)."""

    def __init__(self, menu: MenuDef, scope: MenuScope, *, route: Callable[[MenuScope], Target]) -> None:
        self.menu = menu
        self.scope = scope
        self.route = route
        self.items, self.kinds = menu_items(menu, scope)
        all_kinds = {item.kind for item in menu_items(menu)[0]} if not scope.kind else {scope.kind}
        #: The menu tells the kind (one kind in it, e.g. `/history`), as the media filter tells the media.
        self.kind_told = len(all_kinds) == 1
        self.acc_count: dict[str, int] = {}
        for acc_id, type_name in {(it.account.id, it.type_name) for it in self.items if it.account}:
            self.acc_count[type_name] = self.acc_count.get(type_name, 0) + 1

    def nodes(self) -> list[MenuNode]:
        """Return the nodes of the level of the scope."""
        shown: set[MenuLevel] = {level for level in ('kind', 'type', 'account') if getattr(self.scope, level)}
        if self.scope.account:
            shown.add('type')  # the account title tells its type
        if self.kind_told:
            shown.add('kind')
        levels: list[tuple[MenuLevel, When]] = [(level, when) for level, when in self.menu.level_whens() if level not in shown]
        return self._group(self.items, levels, shown, self.scope)

    # --- groups ---

    def _group(self, items: Sequence[MenuItem], levels: Sequence[tuple[MenuLevel, When]], shown: set[MenuLevel],
               scope: MenuScope) -> list[MenuNode]:
        """Return the nodes of the items grouped by the levels (a level is a folder by its When, else it is skipped)."""
        if not levels:
            return [node for item in items for node in self._entry(item, shown, scope)]
        (level, when), rest = levels[0], levels[1:]
        out: list[MenuNode] = []
        i = 0
        while i < len(items):
            item = items[i]
            if level == 'account' and item.account is None:  # general lists have no account: the level is skipped
                out.extend(self._group([item], rest, shown, scope))
                i += 1
                continue
            value = self._value(level, item)
            j = i
            while j < len(items) and (level != 'account' or items[j].account) and self._value(level, items[j]) == value:
                j += 1
            group = items[i:j]
            group_when = when
            if level == 'kind':
                count = len(group)
                if item.kind == 'general' and self.menu.id == 'lists':
                    group_when = folder_when('lists.general')  # the general lists have their own When
                if self.kind_told:
                    group_when = When.NEVER
            elif level == 'type':
                count = len({it.type_name for it in items})
            else:
                count = len({it.account.id for it in items if it.account and it.type_name == item.type_name})
            if group_when(count):
                sub = MenuScope(**{**{f: getattr(scope, f) for f in ('kind', 'type', 'account')}, level: value})
                if level == 'account':
                    sub = MenuScope(kind=sub.kind, type=item.type_name, account=value)
                out.append(self._folder(level, item, sub))
            else:
                out.extend(self._group(group, rest, shown, scope))
            i = j
        return out

    @staticmethod
    def _value(level: MenuLevel, item: MenuItem) -> str:
        """Return the value of the item on the level."""
        if level == 'kind':
            return item.kind
        if level == 'type':
            return item.type_name
        return item.account.id if item.account else ''

    def _folder(self, level: MenuLevel, item: MenuItem, scope: MenuScope) -> MenuNode:
        """Return the folder of the group of the level."""
        if level == 'kind':
            return MenuNode(kind_label(item.kind), self.route(scope), thumb=self._thumb(item.type_name, item.kind))
        if level == 'type':
            return MenuNode(SERVICE_TYPES[item.type_name].label, self.route(scope), thumb=f'services/{item.type_name}/main.png')
        from ...ff.account_admin import account_title, account_nick
        assert item.account is not None
        return MenuNode(account_title(item.account), self.route(scope), thumb=f'services/{item.type_name}/main.png',
                        descr=account_nick(item.account))

    # --- entries ---

    def _label(self, item: MenuItem, shown: set[MenuLevel], *, base: str | None = None, media: str | None = None,
               pattern: str | None = None, empty: bool = False) -> tuple[str, str]:
        """
        Return the label and the role of an entry: what it is (the kind or the own `base` name, the media variant) in the
        label, where it is from (the service, the nick if the type has more accounts) in the role - only what the folders
        above (and the menu) do not tell. Without the role format (`const.folder.style.role`) or with nothing else in the
        label, where it is from goes to the label. `empty` - '' if all is told (else the kind).
        """
        label = base if base is not None else ('' if 'kind' in shown else kind_label(item.kind))
        if media:
            label = L(30656, '{list}: {media}').format(list=label, media=variant_label(media)) if label else variant_label(media)
        service = '' if 'type' in shown else SERVICE_TYPES[item.type_name].label
        nick = ''
        if item.account and 'account' not in shown and self.acc_count.get(item.type_name, 0) > 1:
            from ...ff.account_admin import account_tag
            nick = account_tag(item.account)
        if label and const.folder.style.role:
            if pattern and base is None and service:
                label = kind_label(item.kind)  # "My Lists" with the service in the role
            role = f'{service} ({nick})' if service and nick else (service or nick)
            return label, role
        if service:
            if not label:
                label = service
            elif pattern and base is None and 'kind' not in shown:
                label = pattern.format(service=service)
            else:
                label = L(30657, '{service} {list}').format(service=service, list=label)
        if nick:
            label = f'{label} ({nick})' if label else nick
        if not label and not empty:
            label = kind_label(item.kind)
        return label, ''

    def _thumb(self, type_name: str, kind: str) -> str:
        """Return the thumb of the entry."""
        return f'services/{type_name}/{KIND_THUMBS.get(kind, kind)}.png'

    def _entry(self, item: MenuItem, shown: set[MenuLevel], scope: MenuScope) -> list[MenuNode]:
        """Return the nodes of an entry (a list, the folder of its variants or its variants, the user lists)."""
        thumb = self._thumb(item.type_name, item.kind)
        if item.general is not None:
            return self._general(item, shown)
        entry, acc = item.entry, item.account
        assert entry is not None and acc is not None
        from ...ff.account_admin import account_nick
        descr = account_nick(acc)
        media = self.menu.media
        if entry.media:  # user lists
            return self._user_lists(item, shown, media, descr=descr, thumb=thumb)
        if not entry.variants:
            label, role = self._label(item, shown)
            return [MenuNode(label, entry.target(None), thumb=thumb, descr=descr, role=role)]
        variants: list[MediaVariant] = [v for v in entry.variants if media is None or v == media]
        if len(variants) == 1:
            told = media is not None or len(entry.variants) == 1  # the menu or the entry tells its media
            label, role = self._label(item, shown, media=None if told else variants[0])
            return [MenuNode(label, entry.target(variants[0]), thumb=thumb, descr=descr, role=role)]
        if folder_when('lists.media')(len(variants)):
            label, role = self._label(item, shown, empty=True)
            if not label:  # the folders above tell everything: no folder of its own
                return self._variant_nodes(entry, variants, thumb=thumb, descr=descr)
            sub = MenuScope(kind=item.kind, type=item.type_name, account=acc.id)  # the kind in the account: the variants
            return [MenuNode(label, self.route(sub), thumb=thumb, descr=descr, role=role)]
        nodes: list[MenuNode] = []
        for v in variants:
            label, role = self._label(item, shown, media=v)
            nodes.append(MenuNode(label, entry.target(v), thumb=thumb, descr=descr, role=role))
        return nodes

    def _general(self, item: MenuItem, shown: set[MenuLevel]) -> list[MenuNode]:
        """Return the nodes of a general list: the list, the folder of its variants or its variants (as an entry of an account)."""
        gen = item.general
        assert gen is not None
        thumb = gen.thumb or self._thumb(item.type_name, item.kind)
        media = self.menu.media
        variants: list[MediaVariant] = [v for v in gen.variants if media is None or v == media]
        if len(variants) <= 1:
            told = media is not None or len(gen.variants) <= 1  # the menu or the list tells its media
            label, role = self._label(item, shown, base=gen.label, media=None if told or not variants else variants[0])
            return [MenuNode(label, gen.target(variants[0] if variants else None), thumb=thumb, role=role)]
        if gen.folder is not None and folder_when('lists.media')(len(variants)):
            label, role = self._label(item, shown, base=gen.label)
            return [MenuNode(label, gen.folder, thumb=thumb, role=role)]
        nodes: list[MenuNode] = []
        for v in variants:
            label, role = self._label(item, shown, base=gen.label, media=v)
            nodes.append(MenuNode(label, gen.target(v), thumb=thumb, role=role))
        return nodes

    @staticmethod
    def _variant_nodes(entry: AccountEntry, variants: Sequence[MediaVariant], *, thumb: str, descr: str) -> list[MenuNode]:
        """Return the variants of an entry (in its folder): the media labels."""
        return [MenuNode(variant_label(v), entry.target(v), thumb=thumb, descr=descr) for v in variants]

    def _user_lists(self, item: MenuItem, shown: set[MenuLevel], media: MediaOrPersonType | None, *, descr: str,
                    thumb: str) -> list[MenuNode]:
        """Return the user lists of the account: a "My Lists" folder or the lists in place (`<type>.mine`, else `lists.mine` folder point)."""
        entry = item.entry
        assert entry is not None
        label, role = self._label(item, shown, pattern=L(30658, 'My {service} lists'))
        folder = MenuNode(label, entry.target(media), thumb=thumb, descr=descr, role=role)
        when = folder_when(f'{item.type_name}.mine', base='lists.mine')
        if entry.inline is None or when is When.ALWAYS:
            return [folder]
        inline = entry.inline

        def add(kdir: KodiDirectory) -> None:
            kdir.group(folder.label, folder.target, when=when, add=lambda group: inline(group, media, role),
                       thumb=folder.thumb, descr=folder.descr, role=folder.role or None)

        return [MenuNode(inline=add)]


def menu_route(menu_id: ListMenuId) -> Callable[[MenuScope], Target]:
    """
    Return the target of a group folder of the menu: a type or an account of `/lists` is its type menu (`/trakt`,
    `/trakt.x`), else the menu route with the pointer of the scope (`/list/trakt.x:watchlist`, `/movie/lists/trakt`).
    """
    from ..navigator import Navigator, nav
    from ...ff.routing import url_for
    scoped = {'lists': nav.lists, 'movies': nav.movie.lists, 'shows': nav.show.lists, 'persons': nav.person.lists,
              'history': nav.history.accounts}[menu_id]

    def route(scope: MenuScope) -> Target:
        if menu_id == 'lists' and scope.type and not scope.kind and hasattr(Navigator, scope.type):
            if scope.account and scope.account != scope.type:
                if (indexer := type_indexer(scope.type)) is not None and hasattr(indexer, 'home'):
                    return url_for(indexer.home, account=scope.account)  # type: ignore[attr-defined]
            else:
                return url_for(getattr(Navigator, scope.type))
        return url_for(scoped, scope=scope_pointer(scope))

    return route


def add_menu_level(kdir: KodiDirectory, menu_id: ListMenuId, scope: MenuScope = MenuScope()) -> None:
    """Add the level of the menu in the scope to the directory."""
    add_menu(kdir, build_menu(menu_id, scope, route=menu_route(menu_id)))


def menu_has_items(menu_id: ListMenuId) -> bool:
    """Return True if the menu has something (an account shown in it with entries for its media), e.g. "My Movies" in the root menu."""
    return bool(menu_items(MENUS[menu_id])[0])


def menu_directory(menu_id: ListMenuId, scope: MenuScope = MenuScope()) -> None:
    """Show the level of the menu in the scope (a group folder)."""
    from ..folder import list_directory
    view = const.indexer.lists_view if menu_id == 'lists' else const.indexer.my_lists_view
    with list_directory(view=view) as kdir:
        add_menu_level(kdir, menu_id, scope)


def build_menu(menu_id: ListMenuId, scope: MenuScope = MenuScope(), *, route: Callable[[MenuScope], Target]) -> list[MenuNode]:
    """Return the nodes of the level of the menu in the scope; `route` - the target of a group folder."""
    return MenuBuilder(MENUS[menu_id], scope, route=route).nodes()


def add_menu(kdir: KodiDirectory, nodes: Iterable[MenuNode]) -> None:
    """Add the nodes of a menu level to the directory."""
    for node in nodes:
        if node.inline is not None:
            node.inline(kdir)
        else:
            kdir.folder(node.label, node.target, thumb=node.thumb or None, descr=node.descr, role=node.role or None)
