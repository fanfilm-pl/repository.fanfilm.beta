from typing import Optional
from typing_extensions import Literal
from . import ServiceLists, account_api
from ...ff.routing import route, info_for
from ..folder import list_directory
from ...defs import ItemList
from const import const


ListMediaType = Literal['movie', 'show', 'episode', 'person']


class ImdbLists(ServiceLists):
    """IMDb: the lists of accounts (the base), the lists of other users."""

    TYPE = 'imdb'

    @route('/mine/{user}/{__page}')
    def user(self, *, media: Optional[ListMediaType] = None, user: str, page: int = 1, account: str = 'imdb') -> None:
        """Show the lists of another IMDb user."""
        api = account_api(account, 'imdb')
        items = api.user_lists(user, page=page, list_type=media) if api is not None else ItemList.empty()
        with list_directory(items, view=const.indexer.imdb.mine.view) as kdir:
            for it in items:
                kdir.add(it, url=info_for(self.user_list, list_id=it.vtag.getIMDBNumber(), media=media, account=account), thumb='services/imdb/lists.png')

    # --- OBSOLETED: URLs of master-202609 (widgets, Kodi favourites) ---

    @route
    def watchlists(self, *, account: str = 'imdb') -> None:
        """OBSOLETED: use the media variants of the watchlist in the menu of lists."""
        self._entry_menu('watchlist', account)
