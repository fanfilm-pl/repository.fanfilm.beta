
from typing import Callable, Dict, List, Optional, TYPE_CHECKING
from ...defs import MainMediaType, Pagina
from . import ServiceLists, account_api
from .menu import AccountEntry
from ...ff.routing import route, info_for, subobject, PathArg
from ...ff import control
from ..folder import Folder, item_folder_route, list_directory
from ..search import Search
from ...api.mdblist import MdbList
from ...kolang import L
from const import const
if TYPE_CHECKING:
    from .menu import MediaVariant
    from ...ff.item import FFItem
    from ...ff.menu import Target
    from ...ff.types import PagedItems


class MDBListIndexer(ServiceLists):
    """Indexer for MDBList service (user lists)."""

    TYPE = 'mdblist'

    def type_entries(self, account: str) -> List['AccountEntry']:
        """Return the entries of MDBList itself: the next episodes (`upnext`), liked lists."""
        return [AccountEntry('upnext', lambda v: info_for(self.upnext, account=account), ('show',)),
                AccountEntry('likes', lambda v: info_for(self.likes, account=account))]

    def general_targets(self) -> 'Dict[str, Callable[[Optional[MediaVariant]], Target]]':
        """Return the targets of the general lists of MDBList (lists of other users, they need a key: the application client)."""
        return {'popular_lists': lambda v: info_for(self.top_lists), 'list_search': lambda v: info_for(self.list_search)}

    @item_folder_route('/upnext')
    def upnext(self, *, page: PathArg[int] = 1, account: str = 'mdblist') -> Folder:
        """The next episodes of the shows in progress of the account (MDBList), the last watched show first."""
        if (api := self._api(account)) is None:
            return Folder([])
        return Folder(api.upnext(page=page or None), alone=True, link=const.indexer.tvshows.progress.episode_folder)

    @route('/user/{user}/lists/{__page}')
    def user_lists(self, user: str, *, page: int = 1, media: Optional[MainMediaType] = None, account: str = 'mdblist'):
        """Show the user lists."""
        if (mdblist := self._api(account)) is None:
            return
        items = sorted(mdblist.user_lists(user=user, media=media), key=lambda x: x.title.lower())
        items = Pagina(items, page=page, limit=const.indexer.mdblist.lists_page_size)
        self.show_lists(items, media=media, account=account)

    def _api(self, account: str, capability: str = 'lists') -> Optional[MdbList]:
        """Return the client of the account (the budget of its key), None if it may not read the `capability`."""
        return account_api(account, 'mdblist', capability)

    def show_lists(self, items: 'PagedItems[FFItem]', *, media: Optional[MainMediaType] = None, account: str = 'mdblist') -> None:
        """Show list of lists."""
        with list_directory(items, view=const.indexer.mdblist.top.view) as kdir:
            for it in items:
                if it.getProperty('mdblist.liked').lower() == 'true':
                    menu = [(L(30660, 'Unlike'), info_for(self.unlike_list, list_id=it.ffid, account=account))]
                else:
                    menu = [(L(30661, 'Like'), info_for(self.like_list, list_id=it.ffid, account=account))]
                if uid := it.getProperty('mdblist.user_id'):
                    user = it.getProperty('mdblist.user_name') or uid
                    menu.append((L(30662, 'User {user} lists').format(user=user), info_for(self.user_lists, user=uid, media=media, account=account)))
                kdir.add(it, url=info_for(self.user_list, list_id=it.ffid, media=media, account=account), thumb='services/mdblist/lists.png', menu=menu)
            # Sort methods don't work with pagination, so add them only if not paginating or all items are on the first page.
            if (total_pages := getattr(items, 'total_pages', 0)) and total_pages < 2:
                # TODO: sort (XXX XXX XXX)
                import xbmcplugin
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_NONE, '%L', '%P')
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_UNSORTED, '%L', '%P')
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_TITLE, '%L')
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR, '%L', '%Y')
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_DURATION, '%L', '%D')  # Kodi sucks! Ratings are supported on folders.
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_VIDEO_RATING, '%L', '%R')  # Kodi sucks! Ratings are supported on folders.
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_DATEADDED, '%L')
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_TRACKNUM, '%L')

    @route('/top/{__page}')
    def top_lists(self, *, page: int = 1, media: Optional[MainMediaType] = None):
        """Show top lists (general: the application client)."""
        from ...api.mdblist import mdblist_app
        self.show_lists(mdblist_app.top_lists(media=media, page=page), media=media)

    @route('/likes/{__page}')
    def likes(self, *, page: int = 1, account: str = 'mdblist'):
        """Show top lists."""
        if (mdblist := self._api(account)) is None:
            return
        items = mdblist.liked_list(page=page)
        self.show_lists(items, account=account)

    @route('/list/{list_id}/like')
    def like_list(self, list_id: int, *, account: str = 'mdblist'):
        """Unlike a list."""
        from ...ff.control import notification
        if (mdblist := self._api(account)) is not None and mdblist.like_list(list_id=list_id):
            notification(L(30663, 'FanFilm'), L(30664, 'List liked'), sound=False, visible=True)
        else:
            notification(L(30663, 'FanFilm'), L(30665, 'Like list FAILED'), icon='ERROR', visible=True)

    @route('/list/{list_id}/unlike')
    def unlike_list(self, list_id: int, *, account: str = 'mdblist'):
        """Unlike a list."""
        from ...ff.control import notification
        if (mdblist := self._api(account)) is not None and mdblist.unlike_list(list_id=list_id):
            notification(L(30663, 'FanFilm'), L(30666, 'List unliked'), sound=False, visible=True)
        else:
            notification(L(30663, 'FanFilm'), L(30667, 'Unlike list FAILED'), icon='ERROR', visible=True)

    @subobject
    def list_search(self) -> 'Search':
        """Search lists."""

        def search_items(query: str, *, page: int = 1, type: Optional[str] = None, **filters) -> None:
            from ...api.mdblist import mdblist_app
            self.show_lists(mdblist_app.list_search(query, page=page))  # general: the application client

        return Search(search_items, name='mdblist.list', type='list')
