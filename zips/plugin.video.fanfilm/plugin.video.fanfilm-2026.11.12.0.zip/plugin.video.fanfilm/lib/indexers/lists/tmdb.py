from . import ServiceLists
from ...ff.routing import route, PathArg


class TmdbLists(ServiceLists):
    """TMDB: the lists of accounts (the base)."""

    TYPE = 'tmdb'

    # --- OBSOLETED: URLs of master-202609 (widgets, Kodi favourites) ---

    @route('favorite/{media}')
    def favorite(self, media: str = 'movie,show', *, page: PathArg[int] = 1, account: str = 'tmdb') -> None:
        """OBSOLETED: use `favorites()` (`favorites/{media}`)."""
        self.favorites(media=media, page=page, account=account)

    @route
    def watchlists(self, *, account: str = 'tmdb') -> None:
        """OBSOLETED: use the media variants of the watchlist in the menu of lists."""
        self._entry_menu('watchlist', account)
