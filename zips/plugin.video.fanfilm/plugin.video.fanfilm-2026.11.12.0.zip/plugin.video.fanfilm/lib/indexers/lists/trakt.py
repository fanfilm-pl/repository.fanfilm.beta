from typing import Callable, Dict, Optional, Sequence, ClassVar, List, Tuple, TYPE_CHECKING
from ..folder import item_folder_route, pagination, ApiPage, FolderRequest, list_directory, Folder
from ...ff.routing import route, url_for, info_for, PathArg
from ...ff.item import FFItem
from ...api import ALL_PAGES
from ...api.trakt import trakt_app
from . import ServiceLists, account_api
from .menu import AccountEntry, media_kw
from ...ff.calendar import day_label
from ...api.trakt import UserGeneralListType as TraktUserGeneralListType, SortType as TraktSortType
from ...defs import MainMediaTypeList, MediaOrPersonType, Pagina
from const import const, CONST_REF
if TYPE_CHECKING:
    from .menu import MediaVariant
    from ...ff.menu import Target


class TraktLists(ServiceLists):
    """Trakt: the lists of accounts (the base), recommendations, the calendar, the history from the service, lists of other users."""

    TYPE = 'trakt'
    # Fale user name for official list.
    OFFICIAL: ClassVar[str] = '-'

    def type_entries(self, account: str) -> List['AccountEntry']:
        """Return the entries of Trakt itself: liked lists, recommendations, the calendar."""
        variants: 'Tuple[MediaVariant, ...]' = ('mixed', 'movie', 'show')
        return [
            AccountEntry('likes', lambda v: url_for(self.likes, account=account)),
            AccountEntry('recommendations', lambda v: info_for(self.recommendation, account=account, **media_kw(v)), variants),
            AccountEntry('calendar', lambda v: info_for(self.calendarium, media='show', account=account), ('show',)),
        ]

    def general_targets(self) -> 'Dict[str, Callable[[Optional[MediaVariant]], Target]]':
        """Return the targets of the general lists of Trakt (lists of other users)."""
        return {'trending_lists': lambda v: url_for(self.user_general, list_type='trending'),
                'popular_lists': lambda v: url_for(self.user_general, list_type='popular')}

    def history_folder(self, media: Optional[str], page: int, account: str) -> Folder:
        """Return the history of the account from Trakt (the watched date in the role)."""
        from ...ff.progress import played_role
        if (api := account_api(account, 'trakt')) is None:
            return Folder([])
        items = api.user_generic_list('history', media_type=media, page=page or ALL_PAGES)
        for it in items:
            if date := it.vtag.getLastPlayedDateTime():
                it.role = played_role(date)
        return Folder(items, alone=True)

    @route
    def likes(self, *, page: PathArg[int] = 1, user: str = 'me', account: str = 'trakt') -> None:
        """The lists the user liked."""
        api = account_api(account, 'trakt')
        with list_directory(view=const.indexer.lists_view) as kdir:
            for it in (() if api is None else api.user_generic_list('likes')):
                kdir.add(it, url=info_for(self.user_list_of, list_id=it.vtag.getUniqueID('trakt.list'),
                                          user=it.vtag.getUniqueID('trakt.user') or self.OFFICIAL, account=account))

    @item_folder_route
    def recommendation(self,
                       req: FolderRequest,  # extra item added by @itemfolder_route
                       /, *,
                       media: PathArg[MainMediaTypeList] = 'movie,show',
                       page: PathArg[int] = 1,
                       account: str = 'trakt',
                       ) -> Sequence[FFItem]:
        """Recommendations of the account."""
        limit = const.trakt.page.limit  # items per page
        if (api := account_api(account, 'trakt')) is None:
            return []
        items = api.recommendations(media, limit=const.trakt.recommendations_limit, chunk=limit//2)  # limit=100 max recommendations (many pages)
        if req.as_library:
            return items
        return Pagina(items, page=page, limit=limit)

    @item_folder_route
    @pagination(CONST_REF.trakt.page.limit)
    def calendarium(self, media: PathArg[MainMediaTypeList] = 'movie,show', *, page: PathArg[int] = 1, account: str = 'trakt'):
        """Calendarium of the account - mainly for tvshows."""
        def role(it: FFItem, index: int) -> str:
            return day_label(it.date, week_without_date=False)
        if (api := account_api(account, 'trakt')) is None:
            return Folder([])
        chunk = const.trakt.page.limit // 2 if page else 0
        items = api.calendarium(media, chunk=chunk)  # limit=100 max recommendations (many pages)
        return Folder(items, role_format=role)

    @item_folder_route('/list/{user}/{list_id}')
    @pagination(CONST_REF.trakt.page.limit, api=ApiPage(size=20, min=10, max=100))
    def user_list_of(self,
                     req: FolderRequest,  # extra item added by @itemfolder_route
                     /, *,
                     list_id: str,
                     page: PathArg[int] = 1,
                     user: str = 'me',
                     media: Optional[MediaOrPersonType] = None,
                     sort: Optional[TraktSortType] = 'trakt',
                     account: str = 'trakt',
                     ) -> Sequence[FFItem]:
        """
        A list of another user (liked, official, general): public, the application client.
        OBSOLETED: `list/me/{list_id}` (an own list, URLs of master-202609) - use `user_list()` (`list/{list_id}`).
        """
        if user == 'me':  # OBSOLETED: an own list
            if (api := account_api(account, 'trakt')) is None:
                return []
            return Folder(api.list_items(list_id, media=media, page=page or None), list_spec='{account}:user:{list_id}')
        if not req.pagination:
            sort = None
        if not user or user == self.OFFICIAL:
            return trakt_app.the_list(list_id, page=page, media_type=media)
        return trakt_app.user_list_items(list_id, user=user, media_type=media, sort=sort)

    @route('/{list_type}')
    def user_general(self, list_type: TraktUserGeneralListType, *, page: PathArg[int] = 1) -> None:
        items = trakt_app.user_general_lists(list_type, page=page)
        with list_directory(items, view=const.indexer.lists_view) as kdir:
            for it in items:
                kdir.add(it, url=info_for(self.user_list_of, list_id=it.vtag.getUniqueID('trakt.list'),
                                          user=it.vtag.getUniqueID('trakt.user') or self.OFFICIAL),
                         thumb='services/trakt/lists.png')

    # --- OBSOLETED: URLs of master-202609 (widgets, Kodi favourites); `list/me/{list_id}`: in `user_list_of()` ---

    @route
    def collections(self, *, account: str = 'trakt') -> None:
        """OBSOLETED: use the media variants of the collection in the menu of lists."""
        self._entry_menu('collection', account)

    @route
    def recommendations(self, *, account: str = 'trakt') -> None:
        """OBSOLETED: use the media variants of the recommendations in the menu of lists."""
        self._entry_menu('recommendations', account)
