from . import ServiceLists


class KodiLists(ServiceLists):
    """The local Kodi: the history and the shows in progress of Kodi video DB (no lists, no ratings)."""

    TYPE = 'kodi'
