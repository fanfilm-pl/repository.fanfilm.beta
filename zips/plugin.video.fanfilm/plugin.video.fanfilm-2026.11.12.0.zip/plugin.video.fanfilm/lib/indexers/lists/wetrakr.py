from typing import Callable, Dict, List, Optional, TYPE_CHECKING
from . import ServiceLists, account_api
from .menu import AccountEntry, media_kw
from ...ff.routing import route, info_for, url_for, subobject, PathArg
from ..folder import Folder, item_folder_route, list_directory
from const import const
from ...kolang import L
from ...defs import MainMediaType, MediaOrPersonType, ItemList, MediaRef
from ...ff.item import FFItem
from ..search import Search
if TYPE_CHECKING:
    from .menu import MediaVariant
    from ...ff.menu import Target


class WeTrakrLists(ServiceLists):
    """WeTrakr: the lists of accounts - watchlist (`planning`), favorites, own lists."""

    TYPE = 'wetrakr'

    def type_entries(self, account: str) -> List['AccountEntry']:
        """Return the entries of WeTrakr itself: liked lists, the calendar of the titles the user tracks."""
        return [
            AccountEntry('likes', lambda v: url_for(self.likes, account=account)),
            AccountEntry('calendar', lambda v: info_for(self.calendar, account=account, mode='following', **media_kw(v)), ('movie', 'show')),
        ]

    @route('/likes')
    def likes(self, *, account: str = 'wetrakr') -> None:
        """Show the public lists the user liked."""
        api = account_api(account, 'wetrakr')
        self.show_lists(ItemList.single(api.liked_lists() if api is not None else []))

    @item_folder_route('/calendar/{media}')
    def calendar(self, *, media: MainMediaType, mode: str = 'discover', milestone: str = '', page: PathArg[int] = 1,
                 account: str = 'wetrakr') -> 'Folder':
        """The calendar: movies or episodes with their days (`discover` - the application client, `following` - the account)."""
        from ...api.wetrakr import wetrakr_app
        from ...ff.calendar import day_label
        api = account_api(account, 'wetrakr') if mode == 'following' else wetrakr_app
        items = [] if api is None or mode not in ('discover', 'following') else api.calendar(media, mode=mode, milestone=milestone)  # type: ignore[arg-type]
        days = dict(items)
        return Folder([ref for ref, _ in items], page=page or 1, limit=const.indexer.wetrakr.page_size,
                      role_format=lambda it, index: day_label(days.get(it.ref) or it.date, week_without_date=False))

    def general_targets(self) -> 'Dict[str, Callable[[Optional[MediaVariant]], Target]]':
        """Return the targets of the general lists of WeTrakr: a folder of movies and of shows (community data, signed "on WeTrakr": terms § 3)."""
        return {'discover_movies': lambda v: url_for(self.discover, media='movie'), 'discover_shows': lambda v: url_for(self.discover, media='show'),
                'public_lists': lambda v: url_for(self.public_lists_menu)}

    @route('/lists')
    def public_lists_menu(self) -> None:
        """The public lists of users: trending, popular, latest, search."""
        thumb = 'services/wetrakr/lists.png'
        with list_directory(view=const.indexer.lists_view) as kdir:
            kdir.folder(L(30671, 'Trending lists on WeTrakr'), url_for(self.public_lists, name='trending'), thumb=thumb)
            kdir.folder(L(30672, 'Popular lists on WeTrakr'), url_for(self.public_lists, name='popular'), thumb=thumb)
            kdir.folder(L(30673, 'Latest lists on WeTrakr'), url_for(self.public_lists, name='last'), thumb=thumb)
            kdir.folder(L(30659, 'List search'), url_for(self.list_search), thumb='common/search.png')

    @route('/lists/{name}/{__page}')
    def public_lists(self, *, name: str, page: int = 1) -> None:
        """Show a page of public lists (`trending`, `popular`, `last`)."""
        from ...api.wetrakr import wetrakr_app
        if name in ('trending', 'popular', 'last'):
            self.show_lists(wetrakr_app.general_lists(name, page=page or 1))

    @subobject
    def list_search(self) -> 'Search':
        """Search public lists."""

        def search_items(query: str, *, page: int = 1, type: Optional[str] = None, **filters) -> None:
            from ...api.wetrakr import wetrakr_app
            self.show_lists(wetrakr_app.search_lists(query, page=page))

        return Search(search_items, name='wetrakr.list', type='list')

    def show_lists(self, items: 'ItemList[FFItem]') -> None:
        """Show folders of public lists."""
        with list_directory(items, view=const.indexer.lists_view) as kdir:
            for it in items:
                kdir.add(it, url=info_for(self.public_list, list_id=it.getProperty('list_id')), thumb='services/wetrakr/lists.png')

    @item_folder_route('/public/{list_id}')
    def public_list(self, *, list_id: str, media: Optional[MediaOrPersonType] = None, page: PathArg[int] = 1) -> 'ItemList[FFItem]':
        """Return a page of the titles of a public list (the application client)."""
        from ...api.wetrakr import wetrakr_app
        return wetrakr_app.public_list(list_id, media=media, page=page or 1)

    @route('/discover/{media}')
    def discover(self, *, media: MainMediaType) -> None:
        """The general lists of movies or shows (the order of `WeTrakrApi.GENERAL`), the rankings in their folder."""
        labels = {'trending': L(30674, 'Trending on WeTrakr'), 'popular': L(30675, 'Popular on WeTrakr'), 'watched': L(30676, 'Most watched on WeTrakr'),
                  'planning': L(30677, 'Most planned on WeTrakr'), 'favorited': L(30678, 'Most favorited on WeTrakr'), 'listed': L(30679, 'Most listed on WeTrakr'),
                  'toprated': L(30680, 'Top rated on WeTrakr'), 'last': L(30681, 'Latest on WeTrakr')}
        with list_directory(view=const.indexer.lists_view) as kdir:
            for name in self._general_names(ranks=False):
                kdir.folder(labels.get(name, name), info_for(self.general_list, name=name, media=media), thumb=f'services/wetrakr/{name}.png')
            kdir.folder(L(30682, 'Rankings on WeTrakr'), url_for(self.ranks, media=media), thumb='services/wetrakr/ranks.png')
            thumb = 'services/wetrakr/calendar.png'
            if media == 'movie':
                kdir.folder(L(30683, 'Movie calendar on WeTrakr'), info_for(self.calendar, media=media), thumb=thumb)
            else:
                kdir.folder(L(30684, 'Episode calendar on WeTrakr'), info_for(self.calendar, media=media), thumb=thumb)
                kdir.folder(L(30685, 'Premieres on WeTrakr'), info_for(self.calendar, media=media, milestone='premiere'), thumb=thumb)
                kdir.folder(L(30686, 'Finales on WeTrakr'), info_for(self.calendar, media=media, milestone='finale'), thumb=thumb)

    @route('/ranks/{media}')
    def ranks(self, *, media: MainMediaType) -> None:
        """The rankings of movies or shows (all time, recomputed daily)."""
        labels = {'rank-best': L(30687, 'Best (ranking)'), 'rank-top-rated': L(30688, 'Top rated (ranking)'), 'rank-most-rated': L(30689, 'Most rated (ranking)'),
                  'rank-most-watched': L(30690, 'Most watched (ranking)'), 'rank-most-planned': L(30691, 'Most planned (ranking)')}
        with list_directory(view=const.indexer.lists_view) as kdir:
            for name in self._general_names(ranks=True):
                kdir.folder(labels.get(name, name), info_for(self.general_list, name=name, media=media), thumb='services/wetrakr/ranks.png')

    @staticmethod
    def _general_names(*, ranks: bool) -> List[str]:
        """Return the names of the general lists: the rankings (`discover/ranks/…`) or the others."""
        from ...api.wetrakr import WeTrakrApi
        return [name for name, (path, _) in WeTrakrApi.GENERAL.items() if path.startswith('discover/ranks/') is ranks]

    @item_folder_route('/general/{name}/{media}')
    def general_list(self, *, name: str, media: MainMediaType, page: PathArg[int] = 1) -> 'ItemList[MediaRef]':
        """A general list of WeTrakr (the application client: the token of the first account), `name` of `WeTrakrApi.GENERAL`."""
        from ...api.wetrakr import WeTrakrApi, wetrakr_app
        if name not in WeTrakrApi.GENERAL:
            return ItemList.empty()
        return wetrakr_app.general_list(name, media=media, page=page or 1)
