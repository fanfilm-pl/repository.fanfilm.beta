from typing import Callable, Dict, List, Optional, TYPE_CHECKING
from . import ServiceLists
from .menu import AccountEntry, media_kw
from ...ff.routing import info_for, PathArg
from ..folder import item_folder_route, pagination, Folder
from const import const
from ...defs import MainMediaType, ItemList
if TYPE_CHECKING:
    from .menu import MediaVariant
    from ...ff.menu import Target


class JustWatchLists(ServiceLists):
    """
    JustWatch: the lists of accounts (the base), their history (the seen titles), the next episodes of their tracked shows
    and the general lists (new VOD).
    """

    TYPE = 'justwatch'

    def type_entries(self, account: str) -> List[AccountEntry]:
        """
        Return the entries of JustWatch itself (no watched state of the account): the history (its seen titles) and the next
        episodes (`upnext`, of the tracked shows in progress; no `progress`: FanFilm would count it from its own watched state).
        """
        return [AccountEntry('history', lambda v: info_for(self.history, account=account, **media_kw(v)), ('mixed', 'movie', 'show')),
                AccountEntry('upnext', lambda v: info_for(self.upnext, account=account), ('show',))]

    @item_folder_route('/upnext')
    def upnext(self, *, page: PathArg[int] = 1, account: str = '') -> Folder:
        """The next episodes of the tracked shows in progress of the account (JustWatch), the latest tracked first."""
        if (api := self._api(account)) is None:
            return Folder([])
        return Folder(api.upnext(page=page or None), alone=True, link=const.indexer.tvshows.progress.episode_folder)

    def history_folder(self, media: Optional[str], page: int, account: str) -> Folder:
        """Return the history of the account from JustWatch: its seen movies (the date they were marked in the role) and shows."""
        if (api := self._api(account)) is None:
            return Folder([])
        return Folder(api.history(media=media, page=page or None))

    def general_targets(self) -> 'Dict[str, Callable[[Optional[MediaVariant]], Target]]':
        """Return the targets of the general lists of JustWatch: new VOD releases (`/movie`, `/show` have them anyway)."""
        return {'vod_new': lambda v: info_for(self.vod_new, **media_kw(v))}

    @item_folder_route('/vod_new/{__page}')
    @pagination
    def vod_new(self, *, page: int = 1, media: Optional[MainMediaType] = None) -> 'Folder':
        """New on VOD: JustWatch new titles (movies, TV shows or both)."""
        return new_vod_folder(media, page)


def new_vod_folder(media: Optional[MainMediaType], page: int) -> Folder:
    """Return new titles on VOD (JustWatch) of the VOD services of the user (`lists_config.subscriptions()`), movies, TV shows or both."""
    from ...api.justwatch import justwatch_app
    from ...ff.lists_config import subscriptions
    items = justwatch_app.new_ffitems(media_type=media,
                                      days=const.indexer.justwatch.new_vod.days,
                                      allowed_short_names=subscriptions(),
                                      limit=const.indexer.justwatch.page_size * page + 1)  # +1 for next page check
    return Folder(ItemList.single(items), alone=True, view='tvshows' if media == 'show' else None)
