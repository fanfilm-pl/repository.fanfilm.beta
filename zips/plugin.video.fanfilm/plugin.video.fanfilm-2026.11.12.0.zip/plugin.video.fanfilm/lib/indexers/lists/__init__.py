"""User lists indexers (Trakt, TMDB, MDBList, IMDb, own lists, ...)."""

import re
from typing import Any, Callable, ClassVar, Dict, List, Optional, Pattern, Sequence, Tuple, Union, TYPE_CHECKING
from typing_extensions import Literal, get_args as get_typing_args
from ..core import Indexer
from .menu import GeneralEntry, variant_label
from ..folder import Folder, item_folder_route, list_directory, pagination
from ...ff.accounts import SERVICE_TYPES, account_enabled, get_account
from ...ff.routing import route, info_for, url_for, PathArg
from ...ff.item import FFItem
from ...ff.lists import show_list_image
from ...defs import ItemList
from ...kolang import L
from cdefs import ListKind, ListType
from const import const
if TYPE_CHECKING:
    from ...defs import FFRef, MediaRef
    from ...ff.info import Progress
    from ...ff.menu import KodiDirectory, Target
    from ...ff.db.playback import MediaPlayInfo
    from .menu import AccountEntry, MediaVariant


def account_rx(type_name: str) -> Pattern[str]:
    """Return the pattern of the account mount path param: the type name (alias of the first account) or an account ID."""
    return re.compile(fr'{type_name}(?:\.[\w-]+)?')


def watched_shows(account: Optional[str] = None, *, first: Optional[int] = None) -> 'List[MediaRef]':
    """
    Return the shows in progress (of the `account`) computed by the service: one computation at a time, it joins a running one
    (e.g. its warm-up), the aired episodes of the `first` shows read (the pages shown, the first one by default); computed
    here if there is no service or it is late (`const.indexer.tvshows.progress.service_wait`).
    """
    from ...ff.info import ffinfo
    from ...service.client import service_client
    if (shows := service_client.progress_shows(account=account, first=first, timeout=const.indexer.tvshows.progress.service_wait)) is not None:
        return shows
    return ffinfo.watched_shows(account=account)


def progress_next_item(it: FFItem, nxt: Optional[FFItem]) -> FFItem:
    """
    Return the item of a show in progress `it` with its next episode `nxt` (`ffinfo.progress_shows_page()`) as
    `const.indexer.tvshows.progress.show`: the next episode (or its season / the show); the show itself without a next episode.
    """
    from ...ff.info import ffinfo
    show = const.indexer.tvshows.progress.show
    if nxt is None or show == 'show':
        return it
    if show == 'season':
        return nxt.season_item or it
    nxt.descr_style = ffinfo.progress_descr_style(it.progress)  # show == 'episode'
    return nxt


def shows_progress_folder(shows: 'Sequence[FFRef]', *, page: int) -> 'Folder':
    """
    Return a page of the shows in progress (`shows`: all of them, filtered and ordered, see `ffinfo.watched_shows()`) as
    `const.indexer.tvshows.progress.show` (`progress_next_item()`); a show without a next episode is the show itself, so
    the pages are even. The progress is the merged one of the accounts.
    """
    from ...ff.info import ffinfo
    from ...defs import Pagina
    pages = Pagina(shows, page=page, limit=const.indexer.tvshows.progress.page_size)
    if const.indexer.tvshows.progress.show == 'show':
        return Folder(pages, page=page)
    items = ItemList.from_list((progress_next_item(it, nxt) for it, nxt in ffinfo.progress_shows_page(pages)), pages)
    return Folder(items, page=page, alone=True, link=const.indexer.tvshows.progress.episode_folder, skip_ffinfo=True)


def continue_watching_folder(*, page: int) -> 'Folder':
    """
    Return a page of the media in progress, the latest touched (watched or paused) first: the movies and episodes with a
    resume point and the shows in progress (`watched_shows()`), one entry a show - its episode paused if the pause is its
    latest touch (played from the resume point), else its next episode (`progress_next_item()`, a link to its season with
    `const.indexer.progress.episode_folder`); the other episodes in progress of the show are in the episodes in progress.
    The progress is the merged one of the accounts, the role is the play time (`const.indexer.history.role`).
    """
    from ...ff.info import ffinfo
    from ...ff.progress import played_at, played_role, played_time
    from ...defs import MediaRef, Pagina
    shows = {ref.ffid for ref in watched_shows(first=page * const.indexer.progress.page_size)}  # the shows of the pages so far
    rows = [pb for pb in ffinfo.playback_info(None).values() if pb.ref.real_type in ('movie', 'episode')]
    latest: 'Dict[int, MediaPlayInfo]' = {}  # the latest touched episode of a show in progress
    for pb in rows:
        if pb.ref.real_type == 'episode' and pb.ref.ffid in shows and ((last := latest.get(pb.ref.ffid)) is None or played_at(pb) > played_at(last)):
            latest[pb.ref.ffid] = pb
    # the shows touched by a watch last: their next episodes (by the episode watched)
    nexts = {pb.ref for pb in latest.values() if not pb.has_progress or (pb.paused_at or 0) < (pb.last_watched_at or 0)}
    entries = [pb for pb in rows if pb.has_progress and not (pb.ref.real_type == 'episode' and pb.ref.ffid in shows)]
    entries.extend(latest.values())
    entries.sort(key=played_at, reverse=True)
    pages = Pagina(entries, page=page, limit=const.indexer.progress.page_size)
    page_rows: 'List[MediaPlayInfo]' = list(pages)
    show_refs = [MediaRef.tvshow(pb.ref.ffid) for pb in page_rows if pb.ref in nexts]
    next_items = {it.ref.ffid: progress_next_item(it, nxt) for it, nxt in ffinfo.progress_shows_page(show_refs)} if show_refs else {}
    videos = {it.ref: it for it in ffinfo.get_items([pb.ref for pb in page_rows if pb.ref not in nexts], duplicate=False, keep_missing=False)}
    items: 'List[FFItem]' = []
    for pb in page_rows:
        if (it := next_items.get(pb.ref.ffid) if pb.ref in nexts else videos.get(pb.ref)) is not None:
            if role := const.indexer.history.role:
                it.role = played_role(played_time(pb), pb=None if pb.ref in nexts else pb, role=role)
            items.append(it)
    linked = {next_items[ref.ffid].ref for ref in show_refs if ref.ffid in next_items} if const.indexer.progress.episode_folder else set()
    return Folder(ItemList.from_list(items, pages), page=page, alone=True, link=lambda it: it.ref in linked, skip_ffinfo=True,
                  view=const.indexer.progress.view)


def media_variants(types: ListType) -> 'Tuple[MediaVariant, ...]':
    """Return the media variants of a list of the media `types`: the main media (persons, collections too), the mixed one first if more."""
    media: 'Tuple[MediaVariant, ...]' = tuple(m for m in ('movie', 'show', 'person', 'collection')  # type: ignore[misc]
                                              if ListType.from_media_ref(m) & types)
    return ('mixed', *media) if len(media) > 1 else media


def one_media(media: Optional[str]) -> Optional[str]:
    """Return the media filter of a route argument: None for all (none, `all`, more media, e.g. `movie,show`)."""
    return None if not media or media == 'all' or ',' in media else media


class ServiceLists(Indexer):
    """
    Menu of a list service type, mounted on the account path param: the type name (`/trakt`) is the menu of the type,
    an account ID (`/trakt.test`) the menu of the account - the menu of lists (`lib.indexers.lists.menu`, `lists`) in
    the scope of the type.

    The lists of an account are of its client (`AccountClient.LISTS`, `RATING` and the vocabulary), the routes are here:
    the fixed sections, the own lists, the ratings, the history and the progress (the synced rows of the account). A type
    adds its own entries (`type_entries()`) and its general lists (`general_entries()`) only.
    """

    #: The service type name.
    TYPE: ClassVar[str] = ''

    def general_targets(self) -> 'Dict[str, Callable[[Optional[MediaVariant]], Target]]':
        """Return the targets of the general lists of the type (`ServiceType.general_lists`) by their keys: a media variant -> the target."""
        return {}

    def general_entries(self) -> List[GeneralEntry]:
        """
        Return the general lists of the type (`ServiceType.general_lists`) with their targets (`general_targets()`), the variants
        of a list of more media in their folder (shown if `general_available()` and the user switches, `lib.ff.lists_config`).
        """
        targets = self.general_targets()
        return [GeneralEntry(gen.key, gen.label(), targets[gen.key], gen.variants, gen.thumb, gen.places,
                             self.general_variants_folder(gen.key) if len(gen.variants) > 1 else None)
                for gen in SERVICE_TYPES[self.TYPE].general_lists]

    def general_variants_folder(self, key: str) -> Any:
        """Return the target of the folder of the media variants of the general list (`GeneralEntry.folder`)."""
        return url_for(self.general_variants, key=key)

    @route('/general/{key}')
    def general_variants(self, key: str) -> None:
        """The media variants of a general list of the type (mixed, movies, TV shows)."""
        with list_directory(view=const.indexer.lists_view) as kdir:
            for gen in self.general_entries():
                if gen.key == key:
                    for variant in gen.variants:
                        kdir.folder(variant_label(variant), gen.target(variant), thumb=gen.thumb or self._thumb('main'))

    def type_entries(self, account: str) -> List['AccountEntry']:
        """Return the entries of the account the type has on its own (e.g. Trakt recommendations)."""
        return []

    def entries(self, account: str) -> List['AccountEntry']:
        """
        Return the entries of the account in the menus of lists: its lists and its ratings (its client, if it reads them),
        the history and the progress (if it reads its watched state), the entries of the type; in order of the kinds.
        """
        from .menu import AccountEntry, media_kw
        from ...ff.accounts import account_client
        if (acc := get_account(account)) is None or acc.type.name != self.TYPE:
            return []
        entries: List[AccountEntry] = []
        client = account_client(acc)
        for section, spec in (client.LISTS.items() if client is not None and account_enabled(acc, 'lists', 'read') else ()):
            if section == 'user':
                entries.append(AccountEntry('mylists', lambda v: url_for(self.mine, account=account, **media_kw(v)),
                                            media=tuple(v for v in media_variants(spec.types) if v != 'mixed'),  # type: ignore[misc]
                                            inline=lambda kdir, media, role: self._add_mine(kdir, media=media, account=account, role=role)))
            else:
                target = getattr(self, section)
                entries.append(AccountEntry(section, lambda v, target=target: info_for(target, account=account, **media_kw(v)), media_variants(spec.types)))
        if client is not None and client.RATING is not None and account_enabled(acc, 'ratings', 'read'):
            entries.append(AccountEntry('ratings', lambda v: url_for(self.rated, account=account, **media_kw(v, mixed='all')),
                                        ('mixed', *client.RATING.media)))
        if account_enabled(acc, 'watched', 'read'):
            entries.append(AccountEntry('history', lambda v: info_for(self.history, account=account, **media_kw(v)), ('mixed', 'movie', 'show')))
            entries.append(AccountEntry('progress', lambda v: info_for(self.progress, account=account), ('show',)))
        if client is not None and account_enabled(acc, 'lists', 'read'):
            entries.extend(self.type_entries(account))
        kinds: Tuple[ListKind, ...] = get_typing_args(ListKind)
        return sorted(entries, key=lambda entry: kinds.index(entry.kind))

    @route('/')
    def home(self, *, account: str = '') -> None:
        """The menu of the type or of the account."""
        from .menu import MenuScope, menu_directory
        menu_directory('lists', MenuScope(type=self.TYPE, account='' if account in ('', self.TYPE) else account))

    def _api(self, account: str, capability: str = 'lists') -> Any:
        """Return the client of the account that may read the `capability`, None otherwise."""
        return account_api(account, self.TYPE, capability)

    def _entry_menu(self, kind: ListKind, account: str) -> None:
        """Show the media variants of an entry of the account (the menu of lists)."""
        from .menu import MenuScope, menu_directory
        acc = get_account(account)
        menu_directory('lists', MenuScope(kind=kind, type=self.TYPE, account=acc.id if acc is not None else account))

    def _thumb(self, name: str) -> str:
        """Return the thumb of the type (`services/<type>/<name>.png`)."""
        return f'services/{self.TYPE}/{name}.png'

    # --- The fixed sections of lists (`AccountClient.LISTS`), the page in the query (`{__media}` is optional) ---

    def _section(self, section: str, media: Optional[str], page: int, account: str) -> Folder:
        """Return the page of a fixed section of the account (page 0: all items), removing items if the account may change its lists."""
        if (api := self._api(account)) is None or section not in api.LISTS:
            return Folder([])
        items = getattr(api, section)(media=one_media(media), page=page or None)
        return Folder(items, list_spec=account_enabled(account, 'lists', 'write'))

    @item_folder_route('watchlist/{__media}', list_spec='{account}:watchlist')
    def watchlist(self, *, media: Optional[str] = None, page: int = 1, account: str = '') -> Folder:
        """The watchlist of the account (page 0: all items)."""
        return self._section('watchlist', media, page, account)

    @item_folder_route('favorites/{__media}', list_spec='{account}:favorites')
    def favorites(self, *, media: Optional[str] = None, page: int = 1, account: str = '') -> Folder:
        """The favorites of the account (page 0: all items)."""
        return self._section('favorites', media, page, account)

    @item_folder_route('collection/{__media}', list_spec='{account}:collection')
    def collection(self, *, media: Optional[str] = None, page: int = 1, account: str = '') -> Folder:
        """The collection of the account (page 0: all items)."""
        return self._section('collection', media, page, account)

    # --- The own lists ---

    @route('/mine/{__page}')
    def mine(self, *, media: Optional[str] = None, page: int = 1, account: str = '') -> None:
        """Show the own lists of the account (the ones with the `media`, their items of the `media` only)."""
        view = getattr(getattr(getattr(const.indexer, self.TYPE, None), 'mine', None), 'view', const.indexer.lists_view)
        with list_directory(view=view) as kdir:
            self._add_mine(kdir, media=media, account=account)

    def _add_mine(self, kdir: 'KodiDirectory', *, media: Optional[str] = None, account: str = '', role: str = '') -> None:
        """Add the own lists of the account (`role`: where they are from, in a menu of lists)."""
        if (api := self._api(account)) is None:
            return
        media = one_media(media)
        wanted = ListType.from_media_ref(media) if media else ListType.ALL
        kwargs = {} if media is None else {'media': media}
        for it in sorted(api.user_lists(), key=lambda it: it.label.lower()):
            if (types := it.getProperty('list_type')) and not ListType.new(types) & wanted:
                continue
            list_id = it.getProperty('list_id') or str(it.ffid)
            show_list_image(it, account, list_id)
            kdir.add(it, url=info_for(self.user_list, list_id=list_id, account=account, **kwargs), thumb=self._thumb('lists'), role=role or None)

    @item_folder_route('list/{list_id}', list_spec='{account}:user:{list_id}')
    def user_list(self, *, list_id: str, media: Optional[str] = None, page: int = 1, account: str = '') -> Folder:
        """
        The items of a list of the account (page 0: all items), removing items if the list is its own and it may change it.
        The page is not in the path: `list/<user>/<list>` of a type (Trakt) is not a page of `list/<list>`.
        """
        if (api := self._api(account)) is None:
            return Folder([])
        items = api.list_items(list_id, media=one_media(media), page=page or None)
        return Folder(items, list_spec=account_enabled(account, 'lists', 'write') and getattr(items, 'mine', True))

    # --- Ratings (`AccountClient.RATING`, `ratings()`) ---

    @route('/rated')
    @route('/rated/{media}')
    def rated(self, *, media: Optional[str] = None, account: str = '') -> None:
        """The ratings menu of the account: the rated media (and all of them, `all`), then the ratings of a media."""
        from ...ff.ratings import NORM_RANGE
        labels = {'movie': L(30547, 'Rated movies'), 'show': L(30548, 'Rated tvshows'), 'season': L(30549, 'Rated seasons'),
                  'episode': L(30550, 'Rated episodes')}
        thumb = self._thumb('ratings')
        with list_directory(view=const.indexer.lists_view) as kdir:
            if (api := self._api(account, 'ratings')) is None or api.RATING is None:
                return
            if media is None:
                for rated in api.RATING.media:
                    kdir.folder(labels.get(rated, rated), info_for(self.rated, media=rated, account=account), thumb=thumb)
                kdir.folder(L(30551, 'Rated (mixed)'), info_for(self.rated, media='all', account=account), thumb=thumb)
            else:
                kdir.folder(L(30552, 'All rated'), info_for(self.rated_items, media=media, rating='-', account=account), thumb=thumb)
                for rating in reversed(NORM_RANGE):
                    label = L(30553, 'Rated {rating}').format(rating=rating)
                    kdir.folder(label, info_for(self.rated_items, media=media, rating=rating, account=account), thumb=thumb)

    @item_folder_route('/rated/{media}/{rating}/{__page}')
    @pagination
    def rated_items(self, *, media: str, rating: Union[int, Literal['-'], None], page: int = 1, account: str = '') -> 'Sequence[FFItem]':
        """The rated media of the account (`all`: of all media) with their ratings (1-10), all ratings (`-`) by the rating."""
        if (api := self._api(account, 'ratings')) is None or (scale := api.RATING) is None:
            return []
        wanted = None if rating == '-' else rating
        items: List[FFItem] = []
        for ref, raw in api.ratings().items():
            if (media_type := one_media(media)) and ref.real_type != media_type:
                continue
            norm = scale.from_service_rating(raw)
            if wanted is not None and norm != wanted:
                continue
            it = FFItem(ref)
            it.vtag.setUserRating(norm)
            if wanted is None:
                it.role = L(30554, 'Rating: {rating}').format(rating=norm)
            items.append(it)
        if wanted is None:
            items.sort(key=lambda it: it.vtag.getUserRating(), reverse=True)
        return ItemList.single(items)

    # --- History and progress (the synced rows of the account) ---

    def _played(self, account: str) -> 'List[MediaPlayInfo]':
        """Return the playback rows of the account (`ffinfo.account_rows()`), the latest played first; none if it does not read its watched state."""
        from ...ff.info import ffinfo
        from ...ff.progress import played_at
        if (acc := get_account(account)) is None or acc.type.name != self.TYPE or not account_enabled(acc, 'watched', 'read'):
            return []
        return sorted(ffinfo.account_rows(acc.id), key=played_at, reverse=True)

    @item_folder_route('history/{__media}')
    def history(self, *, media: Optional[str] = None, page: int = 1, account: str = '') -> Folder:
        """The watched movies and episodes of the account, the latest first."""
        return self.history_folder(one_media(media), page, account)

    def history_folder(self, media: Optional[str], page: int, account: str) -> Folder:
        """Return the history of the account: its synced rows (a type may read it from its service)."""
        from ...ff.progress import played_items
        reals = ('movie',) if media == 'movie' else ('episode',) if media == 'show' else ('movie', 'episode')
        partial = const.indexer.history.show_watching
        rows = [pb for pb in self._played(account) if pb.ref.real_type in reals and (pb.play_count or (partial and pb.has_progress))]
        return Folder(played_items(rows, role=const.indexer.history.role), page=page or 1, limit=const.indexer.page_size)

    @item_folder_route('/progress')
    def progress(self, *, page: PathArg[int] = 1, account: str = '') -> Folder:
        """The shows in progress the account played (its synced rows), the latest played first; their progress is the merged one."""
        if (acc := get_account(account)) is None or acc.type.name != self.TYPE:
            return Folder([])
        return shows_progress_folder(watched_shows(account=acc.id, first=page * const.indexer.tvshows.progress.page_size), page=page)


def account_api(account: str, type_name: str, capability: str = 'lists') -> Any:
    """Return the API client of the account of the type that may read the `capability` (its lists), None otherwise (no other account instead)."""
    from ...ff.accounts import account_client
    from ...ff.logs import fflog
    acc = get_account(account)
    if acc is None or acc.type.name != type_name or not account_enabled(acc, capability, 'read'):  # type: ignore[arg-type]  # a capability
        fflog(f'[LISTS] account {account!r} ({type_name}) can not read its {capability}')
        return None
    return account_client(acc)
