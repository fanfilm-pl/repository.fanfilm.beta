"""History module (played from KodiDb)."""

from typing import List, Sequence, TYPE_CHECKING
from datetime import datetime

from .core import Indexer
from .folder import item_folder_route, pagination, list_directory
from ..ff.item import FFItem
from ..ff.routing import info_for, route
from ..ff.info import ffinfo
from ..ff.progress import played_items
# from ..ff.logs import fflog
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..defs import MediaPlayType


class History(Indexer):
    """History indexer."""

    @route('/')
    def root(self) -> None:
        """Main history menu: the merged history of FanFilm, then the history of the accounts."""
        with list_directory() as kdir:
            kdir.entry('history.movie', info_for(self.movies))
            kdir.entry('history.show', info_for(self.tvshows))
            from .lists.menu import add_menu_level
            add_menu_level(kdir, 'history')  # the history of the accounts

    @item_folder_route('/movie', limit=CONST_REF.indexer.history.limit)
    @pagination(limit=CONST_REF.indexer.movies.discovery_scan_limit)
    def movies(self) -> Sequence[FFItem]:
        """Show watched movies."""
        return self._get_watched_items(media_type='movie')

    @item_folder_route('/show', limit=CONST_REF.indexer.history.limit)
    @pagination(limit=CONST_REF.indexer.tvshows.discovery_scan_limit)
    def tvshows(self) -> Sequence[FFItem]:
        """Show watched TV show episodes directly."""
        return self._get_watched_items(media_type='episode')

    @route('/{scope}')  # after /movie and /show: an account ID or a pointer is never a media
    def accounts(self, scope: str) -> None:
        """A group folder of the history of the accounts by the pointer of its scope (`/history/trakt.x`)."""
        from .lists.menu import menu_directory, pointer_scope
        menu_directory('history', pointer_scope(scope))

    def _get_watched_items(self, *, media_type: 'MediaPlayType') -> List[FFItem]:
        """Get watched media items (the merged progress of accounts, the local Kodi account reads Kodi video DB)."""
        partial = const.indexer.history.show_watching
        rows = (pb for pb in ffinfo.playback_info(None).values()
                if pb.ref.real_type == media_type and (pb.play_count or (partial and pb.has_progress)))
        return played_items(rows, role=const.indexer.history.role)
