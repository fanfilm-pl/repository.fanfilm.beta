"""
Global play routes, light: the first dispatch phase (lib.main) finds a play without loading the navigator and its indexers.

Routable module: no `from __future__ import annotations` (the types are used to route).
"""

from typing import Optional, Union
from typing_extensions import Literal
from attrs import evolve

from ..ff import control
from ..ff.logs import fflog
from ..ff.routing import route, main_router, URL
from ..ff.types import EllipsisType
from ..defs import MediaRef, VideoIds
from .folder import mediaref_endpoint


@mediaref_endpoint
@route('/play/{ref}')
def play(ref: MediaRef,
         *,
         edit: bool = False,
         season: Optional[int] = None,  # not used
         episode: Optional[int] = None,  # not used
         episode_group: Union[str, None, EllipsisType] = ...,
         ) -> None:
    """Play any video (movie, episode). Optionally override season/episode for show episode."""
    from ..ff.sources import SourceManager
    if not (ref.is_movie or ref.is_episode or (ref.type == 'show' and season is not None and episode is not None)):
        return no_play(ref)
    if season is None or episode is None:
        override_episode = None
        play_as = ''
    else:
        override_episode = (season, episode)
        play_as = f' as S{season:02}E{episode:02}'
    fflog(f'play({ref}){play_as}...')
    if ref.ffid in VideoIds.KODI:
        ref = evolve(ref, ffid=ref.ffid + VideoIds.TMDB.start)
    if ref.type in ('movie', 'show'):
        SourceManager().play(ref.type, ref.ffid, ref.season, ref.episode, edit_search=edit,
                             override_episode=override_episode, episode_group=episode_group or None)


def is_play_url(url: URL) -> bool:
    """Return True if `url` is in the space of the play URLs (the static part of the play route path, `play/…`)."""
    entry = main_router.find_func_route(play)
    prefix = entry.path_format.partition('{')[0].strip('/') if entry else ''
    return bool(prefix) and url.path.strip('/').partition('/')[0] == prefix


def no_play(what: object) -> None:
    """
    Answer a play URL of no item to play (a show, a season, no ref): Kodi lists the parent of a play URL as a folder
    (Files.GetFileDetails). A failed folder is not kept in Kodi directory cache - a kept one (even empty) makes every
    play URL in it a missing file there, Files.SetFileDetails of them fails (Invalid params).
    """
    fflog(f'play: {what} is no item to play, a failed folder')
    control.end_of_directory(control.current_call().handle, succeeded=False, cacheToDisc=False)


# Example for FF2 library links. Keep it for compatibility.
#  plugin://plugin.video.fanfilm/?action=play&name=Rebel+Moon+-+Part+One%3A+A+Child+of+Fire+%282023%29&title=Rebel+Moon+-+Part+One%3A+A+Child+of+Fire&localtitle=Rebel+Moon+%E2%80%93+cz%C4%99%C5%9B%C4%87+1%3A+Dziecko+Ognia&year=2023&imdb=tt14998742&tmdb=848326
#  plugin://plugin.video.fanfilm/?action=play&title=What+If...+Strange+Supreme+Intervened%3F&year=2021&imdb=tt10168312&tmdb=91363&season=2&episode=9&tvshowtitle=What+If...%3F&date=2023-12-30


# Kolejność ma znaczenie, old_play_tvshow() musi być nad old_play_movie(),
# bo inaczej filmy zjedzą seriale (mają podzbiór argumentów, więc trafią).
@route('/')
def old_play_tvshow(action: Literal['play'], tmdb: int, season: int, episode: int, **kwargs) -> None:
    """Play movie video in old API (up to FanFilm 2023)."""
    ffid = VideoIds(tmdb=tmdb, imdb=kwargs.get('imdb')).ffid
    if ffid:
        fflog(f'old play.tvshow({tmdb=}, {season=}, {episode=}):  {ffid=} ...')
        play(MediaRef('show', ffid, season, episode))
    else:
        fflog(f'old play.tvshow({tmdb=}, {season=}, {episode=}):  {ffid=} FAILED')


# Musi być po serialach, patrz komentarz wyżej.
@route('/')
def old_play_movie(action: Literal['play'], tmdb: int, **kwargs) -> None:
    """Play movie video in old API (up to FanFilm 2023)."""
    ffid = VideoIds(tmdb=tmdb, imdb=kwargs.get('imdb')).ffid
    if ffid:
        fflog(f'old play.movie({tmdb=}):  {ffid=} ...')
        play(MediaRef('movie', ffid))
    else:
        fflog(f'old play.movie({tmdb=}):  {ffid=} FAILED')
