
from typing import Optional, TYPE_CHECKING

from xbmcgui import Dialog, INPUT_NUMERIC
from .. import run_by_kodi
from ..ff.routing import route, subobject, url_for, RouteObject
from ..ff.menu import directory
from ..ff.sync import syncing_accounts
from ..ff.control import yesnoDialog, busy_section, addonName, notification, show_changelog
from ..ff.settings import settings
from ..sources.natives import provider_searched, set_provider_value
from ..service.client import service_client, LibraryAutoAddSource

from ..ff.logs import fflog
from ..kolang import L
from .navigator import nav
from const import const
if TYPE_CHECKING:
    from .accounts import Accounts


def yes_no(name: Optional[str] = None) -> bool:
    lines = [L(32056, 'Are you sure?')]
    if name is not None:
        lines.insert(0, name)
    return yesnoDialog(*lines)


class Cache(RouteObject):
    """Podmenu: /narzędzia/cache."""

    CLEAR_SOURCES_LABEL = L(30252, 'Clear cached source list')
    CLEAR_SOURCES_PROVIDERS_LABEL = L(32851, 'Clear cached source list and provider data (logins)')
    CLEAR_SEARCH_LABEL = L(30253, 'Clear search history')
    CLEAR_MEDIA_LABEL = L(32852, 'Clear media cache')
    CLEAR_LISTS_LABEL = L(32853, 'Clear lists cache')

    @route('/')
    def cache(self):
        with directory(view=const.indexer.tools.view, thumb='common/cache.png') as kdir:
            # kdir.action(32807, "clearCacheBookmarks")
            kdir.action(self.CLEAR_MEDIA_LABEL, self.clear_media)
            kdir.action(self.CLEAR_LISTS_LABEL, self.clear_lists)
            kdir.action(self.CLEAR_SOURCES_LABEL, self.clear_sources)
            kdir.action(self.CLEAR_SOURCES_PROVIDERS_LABEL, url_for(self.clear_sources, provider_data=True))
            kdir.action(self.CLEAR_SEARCH_LABEL, self.clear_search)       # clearCacheSearch
            # kdir.action(32794, "clearCacheAll")

    @route('/sources')
    def clear_sources(self, *, provider_data: bool = False) -> None:
        """Clear the sources cache, with `provider_data` also data of providers (logins, tokens)."""
        from ..ff import cache
        if yes_no(self.CLEAR_SOURCES_PROVIDERS_LABEL if provider_data else self.CLEAR_SOURCES_LABEL):
            with busy_section(complete_notif=True):
                cache.cache_clear_sources(provider_data=provider_data)

    @route('/search')
    def clear_search(self) -> None:
        from ..ff.db.search import remove_search_history
        if yes_no(self.CLEAR_SEARCH_LABEL):
            with busy_section(complete_notif=True):
                # Clear the search-history rows via DELETE (visible to all connections) instead of
                # unlinking the shared 'search' DB file — which left other threads' connections on an
                # orphaned inode and also wiped the unrelated `source_edit` table.
                remove_search_history(None)

    @route('/media')
    def clear_media(self) -> None:
        """Clear media info (media DB)."""
        if yes_no(self.CLEAR_MEDIA_LABEL):
            with busy_section(complete_notif=True):
                from ..ff.db import media
                media.clear()

    @route('/lists')
    def clear_lists(self) -> None:
        """Clear the lists cache (lists of accounts, general lists, `lists.db`)."""
        if yes_no(self.CLEAR_LISTS_LABEL):
            with busy_section(complete_notif=True):
                from ..ff.db import lists
                lists.clear()


class Views(RouteObject):
    """Podmenu: /narzędzia/Widoki."""
    CLEAR_VIEW_LABEL = L(32640, 'Clear views...')
    VIEW_ITEMS = [
        (L(32001, 'Movies'), 'movies'),
        (L(32002, 'TV Shows'), 'tvshows'),
        (L(30302, 'Seasons'), 'seasons'),
        (L(30303, 'Episodes'), 'episodes'),
        (L(32032, 'Collection'), 'sets'),
        (L(30133, 'Actors'), 'actors'),
        (L(30304, 'Mixed lists'), 'videos'),
        (L(32011, 'Genres'), 'genres'),
        (L(30305, 'Menu'), 'addons'),
    ]

    @route('/')
    def views(self):
        """Menu wyboru widoków."""
        with directory(view=const.indexer.tools.view, thumb='common/views.png') as kdir:
            for label_id, view_type in self.VIEW_ITEMS:
                kdir.folder(label_id, url_for(self.set_views, type=view_type))
            kdir.action(self.CLEAR_VIEW_LABEL, self.clear_views)

    @route('/set_views/')
    def set_views(self, type: str) -> None:
        # TODO: use type: ContentView ???
        with directory(view=type) as kdir:
            kdir.action(L(32059, 'CLICK HERE TO SAVE VIEW'), url_for(self.addCustomView, type=type))

    @route('/addCustomView/')
    def addCustomView(self, type: str) -> None:
        from ..ff.views import view_manager
        view_manager.add_custom_view(type)

    @route
    def clear_views(self) -> None:
        from ..ff import cache
        if yes_no(self.CLEAR_VIEW_LABEL):
            with busy_section(complete_notif=True):
                cache.cache_clear_view()


class LibraryTools(RouteObject):
    """Podmenu: /narzędzia/library."""

    movie_library = settings.getString("library.movie")
    tv_library = settings.getString("library.tv")

    @route('/sync/{source}')
    def sync_lib(self, source: LibraryAutoAddSource):
        service_client.library_auto_add(source)

    @route('/pick_lists')
    def pick_lists(self) -> None:
        """Pick any list(s) - collection, watchlist, favorites or a custom user list, from any
        service (Trakt/TMDB/MDBList/Own/IMDb) - to sync into the local video library."""
        from ..ff.lists import run_pick_lists_dialog
        run_pick_lists_dialog()

    @route('/preview_lists')
    def preview_lists(self) -> None:
        """Show item counts for the currently picked lists - a dry-run, nothing gets written."""
        from ..ff.lists import run_preview_lists_dialog
        run_preview_lists_dialog()

    @route('/')
    def library(self):
        with directory(view=const.indexer.tools.view, thumb='common/library.png') as kdir:
            kdir.folder(L(32543, 'Movies'), self.movie_library, thumb='movies/main.png')
            kdir.folder(L(32544, 'TV Shows'), self.tv_library, thumb='tvshows/main.png')
            kdir.action(L(30646, 'Select lists to sync to library'), url_for(self.pick_lists), thumb='services/own/update.png')
            kdir.action(L(30648, 'Preview selected lists'), url_for(self.preview_lists), thumb='services/own/update.png')
            kdir.action(L(30649, 'Update selected lists'), url_for(self.sync_lib, source='lists'), thumb='services/own/update.png')


class Download(RouteObject):
    """Podmenu: /narzędzia/download."""

    CLEAR_DOWNLOADER_LABEL = L(30227, 'Clear downloader cache')

    movie_downloads = settings.getString("movie.download.path")
    tv_downloads = settings.getString("tv.download.path")

    @route('/')
    def download(self):
        with directory(view=const.indexer.tools.view, thumb='common/downloads.png') as kdir:
            kdir.folder(L(30319, 'Movies downloaded'), f'{self.movie_downloads}', thumb='movies/download.png')
            kdir.folder(L(30320, 'TV Shows downloaded'), f'{self.tv_downloads}', thumb='tvshows/download.png')
            kdir.action(L(32807, 'Download manager'), self.download_manager, thumb='common/downloads.png')
            kdir.action(self.CLEAR_DOWNLOADER_LABEL, self.download_clear_cache)

    @route
    def download_manager(self) -> None:
        from lib.ff.downloader import downloadManager
        downloadManager()

    @route
    def download_clear_cache(self) -> None:
        from ..ff import cache
        if yes_no(self.CLEAR_DOWNLOADER_LABEL):
            with busy_section(complete_notif=True):
                cache.cache_clear_downloader()


class SourcesEdit(RouteObject):
    """Podmenu: /narzędzia/alternatywy 4 (tytuły, podział na sezony itp.)."""

    @route('/')
    def home(self):
        with directory(view=const.indexer.tools.view, thumb='common/tools.png') as kdir:
            kdir.action(L(30522, 'Remove source edit'), self.remove)
            kdir.action(L(30523, 'Clear all sources edits'), self.clear)

    @route
    def clear(self) -> None:
        from ..ff.db.search import sources_edit_db
        if yes_no(L(30524, 'Clear all sources edits?')):
            # with busy_section(complete_notif=True):
            #     sources_edit_db.clear()
            sources_edit_db.clear()

    @route
    def remove(self) -> None:
        from xbmcgui import Dialog
        from ..ff.db.search import sources_edit_db
        items = sources_edit_db.list_ffitems()
        indexes = Dialog().multiselect(L(30525, 'Select items to remove'), items)
        if indexes:
            with busy_section(complete_notif=True):
                for i in indexes:
                    sources_edit_db.delete(items[i])


class Tools(RouteObject):
    """Głowne menu FanFilm."""

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with directory(view=const.indexer.tools.view) as kdir:
            # the configuration and the settings
            if run_by_kodi():
                kdir.action(L(30150, 'Configuration'), self.config, thumb='common/tools.png')
                # For tests. Do not remove next line.
                # kdir.action(L(30628, 'General lists'), url_for(self.config, tab='general'), thumb='common/tools.png')
            else:
                kdir.folder(L(32916, 'Accounts'), self.accounts_folder, thumb='common/tools.png')
            if const.indexer.tools.external_addons and not run_by_kodi():  # in Kodi: the configuration opens on its tab
                kdir.action(L(32917, 'Source providers'), self.source_providers_folder, thumb='common/tools.png')
            kdir.action(L(32806, 'Settings'), nav.settings, thumb='common/tools.png')
            kdir.folder(L(30368, 'Manage settings'), self.settings, thumb='common/tools.png')
            # the accounts and the services
            if const.indexer.tools.sync_entry and syncing_accounts():
                kdir.action(L(32995, 'Synchronize accounts'), self.sync_accounts, thumb='services/own/update.png')
            if provider_searched('netmirror'):
                kdir.action(L(30643, 'NetMirror: Enter OTP code'), self.netmirror_otp, thumb='common/tools.png')
            # the videos
            if settings.getBool('enable_library'):
                kdir.folder(L(32541, 'Library'), self.librarytools, thumb='common/library.png')
            if settings.getBool('downloads'):
                kdir.folder(L(30306, 'Downloaded'), self.download, thumb='common/downloads.png')
            kdir.folder(L(30530, 'Edited searchs'), self.sources_edit, thumb='common/tools.png')
            # the look
            kdir.folder(L(32049, 'Viewtypes'), self.views, thumb='common/views.png')
            if const.indexer.tools.select_theme:
                kdir.action(L(32918, 'Theme'), self.theme, thumb='common/tools.png')
            # the maintenance and the info
            kdir.folder(L(30254, 'Cache'), self.cache, thumb='common/cache.png')
            if const.tune.service.web_server.port:
                kdir.action(L(30373, 'FanFilm web server'), self.web_server, thumb='common/tools.png')
            kdir.action(L(30634, 'Changelog'), self.changelog, thumb='common/tools.png')

    @route
    def config(self, tab: str = '', account: str = '') -> None:
        """The configuration window (Kodi), `tab`: the tab to show (none: the last shown one, else the first one), `account`: the account to select."""
        from ..windows.config_dialog import ConfigDialog
        ConfigDialog(tab=tab, account=account or None).doModal()

    @route('/accounts/{__account}')
    def accounts(self, account: Optional[str] = None) -> None:
        """The configuration window (Kodi) at its tab of the accounts, `account`: the account to select."""
        self.config(tab='accounts', account=account or '')

    @subobject
    def accounts_folder(self) -> 'Accounts':
        """Accounts via folder (the CLI)."""
        from .accounts import Accounts
        return Accounts()

    @route('/external_addons')  # the old name: lib/sdk/worker.py HOST_PAGE (also in the SDK copies of the provider add-ons)
    @route('/source_providers')  # the first route is the one of url_for()
    def source_providers(self) -> None:
        """The configuration window (Kodi) at its tab of the source providers."""
        self.config(tab='addons')

    @route
    def source_providers_folder(self) -> None:
        """
        Choose the source providers searched (the CLI): a tree of the external add-ons: add-on / group / scraper (a whole add-on by the node
        action); an add-on with a chosen scraper is searched (every found one is kept with its choice).
        """
        from ..ff.config import config
        from ..windows.tree import tree_select
        from ..sources.addons.external import ADDONS_CONFIG, addons_choice, addons_tree, found_xproviders
        with busy_section():
            xproviders = found_xproviders()
        found = [addon for xp in xproviders for addon in xp.addons]
        if not found:
            fflog('No external add-ons served by an active provider add-on')
        chosen = config.get(ADDONS_CONFIG) or {}
        roots, entries, preselect = addons_tree(xproviders, chosen)
        selected = tree_select(L(32917, 'Source providers'), roots, multi=True, preselect=preselect, left_to_parent=True)
        if selected is None:  # canceled
            return
        keys: dict = {}
        for leaf in selected:
            if (entry := entries.get(id(leaf))) is not None and entry.key:
                keys.setdefault(entry.addon, set()).add(entry.key)
        config.set(ADDONS_CONFIG, addons_choice(found, chosen, keys))

    @route
    def theme(self) -> None:
        """The themes and their variant: the configuration window on its page of the appearance."""
        self.config(tab='appearance')

    @route('/theme/variant/{variant}')
    def theme_variant(self, variant: str) -> None:
        """
        Set the variant of the themes: its name (`auto` - by the skin, `dark`, `light`), `toggle` - by hand the other one of dark / light
        than the one of now (`toggled_variant()`: from the automatic one too). The FF windows take it at their next open.
        """
        from ..ff import theme
        if variant == theme.TOGGLE_VARIANT:
            variant = theme.toggled_variant()
        if not theme.RX_VARIANT.fullmatch(variant):
            fflog.warning(f'Theme variant {variant!r}: not a name of a variant')
            return
        theme.set_variant(variant)
        fflog(f'Theme variant: {variant}')

    @route
    def changelog(self) -> None:
        show_changelog()

    @route('/trakt/sync')  # the old path (shortcuts of users)
    def sync_accounts(self) -> None:
        """Sync all accounts now and wait for it: tell a success (the service tells a failure)."""
        from ..ff.ui import ui
        if (failed := service_client.accounts_sync()) is None:
            ui.notify(f'[FanFilm] {L(32916, "Accounts")}', L(32988, 'Synchronization failed: no answer of the FanFilm service'), error=True)
        elif not failed:
            ui.notify(f'[FanFilm] {L(32916, "Accounts")}', L(30196, 'Synchronize successful'))

    @route('/pairekino')
    def pairekino(self) -> None:
        from ..sources.pl.ekinotv import _source
        _source().pair_scraper()

    @subobject
    def cache(self) -> Cache:
        """Cache submenu."""
        return Cache()

    @subobject
    def views(self) -> Views:
        """Views submenu."""
        return Views()

    @subobject
    def download(self) -> Download:
        """Download submenu."""
        return Download()

    @subobject
    def librarytools(self) -> LibraryTools:
        """Library submenu."""
        return LibraryTools()

    @subobject
    def sources_edit(self) -> SourcesEdit:
        """SourcesEdit submenu."""
        return SourcesEdit()

    @route
    def settings(self) -> None:
        with directory(view=const.indexer.tools.view) as kdir:
            kdir.action(L(30369, 'Clean settings'), self.clean_settings, thumb='common/tools.png')
            kdir.action(L(30370, 'Restore a backup'), self.restore_settings, thumb='common/tools.png')
            kdir.action(L(30371, 'Make a backup'), self.backup_settings, thumb='common/tools.png')
            kdir.action(L(30497, 'Factory settings reset'), self.factory_settings_reset, thumb='common/tools.png')

    @route('/settings/factory_reset')
    def factory_settings_reset(self) -> None:
        addon = addonName()
        if Dialog().yesno(heading=L(30498, 'Reset {addon} settings').format(addon=addon),
                          message=L(30499, 'Reset settings to the factory defaults?\nThis will overwrite current settings!')):
            if settings.factory_reset():
                notification(addon, L(30500, 'Factory reset is done')).show()
            else:
                notification(addon, L(30501, 'Factory reset FAILED'), icon='ERROR').show()

    @route('/settings/clean')
    def clean_settings(self) -> None:
        addon = addonName()
        answer = 0
        changes = settings.clear_undefined(override_defaults=True, dry_run=True)
        # nothing to clear
        if changes is settings.Changes.NONE:
            Dialog().ok(addonName(), L(30502, 'Settings already cleared'))
            return
        # if there are changes with defaults update, ask for confirmation (yes/no/update_default)
        # elif changes is settings.Changes.DEFAULTS:
        if False:  # force to ask for confirmation
            answer = Dialog().yesnocustom(heading=L(30372, 'Clear {addon} settings').format(addon=addon),
                                          message=L(30373, ('Clear the setting?\nThis will remove undefined user settings.\n'
                                                            'You can override default values with the addon ones.')),
                                          customlabel=L(30495, 'Update defaults too'))
        # if there are changes without defaults update, ask for confirmation (yes/no)
        # elif changes is settings.Changes.CHANGED:
        if True:  # force to ask for confirmation
            answer = Dialog().yesno(heading=L(30372, 'Clear {addon} settings').format(addon=addon),
                                    message=L(30503, 'Clear the setting?\nThis will remove undefined user settings.'))
        if answer:
            override = answer == 2
            if settings.clear_undefined(override_defaults=override):
                notification(addon, L(30375, 'Settings cleared.')).show()
            else:
                notification(addon, L(30376, 'Clear settings FAILED.'), icon='ERROR').show()

    @route('/settings/backup')
    def backup_settings(self) -> None:
        """Make a backup of the user data: the parts and the folder chosen in the backup window."""
        from ..ff.backup import make_backup
        from ..windows.backup import BackupDialog
        addon = addonName()
        if (choice := BackupDialog().do_modal()) is None:
            return
        if make_backup(choice.parts, choice.folder):
            notification(addon, L(30379, 'Backup created.')).show()
        else:
            notification(addon, L(30380, 'Create backup FAILED.'), icon='ERROR').show()

    @route('/settings/restore')
    def restore_settings(self) -> None:
        """Restore a backup of the user data: the backup and its parts chosen in the backup window, confirmed."""
        from ..ff.backup import restore_backup
        from ..windows.backup import BackupDialog
        addon = addonName()
        if (choice := BackupDialog(restore=True).do_modal()) is None or choice.backup is None:
            return
        if Dialog().yesno(heading=L(30384, 'Restore {addon} settings').format(addon=addon),
                          message=L(30385, 'Restore backup: {backup}?\nThis will overwrite current settings!').format(backup=choice.backup.name)):
            if restore_backup(choice.backup, choice.parts):
                notification(addon, L(30386, 'Backup restored. Restart the plugin.')).show()
            else:
                notification(addon, L(30387, 'Restore backup FAILED.'), icon='ERROR').show()

    @route('/netmirror/otp')
    def netmirror_otp(self) -> None:
        code = Dialog().input(heading=L(30603, 'NetMirror OTP code'), type=INPUT_NUMERIC)
        if code:
            set_provider_value('netmirror', 'otp_code', code)
            from ..sources.en.netmirror import source as NetMirrorSource
            NetMirrorSource.prefetch_otp_token()

    @route('/web')
    def web_server(self) -> None:
        from ..windows.site_auth import SiteAuthWindow
        from xbmc import getIPAddress
        ip, port = getIPAddress(), const.tune.service.web_server.port
        url = f'http://{ip}:{port}'
        SiteAuthWindow(code=f'{ip}:{port}', qrcode=url, url=url, progress=False, title=L(30373, 'FanFilm web server')).doModal()
