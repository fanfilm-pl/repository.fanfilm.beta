"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from typing import Optional, Union, Sequence, TYPE_CHECKING
from typing_extensions import Annotated, cast

from ..ff import control
from ..ff.menu import directory, KodiDirectoryKwArgs, KodiDirectory
from ..ff.lists_config import folder_when
from ..ff.routing import route, subobject, MainRouteObject, main_router, PathArg
from ..ff.tricks import singleton, MissingType, MISSING
from ..ff.info import ffinfo, ItemInfoKwargs
from ..ff.item import FFItem
from ..ff.types import PagedItems, SequenceProto
from ..ff.settings import settings
from ..defs import MediaRef
from ..kolang import L
from .folder import filter_kwargs, item_folder_route
from .core import ShowItemKwargs, ShowItemOnlyKwargs, Indexer
from .lists import account_rx
from const import const
if TYPE_CHECKING:
    from typing_extensions import Set, Unpack
    from .search import Search
    from .movies import Movies
    from .tvshows import TVShows
    from .anime import Anime
    from .persons import Persons
    from .stump import Keywords
    from .stump import Companies
    from .collections import Collections
    from .lists.trakt import TraktLists
    from .lists.tmdb import TmdbLists
    from .lists.imdb import ImdbLists
    from .lists.mdblist import MDBListIndexer
    from .lists.wetrakr import WeTrakrLists
    from .lists.floppy import FloppyLists
    from .lists.justwatch import JustWatchLists
    from .lists.kodi import KodiLists
    from .lists.own import OwnLists
    from .history import History
    from .folder import Folder
    from .tools import Tools
    from .dev import DevMenu
    from ..defs import RefType


def reset() -> None:
    """Reset navigator stuff for reuse code (re-run in the same Python interpreter)."""
    ...


reset()


# -- Global routes, MUST be on top of the Navigator (registered first). --
from .play import play  # noqa: E402, F401  (also used by the indexers to build play URLs)


# --- Heler: Multi-search indexer. ---

class MultiSearch(Indexer):
    """Indexer used for multi search."""

    @subobject
    def search(self) -> 'Search':
        """Multi search submodule."""
        from .search import Search
        return Search(indexer=self, type='multi')


# -- The Navigator. --

@singleton
class Navigator(MainRouteObject):
    """Głowne menu FanFilm."""

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        # UWAGA: W tym miejscu zostały użyte nietypowe odwołania sięgające przez klasę (np. Navigator.movie)
        #        a nie przez właściwość (np. self.movie). Jest to użyte WYŁĄCZNIE w celach optymalizacji,
        #        nie trzeba wtedy ładować wszystkich modułów na start. Link wskazuje na cały moduł, nie może
        #        tak wskazać na metodę modułu.
        #        Niezbędnym warunkiem działania są:
        #          - @subobject na wskazanym miejscu (np. w def movie),
        #          - @route('/') w klasie pod-obiektu (np. w Movies).
        # To działa TYLKO w Navigatorze (głównym obiekcie). NIE używać w innych klasach.
        with directory() as kdir:
            if const.debug.dev_menu:
                kdir.folder('« DEV »', Navigator.dev, thumb='featured.png')
            kdir.entry('progress', self.progress)
            kdir.entry('movie', Navigator.movie)
            kdir.entry('show', Navigator.show)
            kdir.entry('anime', Navigator.anime)
            if const.indexer.persons.enabled:
                kdir.entry('person', Navigator.person)
            kdir.entry('lists', self.lists, when=folder_when('main.lists'), add=self.add_my_lists_entries)
            kdir.entry('history', Navigator.history)
            kdir.folder(L(32008, 'Tools'), Navigator.tools, thumb='common/tools.png')  # always there (the settings)
            kdir.entry('search', self.search)  # self.search jest lokalnie
        # one-time changelog, right after an addon update: over the menu shown in the GUI (the call itself does not say
        # if it comes from the GUI; a JSON-RPC call or a widget would wait for the dialog), the next entry otherwise
        version = control.addonInfo('version')
        if version != settings.getString('changelog.version'):
            from ..ff.account_admin import drop_old_keys
            drop_old_keys()  # after an update: once (no key there any more)
            if not settings.getBool('changelog.show_on_update'):
                settings.setString('changelog.version', version)
            elif control.wait_for_folder(control.current_call().addon, const.dialog.changelog.gui_timeout):
                settings.setString('changelog.version', version)
                control.show_changelog()

    @item_folder_route('/progress')
    def progress(self, *, page: PathArg[int] = 1) -> 'Folder':
        """Continue watching: the media in progress, the latest touched first (`continue_watching_folder()`)."""
        from .lists import continue_watching_folder
        return continue_watching_folder(page=page)

    @route
    def search(self) -> None:
        """Main search menu."""
        with directory(thumb='search.png') as kdir:
            kdir.entry('search.movie', self.movie.search)
            kdir.entry('search.show', self.show.search)
            kdir.entry('search.person', self.person.search)
            kdir.entry('search.keyword', self.keyword.search)
            kdir.entry('search.company', self.company.search)
            kdir.entry('search.collection', self.collection.search)
            if const.indexer.search.multi_search:
                kdir.folder(L(30472, 'Multi search'), self.multi.search, thumb='common/search.png')

    @subobject
    def multi(self) -> MultiSearch:
        """Multi search submodule."""
        return MultiSearch()

    @route
    def settings(self) -> None:
        """Open the settings."""
        control.openSettings()
        # control.execute("Dialog.Close(busydialognocancel)")

    def add_my_lists_entries(self, kdir: KodiDirectory):
        """Add the menu of lists (`/list`): the service types (their accounts and general lists) and the own lists."""
        from .lists.menu import add_menu_level
        add_menu_level(kdir, 'lists')

    @route('/list/{__scope}')
    def lists(self, scope: str = '') -> None:
        """User lists (for all services); a group folder of the menu by the pointer of its scope (`/list/trakt.x:watchlist`)."""
        if scope:
            from .lists.menu import menu_directory, pointer_scope
            menu_directory('lists', pointer_scope(scope))
            return
        with directory(view=const.indexer.my_lists_view) as kdir:
            self.add_my_lists_entries(kdir)

    @route
    def noop(self) -> None:
        ...

    def show_items(self,
                   items: SequenceProto[Union[FFItem, MediaRef]],
                   *,
                   # Current page number (starts from one) or None for single/first page. Is ignored at this moment (PagedItems.page is used).
                   page: Optional[int] = None,
                   # All directory (kdir), ffinfo.get_items and Indexer.show_item arguments.
                   **kwargs: 'Unpack[ShowItemKwargs]',
                   ) -> None:
        """Show items in directory, select movie, tvshow or else."""
        # find all used types
        types: 'Set[RefType]' = {it.ref.real_type for it in items if it}
        # only one type, view could be selected
        if len(types) == 1:
            mtype = next(iter(types))
            if kwargs.get('alone') and kwargs.get('view') is None and (view := const.indexer.default_alone_view.get(mtype)):
                kwargs['view'] = view
            if mtype == 'movie':
                return self.movie.show_items(items, **kwargs)
            if mtype == 'show':
                return self.show.show_items(items, **kwargs)
            if mtype == 'season':
                return self.show.show_items(items, **{'view': 'seasons', **kwargs})
            if mtype == 'episode':
                return self.show.show_items(items, **{'view': 'episodes', **kwargs})
            if mtype in ('person', 'collection', 'keyword', 'company'):
                return getattr(self, mtype).show_items(items, **kwargs)
        # no so good known type or mixed types
        pg_items = cast(PagedItems, items)  # directory() check if items object is PagedItems type
        count = 0
        if kwargs.get('view') is None:
            if kwargs.get('alone'):
                # default view for mixed items
                kwargs['view'] = const.indexer.default_alone_view.get('MIXED') or const.indexer.default_mixed_view or 'videos'
            else:
                kwargs['view'] = const.indexer.default_mixed_view or 'videos'
        role_format = kwargs.get('role_format')
        dir_kwargs = filter_kwargs(KodiDirectoryKwArgs, kwargs)
        with directory(pg_items, **dir_kwargs) as kdir:
            show_kwargs = filter_kwargs(ShowItemOnlyKwargs, kwargs)
            show_kwargs.setdefault('alone', True)
            get_kwargs = filter_kwargs(ItemInfoKwargs, kwargs)
            if not kwargs.get('skip_ffinfo'):
                items = ffinfo.get_items(items, **get_kwargs, duplicate=False, keep_missing=False)
            elif TYPE_CHECKING:
                items = cast(Sequence[FFItem], items)
            for it in items:
                count += 1
                mtype = it.ref.type
                if callable(role_format):
                    it.role = role_format(it, count)
                elif role_format is not None:
                    it.role = role_format.format(it=it, item=it, ref=it.ref, index=count, title=it.title, year=it.year)
                if mtype == 'movie':
                    self.movie.show_item(kdir, it, **show_kwargs)
                elif mtype in ('show', 'season', 'episode'):
                    self.show.show_item(kdir, it, **show_kwargs)
                elif mtype in ('person', 'collection', 'keyword', 'company'):
                    getattr(self, mtype).show_item(kdir, it, **show_kwargs)
                else:
                    it.mode = it.Mode.Separator
                    kdir.add(it, url=kdir.no_op)
            if not count:
                kdir.no_content('sets', empty_message=kwargs.get('empty_message'))

    @subobject
    def movie(self) -> 'Movies':
        """Menu /movie."""
        from .movies import Movies
        return Movies()

    @subobject
    @subobject('/tvshow')  # URL for FF3-alfa tests only. TODO: Remove before release.
    def show(self) -> 'TVShows':
        """Menu /show."""
        from .tvshows import TVShows
        return TVShows()

    @subobject
    def anime(self) -> 'Anime':
        """Menu /anime."""
        from .anime import Anime
        return Anime()

    @subobject
    def person(self) -> 'Persons':
        """Menu /person."""
        from .persons import Persons
        return Persons()

    @subobject
    def keyword(self) -> 'Keywords':
        """Menu /keyword."""
        from .stump import Keywords
        return Keywords()

    @subobject
    def company(self) -> 'Companies':
        """Menu /keyword."""
        from .stump import Companies
        return Companies()

    @subobject
    def collection(self) -> 'Collections':
        """Menu /collection (TMDB collections)."""
        from .collections import Collections
        return Collections()

    @subobject('/{account}')
    def trakt(self, account: Annotated[str, account_rx('trakt')] = 'trakt') -> 'TraktLists':
        """Menu /trakt (trakt lists)."""
        from .lists.trakt import TraktLists
        return TraktLists()

    @subobject('/{account}')
    def tmdb(self, account: Annotated[str, account_rx('tmdb')] = 'tmdb') -> 'TmdbLists':
        """Menu /tmdb (tmdb lists)."""
        from .lists.tmdb import TmdbLists
        return TmdbLists()

    @subobject('/{account}')
    def imdb(self, account: Annotated[str, account_rx('imdb')] = 'imdb') -> 'ImdbLists':
        """Menu /imdb (imdb lists)."""
        from .lists.imdb import ImdbLists
        return ImdbLists()

    @subobject('/{account}')
    def mdblist(self, account: Annotated[str, account_rx('mdblist')] = 'mdblist') -> 'MDBListIndexer':
        """Menu /mdblist (mdblist lists)."""
        from .lists.mdblist import MDBListIndexer
        return MDBListIndexer()

    @subobject('/{account}')
    def wetrakr(self, account: Annotated[str, account_rx('wetrakr')] = 'wetrakr') -> 'WeTrakrLists':
        """Menu /wetrakr (wetrakr lists)."""
        from .lists.wetrakr import WeTrakrLists
        return WeTrakrLists()

    @subobject('/{account}')
    def floppy(self, account: Annotated[str, account_rx('floppy')] = 'floppy') -> 'FloppyLists':
        """Menu /floppy (floppy lists)."""
        from .lists.floppy import FloppyLists
        return FloppyLists()

    @subobject('/{account}')
    def justwatch(self, account: Annotated[str, account_rx('justwatch')] = 'justwatch') -> 'JustWatchLists':
        """Menu /justwatch (justwatch lists: of accounts, new VoD)."""
        from .lists.justwatch import JustWatchLists
        return JustWatchLists()

    @subobject('/{account}')
    def kodi(self, account: Annotated[str, account_rx('kodi')] = 'kodi') -> 'KodiLists':
        """Menu /kodi (the local Kodi: history, progress)."""
        from .lists.kodi import KodiLists
        return KodiLists()

    @subobject('/{account}')
    def own(self, account: Annotated[str, account_rx('own')] = 'own') -> 'OwnLists':
        """Menu /own (the lists of FanFilm: favorites, watchlist, own lists, lists defined by an address)."""
        from .lists.own import OwnLists
        return OwnLists()

    @subobject
    def history(self) -> 'History':
        """Menu /history."""
        from .history import History
        return History()

    @subobject
    def tools(self) -> 'Tools':
        """Menu /tools."""
        from .tools import Tools
        return Tools()

    @subobject
    def dev(self) -> 'DevMenu':
        """Developer menu."""
        from .dev import DevMenu
        return DevMenu()


# singleton, the default route object (bound here: the routes above exist once this module is loaded, however it is loaded)
nav = Navigator()
main_router.set_default_route_object(nav)
