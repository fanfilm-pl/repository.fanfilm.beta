
from typing import Any, Optional, Union, Sequence, Iterator, TYPE_CHECKING
from typing_extensions import Literal
from time import monotonic
from attrs import frozen
from cdefs import SourceAttributeBadge, ResolveKind
from ...sources import ResolveRoute
from ...ff.routing import route, subobject, RouteObject, url_for, info_for
from ...ff.menu import directory, CMenu
from ...ff.logs import fflog
from ...ff.kotools import Notification, xsleep
from ...ff.info import ffinfo
from ...defs import MediaRef, MainMediaType
from ..folder import list_directory, item_folder_route, pagination, Folder
from ...kolang import L
from const import const
if TYPE_CHECKING:
    from .widgets import DevWidgets
    from ...ff.item import FFItem
    from ...sources import Source


def print_settings(name: str):
    from ...ff.settings import settings
    for getter in (settings.getBool, settings.getInt, settings.getNumber, settings.getString,
                   settings.getBoolList, settings.getIntList, settings.getNumberList, settings.getStringList):
        try:
            value = getter(name)
        except Exception as exc:
            fflog(f'{name=}: {exc}')
        else:
            fflog(f'{name=}: {getter.__name__}({value!r})')


@frozen
class BadgeDemoRow:
    """A row of the badge demo of the sources window: its label (what it shows), its badges (the rules API), the icon of the source."""

    #: What the row shows (the label of its source).
    label: str
    #: The badges of the row (`SourceAttribute.badge`).
    badges: 'tuple[SourceAttributeBadge, ...]'
    #: The row has the icon of the source (the icons of the right part beside it, the ones `over_item_icon` over it).
    source_icon: bool = False


def badge_demo_rows() -> 'list[BadgeDemoRow]':
    """Return the rows of the badge demo of the sources window: every kind of a badge in every slot of a row, a few in a row."""
    icons = ('noto-1st-place-medal', 'noto-thumbs-up', 'noto-warning', 'noto-stop-sign', 'noto-2nd-place-medal')
    colors = ('CCFF3333', 'CC33FF33', 'CC3366FF', 'CCFFCC33', 'CCFF66FF')

    def badges(kind: str, panel: str, places: str, n: int = 1, **kw: Any) -> 'tuple[SourceAttributeBadge, ...]':
        """
        Return the badges of a kind in the places (`NW NE`) of a part, `n` of each (their orders: the slots of the place); an icon its
        image by the slot (its own colours), the others a colour by the place and the slot (the neighbours differ).
        """
        return tuple(SourceAttributeBadge(type=kind, panel=panel, place=place, order=i + 1,  # type: ignore[misc]
                                          **({'icon': icons[i]} if kind == 'icon' else {'color': colors[(i + j) % len(colors)]}), **kw)
                     for j, place in enumerate(places.split()) for i in range(n))

    over = {'over_item_icon': True}
    return [
        BadgeDemoRow('source icon: right icons NE SE x5 beside it, NE SE x2 over it',
                     badges('icon', 'right', 'NE SE', 5) + badges('icon', 'right', 'NE SE', 2, **over), source_icon=True),
        BadgeDemoRow('source icon: right icon E beside it, E over it', badges('icon', 'right', 'E') + badges('icon', 'right', 'E', **over), source_icon=True),
        BadgeDemoRow('right icons NE SE x5', badges('icon', 'right', 'NE SE', 5)),
        BadgeDemoRow('right icon E, left icons W E', badges('icon', 'right', 'E') + badges('icon', 'left', 'W E')),
        BadgeDemoRow('left icons NW NE SE SW x2', badges('icon', 'left', 'NW NE SE SW', 2)),
        BadgeDemoRow('item ribbons NW NE SE SW', badges('ribbon', 'item', 'NW NE SE SW')),
        BadgeDemoRow('left, right ribbons NW NE SE SW, left icon NW over its ribbon',
                     badges('ribbon', 'left', 'NW NE SE SW') + badges('ribbon', 'right', 'NW NE SE SW') + badges('icon', 'left', 'NW')),
        BadgeDemoRow('item bars N S W E', badges('bar', 'item', 'N S W E')),
        BadgeDemoRow('left, right bars N S W E', badges('bar', 'left', 'N S W E') + badges('bar', 'right', 'N S W E')),
        BadgeDemoRow('item lines N S, left lines N S W E H', badges('line', 'item', 'N S') + badges('line', 'left', 'N S W E H')),
        BadgeDemoRow('right lines N S x2, H W E', badges('line', 'right', 'N S', 2) + badges('line', 'right', 'H W E')),
        BadgeDemoRow('split (the joint of the parts) stickers C N S, lines V x2', badges('icon', 'split', 'C N S') + badges('line', 'split', 'V', 2)),
        BadgeDemoRow('item numbers NW NE, the text tag NE (the number beside it)',
                     (SourceAttributeBadge(number=7, place='NW'), SourceAttributeBadge(number=888, place='NE'), SourceAttributeBadge(text='TEXT TAG'))),
        BadgeDemoRow('source icon: the text tag NE, item number NE beside them',
                     (SourceAttributeBadge(text='TEXT TAG'), SourceAttributeBadge(number=888, place='NE')), source_icon=True),
        BadgeDemoRow('source icon: item number NE beside it', (SourceAttributeBadge(number=888, place='NE'),), source_icon=True),
        BadgeDemoRow('source icon: the text tag NE, right icons NE x2 beside them',
                     (SourceAttributeBadge(text='TEXT TAG'),) + badges('icon', 'right', 'NE', 2), source_icon=True),
    ]



@frozen(kw_only=True)
class SourceDemoRow:
    """A row of the rows demo of the sources window: the meta of its source (`Source.from_meta()`) and the ways which open it."""

    #: The meta of the source (provider, hosting, quality, texts ...; the URL derived when missing).
    meta: 'dict[str, Any]'
    #: The ways which open it (`Resolvability`, sorted as FanFilm sorts them), none: no way (greyed out).
    routes: 'tuple[ResolveRoute, ...]' = ()

    def source(self, ffitem: 'FFItem', n: int) -> 'Source':
        """Return the source of the row number `n` of the media (its URL by the number when missing), its ways sorted as FanFilm sorts them."""
        from ...ff.sources import ResolveMap
        from ...sources import Source
        meta = {'url': f'https://demo.invalid/{n:02d}', 'language': 'pl', 'info2': '', **self.meta}
        src = Source.from_meta(ffitem=ffitem, meta=meta)  # type: ignore[arg-type]
        src.resolvability = ResolveMap().ordered(self.routes)
        return src


def source_demo_rows() -> 'list[SourceDemoRow]':
    """
    Return the rows of the rows demo of the sources window (no search, no account, no network): every way FanFilm opens a source
    (debrids with the torrent cached / not / not known, three debrids of one torrent, premium accounts, direct links, a plugin, the
    resolvers, the provider itself, none), long names (a provider of a number, the info, the hosting, an emoji file name), languages,
    packs, the library, the sources of the provider add-ons.
    """
    film = 'The.Dark.Knight.2008.MULTi.1080p.BluRay.x264-DSiTE.mkv'
    #: the file names of the rows (their facts differ: the panel of the filter shows their values)
    films = ('The.Dark.Knight.2008.1080p.WEB-DL.DDP5.1.H.264-NTb.mkv', 'The.Dark.Knight.2008.720p.BluRay.x264.AAC-YTS.mp4',
             'The.Dark.Knight.2008.2160p.WEB-DL.DV.HDR10Plus.HEVC.Atmos-FLUX.mkv', 'The.Dark.Knight.2008.1080p.BluRay.10bit.x265.DTS-HD.MA.5.1.Extended.mkv',
             'The.Dark.Knight.2008.HDCAM.x264-PL.avi', 'The.Dark.Knight.2008.3D.HSBS.1080p.BluRay.x264.mkv',
             'The.Dark.Knight.2008.PL.1080p.WEBRip.AV1.Opus.mkv', 'Mroczny.Rycerz.2008.PL.DUBBING.AI.720p.HDTV.XviD.avi',
             'The.Dark.Knight.2008.IMAX.2160p.UHD.BluRay.REMUX.HDR10.TrueHD.7.1.Atmos.mkv', 'The.Dark.Knight.2008.1080p.Hi10P.BluRay.FLAC.2.0.mkv',
             'The.Dark.Knight.2008.PLSUB.1080p.WEB-DL.H264.AC3.mkv', 'The.Dark.Knight.2008.Directors.Cut.1080p.WEB-DL.EAC3.5.1.H.265.mkv',
             'Mroczny.Rycerz.2008.Lektor.PL.AI.1080p.WEB-DL.x264.mkv', 'The.Dark.Knight.2008.PROPER.REPACK.720p.DVDRip.MPEG2.AC3.mpg',
             'The.Dark.Knight.2008.1080p.TELESYNC.PLDUB.MD.x264.mkv')
    long_file = 'Mroczny.Rycerz.The.Dark.Knight.2008.PL.DUBBING.KINO.LEKTOR.MULTi.2160p.UHD.BluRay.REMUX.HDR10.DV.TrueHD.Atmos.7.1-FraMeSToR.mkv'
    ffork, fenom, coco, magneto = 'script.fanfilm.provider.ffork', 'script.fanfilm.provider.fenom', 'script.module.cocoscrapers', 'script.module.magneto'

    def magnet(n: int) -> str:
        """Return the magnet link of the demo torrent `n`."""
        return f'magnet:?xt=urn:btih:{n:040x}'

    def debrid(name: str, cached: 'bool | None' = None) -> ResolveRoute:
        """Return the way of a debrid (`cached`: the torrent cached on it)."""
        return ResolveRoute(kind='debrid', name=name, cached=cached)

    def way(kind: ResolveKind, name: str) -> ResolveRoute:
        """Return a way of the kind (not a debrid)."""
        return ResolveRoute(kind=kind, name=name)

    return [
        # debrids: the hosters of a free provider, the torrents cached / not cached / not known, three debrids of one torrent
        SourceDemoRow(meta={'provider': 'premiumsmart', 'hosting': 'streamtape.com', 'quality': '1080p', 'info': 'Lektor Multi | BluRay | H264',
                            'filename': film}, routes=(debrid('Premiumize.me'), way('resolveurl', 'streamtape.com'))),
        SourceDemoRow(meta={'provider': 'obejrzyjto', 'hosting': 'voe.sx', 'quality': '720p', 'info': 'Napisy', 'filename': films[0]},
                      routes=(debrid('AllDebrid'),)),
        SourceDemoRow(meta={'provider': 'filmyonline', 'hosting': 'dood.watch', 'quality': '1080p', 'info': 'Lektor', 'filename': films[1]},
                      routes=(debrid('Debrid-Link'),)),
        SourceDemoRow(meta={'provider': 'ffork:torrentio', 'addon': ffork, 'hosting': 'torrent', 'quality': '2160p', 'size': '58.3 GB',
                            'info': 'Multi | REMUX | HEVC | HDR10 DV | DTS-HD MA 5.1 · TrueHD · AC3', 'filename': long_file, 'url': magnet(1)},
                      routes=(debrid('TorBox', True),)),  # cached, a long first line (it reaches the cached symbol)
        SourceDemoRow(meta={'provider': 'fenom:torrentgalaxy', 'addon': fenom, 'hosting': 'torrent', 'quality': '1080p', 'size': '12.1 GB',
                            'info': 'WEB-DL', 'filename': films[2], 'url': magnet(2)}, routes=(debrid('TorBox', False),)),
        SourceDemoRow(meta={'provider': 'coco:knaben', 'addon': coco, 'hosting': 'torrent', 'quality': '1080p', 'size': '9.4 GB', 'info': 'BluRay',
                            'filename': films[3], 'url': magnet(3)}, routes=(debrid('Real-Debrid'), debrid('Premiumize.me', True), debrid('AllDebrid', False))),
        SourceDemoRow(meta={'provider': 'coco:thepiratebay', 'addon': coco, 'hosting': 'torrent', 'quality': '720p', 'size': '1.4 GB',
                            'filename': films[4], 'url': magnet(4)}, routes=(debrid('Real-Debrid'),)),
        SourceDemoRow(meta={'provider': 'magneto:eztv', 'addon': magneto, 'hosting': 'torrent', 'quality': '1080p', 'size': '2.2 GB',
                            'filename': films[5], 'url': magnet(5)}, routes=(debrid('AllDebrid', True), debrid('Real-Debrid'))),
        # premium accounts: on the account (its expiry), with the transfer, without it (a debrid opens it / nothing does), one plan
        SourceDemoRow(meta={'provider': 'tb7', 'hosting': 'rapidgator.net', 'quality': '1080p', 'size': '8.2 GB', 'info': 'Lektor', 'filename': films[6],
                            'premium': True, 'on_account': True, 'on_account_expires': '2026-12-31'}, routes=(way('account', 'tb7'),)),
        SourceDemoRow(meta={'provider': 'twojlimit', 'hosting': 'turbobit.net', 'quality': '1080p', 'size': '8.2 GB', 'info': 'Lektor',
                            'filename': films[7], 'premium': True}, routes=(way('account', 'twojlimit'),)),
        SourceDemoRow(meta={'provider': 'nopremium', 'hosting': 'nitroflare.com', 'quality': '2160p', 'size': '41 GB', 'info': 'Dubbing Kino',
                            'filename': long_file, 'premium': True, 'no_transfer': True}, routes=(debrid('Real-Debrid'),)),
        SourceDemoRow(meta={'provider': 'nopremium', 'hosting': 'katfile.com', 'quality': '1080p', 'size': '6.3 GB', 'info': 'Lektor', 'filename': films[8],
                            'premium': True, 'no_transfer': True}),
        SourceDemoRow(meta={'provider': 'ekinopremium', 'hosting': 'mix', 'quality': '720p', 'info': 'Lektor', 'filename': '90-minut-do-wolnosci-hd-mercy-2026',
                            'premium': True, 'direct': True}, routes=(way('account', 'ekinopremium'), way('direct', 'ekinopremium'))),
        SourceDemoRow(meta={'provider': 'cda', 'hosting': 'cda.pl', 'quality': '1080p', 'info': 'Lektor', 'filename': films[9], 'premium': True,
                            'direct': True}, routes=(way('account', 'cda'), way('direct', 'cda'))),  # premium among the free ones of its provider
        # free: a direct link, a plugin, the resolvers of FanFilm / ResolveURL, the provider itself, only a debrid and none (greyed out)
        SourceDemoRow(meta={'provider': 'cda', 'hosting': 'cda.pl', 'quality': '1080p', 'info': 'Lektor', 'filename': films[10], 'direct': True},
                      routes=(way('direct', 'cda'),)),
        SourceDemoRow(meta={'provider': 'youtube', 'hosting': 'plugin.video.youtube', 'quality': '1080p', 'info': 'Napisy',
                            'url': 'plugin://plugin.video.youtube/play/?video_id=demo'}, routes=(way('plugin', 'plugin.video.youtube'),)),
        SourceDemoRow(meta={'provider': 'zaluknijcc', 'hosting': 'vidoza.net', 'quality': '720p', 'info': 'Lektor', 'filename': films[11]},
                      routes=(way('ff', 'vidoza.net'), way('resolveurl', 'vidoza.net'))),
        SourceDemoRow(meta={'provider': 'filman', 'hosting': 'upstream.to', 'quality': 'SD', 'info': 'Lektor', 'filename': films[12]},
                      routes=(way('resolveurl', 'upstream.to'),)),
        SourceDemoRow(meta={'provider': 'vixsrc', 'hosting': '', 'quality': '1080p', 'language': 'en', 'info': 'Original', 'filename': ''},
                      routes=(way('provider', 'vixsrc'),)),
        SourceDemoRow(meta={'provider': 'alefilmy', 'hosting': 'unknownhost.xyz', 'quality': 'CAM', 'info': 'Lektor', 'filename': films[13],
                            'debridonly': True}),
        # long names: a provider of a number (`.2`), a long info, a long hosting and an emoji file name, an add-on of a long name
        SourceDemoRow(meta={'provider': 'rapideo.2', 'hosting': 'rapidgator.net', 'quality': '1080p', 'info': 'Lektor', 'filename': films[14],
                            'premium': True}, routes=(way('account', 'rapideo.2'),)),
        SourceDemoRow(meta={'provider': 'dramaqueen', 'hosting': 'streamtape.com', 'quality': '1080p', 'language': 'ko', 'info': 'Napisy PL',
                            'filename': long_file}, routes=(debrid('Simply-Debrid'),)),
        SourceDemoRow(meta={'provider': 'ffork:fourkhdhub', 'addon': ffork, 'hosting': 'hubcloud.ink', 'quality': '2160p', 'size': '61.7 GB',
                            'info': 'HDR10+ | DV | TrueHD Atmos 7.1 | REMUX | Multi Audio | Multi Subs', 'info2': 'HEVC | 10bit', 'filename': long_file},
                      routes=(debrid('Real-Debrid'), way('provider', 'ffork:fourkhdhub'))),
        SourceDemoRow(meta={'provider': 'webstreamr', 'hosting': 'supervideo-very-long-hosting-name.cc', 'quality': '1080p', 'language': 'multi',
                            'info': 'Dubbing', 'filename': f'\U0001f3ac {long_file}'}, routes=(way('resolveurl', 'supervideo.cc'),)),
        # languages, audio types, packs, the library
        SourceDemoRow(meta={'provider': 'shinden', 'hosting': 'cda.pl', 'quality': '1080p', 'language': 'ja', 'info': 'Napisy', 'filename': films[0],
                            'pack': 'season', 'direct': True}, routes=(way('direct', 'shinden'),)),
        SourceDemoRow(meta={'provider': 'tvpvod', 'hosting': 'vod.tvp.pl', 'quality': '1080p', 'info': 'Audiodeskrypcja | Lektor', 'filename': '',
                            'pack': 'show', 'direct': True}, routes=(way('direct', 'tvpvod'),)),
        SourceDemoRow(meta={'provider': 'library', 'hosting': '', 'quality': '1080p', 'info': 'Dubbing', 'filename': '/media/films/Mroczny Rycerz (2008).mkv',
                            'local': True}, routes=(way('direct', 'library'),)),
    ]

class DevMenu(RouteObject):
    """Głowne menu FanFilm."""

    def __init__(self) -> None:
        super().__init__()
        self.notif = Notification('FF dev', 'Test continous notification')

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        from ...main import restart
        from ..navigator import nav
        with directory(view='sets') as kdir:
            kdir.action(L(30150, 'Configuration'), nav.tools.config, thumb='common/tools.png')
            kdir.folder('GUI', self.gui)
            kdir.folder('Library', self.library)
            kdir.action('Empty folder', self.empty)
            kdir.folder('Images', self.images)
            kdir.folder('Notifications', self.notifications)
            kdir.folder('Old tests', self.old_tests)
            kdir.action('Nothing', kdir.no_op)  # do nothing
            kdir.action('Restart server', restart)
            kdir.action('Exit', self.exit)  # The Last One

    @route
    def old_tests(self) -> None:
        with directory(view='sets') as kdir:
            kdir.action('Videos', self.videos)
            kdir.action('Video DB info', self.video_db)
            kdir.action('Simple dialog', self.simple_dialog)
            kdir.action('Test settings engine', self.test_settings)
            kdir.folder('Settings', self.settings)
            kdir.action('Mixed IDs', self.mixed_ids)

    @route
    def images(self) -> None:
        with directory(view='sets') as kdir:
            kdir.action('Gallery', self.gallery)
            kdir.folder('Genre Images', self.genre_images)
            kdir.action('Image slideshow', self.image_slideshow)

    @route
    def gui(self) -> None:
        with directory(view='sets') as kdir:
            kdir.action('Widget demo', self.widgets.home)
            kdir.action('Focus lines', self.focus_lines)
            kdir.action('Auth dialog', self.auth_dialog)
            kdir.folder('Ratings', self.ratings)
            kdir.folder('Add-to stuff', self.add_to)
            kdir.folder('Source dialog', self.source_dialog)
            kdir.folder('Color picker', self.colorpicker)
            kdir.action('Test GUI', self.test_gui)

    @subobject
    def widgets(self) -> 'DevWidgets':
        """The widget demo."""
        from .widgets import DevWidgets
        return DevWidgets()

    @route
    def exit(self) -> None:
        """The iterpreter exit. Reload sources in next plugin call."""
        import sys
        sys.exit()

    @route
    def empty(self) -> None:
        """Folder with no items."""
        with directory(view='sets'):
            pass

    @route
    def videos(self) -> None:
        from ...main import fake_play_movie
        with directory(view='videos') as kdir:
            # kdir.play('Fake video', url_for(fake_play_movie, ref=MediaRef('movie', 909_000_001)))
            kdir.play('Fake video', url_for(fake_play_movie, ffid=100_000_646))
            ffitem = ffinfo.find_item(MediaRef('movie', 100_000_646))
            if ffitem:
                ffitem.label = 'Fake video'
                ffitem.url = str(url_for(fake_play_movie, ffid=ffitem.ref.ffid))
                kdir.add(ffitem)

    @route
    def notifications(self) -> None:
        with directory(view='sets') as kdir:
            kdir.action('Notification', self.notification)
            kdir.action('Send notif', self.send_notif)

    @route
    def notification(self) -> None:
        from ...ff.kotools import Notification, xsleep
        if 1:
            # xsleep(1.025)
            with Notification('FF dev', 'This is a test notification') as notif:
                fflog('[DEV] Notification start')
                xsleep(3)
                fflog('[DEV] Notification stop')
                xsleep(2)
        if 0:
            fflog('[DEV] Notification show 3s')
            self.notif.show()
            xsleep(3)
            fflog('[DEV] Notification show 5s (re-show)')
            # self.notif.message = 'Re-shown notification'
            self.notif.show(message='Continue notification')
            xsleep(8)
            fflog('[DEV] Notification show 5s (re-show)')
            # self.notif.message = 'Re-shown notification'
            self.notif.show(message='Re-show notification', interval=2)
            xsleep(5)
            fflog('[DEV] Notification script exit')

    @route
    def simple_dialog(self) -> None:
        from ...windows.dialogs import SimpleDialog, ButtonBox
        win = SimpleDialog('label|text', label='Bla bla bla', text="...", buttons=ButtonBox.YES_NO)
        result = win.doModal()
        fflog(f'[DEV] Dialog result: {result!r}')
        Notification('FF dev', f'Dialog result: {result!r}').show()

    @route('/auth/{__what}')
    def auth_dialog(self, what: Literal['tmdb', 'trakt'] = 'trakt') -> None:
        from ...windows.site_auth import SiteAuthWindow
        from ...ff.control import dataPath as DATA_PATH
        from pathlib import Path
        import segno
        if what == 'tmdb':  # TMDB
            token = ('eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5MDgwNjQ3ZmYxNjQ3ZiIsIm5iZiI6mYwMmI3NDc4ZGI5MDBmMTIzYMTc0MzU5Mjc2MS44MTkzLCJqdGkiOiI2N2VkMW'
                     'QzOTM0YzZjOTQxMDhkMGJmZmUiLCJzY29wZXMiOlsRva2VuIl0sInZlcnNpb24icGVuZGluZ19yZXF1ZXN0X3iOjIsImV4cCI6MTc0MzU5MzY2MX0.U8Tq8eLlC3e0Tb5O1P2lOYPyKdsTvgEufWG4tQGWnOk')
            verification_url = f'https://www.themoviedb.org/auth/access?request_token={token}'

            code_hash = f'{hash(verification_url):08x}'
            icon = Path(DATA_PATH) / f'tmp/dev-auth-qrcode.{code_hash}.png'
            icon.parent.mkdir(parents=True, exist_ok=True)
            qrcode = segno.make(verification_url)
            qrcode.save(str(icon), scale=const.tmdb.auth.qrcode_size)
        else:  # Trakt
            token = '12345678'
            verification_url = f'https://trakt.tv/activate/{token}'
            code_hash = f'{hash(verification_url):08x}'
            icon = Path(DATA_PATH) / f'tmp/dev-auth-qrcode.{code_hash}.png'
            icon.parent.mkdir(parents=True, exist_ok=True)
            qrcode = segno.make(verification_url)
            qrcode.save(str(icon), scale=const.trakt.auth.qrcode.size)
        modal = False
        win = SiteAuthWindow(code=token, url=verification_url, icon=icon, modal=modal)
        if modal:
            win.update(100)
            result = win.doModal()
        else:
            win.doModal()  # this dialog is modeless (!)
            try:
                for progress in range(0, 101, 5):
                    # Current timestamp.
                    now = monotonic()
                    # check if dialog is canceled
                    if win.dialog_is_canceled():
                        break
                    # check if user authorized this device
                    # if access := self._get_access_token(device_code, cred):
                    #     break
                    # update progress-bar
                    win.update(int(progress))
                    # sleep given interval
                    xsleep(0.5)
            except KeyboardInterrupt:
                print('''\nCancelled. Enter '0'.\n''')
            finally:
                # finish - close dialog (its result is known once it is closed)
                win.destroy()
                result = win.result()
                del win
        icon.unlink()
        fflog(f'[DEV] Dialog result: {result!r}')
        Notification('FF dev', f'Dialog result: {result!r}').show()

    @route
    def add_to(self) -> None:
        with list_directory(view='sets') as kdir:
            kdir.action('Add-to dialog', self.add_to_dialog)
            kdir.action('New-list dialog', self.new_list_dialog)
            kdir.folder('Example items', info_for(self.item_examples))

    @route
    def colorpicker(self) -> None:
        """The colour picker of no place: a colour, a colour with its opacity (nothing written, the result shown)."""
        from ...sources.source_settings import source_setting
        identify2 = source_setting('default_color')
        with directory(view='sets') as kdir:
            kdir.action('Color', info_for(self.colorpicker_open, default=identify2))
            kdir.action('Color with opacity', info_for(self.colorpicker_open, alpha=True, default=identify2))
            kdir.action('Color (no default)', info_for(self.colorpicker_open))

    @route
    def colorpicker_open(self, alpha: bool = False, default: str = '') -> None:
        """The colour picker of no colour (the default one; `alpha`: with the opacity slider), its choices and its result logged, the result notified."""
        from ...windows.color_picker import ColorPicker
        win = ColorPicker(alpha=alpha, default=default)
        win.changed.connect(lambda color: fflog(f'[DEV] ColorPicker changed: {color!r}'))
        color = win.do_modal()
        del win
        fflog(f'[DEV] ColorPicker result: {color!r}')
        Notification('FF dev', f'Color: {color!r}').show()

    def _item_examples(self) -> Sequence[MediaRef]:
        from ...defs import VideoIds
        tmdb = VideoIds.ffid_from_tmdb_id
        items = [
            MediaRef('movie', tmdb(78)),
            MediaRef('show', tmdb(119051)),
            MediaRef('show', tmdb(1434), 2),
            MediaRef('show', tmdb(2734), 3, 4),
            MediaRef('person', tmdb(190)),
            MediaRef('collection', tmdb(726871)),
            MediaRef('genre', tmdb(12)),
            # MediaRef('list', 123),  # not-supported
        ]
        return items

    @item_folder_route
    def item_examples(self) -> Sequence[MediaRef]:
        return self._item_examples()

    @route
    def add_to_dialog(self, empty: bool = False) -> None:
        """The Add-to dialog of the example items (`empty`: a service without lists first)."""
        from ...windows.add_to import AddToDialog, ListInfo
        from ...ff.control import notification
        from ...ff.lists import ServiceDescr, add_to_defs
        items = self._item_examples()
        services = {'No lists (dev)': [ServiceDescr('dev:empty')], **add_to_defs()} if empty else None
        win = AddToDialog(items=items, services=services)
        lst: Optional[ListInfo] = win.doModal()
        fflog(f'Add-to dialog {lst=}')
        if lst:
            num = lst.add_items(items=items)
            notification(L(30476, 'Add to {pointer} list').format(pointer=lst.service.pointer),
                         L(30478, 'Added {n} item to {name}|||Added {n} items to {name}', n=num, name=lst.name), visible=True)

    @route
    def new_list_dialog(self, service: str = '') -> None:
        """The new list dialog (`service`: of the first account of the type creating lists, e.g. imdb - its choices of the types)."""
        from ...windows.new_list import NewWindowDialog
        from ...ff.lists import add_to_defs, add_to_services
        found = next((srv for group in add_to_services(add_to_defs()).values() for srv in group
                      if srv.create_enabled() and getattr(srv, 'type_name', '') == service), None) if service else None
        win = NewWindowDialog() if found is None else NewWindowDialog.of_service(found)
        result = win.doModal()
        fflog(f'New-list dialog {result=}')

    @route
    def video_db(self) -> None:
        import sys
        from ...ff.kodidb import video_db
        # video_db.get_players()
        # video_db.get_player_item()
        x = tuple(video_db.get_library('movie'))
        fflog(f'ITEMS count {len(x)}')
        if x:
            fflog(f'First item {x[0]}')
        sys.exit(0)

    @route
    def send_notif(self) -> None:
        # import json
        # import xbmc
        # req = json.dumps({
        #     'id': 123,
        #     'jsonrpc': '2.0',
        #     'method': 'JSONRPC.NotifyAll',
        #     'params': {
        #         'sender': 'Dupa',
        #         'message': 'Blada',
        #         'data': {'a': 42},
        #     },
        # })
        # fflog(f'RPC {req = }')
        # resp = xbmc.executeJSONRPC(req)
        # fflog(f'RPC {resp = }')
        from ...ff.kotools import KodiRpc
        req  = {'dupa': 'blada'}
        fflog(f'RPC {req  = }')
        T = monotonic()
        resp = KodiRpc().service_call('ServicePing', req, timeout=3)
        T = monotonic() - T
        fflog(f'RPC {resp = }  [{T:.3f}s]')

    @route
    def test_gui(self) -> None:
        import xbmcgui
        from ...windows.base import BaseDialog

        class Test(BaseDialog):
            XML = 'Test.xml'

            def on_action(self, action: 'xbmcgui.Action') -> None:
                aid = action.getId()
                if xbmcgui.ACTION_JUMP_SMS2 <= aid <= xbmcgui.ACTION_JUMP_SMS9:
                    btn = aid - xbmcgui.ACTION_JUMP_SMS2 + 2
                elif xbmcgui.REMOTE_0 <= aid <= xbmcgui.REMOTE_9:
                    btn = aid - xbmcgui.REMOTE_0
                else:
                    btn = None
                name = ''
                for k in dir(xbmcgui):
                    if k.isupper() and getattr(xbmcgui, k) == aid:
                        name = k
                        break
                fflog(f'[Test] Action: code={action.getId()}, digit={btn}')
                self.get_control(1000).setLabel(f'Action: code={action.getId()}, button={action.getButtonCode()}, name={name}\nDIGIT={btn}')
                super().on_action(action)

        Test().doModal()

    @route
    def focus_lines(self, window: str = 'focus_lines_dialog') -> None:
        """
        A live test window of the focus lines: its template `test/ff/data/<window>.xml` (a source checkout only, not shipped;
        `focus_lines_cross_dialog`: the crossings) generated with the widget families in the profile (the generator takes them
        from the folder of the window).
        """
        import shutil
        from pathlib import Path
        from ...ff.control import addonPath, dataPath
        from ...windows.base import BaseDialog
        from ...windows.gui import WIDGETS_FOLDER
        addon = Path(addonPath)
        folder = Path(dataPath) / 'widget-test' / 'skins' / WIDGETS_FOLDER
        shutil.rmtree(folder, ignore_errors=True)  # a family removed or renamed since would declare its widgets again
        folder.mkdir(parents=True, exist_ok=True)
        for path in (*(addon / 'resources' / 'skins' / WIDGETS_FOLDER).glob('*.xml'), addon / 'test' / 'ff' / 'data' / f'{window}.xml'):
            shutil.copy(path, folder)

        class FocusLinesDialog(BaseDialog):
            """The window of the test."""

            @classmethod
            def widget_source(cls, script_path: str) -> Path:
                """Return the source in the profile."""
                return folder / f'{window}.xml'

            def on_init(self) -> None:
                """The rows of the list (a window with one)."""
                if 'list' in self.widgets.children:
                    self.find('list').rows = [f'Row {i}' for i in range(1, 13)]

        FocusLinesDialog().doModal()

    @route
    def library(self) -> None:
        from ...ff.kodidb import video_db
        video_db.get_library('movie')
        with list_directory(view='sets') as kdir:
            kdir.folder('Mixed', info_for(self.library_items))
            for media in ('movie', 'show', 'season', 'episode'):
                kdir.folder(media.capitalize(), info_for(self.library_items, media=media))

    @item_folder_route('/library/media/{__media}')
    @pagination(20)
    def library_items(self, media: Optional[Literal['movie', 'show', 'season', 'episode']] = None):
        from ...ff.kodidb import video_db
        return Folder(video_db.get_library_ffitems(media), alone=True)
        # items = video_db.get_library_dict(media)
        # return Folder([it.ffitem() for ref, it in items.items() if not media or media == ref.real_type], alone=True)

    @route
    def test_settings(self) -> None:
        from ...ff.settings import settings
        for name in (
            # 'library.service.update',
            # 'library.days_delay',
            'movie.download.path',
        ):
            print_settings(name)
            fflog(f'DEF: {settings.definitions[name]}')
            val = settings.eval(f'0 or {name}')
            # val = settings.eval(f'0 or {{{name}}}')
            fflog(f'VAL: {val}')
        print(settings.eval('{listCache}'))

    @route('/source_filters')
    def source_filters(self, media: Literal['movie', 'show'] = 'movie') -> None:
        from ...windows.source_filters_dialog import SourceFiltersDialog
        SourceFiltersDialog(media=media).doModal()

    @route('/source_dialog')
    @route('/source_dialog/{media}/{tmdb}')
    def source_dialog(self, media: Union[MainMediaType, Literal['progress', 'badges', 'colors', 'rows', 'live'], None] = None, tmdb: int = 0,
                      edit: bool = False) -> None:
        from ...windows.sources import SourceDialog, EditDialog
        from ...ff.sources import Source, RescanSources
        from ...sdk.protocol import resolve_result
        from ...ff.db.search import sources_edit_db
        from ...ff.control import addonInfo
        from attrs import evolve
        if TYPE_CHECKING:
            from typing import Callable
            from ...ff.sources import SourceSearchQuery, SourceResolveKwargs, SourceManager as SourceFactory, FFItem
            from ...sources import ProviderModule, SourceXMeta

        class FakeSources:
            """The sources of the demo: each resolved to its own URL, the real providers by their names (their declarations)."""

            def __init__(self, ffitem: 'FFItem') -> None:
                #: The media of the demo (the providers scanned for it).
                self.ffitem: 'FFItem' = ffitem
                #: The scanned providers by their names (none yet: scanned at the first ask).
                self.modules: 'dict[str, ProviderModule] | None' = None
                #: The priority of the provider of a source in the sort of the user (none in the demo).
                self.source_priority: 'Callable[[Source], int]' = lambda src: 0

            def provider_module(self, name: str) -> 'ProviderModule | None':
                """Return the provider module by its name (the real one: the demo rows of the real providers)."""
                if self.modules is None:
                    from ...sources import scan_providers
                    self.modules = {mod.name: mod for mod in scan_providers(ffitem=self.ffitem)}
                return self.modules.get(name)

            def resolve_source(self, item: 'Source', /, info: bool = False, for_resolve: 'SourceResolveKwargs | None' = None, **kwargs) -> 'Source | None':
                """Return the source resolved to its own URL."""
                return item.with_stream(resolve_result(item.url))

        #: the facts of the fake sources (lists of other lengths: every source another mix): the tags of the file name, the quality,
        #: the size, the language type, the language
        fake_tags = ('WEB-DL.DDP5.1.H.264', 'BluRay.x264.AAC', 'WEB-DL.DV.HDR10Plus.HEVC.Atmos', 'BluRay.10bit.x265.DTS-HD.MA.5.1.Extended',
                     'HDCAM.x264', '3D.HSBS.BluRay.x264', 'WEBRip.AV1.Opus', 'HDTV.XviD', 'IMAX.UHD.BluRay.REMUX.HDR10.TrueHD.7.1.Atmos',
                     'Hi10P.BluRay.FLAC.2.0', 'WEB-DL.H264.AC3', 'Directors.Cut.WEB-DL.EAC3.5.1.H.265', 'PROPER.REPACK.DVDRip.MPEG2.AC3',
                     'TELESYNC.x264.MD', 'HDR.WEB-DL.HEVC.AAC.2.0', 'Colorized.by.AI.BluRay.x264')
        fake_qualities = ('720p', '1080p', '4K', 'SD', '1080p', 'CAM', '720p', 'SCR', '4K', '1080p', 'SD')
        fake_sizes = ('1.4 GB', '4.7 GB', '700 MB', '12.1 GB', '', '58.3 GB', '2.2 GB', '350 MB', '24 GB')
        fake_infos = ('Lektor', 'Dubbing', 'Napisy', 'Lektor AI', 'Dubbing Kino', '', 'Napisy PL | ENG', 'Lektor | Napisy', 'Multi')
        fake_languages = ('pl', 'pl', 'en', 'pl', 'multi', 'pl', 'de')
        fake_containers = ('mkv', 'mp4', 'mkv', 'avi', 'mkv', 'ts')

        def fake_source(ffitem: 'FFItem', providers: 'Sequence[str]' = ()) -> 'Iterator[Source]':
            """Yield the fake sources (32, mixed facts), of the `providers` (as many sources, else the provider FAKE)."""
            for i in range(len(providers) or 32):
                meta: 'SourceXMeta' = {}  # type: ignore[assignment]
                if i == 0:
                    meta['icon'] = addonInfo('icon')
                yield Source.from_meta(ffitem=ffitem, meta={
                    'addon': 'coco' if i & 16 else '',
                    'provider': providers[i] if providers else 'FAKE',
                    'direct': True,
                    'filename': f'video.bla.bla.{i+1:02d}.{fake_tags[i % len(fake_tags)]}.{fake_containers[i % len(fake_containers)]}',
                    'info': f'{fake_infos[i % len(fake_infos)]} | kicha {i+1:02d}',
                    'language': fake_languages[i % len(fake_languages)],
                    'on_account': bool(i & 4),
                    'quality': fake_qualities[i % len(fake_qualities)],
                    'size': fake_sizes[i % len(fake_sizes)],
                    'hosting': '' if i & 2 else 'pustka',
                    'url': f'ftp://dupa/zbita/{i+1:02d}',
                    'info2': 'NIC | ZUPEŁNIE',
                    # 'color_identify': 'FF20C020',
                    'debrid': '',
                    'no_transfer': bool(i & 8),
                    **meta,
                })

        def make_query(ffitem: 'FFItem') -> 'SourceSearchQuery':
            ref = ffitem.ref
            ffitem.copy_from(ffitem.season_item, ffitem.show_item)
            if ref.type == 'show' and (sh_item := ffitem.show_item):
                vtag = sh_item.getVideoInfoTag()
                premiered = sh_item.date
            else:
                vtag = ffitem.getVideoInfoTag()
                premiered = ffitem.date
            # get aliases (new way)
            if show_ffitem := ffitem.show_item:
                ffinfo.get_title_aliases(show_ffitem)
            else:
                ffinfo.get_title_aliases(ffitem)
            # `title` and `show_title` should be in English.
            title = vtag.getTitle()
            en_title = vtag.getEnglishTitle() or vtag.getOriginalTitle() or title
            query: 'SourceSearchQuery' = {
                'english_title': en_title,
                'local_title': title,  # title is in api locale
                'year': vtag.getYear(),
                'tmdb': int(vtag.getUniqueID('tmdb') or 0),
                'imdb': vtag.getUniqueID('imdb'),
                'tvdb': int(vtag.getUniqueID('tvdb') or 0),
                'season': ffitem.season,
                'episode': ffitem.episode,
                # 'tvshowtitle': en_title if ref.type == 'show' else '',
                'premiered': premiered,
                'original_title': vtag.getOriginalTitle(),
                'episode_group': None,
                'episode_offset': {},
                'ffitem': ffitem,
            }
            return query

        if not media:
            with directory(view='sets') as kdir:
                for mtype, tmdb in (('movie', 78), ('show', 119051),  # Blade Runner, Wednesday
                                    ('movie', 1311031), ('show', 85937),  # Demon Slayer
                                    ('movie', 262391),  # Za jakie grzechy, dobry Boże? (2014)
                                    ):
                    if ffitem := ffinfo.find_item(MediaRef.from_tmdb(mtype, tmdb)):
                        label = f'{mtype.capitalize()}: {ffitem.title}'
                        if mtype == 'show':
                            label += ' (S02E05)'
                        menu = [CMenu('Edit', info_for(self.source_dialog, media=mtype, tmdb=tmdb, edit=True))]
                        kdir.action(label, info_for(self.source_dialog, media=mtype, tmdb=tmdb), menu=menu)
                kdir.action('= Badges of the rows =', info_for(self.source_dialog, media='badges'))
                kdir.action('= Colors of the providers =', info_for(self.source_dialog, media='colors'))
                kdir.action('= Ways and names of the rows =', info_for(self.source_dialog, media='rows'))
                kdir.action('= Progress Dialog =', info_for(self.source_dialog, media='progress'))

            return

        if media == 'progress':
            from threading import Thread
            from contextlib import suppress
            from ...ff.threads import xsleep

            # Search in background thread while window is shown
            def search_thread(win: SourceDialog) -> None:
                # NOW enable search mode (progress bar appears)
                win.start_search()
                # Search for sources
                for t in range(0, 101, 1):
                    i = int(100 - ((100 - t)/100)**3 * 100)
                    win.update(i, f'Bla bla bla... {i}% at {t}T')
                    win.update_time(t, 100)
                    xsleep(0.1)
                # Set found sources to window
                win.finish_search([])

            if ffitem := ffinfo.find_item(MediaRef.from_tmdb('movie', 78)):  # Demon Slayer
                query = make_query(ffitem)
                defaults = query.copy()
                win = SourceDialog(sources=FakeSources(ffitem), item=ffitem, items=[], query=query, default_query=defaults)
                thread = Thread(target=search_thread, args=(win,), name="SourcesSearch")
                thread.start()

                # Show window (blocks until user closes or selects source)
                # Search thread updates window in background
                try:
                    source_to_play = win.do_modal()
                    thread.join(timeout=1)  # wait for thread to finish (should be done already)
                finally:
                    with suppress(Exception):
                        win.destroy()
                    win = None  # remove reference to closed window
            return

        demo = badge_demo_rows() if media == 'badges' else None  # the badges of the demo instead of the ones of the rules
        colors = media == 'colors'  # the providers of the automatic colours, the colour of a source by its chain (`source_color()`)
        live = media == 'live'  # the rows demo found step by step: the search with its list
        rows = source_demo_rows() if media == 'rows' or live else None  # the sources of the rows demo: their ways, their colours by their chain
        if demo is not None or colors or rows is not None:
            media, tmdb = 'movie', 78
        se = [2, 5] if media == 'show' else []
        ffitem = ffinfo.find_item(MediaRef.from_tmdb(media, tmdb, *se))
        fflog(f'[DEV][source_dialog] found {ffitem=}')
        if not ffitem:
            Notification('FF dev', f'Item not found: {media} / {tmdb}').show()
            return
        factory: 'SourceFactory' = FakeSources(ffitem)  # type: ignore
        providers = [entry if isinstance(entry, str) else entry[0] for entry in const.sources.providers.auto_colors] if colors else []
        sources: 'list[Source]' = list(fake_source(ffitem, providers))
        if rows is not None:
            sources = [row.source(ffitem, n) for n, row in enumerate(rows, 1)]
        if colors or rows is not None:
            from ...ff.sources import LibraryColorSettings, NodeStyles, source_color
            styles, libcolors = NodeStyles(source_mods=[]), LibraryColorSettings(source_mods=[])
            for src in sources:
                src['color_identify'] = source_color(src, styles, libcolors)
        # filtering
        sources = [src for src in sources if src.enabled]
        # update (similar to sources.py)
        for src in sources:
            if color := src.attr.color:
                src['color_identify'] = color
        if demo is not None:
            for src, row in zip(sources, demo):
                src.attr = evolve(src.attr, badge=row.badges)
                src.update({'info': row.label, 'info2': '', 'no_transfer': False})  # the text of the row: what it shows; no overlay over it
                src['icon'] = addonInfo('icon') if row.source_icon else ''
            sources = sources[:len(demo)]
        # call dialog
        query = make_query(ffitem)
        defaults = query.copy()
        if const.sources_dialog.edit_search.cache and (se := sources_edit_db.get(ffitem)):
            fflog(f'Loaded saved search edits: {se}')
            saved_data = se.data
            query.update(saved_data)  # type: ignore[reportArgumentType]
        if (eg := query.get('episode_group')):
            ffinfo.switch_episode_group(ffitem, eg)
            if ffitem.episode_group.current is not None:
                defaults['season'] = ffitem.season
                defaults['episode'] = ffitem.episode
                if const.sources_dialog.edit_search.show_granularity == 'show':
                    query['season'] = ffitem.season
                    query['episode'] = ffitem.episode
                elif const.sources_dialog.edit_search.show_granularity == 'season':
                    query['episode'] = ffitem.episode
        elif eg == '':
            query['episode_group'] = None
        if live:
            from threading import Thread
            from ...ff.threads import xsleep

            def found_step_by_step(win: SourceDialog) -> None:
                """The search of the demo: the window of the progress, the empty list, the sources a few at a time, the end."""
                win.start_search()
                for step in range(61):
                    win.update(step * 100 // 60, f'Demo {step}')
                    win.update_time(step, 60)
                    if step >= 8:  # the first time of the search
                        win.show_found(sources[:step - 16] if step > 16 else [])
                    xsleep(0.5)
                win.finish_search(sources)

            win = SourceDialog(sources=factory, item=ffitem, items=[], query=query, default_query=defaults)
            Thread(target=found_step_by_step, args=(win,), name='SourcesSearch').start()
            win.do_modal()
            return

        if edit:
            try:
                EditDialog(query=query, default_query=defaults).doModal()
            except RescanSources as exc:
                fflog(f'Edit dialog result: {exc.query}')
                if exc.query is not None:
                    query = exc.query
                    if allowed := const.sources_dialog.edit_search.cache:
                        if query == defaults:
                            sources_edit_db.delete(ffitem)
                        else:
                            sources_edit_db.set(ffitem, {k: v for k, v in query.items() if k in allowed})
        else:
            while True:
                win = SourceDialog(sources=factory, item=ffitem, items=sources, query=query, default_query=defaults)
                try:
                    result = win.doModal()
                    fflog(f'Source dialog {result=}')
                except RescanSources as exc:
                    fflog(f'Source dialog rescanning sources: {exc.query}')
                    if exc.query is not None:
                        query = exc.query
                else:
                    if allowed := const.sources_dialog.edit_search.cache:
                        if query == defaults:
                            sources_edit_db.delete(ffitem)
                        else:
                            sources_edit_db.set(ffitem, {k: v for k, v in query.items() if k in allowed})
                    break

    @route
    def mixed_ids(self) -> None:
        """Test mixed media IDS (mixed services)."""
        from ...defs import VideoIds
        from ...ff.item import FFItem
        media: 'list[tuple[MediaRef, str]]' = [
            (MediaRef.from_tmdb('movie', 78), 'TMDB Movie (Blade Runner)'),
            (MediaRef.from_tmdb('show', 119051), 'TMDB Show (Wednesday)'),
            (MediaRef.movie(VideoIds(imdb='tt0068646').ffid), 'IMDB Movie (The Godfather)'),
            (MediaRef.tvshow(VideoIds(imdb='tt0141842').ffid), 'IMDB Show (The Sopranos)'),
            (MediaRef('', VideoIds(imdb='tt0110912').ffid), 'IMDB Movie (Pulp Fiction) – guess type'),
            (MediaRef('', VideoIds(imdb='tt2560140').ffid), 'IMDB Show (Shingeki no Kyojin/Titans) – guess type'),
            (MediaRef.movie(VideoIds(trakt=458837).ffid), 'Trakt Movie (Nobody)'),
            (MediaRef.tvshow(VideoIds(trakt=173996).ffid), 'Trakt Show (Wednesday)'),
            # (MediaRef.movie(VideoIds(tvdb=0).ffid), 'tvdb Movie (Iron Man)'),  # tvdb has no movies ID (but has movie records on the site)
            (MediaRef.tvshow(VideoIds(tvdb=81189).ffid), 'tvdb Show (Breaking Bad)'),
        ]
        ids, descrs = zip(*media)
        print(', '.join(map(str, ids)))
        with directory() as kdir:
            # xx = ffinfo.get_items(ids, keep_missing=True)
            for it, descr in zip(ffinfo.get_items(ids, keep_missing=True), descrs):
                if it is None:
                    it = FFItem(f'MISS: {descr}', mode=FFItem.Mode.Separator)
                it.vtag.setPlot(f'{descr}\n—————\n{it.vtag.getPlot()}')
                kdir.add(it, url=kdir.no_content)

    @route('/ratings/{__ref}')
    def ratings(self, *, ref: Optional[MediaRef] = None) -> None:
        """Test ratings display."""
        from ...ff.info import ffinfo
        from ...ff.ratings import RatingService, RatingScale, MediaRating, all_rating_services, colored_services

        def test_service(name: str, **scale: Any) -> RatingService:
            return RatingService(name=name, rating_scale=RatingScale(**scale))  # type: ignore[arg-type]  # a test name

        services: dict[str, Any] = colored_services({**all_rating_services, **{srv.name: srv for srv in (
            # --- TESTS and DEBUG ---
            test_service('x100', min=1, max=100),
            test_service('bin', min=0, max=1),
            test_service('float', type=float, min=0, max=1, step=.25),
            test_service('neg', min=-5, max=5),
            test_service('rev', min=10, max=1, step=-1),
            test_service('dup1', min=1, max=10, step=-1),
            test_service('dup2', min=1, max=10, step=-1),
        )}})  # the colors of the real dialogs
        media = [
            (MediaRef.from_tmdb('movie', 550),        # Fight Club
             [
                 MediaRating(5, service=services['trakt']),
                 MediaRating(10, service=services['tmdb']),
                 MediaRating(5, service=services['mdblist']),
                 MediaRating(50, service=services['x100']),
                 MediaRating(1, service=services['bin']),
                 MediaRating(.5, service=services['float']),
                 MediaRating(0, service=services['neg']),
                 MediaRating(2, service=services['rev']),
                 MediaRating(5, service=services['dup1']),
                 MediaRating(5, service=services['dup2']),
             ]),
            (MediaRef.from_tmdb('movie', 278),        # The Shawshank Redemption
             []),
            (MediaRef.from_tmdb('show', 1399),        # Game of Thrones
             []),
            (MediaRef.from_tmdb('show', 66732),       # Stranger Things
             []),
            (MediaRef.from_tmdb('show', 66732, 1),       # Stranger Things S01
             []),
            (MediaRef.from_tmdb('show', 66732, 1, 5),       # Stranger Things S01E05
             []),
            # MediaRef.from_tmdb('movie', 1),          # missing
            # []),
        ]

        if ref:
            from ...windows.ratings import RatingsDialog
            if ffitem := ffinfo.find_item(ref):
                ratings = next((m[1] for m in media if m[0] == ref), [])
                # fflog.error(f'RAT: {len(ratings)=} for {ref=}')
                result = RatingsDialog(ffitem=ffitem, ratings=ratings, services=services).doModal()
                fflog(f'Ratings dialog result: {result!r}')
            return

        refs = [m[0] for m in media]
        with list_directory(view='sets') as kdir:
            for it in ffinfo.get_items(refs):
                label = it.title
                if it.ref.is_season:
                    assert it.show_item is not None
                    label = f'{it.show_item.title} - Season {it.season}'
                elif it.ref.is_episode:
                    assert it.show_item is not None
                    label = f'{it.show_item.title} - {it.season}x{it.episode:02} - {it.title}'
                it.label = label
                it.mode = it.Mode.Command
                kdir.add(it, url=info_for(self.ratings, ref=it.ref))

    @route
    def gallery(self) -> None:
        from pathlib import Path
        from ...windows.gallery import GalleryDialog
        def fix_ecoding(p: Path) -> Path:
            try:
                x = b''.join(bytes([ord(c) & 0xff]) if 0xdc00 <= ord(c) <= 0xdcff else c.encode('utf-8') for c in str(p))
                return Path(x.decode('utf-8', errors='replace'))
            except UnicodeEncodeError:
                return p
        # GalleryDialog(title='Test gallery', images=[f'Image {i:03d}' for i in range(17)]).doModal()
        GalleryDialog(title='Test gallery', images=[fix_ecoding(p) for p in Path('~/Pictures').expanduser().glob('*.jpg')]).doModal()

    @route('/images/{__name}')
    def genre_images(self, name: str = '') -> None:
        from pathlib import Path
        from ...ff.control import artPath, execute
        from ...ff.item import FFItem
        art_path = Path(artPath())
        fflog(f'image: directory: {art_path}  ------------------------------------------------')
        if name:
            execute(f'ShowPicture({art_path / "genres" / name}.png)')
        else:
            with directory(view='images') as kdir:
                for path in art_path.glob('genres/*'):
                    # kdir.image(path.stem, str(path))
                    fflog(f'image: {path.stem} -> {path}')
                    item = FFItem(label=path.stem, info_type='pictures', art={'thumb': str(path)}, mode=FFItem.Mode.Command)
                    item.setProperty('IsPlayable', 'false')
                    # item.setPath(f'ShowPicture({path})')
                    kdir.add(item, url=f'XMBC.ShowPicture({path})')
                    # kdir.add(item, url=url_for(self.images, name=path.stem))

    @route
    def image_slideshow(self) -> None:
        from ...ff.control import execute
        # execute(f'SlideShow({url_for(self.images)})')
        execute('ShowPicture(https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F31284696%2Fpexels-photo-31284696.jpeg%3Fcs%3Dsrgb%26dl%3Dpexels-optical-chemist-340351297-31284696.jpg%26fm%3Djpg&f=1&nofb=1&ipt=bb54cb2503d11a4418492fe6585637921c6441a9b9558f9db203c02dd99861e8)')

    @route('/settings/__name')
    def settings(self, name: Optional[str] = None) -> None:
        from ...ff.settings import settings
        defs = settings.definitions
        if name:
            with directory(view='sets') as kdir:
                kdir.action(f'name: {name!r}', kdir.no_op)
                kdir.action(f'value: {settings.get(name)!r}', kdir.no_op)
                kdir.action(f'default: {defs[name].default!r}', kdir.no_op)
                kdir.action(f'type: {defs[name].type}', kdir.no_op)
        else:
            with list_directory(view='sets') as kdir:
                for name in sorted(settings.definitions.keys(), key=lambda s: s.lower()):
                    val = settings.get(name)
                    descr = (
                        f'[B]name:[/B] {name!r}\n'
                        f'[B]value:[/B] {val!r}\n'
                        f'[B]default:[/B] {defs[name].default!r}\n'
                        f'[B]type:[/B] {defs[name].type}\n'
                    )
                    label = f'{name} = {val!r}'
                    kdir.folder(label, info_for(self.settings, name=name), descr=descr)
