"""
The widget demo of the developer menu (`/dev/widgets`, like Qt's `qtdemo`): a page of every widget of the catalog (not the
whole dialogs, not the whole pages of the configuration), of the style and of the textures - one `DemoPage` declaration each.
"""

from functools import partial
from typing import Any
from ...ff.locales import flag_url
from ...ff.routing import route, RouteObject
from ...windows.gui import ANCHORS, TOGGLE
from ...windows.style import SURFACE_SHAPES, TAG_EDGES, TAB_SHAPES, TAG_OUTS
from ...windows.scale import Scale
from ...windows.widget_demo import (DEMO_FIELD_SLIDERS, DEMO_FILTERS, DEMO_MANY_PAGES, DEMO_SCALE, DEMO_SETTINGS, DEMO_SPIN_SCALE, DEMO_STACK_PAGES,
                                    DemoPage, DemoParam, DemoProp, DemoState, WidgetDemo)
from ...windows.widgets import Widget
from ...windows.widgets.frames import TagData, set_tags
from ...windows.widgets.views import ComboItem

#: A sample text.
TEXT = 'The quick brown fox jumps over the lazy dog'
#: A long sample text (a text box).
LONG_TEXT = '\n'.join(f'{n}. {TEXT}.' for n in range(1, 21))
#: The font roles (the parameter `style`).
STYLES = ('normal', 'small', 'tiny', 'heading')
#: Sample rows of a list.
ROWS = tuple(f'Row {n}' for n in range(1, 31))
#: The layouts of the content of a frame (the parameter `layout`).
FRAME_LAYOUTS = ('free', 'column', 'row')
#: The tabs of Python (dynamic: the rows of a tab bar).
TAB_ROWS = ('Movies', 'Shows', 'Persons', 'Collections')
#: The sides of a tab bar.
TAB_SIDES = ('W', 'N', 'E', 'S')
#: The items of a combo box: three groups (their separators; more items than its list: the filter on demand).
COMBO_ITEMS = tuple(ComboItem(label=f'{group} {n}', group=group, icon=f'icons/{icon}.32.png')
                    for group, icon in (('Movies', 'movie'), ('Shows', 'show'), ('Persons', 'person')) for n in range(1, 6))
#: The items of a combo box of the titles of a media: the flag of its country as the icon (the default title: none).
COMBO_FLAGS = (ComboItem(label='Wednesday'), *(ComboItem(label=title, icon=flag_url.format(lower=country))
                                               for country, title in (('pl', 'Wednesday Addams'), ('de', 'Wednesday'), ('ua', 'Венздей'),
                                                                      ('jp', 'ウェンズデー'), ('br', 'Wandinha'))))
#: The kinds of the rows of a list with a combo box in each row.
COMBO_KINDS = ('Movie', 'Show', 'Person')
#: The static icons of a tag (the media types).
TAG_ICONS = ('movie', 'show', 'person')
#: The data of a tag / an edge mark of Python: a text (a number), an icon and its colour, the colours of the static icons.
TAG_DATA = (TagData(text='42', icon='icons/star.32.png', color='FFE0A84F', icons={'movie': 'FFFFFFFF', 'show': '66999999', 'person': 'FF66CCFF'}),
            TagData(text='Python', icon='icons/sync.32.png', color='FF66CCFF', icons={'movie': '66999999', 'show': 'FFFFFFFF'}),
            None)
#: The images of the stickers of a rich row (the icons of the rules of the sources).
ROW_STICKERS = ('badges/noto-1st-place-medal.png', 'badges/noto-thumbs-up.png', 'badges/noto-warning.png')
#: The tree of the page of the toggle switches: its nodes and their tristate leaves (a leaf of the roots too).
FILTER_TREE = {'Audio': ('Lector', 'Dubbing', 'Original'), 'Video': ('3D', 'HDR')}
#: The maxima of the scale of Python of a spin box (1..N: e.g. the number of the items to add; its button switches them).
SPIN_MAXIMA = (5, 20, 100)


def tree_model(sample: Widget) -> None:
    """Give the tree sample a small model: two nodes with leaves and a leaf."""
    from ...ff.item import FFItem
    from ...windows.tree import TreeModel
    roots = []
    for name in ('Movies', 'Shows'):
        node = FFItem(name)
        node.children_items = [FFItem(f'{name} {n}') for n in range(1, 4)]
        roots.append(node)
    roots.append(FFItem('Persons'))
    sample.set_model(TreeModel(roots))  # type: ignore[attr-defined]


def tree_tabs(sample: Widget) -> None:
    """A tree as a tab bar: its top rows are the pages of the stack beside it (a row of a node: the page of the node)."""
    from ...ff.item import FFItem
    from ...windows.tree import TreeModel
    roots = []
    for page in DEMO_STACK_PAGES:
        node = FFItem(page.title)
        node.children_items = [FFItem(f'{page.title} {n}') for n in range(1, 3)]
        roots.append(node)
    tree, stack = sample.find('tree'), sample.find('stack')
    tree.set_model(TreeModel(roots))  # type: ignore[attr-defined]
    tree.current_changed.connect(partial(show_tree_page, tree, stack))


def combo_rows(sample: Widget) -> None:
    """The list of the combo boxes in its rows: rows of a kind each (the second label), a chosen kind is set in the row of the combo box."""
    from xbmcgui import ListItem
    rows = sample.find('rows')

    def item(n: int, kind: str) -> ListItem:
        """Return the row `n` of the kind."""
        return ListItem(f'Title {n}', kind)

    rows.rows = [item(n, COMBO_KINDS[n % len(COMBO_KINDS)]) for n in range(1, 13)]  # type: ignore[attr-defined]
    kind = sample.find('rows.kind')

    def chosen(index: int) -> None:
        """A kind chosen in a row: the row of that kind."""
        if 0 <= index < len(COMBO_KINDS) and 0 <= (row := kind.row) < len(rows.rows):  # type: ignore[attr-defined]
            rows.rows[row].setLabel2(COMBO_KINDS[index])  # type: ignore[attr-defined]  # the list keeps the list item
            rows.control().getListItem(row).setLabel2(COMBO_KINDS[index])  # type: ignore[attr-defined, union-attr]

    kind.activated.connect(chosen)  # type: ignore[attr-defined]


def tag_rows(sample: Widget) -> None:
    """The rows of the list of the tags: their data (`set_tags()`) - a number, the types, a bar and a line of some rows."""
    from xbmcgui import ListItem
    rows = []
    for n in range(1, 9):
        item = ListItem(f'Title {n}')
        set_tags(item, number=TagData(text=str(n)), types=TagData(icons={icon: 'FFFFFFFF' if (n >> i) & 1 else '66999999' for i, icon in enumerate(TAG_ICONS)}),
                 bar=TagData(color='FFE0A84F') if n % 3 == 0 else None, line=TagData(color='FF66CCFF') if n % 2 else None)
        rows.append(item)
    sample.find('rows').rows = rows  # type: ignore[attr-defined]


def row_tags(sample: Widget) -> None:
    """
    The rows of the list of the tags of a rich row: their data (`set_tags()`) - a bar of the left part, a sticker over the ribbon of its
    corner, up to three stickers along the top of the right part, a line across its centre, a ribbon of an image of the data.
    """
    from xbmcgui import ListItem
    rows = []
    for n in range(1, 7):
        item = ListItem(f'Source {n}')
        set_tags(item, bar=TagData(color='FFE0A84F') if n % 2 else None, medal=TagData(icon=ROW_STICKERS[0], color='FFFFFFFF'),
                 line=TagData(color='FF66CCFF') if n % 3 == 0 else None, flag=TagData(icon='icons/star.32.png', color='FFE0A84F') if n % 2 == 0 else None,
                 **{f'icon_{i}': TagData(icon=icon, color='FFFFFFFF') if i <= n % 4 else None for i, icon in enumerate(ROW_STICKERS, 1)})
        rows.append(item)
    sample.find('rows').rows = rows  # type: ignore[attr-defined]


def scale_signals(sample: Widget) -> None:
    """
    The signals of a slider, a spin box in the hint of its page (and the log): every move of the user (`changed`), the end of its moves
    (`committed`).
    """
    from ...ff.logs import fflog
    page = sample.path.split('.')[1]  # pages.<page>.panel.sample
    hint = sample.win.find(f'pages.{page}.hint')

    def show(signal: str, value: object) -> None:
        """Show the signal and its value."""
        hint.text = f'{signal}: {value}'  # type: ignore[attr-defined]
        fflog(f'[DEMO] {page} {signal}: {value!r}')

    sample.changed.connect(partial(show, 'changed'))  # type: ignore[attr-defined]
    sample.committed.connect(partial(show, 'committed'))  # type: ignore[attr-defined]


def spin_box_kinds(sample: Widget) -> None:
    """The spin box of a scale of Python: 1..N (`SPIN_MAXIMA`), its button switches N."""
    box, button = sample.find('python'), sample.find('rescale')

    def rescale() -> None:
        """The scale of the next maximum."""
        scale = box.scale  # type: ignore[attr-defined]
        maximum = SPIN_MAXIMA[(SPIN_MAXIMA.index(scale.maximum) + 1) % len(SPIN_MAXIMA)] if scale is not None else SPIN_MAXIMA[0]
        box.scale = Scale(minimum=1, maximum=maximum, format=f'{{}} of {maximum}')  # type: ignore[attr-defined]

    rescale()
    button.clicked.connect(rescale)


def slider_rows(sample: Widget) -> None:
    """
    The fields of a slider on a card: their signals in the hint; the list of the settings edited by a slider in a field at the current row
    (`DEMO_SETTINGS`): OK on a row opens the slider of its kind (`open()`; its value given at `about_to_show` - also opened by the mouse on
    the field of the row), every move shown in the row at once (`changed`; Back: the text from before), the value kept at `committed`.
    """
    from xbmcgui import ListItem
    for name in DEMO_FIELD_SLIDERS:
        scale_signals(sample.find(name))
    rows = sample.find('rows')
    values = [setting.value for setting in DEMO_SETTINGS]
    sliders = {setting.slider: sample.find(f'rows.{setting.slider}') for setting in DEMO_SETTINGS}

    def row_text(slider: Widget, value: Any) -> str:
        """Return the text of the value of the slider."""
        slider.value = value  # type: ignore[attr-defined]
        return slider.value_text()  # type: ignore[attr-defined]

    items = []
    for setting in DEMO_SETTINGS:
        item = ListItem(setting.label, row_text(sliders[setting.slider], setting.value))
        item.setProperty('slider', setting.slider)
        items.append(item)
    rows.rows = items  # type: ignore[attr-defined]

    def given(slider: Widget) -> None:
        """The card of the row opens: the value of its row."""
        slider.value = values[slider.row]  # type: ignore[attr-defined]

    def shown(slider: Widget, value: Any) -> None:
        """A move: the text of the row (the list keeps the list item)."""
        if 0 <= (row := slider.row) < len(values):  # type: ignore[attr-defined]
            rows.control().getListItem(row).setLabel2(slider.value_text())  # type: ignore[attr-defined, union-attr]

    def kept(slider: Widget, value: Any) -> None:
        """The value of the row kept."""
        if 0 <= (row := slider.row) < len(values):  # type: ignore[attr-defined]
            values[row] = value

    for slider in sliders.values():
        slider.about_to_show.connect(partial(given, slider))  # type: ignore[attr-defined]
        slider.changed.connect(partial(shown, slider))  # type: ignore[attr-defined]
        slider.committed.connect(partial(kept, slider))  # type: ignore[attr-defined]

    def opened(index: int) -> None:
        """OK on a row: the slider of its kind opens at it (its value given at `about_to_show`), the focus back on the list."""
        sliders[DEMO_SETTINGS[index].slider].open()  # type: ignore[attr-defined]

    rows.activated.connect(opened)  # type: ignore[attr-defined]


def range_fields(sample: Widget) -> None:
    """
    The range and the spin boxes of its bounds: a move of the range shows in the spin boxes, a move of a bound in the range and in the
    other bound - the knobs of the range keep the minimum not above the maximum (`Scale.range_positions()`: the maximum follows a minimum
    above it, a maximum below the minimum stays at it); their signals in the hint.
    """
    from ...windows.widget_demo import DEMO_RANGE_SCALE
    span, bounds = sample.find('range'), [sample.find(name) for name in ('low', 'high')]
    scale_signals(span)

    def show(value: Any) -> None:
        """The range moved: its bounds in the spin boxes."""
        for box, bound in zip(bounds, value):
            box.value = bound  # type: ignore[attr-defined]

    def bound(knob: int, value: Any) -> None:
        """A bound moved: the range of it and the other bound (kept in order), shown in both spin boxes."""
        pair = list(span.value)  # type: ignore[attr-defined]
        pair[knob] = value
        positions = DEMO_RANGE_SCALE.range_positions(*pair)
        span.value = tuple(DEMO_RANGE_SCALE.value_at(pos) for pos in positions)  # type: ignore[attr-defined]
        show(span.value)  # type: ignore[attr-defined]

    span.changed.connect(show)  # type: ignore[attr-defined]
    for knob, box in enumerate(bounds):
        box.changed.connect(partial(bound, knob))  # type: ignore[attr-defined]


def switch_signals(sample: Widget) -> None:
    """The signals of the switches in the hint of their page."""
    from ...windows.widget_demo import DEMO_SWITCHES
    for n in range(len(DEMO_SWITCHES)):
        scale_signals(sample.find(f'switch{n}'))


def toggle_rows(sample: Widget) -> None:
    """
    The toggle switches in rows: the list of the filters (`DEMO_FILTERS`), OK on a row its next value (`next_checked()`, the row shown
    again); the tree of the tristate leaves (`FILTER_TREE`, a leaf of the roots; OK on a leaf its next value).
    """
    from attrs import evolve
    from ...ff.item import FFItem
    from ...windows.tree import TreeModel
    from ...windows.widgets.buttons import next_checked
    rows = sample.find('rows')
    rows.rows = DEMO_FILTERS  # type: ignore[attr-defined]

    def toggled(index: int) -> None:
        """OK on a filter: its next value."""
        old = list(rows.rows)  # type: ignore[attr-defined]
        old[index] = evolve(old[index], checked=next_checked(old[index].checked, True))
        rows.rows = old  # type: ignore[attr-defined]

    rows.activated.connect(toggled)  # type: ignore[attr-defined]
    roots = []
    for name, leaves in FILTER_TREE.items():
        node = FFItem(name)
        node.children_items = [FFItem(leaf) for leaf in leaves]
        roots.append(node)
    roots.append(FFItem('Subtitles'))
    sample.find('tree').set_model(TreeModel(roots, expanded=roots[:-1]))  # type: ignore[attr-defined]


def show_tree_page(tree: Widget, stack: Widget, pos: int) -> None:
    """The current row of the tree changed: the stack shows the page of its top node."""
    view = tree.view  # type: ignore[attr-defined]
    if view is not None and 0 <= pos < len(rows := view.model.rows):
        label = rows[pos].item.getLabel()
        stack.current = next((page.name for page in DEMO_STACK_PAGES if label.startswith(page.title)), stack.current)  # type: ignore[attr-defined]


#: The pages of the demo, one per widget.
PAGES = (
    DemoPage(widget='label', args={'text': TEXT}, width=1000,
             params=(DemoParam('style', STYLES), DemoParam('align', ('left', 'center', 'right')), DemoParam('aligny', ('', 'center'))),
             props=(DemoProp('text', ('', 'A text of Python')),)),
    DemoPage(widget='text_box', width=1000, height=400,
             params=(DemoParam('style', STYLES), DemoParam('autoscroll', (False, True))),
             props=(DemoProp('text', (LONG_TEXT, TEXT)),)),
    DemoPage(widget='image', args={'texture': 'icons/movie.32.png'}, width=128, height=128,
             params=(DemoParam('color', ('', '{tokens.color.accent}')),),
             props=(DemoProp('texture', ('', 'icons/star.32.png')),)),
    DemoPage(widget='line_edit', look='line_edit_look', width=700, height=80, params=(DemoParam('hint', ('Type a title', '')),)),
    DemoPage(widget='progress_bar', look='progress_bar_look', width=1000, height=36,
             props=(DemoProp('percent', (40, 0, 100, 75)),)),
    DemoPage(widget='slider', args={'scale': DEMO_SCALE, 'value': 40, 'width': 1000, 'height': 130}, width=1000, height=130,
             setup=scale_signals, params=(DemoParam('ticks', ('S', 'N', '')), DemoParam('label', ('end', 'knob', '')), DemoParam('inverted', (False, True)),
                     DemoParam('mode', ('', 'min', 'value')), DemoParam('readonly', (False, True))),
             props=(DemoProp('value', (40, 0, 100, 75, 'x')),)),
    # the kinds of a slider: a logarithmic scale, an enum (value), an end "off", min, a range, a two-sided one (its fill from 0), a meter, a vertical one
    DemoPage(name='slider_kinds', widget='group', look='slider_kinds_look', width=1300, height=560),
    DemoPage(widget='spin_box', args={'scale': DEMO_SPIN_SCALE, 'value': 25, 'heading': 'Size (GB)'}, width=400, height=80, setup=scale_signals,
             params=(DemoParam('look', ('field', 'button')),), props=(DemoProp('value', (25, 0, 100, 'x')),)),
    # the kinds of a spin box: a logarithmic scale, an end "off", a scale of Python (1..N, its button changes N)
    DemoPage(name='spin_box_kinds', widget='group', look='spin_box_kinds_look', width=700, height=400, setup=spin_box_kinds),
    # a slider in a field (its card at the field, at a row of a list): a percent one, a range; the settings of a list edited by it
    DemoPage(name='slider_popup', widget='group', look='slider_popup_look', width=1300, height=500, setup=slider_rows),
    # a range and the spin boxes of its bounds: a move of one shows in the others
    DemoPage(name='range_fields', widget='group', look='range_fields_look', width=1000, height=360, setup=range_fields),
    # a switch (a slider of the look of the textures of its positions): 2, 3, 4 positions
    DemoPage(name='switch', widget='group', look='switch_look', width=1000, height=420, setup=switch_signals),
    DemoPage(widget='push_button', width=350, params=(DemoParam('text', ('OK', '')), DemoParam('style', STYLES)),
             props=(DemoProp('text', ('', 'Text of Python')),)),
    DemoPage(widget='check_box', args={'text': 'A check box'}, width=600, height=64,
             params=(DemoParam('look', ('{tokens.texture.box.check}', TOGGLE)), DemoParam('tristate', (False, True)), DemoParam('compact', (False, True)),
                     DemoParam('style', STYLES)),
             props=(DemoProp('checked', (False, True)),)),
    # the toggle switches in rows: a list of filters (must, must not, any), a tree of them (its leaves)
    DemoPage(name='toggle_rows', widget='group', look='toggle_rows_look', width=1200, height=420, setup=toggle_rows),
    DemoPage(widget='radio_button', args={'text': 'A radio button'}, width=600, height=64,
             params=(DemoParam('compact', (False, True)), DemoParam('style', STYLES)),
             props=(DemoProp('checked', (False, True)),)),
    DemoPage(widget='tool_button', args={'icon': 'sync'}, width=90, height=90,
             params=(DemoParam('size', (70, 90)), DemoParam('spin', ('', 'true')))),
    DemoPage(widget='field_button', args={'text': 'A value'}, width=700, height=80, params=(DemoParam('style', STYLES),)),
    DemoPage(widget='form_field', look='form_field_look', width=900, height=80,
             params=(DemoParam('mark_size', (0, 50)),),
             props=(DemoProp('modified', (True, False)),)),
    DemoPage(widget='rating_bar', args={'ratings': range(1, 11), 'first': 35, 'height': 80}, width=800, height=80),
    DemoPage(widget='list_view', args={'row_height': '{tokens.metric.row}'}, width=600, height=448,
             params=(DemoParam('kind', ('list', 'fixedlist', 'wraplist')), DemoParam('empty', ('No rows', ''))),
             props=(DemoProp('rows', (ROWS, ROWS[:3], ())), DemoProp('current', (0, 5, 20)))),
    DemoPage(widget='panel_view', args={'row_height': '{tokens.metric.row}', 'row_width': 200}, width=800, height=448,
             params=(DemoParam('empty', ('No rows', '')),), props=(DemoProp('rows', (ROWS, ROWS[:3], ())),)),
    DemoPage(widget='tree_view', args={'width': 800, 'rows': 6}, width=800, height=500, setup=tree_model,
             params=(DemoParam('details', (False, True)), DemoParam('multi', (False, True))),
             props=(DemoProp('hint', ('', 'A hint of the tree')),)),
    DemoPage(widget='group', look='buttons_look', width=800, height=100),
    DemoPage(widget='frame', look='frame_look', width=1000, height=440,
             params=(DemoParam('layout', FRAME_LAYOUTS), DemoParam('level', ('', 0, 1)), DemoParam('bg', ('', '{tokens.color.accent}')),
                     DemoParam('edge', ('', '{tokens.color.accent}')), DemoParam('pad', ('', 0, '{tokens.space.xxl}')),
                     DemoParam('shape', ('', *SURFACE_SHAPES)))),
    DemoPage(widget='group_box', look='buttons_look', width=800, height=400,
             params=(DemoParam('title', ('Options', '')), DemoParam('layout', FRAME_LAYOUTS))),
    DemoPage(widget='separator', width=800, height=300, params=(DemoParam('orientation', ('horizontal', 'vertical')),)),
    DemoPage(widget='stack', args={'pages': DEMO_STACK_PAGES}, width=800, height=300,
             props=(DemoProp('current', tuple(page.name for page in DEMO_STACK_PAGES)),)),
    DemoPage(widget='tab_bar', args={'tabs': DEMO_STACK_PAGES}, width=1200, height=400,
             params=(DemoParam('side', TAB_SIDES), DemoParam('shape', ('', *TAB_SHAPES)), DemoParam('elide', ('', 'none', 'end')),
                     DemoParam('depth', (0, 150))),
             props=(DemoProp('current', (0, 1, 2)), DemoProp('rows', (DEMO_STACK_PAGES, TAB_ROWS)))),
    # a tab widget: its side and kind as a page each (a choice from the list of the pages, no button of values in turn)
    # a tab widget: a panel on the dialog surface (its level forced: the frame of the samples is around it)
    # (the side given: the content of a page moves to the bar towards it; a bar on W: Left to the list of the pages)
    DemoPage(widget='tab_widget', args={'pages': DEMO_STACK_PAGES, 'level': 1, 'side': 'W', 'onleft': '@list'}, look='dialog_look', width=1200,
             height=440),
    *(DemoPage(name=f'tab_widget_{name}', widget='tab_widget', args={'pages': DEMO_STACK_PAGES, 'level': 1, **args}, look='dialog_look', width=1200,
               height=440) for name, args in (('n', {'side': 'N', 'shape': 'bevel'}), ('e', {'side': 'E', 'shape': 'straight'}),
                                              ('s', {'side': 'S'}), ('flat', {'side': 'W', 'onleft': '@list', 'shape': 'flat'}),
                                              ('line', {'side': 'W', 'onleft': '@list', 'shape': 'line'}),
                                              ('line_n', {'side': 'N', 'shape': 'line'}))),
    # more and longer tabs than a side: the bar scrolls (the marks of more tabs at its ends), the titles elided
    DemoPage(name='tab_widget_many', widget='tab_widget', args={'pages': DEMO_MANY_PAGES, 'side': 'N', 'elide': 'end', 'level': 1}, look='dialog_look',
             width=1200, height=440),
    # the same in a margin of its parent: the marks of more tabs in that room, beyond the ends of the bar
    DemoPage(name='tab_widget_margin', widget='group', look='tab_margin_look', width=1200, height=440),
    DemoPage(widget='tool_box', args={'pages': DEMO_STACK_PAGES, 'height': 440}, width=800, height=440,
             props=(DemoProp('current', tuple(page.name for page in DEMO_STACK_PAGES)),)),
    DemoPage(name='tree_tabs', widget='group', look='tree_tabs_look', width=1200, height=440, setup=tree_tabs),  # a tree as a tab bar
    DemoPage(widget='combo_box', args={'width': 600}, width=600, height=80,
             params=(DemoParam('items', (COMBO_ITEMS, COMBO_FLAGS)), DemoParam('editable', (False, True)), DemoParam('edit', ('click', 'direct')),
                     DemoParam('filter', ('', 'none', 'typed', 'demand')), DemoParam('label', ('', 'Title:')),
                     DemoParam('group_names', ('', 'shown', 'hidden')), DemoParam('group_align', ('', 'left', 'center', 'right'))),
             props=(DemoProp('current_index', (0, 7, -1)),)),
    # a combo box in each place: a fixed one (its list over the window), in a grouplist (its list in place), in the rows of a list
    DemoPage(name='combo_places', widget='group', look='combo_places_look', width=1300, height=500, setup=combo_rows),
    # a tag on its host (a card): its place - its anchor, the edge in a corner, how far it sticks out, its slot
    DemoPage(widget='tag', args={'text': 'New'}, width=600, height=300,
             params=(DemoParam('anchor', ('NE', *(a for a in ANCHORS if a != 'NE'))), DemoParam('out', ('', *TAG_OUTS)), DemoParam('edge', ('', *TAG_EDGES)),
                     DemoParam('slot', (1, 2, 3)))),
    # a tag: its content - a text, a number, icons; static or of Python (its data)
    DemoPage(name='tag_content', widget='tag', width=600, height=300,
             params=(DemoParam('kind', ('text', 'number', 'icon')), DemoParam('text', ('New', '')), DemoParam('icons', ((), TAG_ICONS)),
                     DemoParam('bg', ('', 'none', '{tokens.color.accent}'))),
             props=(DemoProp('data', TAG_DATA),)),
    # an edge mark on its host: a bar / a line on a side, a ribbon in a corner (a page each: their anchors)
    DemoPage(widget='edge_mark', width=600, height=300,
             params=(DemoParam('kind', ('bar', 'line')), DemoParam('anchor', ('W', 'N', 'E', 'S')), DemoParam('slot', (1, 2)),
                     DemoParam('color', ('{tokens.color.accent}', '')), DemoParam('corners', ('{0b1111}', '{0b1001}', '{0b0110}'))),
             props=(DemoProp('data', TAG_DATA),)),
    DemoPage(name='edge_mark_ribbon', widget='edge_mark', args={'kind': 'ribbon'}, width=600, height=300,
             params=(DemoParam('anchor', ('NE', 'NW', 'SE', 'SW')), DemoParam('out', ('inside', 'up', 'side', 'corner')),
                     DemoParam('color', ('{tokens.color.accent}', ''))),
             props=(DemoProp('data', TAG_DATA),)),
    # tags and edge marks in their places: a frame (its layers), a button (its focus), the rows of a list (the data of Python, the focus)
    DemoPage(name='tag_places', widget='group', look='tag_places_look', width=1300, height=500, setup=tag_rows),
    # the tags of a rich row (the sources): the marks of two parts of a row, stickers, a ribbon and a sticker in a corner, the data of Python
    DemoPage(name='row_tags', widget='group', look='row_tags_look', width=1000, height=500, setup=row_tags),
    DemoPage(name='style', widget='group', look='style_look', width=1200, height=540),  # the colours of the style (its colour functions)
    DemoPage(name='textures', widget='group', look='textures_look', width=1300, height=520),  # the tab shapes, the frame shapes
)


class DevWidgets(RouteObject):
    """The widget demo."""

    @route('/')
    def home(self) -> None:
        """Open the demo; a changed template parameter opens it again with the new values."""
        state = DemoState()
        while (state := WidgetDemo(pages=PAGES, state=state).do_modal()) is not None:
            pass
