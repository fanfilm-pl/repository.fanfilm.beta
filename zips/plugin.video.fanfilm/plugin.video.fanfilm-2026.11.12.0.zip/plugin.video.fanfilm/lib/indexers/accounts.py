"""
Folder of accounts: `tools/accounts_folder` renders the view model of `lib.ff.account_admin` (also in the CLI).

The list of accounts (the order is the priority), the menu of an account, its switch cells (a cell the state does not
allow is gray, a click shows the reason). The actions call the operations of the core and refresh the folder.
"""

from typing import Optional
from ..ff.routing import route, url_for, RouteObject
from ..ff.menu import directory
from ..ff.control import refresh
from ..ff.accounts import Account, get_account
from ..ff.sync import syncing_accounts
from ..ff import account_admin as admin
from ..kolang import L
from ..windows.skinfonts import symbol
from const import const

#: Style of a row the state of the account does not allow.
GRAY: str = '[COLOR gray]{}[/COLOR]'
#: View texts (shared with the window of accounts).
capability_label, menu_label, cell_label, state_label = admin.capability_label, admin.menu_label, admin.cell_label, admin.state_label


class Accounts(RouteObject):
    """Accounts: list, account menu, switches, actions."""

    def _account(self, account: str) -> Optional[Account]:
        """Return the account by the ID (gone: refresh)."""
        if (acc := get_account(account)) is None or acc.id != account:
            refresh()
            return None
        return acc

    @route('/')
    def home(self) -> None:
        """The list of accounts."""
        with directory(view=const.indexer.tools.view) as kdir:
            kdir.action(L(32859, 'Add account…'), self.add, thumb='common/tools.png', style='[B]{}[/B]')
            if free := admin.free_imdb_cookie():  # a cookie from the browser of a user without an account
                kdir.action(L(32909, 'Add the IMDb account of {nick}').format(nick=free['profile']['username']), url_for(self.add, type_name='imdb'),
                            thumb='services/imdb/main.png', style='[B]{}[/B]')
            if syncing_accounts():
                kdir.action(L(32985, 'Synchronize all accounts'), self.sync, thumb='services/own/update.png')
            for row in admin.account_rows():
                acc = row.account
                kdir.folder(f'{row.title} · {state_label(row.state, acc)}', url_for(self.account, account=acc.id),
                            thumb=f'services/{acc.type.name}/main.png', descr=' · '.join((acc.type.label, acc.id, *admin.account_summary(acc))),
                            style=GRAY if row.state in ('none', 'suspended') else None)

    @route
    def account(self, account: str) -> None:
        """The menu of the account."""
        if (acc := self._account(account)) is None:
            return
        state = admin.account_state(acc)
        thumb = f'services/{acc.type.name}/main.png'
        with directory(view=const.indexer.tools.view) as kdir:
            if acc.type.multi:  # a click on the state: refresh the profile (the nick)
                kdir.action(f'{L(30638, "State")}: {state_label(state, acc)}', url_for(self.refresh_profile, account=acc.id), thumb=thumb,
                            descr=admin.account_title(acc))
                kdir.action(L(32871, 'Sign in again…') if state != 'none' else L(32872, 'Sign in…'), url_for(self.authorize, account=acc.id),
                            thumb=thumb)
                if state != 'none':
                    kdir.action(L(32777, 'Revoke authorization'), url_for(self.revoke, account=acc.id), thumb=thumb)
                kdir.action(f'{L(32869, "Account label")}: {acc.label}', url_for(self.rename, account=acc.id), thumb=thumb)
            kdir.action(f'{L(32881, "Active")}: {symbol("check" if acc.active else "cross")}', url_for(self.toggle_active, account=acc.id),
                        thumb=thumb)
            kdir.action(L(32863, 'Move up'), url_for(self.move, account=acc.id, delta=-1), thumb=thumb)
            kdir.action(L(32866, 'Move down'), url_for(self.move, account=acc.id, delta=1), thumb=thumb)
            kdir.folder(L(32910, 'Switches'), url_for(self.switches, account=acc.id), thumb=thumb)
            sync = admin.account_actions(acc)['sync']
            kdir.action(sync.label, url_for(self.sync, account=acc.id), thumb=thumb, style=None if sync.available else GRAY, descr=sync.help)
            if acc.type.multi:
                kdir.action(L(32861, 'Remove account…'), url_for(self.remove, account=acc.id), thumb=thumb)

    @route
    def switches(self, account: str) -> None:
        """The switch cells of the account: a cell the state does not allow is gray, a click tells why."""
        if (acc := self._account(account)) is None:
            return
        with directory(view=const.indexer.tools.view) as kdir:
            for cell in (*admin.switch_cells(acc), *admin.menu_cells(acc)):
                mark = symbol('check' if cell.value else 'cross')  # ✔ / ✓ / yes: what the skin font draws
                kdir.action(f'{cell_label(cell.cell)}: {mark}', url_for(self.toggle_switch, account=acc.id, cell=cell.cell),
                            style=None if cell.available else GRAY, descr=admin.cell_help(cell))

    # --- actions ---

    @route
    def add(self, type_name: Optional[str] = None) -> None:
        """Add an account, not signed in: the type (asked), the label (it signs in by its own action)."""
        if admin.ask_add(type_name) is not None:
            refresh()

    @route
    def authorize(self, account: str) -> None:
        """Sign in the account, also again."""
        if (acc := self._account(account)) is not None:
            admin.ask_authorize(acc)
            refresh()

    @route
    def refresh_profile(self, account: str) -> None:
        """Get the user profile of the account again (the nick)."""
        if (acc := self._account(account)) is not None and admin.ask_refresh_profile(acc):
            refresh()

    @route
    def revoke(self, account: str) -> None:
        """Revoke the authorization of the account."""
        if (acc := self._account(account)) is not None and admin.ask_revoke(acc):
            refresh()

    @route
    def rename(self, account: str) -> None:
        """Change the label of the account (its ID stays)."""
        from ..ff.ui import ui
        if (acc := self._account(account)) is not None and (label := ui.input(L(32869, 'Account label'), acc.label)):
            admin.rename(acc, label)
            refresh()

    @route
    def toggle_active(self, account: str) -> None:
        """Suspend or restore the account."""
        if (acc := self._account(account)) is not None:
            admin.set_active(acc, not acc.active)
            refresh()

    @route
    def move(self, account: str, delta: int) -> None:
        """Move the account in the list (the first account of a type is the type alias)."""
        if (acc := self._account(account)) is not None:
            admin.move(acc, delta)
            refresh()

    @route
    def sync(self, account: Optional[str] = None) -> None:
        """Sync the account (none: all) now; an account that can not tells why."""
        from ..ff.ui import ui
        acc = None
        if account is not None:
            if (acc := self._account(account)) is None:
                return
            if not (view := admin.account_actions(acc)['sync']).available:
                ui.notify(acc.label, view.help)
                return
        if admin.ask_sync(acc):
            refresh()

    @route
    def toggle_switch(self, account: str, cell: str) -> None:
        """Toggle the switch cell; switching off a cell needed by others asks to switch them off too."""
        if (acc := self._account(account)) is not None and admin.ask_switch(acc, cell):
            refresh()

    @route
    def remove(self, account: str) -> None:
        """Remove the account (a warning: Trakt / TMDB authorization is revoked, its data in FanFilm are gone)."""
        if (acc := self._account(account)) is not None and admin.ask_remove(acc):
            refresh()
