# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from enum import Enum
from typing import Optional, Union, Any, Tuple, List, Dict, Sequence, TYPE_CHECKING
from datetime import date as dt_date, timedelta

from ..kolang import L
from ..defs import MediaRef, ItemList
from ..ff.item import FFItem
from ..ff.info import ffinfo
from ..ff.menu import directory, KodiDirectory, ContextMenuItem, CMenu
from ..ff.routing import route, subobject, url_for, info_for, PathArg
from ..api.tmdb import tmdb
from ..ff.settings import settings
from ..ff.control import is_plugin_folder
from ..ff.tricks import adict, FormatObjectGetter, Formatter
from ..ff.ratings import enabled_rating_services
from ..api.tmdb import DiscoveryFilters
from ..ff.logs import fflog
from .navigator import nav
from .play import play
from .core import MainIndexer, no_content
from .folder import list_directory, item_folder_route, pagination, mediaref_endpoint, Folder
from .lists.menu import menu_has_items
from .search import Search
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.routing import EndpointInfo


class Flatten(Enum):
    """Flat seasons (show eposodes directly in tvshow)."""
    Never = 0
    Single = 1
    Always = 2

    @classmethod
    def _missing_(cls, value: Any) -> 'Flatten':
        fflog.error(f'ERROR: Unknown type of Faltten: {value!r}')
        return Flatten.Never


class TVShows(MainIndexer):
    """TV-show navigation."""

    MODULE = 'tvshows'  # to read const settings
    TYPE = 'show'
    VIDEO_TYPE = 'episode'
    TMBD_CONTENT = 'tv'
    TRAKT_CONTENT = 'shows'
    VOTE_COUNT_SETTING = 'tmdbtv.vote'
    VIEW = 'tvshows'
    IMAGE = 'tvshows/main.png'

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        # u = url_for(self.popular)
        with list_directory(view='addons', icon='tvshows/main.png') as kdir:
            if const.indexer.tvshows.joke.production_company:
                kdir.folder(L(30138, 'Companies'), url_for(self.joke, type='production_company'))
            kdir.entry('show.search', self.search)
            if menu_has_items('shows'):
                kdir.entry('show.my', self.lists)
            kdir.entry('show.progress', info_for(self.progress))
            if self.trending_service():
                kdir.entry('show.trending', info_for(self.trending))
            kdir.entry('show.popular', info_for(self.popular))
            kdir.entry('show.top_rated', info_for(self.top_rated))
            kdir.entry('show.aired_today', self.aired_today)
            kdir.entry('show.premiere', self.premiere)
            if self.vod_new_available():
                kdir.entry('show.vod_new', info_for(self.vod_new))
            kdir.entry('show.genre', self.genre)
            kdir.entry('show.network', self.network)
            kdir.entry('show.providers', self.provider_list)
            kdir.entry('show.year', self.year)
            kdir.entry('show.language', self.language)
            kdir.entry('show.country', self.country)
            kdir.entry('show.awards', self.awards)
            if settings.getBool('downloads'):
                kdir.entry('show.download', f'{settings.getString("tv.download.path")}')

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self)

    def play_url(self, it: FFItem, *, edit: bool = False) -> 'Optional[EndpointInfo]':
        """Returns URL for episode play."""
        if it.aired_before(self.today()) and not const.indexer.episodes.future_playable:
            return info_for(KodiDirectory.no_op)
        kwargs: Dict[str, Any] = {}
        if it.ref.is_episode and (it.ref.season != it.season or it.ref.episode != it.episode):
            kwargs = {'season': it.season, 'episode': it.episode}
        if edit:
            return info_for(play, ref=it.ref, edit=edit, **kwargs)
        return info_for(play, ref=it.ref, **kwargs)

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process discover item. Called from discover()."""
        ref = it.ref
        mtype = it.ref.real_type
        if mtype == 'episode':
            it.label = self._episode_label(it, alone=alone)
            it.copy_from(it.season_item, it.show_item)  # year?
            if link:
                it.mode = it.Mode.Folder
                url = info_for(self.episodes, tv_ffid=ref.ffid, season=ref.season, select=ref.episode)
            else:
                it.mode = it.Mode.Playable
                url = self.play_url(it)
                menu += [
                    CMenu(L(30207, 'Edit search'), self.play_url(it, edit=True), visible=settings.getBool('cm.custom_search') or const.sources_dialog.edit_search.in_menu),
                ]
        elif mtype == 'season':
            it.label = self._season_label(it, alone=alone)
            it.mode = it.Mode.Folder
            it.copy_from(it.show_item)
            url = info_for(self.episodes, tv_ffid=ref.ffid, season=ref.season)
        else:
            it.label = f'{it.title}'
            it.setLabel2('%Y')
            it.mode = it.Mode.Folder
            url = info_for(self.seasons, tv_ffid=it.ffid)
        # test fix for double mark as watched/unwatched i TVShows/seasons
        # self.item_progress(it, menu=menu)
        # library_enabled = settings.getBool('enable_library')
        cm_show_details = is_plugin_folder() and settings.getBool('cm.details')
        cm_show_custom_search = settings.getBool('cm.custom_search') or const.sources_dialog.edit_search.in_menu
        cm_show_rate = bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=it.ref))
        menu += [
            CMenu(L(30162, 'Details'), url_for(self.media_info, ref=it.ref), visible=cm_show_details),
            # CMenu(L(30124, 'Add to library'), url_for(self.add_to_library, ref=it.ref), visible=library_enabled),
            CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref), visible=cm_show_rate),
        ]
        if mtype not in ('episode', 'season') and settings.getBool('cm.similar'):
            menu.append(CMenu(L(30132, 'Similar'), info_for(self.media_items, ref=it.ref, resource='similar')))
        kdir.add(it, url=url, auto_menu=self.item_auto_menu(it, kdir=kdir), menu=menu)

    def show_media_info_item(self, kdir: KodiDirectory, it: FFItem):
        """Add media item in details view."""
        ref = it.ref
        mtype = ref.real_type
        menu: List[ContextMenuItem]
        if mtype == 'show' or it.show_item:
            up = it.show_item or it
            up.label = f'[B]{up.title}[/B]'
            menu = [
                CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=up.ref),
                      visible=bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=up.ref))),
            ]
            self.item_progress(up, menu=menu)
            url = info_for(self.seasons, tv_ffid=up.ref.ffid, select=it.season)
            kdir.add(up, url=url, menu=menu)
        if mtype == 'season' or it.season_item:
            up = it.season_item or it
            up.label = self._season_label(up)
            up.label = f'[B]{up.label}[/B]'
            up.copy_from(it.show_item)
            menu = [
                CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=up.ref),
                      visible=bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=up.ref))),
            ]
            self.item_progress(up, menu=menu)
            kdir.add(up, url=info_for(self.episodes, tv_ffid=up.ref.ffid, season=it.season, select=it.episode), menu=menu)
        if mtype == 'episode':
            it.label = self._episode_label(it=it)
            it.label = f'[B]{it.label}[/B]'
            it.copy_from(it.season_item, it.show_item)  # year?
            menu = [
                CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref),
                      visible=bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=it.ref))),
            ]
            self.item_progress(it, menu=menu)
            if const.sources_dialog.edit_search.in_menu:
                menu = [*menu, (L(30207, 'Edit search'), self.play_url(it, edit=True))]
            it.mode = it.Mode.Playable
            kdir.add(it, url=self.play_url(it), menu=menu)

    def discover_year(self, year: int, end: int, *, page: int = 1) -> None:
        """Discover media in year range. Override it for tune."""
        vote_count = const.indexer.tvshows.year.votes
        sort_by = 'first_air_date.asc' if year == end else 'popularity.desc'
        return self.discover(page=page, sort_by=sort_by, votes=vote_count,
                             first_air_date=tmdb.Date.range(dt_date(year, 1, 1), dt_date(end, 12, 31)))

    @route('lists/{__scope}')
    def lists(self, scope: str = '') -> None:
        """My tv-show lists: the menu of lists of shows, then the local ones of FanFilm; a group folder of the menu by its pointer."""
        from .lists.menu import add_menu_level, menu_directory, pointer_scope
        if scope:
            menu_directory('shows', pointer_scope(scope))
            return
        with list_directory(view=const.indexer.my_lists_view, icon='tvshows/main.png') as kdir:
            add_menu_level(kdir, 'shows')
            kdir.entry('show.my.resume', self.resume)
            kdir.entry('show.my.history', nav.history.tvshows)

    @item_folder_route('/progress')
    def progress(self, *, page: PathArg[int] = 1) -> Folder:
        """The shows in progress (`ffinfo.watched_shows()`): watched in any account with the watched / progress read and in the local Kodi."""
        from .lists import shows_progress_folder, watched_shows
        return shows_progress_folder(watched_shows(first=page * const.indexer.tvshows.progress.page_size), page=page)

    @item_folder_route('/next_up')
    def next_up(self, *, page: PathArg[int] = 1) -> Folder:
        """The old address of the shows in progress (widgets, favourites)."""
        from .lists import shows_progress_folder, watched_shows
        return shows_progress_folder(watched_shows(first=page * const.indexer.tvshows.progress.page_size), page=page)

    @item_folder_route('/popular', limit=CONST_REF.indexer.tvshows.discovery_scan_limit)
    @pagination
    def popular(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """Most popular tv-shows."""

        # Ukrywaj stare seriale
        def old_date(flt: str, setting_name: str) -> None:
            rollback = settings.getInt(setting_name)
            if rollback and hideoldshows:
                # rallback > 0 i hideoldshows jest true
                filters[flt] = tmdb.Date >= today - timedelta(days=365 * rollback)

        today = self.today()
        vote_count: int = settings.getInt('tmdbtv.votePopular')
        filters: DiscoveryFilters = {
            'sort_by': 'popularity.desc',
            'first_air_date': tmdb.Date <= today,
            'vote_count': tmdb.VoteCount >= vote_count,
            'with_watch_monetization_types': 'flatrate|free|ads|rent|buy',
            'without_genres': '10763,10764,10767',
            'watch_region': const.indexer.tvshows.region,
        }
        hideoldshows = settings.getBool('hideoldshows')
        # Ukrywaj seriale starsze niż
        old_date('first_air_date', 'hideoldshows.rollback')
        # Ukrywaj seriale których ostatni odcinek jest starszy niż
        old_date('air_date', 'hideoldshowsepi.rollback')
        # Ukrywanie anime, domyślnie wyłączone
        if settings.getBool("withoutAnime"):
            filters['without_keywords'] = (210024, *const.tmdb.avoid_keywords)

        return self.discover_items(page=page, **filters)

    @item_folder_route('/top_rated', limit=CONST_REF.indexer.tvshows.discovery_scan_limit)
    @pagination
    def top_rated(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """Top rated tv-shows."""
        # TMDB API: sort_by=vote_average.desc&vote_count.gte=200'
        filters: DiscoveryFilters = {
            'sort_by': 'vote_average.desc',
        }
        if vote_count := const.indexer.tvshows.top_rated.votes:
            filters['vote_count'] = tmdb.VoteCount >= vote_count
        return self.discover_items(page=page, **filters)

    @item_folder_route('/aired_today', limit=CONST_REF.indexer.tvshows.discovery_scan_limit)
    @pagination
    def aired_today(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """Aired today."""
        # TMDB API: sort_by=popularity.desc&air_date.lte={max_date}&air_date.gte={min_date}'
        filters: DiscoveryFilters = {
            'sort_by': 'popularity.desc',
            'air_date': tmdb.Date.range(tmdb.Today, tmdb.Today),
            'with_watch_monetization_types': 'flatrate|free|ads|rent|buy',
            'without_genres': '10763,10764,10767',
            'watch_region': const.indexer.tvshows.region,
        }
        return self.discover_items(page=page, **filters)

    @item_folder_route('/premiere', limit=CONST_REF.indexer.tvshows.discovery_scan_limit)
    @pagination
    def premiere(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """New tv-shows."""
        filters: DiscoveryFilters = {
            'sort_by': 'first_air_date.desc',
            'first_air_date': tmdb.Date <= tmdb.Today,
            'with_watch_monetization_types': 'flatrate|free|ads|rent|buy',
            'without_genres': '10763,10764,10767',
            'watch_region': const.indexer.tvshows.region,
        }
        return self.discover_items(page=page, votes=const.indexer.tvshows.premiere.votes, **filters)

    @route
    def awards(self) -> None:
        """Create main awards menu. Must be called from @route, eg. awards()."""
        with directory(view='sets', thumb='tvshows/awards.png') as kdir:
            kdir.entry('show.awards.emmy_winner', info_for(self.awards_media, name='emmy_winner'))
            kdir.entry('show.awards.emmy_nominee', info_for(self.awards_media, name='emmy_nominee'))
            kdir.entry('show.awards.golden_globe_winner', info_for(self.awards_media, name='golden_globe_winner'))
            kdir.entry('show.awards.golden_globe_nominee', info_for(self.awards_media, name='golden_globe_nominee'))

    @route
    def network(self, nid: Optional[PathArg[int]] = None, page: PathArg[int] = 1) -> None:
        """Predefined tv networks."""
        if nid:
            return self.discover(page=page, votes=0, with_networks=nid)

        with directory(view='studios') as kdir:
            for nid, name, logo in sorted(self._get_networks(), key=lambda network: network[1].lower()):
                kdir.folder(name, info_for(nid=nid), icon=logo, thumb=logo)

    # --- sezony i odcinki ---

    def _kodi_labels(self, *, key: Optional[str] = None, num: Union[int, str, None] = None) -> 'adict[str]':
        labels = adict(
            tvshow=ffinfo.api_labels('TV Show'),  # Kodi global string: "TV Show"
            season=ffinfo.api_labels('Season'),  # Kodi global string: "Season"
            episode=ffinfo.api_labels('Episode'),  # Kodi global string: "Episode"
        )
        if key:
            if num is None:
                num = ''
            labels['en_label'] = f'{key} {num}'
            labels['loc_label'] = f'{ffinfo.api_labels(key)} {num}'
        return labels

    def _subitem_label(self, it: FFItem, *, alone: bool, labels: 'adict[str]', label_format: str, alone_format: str) -> str:
        """Helper. Generate label for sub-item (season, episode). `labels` must have `loc_label` and `en_label`."""
        loc_label = labels.loc_label
        en_label = labels.en_label
        title = it.title
        if it.title in (loc_label, en_label) and (en := it.vtag.getEnglishTitle()) and en != en_label:
            # locale title is generic and English title is specific, return English title
            title = en
            # force set title to English if has not specific locale title or locale title is generic
            it.vtag.setTitle(title)
        fmt = Formatter()
        item = FormatObjectGetter(it)
        label = fmt.format(label_format, it=it, item=item, ref=it.ref, locale=labels, title=title,
                           season=it.season, episode=it.episode or 0, year=it.year, date=it.date)
        if alone and it.show_item:
            label = fmt.format(alone_format, label=label,
                               it=it, item=item, show=FormatObjectGetter(it.show_item), ref=it.ref, locale=labels,
                               title=title, season=it.season, episode=it.episode or 0, year=it.year, date=it.date)
        return label

    def _season_label(self, it: FFItem, *, alone: bool = False) -> str:
        """Generate season label. Look on tvshow.season_label user settings."""
        labels = self._kodi_labels(key='Season', num=it.season)
        has_title = (((title := it.title) and title != labels.loc_label)
                     or ((en_title := it.vtag.getEnglishTitle()) and en_title != labels.en_label))
        if has_title:
            formats = const.indexer.seasons.with_title_labels
        else:
            formats = const.indexer.seasons.no_title_labels
        fmt_index = settings.getInt('tvshow.season_label')
        try:
            label_format = formats[fmt_index]
        except IndexError:
            fflog.error(f'No season format (title={has_title}) at index {fmt_index}')
            label_format = formats[0]
        label = self._subitem_label(it, alone=alone, labels=labels, label_format=label_format,
                                    alone_format=const.indexer.seasons.alone_label)
        if const.indexer.seasons.override_title_by_label:
            it.title = label
        return label

    def _episode_label(self, it: FFItem, *, alone: bool = False) -> str:
        """Generate episode label."""
        return self._subitem_label(it, alone=alone, labels=self._kodi_labels(key='Episode', num=it.episode),
                                   label_format=const.indexer.episodes.label,
                                   alone_format=const.indexer.episodes.alone_label)

    @mediaref_endpoint(param_ref_ffid='tv_ffid')
    @route('/')
    def seasons(self, tv_ffid: PathArg[int], *, select: Optional[int] = None, episode_group: Optional[str] = None) -> None:
        """Do list tvshow seasons (or episodes if flatten)."""
        flatten = Flatten(settings.getInt('flatten.tvshows'))
        # print(f'TVShows.seasons({tv_ffid=}, {flatten=})')
        tv_item: Optional[FFItem] = ffinfo.get_item(MediaRef.tvshow(tv_ffid), details=const.indexer.tvshows.season_details)
        if tv_item is None:
            fflog(f'ERROR: tvshow {tv_ffid} NOT found')
            return no_content('seasons', empty_message=L(32981, 'No data in TMDB'))
        if episode_group:
            flatten = Flatten.Never  # disable flattening if episode group is requested
            if (egr := tmdb.episode_group(episode_group, show=tv_ffid)) is None:
                fflog(f'ERROR: episode group {episode_group} NOT found for show {tv_ffid}')
                return no_content('seasons')
            ffinfo.switch_episode_group(tv_item, egr)  # the quasi-seasons of the group (with its episodes)
        seasons = list(tv_item.season_iter())
        if flatten == Flatten.Always or (flatten == Flatten.Single and len(seasons) == 1):
            # episodes (flatten view)
            self.flatten_show(tv_ffid, seasons)
        else:
            # seasons
            show_unaired = settings.getBool('showunaired')
            # library_enabled = settings.getBool('enable_library')
            cm_show_details = is_plugin_folder() and settings.getBool('cm.details')
            cm_show_rate = bool(enabled_rating_services(action='context_menu', setting='cm.rate', media_type='season'))
            with list_directory(view='seasons') as kdir:
                for it in seasons:
                    if show_unaired or not it.unaired:
                        it.label = self._season_label(it)
                        it.copy_from(tv_item)
                        menu = []
                        self.prepare_item(kdir, it, menu=menu)
                        self.item_properties(it)
                        self.item_progress(it, menu=menu)
                        it.mode = it.Mode.Folder
                        url_info = info_for(self.episodes, tv_ffid=tv_ffid, season=it.season, episode_group=episode_group)
                        # if url_info := info_for(self.episodes, tv_ffid=tv_ffid, season=it.season):
                        #     it.url = str(url_info.url)
                        if select is not None and it.season == select:
                            it.select(True)
                        kdir.add(it, url=url_info, menu=[
                            # a season of an episode group has no details / rating (its ref is the real season of the same number)
                            CMenu(L(30162, 'Details'), url_for(self.media_info, ref=it.ref), visible=cm_show_details and not episode_group),
                            CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref), visible=cm_show_rate and not episode_group),
                            *menu,
                            # CMenu(L(30124, 'Add to library'), url_for(self.add_to_library, ref=it.ref), visible=library_enabled),
                        ])
                    else:
                        fflog(f'Not-aired: {it.ref}, date={it.date}')

    def _group_episodes(self, tv_ffid: int, season: int, *, select: Optional[int] = None, episode_group: str) -> None:
        """List episodes for the group."""
        from ..api.tmdb import MediaRequest
        egr = tmdb.episode_group(episode_group, show=tv_ffid)
        if egr is None:
            fflog(f'ERROR: episode group {episode_group} NOT found for show {tv_ffid}')
            return no_content('episodes')
        # all real season needed to fetch episodes from given group
        mapping = egr.mapping()
        seasons = {ref for gen, new in mapping.items() if new.season == season and (ref := gen.season_ref)}
        show = ffinfo.find_item(MediaRequest(MediaRef.tvshow(tv_ffid), seasons=[sz.season or 0 for sz in seasons]))
        if show is None:
            fflog(f'ERROR: show {tv_ffid} for episode group {episode_group} NOT found')
            return no_content('episodes')
        ffinfo.switch_episode_group(show, egr)
        sz = show.get_season_item(season)
        if sz is None:
            fflog(f'ERROR: season {season} for episode group {episode_group} NOT found in show {tv_ffid}')
            return no_content('episodes')
        items = ItemList.single(sz.episode_iter())
        return self._episodes(tv_ffid, items, select=select)  # show group episodes

    @mediaref_endpoint(param_ref_ffid='tv_ffid')
    @route('/')
    def episodes(self, tv_ffid: PathArg[int], season: PathArg[int], *, select: Optional[int] = None, episode_group: Optional[str] = None) -> None:
        """List tvshow seasons."""
        print(f'TVShows.episodes({tv_ffid=}, {season=})')
        if episode_group:
            return self._group_episodes(tv_ffid, season, select=select, episode_group=episode_group)  # show group episodes
        season_item: Optional[FFItem] = ffinfo.get_item(MediaRef.tvshow(tv_ffid, season), details=const.indexer.tvshows.episodes_details)
        if season_item is None:
            fflog(f'ERROR: season {tv_ffid} / {season} NOT found')
            # return Folder([])
            return no_content('episodes')
        items = ItemList.single(season_item.episode_iter())
        return self._episodes(tv_ffid, items, select=select)  # show season episodes

    def flatten_show(self, tv_ffid: int, tv_seasons: List[FFItem]) -> None:
        """List all episodes of the tvshow (flatten): its seasons with all their episodes. Called from seasons()."""
        seasons = ffinfo.get_items([sz.ref for sz in tv_seasons], details=const.indexer.tvshows.episodes_details)
        self._episodes(tv_ffid, [ep for sz in seasons if sz for ep in sz.episode_iter()])

    def _episodes(self, tv_ffid: int, episodes: List[FFItem], *, select: Optional[int] = None) -> None:  # Folder:
        """Create directory with episodes."""
        show_unaired = settings.getBool('showunaired')
        # library_enabled = settings.getBool('enable_library')
        cm_show_details = is_plugin_folder() and settings.getBool('cm.details')
        cm_show_custom_search = settings.getBool('cm.custom_search') or const.sources_dialog.edit_search.in_menu
        cm_show_rate = bool(enabled_rating_services(action='context_menu', setting='cm.rate', media_type='episode'))
        with list_directory(view='episodes') as kdir:
            # iterate over all episodes
            for it in episodes:
                if show_unaired or not it.unaired:
                    it.label = self._episode_label(it)
                    it.copy_from(it.season_item, it.show_item)  # year?
                    menu = []
                    self.prepare_item(kdir, it, menu=menu)
                    self.item_properties(it)
                    self.item_progress(it, menu=menu)
                    it.mode = it.Mode.Playable
                    style = None
                    if select is not None and not KodiDirectory.state().info.refresh and it.episode == select:
                        if const.indexer.tvshows.progress.episode_focus:
                            kdir.focus_item(it)
                        if const.indexer.tvshows.progress.episode_select:
                            it.select(True)
                        style = const.indexer.tvshows.progress.episode_label_style
                    kdir.add(it, url=self.play_url(it), style=style, menu=[
                        CMenu(L(30162, 'Details'), url_for(self.media_info, ref=it.ref), visible=cm_show_details),
                        CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref), visible=cm_show_rate),
                        *menu,
                        CMenu(L(30207, 'Edit search'), self.play_url(it, edit=True), visible=cm_show_custom_search),
                        # CMenu(L(30124, 'Add to library'), url_for(self.add_to_library, ref=it.ref), visible=library_enabled),
                    ])
                else:
                    fflog(f'Not-aired: {it.ref}, date={it.date}')

    @route('{ffid}/folder')
    def as_folder(self, ffid: int, *, episode_group: Optional[str] = None) -> None:
        """Debug endpoint. Folder with single tv-show."""
        from ..defs import VideoIds
        if ffid < VideoIds.TMDB.start:
            ffid += VideoIds.TMDB.start
        nav.show_items([MediaRef.tvshow(ffid)])

    # -----

    def _get_networks(self) -> Sequence[Tuple[int, str, str]]:
        """Return predefined tv networks."""
        # Hmmm... logo i nazwy można wziąć z API: https://api.themoviedb.org/3/network/{network_id}
        return (
            (54, 'Disney Channel', 'https://i.imgur.com/ZCgEkp6.png'),
            (44, 'Disney XD', 'https://i.imgur.com/PAJJoqQ.png'),
            (2, 'ABC', 'https://i.imgur.com/qePLxos.png'),
            (493, 'BBC America', 'https://i.imgur.com/TUHDjfl.png'),
            (6, 'NBC', 'https://i.imgur.com/yPRirQZ.png'),
            (13, 'Nickelodeon', 'https://i.imgur.com/OUVoqYc.png'),
            (14, 'PBS', 'https://i.imgur.com/r9qeDJY.png'),
            (16, 'CBS', 'https://i.imgur.com/8OT8igR.png'),
            (19, 'FOX', 'https://i.imgur.com/6vc0Iov.png'),
            (21, 'The WB', 'https://i.imgur.com/rzfVME6.png'),
            (24, 'BET', 'https://i.imgur.com/ZpGJ5UQ.png'),
            (30, 'USA Network', 'https://i.imgur.com/Doccw9E.png'),
            (32, 'CBC', 'https://i.imgur.com/unQ7WCZ.png'),
            (33, 'MTV', 'https://i.imgur.com/QM6DpNW.png'),
            (34, 'Lifetime', 'https://i.imgur.com/tvYbhen.png'),
            (35, 'Nick Junior', 'https://i.imgur.com/leuCWYt.png'),
            (41, 'TNT', 'https://i.imgur.com/WnzpAGj.png'),
            (43, 'National Geographic', 'https://i.imgur.com/XCGNKVQ.png'),
            (47, 'Comedy Central', 'https://i.imgur.com/ko6XN77.png'),
            (49, 'HBO', 'https://i.imgur.com/Hyu8ZGq.png'),
            (55, 'Spike', 'https://i.imgur.com/BhXYytR.png'),
            (67, 'Showtime', 'https://i.imgur.com/SawAYkO.png'),
            (56, 'Cartoon Network', 'https://i.imgur.com/zmOLbbI.png'),
            (65, 'History Channel', 'https://i.imgur.com/LEMgy6n.png'),
            (84, 'TLC', 'https://i.imgur.com/c24MxaB.png'),
            (68, 'TBS', 'https://i.imgur.com/RVCtt4Z.png'),
            (71, 'The CW', 'https://i.imgur.com/Q8tooeM.png'),
            (74, 'Bravo', 'https://i.imgur.com/TmEO3Tn.png'),
            (76, 'E!', 'https://i.imgur.com/3Delf9f.png'),
            (77, 'Syfy', 'https://i.imgur.com/9yCq37i.png'),
            (80, 'Adult Swim', 'https://i.imgur.com/jCqbRcS.png'),
            (91, 'Animal Planet', 'https://i.imgur.com/olKc4RP.png'),
            (110, 'CTV', 'https://i.imgur.com/qUlyVHz.png'),
            (129, 'A&E', 'https://i.imgur.com/xLDfHjH.png'),
            (158, 'VH1', 'https://i.imgur.com/IUtHYzA.png'),
            (174, 'AMC', 'https://i.imgur.com/ndorJxi.png'),
            (928, 'Crackle', 'https://i.imgur.com/53kqZSY.png'),
            (202, 'WGN America', 'https://i.imgur.com/TL6MzgO.png'),
            (209, 'Travel Channel', 'https://i.imgur.com/mWXv7SF.png'),
            (213, 'Netflix', 'https://i.imgur.com/jI5c3bw.png'),
            (251, 'Audience', 'https://i.imgur.com/5Q3mo5A.png'),
            (270, 'SundanceTV', 'https://i.imgur.com/qldG5p2.png'),
            (318, 'Starz', 'https://i.imgur.com/Z0ep2Ru.png'),
            (359, 'Cinemax', 'https://i.imgur.com/zWypFNI.png'),
            (364, 'truTV', 'https://i.imgur.com/HnB3zfc.png'),
            (384, 'Hallmark Channel', 'https://i.imgur.com/zXS64I8.png'),
            (397, 'TV Land', 'https://i.imgur.com/1nIeDA5.png'),
            (1024, 'Amazon', 'https://i.imgur.com/ru9DDlL.png'),
            (1267, 'Freeform', 'https://i.imgur.com/f9AqoHE.png'),
            (4, 'BBC One', 'https://i.imgur.com/u8x26te.png'),
            (332, 'BBC Two', 'https://i.imgur.com/SKeGH1a.png'),
            (3, 'BBC Three', 'https://i.imgur.com/SDLeLcn.png'),
            (100, 'BBC Four', 'https://i.imgur.com/PNDalgw.png'),
            (214, 'Sky One', 'https://i.imgur.com/xbgzhPU.png'),
            (9, 'ITV', 'https://i.imgur.com/5Hxp5eA.png'),
            (26, 'Channel 4', 'https://i.imgur.com/6ZA9UHR.png'),
            (99, 'Channel 5', 'https://i.imgur.com/5ubnvOh.png'),
            (136, 'E4', 'https://i.imgur.com/frpunK8.png'),
            (210, 'HGTV', 'https://i.imgur.com/INnmgLT.png'),
            (453, 'Hulu', 'https://i.imgur.com/uSD2Cdw.png'),
            (1436, 'YouTube Red', 'https://i.imgur.com/ZfewP1Y.png'),
            (64, 'Discovery Channel', 'https://i.imgur.com/8UrXnAB.png'),
            (2739, 'Disney+', 'https://i.imgur.com/DVrPgbM.png'),
            (2552, 'Apple TV +', 'https://i.imgur.com/fAQMVNp.png'),
            (2697, 'Acorn TV', 'https://i.imgur.com/fSWB5gB.png'),
            (1709, 'CBS All Access', 'https://i.imgur.com/ZvaWMuU.png'),
            (3186, 'HBO Max', 'https://i.imgur.com/mmRMG75.png'),
            (2243, 'DC Universe', 'https://i.imgur.com/bhWIubn.png'),
            (2076, 'Paramount Network', 'https://i.imgur.com/ez3U6NV.png'),
            (4330, 'Paramount+', 'https://i.imgur.com/dmUjWmU.png'),
            (3353, 'Peacock', 'https://imgur.com/1JXFkSM.png'),
            (504, 'TVN', 'https://i.imgur.com/yA8TJ4o.png'),
            (483, 'TVP1', 'https://i.imgur.com/as4ipbu.png'),
            (466, 'TVP2', 'https://i.imgur.com/qj1Ta1Q.png'),
            (315, 'Polsat', 'https://i.imgur.com/knnmJG5.png'),
        )
