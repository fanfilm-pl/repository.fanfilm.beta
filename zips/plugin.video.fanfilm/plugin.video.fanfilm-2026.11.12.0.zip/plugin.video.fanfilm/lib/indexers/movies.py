"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from datetime import date as dt_date, timedelta
from typing import Optional, List, Sequence, TYPE_CHECKING

from ..ff.routing import route, subobject, url_for, info_for, PathArg
from ..ff.menu import directory, KodiDirectory, ContextMenuItem, CMenu
from ..ff.settings import settings
from ..api.tmdb import tmdb
from ..api.trakt import trakt_app
from ..api.tmdb import DiscoveryFilters
from ..api.tv import TvProgram
from ..kolang import L
from ..ff.item import FFItem
from ..ff.info import ffinfo
from ..ff.ratings import enabled_rating_services
from ..ff.logs import fflog, log
from ..ff.control import is_plugin_folder
from ..ff import control
from .search import Search
from .core import MainIndexer
from .folder import list_directory, item_folder_route, pagination
from .lists.menu import menu_has_items
from .navigator import nav
from .play import play
from cdefs import ProgramTvService
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.routing import EndpointInfo
    from ..api.tv import TvMovie


class Movies(MainIndexer):
    """Movies navigation."""

    MODULE = 'movies'  # to read const settings
    TYPE = 'movie'
    VIDEO_TYPE = 'movie'
    TMBD_CONTENT = 'movie'
    TRAKT_CONTENT = 'movies'
    VOTE_COUNT_SETTING = 'tmdbmovie.vote'
    VIEW = 'movies'
    IMAGE = 'movies/main.png'

    @route('/')
    def home(self) -> None:
        """Create root / main menu."""
        with list_directory(view='addons', icon='movies/main.png') as kdir:
            if const.indexer.movies.joke.production_company:
                kdir.folder(L(30138, 'Companies'), info_for(self.joke, type='production_company'))
            if const.indexer.movies.joke.keyword:
                kdir.folder(L(30137, 'Keywords'), info_for(self.joke, type='keyword'))
            kdir.entry('movie.search', self.search)
            if menu_has_items('movies'):
                kdir.entry('movie.my', self.lists)
            if self.trending_service():
                kdir.entry('movie.trending', info_for(self.trending))
            kdir.entry('movie.popular', info_for(self.popular))
            kdir.entry('movie.top_rated', info_for(self.top_rated))
            kdir.entry('movie.genre', self.genre)
            kdir.entry('movie.new', info_for(self.new))
            if self.vod_new_available():
                kdir.entry('movie.vod_new', info_for(self.vod_new))
            kdir.entry('movie.cinema', info_for(self.cinema))
            kdir.entry('movie.tv', self.tv)
            kdir.entry('movie.boxoffice', info_for(self.boxoffice))
            kdir.entry('movie.companies', self.companies)
            kdir.entry('movie.providers', self.provider_list)
            kdir.entry('movie.year', self.year)
            kdir.entry('movie.language', self.language)
            kdir.entry('movie.country', self.country)
            kdir.entry('movie.awards', self.awards)
            if settings.getBool('downloads'):
                kdir.entry('movie.download', f'{settings.getString("movie.download.path")}')

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self)

    def not_so_today(self) -> dt_date:
        """Fake today, without cinema last N months."""
        today = self.today()
        months: int = settings.getInt('hidecinema.rollback') if settings.getBool('hidecinema') else 0
        if months:
            return today - timedelta(days=30 * months)
        return today

    def play_url(self, it: FFItem, *, edit: bool = False) -> 'Optional[EndpointInfo]':
        """Returns URL for movie play."""
        if it.aired_before(self.today()) and not const.indexer.movies.future_playable:
            return info_for(KodiDirectory.no_op)
        if edit:
            return info_for(play, ref=it.ref, edit=edit)
        return info_for(play, ref=it.ref)
        # return info_for(play_movie, ffid=it.ffid, edit=edit)

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process discover item. Called from discover()."""
        it.label = f'{it.title}'
        it.setLabel2('%T|%Y')
        it.mode = it.Mode.Playable
        # library_enabled = settings.getBool('enable_library')
        cm_show_details = is_plugin_folder() and settings.getBool('cm.details')
        cm_show_custom_search = settings.getBool('cm.custom_search') or const.sources_dialog.edit_search.in_menu
        cm_show_rate = bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=it.ref))
        menu = [
            CMenu(L(30162, 'Details'), url_for(self.media_info, ref=it.ref), visible=cm_show_details),
            CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref), visible=cm_show_rate),
            CMenu(L(30207, 'Edit search'), self.play_url(it, edit=True), visible=cm_show_custom_search),
        ]
        if settings.getBool('cm.movie_collection') and (collection := ffinfo.item_collection(it)):
            menu.append((L(30130, 'Movie Collection'), info_for(nav.collection.item, oid=collection.ref.ffid)))
        if settings.getBool('cm.similar'):
            menu.append(CMenu(L(30132, 'Similar'), info_for(self.media_items, ref=it.ref, resource='similar')))
        kdir.add(it, url=self.play_url(it), auto_menu=self.item_auto_menu(it, kdir=kdir), menu=menu)

    def show_media_info_item(self, kdir: KodiDirectory, it: FFItem):
        """Add media item in details view."""
        cm_show_custom_search = settings.getBool('cm.custom_search') or const.sources_dialog.edit_search.in_menu
        cm_show_rate = bool(enabled_rating_services(action='context_menu', setting='cm.rate', ref=it.ref))
        menu = [
            CMenu(L(30542, 'Rate'), url_for(self.rate_media, ref=it.ref), visible=cm_show_rate),
            CMenu(L(30207, 'Edit search'), self.play_url(it, edit=True), visible=cm_show_custom_search),
        ]
        it.mode = it.Mode.Separator
        it.label = f'[B]{it.title}[/B]'
        kdir.add(it, url=self.play_url(it), menu=menu)

    def discover_year(self, year: int, end: int, *, page: int = 1) -> None:
        """Discover media in year range. Override it for tune."""
        vote_count = const.indexer.movies.year.votes
        if year == end:
            return self.discover(page=page, votes=vote_count,
                                 sort_by='primary_release_date.asc', primary_release_year=year)
        else:
            return self.discover(page=page, votes=vote_count, sort_by='popularity.desc',
                                 primary_release_date=tmdb.Date.range(dt_date(year, 1, 1), dt_date(end, 12, 31)))

    @route('lists/{__scope}')
    def lists(self, scope: str = '') -> None:
        """My movie lists: the menu of lists of movies, then the local ones of FanFilm; a group folder of the menu by its pointer."""
        from .navigator import nav
        from .lists.menu import add_menu_level, menu_directory, pointer_scope
        if scope:
            menu_directory('movies', pointer_scope(scope))
            return
        with list_directory(view=const.indexer.my_lists_view, icon='movies/main.png') as kdir:
            add_menu_level(kdir, 'movies')
            kdir.entry('movie.my.resume', info_for(self.resume))
            kdir.entry('movie.my.history', nav.history.movies)

    @item_folder_route('/popular', limit=CONST_REF.indexer.movies.discovery_scan_limit)
    @pagination
    def popular(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """Most popular movies."""
        # FF: primary_release_date.lte=%s&sort_by=popularity.desc
        return self.discover_items(page=page, sort_by='popularity.desc', primary_release_date=tmdb.Date <= self.today())

    @item_folder_route('/top_rated', limit=CONST_REF.indexer.movies.discovery_scan_limit)
    @pagination
    def top_rated(self, *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """Top rated movies."""
        # TMDB API: sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200'
        filters: DiscoveryFilters = {
            'sort_by': 'vote_average.desc',
            'without_genres': '99,10755',
            'primary_release_date': tmdb.Date <= self.not_so_today(),
        }
        if vote_count := const.indexer.movies.top_rated.votes:
            filters['vote_count'] = tmdb.VoteCount >= vote_count
        return self.discover_items(page=page, **filters)

    @route
    def new(self, *, page: PathArg[int] = 1) -> None:
        """Latest movies list."""
        # FF: sort_by=primary_release_date.desc&primary_release_date.lte=%s&vote_count.gte=%s
        self.discover(page=page, sort_by='primary_release_date.desc', primary_release_date=tmdb.Date <= tmdb.Today,
                      votes=const.indexer.movies.new.votes)

    @route
    def cinema(self, *, page: PathArg[int] = 1) -> None:
        """In Theaters (in cinema)."""
        # FF: sort_by=primary_release_date.desc&release_date.gte=%s&release_date.lte=%s&with_release_type=3&vote_count.gte=%s
        today = self.today()
        old = today - timedelta(days=const.indexer.movies.cinema.last_days)
        today += timedelta(days=const.indexer.movies.cinema.next_days)
        filters: DiscoveryFilters = {
            'sort_by': 'primary_release_date.desc',
            'with_release_type': 3,
            'release_date': tmdb.Date.range(old, today),
        }
        if const.indexer.movies.cinema.use_region:
            filters['watch_region'] = const.indexer.movies.region
        self.discover(page=page, **filters)

    @route('/tv/{service}/prog/{entry_id}')
    def tv_items(self, service: ProgramTvService, entry_id: str, *, page: PathArg[int] = 1, day: int = 0) -> None:
        """Today in TV. Must be above tv/{service} to override it."""
        if not (common := TvProgram.tv_service(service=service)):
            return self.no_content()
        self.show_items(common.tv_movie_items(entry_id, day_offset=day), skip_ffinfo=True)

    @route('tv/{service}')
    @route('tv')
    def tv(self, service: Optional[ProgramTvService] = None, *, page: PathArg[int] = 1, day: int = 0) -> None:
        """Today in TV."""

        def update_item(it: FFItem, tv: 'TvMovie') -> None:
            nonlocal N
            it.vtag.setProductionCode(f'{tv.time:%H:%M}')
            it.title = tv.title
            # it.setLabel2(f'{tv.channel} | {tv.time:%H:%M}')
            # it.setLabel2(tv.channel)
            it.vtag.setYear(tv.year)
            if tv.ratings:
                rating = max(r for r, v in tv.ratings.values())
                it.vtag.setRatings(tv.ratings)
                it.vtag.setRating(rating, 0)
                # it.set_info('rating', rating)
                # it.set_info('mediatype', 'video')
            if tv.duration:
                it.vtag.setDuration(tv.duration)
            it.vtag.setDateAdded(f'{tv.time}')
            it.vtag.setTrackNumber(N)  # for sorting
            N += 1

        def add_tv(kdir: KodiDirectory, tv: 'TvMovie') -> None:
            ffitem = kdir.folder(tv.title, url_for(self.tv_items, service=service, entry_id=tv.id, day=day),
                                 thumb=tv.image or 'DefaultMovies.png', descr=tv.descr, role=tv.role())
            update_item(ffitem, tv)

        def extra_days(kdir: KodiDirectory) -> None:
            assert common is not None
            day_range = range(max(common.DAY_RANGE.start, const.indexer.movies.tv.day_range.start),
                              min(common.DAY_RANGE.stop, const.indexer.movies.tv.day_range.stop))
            if page == 1 and day == 0 and len(day_range) > 1:
                from ..ff.calendar import day_label
                today = self.today()
                for offset in day_range:
                    if offset:  # skip today
                        the_day = today + timedelta(days=offset)
                        kdir.folder(day_label(the_day, now=today, week_without_date=True),
                                    url_for(self.tv, service=service, day=offset),
                                    descr=day_label(the_day, now=today, always_date=True),
                                    thumb='movies/today.png')

        def sorting(kdir: KodiDirectory) -> None:
            if one_page:
                import xbmcplugin
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_NONE, '%L', '%P')
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_UNSORTED, '%L', '%P')
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_TITLE, '%L')
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR, '%L', '%Y')
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_CHANNEL, '%L', '')         # Kodi sucks! Channels are supported only in PVR.
                if has_duration:
                    control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_DURATION, '%L', '%D')  # Kodi sucks! Ratings are supported on folders.
                if has_ratings:
                    control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_VIDEO_RATING, '%L', '%R')  # Kodi sucks! Ratings are supported on folders.
                control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_DATEADDED, '%L')
                # control.sortMethod(kdir.handle, xbmcplugin.SORT_METHOD_TRACKNUM, '%L')

        N = 1
        if service is None:
            if isinstance(const.indexer.movies.tv.service, str):
                service = const.indexer.movies.tv.service
            else:
                # Multi service, add folder with services names
                with directory(view=const.indexer.movies.tv.service_view) as kdir:
                    for service in const.indexer.movies.tv.service:
                        kdir.folder(service, url_for(service=service), thumb='movies/today.png')
                return
        if not (common := TvProgram.tv_service(service=service)):
            return self.no_content()
        mode = const.indexer.movies.tv.list_mode
        if mode in ('folders', 'direct', 'direct_or_folder'):
            page_size = const.indexer.movies.tv.stub_page_size
        else:
            page_size = const.indexer.movies.tv.media_page_size
        fflog(f'In TV: {service=}, {mode=}, {page=}, page_size={page_size}')
        one_page = not page_size
        if not page_size:
            page_size = 1_000_000_000  # a lot
        has_ratings = has_duration = False
        cm_show_details = is_plugin_folder() and settings.getBool('cm.details')
        if mode == 'media':
            self.show_items(common.tv_movie_all_items(page=page, limit=page_size), top=extra_days)
        elif mode == 'mixed':
            movies = common.tv_movie_mixed_items(page=page, limit=page_size, day_offset=day)
            with directory(movies, view='movies', top=extra_days) as kdir:
                # show items
                for tv in movies:
                    if isinstance(tv, FFItem):
                        self.show_item(kdir, tv)
                    else:
                        add_tv(kdir, tv)
        elif mode == 'folders':
            movies = common.tv_movies(page=page, limit=page_size, day_offset=day)
            with directory(movies, view='movies', top=extra_days) as kdir:
                for tv in movies:
                    add_tv(kdir, tv)
                sorting(kdir)
        elif mode in ('direct', 'direct_or_folder'):
            movies = common.tv_movies(page=page, limit=page_size, day_offset=day)
            has_ratings = any(tv.ratings for tv in movies)
            has_duration = any(tv.duration for tv in movies)
            with directory(movies, view='movies', top=extra_days) as kdir:
                for tv in movies:
                    if tv.ref is None:
                        if mode == 'direct_or_folder':
                            add_tv(kdir, tv)
                        else:
                            fflog(f'{service} TV item without ref: {tv!r}')
                    else:
                        menu = [CMenu(L(30162, 'Details'), url_for(self.media_info, ref=tv.ref), visible=cm_show_details)]
                        ffitem = kdir.play(tv.title, url_for(play, ref=tv.ref), thumb=tv.image or 'DefaultMovies.png', descr=tv.descr, role=tv.role(), menu=menu)
                        update_item(ffitem, tv)
                        ids = tv.ref.video_ids.kodi_ids()
                        ffitem.vtag.setUniqueIDs(ids)
                        if 'imdb' in ids:
                            ffitem.vtag.setIMDBNumber(ids['imdb'])
                sorting(kdir)
        else:
            log.error(f'Unknown const.indexer.movies.tv.list_mode: {mode!r}')
            self.no_content()

    @route
    def boxoffice(self) -> None:
        """Box office."""
        items = trakt_app.box_office()
        self.show_items(items)

    @route
    def awards(self) -> None:
        """Create main awards menu. Must be called from @route, eg. awards()."""
        with directory(view='sets', thumb='movies/awards.png') as kdir:
            kdir.entry('movie.awards.oscar_winner', url_for(self.awards_media, name='oscar_winner'))
            kdir.entry('movie.awards.oscar_nominee', url_for(self.awards_media, name='oscar_nominee'))
            kdir.entry('movie.awards.best_picture_winner', url_for(self.awards_media, name='best_picture_winner'))
            kdir.entry('movie.awards.oscar_best_picture_nominees', url_for(self.awards_media, name='oscar_best_picture_nominees'))
            kdir.entry('movie.awards.best_director_winner', url_for(self.awards_media, name='best_director_winner'))
            kdir.entry('movie.awards.oscar_best_director_nominees', url_for(self.awards_media, name='oscar_best_director_nominees'))
            kdir.entry('movie.awards.golden_globe_winner', info_for(self.awards_media, name='golden_globe_winner'))
            kdir.entry('movie.awards.golden_globe_nominee', info_for(self.awards_media, name='golden_globe_nominee'))
            kdir.entry('movie.awards.razzie_winner', url_for(self.awards_media, name='razzie_winner'))
            kdir.entry('movie.awards.razzie_nominee', url_for(self.awards_media, name='razzie_nominee'))

    @route
    def companies(self, cid: Optional[PathArg[str]] = None, page: PathArg[int] = 1) -> None:
        """Predefined tv networks."""
        if cid:
            return self.discover(page=page, votes=0, with_companies=cid)

        from xbmcaddon import Addon
        from xbmcvfs import exists
        rx = re.compile(r'["/:]')
        has_white_icons: bool = False
        try:
            if Addon('resource.images.studios.white').getAddonInfo('path'):
                has_white_icons = True
        except Exception:
            pass
        with directory(view='studios') as kdir:
            for cid, name, whitelogo, logo in sorted(self._get_companies(), key=lambda x: x[1]):
                icon = None
                if has_white_icons:
                    icon = f'resource://resource.images.studios.white/{whitelogo}.png'
                    if not exists(icon):
                        icon = None
                if not icon and logo:
                    icon = f'{tmdb.art_image_url}/{logo}'
                kdir.folder(name, url_for(cid=cid), icon=icon, thumb=icon)


    # -----

    def _get_companies(self):
        """Return predefined companies."""
        # TMDB-ID, Name, studios.white name, TMDB icon
        return (
            ('20580',       'Amazon Studios',             'Amazon Studios',                 'oRR9EXVoKP9szDkVKlze5HVJS7g.png'),
            ('178464',      'Netflix',                    'Netflix',                        'tyHnxjQJLH6h4iDQKhN5iqebWmX.png'),
            ('3268|7429',   'HBO',                        'HBO',                            'tuomPhY2UtuPTqqFnKMVHvSb724.png'),
            ('6480',        'TVP',                        'TVP',                            'qJUUNzFYXNUDaisssBTV3Zdki9R.png'),
            ('5622',        'TVN Group',                  'TVN',                            'bKcpepYRLylECRb5LVkskW0TQIX.png'),
            ('25|127928',   '20th Century',               '20th Century Fox',               'qZCc1lty5FzX30aOCVRBLzaVmcp.png'),
            ('7',           'DreamWorks Pictures',        'DreamWorks Pictures',            '1kqoutvio9eDaQpp0l4gQoEF4Yf.png'),
            ('4',           'Paramount',                  'Paramount',                      'gz66EfNoYPqHTYI4q9UEN4CbHRc.png'),
            ('33',          'Universal Pictures',         'Universal Pictures',             '8lvHyhjr8oUKOOy2dKXoALWKdp0.png'),
            ('2',           'Walt Disney Pictures',       'Walt Disney Pictures Presents',  'wdrCwmRnLFJhEoH8GSfymY85KHT.png'),
            ('17',          'Warner Bros. Entertainment', 'Warner Bros. Entertainment',     '7Qu05UOqxdTGLl3kOvkRBv723Vz.png'),
            ('3',           'Pixar',                      'Pixar',                          '1TjvGVDMYsj6JBxOAkUHpPEwLf7.png'),
            ('1',           'Lucasfilm Ltd.',             'Lucasfilm Ltd.',                 'tlVSws0RvvtPBwViUyOFAO0vcQS.png'),
            ('5',           'Columbia Pictures',          'Columbia Pictures',              '71BqEFAF4V3qjjMPCpLuyJFB9A.png' ),
            ('34',          'Sony Pictures',              'Sony Pictures',                  'mtp1fvZbe4H991Ka1HOORl572VH.png'),
            ('38',          'Zespół Filmowy "Tor"',       'Studio Filmowe Tor',             'qMi10Y3HnR7BQRqMC4ch7qZ6HN4.png'),
            ('21',          'Metro-Goldwyn-Mayer',        'Metro-Goldwyn-Mayer',            'usUnaYV6hQnlVAXP6r4HwrlLFPG.png'),
            ('7926',        'Zespół Filmowy Kadr',        'Kadr',                           ''                               ),
            ('58225',       'Studio Filmowe Zebra',       'Studio Filmowe Zebra',           ''                               ),
            ('81883',       'Studio Filmowe Iluzjon',     'Studio Filmowe Iluzjon',         ''                               ),
            ('18392',       'Monolith Films',             'Monolith Films',                 ''                               ),
            ('14',          'Miramax',                    'Miramax',                        'm6AHu84oZQxvq7n1rsvMNJIAsMu.png'),
            ('6704',        'Illumination',               'Illumination Entertainment',     'uwy3O0fb0CKeLqINPgiGKbTMeux.png'),
            ('12',          'New Line Cinema',            'New Line Cinema',                'iaYpEp3LQmb8AfAtmTvpqd4149c.png'),
            ('56',          'Amblin Entertainment',       'Amblin Entertainment',           'cEaxANEisCqeEoRvODv2dO1I0iI.png'),
            ('429',         'DC Comics',                  'DC Comics',                      '2Tc1P3Ac8M479naPp1kYT3izLS5.png'),
            ('923',         'Legendary Pictures',         'Legendary Pictures',             '8M99Dkt23MjQMTTWukq4m5XsEuo.png'),
            ('10342',       'Studio Ghibli',              'Studio Ghibli',                  'eS79pslnoKbWg7t3PMA9ayl0bGs.png'),
            ('521',         'DreamWorks Animation',       'DreamWorks Animation',           'kP7t6RwGz2AvvTkvnI1uteEwHet.png'),
        )
