"""
    FanFilm Add-on
    Copyright (C) 2016 mrknow

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from lib.ff.control import CallScope


def launch() -> None:
    """Main entry point for plugin calls (default.py)."""

    import sys
    from time import monotonic

    # debug
    _start_time: float = monotonic()

    # MUST be before any kodi or FF import
    from lib import autoinstall  # noqa: E402, F401, pylint: disable=W0611  # type: ignore
    # Kodi can abort this call any time from now, only an existing monitor sees it (see script_aborted()).
    from lib.info import watch_abort, unwatch_abort  # noqa: E402
    watch_abort()
    # Some consts.
    from const import const                       # noqa: E402
    from lib.preenter import preinit              # noqa: E402
    from lib.service.exc import ReloadExit        # noqa: E402
    from lib import DEBUG_LEFTOVER_OBJECTS, MODULES_TO_REMOVE_ON_EXIT  # noqa: E402

    try:
        preinit()
    except ReloadExit:
        # -- reload on source file chnged
        import xbmc
        import xbmcgui
        xbmc.log("[FanFilm][default.py][dev] change detected, force exit...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("[FanFilm][dev]", "FanFilm reload, force exit", sound=False)
        sys.exit()

    # Kodi announces its exit (System.OnQuit) once, only a monitor existing then sees it, it needs its own waiting thread
    # (the x-monitor). A call in the background (e.g. a widget) is not aborted at the exit, Kodi only waits for its end.
    from lib.ff.kotools import KodiMonitor  # noqa: E402
    KodiMonitor.instance()

    from lib.ff.logs import fflog     # noqa: E402
    from lib.info import exec_id, new_run  # noqa: E402
    from lib.ff.control import is_plugin_folder, remember_plugin_folder, current_call  # noqa: E402

    run_count: int = 0  # a call broken before it is counted: no exit / GC of "every nth"
    yellow = yellow_bold = off = ''

    # Everything after the x-monitor runs in `try`: its thread ends only by the cleanup in `finally` and Kodi waits
    # for every thread of the script (an error here would keep the call, e.g. the job of a widget, forever).
    try:
        from lib.main import reset       # noqa: E402

        # count run calls
        run_count = new_run()

        # reset some stuff on script relaod, the call of `sys.argv` too: the state of this call is kept in it from now
        reset()

        # where the call comes from (FF folder or e.g. a widget), once for the whole call
        remember_plugin_folder()

        # debug
        if const.debug.enabled:
            if const.debug.tty:
                yellow, yellow_bold, off = '\033[93m', '\033[93;1m', '\033[0m'
            T: float = monotonic() - _start_time
            fflog(f"{yellow} [FF] enter {off} [{exec_id(highlight=yellow)}] {sys.argv=}, folder={is_plugin_folder()} --- ({T:.3f}s)")
        if const.debugger.enabled:
            from cdefs import run_debugger
            run_debugger()

        run_call(current_call())
    finally:
        widgets_exit_every_nth = const.core.widgets_exit_every_nth
        if is_plugin_folder() or widgets_exit_every_nth is None:
            exit_every_nth = const.core.exit_every_nth
        else:
            exit_every_nth = widgets_exit_every_nth
        gc_every_nth = const.core.gc_every_nth
        if const.debug.enabled:
            from lib.ff.tricks import memory_stats
            T: float = monotonic() - _start_time
            exit_mode = ''
            if exit_every_nth and run_count >= exit_every_nth:
                exit_mode = ' (sys)'
            fflog(f'{yellow} [FF] exit{exit_mode} {off} [{exec_id(highlight=yellow)}] --- ({T:.3f}s),'
                  f' run={run_count}/{exit_every_nth}, gc={run_count}/{gc_every_nth}, folder={is_plugin_folder()}'
                  f' {memory_stats()}')
        # Cleanup on every plugin call
        from lib.ff.menu import KodiDirectory
        KodiDirectory.set_current_info(None, None)  # force clean  # type: ignore[reportArgumentType]
        # pending grouped notifications now, their timer threads would keep the interpreter busy (no reuse)
        from lib.ff.control import flush_grouped_notifications
        flush_grouped_notifications()
        from threading import enumerate as threading_enumerate
        from lib.ff.kotools import xmonitor_script_finish, destroy_xmonitor, active_threads
        fflog(f' [FF] finishing [{exec_id(highlight=yellow)}] threads: active={active_threads()}, all=({len(threading_enumerate())}){threading_enumerate()}')
        xmonitor_script_finish()
        fflog(f' [FF] finished [{exec_id(highlight=yellow)}] threads: active={active_threads()}, all=({len(threading_enumerate())}){threading_enumerate()}')
        if MODULES_TO_REMOVE_ON_EXIT:
            # remove same modules to free kodi objects (Addons, ListItems, etc.) from memory
            from lib.ff.tricks import remove_modules
            remove_modules(MODULES_TO_REMOVE_ON_EXIT)
        # Break FFItem reference cycles. Kodi reuses the interpreter between plugin calls and its GC can not see
        # these cycles (xbmcgui.ListItem has no Py_TPFLAGS_HAVE_GC), so unlinked items would live until the interpreter dies.
        from lib.ff.item import FFItem
        FFItem._destroy_all_items()
        if DEBUG_LEFTOVER_OBJECTS >= 2:  # what is left here is held by something else than a FFItem link
            from lib.ff.tricks import dump_ffitem_referrers, dump_leftover_objects
            dump_leftover_objects()
            dump_ffitem_referrers()
        # Free the cached xbmcaddon.Settings object now, don't keep it between runs of a reused interpreter
        # (the interpreter exit is handled by settings.release(), anything can read a setting after this point).
        from lib.ff.settings import settings
        settings.reset()
        unwatch_abort()
        # Script exit to force python interpreter reload
        exit_now = bool(exit_every_nth and run_count >= exit_every_nth)
        if exit_now:
            destroy_xmonitor()
        collect_garbage(run_count, gc_every_nth, interpreter_exit=exit_now)
        if exit_now:
            sys.exit()


def run_call(call: CallScope) -> None:
    """
    Run one plugin call, the current one (the plugin interpreter, a call thread of the service): the messages of the ignored
    `local.py` in a FF folder, main(), the Kodi exit.
    """
    from lib.ff.control import is_plugin_folder, show_local_error, show_local_obsolete
    from lib.ff.logs import fflog
    from lib.info import exec_id, script_aborted
    from lib.main import main
    from lib.preenter import premain
    from lib.service.exc import KodiExit
    if is_plugin_folder():
        show_local_error()  # the ignored `local.py`: the window the first time in a Kodi session, then a notification
        show_local_obsolete()  # its withdrawn keys (ignored): the window the first time in a Kodi session
    try:
        premain()
        if script_aborted():
            fflog(f' [FF] aborted by Kodi before start [{exec_id()}]')
        else:
            main(call.argv)
    except KodiExit:  # e.g. a sign-in waits in `xsleep()`: the call ends, not an error of the script
        fflog(f' [FF] ended by Kodi exit [{exec_id()}]')


def collect_garbage(run_count: int, gc_every_nth: int, *, interpreter_exit: bool) -> None:
    """Run the GC at the end of a plugin call: every `gc_every_nth` call and before the interpreter exit.

    After the first call the live objects (modules, imports) are frozen, later collections skip them (K22 desktop
    20 -> 2 ms). The collection runs after the answer to Kodi, which reuses only an idle interpreter: a call coming
    meanwhile gets a cold one (1.4 s). Python 3.8 is not frozen: it has one GC for all interpreters (the service, other
    add-ons), its freeze would keep their objects past the end of their interpreter.
    """
    import gc
    import sys
    if interpreter_exit:
        gc.unfreeze()
        gc.collect()
        return
    if gc_every_nth and run_count % gc_every_nth == 0:
        gc.collect()
    if run_count == 1 and sys.version_info >= (3, 9):
        gc.freeze()
