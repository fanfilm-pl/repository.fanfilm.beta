"""
The logs of the SDK: no import of the add-on code (only stdlib, Kodi modules and `typing_extensions`), the add-on
binds it with `options` (prefix, thread check, developer logs switch, top path) and `log.format` (FanFilm: `lib/ff/logs.py`).

MIT License

Copyright (c) 2023-2026 FanFilm

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

from pathlib import Path
from contextlib import contextmanager, redirect_stdout
from functools import wraps, lru_cache
from io import TextIOBase
import sys
import re
import logging
from traceback import extract_tb, extract_stack, format_exception_only, FrameSummary
from sys import exc_info
from inspect import isclass, currentframe
from typing import Optional, Union, Any, Callable, Dict, List, Set, Tuple, Generator, Iterable, Iterator, Type, NamedTuple, TypeVar, overload
from typing_extensions import Protocol, TypedDict, Unpack, NotRequired, ParamSpec, Literal, Self
from types import ModuleType, TracebackType


P = ParamSpec('P')
R = TypeVar('R')


try:
    import xbmc
    import xbmcaddon
    from xbmc import LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR, LOGFATAL

except ModuleNotFoundError:
    # DEBUG & TESTS: direct run
    xbmcaddon = None
    LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR, LOGFATAL = 0, 1, 2, 3, 4
    _stdout = sys.stdout
    _stderr = sys.stderr

    class xbmc:
        @staticmethod
        def log(msg: str, level: int = LOGINFO):
            print(f'<{level}> {msg}', file=_stderr)


#: Special FanFilm log level. MUST be power of two.
LOGFF = 0x10000

#: Kodi log levels as `logging` levels.
PY_LEVELS: Dict[int, int] = {
    LOGDEBUG: logging.DEBUG,
    LOGINFO: logging.INFO,
    LOGWARNING: logging.WARNING,
    LOGERROR: logging.ERROR,
    LOGFATAL: logging.CRITICAL,
}

#: Name of the handler of `logging` records (on the root logger).
HANDLER_NAME = 'kodi'


def py_level(level: int) -> int:
    """Return the `logging` level of a Kodi log level."""
    return PY_LEVELS.get(level, logging.INFO)


def kodi_level(levelno: int) -> int:
    """Return the Kodi log level of a `logging` level (a level between two goes down)."""
    return max((level for level, py in PY_LEVELS.items() if py <= levelno), key=PY_LEVELS.__getitem__, default=LOGDEBUG)

#: Top lib path.
TOP_PATH = Path(__file__).parent.parent  # lib/ folder


@lru_cache(maxsize=None)
def _relative_filename(filename: str, top_path: Path) -> str:
    """Source file path relative to `top_path` (or the bare file name), computed once per file - it is needed in every log line."""
    try:
        return str(Path(filename).relative_to(top_path))
    except ValueError:
        return Path(filename).name


def _path_is_relative_to(path: Path, other: Path) -> bool:
    """Return True if `path` is under `other` (`Path.is_relative_to()` of Python 3.9+)."""
    try:
        path.relative_to(other)
    except ValueError:
        return False
    return True


class LogProto(Protocol):
    """Protocol for log* functions."""  # noqa: D204
    ERROR: int
    WARNING: int
    INFO: int
    DEBUG: int
    #: The line format (log only).
    format: '_Format'
    def __call__(self, msg: str, level: int = LOGINFO, *, module: Optional[str] = None, title: Optional[str] = None, stack_depth: int = 1,     # noqa: D102
                 skip_empty_frames: bool = True, traceback: bool = False, indent: int = 4, internal: bool = False) -> None: ...
    @staticmethod                                                                                                                              # noqa: E301
    def error(msg: str, *, module: Optional[str] = None, title: Optional[str] = None, stack_depth: int = 1, skip_empty_frames: bool = True,    # noqa: D102
              traceback: bool = False, indent: int = 4, internal: bool = False) -> None: ...
    @staticmethod                                                                                                                              # noqa: E301
    def warning(msg: str, *, module: Optional[str] = None, title: Optional[str] = None, stack_depth: int = 1, skip_empty_frames: bool = True,  # noqa: D102
                traceback: bool = False, indent: int = 4, internal: bool = False) -> None: ...
    @staticmethod                                                                                                                              # noqa: E301
    def info(msg: str, *, module: Optional[str] = None, title: Optional[str] = None, stack_depth: int = 1, skip_empty_frames: bool = True,     # noqa: D102
             traceback: bool = False, indent: int = 4, internal: bool = False) -> None: ...
    @staticmethod                                                                                                                              # noqa: E301
    def debug(msg: str, *, module: Optional[str] = None, title: Optional[str] = None, stack_depth: int = 1, skip_empty_frames: bool = True,    # noqa: D102
              traceback: bool = False, indent: int = 4, internal: bool = False) -> None: ...


class LogExcProto(Protocol):
    """Protocol for log_exc* functions."""  # noqa: D204
    def __enter__(self) -> None: ...                                                                                                           # noqa: D105
    def __exit__(self, exc_type: Optional[Type[BaseException]], exc: Optional[BaseException], tb: Optional[TracebackType]) -> None: ...        # noqa: D105
    def __call__(self, func: Callable[P, R]) -> Callable[P, R]: ...                                                                            # noqa: D102


class LogKwargs(TypedDict):
    module: NotRequired[Optional[str]]    # force module name
    title: NotRequired[Optional[str]]     # add extra == TITLE ==
    # stack_depth: NotRequired[int]         # stack depth, how many frame omits, default is 1 – log() caller
    skip_empty_frames: NotRequired[bool]  # hide frames with no info
    traceback: NotRequired[bool]          # print traceback (call stack)
    indent: NotRequired[int]              # traceback lines indent
    internal: NotRequired[bool]           # internal log (skip thread cancel check and FF-log level check, for log_exc() and fflog_exc()


class Options:
    """Simple global logging options, the add-on binds the core with them."""

    def __init__(self) -> None:
        self._show_fflog: Optional[bool] = None
        #: Read the developer logs switch (None: always shown), read once, again after `del options.show_fflog`.
        self.read_show_fflog: Optional[Callable[[], bool]] = None
        #: The line prefix (called for every line, e.g. "[FanFilm][service]").
        self.prefix: Callable[[], str] = lambda: f'[{addon_name}]'
        #: Called before every not internal log (e.g. raise if the current thread is canceled).
        self.on_log: Optional[Callable[[], None]] = None
        #: Top path of the sources, the file paths in the lines are relative to it.
        self.top_path: Path = TOP_PATH
        #: The lines go to `logging` (tests), not to the Kodi log; see `use_logging()`.
        self.to_logging: bool = False
        #: The `logging` configuration of the developer logs (see `logging_config()`), applied when they are shown.
        self.logging_config: Optional[Callable[[], Dict[str, Any]]] = None
        #: The logger of `log()` (the user logs) with `to_logging`.
        self.user_logger: str = addon_name.lower()

    @property
    def show_fflog(self) -> bool:
        if self._show_fflog is None:
            self.show_fflog = True if self.read_show_fflog is None else self.read_show_fflog()
        return self._show_fflog

    @show_fflog.setter
    def show_fflog(self, value: bool) -> None:
        self._show_fflog = bool(value)
        _switch_developer_logs(self._show_fflog)

    @show_fflog.deleter
    def show_fflog(self) -> None:
        self._show_fflog = None


#: Extra sub-module in logging
_log_submodule: List[str] = []


if xbmcaddon:
    addon_name = xbmcaddon.Addon().getAddonInfo('name')
else:
    addon_name = 'FanFilm'

#: Global logging options
options = Options()


class CallerInfo(NamedTuple):
    """Nicer caller frame info."""

    #: Source filename.
    filename: str
    #: Code line.
    lineno: int
    #: Caller function.
    funcname: str
    #: Caller function.
    func_short_name: str
    #: Caller module.
    module: Union[ModuleType, Literal['-']]

    @property
    def is_exec(self) -> bool:
        """True if code is dynamic (exec)."""
        return self.filename == '<string>'

    @property
    def full_name(self) -> str:
        """Full name: module and function."""
        return f'{self.module}.{self.funcname}'

    @classmethod
    def from_frame(cls, frame) -> 'CallerInfo':
        """Create CallerInfo form given frame."""
        caller = frame.f_code
        module = frame.f_globals.get('__name__')
        co_qualname: str = caller.co_name
        if sys.version_info >= (3, 11):
            co_qualname = caller.co_qualname
        else:
            if 'self' in caller.co_varnames:
                this = frame.f_locals.get('self')
                if this:
                    try:
                        co_qualname = f'{this.__class__.__name__}.{caller.co_name}'
                    except KeyError:
                        pass
            elif 'cls' in caller.co_varnames:
                this = frame.f_locals.get('cls')
                if this and isclass(this):
                    try:
                        co_qualname = f'{this.__name__}.{caller.co_name}'
                    except KeyError:
                        pass
        return cls(caller.co_filename, frame.f_lineno, co_qualname, caller.co_name, module)

    @classmethod
    def info(cls, n: int = 1, *, skip_empty_frames: bool = True) -> Optional['CallerInfo']:
        """Return CallerInfo from `n` depth caller frame."""
        frame = currentframe().f_back  # back from get_caller_info()
        try:
            for _ in range(n):
                if frame is None:
                    break
                back = frame.f_back
                del frame
                frame = back
            while frame:
                info = cls.from_frame(frame)
                if not skip_empty_frames or not info.is_exec:
                    return info
                back = frame.f_back
                del frame
                frame = back
        finally:
            # see https://docs.python.org/3/library/inspect.html#inspect.Traceback
            del frame

    @property
    def module_name(self) -> str:
        if self.is_exec:
            return '-'
        return f'{_relative_filename(self.filename, options.top_path)}:{self.lineno}'

    @classmethod
    def empty(cls) -> Self:
        return cls('<string>', 0, '-', '-', '-')


def _log(msg: str, level: int = LOGINFO, *,
         module: Optional[str] = None,    # force module name
         title: Optional[str] = None,     # add extra == TITLE ==
         stack_depth: int = 1,            # stack depth, how many frame omits, default is 1 – log() caller
         skip_empty_frames: bool = True,  # hide frames with no info
         traceback: bool = False,         # print traceback (call stack)
         indent: int = 4,                 # traceback lines indent
         internal: bool = False,          # internal log (skip thread cancel check and FF-log level check, for log_exc() and fflog_exc()
         ) -> None:
    """Nicer logging (with addon name and caller info)."""

    # Support threads canceling (the add-on hook, e.g. raise if the current thread is canceled,
    # so log() caller can stop execution immediately without extra checks).
    if not internal and options.on_log is not None:
        options.on_log()

    # Support extended levels.
    dev = False  # developer log (fflog)
    try:
        if level & LOGFF:
            if not options.to_logging and not options.show_fflog:
                return
            level &= LOGFF - 1  # mask (0x10000 -> 0xffff)
            dev = True
    except Exception as exc:  # e.g. the switch read in the middle of an import (`local.py` broken at the start): never lose the message
        xbmc_log(f'log(FF) failed: {exc}', LOGDEBUG)
        level &= LOGFF - 1
        dev = True

    # Get info about caller.
    caller = CallerInfo.info(n=stack_depth, skip_empty_frames=skip_empty_frames)
    if not caller:
        caller = CallerInfo.empty()

    # Module / source.
    if module is None:
        # a) module name.
        # module = caller.module
        # b) source:line.
        module = caller.module_name
        logger_name = str(caller.module)
    else:
        logger_name = module

    # The logger: the module of the source in the line (developer logs), the add-on one (user logs, to `logging` only).
    logger: Optional[logging.Logger] = None
    if dev or options.to_logging:
        logger = logging.getLogger(logger_name if dev else options.user_logger)
        if not logger.isEnabledFor(py_level(level)):
            return

    # kodi bug, each `sys.stderr.flush()` generates message "."
    if msg == '.' and caller:
        direct = CallerInfo.info(n=stack_depth, skip_empty_frames=False)
        if direct is not None and direct.func_short_name == 'flush':
            return
    # reformat
    msg = log.format.sub(3 * "\052", str(msg))

    # Extra == TITLE ==.
    if title is None:
        title = ''
    else:
        title = f' == {title} =='

    # Function name.
    funcname = caller.funcname
    if funcname == '<module>':
        funcname = '-'

    if traceback:
        msg = f'{msg}\n{traceback_string(None, current_stack=True, stack_depth=stack_depth+1, indent=indent)}'

    try:
        if msg:  # Sprawdzanie, czy msg nie jest puste
            sub = ''.join(f'[{mod}]' for mod in _log_submodule)
            if options.to_logging and logger is not None:
                text = f'{title.strip()} {msg}' if title else msg
                record = logger.makeRecord(logger.name, py_level(level), caller.filename, caller.lineno, text, (), None, caller.funcname,
                                           extra={'prefix': options.prefix(), 'submodule': sub})
                logger.handle(record)
            else:
                xbmc_log(f'{options.prefix()}[{module}][{funcname}]{sub}{title} {msg}', level)
    except Exception as exc:
        try:
            if not isinstance(level, int):
                level = LOGINFO
            xbmc_log(f"Logging Failure: {exc}", level)
        except Exception:
            pass  # just give up


def error(msg: str, *,
          stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
          **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
          ) -> None:
    """Just log() but with LOGERROR level."""
    return _log(msg, level=LOGERROR, stack_depth=stack_depth+1, **kwargs)


def warning(msg: str, *,
            stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
            **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
            ) -> None:
    """Just log() but with LOGWARNING level."""
    return _log(msg, level=LOGWARNING, stack_depth=stack_depth+1, **kwargs)


def info(msg: str, *,
         stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
         **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
         ) -> None:
    """Just log() but with LOGINFO level."""
    return _log(msg, level=LOGINFO, stack_depth=stack_depth+1, **kwargs)


def debug(msg: str, *,
          stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
          **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
          ) -> None:
    """Just log() but with LOGDEBUG level."""
    return _log(msg, level=LOGDEBUG, stack_depth=stack_depth+1, **kwargs)


log: LogProto = _log
log.error = error
log.warning = warning
log.info = info
log.debug = debug

log.ERROR = LOGERROR
log.WARNING = LOGWARNING
log.INFO = LOGINFO
log.DEBUG = LOGDEBUG


# -- fflog ---


def _fflog(msg: str, level: int = LOGINFO, *,
           stack_depth: int = 1,         # stack depth, how many frame omits, default is fflog() caller
           **kwargs: Unpack[LogKwargs],  # rest of log() keyword args
           ) -> None:
    """Just log() but with LOGFF flag, default LOGINFO level."""
    if not isinstance(level, int):
        level = LOGINFO
    return _log(msg, level=level | LOGFF, stack_depth=stack_depth+1, **kwargs)


def fferror(msg: str, *,
            stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
            **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
            ) -> None:
    """Just fflog() but with LOGERROR level."""
    return _fflog(msg, level=LOGERROR, stack_depth=stack_depth+1, **kwargs)


def ffwarning(msg: str, *,
              stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
              **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
              ) -> None:
    """Just fflog() but with LOGWARNING level."""
    return _fflog(msg, level=LOGWARNING, stack_depth=stack_depth+1, **kwargs)


def ffinfo(msg: str, *,
           stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
           **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
           ) -> None:
    """Just fflog() but with LOGINFO level."""
    return _fflog(msg, level=LOGINFO, stack_depth=stack_depth+1, **kwargs)


def ffdebug(msg: str, *,
            stack_depth: int = 1,          # stack depth, how many frame omits, default is fflog() caller
            **kwargs: Unpack[LogKwargs],   # rest of log() keyword args
            ) -> None:
    """Just fflog() but with LOGDEBUG level."""
    return _fflog(msg, level=LOGDEBUG, stack_depth=stack_depth+1, **kwargs)


fflog: LogProto = _fflog
fflog.error = fferror
fflog.warning = ffwarning
fflog.info = ffinfo
fflog.debug = ffdebug

fflog.ERROR = LOGERROR | LOGFF
fflog.WARNING = LOGWARNING | LOGFF
fflog.INFO = LOGINFO | LOGFF
fflog.DEBUG = LOGDEBUG | LOGFF


# ---


class _Format:
    """The format of the log lines (the base words of the add-on), tuned by the stored values (see `tune()`)."""

    def __init__(self, words: Iterable[str] = (), keys: Union[str, Callable[[], str]] = '') -> None:
        from threading import Lock
        #: The keys regex of the tuning values (or its getter), nothing tuned if empty.
        self.keys: Union[str, Callable[[], str]] = keys
        #: The words: the base ones and the tuning ones.
        self._words: Set[str] = {word for word in words if word}
        #: The current state: the pattern of the words and their lower-case forms (`_compile()`), replaced at once.
        self._state: Tuple['re.Pattern[str]', Optional[Tuple[str, ...]]] = self._compile(self._words)
        #: Lock of a change.
        self._lock = Lock()

    @staticmethod
    def _compile(words: Iterable[str]) -> Tuple['re.Pattern[str]', Optional[Tuple[str, ...]]]:
        """
        Return the state of the words: their pattern (any case, the longest first; no word: never matching) and their lower-case
        forms if all of them are ASCII (else None: the pattern only, `sub()`).
        """
        ordered = sorted(words, key=len, reverse=True)
        if not ordered:
            return re.compile(r'^(?<=>)'), ()
        pattern = re.compile('|'.join(re.escape(word) for word in ordered), re.IGNORECASE)
        return pattern, tuple(word.lower() for word in ordered) if all(word.isascii() for word in ordered) else None

    def tune(self, key: str, value: Any, *, any_key: bool = False) -> None:
        """
        Tune the format by the value stored under `key`: its strings if the last part of the key ("tb7.password")
        matches `keys` (`any_key`: whatever the key), else the ones of the matching keys inside a dict ("profile" -> "username").
        """
        from urllib.parse import quote
        keys = self.keys() if callable(self.keys) else self.keys
        if not keys:
            return
        texts = _format_texts(key, value, '' if any_key else keys)  # an empty pattern matches every key
        words = {word for text in texts if len(text) >= 6 for word in (text, quote(text, safe=''))} - self._words
        if words:
            with self._lock:
                self._words |= words
                self._state = self._compile(self._words)

    def tunes(self, key: str) -> bool:
        """Return True if a value stored under `key` tunes the format (`tune()`: the last part of the key matches `keys`; no `keys`: none)."""
        keys = self.keys() if callable(self.keys) else self.keys
        return bool(keys) and _tuning_key(key, keys)

    def sub(self, repl: str, text: str) -> str:
        """
        Return the formatted text. ASCII words in an ASCII text are looked for by `in` first (its lower-case form): the pattern only
        for a found one, the same result (`re` matches some other letters for ASCII ones in any case, e.g. "K" Kelvin - a text or a
        word not ASCII: the pattern).
        """
        pattern, lows = self._state
        if lows is not None and text.isascii():
            low = text.lower()
            if not any(word in low for word in lows):
                return text
        return pattern.sub(repl, text)


def _tuning_key(key: str, keys: str) -> bool:
    """Return True if the last part of the key ("tb7.password" -> "password") matches the `keys` regex (any case; '' matches every key)."""
    return bool(re.search(keys, key.rpartition('.')[2], re.IGNORECASE))


def _format_texts(key: str, value: Any, keys: str) -> Iterator[str]:
    """Yield the strings of the value of a matching key (`keys` regex), in dicts and lists too, or of its matching subkeys."""
    if _tuning_key(key, keys):
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            for item in value.values():
                yield from _format_texts(key, item, keys)
        elif isinstance(value, (list, tuple)):
            for item in value:
                yield from _format_texts(key, item, keys)
    elif isinstance(value, dict):
        for sub, item in value.items():
            yield from _format_texts(str(sub), item, keys)


class _LogExcContext:
    """Helper for `with log_exc()`."""

    def __init__(self, stack_depth: int = 1, **kwargs):
        self.stack_depth: int = stack_depth
        self.kwargs = kwargs

    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc, tb):
        if exc:
            log_exc(exc, stack_depth=self.stack_depth, **self.kwargs)

    def __call__(self, func: Callable):
        """Return callable for  decorator()."""
        return log_exc(func, stack_depth=self.stack_depth, **self.kwargs)


def traceback_list(traceback: Optional[TracebackType],  # traceback object
                   *,
                   stack_depth: int = 1,                # stack depth, how many frame omits, default is caller
                   current_stack: bool = True,          # prepend current frame stack, useful with decorators
                   stack_limit: Optional[int] = None,   # max frames to return (negative means number of modules)
                   from_file: Optional[str] = None,     # only frames under given file (relative to TOP_PATH) and nested under it
                   ffonly: bool = False,                # only frames from FanFilm (TOP_PATH)
                   ) -> List[FrameSummary]:
    """Format traceback to list."""
    # exception
    own = {'log_exc', 'fflog_exc', 'log_exc_wrapped', 'traceback_list', 'traceback_lines', 'traceback_string', '__exit__'}
    stack: List[FrameSummary] = []
    # print('          >>', stack_depth, ', '.join(f.name for f in extract_stack()))  # DEBUG of DEBUG
    if current_stack:
        stack.append(FrameSummary('Logger traceback (most recent call last):', 0, '#'))
        stack.extend(extract_stack()[:-stack_depth or None])
    if traceback:
        stack.append(FrameSummary('Exception traceback (most recent call last):', 0, '#'))
        stack.extend(extract_tb(traceback))
    if ffonly:
        def resolve(p: 'Path | str') -> Path:
            p = Path(p)
            try:
                return p.resolve()
            except Exception:
                return p
        top_path = options.top_path.resolve()
        stack = [frame for frame in stack if _path_is_relative_to(Path(frame.filename).resolve(), top_path)]
    stack = [frame for frame in stack if frame.filename != __file__ or frame.name not in own]
    if from_file:
        skip = 0
        for frame in stack:
            if frame.filename == from_file:
                break
            skip += 1
        stack = stack[skip:]
    if stack_limit is not None and stack_limit < 0:
        file_count = -stack_limit
        prev_file = None
        stack_limit = 0
        for frame in reversed(stack):
            if frame.filename != prev_file:
                file_count -= 1
                if file_count < 0:
                    break
                prev_file = frame.filename
            stack_limit += 1
        stack = [frame for frame in stack if _path_is_relative_to(resolve(frame.filename).resolve(), top_path)]
    if stack_limit:
        stack = stack[-stack_limit:]
    return stack


def traceback_lines(traceback: Optional[TracebackType],  # traceback object
                    *,
                    stack_depth: int = 1,                # stack depth, how many frame omits, default is caller
                    current_stack: bool = True,          # prepend current frame stack, useful with decorators
                    indent: int = 4,                     # lines indent
                    stack_limit: Optional[int] = None,   # max frames to return (negative means number of modules)
                    from_file: Optional[str] = None,     # only frames under given file (relative to TOP_PATH) and nested under it
                    ffonly: bool = False,                # only frames from FanFilm (TOP_PATH)
                    ) -> Iterable[str]:
    """Format traceback to list of string."""

    def frame_str(frame: FrameSummary) -> Generator[str, None, None]:
        if frame.name == '#':
            yield f'{ind}{frame.filename}'
        else:
            yield f'{ind}  File "{frame.filename}", line {frame.lineno}, in {frame.name}'
            if frame.line:
                yield f'{ind}    {frame.line}'

    ind: str = ' ' * indent
    stack = traceback_list(traceback, stack_depth=stack_depth, current_stack=current_stack, stack_limit=stack_limit, from_file=from_file, ffonly=ffonly)
    return (line for frame in stack for line in frame_str(frame))


def traceback_string(traceback: Optional[TracebackType],  # traceback object
                     *,
                     stack_depth: int = 1,                # stack depth, how many frame omits, default is caller
                     current_stack: bool = True,          # prepend current frame stack, useful with decorators
                     indent: int = 4,                     # lines indent
                     stack_limit: Optional[int] = None,   # max frames to return (negative means number of modules)
                     from_file: Optional[str] = None,     # only frames under given file (relative to TOP_PATH) and nested under it
                     ffonly: bool = False,                # only frames from FanFilm (TOP_PATH)
                     ) -> str:
    """Format traceback to string."""
    bt_str = '\n'.join(traceback_lines(traceback, stack_depth=stack_depth, current_stack=current_stack, indent=indent,
                                       stack_limit=stack_limit, from_file=from_file, ffonly=ffonly))
    return bt_str


@overload
def log_exc(exc: Union[str, None] = None, /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> LogExcProto:  ...


@overload
def log_exc(exc: BaseException, /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> None:  ...


@overload
def log_exc(exc: Callable[P, R], /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> Callable[P, R]:  ...


def log_exc(exc: Union[BaseException, Callable[..., Any], str, None] = None,
            /,
            level: int = LOGINFO,
            *,
            stack_depth: int = 1,         # stack depth, how many frame omits, default is log_exc() caller
            traceback: bool = True,       # log fill exception traceback or traceback object directly
            current_stack: bool = True,   # prepend current frame stack, useful with decorators
            indent: int = 4,              # traceback lines indent
            title: Optional[str] = None,  # extra title for log message
            internal: bool = False,       # internal log (skip thread cancel check and FF-log level check, for log_exc() and fflog_exc()
            **kwargs,                     # rest of log() keyword args
            ) -> Any:
    """
    Nicer exception logging.

    If `exc` is None `log_exc` must be called from `except:`.
    >>> try:
    >>>     ...
    >>> except Exception:
    >>>     log_exc()

    Or as with statement:
    >>> with log_exc():
    >>>     ...

    Or as decorator:
    >>> @log_exc
    >>> def foo():
    >>>     ...
    """
    # Support threads canceling (see `_log()`).
    if not internal and options.on_log is not None:
        options.on_log()

    if isinstance(exc, str):
        if title is None:
            title = exc
        exc = None
    if exc is None:
        etype, exc, bt = exc_info()
    elif isinstance(exc, BaseException):
        etype = type(exc)
        bt = exc.__traceback__
    if isinstance(exc, BaseException):
        if traceback:
            ind = ' ' * indent
            exc_str = '\n'.join(format_exception_only(etype, exc)).rstrip().replace('\n', f'\n{ind}')
            bt_str = traceback_string(bt, current_stack=current_stack, stack_depth=stack_depth+1, indent=indent)
            bt_str = f'\n{bt_str}\n{ind}{exc_str}'
        else:
            bt_str = ''
        if title:
            title = f' == {title} ==   '
        else:
            title = ''
        log(f'{title}EXCEPTION: {exc!r}{bt_str}', level=level, stack_depth=stack_depth+1, internal=internal, **kwargs)
    elif callable(exc):
        # decorator
        @wraps(exc)
        def log_exc_wrapped(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception:
                log_exc(current_stack=True, level=level, stack_depth=stack_depth,
                        traceback=traceback, indent=indent, **log_kwargs)
                raise

        func = exc
        log_kwargs = kwargs
        return log_exc_wrapped
    else:
        return _LogExcContext(level=level, stack_depth=stack_depth, traceback=traceback,
                              current_stack=current_stack, indent=indent, **kwargs)


@overload
def fflog_exc(exc: Union[str, None] = None, /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> LogExcProto:  ...


@overload
def fflog_exc(exc: BaseException, /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> None:  ...


@overload
def fflog_exc(exc: Callable[P, R], /, level: int = LOGINFO, *, stack_depth: int = 1, **kwargs: Unpack[LogKwargs]) -> Callable[P, R]:  ...


def fflog_exc(exc: Union[BaseException, Callable[..., Any], str, None] = None,
              level: int = LOGINFO, *,
              stack_depth: int = 1,         # stack depth, how many frame omits, default is log_exc() caller
              **kwargs: Unpack[LogKwargs],  # rest of log_exc() keyword args
              ) -> Any:
    """Just log_exc() but with default LOGFF level."""
    return log_exc(exc, level=level | LOGFF, stack_depth=stack_depth+1, **kwargs)


class LogFile(TextIOBase):

    def __init__(self) -> None:
        self.closed = False
        self._buf = ''

    def closed(self) -> None:
        self.close = True

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False

    def readable(self) -> bool:
        return False

    def seekable(self) -> bool:
        return False

    def writable(self) -> bool:
        return True

    # def writelines(self) -> bool:
    #     return True

    def write(self, s: str) -> int:
        self._buf += s
        while True:
            msg, sep, self._buf = self._buf.partition('\n')
            if not sep:
                break
            fflog(msg, stack_depth=2)
        self._buf = msg
        return len(s)

    def __getattr__(self, key: str) -> None:
        raise IOError(key)


@contextmanager
def log_submodule(name: str):
    _log_submodule.append(name)
    try:
        yield None
    finally:
        _log_submodule.pop()


@contextmanager
def print_as_fflog():
    """Redirect prints as fflog() messages."""
    logfile = LogFile()
    with redirect_stdout(logfile):
        yield None


class LogHandler(logging.Handler):
    """Writes the `logging` records to the Kodi log in the format of the lines (developer logs)."""

    def emit(self, record: logging.LogRecord) -> None:
        """Write the record (a developer log: only if shown)."""
        if options.to_logging or not options.show_fflog:
            return
        try:
            msg = record.getMessage()
            if record.exc_info and record.exc_info[1] is not None:
                etype, exc, tb = record.exc_info
                ind = 4 * ' '
                exc_str = ''.join(format_exception_only(etype, exc)).rstrip().replace('\n', f'\n{ind}')
                msg = f'{msg}\n{traceback_string(tb, current_stack=False, indent=len(ind))}\n{ind}{exc_str}'
            if record.stack_info:
                msg = f'{msg}\n{record.stack_info}'
            msg = log.format.sub(3 * "\052", msg)
            sub = ''.join(f'[{mod}]' for mod in _log_submodule)
            xbmc_log(f'{options.prefix()}[{record.name}:{record.lineno}][{record.funcName}]{sub} {msg}', kodi_level(record.levelno))
        except Exception:
            self.handleError(record)


def _install_handler() -> None:
    """Put the handler on the root logger, once (an old one, e.g. of a reloaded module, is replaced)."""
    root = logging.getLogger()
    for handler in root.handlers[:]:
        if handler.get_name() == HANDLER_NAME:
            if type(handler) is LogHandler:
                return
            root.removeHandler(handler)
    handler = LogHandler()
    handler.set_name(HANDLER_NAME)
    root.addHandler(handler)


def _remove_handler() -> None:
    """Remove the handler from the root logger."""
    root = logging.getLogger()
    for handler in root.handlers[:]:
        if handler.get_name() == HANDLER_NAME:
            root.removeHandler(handler)


def use_logging(enabled: bool = True) -> None:
    """
    Write the lines to `logging` (tests): `log()` to the add-on logger, `fflog()` to the logger of the module, the levels
    and handlers of `logging` decide. Else (default) the `logging` records go to the Kodi log as developer logs.
    """
    options.to_logging = enabled
    if enabled:
        _remove_handler()  # no loop: fflog -> logging -> handler -> fflog
        logging.disable(logging.NOTSET)
    else:
        _install_handler()


def logging_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return the `logging.config.dictConfig()` configuration of the developer logs from the `loggers` section
    (or a full configuration, with "version"). A level text under a logger name is the short form of {"level": ...};
    levels in any case; the "" logger is the root one; the loggers existing already stay enabled.
    """

    def norm(value: Any) -> Dict[str, Any]:
        """Return the logger configuration."""
        value = {'level': value} if isinstance(value, str) else dict(value)
        if isinstance(value.get('level'), str):
            value['level'] = value['level'].upper()
        return value

    full = dict(config) if 'version' in config else {'loggers': config}
    loggers = {name: norm(value) for name, value in full.get('loggers', {}).items()}
    root = loggers.pop('', None)
    if root is not None:
        full['root'] = root
    elif 'root' in full:
        full['root'] = norm(full['root'])
    full['loggers'] = loggers
    full['version'] = 1
    full.setdefault('disable_existing_loggers', False)
    return full


#: The developer logs configuration is applied (once).
_logging_configured: bool = False


def _switch_developer_logs(show: bool) -> None:
    """Switch the developer logs: hidden - no `logging` record at all, shown - the configuration applied (once)."""
    global _logging_configured
    if options.to_logging:
        return
    if show:
        if not _logging_configured and options.logging_config is not None:
            from logging.config import dictConfig  # not imported if the developer logs are hidden
            _logging_configured = True
            dictConfig(logging_config(options.logging_config()))
            _install_handler()  # the configuration of the root logger removes its handlers
        logging.disable(logging.NOTSET)
    else:
        logging.disable(logging.CRITICAL)


#: The format of the lines (the add-on sets its own, see `_Format`), no word here.
log.format = _Format()
#: Kodi log (the original one, the add-on can replace `xbmc.log` with `log`).
xbmc_log = xbmc.log


# Direct call – TESTS
if __name__ == '__main__':

    def test3():
        from contextlib import suppress
        with suppress(Exception):
            with log_exc():
                raise ValueError('with')

        @log_exc
        def aa1(): raise ValueError('aa1')

        @log_exc()
        def aa2(): raise ValueError('aa2')

        @log_exc('a')
        def aa3(): raise ValueError('aa3')

        with suppress(Exception):
            aa1()
        with suppress(Exception):
            aa2()
        with suppress(Exception):
            aa3()

        try:
            raise ValueError('log_exc()')
        except:
            log_exc()
        try:
            raise ValueError('log_exc("a")')
        except:
            log_exc('a')
        try:
            raise ValueError('log_exc(exc)')
        except:
            log_exc(Exception('exc'))
        raise SystemExit(0)

    # test3()

    from contextlib import suppress
    from inspect import currentframe

    def aaa():
        frame = currentframe()
        while frame:
            print(CallerInfo.from_frame(frame))
            frame = frame.f_back

    class Class:
        def bar(self):
            log('Blada')

        @classmethod
        def baz(cls):
            log('Kopana')

    def foo(a='a'):
        log('Dupa')

    def bbb():
        exec('aaa()')

    if 1:
        bbb()
        print('---')
        aaa()
        print('--- --- ---')

    exec('log("egzek")')
    foo()
    Class().bar()
    Class.baz()

    try:
        import yyy.zzz  # noqa: F401
    except ModuleNotFoundError:
        pass

    with print_as_fflog():
        print('dupa\nblada')
        print('i zbita')

    if 1:
        def raise_exc():
            raise SyntaxError('łubudu')

        def test_except():
            try:
                raise_exc()
            except SyntaxError:
                fflog_exc()

        def no_deco():
            raise_exc()

        @fflog_exc
        def deco1():
            raise_exc()

        @fflog_exc(indent=8)
        def deco2():
            raise_exc()

        def outer(func):
            func()

        print('--- log exc ---')
        print('--- except: (module)')
        try:
            outer(no_deco)
        except SyntaxError:
            fflog_exc()
        print('--- except: (inside)')
        outer(test_except)
        print('--- @decorator')
        with suppress(SyntaxError):
            outer(deco1)
        print('--- @decorator()')
        with suppress(SyntaxError):
            outer(deco2)
        print('--- with:')
        with suppress(SyntaxError):
            with fflog_exc(level=LOGERROR):
                outer(no_deco)
