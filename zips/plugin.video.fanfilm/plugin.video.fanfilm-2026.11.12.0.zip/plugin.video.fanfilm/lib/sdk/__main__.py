"""
The SDK commands.

    python -m lib.sdk copy <add-on lib folder>

copies the SDK as the package `ffsdk` and the libraries it needs (`attrs`, `typing_extensions`, `simpleeval`, with their licenses)
into `3rd` of the add-on lib folder (the worker script puts `lib` and `lib/3rd` on its path). A copy is generated: it
is replaced as a whole, its version is in `ffsdk/COPY.json`.
"""

from __future__ import annotations
import json
import shutil
import sys
from datetime import date
from pathlib import Path
from . import __version__

#: The SDK folder.
SDK_PATH = Path(__file__).resolve().parent
#: The libraries of the SDK (`lib/3rd` of FanFilm).
THIRD_PATH = SDK_PATH.parent / '3rd'
#: The libraries the SDK imports, copied with it.
LIBRARIES: tuple[str, ...] = ('attr', 'attrs', 'typing_extensions', 'simpleeval')
#: The license of `attrs` (MIT), its package carries none.
ATTRS_LICENSE = '''The MIT License (MIT)

Copyright (c) 2015 Hynek Schlawack and the attrs contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
'''


def copy(dest: Path) -> None:
    """Copy the SDK (`<dest>/ffsdk`) and its libraries (`<dest>/3rd`) into the add-on lib folder `dest`."""
    ignore = shutil.ignore_patterns('__pycache__', '*.pyc', '__main__.py')
    target = dest / 'ffsdk'
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(SDK_PATH, target, ignore=ignore)
    (target / 'COPY.json').write_text(json.dumps({'sdk': __version__, 'generated': date.today().isoformat(),
                                                  'source': 'FanFilm lib/sdk'}, indent=2) + '\n', encoding='utf-8')
    third = dest / '3rd'
    third.mkdir(parents=True, exist_ok=True)
    for name in LIBRARIES:
        if (third / name).exists():
            shutil.rmtree(third / name)
        shutil.copytree(THIRD_PATH / name, third / name, ignore=ignore)
    (third / 'attrs.LICENSE').write_text(ATTRS_LICENSE, encoding='utf-8')


def main(argv: list[str]) -> int:
    """Run a command, return the exit code."""
    if len(argv) == 2 and argv[0] == 'copy':
        copy(Path(argv[1]))
        print(f'ffsdk {__version__} copied to {argv[1]}')
        return 0
    print(__doc__)
    return 2


if __name__ == '__main__':
    # the arguments as given: FanFilm's `lib` (the package of `-m lib.sdk`) replaces `sys.argv` with a plugin call
    args = sys.orig_argv[sys.orig_argv.index('-m') + 2:] if '-m' in getattr(sys, 'orig_argv', ()) else sys.argv[1:]
    sys.exit(main(args))
