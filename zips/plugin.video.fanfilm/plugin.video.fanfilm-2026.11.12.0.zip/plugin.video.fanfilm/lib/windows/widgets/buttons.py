"""
The buttons (`resources/skins/widgets/buttons.xml`): a button, a check box, a radio button (Qt: QAbstractButton and its children), a group
of check boxes (Qt: QButtonGroup).
"""

from __future__ import annotations
from typing import Any, Iterable, Iterator, TYPE_CHECKING
from ...ff.signals import ClassSignal
from . import Property, Widget, gray_text, widget_class
if TYPE_CHECKING:
    from ..xgui import WidgetEntry

#: The state words of a check box by its value (the window property `ffw.<id>.state`, a row property: the texture name, the look):
#: checked, unchecked, neither (a tristate box: Qt's partially checked).
CHECK_STATES: dict[bool | None | str, str] = {True: 'on', False: 'off', None: 'mid', 'block': 'block', 'pass': 'pass'}


def next_checked(checked: bool | None, tristate: bool = False) -> bool | None:
    """Return the value of a check box after a click (OK): a tristate one neither -> checked -> unchecked -> neither, else the other one."""
    if tristate:
        return True if checked is None else False if checked else None
    return not checked


def group_paths(path: str, name: str) -> Iterator[str]:
    """
    Yield the paths the button group `name` of the widget `path` may have, the nearest first: a group of that name among the children of
    each parent widget, up to the window (a member takes the first one existing).
    """
    while path:
        path = path.rpartition('.')[0]
        yield f'{path}.{name}' if path else name


def check_button_groups(entries: Iterable[WidgetEntry]) -> None:
    """Check the button groups of the members of a generated window (`TemplateError`): a group of their name is declared, not in a row."""
    from ..xgui import TemplateError
    by_path = {entry.path: entry for entry in entries}
    for entry in by_path.values():
        if not (name := entry.data.get('button_group')):
            continue
        if entry.row:
            raise TemplateError(f'Widget {entry.path!r} of a row of a list in the button group {name!r} (no controls of the window)', src=entry.src)
        group = next((by_path[path] for path in group_paths(entry.path, name) if path in by_path), None)
        if group is None or not issubclass(widget_class(group), ButtonGroup):
            raise TemplateError(f'Widget {entry.path!r}: no button group {name!r} declared in its parent widgets', src=entry.src)


class AbstractButton(Widget):
    """
    A button: its text, its click (`clicked`); a click of a disabled one (a gray one with its reason) does nothing. A text of
    Python (`text`) is gray while the button is disabled (`shown_text()`); a text of the template is Kodi's (its `disabledcolor`).
    """

    #: The text (empty: the one of the template).
    text: Property[str] = Property('')

    def shown_text(self) -> str:
        """Return the text as Kodi shows it: the one of Python (grayed if the button is disabled), else the one of the template."""
        return gray_text(self.text, self.enabled) or self.template_value('text')

    def _text_changed(self, name: str) -> bool:
        """Return True if the property changes the shown text of Python (the text, its gray look)."""
        return name == 'text' or (name == 'enabled' and bool(self.text))

    def apply_window_property(self, name: str) -> None:
        """Apply the text (also its gray look) of the window property of the template (no text there)."""
        if self._text_changed(name) and self.window_text:
            self.win.setProperty(f'ffw.{self.id}.text', self.shown_text())  # type: ignore[attr-defined]

    def apply_property(self, name: str) -> None:
        """Apply the text (also its gray look): the window property of the template (no text there), else the label of the Kodi button."""
        self.apply_window_property(name)
        if self._text_changed(name) and not self.window_text and (button := self.control()) is not None:
            button.setLabel(self.shown_text())  # type: ignore[attr-defined]
        if name != 'text':
            super().apply_property(name)

    def handle_click(self, control_id: int) -> bool | None:
        """A click of the button: `clicked`; a disabled button (gray, keeping the focus) ignores it (the window too)."""
        if control_id == self.id and not self.enabled:
            return True
        return super().handle_click(control_id)


class PushButton(AbstractButton):
    """A button."""


class FocusButton(AbstractButton):
    """A transparent button: the focus and the clicks over something drawn elsewhere (a column of a row of a list)."""


class CheckBox(AbstractButton):
    """
    A check box: a click toggles it (`checked`, `toggled(checked)`; a tristate one goes through its three values, `next_checked()`); its
    look is the state of the window properties of the widget.
    """

    #: The value: checked or not.
    VALUE = 'checked'

    #: Checked (True), unchecked (False), neither (None: a tristate box only - Qt's partially checked; a filter: must, must not, any).
    checked: Property[bool | None] = Property(False)

    #: The user toggled it: its new value.
    toggled: ClassSignal = ClassSignal()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The box, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        #: The group of the box (None: none; `built()`).
        self.group: ButtonGroup | None = None

    def built(self) -> None:
        """
        Join the group of the box (the nearest of the parent widgets with a group of its name: `group_paths()`), set the state and the
        colours of the box at once, also the defaults (the first frame of the window shows them).
        """
        super().built()
        if name := self.button_group:
            root: Widget = self
            while root.parent is not None:  # the root of the tree (the window has no tree yet)
                root = root.parent
            for path in group_paths(self.path, name):
                try:
                    group = root.find(path, ButtonGroup)
                except KeyError:
                    continue
                group.add(self)
                break
            else:
                raise KeyError(f'{self!r}: no button group {name!r}')
        self.apply_window_property('checked')
        self.apply_window_property('enabled')

    def apply_window_property(self, name: str) -> None:
        """
        Apply the state (the box texture by the window property `ffw.<id>.state`), the colours of the box not focused / focused
        (`ffw.<id>.color0` / `color1`: the template's `color`, `focused_color`, a disabled box `gray_color`; a toggle switch: faded by
        `ffw.<id>.gray`), the text.
        """
        if name == 'checked':
            self.win.setProperty(f'ffw.{self.id}.state', CHECK_STATES[self.checked])  # type: ignore[attr-defined]
        elif name in ('enabled', 'reason') and self.entry is not None:
            data = self.entry.data
            colors = (data['color'], data['focused_color']) if self.enabled else (data['gray_color'],) * 2
            for focused, color in enumerate(colors):
                self.win.setProperty(f'ffw.{self.id}.color{focused}', color)  # type: ignore[attr-defined]
            self.win.setProperty(f'ffw.{self.id}.gray', '' if self.enabled else 'true')  # type: ignore[attr-defined]
        super().apply_window_property(name)

    def apply_property(self, name: str) -> None:
        """Apply the window properties of the widget (`apply_window_property()`), the visibility (the box and the button: the group)."""
        if name == 'visible':  # the box and the button together
            if (group := self.control('group')) is not None:
                group.setVisible(self.visible)
        else:
            super().apply_property(name)

    @property
    def button_group(self) -> str:
        """Return the name of the group of the box (its template param `button_group`; '' none)."""
        return self.entry.data.get('button_group', '') if self.entry is not None else ''

    @property
    def tristate(self) -> bool:
        """Return True if the box has the third value (None: neither; its template param `tristate` - the look is generated for it)."""
        return self.entry is not None and bool(self.entry.data.get('tristate'))

    @property
    def group_value(self) -> Any:
        """Return the value of the box in its group: its template param `value`, else its position among the members (None: no group)."""
        if self.group is None:
            return None
        value = self.entry.data.get('value') if self.entry is not None else None
        return self.group.members.index(self) if value is None else value

    def property_changed(self, name: str) -> None:
        """The box checked or unchecked: its group follows (Qt: QButtonGroup)."""
        if name == 'checked' and self.checked is None and not self.tristate:
            raise ValueError(f'{self!r}: no third value (None) of a box which is not tristate')
        if name == 'checked' and self.group is not None:
            self.group.member_toggled(self)
        super().property_changed(name)

    def handle_click(self, control_id: int) -> bool | None:
        """
        A click toggles the box (`next_checked()`; not a disabled one, not the checked one of an exclusive group without `allow_none`),
        `toggled`, then `changed` of its group.
        """
        if control_id == self.id and self.enabled and (self.group is None or self.group.can_toggle(self)):
            self.checked = next_checked(self.checked, self.tristate)
            self.toggled.emit(self.checked)
            if self.group is not None:
                self.group.changed.emit(self.group.value)
        return super().handle_click(control_id)


class RadioButton(CheckBox):
    """A radio button (the radio look of a check box)."""


class ButtonGroup(Widget):
    """
    A group of check boxes / radio buttons (Qt: QButtonGroup): no control. Exclusive (its template param `exclusive`, the default): one
    member checked, its value the value of the checked one (None: none yet; `allow_none` - a click on the checked one unchecks it); else
    any (a set): the frozenset of the values of the checked ones. The value set checks the members; `changed` - a click of the user only.
    """

    #: The value: of the checked member (exclusive, None none) / the frozenset of the values of the checked members.
    VALUE = 'value'

    #: The value of the checked member (exclusive; None: none) / the set of the values of the checked members (not exclusive).
    value: Property[Any] = Property(None)

    #: The user clicked a member: the new value of the group.
    changed: ClassSignal = ClassSignal()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The group, no members yet (they join it: `CheckBox.built()`, in the document order)."""
        super().__init__(*args, **kwargs)
        #: The members in the document order.
        self.members: list[CheckBox] = []
        #: The group sets its members (their changes do not change the value).
        self._syncing: bool = False
        if not self.exclusive:
            self.__dict__['value'] = frozenset()  # the default of a set, no change

    @property
    def exclusive(self) -> bool:
        """Return True if one member is checked (its template param `exclusive`), False for any (a set)."""
        return self.entry is None or bool(self.entry.data.get('exclusive', True))

    @property
    def allow_none(self) -> bool:
        """Return True if a click on the checked member of an exclusive group unchecks it (its template param `allow_none`)."""
        return self.entry is not None and bool(self.entry.data.get('allow_none'))

    def add(self, box: CheckBox) -> None:
        """Add a member (its value: `CheckBox.group_value`)."""
        box.group = self
        self.members.append(box)

    def can_toggle(self, box: CheckBox) -> bool:
        """Return True if a click toggles the member: not the checked one of an exclusive group without `allow_none`."""
        return not (self.exclusive and box.checked and not self.allow_none)

    def member_toggled(self, box: CheckBox) -> None:
        """A member checked or unchecked (not by the value): an exclusive group unchecks the others, the value follows."""
        if self._syncing:
            return
        if self.exclusive and box.checked:
            self._syncing = True
            try:
                for other in self.members:
                    if other is not box:
                        other.checked = False
            finally:
                self._syncing = False
        values = [member.group_value for member in self.members if member.checked]
        if self.exclusive:
            self.value = values[0] if values else None
        else:
            self.value = frozenset(values)

    def property_changed(self, name: str) -> None:
        """The value set: the members checked by it (a value of no member is an error)."""
        if name == 'value':
            values = {member.group_value for member in self.members}
            chosen = (self.value,) if self.exclusive else self.value
            if unknown := [value for value in chosen if value is not None and value not in values]:
                raise ValueError(f'{self!r}: no member of the value(s) {unknown!r}')
            self._syncing = True
            try:
                for member in self.members:
                    member.checked = member.group_value in chosen
            finally:
                self._syncing = False
        super().property_changed(name)

    def apply_property(self, name: str) -> None:
        """Nothing: no control (the members show the value)."""
