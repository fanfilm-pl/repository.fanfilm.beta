"""
The page of debrid services of the configuration window (`resources/skins/widgets/debrid.xml`): the debrids of ResolveURL in
their priority order (up, down) and the panel of the debrid of the list (its account: authorize, revoke, active, the settings of
ResolveURL). ResolveURL keeps the accounts; the page shows them and changes them at once by the operations of the debrids
(`lib.windows.debrid`). The account info (the user, the end of premium) is asked from the services in a thread
while the window is open (it keeps the page, the page keeps the window weakly).
"""

from __future__ import annotations
from functools import partial
from threading import RLock
from typing import Any, TYPE_CHECKING
from .tabs import TabPage
from ..debrid import (CONTROL_ACTIONS, DebridListRow, DebridPanel, action_account, ask_infos_in_thread, debrid_layout, panel_of, run_action,
                      run_switch)
from ...ff import debrid
from ...kolang import L
if TYPE_CHECKING:
    from .views import ListView
    from ..debrid import DebridAccount, DebridActionName, DebridInfo, DebridLayout

#: The actions of the buttons (the names of their widgets).
BUTTONS: tuple[DebridActionName, ...] = tuple(action for action in CONTROL_ACTIONS if action != 'active')
#: The actions of the buttons of a text (the others: icons).
TEXT_BUTTONS: tuple[DebridActionName, ...] = ('authorize', 'revoke', 'settings')


class DebridPage(TabPage):
    """The page of debrid services."""

    WIDGET = 'debrid_page'
    DEFAULT = 'list'
    TOP = 'active'  # the top of the panel (its moves up go to "Close")
    BOTTOM = 'allowed'

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The structure of the page (`debrid_layout()`: the sizes, the texts)."""
        return {'DEBRID_LAYOUT': debrid_layout()}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        #: The debrids in their priority order.
        self.accounts: list[DebridAccount] = []
        #: The account info by the debrid name (asked in the background).
        self.infos: dict[str, DebridInfo | None] = {}
        #: The panel of the debrid of the list.
        self.panel: DebridPanel = DebridPanel()
        #: True if ResolveURL uses the debrid services.
        self.allowed: bool = False
        #: The structure of the page (its texts).
        self.layout: DebridLayout = debrid_layout()
        self._showing: bool = False  # the page sets the list (not the user)
        self._lock: RLock = RLock()  # the page is shown by the window and by the thread of the account info

    @property
    def list_view(self) -> ListView:
        """Return the list of the debrids."""
        return self.find('list')  # type: ignore[return-value]

    def built(self) -> None:
        """The buttons and the switches connected, the help of the list and of "Use debrid services", the text of "Active" (grayed when disabled)."""
        self.find('active').text = self.layout.active_label  # type: ignore[attr-defined]
        self.list_view.help = L(30743, 'The debrid services of ResolveURL in their order: the order is the priority, the first one opens a source first.')
        self.find('allowed').help = L(30744, 'ResolveURL uses the debrid services (off: none opens a source, the accounts stay).')
        for action in BUTTONS:
            self.find(action).clicked.connect(partial(self.run, action))
        for name in ('active', 'allowed'):
            self.find(name).toggled.connect(partial(run_switch, self, name))  # type: ignore[attr-defined]

    def show(self, changes: int) -> None:
        """The page is shown: filled the first time, else shown again (every time: ResolveURL may have changed)."""
        first, self.refreshed = self.refreshed is None, changes
        if first:
            self.fill()
        else:
            self.refresh()

    def fill(self) -> None:
        """Fill the list and the panel (the controls exist now), ask the account info in the background."""
        self.show_debrids()
        self.ask_infos()

    def refresh(self) -> None:
        """The state again (ResolveURL may have changed)."""
        self.show_debrids(select=self.panel.account.name if self.panel.account else None)

    def run(self, action: DebridActionName) -> None:
        """A button: its action on the debrid of the panel (a grayed one does nothing; the settings need no debrid)."""
        acc = None if action == 'settings' else action_account(self.panel, action)
        if action == 'settings' or acc is not None:
            run_action(self, action, acc)

    def ask_infos(self) -> None:
        """Ask the account info of the authorized debrids in a thread, show each one."""
        ask_infos_in_thread(self, self.show_info)

    # --- the view ---

    def show_info(self, name: str) -> None:
        """Show the account info of a debrid asked in the background (its row, the panel): only while the window is open."""
        with self._lock:
            if self.win.wait_ready(0) and any(acc.name == name for acc in self.accounts):
                self._show_rows()
                self._show_panel()

    def show_debrids(self, *, select: str | None = None) -> None:
        """Show the debrids again (after a change) with the debrid `select` (else the same place in the list)."""
        with self._lock:
            self.accounts = debrid.debrid_accounts()
            self.allowed = debrid.debrids_allowed()
            index = self.list_view.current
            if select is not None:
                index = next((i for i, acc in enumerate(self.accounts) if acc.name == select), index)
            self._show_rows(index)
            self._show_panel()

    def _show_rows(self, index: int | None = None) -> None:
        """Show the rows of the list with the row `index` selected (None: the same one; under the lock)."""
        view = self.list_view
        self._showing = True
        try:
            view.rows = [DebridListRow.of(acc, self.infos.get(acc.name), self.allowed) for acc in self.accounts]
            view.current = max(0, min(view.current if index is None else index, len(self.accounts) - 1))
        finally:
            self._showing = False

    def show_panel(self) -> None:
        """Show the panel of the debrid selected in the list."""
        with self._lock:
            self._show_panel()

    def _show_panel(self) -> None:
        """Show the panel of the debrid selected in the list (under the lock)."""
        current = self.list_view.current
        acc = self.accounts[current] if 0 <= current < len(self.accounts) else None
        self.panel = panel = panel_of(acc, self.infos.get(acc.name), current, len(self.accounts), self.allowed) if acc else DebridPanel()
        self.find('none').visible = acc is None
        self.find('title').text = panel.title  # type: ignore[attr-defined]
        self.find('info').text = panel.info  # type: ignore[attr-defined]
        self.find('summary').text = panel.summary  # type: ignore[attr-defined]
        for action in CONTROL_ACTIONS:
            widget = self.find(action)
            view = panel.actions.get(action)
            available = view is not None and view.available
            widget.help = view.help if view is not None else ''
            widget.reason = '' if available else widget.help
            widget.enabled = available
            if action in TEXT_BUTTONS:
                widget.text = view.label if view is not None else ''  # type: ignore[attr-defined]
        self.find('active').checked = acc is not None and acc.active  # type: ignore[attr-defined]
        self.find('allowed').checked = self.allowed  # type: ignore[attr-defined]
        self.win.on_focus(self.win.focused_id())  # the help of the focused control may have changed

    # --- events ---

    def on_list_current_changed(self, index: int) -> None:
        """A move in the list shows the panel of the new debrid."""
        if not self._showing:
            self.show_panel()
