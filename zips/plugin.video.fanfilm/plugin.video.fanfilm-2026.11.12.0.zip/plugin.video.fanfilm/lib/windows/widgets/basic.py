"""
The basic widgets (`resources/skins/widgets/basic.xml`): a group, a text, a text box, an image, a text edit, a row of a form, a progress bar,
a slider, a spin box.
"""

from __future__ import annotations
from math import ceil
from time import monotonic
from typing import Any, Sequence, TYPE_CHECKING
from attrs import evolve, frozen
from xbmcgui import (
    ACTION_MOUSE_DRAG, ACTION_MOUSE_DRAG_END, ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_WHEEL_DOWN, ACTION_MOUSE_WHEEL_UP, ACTION_MOVE_DOWN, ACTION_MOVE_LEFT,
    ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_PAGE_DOWN, ACTION_PAGE_UP, ACTION_SELECT_ITEM,
)
from . import Property, Widget, gray_text
from .views import PopupWidget
from ..base import CANCEL_ACTIONS, number_button
from ..geom import Point, Rect, Size
from ..gui import BoxTexture, TextureName, box_texture, media_textures, window_texture
from ..scale import Scale, Tick
from ..style import tokens
from ...ff.logs import fflog
from ...ff.signals import ClassSignal
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action, ControlImage, ControlLabel, ControlProgress, ControlSlider


class Label(Widget):
    """
    A text; a text of Python (`text`) is gray while the label is disabled (`shown_text()`), an empty one shows the text of the
    template again. A label has no focus: no Kodi state of it (a disabled Kodi label draws its `disabledcolor` only, no colors of its text).
    """

    #: The value: the text.
    VALUE = 'text'

    #: The text (empty: the one of the template).
    text: Property[str] = Property('')

    def shown_text(self) -> str:
        """Return the text as Kodi shows it: the one of Python (grayed if the label is disabled), else the one of the template."""
        return gray_text(self.text, self.enabled) or self.template_value('text')

    def apply_property(self, name: str) -> None:
        """Apply the text (also its gray look) to the Kodi label."""
        if name in ('text', 'enabled'):
            label: ControlLabel | None = self.control()  # type: ignore[assignment]
            if label is not None and (name == 'text' or self.text):
                label.setLabel(self.shown_text())
        elif name != 'reason':
            super().apply_property(name)


class TextBox(Widget):
    """A text box (Qt: QTextBrowser, read only): its text broken into lines, scrolled by Kodi."""

    #: The value: the text.
    VALUE = 'text'

    #: The text (empty: the one of the template).
    text: Property[str] = Property('')

    def apply_window_property(self, name: str) -> None:
        """Apply the text of the window property of the template (no text there)."""
        if name == 'text' and self.window_text:
            self.win.setProperty(f'ffw.{self.id}.text', self.text)  # type: ignore[attr-defined]

    def apply_property(self, name: str) -> None:
        """Apply the text: the window property of the template (no text there), else the text of the Kodi text box."""
        if name == 'text':
            self.apply_window_property(name)
            if not self.window_text and (box := self.control()) is not None:
                box.setText(self.text or self.template_value('text'))  # type: ignore[attr-defined]
        else:
            super().apply_property(name)


class Image(Widget):
    """An image."""

    #: The texture (empty: the one of the template).
    texture: Property[str] = Property('')
    #: The diffuse color (empty: the one of the template).
    color: Property[str] = Property('')

    def apply_property(self, name: str) -> None:
        """Apply the texture (its full path, of an active theme which has it: `window_texture()`) / the color to the Kodi image."""
        if name in ('texture', 'color'):
            image: ControlImage | None = self.control()  # type: ignore[assignment]
            if image is not None:
                if name == 'texture':
                    image.setImage(window_texture(self.texture or self.template_value('texture')))
                else:
                    image.setColorDiffuse(self.color or self.template_value('color') or tokens().color.image)  # Kodi: '' is transparent
        else:
            super().apply_property(name)


class FormField(Widget):
    """
    A row of a form (`form_field`, Qt: a row of QFormLayout): its field (`field`: a text edit, a combo box) and the mark "modified"
    shown while the row is modified (`modified`: the window property `ffw.<id>.modified`, shown with the first frame of the window).
    """

    #: The value of the row differs from its default: the mark "modified" shown.
    modified: Property[bool] = Property(False)

    @property
    def field(self) -> Widget:
        """Return the field of the row: its one child widget."""
        return next(iter(self.children.values()))

    def apply_window_property(self, name: str) -> None:
        """Apply the mark "modified" (the window property of the widget: the controls may not exist yet)."""
        if name == 'modified':
            self.win.setProperty(f'ffw.{self.id}.modified', 'true' if self.modified else '')  # type: ignore[attr-defined]

    def apply_property(self, name: str) -> None:
        """Apply the mark "modified" (its window property), the other properties to the controls."""
        if name == 'modified':
            self.apply_window_property(name)
        else:
            super().apply_property(name)


class ProgressBar(Widget):
    """A progress bar."""

    #: The value: the percent.
    VALUE = 'percent'

    #: The percent (0 - 100).
    percent: Property[int] = Property(0)

    def apply_property(self, name: str) -> None:
        """Apply the percent to the Kodi progress control."""
        if name == 'percent':
            progress: ControlProgress | None = self.control()  # type: ignore[assignment]
            if progress is not None:
                progress.setPercent(self.percent)
        else:
            super().apply_property(name)


#: The orientations of a slider.
SLIDER_ORIENTATIONS: tuple[str, ...] = ('horizontal', 'vertical')
#: The places of the value label of a slider: '' none, `end` after its end (right / under it), `knob` beside its knob (moved with it).
SLIDER_LABELS: tuple[str, ...] = ('', 'end', 'knob')
#: The modes of a slider (its knobs and its fill; the ends by the scale, not by the screen): `max` - the knob is the upper bound (the fill from
#: the minimum end or from the origin to it), `min` - the knob is the lower bound (the fill from it to the maximum end or to the origin),
#: `value` - the value alone (no fill), `range` - two knobs (the minimum one, the maximum one; the value a pair), the fill between them.
SLIDER_MODES: tuple[str, ...] = ('max', 'min', 'value', 'range')


def switch_texture(look: str, scale: Scale, height: float = 0) -> BoxTexture:
    """
    Return the textures of a switch of the look (a slider `look`: `dialogs/<look>.<position>.f<focused>.<parts>.png`, `box_texture()` with a
    frame - the knob on the left, its frame stretched under the text) for the positions of the scale (their state words `1`, `2` ...);
    a missing file of a position is an error, a file of a position past the scale too (a family of textures for each count of positions).
    """
    count = scale.last + 1
    textures = box_texture(look, frame=True, height=height, states=tuple(str(pos + 1) for pos in range(count)))
    if any(tex.name == textures.name(str(count + 1), 0) for tex in media_textures(TextureName.parse(look).base.rpartition('/')[0])):
        raise ValueError(f'The textures of the look {look!r} have more positions than the scale ({count})')
    return textures


@frozen(kw_only=True)
class SliderVars:
    """
    The template data of a slider (`Slider.template_slider()`): its band (the track and the knobs along its length, the focus ring around),
    its ticks, its labels; the places along (left - right, top - bottom) and across, a vertical one turned by `rect()`.
    """

    #: The slider is vertical (the maximum at the top), else horizontal (the maximum on the right).
    vertical: bool
    #: The maximum at the other end (on the left, at the bottom).
    inverted: bool
    #: The length of the band (the track; the knob moves along it).
    length: int
    #: The band across (the focus ring: the knob and a pad on both sides of it); the centre of the knob stays half of it from the ends.
    across: int
    #: The knob with the focus (without it: smaller, `small`; edited: its halo, `halo`).
    knob: int
    #: The track across (in the middle of the band).
    track: int
    #: The place of the band across in the widget.
    band: int
    #: The side of the ticks (N / S horizontal, W / E vertical; '' none).
    ticks: str
    #: The ticks of the scale of the template (none: no ticks, a scale of Python).
    marks: tuple[Tick, ...]
    #: The place of the labels of the major ticks across (the side of the ticks, beyond them).
    tick_label: int
    #: A label of a tick across (horizontal: its line, vertical: the widest one).
    tick_room: int
    #: A label of a tick along, centred on its tick (horizontal: the widest one, vertical: its line).
    tick_span: int
    #: The value label (`SLIDER_LABELS`).
    label: str
    #: The size of the value label: horizontal its width, vertical its line.
    text_width: int
    #: The line of the value label.
    text_line: int
    #: The value label beside the knob: its place across from the knob (before it: negative).
    label_at: int
    #: The positions of the knobs at the value of the template (the knobs and the fill placed there by the template).
    positions: tuple[int, ...]
    #: The last position of the scale of the template (0: none).
    last: int
    #: The fill from the value of its origin instead of an end of the scale (a two-sided scale: from 0; modes `max`, `min`), None from the end.
    origin: Any
    #: The mode (`SLIDER_MODES`).
    mode: str
    #: The width of the slider.
    width: int = 0
    #: The height of the slider.
    height: int = 0
    #: The slider is on a card of a field (`popup`): where the field lies (`widget_place()`: fixed, grouplist, row), '' in place.
    popup: str = ''
    #: The start of the band along (and its room after the end): half the label of a tick at an end of the scale beyond the end of the band.
    inset: int = 0
    #: A switch (`look`): the textures of its positions (`switch_texture()`; no band), None a slider.
    switch: BoxTexture | None = None

    @property
    def small(self) -> int:
        """Return the knob without the focus: two thirds of the knob (the same knob at rest; not under the track, not above the knob)."""
        return min(max(round(2 * self.knob / 3), self.track), self.knob)

    @property
    def halo(self) -> int:
        """Return the halo around the edited knob: twice the knob, within the band (the focus ring around it)."""
        return min(2 * self.knob, self.across)

    @property
    def switch_offset(self) -> int:
        """Return the knob of a switch along (the left border of its textures: their frame stretched under the text), 0 a slider."""
        return round(next(iter(TextureName.parse(self.switch.pattern).numbers('b')), 0)) if self.switch is not None else 0

    @property
    def knobs(self) -> tuple[str, ...]:
        """Return the names of the knobs (their groups in the widget): the only one or the minimum one of a range, the maximum one; a switch none."""
        if self.switch is not None:
            return ()
        return ('knob', 'knob_max') if self.mode == 'range' else ('knob',)

    def rect(self, along: float, across: float, along_size: float, across_size: float, *, local: bool = False) -> Rect:
        """
        Return the rectangle in the widget of a place along and across the band (a vertical slider: along is down; from the start of the band,
        `inset` - `local`: in a knob, from its start).
        """
        if not local:
            along += self.inset
        if self.vertical:
            return Rect(Point(round(across), round(along)), Size(round(across_size), round(along_size)))
        return Rect(Point(round(along), round(across)), Size(round(along_size), round(across_size)))

    def from_start(self, at: float) -> float:
        """Return the part of the length from the start (left / top) of a place of the scale (0 the first position .. 1 the last)."""
        return 1 - at if self.vertical != self.inverted else at

    def place(self, at: float) -> int:
        """Return the centre of the knob along the band at a place of the scale (half the band across from its ends)."""
        return round(self.across / 2 + self.from_start(at) * (self.length - self.across))

    def kodi_value(self, position: int, last: int) -> int:
        """Return the value of the Kodi slider of a position (Kodi: its maximum on the right / at the top) or back."""
        return last - position if self.inverted else position

    def spaced_labels(self, room: int) -> tuple[Tick, ...]:
        """
        Return the ticks without the labels too close to another one (their centres nearer than `room`): the ends first (the special
        values), then the rest in order; a tick of a label dropped is a minor one (short: no two long marks side by side).
        """
        labelled = [n for n, tick in enumerate(self.marks) if tick.label]
        kept: list[int] = []
        for n in (*labelled[:1], *labelled[-1:], *labelled[1:-1]):
            if n not in kept and all(abs(self.place(self.marks[n].at) - self.place(self.marks[k].at)) >= room for k in kept):
                kept.append(n)
        return tuple(tick if n in kept or not tick.label else evolve(tick, label='', major=False) for n, tick in enumerate(self.marks))

    def band_rect(self) -> Rect:
        """Return the band in the widget (the focus ring around it)."""
        return self.rect(0, self.band, self.length, self.across)

    def track_end(self, at: float) -> float:
        """Return the end of the track along at an end of the scale (0 the minimum one, 1 the maximum one): the centre of the knob there and its cap."""
        start = (self.across - self.track) / 2
        return start if self.from_start(at) == 0 else self.length - start

    def track_rect(self) -> Rect:
        """Return the track in the widget: the range of the centre of the knob and the caps (half the track) beyond, in the middle of the band."""
        start = (self.across - self.track) / 2
        return self.rect(start, self.band + start, self.length - 2 * start, self.track)

    def slider_rect(self) -> Rect:
        """Return the Kodi slider in the widget: the range of the centre of the knob (a click of the mouse is where the knob goes)."""
        return self.rect(self.across / 2, self.band, self.length - self.across, self.across)

    def knob_rect(self, position: int, last: int) -> Rect:
        """Return the knob (with the focus) in the widget at the position."""
        return self.rect(self.place(position / last if last else 0) - self.knob / 2, self.band + (self.across - self.knob) / 2, self.knob, self.knob)

    def in_knob(self, size: int) -> Rect:
        """Return an image of the knob of the size centred in the knob (its group): the knob without the focus, the halo."""
        offset = (self.knob - size) / 2
        return self.rect(offset, offset, size, size, local=True)

    def tick_rect(self, tick: Tick, size: int, pen: int) -> Rect:
        """Return the mark of the tick in the widget: `size` long from the band on the side of the ticks, `pen` wide."""
        return self.rect(self.place(tick.at) - pen / 2, self.band - size if self.ticks in ('N', 'W') else self.band + self.across, pen, size)

    def tick_label_rect(self, tick: Tick) -> Rect:
        """
        Return the label of the tick in the widget: beyond the marks, centred on its tick - twice its widest one along (Kodi cuts a text of
        no room with an ellipsis: the text drawn wider than measured, a scaled GUI).
        """
        return self.rect(self.place(tick.at) - self.tick_span, self.tick_label, 2 * self.tick_span, self.tick_room)

    def end_label_rect(self, gap: int) -> Rect:
        """Return the value label after the band (`gap` after it): beside a horizontal band, under a vertical one (as wide as its text)."""
        if self.vertical:
            return self.rect(self.length + gap, self.band + (self.across - self.text_width) / 2, self.text_line, self.text_width)
        return self.rect(self.length + gap, self.band, self.text_width, self.across)

    def knob_label_rect(self) -> Rect:
        """Return the value label beside the knob in the knob (its group): over / under it, on the left / the right of it."""
        if self.vertical:
            return self.rect((self.knob - self.text_line) / 2, self.label_at, self.text_line, self.text_width, local=True)
        return self.rect((self.knob - self.text_width) / 2, self.label_at, self.text_width, self.text_line, local=True)

    def fill_rect(self, positions: Sequence[int], last: int, origin: int | None) -> Rect:
        """
        Return the fill of the track in the widget at the positions of the knobs by the mode: between the knobs of a range, else from the
        knob to its fixed bound - the origin position, None: the end of the scale (`max`: the minimum one, `min`: the maximum one).
        """
        one = self.place(positions[0] / last if last else 0)
        if self.mode == 'range':
            other: float = self.place(positions[1] / last if last else 0)
        elif origin is not None:
            other = self.place(origin / last if last else 0)
        else:
            other = self.track_end(1 if self.mode == 'min' else 0)
        return self.rect(min(one, other), self.band + (self.across - self.track) / 2, abs(other - one), self.track)


#: The moves of the keys and their Kodi actions (a move across the editing control leaves it: the same move again from the widget control).
MOVES: dict[int, str] = {ACTION_MOVE_LEFT: 'Left', ACTION_MOVE_RIGHT: 'Right', ACTION_MOVE_UP: 'Up', ACTION_MOVE_DOWN: 'Down'}
#: The actions of the mouse which end its move (`committed` with them, also while editing): a click, a notch of the wheel, the end of a drag.
MOUSE_DONE: tuple[int, ...] = (ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_WHEEL_UP, ACTION_MOUSE_WHEEL_DOWN, ACTION_MOUSE_DRAG_END)


class ScaleWidget(Widget):
    """
    A widget of a value on a scale (`Scale`, `lib/windows/scale.py`): a slider, a spin box - the positions of its knobs (one; a range: two,
    the value a pair) and their moves. The value is the one of the scale (the same value at both ends: the position kept); a number off the
    steps is kept (the knob at the nearest position, its own text; a step from it goes to the next position that way - the nearest one
    first if it is that way); a value of no position (not a number) is logged and the position stays; another scale of Python: the value of
    the nearest position.

    Activated by OK (Qt: a keypad navigation of an editing focus): the widget control (a plain button) takes the focus of the keys, its
    arrows move as the ones of a button; OK starts the editing (`ffw.<id>.editing`: `EDITING` of the knob edited; the focus on the editing
    control `EDIT_CONTROL`, the arrows along change the value, Page up / down a big step - `Scale.page()`), OK ends it (a range: OK goes on
    to the maximum knob first), Back (the cancel keys) brings the value from before back and ends it, an arrow across ends it and moves on
    (the editing control moves to the widget control, the same move again from there); the digits type a number (each one within
    `const.tune.gui.number_typing_timeout` of the previous one: the same number; a numeric scale) at its nearest position at once, starting
    the editing. The focus on the editing control (the mouse over it) is the editing too: the keys there step without a commit each. The
    mouse acts at once (a click, a drag, a notch of the wheel: one position). All the keys here (`handle_action()`, `handle_focus()`). A move
    of the user: `changed`; the end of the editing (OK, an arrow across, the focus out), a move of the mouse: `committed`.
    """

    #: The value: the value of the scale (a range: the pair of its knobs).
    VALUE = 'value'
    #: The control of the editing: the arrows along it change the value, the ones across lead to the widget control.
    EDIT_CONTROL = 'edit'
    #: The value of the window property `ffw.<id>.editing` by the knob edited (the only one or the minimum one of a range, the maximum one).
    EDITING: tuple[str, ...] = ('true', 'max')

    #: The value (a value of the scale, a range: a pair of them - the minimum, the maximum; None: the one of the template).
    value: Property[Any] = Property(None)
    #: The scale (None: the one of the template).
    scale: Property[Scale | None] = Property(None)

    #: The user moved the value: the value (every step).
    changed: ClassSignal = ClassSignal()
    #: The user is done moving the value (the end of the editing, a move of the mouse): the value.
    committed: ClassSignal = ClassSignal()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The widget at the first position (the one of the template value: `built()`), not edited."""
        super().__init__(*args, **kwargs)
        #: The positions of the knobs (a range: the minimum one, the maximum one).
        self._positions: list[int] = [0]
        #: The knob the keys move (its index in the positions).
        self._knob: int = 0
        #: The user moved the value since the last `committed`.
        self._moved: bool = False
        #: The user moved the value since the last `changed`.
        self._unsent: bool = False
        #: The value is edited (OK, a digit, the focus on the editing control): the keys change it.
        self._editing: bool = False
        #: The positions before the editing (Back brings them back).
        self._edit_from: tuple[int, ...] = (0,)
        #: The editing control was left by a move across: the move again from the widget control (its next action).
        self._move_on: bool = False
        #: The digits typed (the number of the last ones within the timeout).
        self._typed: str = ''
        #: The time of the last digit typed.
        self._typed_at: float = 0.0

    @property
    def _position(self) -> int:
        """Return the position of the knob the keys move."""
        return self._positions[self._knob]

    def is_range(self) -> bool:
        """Return True for a range: two knobs, the value a pair."""
        return False

    def shown_scale(self) -> Scale | None:
        """Return the scale: of Python, else of the template (None: none yet)."""
        return self.scale or self.template_value('scale') or None

    def built(self) -> None:
        """The positions and the value of the template (None: the first position; a range: the whole scale)."""
        super().built()
        scale = self.shown_scale()
        if self.is_range():
            self._positions = [0, 0 if scale is None else scale.last]
        if scale is not None:
            value = self.template_value('value')
            if value is not None and value != '':
                self._positions = self._positions_of(value)
            if self.value is None:
                self.value = self._value_of(scale, self._positions)

    def _value_of(self, scale: Scale, positions: Sequence[int]) -> Any:
        """Return the value of the positions: the one of the knob, a range: the pair."""
        if self.is_range():
            return tuple(scale.value_at(pos) for pos in positions)
        return scale.value_at(positions[0])

    def _positions_of(self, value: Any) -> list[int]:
        """
        Return the positions of the value: the current ones if they have the value (the same value at both ends), a value of none (logged):
        the current ones.
        """
        if (scale := self.shown_scale()) is None or value is None:
            return self._positions
        current = [min(pos, scale.last) for pos in self._positions]
        try:
            if self.is_range():
                value = tuple(value)
                return current if self._value_of(scale, current) == value else list(scale.range_positions(*value))
            return current if self._value_of(scale, current) == value else [scale.position_of(value)]
        except (TypeError, ValueError) as exc:
            fflog(f'[{type(self).__name__.upper()}] {self.path}: {exc}, the position stays')
            return current

    def property_changed(self, name: str) -> None:
        """The value, the scale: the positions of the value; another scale: the value of the positions (the nearest ones)."""
        if name in ('value', 'scale'):
            self._positions = self._positions_of(self.value)
        super().property_changed(name)
        if name == 'scale' and (scale := self.shown_scale()) is not None and (value := self._value_of(scale, self._positions)) != self.value:
            self.value = value

    def value_text(self) -> str:
        """
        Return the text of the value (`Scale.text()`, a number off the steps: `Scale.number_text()`, a range: `Scale.range_text()`; '' no
        scale), e.g. for a row the widget edits.
        """
        if (scale := self.shown_scale()) is None:
            return ''
        if self.is_range():
            return scale.range_text(*self._positions)
        if self._off_step(scale):
            return scale.number_text(self.value)
        return scale.text(self._position)

    def _off_step(self, scale: Scale) -> bool:
        """Return True for a number (one knob) off the steps of the scale: not the number of its position (the nearest one)."""
        if self.is_range():
            return False
        value, shown = self.value, scale.value_at(self._position)
        return all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (value, shown)) and value != shown

    def apply_window_property(self, name: str) -> None:
        """The text of the value (the window property `ffw.<id>.text`: shown with the first frame)."""
        if name in ('value', 'scale') and self.shown_scale() is not None:
            self.win.setProperty(f'ffw.{self.id}.text', self.value_text())  # type: ignore[attr-defined]

    def apply_property(self, name: str) -> None:
        """The value, the scale: the text of the value, the controls of the positions (`place()`); enabled: the editing control too."""
        if name in ('value', 'scale'):
            self.apply_window_property(name)
            self.place()
        else:
            super().apply_property(name)
            if name in ('enabled', 'reason'):
                self.win.set_control_enabled(self.control_id(self.EDIT_CONTROL), self.enabled)

    def place(self) -> None:
        """Show the positions by the controls of the widget (besides its window properties)."""

    def move(self, position: int, *, push: bool = True) -> None:
        """
        Move the knob of the keys to the position (kept in its positions: a range - it pushes the other knob on, not `push`: not past it) as the
        user does (`changed`); a step from a number off the steps goes to its own position if that is the way.
        """
        if (scale := self.shown_scale()) is None:
            return
        if self.is_range():
            allowed = scale.knob_positions('max' if self._knob else 'min', None if push else self._positions[1 - self._knob])
        else:
            allowed = range(scale.last + 1)
        off_step = self._off_step(scale)
        if off_step and abs(direction := position - self._position) == 1 and (scale.value_at(self._position) - self.value) * direction > 0:
            position = self._position  # a step from a number off the steps: the nearest position first if it is that way
        positions = list(self._positions)
        positions[self._knob] = min(max(position, allowed.start), allowed.stop - 1)
        if len(positions) > 1 and positions[0] > positions[1]:
            positions[1 - self._knob] = positions[self._knob]
        if positions == self._positions and not off_step:
            return
        self._positions = positions
        if (value := self._value_of(scale, positions)) == self.value:  # the same value at another position
            self.apply_property('value')
        else:
            self.value = value
        self._moved = self._unsent = True
        self.send_changed()

    def send_changed(self) -> None:
        """Tell the moves of the user since the last time: `changed`."""
        if self._unsent:
            self._unsent = False
            self.changed.emit(self.value)

    def step(self, direction: int) -> None:
        """Step to the next position in the direction (1 up, -1 down), none past the ends."""
        self.move(self._position + direction)

    def wheel(self, direction: int) -> None:
        """A notch of the mouse wheel (1 up, -1 down): a step."""
        self.step(direction)

    def type_digit(self, digit: int) -> bool:
        """
        A digit typed: the number of the digits typed within the timeout, its nearest position (the editing started). Return False for
        a scale of no numbers.
        """
        now = monotonic()
        if now - self._typed_at > const.tune.gui.number_typing_timeout:
            self._typed = ''
        self._typed, self._typed_at = f'{self._typed}{digit}', now
        if (scale := self.shown_scale()) is None:
            return False
        try:
            position = scale.position_of(int(self._typed))
        except ValueError:  # an enum
            return False
        self.start_edit()
        self.move(position, push=False)  # the first digit of a number is not its value: no knob pushed by it
        return True

    def commit(self) -> None:
        """The user is done moving the value: `committed` (once after moves)."""
        self.send_changed()
        if self._moved:
            self._moved = False
            self.committed.emit(self.value)

    def show_edit(self, editing: bool) -> None:
        """Show the editing control while the value is edited (the slider: always, the mouse acts there)."""

    def choose_knob(self, knob: int) -> None:
        """Make the knob the one of the keys (its index; while editing: `ffw.<id>.editing` tells it)."""
        self._knob = knob
        if self._editing:
            self.win.setProperty(f'ffw.{self.id}.editing', self.EDITING[knob])  # type: ignore[attr-defined]
        self.place()

    def start_edit(self) -> None:
        """Start the editing (the first knob): the focus on the editing control."""
        if self._editing:
            return
        self._editing, self._edit_from, self._moved = True, tuple(self._positions), False
        self.choose_knob(0)
        self.show_edit(True)
        if self.win.focused_id() != (cid := self.control_id(self.EDIT_CONTROL)):
            self.win.setFocusId(cid)  # type: ignore[attr-defined]

    def end_edit(self, *, cancel: bool = False, focus: bool = True) -> None:
        """End the editing: `committed` (cancel: the value from before back, no signal of the end), the focus on the widget control."""
        if not self._editing:
            return
        if cancel:
            if (scale := self.shown_scale()) is not None and self._positions != (before := list(self._edit_from)):
                self._positions = before
                self.value = self._value_of(scale, before)
                self.apply_property('value')  # the same value at another position
                self._unsent = True
                self.send_changed()
            self._moved = False
        self._editing = False
        self.win.setProperty(f'ffw.{self.id}.editing', '')  # type: ignore[attr-defined]
        self.choose_knob(0)
        if focus:
            self.win.setFocusId(self.id)  # type: ignore[attr-defined]
        self.show_edit(False)
        self.commit()

    def handle_focus(self, control_id: int) -> None:
        """
        The widget control got the focus while editing: the editing control was left by a move across - the end, the move again; the
        editing control got it (the mouse over it): the editing.
        """
        super().handle_focus(control_id)
        if control_id == self.id and self._editing:
            self.left_across()
        elif control_id == self.control_id(self.EDIT_CONTROL):
            self.start_edit()

    def left_across(self) -> None:
        """The editing control was left by a move across (to the widget control): the end of the editing, the move again from there."""
        self.end_edit(focus=False)
        self._move_on = True

    def handle_focus_out(self, control_id: int) -> None:
        """The focus went away: the end of the editing, `committed`."""
        self.end_edit(focus=False)
        self.commit()

    def handle_action(self, action: Action) -> bool | None:
        """
        The keys and the mouse of a scale widget (see the class); a move of the mouse is done with its action (a click, a notch of the
        wheel, the end of a drag: `MOUSE_DONE`; while editing too - the value from before of Back is the one after it), out of the editing
        with any other one but a drag: `committed`.
        """
        try:
            return self._action(action)
        finally:
            if (aid := action.getId()) in MOUSE_DONE or not self._editing and aid != ACTION_MOUSE_DRAG:
                self.commit()
                if self._editing:
                    self._edit_from = tuple(self._positions)

    def _action(self, action: Action) -> bool | None:
        """Handle the action (`handle_action()`)."""
        aid = action.getId()
        move_on, self._move_on = self._move_on, False
        if aid in (ACTION_MOUSE_WHEEL_UP, ACTION_MOUSE_WHEEL_DOWN):
            self.wheel(1 if aid == ACTION_MOUSE_WHEEL_UP else -1)
            return True
        if aid == ACTION_MOUSE_LEFT_CLICK:
            return self.mouse_click(self.win.focused_id())
        if (digit := number_button(action)) is not None:
            return self.type_digit(digit) or None
        if not self._editing:
            if move_on and aid in MOVES:  # the move across which left the editing control: again from the widget control
                from xbmc import executebuiltin
                executebuiltin(f'Action({MOVES[aid]})')
                return True
            if aid == ACTION_SELECT_ITEM:
                self.start_edit()
                return True
            return None
        if aid == ACTION_SELECT_ITEM:
            if self._knob + 1 < len(self._positions):  # a range: on to the maximum knob
                self.choose_knob(self._knob + 1)
            else:
                self.end_edit()
        elif aid in CANCEL_ACTIONS:
            self.end_edit(cancel=True)
        elif aid in (ACTION_PAGE_UP, ACTION_PAGE_DOWN):
            if (scale := self.shown_scale()) is not None:
                self.move(scale.page(self._position, 1 if aid == ACTION_PAGE_UP else -1))
        else:
            return None
        return True

    def mouse_click(self, control_id: int) -> bool | None:
        """A click of the mouse on the control (its own click came first). Return True if handled."""
        return None


class Slider(ScaleWidget, PopupWidget):
    """
    A slider (Qt: QSlider) on a scale (`ScaleWidget`): the widget control a plain button (the keys), the editing control a Kodi slider over
    it (the mouse) on the positions of the scale (`setInt(position, 0, 1, last)`; Kodi moves it by the arrows, the mouse and its wheel and
    tells each step by a click), the knobs and the fill drawn by FF (placed by Python, the ticks at the same places), the value label
    (`scale.text()`, a range: `scale.range_text()`). A range (`mode` range): the Kodi slider at the knob of the keys; a click or a drag of
    the mouse takes the knob nearer to it.

    In a field (`popup`, `PopupWidget`): the widget control is a field of the text of the value, the slider is on a card at it (the
    mechanism of the list of a combo box) - the editing (OK, a click of the mouse, a digit) opens the card, its end closes it (OK; a range:
    OK on the maximum knob; Back the value from before; a move across) with the focus back on the field (opened from outside, `open()`:
    on the control it came from); the focus out closes it too (`committed`). In a row of a list it edits the current row (`row`; the window
    gives its value at `about_to_show` or by `open()`, takes the new one at `committed`).

    A switch (`look`: a multi-position rotary switch, Qt: a QDial of a few notches): the image of its position (`ffw.<id>.state`,
    `switch_texture()`) instead of the band, the keys of a slider; a click of the mouse turns it to the next position.
    """

    #: The Kodi slider: the editing control.
    EDIT_CONTROL = 'slider'

    @classmethod
    def template_slider(cls, *, scale: Scale | None, orientation: str, inverted: bool, ticks: str, label: str, mode: str, origin: Any,
                        value: Any, width: int, height: int, track: int, popup: str = '', look: str = '') -> SliderVars:
        """
        Return the template data of a slider of the size (`width`, `height`; across 0: the least it needs): across - the ticks on their
        side (their marks, the labels of the major ones), the band (the focus ring: the knob `metric.slider.knob` and a pad, the track in
        its middle, `track` across - 0: `metric.slider.track`), the value label beside the knob on the other side (`knob`), all of them in
        the middle; along - the band, the value label after it (`end`); the knobs and the fill at the positions of the value (None: the
        first position, a range: the whole scale). The mode '': a numeric scale `max`, else (an enum) `value`. On a card of a field: `popup`
        (where the field lies). A switch (`look`, `switch_texture()`): the image of the position over the whole slider (its height 0: the
        one of the textures), no band.
        """
        from ..skinfonts import text_metrics
        if look:
            if scale is None or popup or mode not in ('', 'value'):
                raise ValueError(f'A switch {look!r} has the positions of the scale of its template, one value (mode value), no field (popup)')
            if not width:
                raise ValueError('A switch has no width (of its use or its parameters)')
            switch = switch_texture(look, scale, height)
            if not height and not (height := round(next(iter(TextureName.parse(switch.pattern).numbers('h')), 0))):
                raise ValueError(f'A switch {look!r} has no height (of its use, its parameters or its textures: the `h` part)')
            return SliderVars(vertical=False, inverted=inverted, length=width, across=height, knob=0, track=0, band=0, ticks='', marks=(),
                              tick_label=0, tick_room=0, tick_span=0, label=label, text_width=0, text_line=0, label_at=0,
                              positions=(0 if value is None else scale.position_of(value),), last=scale.last, origin=None, mode='value',
                              width=width, height=height, switch=switch)
        if orientation not in SLIDER_ORIENTATIONS:
            raise ValueError(f'Unknown orientation {orientation!r} of a slider (not one of {", ".join(SLIDER_ORIENTATIONS)})')
        vertical = orientation == 'vertical'
        if ticks and ticks not in ('WE' if vertical else 'NS'):
            raise ValueError(f'No ticks {ticks!r} of a {orientation} slider')
        if label not in SLIDER_LABELS:
            raise ValueError(f'Unknown value label {label!r} of a slider (not one of {", ".join(SLIDER_LABELS)})')
        mode = mode or ('max' if scale is None or scale.numeric else 'value')
        if mode not in SLIDER_MODES:
            raise ValueError(f'Unknown mode {mode!r} of a slider (not one of {", ".join(SLIDER_MODES)})')
        if mode == 'range' and label == 'knob':
            raise ValueError('A range has no value label at its knob (two knobs): end')
        along, across = (height, width) if vertical else (width, height)
        if not along:
            raise ValueError(f'A slider has no {"height" if vertical else "width"} (of its use or its parameters)')
        style = tokens()
        text_width, text_line = text_metrics('normal')
        texts = [scale.text(pos) for pos in range(scale.last + 1)] if scale is not None else []
        if mode == 'range' and scale is not None:  # the ranges of the widest value with every other one
            one = max(range(scale.last + 1), key=lambda pos: text_width(texts[pos]))
            pairs = (sorted((one, other)) for other in range(scale.last + 1))
            texts += [scale.range_text(low, high) for low, high in pairs if low in scale.knob_positions('min') and high in scale.knob_positions('max', low)]
        widest = ceil(max(map(text_width, texts))) if texts else style.metric.tag.width
        marks = scale.ticks() if scale is not None and ticks else ()
        tick_width, tick_line = text_metrics('tiny')
        labels = [tick.label for tick in marks if tick.label]
        widest_tick = ceil(max(map(tick_width, labels))) if labels else 0
        tick_room, tick_span = (widest_tick, round(tick_line)) if vertical else (round(tick_line), widest_tick)
        ends = [ceil(tick_line if vertical else tick_width(tick.label)) for tick in (marks[:1] + marks[-1:]) if tick.label and tick.at in (0, 1)]
        ticks_size = style.space.s + (style.space.xs + tick_room if labels else 0) if ticks else 0
        knob_label = (widest if vertical else round(text_line)) + style.space.xs if label == 'knob' else 0
        knob, track = style.metric.slider.knob, track or style.metric.slider.track
        band_across = max(knob, track) + 2 * style.space.xs
        overhang = max([0, *(size // 2 + size % 2 - band_across // 2 for size in ends)])  # an end label: its half beyond the centre of the knob there
        across = across or ticks_size + band_across + knob_label
        spare = across - ticks_size - band_across - knob_label
        end = (round(text_line) if vertical else widest) + style.space.m if label == 'end' else 0
        if spare < 0 or along - end - 2 * overhang <= band_across:
            raise ValueError(f'A slider of {width} x {height} has no room for its band')
        first = ticks in ('N', 'W')  # the ticks before the band, the knob label after it
        band = spare // 2 + (ticks_size if first else knob_label)
        inset = (band_across - knob) // 2  # the knob in the band
        if scale is None:
            positions: tuple[int, ...] = (0, 0) if mode == 'range' else (0,)
        elif mode == 'range':
            positions = (0, scale.last) if value is None else scale.range_positions(*value)
        else:
            positions = (0 if value is None else scale.position_of(value),)
        v = SliderVars(vertical=vertical, inverted=inverted, length=along - end - 2 * overhang, inset=overhang,
                       across=band_across, knob=knob, track=track, band=band,
                       ticks=ticks, marks=marks, tick_label=spare // 2 if first else band + band_across + style.space.s + style.space.xs,
                       tick_room=tick_room, tick_span=tick_span, label=label, text_width=widest, text_line=round(text_line),
                       label_at=band_across - inset + style.space.xs if first else -knob_label - inset, positions=positions,
                       last=scale.last if scale is not None else 0, origin=origin, mode=mode, width=across if vertical else along,
                       height=along if vertical else across, popup=popup)
        return evolve(v, marks=v.spaced_labels(tick_span + style.space.xs))  # the labels along: their widest one / their line apart

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """No click of the Kodi slider yet."""
        super().__init__(*args, **kwargs)
        #: The position of the last click of the Kodi slider, done with its action (`handle_action()`; None: none).
        self._clicked: int | None = None
        #: The mouse drags the knob (its first move took the nearer knob of a range).
        self._dragging: bool = False

    @property
    def vars(self) -> SliderVars:
        """Return the template data."""
        assert self.entry is not None
        return self.entry.data['slider']

    def is_range(self) -> bool:
        """Return True for the mode `range`."""
        return self.entry is not None and self.vars.mode == 'range'

    def apply_window_property(self, name: str) -> None:
        """A switch: the state word of its position too (`ffw.<id>.state`: the texture of the position, `switch_texture()`)."""
        super().apply_window_property(name)
        if name in ('value', 'scale') and self.entry is not None and self.vars.switch is not None:
            self.win.setProperty(f'ffw.{self.id}.state', str(self._position + 1))  # type: ignore[attr-defined]

    def place(self) -> None:
        """Set the Kodi slider (the knob of the keys), place the knobs and the fill at the positions."""
        if (scale := self.shown_scale()) is None:
            return
        v, last = self.vars, scale.last
        slider: ControlSlider | None = self.control(self.EDIT_CONTROL)  # type: ignore[assignment]
        if slider is not None:
            slider.setInt(v.kodi_value(self._position, last), 0, 1, last)
        for name, pos in zip(v.knobs, self._positions):
            if (knob := self.control(name)) is not None:
                place = v.knob_rect(pos, last)
                knob.setPosition(place.left, place.top)
        if v.mode != 'value' and (fill := self.control('fill')) is not None:
            origin = None if v.origin is None or v.mode == 'range' else self._origin(scale)
            place = v.fill_rect(self._positions, last, origin)
            fill.setPosition(place.left, place.top)
            fill.setWidth(place.size.width)
            fill.setHeight(place.size.height)
            fill.setVisible(bool(place))  # empty: hidden (Kodi draws a texture at least as large as its border)

    def _origin(self, scale: Scale) -> int | None:
        """Return the position of the origin of the fill (None: a value of no position, from the end)."""
        try:
            return scale.position_of(self.vars.origin)
        except ValueError as exc:
            fflog(f'[SLIDER] {self.path}: origin {exc}')
            return None

    def handle_click(self, control_id: int) -> bool | None:
        """
        A step of the Kodi slider (a key, the mouse): done with its action (`handle_action()`; a drag of the mouse from out of it, no
        focus: at once, `committed`); the widget control (OK): its action.
        """
        if control_id == self.id:
            return True
        if control_id != self.control_id(self.EDIT_CONTROL):
            return super().handle_click(control_id)
        slider: ControlSlider | None = self.control(self.EDIT_CONTROL)  # type: ignore[assignment]
        if (scale := self.shown_scale()) is not None and slider is not None:
            self._clicked = self.vars.kodi_value(slider.getInt(), scale.last)
            if self.win.focused_id() != control_id:  # a drag from out of it (no focus): its action goes elsewhere - the mouse now
                self.done_click(ACTION_MOUSE_LEFT_CLICK)
                self.commit()
        return True

    def done_click(self, aid: int) -> None:
        """
        The click of the Kodi slider done with its action (Kodi tells the click first) moved it: a notch of the wheel - one position from
        the knob the way Kodi went (Kodi moved it by 10: `Move(±10)`), a click or the first move of a drag of the mouse on a range - the
        nearer knob there, a click on a switch - its next position (a drag: none), else (a key, a drag) the knob of the keys there; one
        move, one `changed`.
        """
        if (clicked := self._clicked) is None:
            return
        self._clicked = None
        if aid in (ACTION_MOUSE_WHEEL_UP, ACTION_MOUSE_WHEEL_DOWN):
            clicked = self._position + (clicked > self._position) - (clicked < self._position)
        elif self.vars.switch is not None and aid in (ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_DRAG, ACTION_MOUSE_DRAG_END):
            # a switch: a click turns it to the next position (after the last one the first: the knob has no place of a click), no drag
            clicked = (self._position + 1) % (self.vars.last + 1) if aid == ACTION_MOUSE_LEFT_CLICK else self._position
        elif self.is_range() and (aid == ACTION_MOUSE_LEFT_CLICK or aid == ACTION_MOUSE_DRAG and not self._dragging):
            low, high = self._positions
            self.choose_knob(0 if clicked < low or clicked <= high and clicked - low <= high - clicked else 1)
        self.move(clicked)
        self.place()  # the Kodi slider at the knob (a knob of a range kept from the other one)

    def handle_action(self, action: Action) -> bool | None:
        """The click of the Kodi slider before the action: done with it (`done_click()`)."""
        aid = action.getId()
        self.done_click(aid)
        self._dragging = aid == ACTION_MOUSE_DRAG
        return super().handle_action(action)

    def wheel(self, direction: int) -> None:
        """A notch of the mouse wheel: the click of the Kodi slider before it moved the knob (`handle_action()`); none: Kodi did not move it."""

    # --- in a field: the card ---

    def popup_owns(self, control_id: int) -> bool:
        """Return True for the Kodi slider of the card (in a field)."""
        return bool(self.vars.popup) and control_id == self.control_id(self.EDIT_CONTROL)

    def open(self, value: Any = None) -> None:
        """
        Open the card of the field from outside it (e.g. OK on a row of its list: the value of the row, `value`; None: as the field shows
        it); the focus goes back to the control it came from when it closes.
        """
        if value is not None:
            self.value = value
        self.start_edit()

    def start_edit(self) -> None:
        """In a field: the card opens first (`popup_opening()`; in a row of a list: the row known first, its value given then)."""
        if self.vars.popup and not self._editing:
            if self.vars.popup == 'row':
                self.row = self.list_row()
            self.popup_opening()
        super().start_edit()

    def end_edit(self, *, cancel: bool = False, focus: bool = True) -> None:
        """In a field: the card closes, the focus back on the field (`focus`; opened from outside: on the control it came from)."""
        if not self.vars.popup or not self._editing:
            super().end_edit(cancel=cancel, focus=focus)
            return
        super().end_edit(cancel=cancel, focus=False)
        self.hide_popup(focus=focus)

    def left_across(self) -> None:
        """In a field: a move across the card leads to the field - the end of the editing there (opened from outside: the focus back)."""
        if not self.vars.popup:
            super().left_across()
            return
        self.end_edit(focus=bool(self._back))

    def handle_focus(self, control_id: int) -> None:
        """In a field: the card got the focus - shown by it from now on (`ffw.<id>.open` cleared: a hidden one takes no focus)."""
        super().handle_focus(control_id)
        if self.popup_owns(control_id):
            self._set_open(False)

    def mouse_click(self, control_id: int) -> bool | None:
        """In a field: a click of the mouse on the field opens the card (the editing)."""
        if not self.vars.popup or control_id != self.id:
            return None
        self.start_edit()
        return True


#: The type of a number of the Kodi number dialog (`Dialog().numeric()`; xbmcgui has no constant of it: Kodi's `ShowAndGetNumber`).
NUMERIC_NUMBER: int = 0


class SpinBox(ScaleWidget):
    """
    A spin box (Qt: QSpinBox) on a numeric scale (`ScaleWidget`; a scale of other values is an error: a combo box chooses one of them):
    a Kodi button of the text of the value (`scale.text()`) between the arrows ‹ › (buttons of the mouse, dimmed at the ends); the editing
    control a button of the same look over it, shown while editing (left / right send the clicks of the arrows: a step, no wrap, Kodi keeps
    the focus). A click of the mouse on the text: the Kodi number dialog of the value, the nearest position of the number.
    """

    #: The looks of its button (the template parameter `look`): a field of a form, a push button.
    LOOKS: tuple[str, ...] = ('field', 'button')

    #: The heading of the number dialog ('' the one of the template, else the range of the scale).
    heading: Property[str] = Property('')

    @staticmethod
    def check_scale(scale: Scale | None) -> None:
        """Raise ValueError for a scale of values which are no numbers (an enum)."""
        if scale is not None and not scale.numeric:
            raise ValueError(f'A spin box of a scale of no numbers {scale.values!r}: use a combo box')

    def property_changed(self, name: str) -> None:
        """A scale of Python: a numeric one."""
        if name == 'scale':
            self.check_scale(self.scale)
        super().property_changed(name)

    def apply(self) -> None:
        """The editing control hidden (shown while editing)."""
        super().apply()
        self.show_edit(self._editing)

    def apply_window_property(self, name: str) -> None:
        """The text of the value, the arrows which step (`ffw.<id>.less`, `ffw.<id>.more`: not at the ends)."""
        super().apply_window_property(name)
        if name in ('value', 'scale') and (scale := self.shown_scale()) is not None:
            self.win.setProperty(f'ffw.{self.id}.less', 'true' if self._position > 0 else '')  # type: ignore[attr-defined]
            self.win.setProperty(f'ffw.{self.id}.more', 'true' if self._position < scale.last else '')  # type: ignore[attr-defined]

    def show_edit(self, editing: bool) -> None:
        """Show the editing control while editing (Python: shown at once, focusable; no visibility condition of Kodi)."""
        if (edit := self.control(self.EDIT_CONTROL)) is not None:
            edit.setVisible(editing)

    def enter_number(self) -> None:
        """The Kodi number dialog of the value (a whole number, else empty): the nearest position of the number."""
        from xbmcgui import Dialog
        if (scale := self.shown_scale()) is None:
            return
        value = self.value if isinstance(self.value, int) and self.value >= 0 else ''
        heading = self.heading or self.template_value('heading') or f'{scale.text(0)} – {scale.text(scale.last)}'  # Kodi: no heading, no dialog
        if (text := Dialog().numeric(NUMERIC_NUMBER, heading, str(value))).isdecimal():
            self.move(scale.position_of(int(text)))

    def mouse_click(self, control_id: int) -> bool | None:
        """A click of the mouse on the text (the widget control, the editing one): the number dialog."""
        if control_id not in (self.id, self.control_id(self.EDIT_CONTROL)):
            return None
        self.enter_number()
        return True

    def handle_click(self, control_id: int) -> bool | None:
        """An arrow (the mouse, left / right of the editing control): a step; the text (OK, the mouse): its action."""
        if control_id in (self.id, self.control_id(self.EDIT_CONTROL)):
            return True
        if control_id in (less := self.control_id('less'), self.control_id('more')):
            self.step(-1 if control_id == less else 1)
            return True
        return super().handle_click(control_id)
