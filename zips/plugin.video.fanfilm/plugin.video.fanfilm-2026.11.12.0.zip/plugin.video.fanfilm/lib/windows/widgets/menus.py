"""
The page of the menus of the configuration window: the fixed entries of the menus of folders in a tree (the logic of the menus:
`lib.windows.menus.MenusTabLogic`), a row shown / hidden (its check), moved up / down in its menu (the buttons of the row),
the default order of a menu (the context menu of a row); every change is written at once.
"""

from __future__ import annotations
from typing import Any, Sequence, TYPE_CHECKING
from .tree_page import TreePage
from .views import TreeView
from ..config_dialog import page_rows
from ..menus import ROW_BUTTONS, WIDTH, MenusTabLogic
from ..tree import tree_row_height
from ...kolang import L
if TYPE_CHECKING:
    from ...ff.item import FFItem


class MenusPage(MenusTabLogic, TreePage):
    """The page of the menus (its title and its defaults: `MenusTabLogic`)."""

    WIDGET = 'menus_page'

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The size of the tree (the rows at once: whole rows of the page under its hint), the buttons of a row."""
        return {'MENUS_WIDTH': WIDTH, 'MENUS_ROWS': page_rows(tree_row_height(False), TreeView.HEADER), 'MENUS_BUTTONS': ROW_BUTTONS}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        self.init_logic()

    def built(self) -> None:
        """The hint of the tree."""
        self.tree.hint = L(30194, 'OK: show / hide, right: the buttons of the row')

    def fill(self) -> None:
        """Show the entries (the controls exist now; the tree as it was left)."""
        self.tree.set_model(self.load(), extra_menu=self.extra_menu)

    def refresh(self) -> None:
        """Read the entries again (the defaults restored, another page changed them)."""
        self.reload()

    def on_tree_checked_changed(self, items: Sequence[FFItem]) -> None:
        """Entries shown / hidden (written at once)."""
        self.checked(items)

    def on_tree_moved(self, item: FFItem) -> None:
        """An entry moved (written at once)."""
        self.moved(item)

    def help_of(self, control_id: int) -> str:
        """Return the help of the tree or of a button of the selected row."""
        return self.tree_help(control_id) if self.view.owns(control_id) else ''
