"""
The page of the settings of the sources of the configuration window (`resources/skins/widgets/source_settings.xml`): the groups of
`SOURCE_SETTINGS` in their frames (a group box: its title, its list of settings - `setting_list`) in two columns, every value in
view; a setting is written at once (`lib.sources.source_settings`).
"""

from __future__ import annotations
from functools import partial
from typing import Any, Callable, TYPE_CHECKING
from attrs import evolve, frozen
from .setting_list import SettingList, SettingRow
from .tabs import TabPage
from ...kolang import L
from ...sources.source_settings import (SEARCH_END_SETTING, SOURCE_SETTINGS, SOURCE_SETTINGS_CONFIG, SEPARATE_SETTING, SIMPLE_SETTING, SettingGroup, set_source_setting,
                                         setting_reason,
                                         source_setting)
if TYPE_CHECKING:
    from ...ff.source_filters import SelectionMedia
    from ...sources.natives import CatalogSetting


def edit_selection(media: SelectionMedia) -> None:
    """Edit the filter and the sort of the sources of the media (imported here: the window of them only when opened)."""
    from ..source_filters_dialog import SourceFiltersDialog
    SourceFiltersDialog(media=media).doModal()


def shown_groups() -> tuple[SettingGroup, ...]:
    """Return the groups of the settings as the page shows them: the row of the shows only with their own selection, one time of the search in the simple view."""
    separate = source_setting(SEPARATE_SETTING)
    simple = simple_view_shown()
    return tuple(evolve(group, settings=tuple(SEARCH_END_SETTING if simple and setting['key'] == 'search_timeout' else setting
                                              for setting in group.settings if separate or setting['key'] != 'selection_show'))
                 for group in SOURCE_SETTINGS)


def simple_view_shown() -> bool:
    """Return the switch of the simple view: on when every selection of its own is shown by it (a filter it can not show: the advanced one)."""
    from ...ff.source_filters import selection_medias, simple_view
    return all(simple_view(media) for media in selection_medias())


def set_simple_view(value: bool) -> None:
    """Switch the simple view: on with a filter it can not show: asked what would go (kept in a set), no answer: nothing."""
    from ...ff.control import yesnoDialog
    from ...ff.source_filters import selection_medias, simple_loss, simplify
    if value:
        losses = {media: loss for media in selection_medias() if (loss := simple_loss(media))}
        name = L(30975, 'Before the simple view')
        what = ', '.join(sorted({label for loss in losses.values() for label in loss}))
        question = L(30976, 'The simple view can not show: {what}. They go, your settings are kept in the set "{name}". Switch to it?', what=what, name=name)
        if losses and not yesnoDialog(question,
                                      heading=L(30951, 'Filters and sort')):
            return
        for media in losses:
            simplify(media, name if len(selection_medias()) == 1 else f'{name} ({media})')
    set_source_setting(SIMPLE_SETTING, value)


def search_end() -> float:
    """Return the end of the search (the row of the simple view)."""
    return source_setting('search_timeout')[1]


def set_search_end(end: float) -> None:
    """Set the end of the search (the time of the list of the advanced view stays, not past the end)."""
    set_source_setting('search_timeout', [min(source_setting('search_timeout')[0], end), end])


@frozen
class RowValue:
    """The value of a row which is not the setting of its key."""

    #: The value of the row.
    get: Callable[[], Any]
    #: Write the value of the row.
    set: Callable[[Any], None]


#: The values of the rows which are not the settings of their keys.
ROW_VALUES: dict[str, RowValue] = {SIMPLE_SETTING: RowValue(get=simple_view_shown, set=set_simple_view),
                                   SEARCH_END_SETTING['key']: RowValue(get=search_end, set=set_search_end)}


def color_default(key: str) -> str:
    """
    Return the colour the default of a colour setting of the sources stands for: its declaration (a colour), else (none) the background of a
    row of the bar and name - a row of the theme (its card in the tint of the sources rows of the mode, `color.bg.row.source.accent`, over
    the dialog: `gui.tinted_surface()`), the premium colour - the default one.
    """
    from ..gui import tinted_surface
    from ..style import tokens
    from ...sources.source_settings import SETTINGS
    if declared := str(SETTINGS[key]['default']):
        return declared
    if key == 'accent_background':
        style = tokens()
        return tinted_surface(str(style.values['color.bg.row.source.accent']), str(style.texture.card), under=str(style.color.bg.under))
    return str(source_setting('default_color'))


class SourceSettingsPage(TabPage):
    """The page of the settings of the sources: their groups in two columns."""

    WIDGET = 'source_settings_page'
    DEFAULT = f'{SOURCE_SETTINGS[0].key}.list'
    BOTTOM = f'{[group for group in SOURCE_SETTINGS if group.column][-1].key}.list'  # the end of the right column, above "Close"
    DEFAULTS = (SOURCE_SETTINGS_CONFIG,)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page: not shown yet."""
        super().__init__(*args, **kwargs)
        #: The shows have their own selection (its row in the group: a window of it).
        self.separate: bool = False
        #: The simple view is shown (the row of the time of the search: another slider).
        self.simple: bool = False
        #: The row of the group of the filter after an open again.
        self.restored_row: int = 0

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The groups of the settings in their columns (the left one first)."""
        columns: list[list[SettingGroup]] = [[], []]
        for group in shown_groups():
            columns[group.column].append(group)
        return {'SOURCE_COLUMNS': tuple(tuple(column) for column in columns)}

    def lists(self) -> dict[str, SettingList]:
        """Return the lists of the settings by their groups."""
        return {group.key: self.find(f'{group.key}.list', cls=SettingList) for group in SOURCE_SETTINGS}

    def fill(self) -> None:
        """Show the settings (the controls exist now); a written one shows every group again (one value can show in another group)."""
        from ..base import weak_callback
        for lst in self.lists().values():
            lst.edited.connect(weak_callback(self.edited))
        self.separate = source_setting(SEPARATE_SETTING)
        self.simple = simple_view_shown()
        self.refresh()
        self.lists()['selection'].current = self.restored_row

    def refresh(self) -> None:
        """Show the settings of every group (their values now; a setting grayed while another one has another value: `when`)."""
        for group in shown_groups():
            self.lists()[group.key].show([SettingRow(setting=self.shown_setting(setting),
                                                     get=own.get if (own := ROW_VALUES.get(setting['key'])) else partial(source_setting, setting['key']),
                                                     set=own.set if own else partial(set_source_setting, setting['key']),
                                                     usable=not (reason := setting_reason(setting)), reason=reason,
                                                     run=partial(edit_selection, setting['key'].rpartition('_')[2]) if setting['key'].startswith('selection_')
                                                     else None,
                                                     color_default=partial(color_default, setting['key']) if setting['kind'] == 'color' else None)
                                          for setting in group.settings])

    @staticmethod
    def shown_setting(setting: CatalogSetting) -> CatalogSetting:
        """Return a setting as its row shows it (the row of the movies with no shows of their own: of all of them)."""
        if setting['key'] == 'selection_movie' and not source_setting(SEPARATE_SETTING):
            return {**setting, 'label': L(30950, 'Movies and shows…')}
        return setting

    def edited(self, index: int) -> None:
        """A setting written: every group shown again (the default colour by the premium one); other rows of a group: the window again (its frame)."""
        if source_setting(SEPARATE_SETTING) != self.separate or simple_view_shown() != self.simple:
            self.win.reopen()
        else:
            self.refresh()

    def reopen_state(self) -> dict[str, Any]:
        """Return the state of the page of an open again: the row of the group of the filter."""
        return {'row': self.lists()['selection'].current}

    def restore(self, state: dict[str, Any]) -> None:
        """Select the row of the closed window."""
        self.restored_row = int(state.get('row') or 0)
