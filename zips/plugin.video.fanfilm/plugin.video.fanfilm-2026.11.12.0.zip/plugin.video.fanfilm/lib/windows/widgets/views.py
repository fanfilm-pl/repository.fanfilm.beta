"""
The views (`resources/skins/widgets/views.xml`): a list of rows, a tree. The model of a list is a sequence of row objects
(`rows`); the roles of a row are the bindings of the delegate (`{=row.name}`, computed for every row: only the ones the template uses), a row
of a check state (its attribute `checked`: a filter) has its state word too (`CHECK_PROPERTY`). A row which
is a list item itself (`FFItem`) is shown as it is (its label, art, properties) with the roles added. The list items made by
the view belong to the Kodi list: the view never keeps them (a list item shown in a window and freed by Python after the window
crashes Kodi 21). A tree is the one of `lib/windows/tree.py` (its model, its rows, its keys) shown by the widget.
"""

from __future__ import annotations
import re
from math import ceil
from typing import Any, Callable, ClassVar, Sequence, TYPE_CHECKING
from attrs import frozen
from xbmcgui import ACTION_MOUSE_MOVE
from ...ff.signals import ClassSignal
from ..base import number_button
from ..gui import SEPARATOR_BITS, SEPARATOR_OCTAVE, window_texture
from ..style import FOCUSED_ICON, surface_art
from . import Property, Widget, position_property
from .buttons import CHECK_STATES
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action, ControlList, ListItem
    from ...ff.item import FFItem
    from ...ff.menu import ContextMenuItem
    from .. import tree
    from ..tree import NavTarget, RowMarks, TreeModel, TreeVars


#: The list item property of every row of a list: its 0-based index (a focus line member `:same` enters a list at the index of
#: the selected row of another one: `SetFocus(<id>,$INFO[Container(<other>).ListItem.Property(ffr.index)],absolute)`); only the
#: lists a line reads it of (the focus lines pass marks them in the manifest data by this name).
INDEX_PROPERTY: str = 'ffr.index'


#: The list item property of the check state of a row (its attribute `checked`: True, False, None - `CHECK_STATES`, `next_checked()`):
#: its state word, drawn by `check_look` (`state="ListItem.Property(check)"`); OK on the row changes it in the window (`activated`).
CHECK_PROPERTY: str = 'check'

#: The list item properties of the separator above a row (`row_separator`): the separator ('true'), the label of its group ('' a plain
#: line), the steps of the zoom of the line beside the label (`separator.bit.<bit>`: their sum shortens the line to the label, Kodi
#: knows no width of a label in a row).
SEPARATOR_PROPERTY: str = 'separator.above'
#: The label of the group of a separator (a section).
SEPARATOR_LABEL: str = 'separator.label'


@frozen(kw_only=True)
class GroupRow:
    """A shown row for the separators of the groups of rows (`group_separators()`)."""

    #: The group of the row ('' none): a row of another group than the row before starts a group.
    group: str = ''
    #: An explicit separator above the row (None: none; '' a plain line; else the label of its group).
    forced: str | None = None
    #: The level of the row (a tree: its depth): a group starts only among the rows of one level under one parent (siblings).
    level: int = 0


def group_separators(rows: Sequence[GroupRow], *, named: bool) -> list[str | None]:
    """
    Return the separators above the shown rows (Qt: the separators of a combo box, the sections of a view): None none, '' a plain line,
    else the label of the group over its line (`named`: the names of the groups shown). A row of another group than the row before it
    of its level (a tree: its previous sibling) starts a group - a named one (`named`) is a section with its label, also over the first
    row; a plain separator (no name, names hidden) never lies over the first row (of the list, of its siblings). An explicit separator
    of the row wins (its label only with `named`).
    """
    result: list[str | None] = []
    last: dict[int, str] = {}  # the group of the row before, by its level (the levels under a row of an upper level end there)
    for row in rows:
        for level in [level for level in last if level > row.level]:
            del last[level]
        first, previous = row.level not in last, last.get(row.level, '')
        last[row.level] = row.group
        if row.forced is not None:
            label: str | None = row.forced if named else ''
        elif first:
            label = row.group if named and row.group else None
        else:
            label = (row.group if named else '') if row.group != previous else None
        result.append(None if first and not label else label)
    return result


def separator_properties(label: str | None, *, width: float, align: str) -> dict[str, str]:
    """
    Return the list item properties of the separator above a row (`group_separators()`: None none, '' a plain line, else its label):
    the separator, its label, the steps of the zoom of the line beside the label (`SEPARATOR_OCTAVE`) - a row of the `width`, its label
    at the start, in the middle or at the end (`align`, `GROUP_ALIGNS`): the line from the end of the row (the middle: each half from
    its end) shortened to the label in the font `group` and the gap beside it (`space.s`); the line at the start / the end before the
    label is a short one of `space.l` (`row_separator`).
    """
    steps = 0
    if label:
        from math import log2
        from ..skinfonts import text_metrics
        from ..style import tokens
        space, text = tokens().space, text_metrics('group')[0](label)
        middle = align == 'center'
        span = max(1.0, width / 2 if middle else width - space.l - space.s)  # the line of no label: from the end of the row to the label
        shown = span - (text / 2 if middle else text) - space.s
        steps = min(sum(SEPARATOR_BITS), max(0, round(-SEPARATOR_OCTAVE * log2(max(1.0, shown) / span))))
    return {SEPARATOR_PROPERTY: '' if label is None else 'true', SEPARATOR_LABEL: label or '',
            **{f'separator.bit.{bit}': 'true' if steps & bit else '' for bit in SEPARATOR_BITS}}


def row_icon(item: ListItem) -> None:
    """
    Show the icon of a list item row (`ListItem.Icon`: its thumb, else its icon) in the variant of its row, of a focused row in the art
    `FOCUSED_ICON` (`surface_art()`); unchanged: as it is.
    """
    from ...ff.item import FFItem
    key = 'thumb' if item.getArt('thumb') else 'icon'
    art = surface_art(item.getArt(key))
    if art['icon'] != item.getArt(key) or art[FOCUSED_ICON]:
        item.setArt({**(item.getArt() if isinstance(item, FFItem) else {}), key: art['icon'], FOCUSED_ICON: art[FOCUSED_ICON]})


@frozen(kw_only=True)
class RowLayout:
    """
    A look of the rows of a list (`list_view` param `layouts`): a pair of item layouts shown by its Kodi condition; the
    content `row` of the use sees it as `layout` (a derived record brings more, e.g. a zoom).
    """

    #: The height of a row.
    height: int
    #: The height of the focused row (0: `height`).
    focused_height: int = 0
    #: The width of a row (a panel: its columns), 0: Kodi's (the list width).
    width: int = 0
    #: The Kodi condition of the layouts ('': always).
    condition: str = ''


class ListView(Widget):
    """
    A list: its rows (`rows`; as many as shown: only the changed ones shown again, `_fill()`), the current one (`current`,
    `current_changed`), the activated one (`activated(index)`).
    """

    #: The value: the current row.
    VALUE = 'current'

    #: The row objects of the model.
    rows: Property[Sequence[Any]] = Property(())
    #: The current row (its index, -1: none).
    current: Property[int] = Property(-1)

    #: A row is activated (clicked): its index.
    activated: ClassSignal = ClassSignal()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The list: no separator written yet."""
        super().__init__(*args, **kwargs)
        #: The list item rows the list wrote the separator of its group on (by `id()`; the others: explicit ones of Python).
        self._separated: set[int] = set()
        #: The width of a row (`row_width()`; 0: not known yet).
        self._row_width: int = 0
        #: The rows the Kodi list shows in its list items (None: none yet, list item rows - they belong to the list).
        self._shown_rows: Sequence[Any] | None = None
        #: The current row which has just come from the Kodi list (it stands there: nothing to select; None: none).
        self._kodi_current: int | None = None

    def apply(self) -> None:
        """The window shows the list (again: Kodi made its controls anew): its rows in new list items."""
        self._shown_rows = None
        super().apply()

    def list_control(self) -> ControlList | None:
        """Return the Kodi list (None before the window shows it, or another control: a fake one of the tests)."""
        from xbmcgui import ControlList
        return self.win.get_control(self.id, ControlList)

    def apply_property(self, name: str) -> None:
        """Fill the Kodi list with the rows, select the current one."""
        if name == 'rows':
            self._fill()
        elif name == 'current':
            kodi_current, self._kodi_current = self._kodi_current, None
            if (self.current != kodi_current and (control := self.list_control()) is not None and 0 <= self.current < len(self.rows)
                    and control.getSelectedPosition() != self.current):
                control.selectItem(self.current)
        else:
            super().apply_property(name)

    def _fill(self) -> None:
        """
        Show the rows in the Kodi list: as many as it shows - only the changed ones in their list items (their labels and roles: the
        roles of a row come from the row only; the focus and the selection stay), else (also a list item row, the separators of the
        groups) new list items of the rows (their roles, their index if a focus line reads it), once for all rows (a Kodi call waits for
        the GUI lock).
        """
        from xbmcgui import ListItem
        from ..xgui import template_names
        if (control := self.list_control()) is None or self.entry is None:
            return
        names = template_names()
        rows, shown = self.rows, self._shown_rows
        own = not any(isinstance(row, ListItem) for row in rows)
        self._shown_rows = rows if own else None
        if own and shown is not None and len(shown) == len(rows) and self.separators() is None:
            for i, (before, row) in enumerate(zip(shown, rows)):
                if before != row:
                    item = control.getListItem(i)  # the list keeps it, not the view
                    label, label2 = self.labels(row)
                    item.setLabel(label)
                    item.setLabel2(label2)
                    for prop, value in self.role_values(row, names).items():
                        item.setProperty(prop, value)
            return
        indexed = self.entry.data.get(INDEX_PROPERTY, False)  # a focus line reads it
        separators = self.separators()
        items = []
        for index, row in enumerate(rows):
            item = row if isinstance(row, ListItem) else ListItem(*self.labels(row))  # a list item row (FFItem) keeps its label, art ...
            if item is row:
                row_icon(item)
            for prop, value in self.role_values(row, names).items():
                item.setProperty(prop, value)
            if indexed:
                item.setProperty(INDEX_PROPERTY, str(index))
            if separators is not None:
                self._set_separator(row, item, separators[index])
            items.append(item)
        control.reset()
        control.addItems(items)
        del items  # the list keeps them, not the view
        self.current = min(max(self.current, 0), len(rows) - 1) if rows else -1
        if self.current >= 0:  # always: new items stand on the first one and the position Kodi still tells is of the old ones
            control.selectItem(self.current)

    def group_rows(self) -> list[GroupRow]:
        """
        Return the rows for the separators of their groups (`group_separators()`): a list item row its properties `group` and - an
        explicit one of Python - `separator.above` (`separator.label`), another row its attributes `group` and `separator` (None none).
        """
        from xbmcgui import ListItem
        rows: list[GroupRow] = []
        for row in self.rows:
            if isinstance(row, ListItem):
                explicit = row.getProperty(SEPARATOR_PROPERTY) == 'true' and id(row) not in self._separated
                rows.append(GroupRow(group=row.getProperty('group'), forced=row.getProperty(SEPARATOR_LABEL) if explicit else None))
            else:
                rows.append(GroupRow(group=str(getattr(row, 'group', '') or ''), forced=getattr(row, 'separator', None)))
        return rows

    def separators(self) -> list[str | None] | None:
        """Return the separators above the rows (`group_separators()`), None if the list draws none (its param `separators`)."""
        data = self.entry.data if self.entry is not None else {}
        return group_separators(self.group_rows(), named=data['group_names']) if data.get('separators') else None

    def _set_separator(self, row: Any, item: ListItem, label: str | None) -> None:
        """Set the separator above the row on its list item (a list item row: remember the computed ones, an explicit one stays)."""
        from xbmcgui import ListItem
        if isinstance(row, ListItem):
            if row.getProperty(SEPARATOR_PROPERTY) == 'true' and id(row) not in self._separated:
                if label is None:
                    return  # explicit: as Python set it
            elif label is not None:
                self._separated.add(id(row))
            elif id(row) in self._separated:
                self._separated.discard(id(row))
            else:
                return
        data = self.entry.data if self.entry is not None else {}
        for prop, value in separator_properties(label, width=self.row_width(), align=data.get('group_align', 'left')).items():
            item.setProperty(prop, value)

    def row_width(self) -> int:
        """Return the width of a row (the template: its param `row_width`, else the width of the Kodi list; 0: not shown yet)."""
        if not self._row_width and (control := self.list_control()) is not None:
            data = self.entry.data if self.entry is not None else {}
            self._row_width = data.get('row_width') or control.getWidth()  # a Kodi call waits for the GUI lock: once
        return self._row_width

    def role_values(self, row: Any, names: dict[str, Any]) -> dict[str, str]:
        """
        Return the roles of the row (the list item properties of the delegate bindings; `names`: the ones of the templates), the state
        word of a row of a check state (`CHECK_PROPERTY`).
        """
        if self.entry is None:
            return {}
        bindings = self.win.bindings
        check = {CHECK_PROPERTY: CHECK_STATES[row.checked]} if hasattr(row, 'checked') else {}
        return {**{role.prop: bindings.value(role, names=names, row=row) for role in self.entry.roles.values()}, **check}

    def labels(self, row: Any) -> tuple[str, str]:
        """Return the labels of the list item of the row: its fields of the template (`label`, `label2`), a text row is its label."""
        data = self.entry.data if self.entry is not None else {}
        if isinstance(row, str):
            return row, ''
        return (str(getattr(row, data['label'])) if data.get('label') else '', str(getattr(row, data['label2'])) if data.get('label2') else '')

    def _take_current(self, position: int) -> None:
        """The Kodi list stands on the row `position`: it is the current one (`current_changed` when the user moved it)."""
        if position != self.current:
            self._kodi_current = position
            self.current = position

    def _sync_current(self) -> None:
        """
        Follow the selection of the Kodi list at its focus and its actions (also every move of the mouse): by its info label, a control call
        waits for the next frame of Kodi and makes it wait too.
        """
        from xbmc import getInfoLabel
        if item := getInfoLabel(f'Container({self.id}).CurrentItem'):
            self._take_current(int(item) - 1)

    def handle_focus(self, control_id: int) -> None:
        """The list got the focus: follow its selection."""
        super().handle_focus(control_id)
        self._sync_current()

    def handle_action(self, action: Action) -> bool | None:
        """An action on the list (a move): follow its selection (a move of the mouse: `const.tune.gui.list_follows_mouse`)."""
        if const.tune.gui.list_follows_mouse or action.getId() != ACTION_MOUSE_MOVE:
            self._sync_current()
        return None

    def handle_click(self, control_id: int) -> bool | None:
        """A click on the list: the current row (exactly the one of Kodi: it gets chosen) is activated."""
        if (control := self.list_control()) is not None:
            self._take_current(control.getSelectedPosition())
        super().handle_click(control_id)
        if control_id == self.id and 0 <= self.current < len(self.rows):
            self.activated.emit(self.current)
        return None


class PanelView(ListView):
    """
    A panel (a list in rows of `columns`): it keeps the first row of the model in the panel row of the current one, the
    position `row_start` a focus line enters it at (e.g. a move back into the panel wraps in its row).
    """

    #: The start of the panel row of the current row.
    FOCUS_POSITIONS = frozenset({'row_start'})

    #: The rows of the model in a row of the panel (the window knows it: Kodi's count, the panel width // the width of a cell shown).
    columns: Property[int] = Property(1)

    def property_changed(self, name: str) -> None:
        """The current row or the columns changed: keep the start of its panel row (a window property: no controls needed)."""
        if name in ('current', 'columns'):
            columns = max(1, self.columns)
            self.win.setProperty(position_property(self.id, 'row_start'), str(max(self.current, 0) // columns * columns))  # type: ignore[attr-defined]
        super().property_changed(name)


class TreeView(Widget):
    """
    A tree (`lib/windows/tree.py`): the model shown (`set_model()`), the events of its controls drive the tree of the module
    (`tree.TreeView`: expand / collapse, check, the keys, the context menu of a row, left to the parent, the row buttons,
    the filter); its users connect its signals. The template data (`TreeVars`, the behaviour) come with the manifest.
    """

    #: The height of the line above the rows: the hint, the filter field in its place (44 high) and a gap.
    HEADER: ClassVar[int] = 50

    #: The text of the line above the rows (before the hint of the keys of the tree).
    hint: Property[str] = Property('')

    #: The user checked / unchecked items: the list of them (in the order of the tree).
    checked_changed: ClassSignal = ClassSignal()
    #: A leaf of a single select is activated (clicked): the item.
    activated: ClassSignal = ClassSignal()
    #: A button of the selected row did its action: its name (`ROW_BUTTONS`), the item of the row.
    row_button_clicked: ClassSignal = ClassSignal()
    #: An item moved among its siblings: the item.
    moved: ClassSignal = ClassSignal()
    #: The shown rows or their states changed (e.g. a counter of the window follows them).
    changed: ClassSignal = ClassSignal()
    #: Another row is selected (a move, the rows shown again): its position.
    current_changed: ClassSignal = ClassSignal()

    @classmethod
    def template_tree(cls, id_of: Callable[[str], int], *, width: int, rows: int, height: int = 0, multi: bool, own_nodes: bool, details: bool,
                      buttons: Sequence[str], memory: str, filter: bool, marks: bool, left_to_parent: bool, onup: NavTarget,
                      ondown: NavTarget, onright: NavTarget, onleft: NavTarget, button_onright: NavTarget, header: bool = True,
                      separators: bool = False, group_names: str = '', group_align: str = '', flat: bool = False, tristate: bool = False,
                      check_look: str = '', summary: str = 'counts', indent_scale: float = 1, icons: bool = True,
                      expanders: bool = True) -> TreeVars:
        """
        Return the template vars of the tree of a widget (`tree_vars()`, the buttons drawn by the selected row): its size by its rows (0:
        the ones `height` holds under the line of its hint - one at least; neither of them is an error),
        the list under the line of its hint (`header`, False: none, the list at the top), its controls by their names in the widget
        (`id_of()`; the list is the widget control): the filter field `filter` (in the line of the hint) and its clear button
        `filter.clear`, the group of the row buttons `buttons` (also with no button) and each one `button.<name>`, each one right
        after the one before (as `TreeVars` has them); the separators of the groups of the rows (`separators`, `group_names`,
        `group_align`); `flat`: one level only (a list); `tristate`, `check_look`: the leaves of three values, the look of their state;
        `summary`: the counter of a node of them (`DecisionSlots.summary`); `indent_scale`: the part of the indent of the style; `icons`: the
        place of the icon of a row; `expanders`: the expander of a node.
        """
        from ..tree import tree_row_height, tree_vars

        def next_id(name: str, expected: int) -> None:
            """Give the control `name` its ID (the one after the previous one)."""
            if id_of(name) != expected:
                raise ValueError(f'The control {name!r} of the tree has no ID right after the one before')

        if filter and not header:
            raise ValueError('The filter of a tree is in the line of its hint (header)')
        filter_id = id_of('filter') if filter else 0
        if filter_id:
            next_id('filter.clear', filter_id + 1)
        from ..gui import group_band
        if not width:
            raise ValueError('A tree has no width (of its use or its parameters)')
        step = tree_row_height(details) + group_band(separators, group_names)  # a row under the band of the label of its group
        top = cls.HEADER if header else 0
        if not rows:
            if not height:
                raise ValueError('A tree has no rows (of its parameters) or height (of its use)')
            rows = max(1, (height - top) // step)
        tree = tree_vars(list_id=id_of(''), left=0, top=top, width=width, height=rows * step, multi=multi,
                         own_nodes=own_nodes, details=details, buttons=buttons, button_id=id_of('buttons'), buttons_in_rows=True,
                         onright=onright, button_onright=button_onright, onleft='' if left_to_parent else onleft, onup=onup, ondown=ondown,
                         memory=memory, filter_id=filter_id, marks=marks, separators=separators, group_names=group_names, group_align=group_align,
                         flat=flat, tristate=tristate, check_look=check_look, summary=summary, indent_scale=indent_scale, icons=icons,
                         expanders=expanders)
        for slot in tree.buttons:
            next_id(f'button.{slot.button.name}', slot.id)
        return tree

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The tree: no model yet (`set_model()`)."""
        super().__init__(*args, **kwargs)
        #: The tree of the model (None: no model yet).
        self.view: tree.TreeView | None = None

    @property
    def model(self) -> TreeModel | None:
        """Return the model of the tree (None: none yet)."""
        return None if self.view is None else self.view.model

    def set_model(self, model: TreeModel, *, extra_menu: Callable[[int], list[ContextMenuItem]] | None = None,
                  dimmed: Callable[[FFItem], bool] | None = None, marks: Callable[[FFItem], RowMarks] | None = None) -> None:
        """
        Show the model (now or when the window shows the tree), the callbacks (a bound method kept weakly): more entries of
        the context menu of a row (`extra_menu`), an item dimmed too (`dimmed`), the marks of an item after its label (`marks`).
        """
        from ..tree import TreeView as Tree
        assert self.entry is not None
        data = self.entry.data
        tree: TreeVars = data['tree']
        self.view = Tree(self.win, model, tree=tree, multi=tree.multi, select_nodes=data['select_nodes'], left_to_parent=data['left_to_parent'],
                         out_left=self._target(data['out_left']), on_change=self._on_change, on_current=self._on_current, on_check=self._on_check,
                         on_move=self._on_move,
                         extra_menu=extra_menu, dimmed=dimmed, marks=marks)
        if (widgets := self.win._widget_tree) is not None and widgets.shown:
            self._show()

    def _target(self, target: NavTarget) -> int:
        """Return the control ID of a navigation target of the template: a widget reference (`@path`, `@path:name`), an ID (0: none)."""
        if isinstance(target, str) and target.startswith('@'):
            path, _, name = target[1:].partition(':')
            return self.win.find(path).control_id(name)
        return int(target or 0)

    def _show(self) -> None:
        """Show the rows of the model (the start row of its view), the hint of its keys."""
        assert self.view is not None
        self.view.show_rows(self.view.start_row())
        self.apply_property('hint')

    def apply(self) -> None:
        """The window shows the tree: its properties, the model set before."""
        super().apply()
        if self.view is not None:
            self._show()

    def full_hint(self) -> str:
        """Return the hint of the tree: its text (`hint`) and the hint of its keys."""
        from ..tree import tree_keys_hint
        button = self.entry.data.get('keys_button') if self.entry is not None else None
        keys = '' if self.view is None else tree_keys_hint(self.view.keys, button=self.view.branch_button if button is None else button)
        return ' · '.join(text for text in (self.hint, keys) if text)

    def apply_property(self, name: str) -> None:
        """Apply the hint: the text and the hint of the keys of the tree (a window property of the widget)."""
        if name == 'hint':
            self.win.setProperty(f'ffw.{self.id}.hint', self.full_hint())  # type: ignore[attr-defined]
        else:
            super().apply_property(name)

    def help_of(self, control_id: int) -> str:
        """Return the help of a control of the tree: its own one, else in a flat tree (no hint in its line) the hint of its list, its filter."""
        if (text := super().help_of(control_id)) or (view := self.view) is None or not view.tree.flat:
            return text
        return self.full_hint() if control_id == self.id else view.filter_help(control_id)

    # --- the callbacks of the tree ---

    def _on_change(self) -> None:
        """The shown rows or their states changed."""
        self.changed.emit()

    def _on_current(self, pos: int) -> None:
        """Another row is selected."""
        self.current_changed.emit(pos)

    def _on_check(self, items: Sequence[FFItem]) -> None:
        """The user checked / unchecked the items."""
        self.checked_changed.emit(list(items))

    def _on_move(self, item: FFItem) -> None:
        """The item moved."""
        self.moved.emit(item)

    # --- events ---

    def handle_click(self, control_id: int) -> bool | None:
        """A click: a row (a leaf of a single select is activated), a row button (its action, then `row_button_clicked`), the filter."""
        super().handle_click(control_id)
        if (view := self.view) is None:
            return None
        item = None  # the item of the row of a button which applies to it (the action may move the row)
        if (button := view.buttons.get(control_id)) is not None and (pos := view.position()) >= 0 and button.applies(view, pos):
            item = view.model.rows[pos].item
        if (leaf := view.on_click(control_id)) is not None:
            self.activated.emit(leaf)
        elif button is not None and item is not None:
            self.row_button_clicked.emit(button.name, item)
        return None

    def handle_focus(self, control_id: int) -> None:
        """A control of the tree got the focus (the tree follows the list)."""
        super().handle_focus(control_id)
        if self.view is not None:
            self.view.on_focus(control_id)

    def handle_focus_out(self, control_id: int) -> None:
        """The focus went out of the tree (a left back into the list is no left in the list)."""
        if self.view is not None:
            self.view.on_focus(control_id)

    def handle_action(self, action: Action) -> bool | None:
        """The keys of the tree (also a digit), the context menu of a row, left to the parent."""
        if (view := self.view) is None:
            return None
        if (digit := number_button(action)) is not None and view.on_number_button(digit):
            return True
        return view.on_action(action)


@frozen(kw_only=True)
class ComboItem:
    """An item of a combo box (`ComboBox.items`; a text is an item of that label): its value, its label, its icon, its group."""

    #: The label (the text of the field when it is the current item).
    label: str
    #: The value (None: the label).
    value: Any = None
    #: The icon ('' none).
    icon: str = ''
    #: The group of the item: a separator above the first item of a group (`group_separators()`), '' none.
    group: str = ''
    #: An explicit separator above the item (the template: `<separator/>`, `<separator label="…"/>` before it): None none, '' a plain line.
    separator: str | None = None

    @property
    def data(self) -> Any:
        """Return the value of the item (its label if it has none)."""
        return self.label if self.value is None else self.value


#: The info of a label of a row (`$INFO[ListItem.Label2]`, its prefix and postfix left out): the text of a row in a combo box.
RX_INFO: re.Pattern[str] = re.compile(r'\$INFO\[([^,\]]+)[^\]]*\]')
#: The modes of the filter of the drop-down list of a combo box: none, the text of an editable field filters it, the filter of a tree on demand.
COMBO_FILTERS: tuple[str, ...] = ('none', 'typed', 'demand')
#: The modes of the edit of an editable combo box: OK opens the keyboard of Kodi (the focus stays on the field as on a button), a text edit.
COMBO_EDITS: tuple[str, ...] = ('click', 'direct')


@frozen(kw_only=True)
class CardSpan:
    """The place of a popup card along its field (`PopupWidget.popup_span()`): where it starts from the field, its width."""

    #: The start of the card from the start of the field (in a row of a list: the start of the row, before it).
    left: int
    #: The width of the card.
    width: int


@frozen(kw_only=True)
class ComboVars:
    """The template data of a combo box (`ComboBox.template_combo()`): where it lies, its field, its drop-down list."""

    #: Where the combo box lies (`widget_place()`): a row of a list, a child of a grouplist, a fixed place.
    place: str
    #: The static items (with their explicit separators).
    items: tuple[ComboItem, ...]
    #: The text of the field may be edited.
    editable: bool
    #: How the field is edited (`COMBO_EDITS`).
    edit: str
    #: The filter of the drop-down list (`COMBO_FILTERS`, resolved).
    filter: str
    #: The rows of the drop-down list.
    rows: int
    #: The width of the field.
    width: int
    #: The place of the drop-down list along the field (`PopupWidget.popup_span()`: at least as wide, wider for its items).
    span: CardSpan
    #: The inner spacing of the drop-down list (a card).
    pad: int
    #: The band of the label of a group over a row of the drop-down list (`group_band()`; 0: the names hidden).
    band: int = 0

    @property
    def tree_width(self) -> int:
        """Return the width of the tree of the drop-down list (in its padding)."""
        return self.span.width - 2 * self.pad

    @property
    def header(self) -> bool:
        """Return True if the tree has the line of its filter (`demand`)."""
        return self.filter == 'demand'

    @property
    def row_height(self) -> int:
        """Return the height of a row of the drop-down list (without the band of the label of a group: `group_band()`)."""
        from ..tree import tree_row_height
        return tree_row_height(False)

    @property
    def band_of_filter(self) -> int:
        """Return the band of the filter of the tree over its rows (`demand`: shown on demand, the card grows by it), 0 none."""
        return TreeView.HEADER if self.header else 0

    @property
    def popup_height(self) -> int:
        """Return the height of the drop-down list: its rows (under the bands of the labels of their groups), the line of its filter, its padding."""
        return self.popup_height_of(self.rows)

    def popup_height_of(self, rows: int) -> int:
        """Return the height of the drop-down list of the rows (`popup_height` of fewer rows: the card of fewer items)."""
        return rows * (self.row_height + self.band) + self.band_of_filter + 2 * self.pad


class PopupWidget(Widget):
    """
    A widget of a field and its popup card over the window, under / over the field (Qt: the popup of a combo box): a combo box (its
    drop-down list), a slider in a field (`gui:slider` popup). The card is shown while it has the focus (the template:
    `ControlGroup(<group>).HasFocus()`) - the window property `ffw.<id>.open` lets the hidden card take the focus Python gives it
    (`allowhiddenfocus`), cleared once the card or the field has the focus (a move along a grouplist passes the hidden card on). It
    closes with the focus back on the field; opened from outside its field (e.g. OK on a row of a list), back on the control it came
    from. In a row of a list it edits the current row (`row`: its index when the card opened); `about_to_show` lets the window give the
    data of the card then (the items of a combo box, the value of the row of a slider).
    """

    #: The row of the list the widget edits (in a row of a list; -1: none or another place).
    row: Property[int] = Property(-1)

    #: The card is about to show (Qt: QMenu.aboutToShow): its data may be given now (e.g. the items of the network, once; of the row).
    about_to_show: ClassSignal = ClassSignal()

    @staticmethod
    def popup_span(*, place: str, field: int, need: int = 0, row: int = 0, left: int = 0, right: int = 0) -> CardSpan:
        """
        Return the place of a popup card along its field of the width `field` (Qt: the popup of a QComboBox): at least the field - in a row of a
        list (`place` row) the row of the width `row` from its start (the field of the use there: `left`, else `right` from its end; the row
        unknown, 0: the field) -, wider for the content it needs (`need`: the widest item of a list), at most `POPUP_ROOM` of the window (a fixed
        place: `geometry.apply_overlays()` shifts it into the window); in a grouplist the field (a grouplist clips its children).
        """
        from ..geometry import POPUP_ROOM, WINDOW_SIZE
        if place == 'grouplist':
            return CardSpan(left=0, width=field)
        start, least = 0, field
        if place == 'row' and row:
            start, least = (left if left or not right else row - right - field), max(field, row)
        return CardSpan(left=-start, width=min(max(least, need), max(least, int(POPUP_ROOM * WINDOW_SIZE.width))))

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The widget: its card closed."""
        super().__init__(*args, **kwargs)
        #: The control the shown card was opened from outside the widget (the focus goes back there), 0: its field.
        self._back: int = 0

    def field_id(self) -> int:
        """Return the control of the field (the focus goes back there when the card closes): the widget control."""
        return self.id

    def popup_owns(self, control_id: int) -> bool:
        """Return True if the control is of the card."""
        return False

    def owns(self, control_id: int) -> bool:
        """Return True if the control is of the widget: its field, its card."""
        return control_id == self.field_id() or self.popup_owns(control_id)

    def list_row(self) -> int:
        """Return the current row of the list the widget lies in (its template data `list_id`; -1: none)."""
        from xbmc import getInfoLabel
        list_id = self.entry.data['list_id'] if self.entry is not None else 0
        return int(getInfoLabel(f'Container({list_id}).CurrentItem') or 0) - 1

    def popup_opening(self) -> None:
        """
        The card opens: `about_to_show` (the data of the card may be given now), the control it was opened from outside the widget
        remembered (the focus goes back there), the hidden card may take the focus.
        """
        self.about_to_show.emit()
        if (focused := self.win.focused_id()) and not self.owns(focused):  # type: ignore[attr-defined]
            self._back = focused
        self._set_open(True)

    def _set_open(self, opened: bool) -> None:
        """Let the hidden card take the focus (`opened`; a text edit filtering a list: show it beside the edit with the focus) or not."""
        self.win.setProperty(f'ffw.{self.id}.open', 'true' if opened else '')  # type: ignore[attr-defined]

    def hide_popup(self, *, focus: bool = True) -> None:
        """
        Hide the card: the focus back on the field (`focus`; the card is shown while it has the focus) - opened from outside, on the
        control it came from.
        """
        self._set_open(False)
        back, self._back = self._back, 0
        if focus:
            self.win.setFocusId(back or self.field_id())  # type: ignore[attr-defined]


class ComboBox(PopupWidget):
    """
    A combo box (Qt: QComboBox): a field of the current item and its drop-down list (a flat tree: `popup`, a card over the window, under
    the field - `PopupWidget`), the items (`items`: texts or `ComboItem` records; the static ones of the template first), the current one
    (`current_index`, `current_text`), the edited text (`edit_text`, editable). OK on the field opens the list (editable, `edit` click:
    the keyboard of Kodi), OK in the list chooses (`activated`), Back closes it without a change; the focus goes back to the field. In a
    row of a list it edits the current row. The list is shown while it (its filter) has the focus (a text edit filtering it: while the
    edit has the focus too). Opened from outside its field (`open()`: e.g. OK on a row of its list), the focus goes back there - the
    field of that list is the control it came from.
    """

    #: The value: the index of the current item.
    VALUE = 'current_index'

    #: The items: texts or `ComboItem` records (the static ones of the template at the start).
    items: Property[Sequence[Any]] = Property(())
    #: The index of the current item (-1: none).
    current_index: Property[int] = Property(-1)
    #: The text of the current item (editable: the edited text).
    current_text: Property[str] = Property('')
    #: The text of the field of an editable combo box.
    edit_text: Property[str] = Property('')

    #: The user chose an item (OK in the list, an edited text of an editable one): its index (-1: a text of no item).
    activated: ClassSignal = ClassSignal()

    @classmethod
    def template_combo(cls, *, place: str, items: Sequence[Any], use: Sequence[Any], editable: bool, edit: str, filter: str, rows: int,
                       width: int, group_names: str = '', row_width: int = 0, left: int = 0, right: int = 0) -> ComboVars:
        """
        Return the template data of a combo box: its static items (`items` and the elements of the place `items` of its use: `<item
        value="…" icon="…" group="…">label</item>`, `<separator label="…"/>` - an explicit separator above the next item), the filter of
        its list ('' derived: editable - typed, else demand when there are more static items than its rows, else none), its rows (0: the
        static items up to the rows of the list as high as `metric.combo.height` - a row under the band of the label of its group with the
        names shown, `group_names`, the line of the filter on demand; none static - that many), its width (0: `metric.button.width.wide`), the
        place of its list (`PopupWidget.popup_span()`: at least the field - in a row of the width `row_width` the row, the field `left` /
        `right` in it -, wider for the widest static item - its text in the role `normal` of a row of the list).
        """
        from ..skinfonts import text_metrics
        from ..gui import group_band
        from ..style import tokens
        style = tokens()
        static = [cls.item_of(item) for item in items]
        separator: str | None = None
        for elem in use:
            if elem.tag == 'separator':
                separator = elem.attrs.get('label', '')
            elif elem.tag == 'item':
                static.append(ComboItem(label=elem.text, value=elem.attrs.get('value'), icon=elem.attrs.get('icon', ''),
                                        group=elem.attrs.get('group', ''), separator=separator))
                separator = None
        if edit not in COMBO_EDITS:
            raise ValueError(f'Unknown edit {edit!r} of a combo box (not one of {", ".join(COMBO_EDITS)})')
        from ..tree import tree_row_height
        band, pad = group_band(True, group_names), style.space.pad.card
        row = tree_row_height(False) + band  # a row of the list (`ComboVars.row_height`) under the band of the label of its group

        def fit(header: bool) -> int:
            """Return the rows of the list: the static items up to as many as fit (`header`: under the line of the filter)."""
            most = max(1, (style.metric.combo.height - 2 * pad - (TreeView.HEADER if header else 0)) // row)
            return rows or (min(len(static), most) if static else most)

        if not filter:
            filter = 'typed' if editable else 'demand' if len(static) > fit(False) else 'none'
        if filter not in COMBO_FILTERS:
            raise ValueError(f'Unknown filter {filter!r} of a combo box (not one of {", ".join(COMBO_FILTERS)})')
        text_width = text_metrics('normal')[0]
        widest = max((ceil(text_width(item.label)) for item in static), default=0)
        need = widest + 3 * style.space.s + style.space.xl + 2 * pad if widest else 0  # a row: the icon, the label (`combo_row`), the padding of the card
        width = width or style.metric.button.width.wide
        return ComboVars(place=place, items=tuple(static), editable=editable, edit=edit, filter=filter, rows=fit(filter == 'demand'), width=width,
                         span=cls.popup_span(place=place, field=width, need=need, row=row_width, left=left, right=right), pad=pad, band=band)

    @staticmethod
    def item_of(item: Any) -> ComboItem:
        """Return the item as a record (a text: an item of that label)."""
        return item if isinstance(item, ComboItem) else ComboItem(label=str(item))

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The combo box: its list closed."""
        super().__init__(*args, **kwargs)
        #: The items of the tree of the shown list by `id()`: their indexes.
        self._indexes: dict[int, int] = {}
        #: The place of the drop-down list of the template (its most rows; None: not read yet), `fit_card()`.
        self._popup_place: tuple[int, int] | None = None

    @property
    def vars(self) -> ComboVars:
        """Return the template data."""
        assert self.entry is not None
        return self.entry.data['combo']

    @property
    def popup(self) -> ListView | TreeView:
        """Return the drop-down list (no filter: a list, else a flat tree)."""
        return self.children['popup']  # type: ignore[return-value]

    def popup_owns(self, control_id: int) -> bool:
        """Return True if the control is of the drop-down list."""
        popup = self.popup
        return control_id == popup.id if isinstance(popup, ListView) else popup.view is not None and popup.view.owns(control_id)

    def records(self) -> list[ComboItem]:
        """Return the items as records."""
        return [self.item_of(item) for item in self.items]

    def built(self) -> None:
        """The static items, the clicks of the field and of its arrow, the choice in the list."""
        from ..base import weak_callback
        super().built()
        if self.entry is not None and (static := self.vars.items):
            self.items = static
        if (field := self.children.get('field')) is not None:
            field.clicked.connect(weak_callback(self._field_clicked))
            field.focused.connect(weak_callback(self._field_focused))
        if (arrow := self.children.get('arrow')) is not None:
            arrow.clicked.connect(weak_callback(self.show_popup))
        self.popup.activated.connect(weak_callback(self._chosen))  # a list: the index of the row, a tree: the item
        self.popup.focused.connect(weak_callback(self._popup_focused))

    # --- the state ---

    def index_of(self, text: str) -> int:
        """Return the index of the (first) item of the label (-1: none)."""
        return next((n for n, record in enumerate(self.records()) if record.label == text), -1)

    def property_changed(self, name: str) -> None:
        """
        The current item: its text; the edited text (editable, also of Python): the current item the one of its label (-1 none); the
        items: the current one kept in range, its text in the field (not editable).
        """
        if name == 'current_index':
            records = self.records()
            if 0 <= self.current_index < len(records):
                self.current_text = records[self.current_index].label
                if self.vars.editable:
                    self.edit_text = self.current_text
        elif name == 'edit_text' and self.vars.editable:
            self.current_text = self.edit_text
            records = self.records()
            if not (0 <= self.current_index < len(records) and records[self.current_index].label == self.edit_text):  # the same label kept
                self.current_index = self.index_of(self.edit_text)
        elif name == 'items':
            if self.current_index >= len(self.items):
                self.current_index = -1
            elif self.current_index >= 0 and not self.vars.editable:  # its text may be another one now
                self.current_text = self.records()[self.current_index].label
        super().property_changed(name)

    def shown_text(self) -> str:
        """Return the text of the field: the edited one (editable), else the one of the current item."""
        return self.edit_text if self.vars.editable else self.current_text

    def apply_window_property(self, name: str) -> None:
        """The text of the field (its window property: a field button, the label of a row)."""
        if name in ('current_text', 'edit_text') and self.entry is not None:
            self.win.setProperty(f'ffw.{self.id}.text', self.shown_text())  # type: ignore[attr-defined]
        super().apply_window_property(name)

    def apply_property(self, name: str) -> None:
        """The text of the field (a text edit: its text)."""
        if name in ('current_text', 'edit_text'):
            self.apply_window_property(name)
            if self.vars.edit == 'direct' and (field := self.children.get('field')) is not None and (edit := field.control()) is not None:
                if edit.getText() != self.shown_text():  # type: ignore[attr-defined]
                    edit.setText(self.shown_text())  # type: ignore[attr-defined]
        else:
            super().apply_property(name)

    # --- the drop-down list ---

    def owns(self, control_id: int) -> bool:
        """Return True if the control is of the combo box: its field, its arrow, its drop-down list."""
        arrow = self.children.get('arrow')
        return control_id in (self.field_id(), arrow.id if arrow is not None else 0) or self.popup_owns(control_id)

    def open(self, index: int | None = None) -> None:
        """
        Open the drop-down list from outside its field (in a row of a list: of its current row, e.g. OK on the row), the current item
        `index` (None: as the field shows it); the focus goes back to the control it came from when it closes.
        """
        if self.vars.place == 'row':
            self._row_opened()
        if index is not None:
            self.current_index = index
        self.show_popup()

    def show_popup(self, *, text: str = '', focus: bool = True) -> None:
        """
        Show the drop-down list (`about_to_show` first: the items may be given then; the items, the current one selected; `text`: filtered
        by it - no item matches: not shown), its current row focused (`focus`); opened from a control out of the combo box: the focus goes
        back there when it closes.
        """
        from ...ff.item import FFItem
        from ..tree import TreeModel
        self.popup_opening()  # the hidden list may take the focus (a text edit filtering it: shown beside it)
        items: list[FFItem] = []
        for record in self.records():
            item = FFItem(record.label)
            if record.icon:
                item.setArt({'icon': window_texture(record.icon)})
            item.setProperty('group', record.group)
            if record.separator is not None:
                item.setProperty(SEPARATOR_PROPERTY, 'true')
                item.setProperty(SEPARATOR_LABEL, record.separator)
            items.append(item)
        self._indexes = {id(item): n for n, item in enumerate(items)}
        current = items[self.current_index] if 0 <= self.current_index < len(items) else None
        popup = self.popup
        if isinstance(popup, ListView):  # no filter: a list
            popup.rows = items
            for n, row in enumerate(popup.rows):  # the items equal to the shown ones (the same labels) keep the shown list items
                row.setProperty('combo.current', 'true' if n == self.current_index else '')
            popup.current = max(0, self.current_index)
        else:
            assert isinstance(popup, TreeView)
            popup.set_model(TreeModel(items, selected=() if current is None else (current,)))
            view = popup.view
            assert view is not None
            if text:
                view.filter(text)
                if not view.model.rows:  # no item matches: no list (not an empty card)
                    self.hide_popup(focus=False)
                    return
            if current is not None and (pos := next((n for n, row in enumerate(view.model.rows) if row.item is current), -1)) >= 0:
                view.list_control().selectItem(pos)
        self.fit_card(len(items) if isinstance(popup, ListView) else len(popup.view.model.rows))  # type: ignore[union-attr]
        if focus:
            self.win.setFocusId(self.popup.id)  # type: ignore[attr-defined]

    def card_place(self, rows: int) -> tuple[str, int]:
        """
        Return the side of the drop-down list of the `rows` (S under its field, N over it) and the rows it shows: the place of its overlay
        (`OverlayPlace`, `apply_overlays()`; a row: its room at the current row of the list) - the first side with room for all, else the
        side of more room and as many rows as it holds, at least `const.tune.gui.popup_min_rows`; no place known: under it, all.
        """
        from xbmc import getInfoLabel
        combo = self.vars
        if self.entry is None or (place := self.entry.data.get('overlay')) is None:
            return 'S', rows
        room = dict(place.room)
        if place.row_info:  # a row: the room at the current row of the list (under the field less, over it more)
            pos = int(getInfoLabel(f'Container({self.entry.data["list_id"]}).{place.row_info}') or 0)
            room = {'S': room['S'] - pos * place.row_step, 'N': room['N'] + pos * place.row_step}
        if side := next((side for side in ('S', 'N') if side in room and combo.popup_height_of(rows) <= room[side]), ''):
            return side, rows
        side = max(room, key=lambda name: room[name])
        fit = (room[side] - combo.popup_height_of(0)) // (combo.row_height + combo.band)
        return side, max(1, min(rows, max(const.tune.gui.popup_min_rows, fit)))

    def fit_card(self, rows: int) -> None:
        """
        Size the drop-down list to the rows shown (`rows` items, up to its rows; the items of Python: their number known only now - Kodi
        sizes the controls of a group at the load of the window only) and its room (`card_place()`): its group and the images of its card
        (`card.*`: the ones the style draws; the filter on demand: `card` without its band, `card_band` with it); a list over its field
        keeps its bottom at the field (a row: over the field of the row, the edge of its side shown by `ffw.<id>.side`).
        """
        combo, ids = self.vars, self.entry.ids if self.entry is not None else {}
        side, shown = self.card_place(max(1, min(rows, combo.rows)))
        height = combo.popup_height_of(shown)
        if (group := self.control('popup_group')) is None:
            return
        if self._popup_place is None:
            self._popup_place = (int(group.getX()), int(group.getY()))
        x, y = self._popup_place
        if combo.place == 'row':  # under the field of the row (its group: the field at 0, the list at its height), or over it
            self.win.setProperty(f'ffw.{self.id}.side', side)
            group.setPosition(x, y if side == 'S' else -height)
        elif side == 'N':  # over its field: the bottom kept
            group.setPosition(x, y + combo.popup_height - height)
        group.setHeight(height)
        if isinstance(self.popup, ListView) and (lst := self.win.get_control(self.popup.id)) is not None:  # its rows (Kodi pages it again)
            lst.setHeight(height - combo.popup_height_of(0))
        for name, cid in ids.items():
            card = name.partition('.')[0]
            if card in ('card', 'card_band') and (image := self.win.get_control(cid)) is not None:
                image.setHeight(height if card == 'card_band' else height - combo.band_of_filter)

    def field_id(self) -> int:
        """Return the control of the field: its widget (a field button, a text edit), in a row the button over the current row."""
        return field.id if (field := self.children.get('field')) is not None else self.control_id('field')

    def _chosen(self, chosen: Any) -> None:
        """An item chosen in the list (a list: its index, a tree: the item): the current one, the list hidden, `activated`."""
        index = chosen if isinstance(chosen, int) else self._indexes.get(id(chosen), -1)
        if not 0 <= index < len(self.items):
            return
        self.hide_popup()
        self.current_index = index
        self.activated.emit(index)

    def _field_clicked(self) -> None:
        """
        The field clicked: an editable one edits its text (click: the keyboard of Kodi; direct: the text edit changed - Kodi clicks it at
        every change), the typed filter shows the matching items; another one opens the list (in a row: of the current row).
        """
        combo = self.vars
        if not combo.editable:
            if combo.place == 'row':
                self._row_opened()
            self.show_popup()
            return
        if combo.edit == 'click':
            from ...ff.ui import ui
            if (text := ui.input(self.help or self.current_text, self.edit_text)) is None:
                return
        else:
            text = self.children['field'].control().getText()  # type: ignore[union-attr]
        self.edit_text = text  # the current item of its label (`property_changed()`)
        if combo.filter == 'typed' and text and self.current_index < 0:
            self.show_popup(text=text, focus=combo.edit == 'click')
        elif combo.edit == 'click':
            self.activated.emit(self.current_index)

    def _row_opened(self) -> None:
        """The list opens in a row of a list: the row (`row`), its current item by the text of the row in its field."""
        from xbmc import getInfoLabel
        list_id = self.entry.data['list_id'] if self.entry is not None else 0
        self.row = self.list_row()
        text = ''
        if self.entry is not None and (info := RX_INFO.fullmatch(self.entry.data['text'])):  # the info of the row in its list
            text = getInfoLabel(info[1].replace('ListItem.', f'Container({list_id}).ListItem.', 1))
        self.current_index = self.index_of(text)

    # --- events ---

    def handle_action(self, action: Action) -> bool | None:
        """Back in the shown list closes it without a change (the focus back on the field)."""
        from ..base import CANCEL_ACTIONS
        if action.getId() in CANCEL_ACTIONS and self.popup_owns(self.win.focused_id()):
            self.hide_popup()
            return True
        return None

    def _field_focused(self) -> None:
        """
        The field got the focus (up from the list, a move): the hidden list takes no focus (a move along a grouplist passes it on); a list
        opened from outside: the focus back on the control it came from.
        """
        self.hide_popup(focus=bool(self._back))

    def _popup_focused(self) -> None:
        """The list got the focus: shown by its focus from now on (it hides itself when the focus goes)."""
        self._set_open(False)

    def handle_click(self, control_id: int) -> bool | None:
        """The button over the current row of a list (in a row): the list of the row opens."""
        if self.vars.place == 'row' and control_id == self.field_id():
            self._field_clicked()
            return True
        return super().handle_click(control_id)

    def handle_focus(self, control_id: int) -> None:
        """The button over the current row of a list (in a row) got the focus: as the field (`_field_focused()`)."""
        if self.vars.place == 'row' and control_id == self.field_id():
            self._field_focused()
        super().handle_focus(control_id)
