"""
The page of general lists of the configuration window: a grid of the general lists of the service types (rows) by the menus
they can be shown in (columns; `lib.windows.general_lists`). A switch of a type, of a list (everywhere) and of a menu (a column)
grays the switches below it, they keep their values (`lib.ff.lists_config`). A grayed switch has no focus: its reason is in
sight (a switch of its row or column is off, or a note of the type, e.g. no key).
"""

from __future__ import annotations
from functools import partial
from typing import Any, TYPE_CHECKING
from attrs import evolve, frozen
from .buttons import CheckBox
from .tabs import Page, TabPage
from ..style import tokens
from ..general_lists import ANGLE, BREAK_WIDTH, STEP, X0, Row, grid_head, grid_rows, place_label, places, row_active, row_note, switch_help
from ...ff import lists_config as lc
from ...kolang import L
if TYPE_CHECKING:
    from ...indexers.lists.menu import MenuDef


@frozen(kw_only=True)
class GeneralRow:
    """The template vars of a row: a service type or a general list of it."""

    #: The position of the row (from 0).
    index: int
    #: The row of the type (else of a general list).
    is_type: bool
    #: The label.
    label: str
    #: The columns (the menus) the list can be shown in.
    columns: frozenset[int]


class GeneralListsPage(TabPage):
    """The page of general lists (its bindings: the colors of the labels, the notes of the types)."""

    WIDGET = 'general_lists_page'
    DEFAULT = 'row_0'
    TOP = 'place_0'  # the switches of the columns
    DEFAULTS = (lc.SERVICES_CONFIG, lc.PLACES_CONFIG)

    @classmethod
    def page_of(cls, name: str) -> Page:
        """Return the template data of the page: its bottom (above "Close") is the last switch of the last row (no cells: the row)."""
        rows = grid_rows()
        last, cells = len(rows) - 1, rows[-1].cells
        return evolve(super().page_of(name), bottom=f'cell_{last}_{max(cells)}' if cells else f'row_{last}')

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The structure of the page: the columns (menus), the rows (types, their general lists) and the columns of their cells."""
        from ...ff.accounts import SERVICE_TYPES
        menus, rows = places(), grid_rows()
        head = grid_head(menus, len(rows))
        return {'GEN_COLS': [place_label(menu.id) for menu in menus],
                'GEN_ROWS': [GeneralRow(index=r, is_type=row.entry is None,
                                        label=SERVICE_TYPES[row.type_name].label if row.entry is None else row.entry.label(),
                                        columns=frozenset(row.cells)) for r, row in enumerate(rows)],
                'GEN_SWITCHES': L(32969, 'Switched on in the menu'), 'GEN_X0': X0, 'GEN_STEP': STEP, 'GEN_HEAD': head.height,
                'GEN_ROW_H': head.row_height, 'GEN_ANGLE': ANGLE, 'GEN_BREAK': BREAK_WIDTH}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        #: The menus of the columns.
        self.menus: list[MenuDef] = places()
        #: The rows of the grid.
        self.rows: list[Row] = grid_rows()

    def built(self) -> None:
        """The switches connected, the help of the switches of the menus and of the lists."""
        for c, menu in enumerate(self.menus):
            switch = self.find(f'place_{c}', cls=CheckBox)
            switch.toggled.connect(partial(self.set_place, c))
            switch.help = switch_help(None, menu.id)
        for r, row in enumerate(self.rows):
            switch = self.find(f'row_{r}', cls=CheckBox)
            switch.toggled.connect(partial(self.set_row, r))
            if row.entry is not None:
                switch.help = switch_help(row, None)
            for c in row.cells:
                cell = self.find(f'cell_{r}_{c}', cls=CheckBox)
                cell.toggled.connect(partial(self.set_cell, r, c))
                cell.help = switch_help(row, self.menus[c].id)

    # --- the view (the bindings read it) ---

    def row_color(self, r: int) -> str:
        """Return the color of the label of the row."""
        return tokens().color.text.strong if row_active(self.rows[r]) else tokens().color.text.hint

    def col_color(self, c: int) -> str:
        """Return the color of the label of the column."""
        return tokens().color.text.strong if lc.place_active(self.menus[c].id) else tokens().color.text.hint

    def note(self, r: int) -> str:
        """Return the note of a row of a type: why its lists can not be shown (e.g. MDBList without a key)."""
        return row_note(self.rows[r])

    # --- events ---

    def fill(self) -> None:
        """Set the switches (the controls exist now)."""
        self.refresh()

    def refresh(self) -> None:
        """Set the switches from the user settings, gray the cells cut by a switch above them, the notes of the types."""
        for c, menu in enumerate(self.menus):
            self.find(f'place_{c}').checked = lc.place_active(menu.id)
        for r, row in enumerate(self.rows):
            switch = self.find(f'row_{r}', cls=CheckBox)
            if row.entry is None:  # an account (a key) may have changed in the page of accounts
                switch.checked = lc.service_active(row.type_name)
                switch.help = switch_help(row, None)
                continue
            switch.checked = lc.list_active(row.type_name, row.entry.key)
            on = row_active(row)
            for c, default in row.cells.items():
                cell = self.find(f'cell_{r}_{c}', cls=CheckBox)
                cell.checked = lc.list_place(row.type_name, row.entry.key, self.menus[c].id, default)
                cell.enabled = on and lc.place_active(self.menus[c].id)
        self.win.bindings.refresh()

    def set_place(self, c: int, checked: bool) -> None:
        """The switch of a menu toggled: all general lists in it or none, written at once."""
        lc.set_place_active(self.menus[c].id, checked)  # type: ignore[arg-type]
        self.refresh()

    def set_row(self, r: int, checked: bool) -> None:
        """The switch of a row toggled: the general lists of the type or the list (everywhere), written at once."""
        row = self.rows[r]
        if row.entry is None:
            lc.set_service_active(row.type_name, checked)
        else:
            lc.set_list_active(row.type_name, row.entry.key, checked)
        self.refresh()

    def set_cell(self, r: int, c: int, checked: bool) -> None:
        """A cell toggled: the list in the menu, written at once."""
        row = self.rows[r]
        assert row.entry is not None  # a row of a type has no cells
        lc.set_list_place(row.type_name, row.entry.key, self.menus[c].id, checked, row.cells[c])  # type: ignore[arg-type]
        self.refresh()
