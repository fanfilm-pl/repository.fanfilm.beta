"""
The page of the source providers of the configuration window (the tab `addons`): the native providers of FanFilm and the
provider add-ons with the add-ons they serve in a tree, a scraper searched or not (the check of its row), the panel of the
selected row (its info, its buttons, its settings). The logic of the tab: `lib.windows.external_addons.ProvidersTabLogic`;
every change is written at once.
"""

from __future__ import annotations
from typing import Any, Sequence, TYPE_CHECKING
from typing_extensions import get_args
from .buttons import PushButton
from .tree_page import TreePage
from .setting_list import SettingList
from .views import TreeView
from ..style import tokens
from ..config_dialog import page_rows
from ..external_addons import NODE_SETTINGS, TREE_WIDTH, PanelButton, ProvidersTabLogic, summary_height
from ..tree import tree_row_height
from ...kolang import L
if TYPE_CHECKING:
    from .basic import Image, Label, TextBox
    from ...ff.item import FFItem

#: The buttons of the panel (their widgets `panel.<name>`), in their order.
BUTTONS: tuple[PanelButton, ...] = get_args(PanelButton)


class SourceProvidersPage(ProvidersTabLogic, TreePage):
    """
    The page of the source providers (its title and its defaults: the ones of the tab). The panel shows the selected row: its
    texts in the labels and the text boxes, its state `native` as the window property of the page (`ffw.<id>.native`: a native
    row has the name and the settings in the place of the buttons and the description); an unusable button is disabled (gray,
    it keeps the focus, the footer tells why).
    """

    WIDGET = 'source_providers_page'
    TOP = 'panel.settings'  # the top of the panel (its moves up go to "Close"; a native row: hidden, its move down passes it on)
    BOTTOM = 'panel.settings_list'  # the bottom of the panel, above "Close"

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """
        The tree, the panel (the summary: two lines of its font); the last
        button of a row: the check button of a choice of leaves (`tree_vars()`, `const.dialog.tree.check`), else none.
        """
        from const import const
        return {'PROVIDERS_TREE_WIDTH': TREE_WIDTH, 'PROVIDERS_ROWS': page_rows(tree_row_height(False), TreeView.HEADER), 'PROVIDERS_TOP': TreeView.HEADER,
                'PROVIDERS_LAST_BUTTON': 'check' if const.dialog.tree.check == 'button' else '',
                'PROVIDERS_PANEL_LEFT': TREE_WIDTH + tokens().space.xxl, 'PROVIDERS_NODE_ROWS': len(NODE_SETTINGS),
                'PROVIDERS_SUMMARY_HEIGHT': summary_height()}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet (the provider add-ons are read when it is shown)."""
        super().__init__(*args, **kwargs)
        self.init_logic()

    def built(self) -> None:
        """The hint of the tree."""
        self.tree.hint = L(30357, 'OK: searched or not (an add-on, a group: expand / collapse)')

    def fill(self) -> None:
        """Show the tree (as it was left) and the panel of its row (the controls exist now)."""
        self.tree.set_model(self.load(), dimmed=self.dimmed, marks=self.marks, extra_menu=self.extra_menu)
        self.show_panel(self.view.start_row())

    def refresh(self) -> None:
        """Read the provider add-ons again (the defaults restored, another page changed something)."""
        self.reload()

    # --- the panel ---

    def label(self, name: str) -> Label:
        """Return a label of the panel."""
        return self.find(f'panel.{name}')  # type: ignore[return-value]

    def button(self, name: PanelButton) -> PushButton:
        """Return a button of the panel."""
        return self.find(f'panel.{name}')  # type: ignore[return-value]

    @property
    def settings_list(self) -> SettingList:
        """Return the list of the settings of the panel."""
        return self.find('panel.settings_list', cls=SettingList)

    def show_panel(self, pos: int | None = None) -> None:
        """Show the panel of the row `pos` (None: the selected one): its texts, its buttons, its settings."""
        self.select_panel(pos)
        panel, win = self.panel, self.win
        win.setProperty(f'ffw.{self.id}.native', '1' if panel.native else '')  # type: ignore[attr-defined]
        for name, text in {'summary': panel.summary, 'description': panel.description}.items():
            box: TextBox = self.find(f'panel.{name}')  # type: ignore[assignment]
            box.text = text
        icon: Image = self.find('panel.icon')  # type: ignore[assignment]
        icon.texture = panel.icon
        self.label('category').text = f'[B]{panel.category}[/B]'
        for name, below in {'title': False, 'title_below': True}.items():  # the name in one line or below its category
            self.label(name).text = panel.title
            self.label(name).visible = bool(panel.category) == below
        texts = {'addon_id': panel.id, 'info': panel.info, 'state': panel.state, 'claimed': panel.claimed, 'heading': f'[B]{panel.heading}[/B]'}
        for name, text in texts.items():
            self.label(name).text = text
        for name in BUTTONS:
            button, usable = self.button(name), self.usable(name)
            button.text = self.button_text(name)
            button.reason = '' if usable else self.button_help(name)  # a gray one keeps the focus
            button.enabled = usable
        self.show_rows()
        self.show_help()

    def show_rows(self, pos: int = 0) -> None:
        """Show the settings of the panel (label - value) with the row `pos` selected."""
        self.settings_list.show(self.panel_settings(), pos)

    def row_selected(self) -> None:
        """Another row of the tree selected: its panel; else the help of the focused control (e.g. another setting)."""
        if self.view.owns(self.win.focused_id()) and self.view.position() != self.pos:
            self.show_panel()
        else:
            self.show_help()

    def help_of(self, control_id: int) -> str:
        """Return the help of the tree, of a button of the selected row, of the panel or of a setting (for a grayed one: why)."""
        if control_id == self.settings_list.id:
            return self.settings_list.help_of_row()
        if (name := next((name for name in BUTTONS if self.button(name).id == control_id), None)) is not None:
            return self.button_help(name)
        return self.tree_help(control_id) if self.view.owns(control_id) else ''

    # --- events ---

    def on_tree_checked_changed(self, items: Sequence[FFItem]) -> None:
        """Scrapers searched / not (written at once)."""
        self.checked(items)

    def on_panel_settings_clicked(self) -> None:
        """Open the settings of the add-on of the panel."""
        self.open_settings()

    def on_panel_enable_clicked(self) -> None:
        """Enable the add-on in Kodi, activate / deactivate the provider add-on."""
        self.enable()

    def on_panel_defaults_clicked(self) -> None:
        """The default selection of the branch of the row."""
        self.default_selection()

    def on_panel_settings_list_current_changed(self, index: int) -> None:
        """A move in the settings of the panel: the help of the setting."""
        self.show_help()

    def on_panel_settings_list_edited(self, index: int) -> None:
        """A setting of the panel written (the list edits it): the marks of the tree (the own color, priority of a node)."""
        self.view.show_states()
