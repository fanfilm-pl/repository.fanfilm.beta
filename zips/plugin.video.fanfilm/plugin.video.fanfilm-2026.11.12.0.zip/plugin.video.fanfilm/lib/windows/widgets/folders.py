"""
The page of folders of the configuration window: when a level of a menu of lists is a folder (`When`: never, if many,
always - one of them in a row; `lib.ff.lists_config.FOLDER_POINTS`), with a preview of the menu of the group of the focused
row (`lib.windows.folders`). The switches: a list of the rows (their looks) under three transparent buttons on its current row.

Accepted limits of that (the mouse only, the keys are as with separate controls): the mouse on another row focuses the list first, the buttons come
over the row after it, so until the next move of the mouse the whole row is framed and the help is of its chosen value, not of the pointed column.
"""

from __future__ import annotations
from functools import partial
from typing import Any, TYPE_CHECKING
from attrs import evolve, frozen
from cdefs import When
from .buttons import CHECK_STATES, FocusButton
from .tabs import TabPage
from .views import ListView
from ..folders import HEAD, ROW_H, STEP, WHENS, X0, head_color, preview_text, switch_help, when_label
from ...ff import lists_config as lc
from ...kolang import L
if TYPE_CHECKING:
    from xbmcgui import Action


@frozen(kw_only=True)
class FolderRow:
    """The template vars of a row: the head of a group or a level with its switches."""

    #: The position of the level (from 0; of the head of a group: its first level).
    index: int
    #: The head of a group (else a level).
    head: bool
    #: The label.
    label: str
    #: The group of the row.
    group: str
    #: The `When` of a level (None: a head, the template rows).
    when: When | None = None

    def state(self, column: int) -> str:
        """Return the state word of the switch of the column."""
        return CHECK_STATES[self.when is WHENS[column]]


@frozen(kw_only=True)
class FolderColumn:
    """The template vars of a column: its `When` (the value of its switches), its label."""

    #: The `When` of the column.
    when: When
    #: The label.
    label: str


class FoldersPage(TabPage):
    """The page of folders (its bindings: the colors of the heads of the groups; the preview: a text box)."""

    WIDGET = 'folders_page'
    DEFAULT = 'cell_0'
    BOTTOM = f'cell_{len(WHENS) - 1}'  # over "Close": the last column of the current row
    DEFAULTS = (lc.FOLDERS_CONFIG,)

    @classmethod
    def rows(cls) -> list[FolderRow]:
        """Return the rows of the list: each group: its head, its levels."""
        rows: list[FolderRow] = []
        group = ''
        for r, point in enumerate(lc.FOLDER_POINTS):
            if point.group != group:
                group = point.group
                rows.append(FolderRow(index=r, head=True, label=lc.FOLDER_GROUPS[group](), group=group))
            rows.append(FolderRow(index=r, head=False, label=point.label(), group=group))
        return rows

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The structure of the page: the rows (in their groups), the columns (the `When` values), the geometry (`lib.windows.folders`)."""
        return {'FOLD_ROWS': cls.rows(), 'FOLD_COLS': [FolderColumn(when=when, label=when_label(when)) for when in WHENS], 'FOLD_PREVIEW': L(32972, 'Preview'),
                'FOLD_X0': X0, 'FOLD_STEP': STEP, 'FOLD_ROW_H': ROW_H, 'FOLD_HEAD': HEAD}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        #: The group of the preview (of the focused row).
        self.group: str = lc.FOLDER_POINTS[0].group

    @property
    def cells(self) -> ListView:
        """Return the list of the rows."""
        return self.find('cells', ListView)

    def built(self) -> None:
        """The buttons of the columns connected (a choice, the focus of the row)."""
        for v, when in enumerate(WHENS):
            cell = self.find(f'cell_{v}', FocusButton)
            cell.focused.connect(self.sync_row)
            cell.clicked.connect(partial(self.choose, when))

    def on_cells_current_changed(self, index: int) -> None:
        """Another row of the list is current (its index)."""
        self.row_shown()

    def group_color(self, group: str) -> str:
        """Return the color of the head of a group: the match color for the group of the preview."""
        return head_color(group, self.group)

    def fill(self) -> None:
        """Show the rows (the controls exist now), the first level current."""
        self.refresh()
        self.cells.current = next(n for n, row in enumerate(self.cells.rows) if not row.head)
        self.row_shown()

    def refresh(self) -> None:
        """Set the rows from the user settings, build the preview (the accounts and the general lists may have changed)."""
        self.cells.rows = [row if row.head else evolve(row, when=lc.folder_when(lc.FOLDER_POINTS[row.index].key)) for row in self.rows()]
        self.show_preview()

    def show_preview(self) -> None:
        """Build the preview of the menu of the group of the focused row, the color of the head of its group."""
        self.find('preview').text = preview_text(self.group)  # type: ignore[attr-defined]
        self.win.bindings.refresh()

    def current_row(self) -> FolderRow | None:
        """Return the current row of the list (None: none yet)."""
        cells = self.cells
        return cells.rows[cells.current] if 0 <= cells.current < len(cells.rows) else None

    def row_shown(self) -> None:
        """Another row is current (or a column got the focus): the help of the columns, the preview of the menu of its group."""
        if (row := self.current_row()) is None:
            return
        point = lc.FOLDER_POINTS[row.index]
        for v, when in enumerate(WHENS):
            self.find(f'cell_{v}', FocusButton).help = '' if row.head else switch_help(point, when)
        self.cells.help = '' if row.head or row.when is None else switch_help(point, row.when)  # the mouse on a row, no column yet
        if point.group != self.group:
            self.group = point.group
            self.show_preview()

    def choose(self, when: When) -> None:
        """A `When` of the current row chosen (its column clicked), written at once; a head (the mouse), the chosen one: nothing."""
        if (row := self.current_row()) is not None and not row.head and row.when is not when:
            lc.set_folder(lc.FOLDER_POINTS[row.index].key, when)
            self.refresh()
            self.row_shown()

    def sync_row(self) -> None:
        """
        Follow the list (a key on a column moved it): on a head of a group, the level after it - a list filled while the window opens starts
        on its first item (Kodi drops an earlier selection) and only the mouse may stop at a head of a group.
        """
        cells = self.cells
        if (control := cells.list_control()) is not None and 0 <= (index := control.getSelectedPosition()) < len(cells.rows):
            cells.current = index + cells.rows[index].head
            cells.apply_property('current')

    def handle_action(self, action: Action) -> bool | None:
        """A key on a button (a move of the list keeps the focus on the buttons): the list followed."""
        self.sync_row()
        return None
