"""
The frames of FF (`resources/skins/widgets/frames.xml`), the Python side: the tags and the edge marks anchored to the edge of their
host (`gui.anchor_place()`) - the data of a tag of a row (`set_tags()`: the list item properties of its key) or of a fixed element
(`Tag.data`: the window properties of the widget), one record (`TagData`) and one naming of its fields either way.
"""

from __future__ import annotations
from typing import Any, Mapping, Sequence, TYPE_CHECKING
from attrs import field, frozen
from . import Property, Widget
from ..gui import window_texture
from ..style import focused_image_variant, tokens
if TYPE_CHECKING:
    from ..gui import AnchorPlace

#: The kinds of a tag: a text, a number (a text of a compact tag), icons.
TAG_KINDS: tuple[str, ...] = ('text', 'number', 'icon')
#: The kinds of an edge mark - a bar along a side, a line along a side, a ribbon in a corner - and their layers by default (`geometry.LAYERS`):
#: a bar / a line under the content of its host (a background of the content), a ribbon over it (a corner sticker).
MARK_KINDS: dict[str, str] = {'bar': 'under', 'line': 'under', 'ribbon': 'over'}
#: The places of the lines of an edge mark across the middle of its host (no side; C is the centre of a sticker - a tag): one horizontal line
#: (H), vertical ones down it (V: as wide as the host, their `length`).
MARK_ACROSS: tuple[str, ...] = ('H', 'V')
#: The widest number of Python a number tag fits (its text unknown at the generation): three digits.
NUMBER_SAMPLE: str = '888'
#: The corners of a host on its sides (the corner mask of `texture_corners()`: top-left 8, top-right 4, bottom-right 2, bottom-left 1).
SIDE_CORNERS: dict[str, int] = {'W': 0b1001, 'N': 0b1100, 'E': 0b0110, 'S': 0b0011}


@frozen(kw_only=True)
class TagData:
    """
    The data of a tag or an edge mark (one record for a row and for a fixed element; Qt: the data of an item): what it shows, the same
    fields under the prefix of its place (`properties()`).
    """

    #: The text of a text / number tag.
    text: str = ''
    #: The image of an icon tag of Python (no static icons), of a ribbon ('' the style `texture.ribbon`), of a line ('' a plain one).
    icon: str = ''
    #: The image of an edge mark on a focused row of another brightness (`focused_image_variant()`: the image in its variant), '' `icon`.
    icon_focused: str = ''
    #: The colour of the icon of Python, of an edge mark ('' the style `color.icon`).
    color: str = ''
    #: The colours of the static icons of a tag (its parameter `icons`) by their names ('': gray - `color.icon.disabled`, none: not shown).
    icons: Mapping[str, str] = field(factory=dict, hash=False)

    def properties(self, prefix: str) -> dict[str, str]:
        """
        Return the properties of the data under the prefix (`<prefix>.shown` true, `.text`, `.icon`, `.icon_focused`, `.color`,
        `.icon.<name>`): a colour '' is the one of the style (Kodi has no default of an info) - the icon `color.icon`, a static icon of no
        colour `color.icon.disabled`; the icon as its full path, of an active theme which has it (`window_texture()`); the icon of a focused
        row only while it is of another brightness (`focused_image_variant()`; its image, else the icon - Kodi takes no other info if one
        is empty).
        """
        style = tokens()
        icon = window_texture(self.icon)
        focused = {f'{prefix}.icon_focused': window_texture(self.icon_focused) or icon} if focused_image_variant() else {}
        return {f'{prefix}.shown': 'true', f'{prefix}.text': self.text, f'{prefix}.icon': icon, **focused,
                f'{prefix}.color': self.color or style.color.icon,
                **{f'{prefix}.icon.{name}': color or style.color.icon.disabled for name, color in self.icons.items()}}


def tag_properties(prefix: str, data: TagData | None) -> dict[str, str]:
    """Return the properties of the data of a tag under the prefix of its place; None: the tag hidden (its other properties kept)."""
    return {f'{prefix}.shown': ''} if data is None else data.properties(prefix)


def set_tags(item: Any, **tags: TagData | None) -> None:
    """Set the data of the tags / edge marks of a row (`item`: its list item) by their keys (`key`, '' the name of the widget; None hidden)."""
    for key, data in tags.items():
        for name, value in tag_properties(f'tag.{key}', data).items():
            item.setProperty(name, value)


@frozen(kw_only=True)
class TagVars:
    """The template data of a tag or an edge mark (`Tag.template_tag()`, `EdgeMark.template_mark()`): its place, its look, its data."""

    #: The kind (`TAG_KINDS`, `MARK_KINDS`).
    kind: str
    #: Its place from its anchor (None: a bar / a line - along a whole side).
    place: AnchorPlace | None
    #: The anchor (`gui.ANCHORS`).
    anchor: str
    #: The layer among the content of its host (`geometry.LAYERS`: under, over, edge).
    layer: str
    #: The properties of its data: `ListItem.Property(tag.<key>` in a row, `Window.Property(ffw.<id>` on a fixed element.
    source: str
    #: The template gives its content: shown always, no data (its colours may come from the data).
    static: bool
    #: The texture of its fill (a tag) / of the mark (its file for its size).
    texture: str = ''
    #: The control of its content: a group (the fill of a tag and its content, its static icons), one label / image (a sticker - a tag of
    #: no background - of a text / of an icon, an edge mark).
    control: str = 'group'
    #: The inner spacing of a tag (0 a sticker).
    pad: int = 0
    #: The text (a static one, else the one of the data).
    text: str = ''
    #: The static icons (their names: `icons/<name>.32.png`).
    icons: tuple[str, ...] = ()
    #: The side of an icon; the size of an edge mark (across its side, a ribbon: its side).
    icon_size: int = 0
    #: A bar / a line: its distance from its side (its slot).
    offset: int = 0
    #: A line: its distance from the ends of its side.
    inset: int = 0
    #: The font role of the text.
    style: str = ''
    #: The Kodi condition of the focus of its parent (its fill `color.bg.tag.focused` then), '' none.
    has_focus: str = ''

    def prop(self, name: str) -> str:
        """Return the info of a field of its data (`$INFO[…]` in a text, a condition)."""
        return f'{self.source}.{name})'

    def info(self, name: str) -> str:
        """Return the label info of a field of its data."""
        return f'$INFO[{self.prop(name)}]'

    @property
    def row(self) -> bool:
        """Return True if it lies in a row of a list (its data: the properties of the list item; no control ID needed)."""
        return self.source.startswith('ListItem.')

    @property
    def point(self) -> bool:
        """Return True if it lies in an anchor point (a group of no size: a middle anchor), else at its place in its host (a corner, a side)."""
        return bool(self.place and self.place.slots)

    @property
    def shown(self) -> str:
        """Return the Kodi condition of a tag with data (`shown`), '' a static one."""
        return '' if self.static else f'String.IsEqual({self.prop("shown")},true)'


def data_source(place: str, key: str, wid: int) -> str:
    """Return the start of the properties of the data of a tag at its place (`widget_place()`): of the list item of a row, else of the window."""
    return f'ListItem.Property(tag.{key}' if place == 'row' else f'Window.Property(ffw.{wid}'


class Tag(Widget):
    """
    A tag (`tag`): a small label on the edge of its host - a text, a number or icons on the surface of the last level (`surface(3)`), or
    with no background (a sticker). On a fixed element its data is `data` (the window properties of the widget); in a row the list item
    properties of its key (`set_tags()`).
    """

    #: The data of the tag on a fixed element (None: hidden, unless its template gives its content).
    data: Property[TagData | None] = Property(None)

    def apply_window_property(self, name: str) -> None:
        """Apply the data to the window properties of the widget (the controls may not exist yet)."""
        if name == 'data':
            for prop, value in tag_properties(f'ffw.{self.id}', self.data).items():
                self.win.setProperty(prop, value)  # type: ignore[attr-defined]

    def apply_property(self, name: str) -> None:
        """Apply the data (window properties), the other properties to the controls."""
        if name == 'data':
            self.apply_window_property(name)
        else:
            super().apply_property(name)

    @classmethod
    def template_tag(cls, *, place: str, key: str, wid: int, anchor: str, out: str, edge: str, slot: int, gap: int | None, layer: str, kind: str,
                     text: str, icon: str, icons: Sequence[str], style: str, width: int, height: int, has_focus: str, bg: str = '',
                     factor: float | None = None) -> TagVars:
        """
        Return the template data of a tag: its size (`height` 0: `metric.tag.height`, a sticker - `bg` none: no background, no padding -
        `metric.mark.icon`; `width` 0 derived - a static text measured, a text of Python `metric.tag.width`, a number as high, wider for its
        text - of Python `NUMBER_SAMPLE` -, the icons by their count), its place from its anchor (`anchor_place()`, how far it sticks out
        `factor` - None the style; a sticker has no side of its host to clear in a corner), the texture of its fill for its size
        (`size_texture()` of `texture.tag`), the control of its content (a sticker of a text / of one icon: one label / image), its data
        (`data_source()`; static: the template gives its text / icons), the font role ('' small, a number tiny), the focus of its parent
        (`has_focus`; a sticker has no fill to change), its layer ('' derived: sticking out of the edge of its host `edge` - over the frame
        of the host, inside or in the centre `over`). A tag flush in a corner (`out` flush) lies in the corner itself, its texture rounded
        only at that corner and the opposite one (a tab of the corner).
        """
        from ..gui import TextureName, anchor_place, size_texture, texture_corners
        from ..skinfonts import text_metrics
        if kind not in TAG_KINDS:
            raise ValueError(f'Unknown kind {kind!r} of a tag (not one of {", ".join(TAG_KINDS)})')
        style_tokens = tokens()
        out = out or style_tokens.tag.out
        layer = layer or ('over' if anchor == 'C' or out in ('inside', 'flush') else 'edge')
        sticker = bg == 'none'
        pad = 0 if sticker else style_tokens.space.pad.tag
        height = height or (style_tokens.metric.mark.icon if sticker else style_tokens.metric.tag.height)
        icon_size = height - 2 * pad
        style = style or ('tiny' if kind == 'number' else 'small')
        if not width:
            if kind == 'icon':
                count = len(icons) or 1
                width = count * icon_size + (count + 1) * pad
            elif kind == 'number':  # a square, wider for its text (a number of Python: up to `NUMBER_SAMPLE`)
                width = max(height, round(text_metrics(style)[0](text or NUMBER_SAMPLE)) + 2 * pad)
            elif text:
                width = round(text_metrics(style)[0](text)) + 2 * pad
            else:
                width = style_tokens.metric.tag.width
        source = data_source(place, key, wid)
        static = bool(text if kind != 'icon' else icon or icons)
        control = 'group' if not sticker or len(icons) > 1 else 'image' if kind == 'icon' else 'label'
        anchored = anchor_place(anchor, width, height, out=out, edge=edge, slot=slot, gap=gap, clear=not sticker and out != 'flush', factor=factor)
        texture = size_texture(style_tokens.texture.tag, width, height)
        if out == 'flush' and len(anchor) == 2 and (corner := TextureName.parse(texture).corner) is not None and corner[1:] != '0':
            opposite = anchor.translate(str.maketrans('NSWE', 'SNEW'))
            texture = texture_corners(texture, SIDE_CORNERS[anchor[0]] & SIDE_CORNERS[anchor[1]] | SIDE_CORNERS[opposite[0]] & SIDE_CORNERS[opposite[1]])
        return TagVars(kind=kind, place=anchored, anchor=anchor, layer=layer, source=source, static=static,
                       texture=texture, control=control, pad=pad,
                       text=text or f'$INFO[{source}.text)]', icons=tuple(icons), icon_size=icon_size, style=style,
                       has_focus='' if sticker else has_focus)


class EdgeMark(Tag):
    """
    An edge mark (`edge_mark`): a bar or a line along a side of its host (a line also across its middle: H, V), a ribbon in its corner, in its
    colour (static, else of its data: `data` on a fixed element, the list item properties of its key in a row - `set_tags()`).
    """

    @classmethod
    def template_mark(cls, *, place: str, key: str, wid: int, kind: str, anchor: str, out: str, slot: int, gap: int | None, size: int, layer: str,
                      color: str, corners: int = 0b1111) -> TagVars:
        """
        Return the template data of an edge mark: a bar / a line on a side (`SIDE_CORNERS`) - its size across it (`size` 0:
        `metric.mark.bar` / `metric.mark.line`), the texture of a bar for its size rounded at the rounded corners of the host (`corners`:
        the mask of `texture_corners()`) on that side, its slot further in by its size and `gap` (None `space.gap.tag`; a line: a gap from
        the side, from its ends by `metric.mark.line.inset`; `out` flush: on the side itself - a line on the side two parts share lies on
        their boundary -, in from its ends as a line inside); one line across the middle (`H`: in from the sides), vertical lines down it
        (`V`: as wide as the host - a narrow one, the joint of two parts -, the height their `length` in the template); a ribbon in a corner -
        its place (`anchor_place()`, `metric.mark.ribbon`), the image of its data mirrored there (a static colour, no data: `texture.ribbon`).
        """
        from ..gui import ANCHORS, anchor_place, size_texture, texture_corners, TextureName
        style = tokens()
        if kind not in MARK_KINDS:
            raise ValueError(f'Unknown kind {kind!r} of an edge mark (not one of {", ".join(MARK_KINDS)})')
        corner, across = len(anchor) == 2, anchor in MARK_ACROSS
        if (anchor not in ANCHORS and not across or anchor == 'C' or corner != (kind == 'ribbon')
                or across and (kind != 'line' or anchor == 'H' and slot != 1)):
            raise ValueError(f'An edge mark {kind} on {anchor!r} (slot {slot}): a ribbon lies in a corner, a bar / a line on a side, one line '
                             'across the middle (H), lines down it (V); C is the centre of a sticker (a tag)')
        source, static, layer = data_source(place, key, wid), bool(color), layer or MARK_KINDS[kind]
        if kind == 'ribbon':
            size = size or style.metric.mark.ribbon
            return TagVars(kind=kind, place=anchor_place(anchor, size, size, out=out, slot=slot, gap=gap), anchor=anchor, layer=layer,
                           source=source, static=static, texture=style.texture.ribbon, control='image', icon_size=size)
        if kind == 'bar':
            size = size or style.metric.mark.bar
            texture = size_texture(style.texture.tag, *((size, 0) if anchor in 'WE' else (0, size)))
            if (corner := TextureName.parse(texture).corner) is not None and corner[1:] != '0':  # rounded / chamfered: its corners on the side
                texture = texture_corners(texture, SIDE_CORNERS[anchor] & corners)
        else:
            size, texture = size or style.metric.mark.line, 'white.png'
        gap = style.space.gap.tag if gap is None else gap
        offset = (slot - 1) * (size + gap) + (gap if kind == 'line' else 0)
        inset = offset - gap + style.metric.mark.line.inset if kind == 'line' else 0  # a line: its ends in by the token, not by the gap
        if kind == 'line' and out == 'flush':
            offset -= gap
        return TagVars(kind=kind, place=None, anchor=anchor, layer=layer, source=source, static=static, texture=texture, control='image',
                       icon_size=size, offset=offset, inset=inset)
