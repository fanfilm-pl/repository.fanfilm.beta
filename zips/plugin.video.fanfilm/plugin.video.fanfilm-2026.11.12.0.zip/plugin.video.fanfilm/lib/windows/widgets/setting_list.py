"""
A list of settings (`resources/skins/widgets/setting_list.xml`; Qt: the rows of a QFormLayout): a row is a declared setting
(`CatalogSetting`, `lib.sources.natives`) with the place of its value - its label, its value on the right (a colour: its sample at
the end, a choice of a list: its combo box in the row, yes / no: its switch); OK edits it by its kind and writes it at once, the
context menu sets its default. The panel of the source providers and the page of the sources show their settings by it.
"""

from __future__ import annotations
from typing import Any, Callable, Sequence, TYPE_CHECKING
from attrs import frozen
from .basic import Slider
from .views import ComboBox, ListView
from ...ff.signals import ClassSignal
from ...kolang import L
if TYPE_CHECKING:
    from xbmcgui import Action
    from ...sources.natives import CatalogSetting

#: The font style of the colour sample of a row (`swatch()`: the symbol font if Kodi has it), the `ff:style` of its label in the
#: template (read as it is, not a template field).
SWATCH_STYLE = 'small.symbol'
#: The kinds of a setting with no value of their own (no default to set): an action (OK runs it), a state of the provider (read only).
NO_VALUE_KINDS: frozenset[str] = frozenset({'action', 'state'})
#: The kinds of the settings edited by the slider of the list (two knobs, one knob).
SLIDER_KINDS: tuple[str, ...] = ('range', 'scale')
#: The most of a row its value takes (the rest: its label, cut with an ellipsis), a part of the row; also the value of a text, a path.
VALUE_PART: float = .45
#: The digits of a colour code (`AARRGGBB`): its width - eight of the widest one.
COLOR_DIGITS: str = '0123456789ABCDEF'


def swatch(color: str) -> str:
    """Return the colour sample of a colour value (the row property `swatch`, right of its text), '' - none (the default colour)."""
    if not color:
        return ''
    from ..skinfonts import symbol
    return f'[COLOR {color}]{symbol("square", SWATCH_STYLE) * 3}[/COLOR]'


def swatch_width() -> int:
    """Return the width of the colour sample of a row and of a space before it."""
    from ..skinfonts import text_metrics
    width_of, _ = text_metrics(SWATCH_STYLE)
    space_width, _ = text_metrics('small')
    return round(width_of(swatch('FFFFFFFF')) + space_width(' '))


def setting_text(setting: CatalogSetting, value: Any) -> str:
    """Return the value of a setting as the text of its row."""
    kind = setting['kind']
    if kind == 'bool':
        return L(30736, 'Yes') if value else L(30752, 'No')
    if kind == 'select':
        return next((opt['label'] for opt in setting.get('options', ()) if opt['value'] == value), str(value))
    if kind == 'password':
        return '***' if value else ''  # never shown in the list (only while it is edited)
    if kind == 'color':
        return L(30753, 'Default') if value in ('', setting.get('default', '')) else value  # its sample: swatch()
    if kind == 'action':
        return ''
    if kind == 'range':
        return setting['scale'].range_text(*setting['scale'].range_positions(*value))
    if kind == 'scale':
        return setting['scale'].text(setting['scale'].position_of(value))
    return str(value)


@frozen(kw_only=True)
class SettingLine:
    """The texts of a row of a list of settings (its list item: `SettingList.rows`)."""

    #: The label.
    label: str
    #: The value.
    value: str
    #: The colour sample after the value ('' none, `swatch()`).
    swatch: str
    #: A choice of a list (a usable setting `select`): its combo box in the row.
    choice: bool = False
    #: A range (a usable setting `range`): its slider in the row.
    slider: bool = False
    #: The value of yes / no (a setting `bool`; `pass` / `block` of a switch which blocks): its switch in the row (the state word of the row,
    #: `CHECK_PROPERTY`); None another kind.
    checked: bool | str | None = None
    #: The row can be used (else grayed: its label the background text, its switch faded).
    usable: bool = True

    @property
    def dim(self) -> bool:
        """Return True for a grayed row (the role `dim` of `row_text`: its label the background text)."""
        return not self.usable


@frozen(kw_only=True)
class SettingRow:
    """
    A row of a list of settings: the declared setting and the place of its value (read, written; the default of the declaration is
    the value its context menu sets).
    """

    #: The setting.
    setting: CatalogSetting
    #: Read the value.
    get: Callable[[], Any]
    #: Write the value.
    set: Callable[[Any], None]
    #: The row can be used (else grayed, its help tells why: `reason`).
    usable: bool = True
    #: Why the row can not be used ('' it can).
    reason: str = ''
    #: The shown text and the colour of its sample instead of the value (e.g. a node of a tree: its effective value and its origin).
    shown: Callable[[], tuple[str, str]] | None = None
    #: The colour "Default" of the colour picker stands for (None: no button Default; '' none).
    color_default: Callable[[], str] | None = None
    #: What OK on a row of an action does (None: the builtin `action` of its setting).
    run: Callable[[], None] | None = None

    def line(self) -> SettingLine:
        """Return the texts of the row: its label, its value (or `shown`), the sample of a colour."""
        setting = self.setting
        checked = None
        if self.shown is not None:
            text, color = self.shown()
        else:
            value = self.get()
            text, color = setting_text(setting, value), ''
            if setting['kind'] == 'color':  # the sample of the colour in effect (the default one: the colour it stands for)
                color = str(value or '') or (self.color_default() if self.color_default is not None else '')
            elif setting['kind'] == 'bool':
                checked = bool(value) if not setting.get('negative') else 'pass' if value else 'block'
        return SettingLine(label=setting['label'], value=text, swatch=swatch(color), choice=setting['kind'] == 'select' and self.usable,
                           slider=setting['kind'] in SLIDER_KINDS and self.usable, checked=checked,
                           usable=self.usable)

    def help(self) -> str:
        """Return the help of the row (for a grayed one: why)."""
        return self.reason or self.setting.get('help') or L(30761, 'OK: change it.')

    def resettable(self) -> bool:
        """Return True if the context menu can set the default of the row (a usable value not the default one)."""
        return self.usable and self.setting['kind'] not in NO_VALUE_KINDS and self.get() != self.setting['default']


class SettingList(ListView):
    """
    A list of settings (`settings`: `SettingRow` records; its rows: their texts): OK edits a row by its kind and writes it at once (a choice
    of a list: its list under the row), the context menu sets its default; `edited(index)` after a written value.
    """

    #: A value of a row is written: its index.
    edited: ClassSignal = ClassSignal()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The list: no settings yet."""
        super().__init__(*args, **kwargs)
        #: The settings of the rows.
        self.settings: Sequence[SettingRow] = ()

    @classmethod
    def template_swatch_width(cls) -> int:
        """Return the width of the colour sample of a row and of a space before it (the template)."""
        return swatch_width()

    @classmethod
    def template_range_scale(cls, settings: Sequence[CatalogSetting]) -> Any:
        """Return the scale of the slider of the `settings` (the template: a list has one), None: no such setting."""
        return next((setting['scale'] for setting in settings if setting['kind'] in SLIDER_KINDS), None)

    @classmethod
    def template_range_mode(cls, settings: Sequence[CatalogSetting]) -> str:
        """Return the mode of the slider of the `settings` (the template): two knobs of a range, else one."""
        return 'range' if next((setting['kind'] for setting in settings if setting['kind'] in SLIDER_KINDS), '') == 'range' else 'max'

    @classmethod
    def template_value_width(cls, settings: Sequence[CatalogSetting], width: int) -> int:
        """
        Return the width of the value of a row of the list `width` wide (the template): the widest value the `settings` can show in the font
        of a value (a choice of a list: its field - the text and its arrow -, a colour: its code and its sample, a number: its maximum; a text
        measured: a step more, Kodi cuts a text as wide as its label) or a switch of yes / no, at most `VALUE_PART` of the row - also for a
        text, a path, a state or no settings (a list of any settings). The `settings` of the lists of one column: their values aligned.
        """
        from math import ceil
        from ..gui import toggle_vars
        from ..skinfonts import text_metrics
        from ..style import tokens
        style = tokens()
        most = int(width * VALUE_PART)
        width_of, _ = text_metrics('small')

        def text(*texts: str) -> int:
            """Return the width of the widest of the texts and a step of the slack."""
            return ceil(max((width_of(txt) for txt in texts), default=0)) + style.space.s

        field = 2 * style.space.l + style.space.xl + style.space.m  # the field of a choice: its padding, its arrow (`combo_box`)
        need = 0 if settings else most
        for setting in settings:
            kind = setting['kind']
            if kind == 'bool':
                need = max(need, toggle_vars().width)
            elif kind == 'select':
                need = max(need, text(*(opt['label'] for opt in setting.get('options', ()))) + field)
            elif kind == 'color':
                need = max(need, text(max(COLOR_DIGITS, key=width_of) * 8, L(30753, 'Default')) + swatch_width())
            elif kind == 'int':
                need = max(need, text(str(setting.get('maximum', 99999))))
            elif kind == 'range':
                widest = setting['scale'].text(setting['scale'].last)
                need = max(need, text(f'{widest}–{widest}') + field)
            elif kind == 'scale':
                need = max(need, text(setting['scale'].text(setting['scale'].last)) + field)
            elif kind != 'action':
                need = most
        return min(need, most)

    def built(self) -> None:
        """OK edits a row; the help of the list is the one of its current row."""
        from ..base import weak_callback
        super().built()
        self.activated.connect(weak_callback(self.edit))
        self.current_changed.connect(weak_callback(self.show_help))
        if 'range' in self.children:  # only a list with a setting of a range has its slider
            self.range.committed.connect(weak_callback(self.range_committed))

    def show_help(self, pos: int = -1) -> None:
        """The help of the list: the one of the current row (the footer of the window follows it)."""
        self.help = self.help_of_row()

    @property
    def choice(self) -> ComboBox:
        """Return the combo box of the choices of a row of a list (`select`)."""
        return self.find('choice', cls=ComboBox)

    @property
    def range(self) -> Slider:
        """Return the slider of a range of a row (`range`)."""
        return self.find('range', cls=Slider)

    def show(self, settings: Sequence[SettingRow], pos: int | None = None) -> None:
        """Show the settings with the row `pos` selected (None: the current one)."""
        pos = self.current if pos is None else pos
        self.settings = settings
        self.rows = [row.line() for row in settings]
        if settings:
            self.current = max(0, min(pos, len(settings) - 1))
        self.show_help()

    def help_of_row(self, pos: int | None = None) -> str:
        """Return the help of the row `pos` (None: the current one)."""
        pos = self.current if pos is None else pos
        return self.settings[pos].help() if 0 <= pos < len(self.settings) else ''

    def edit(self, pos: int) -> None:
        """Edit the setting of the row `pos` by its kind (an action: run it) and write it at once."""
        from xbmc import executebuiltin
        from xbmcgui import Dialog
        from ...ff.ui import ui
        from const import const
        if not 0 <= pos < len(self.settings) or not (row := self.settings[pos]).usable:
            return
        setting = row.setting
        kind, label = setting['kind'], setting['label']
        if row.run is not None:
            row.run()
            return
        if action := setting.get('action'):
            executebuiltin(action)
            return
        value, new = row.get(), None
        if kind == 'bool':
            new = not value
        elif kind in ('text', 'password'):
            if (text := ui.input(label, str(value), hidden=kind == 'password' and const.dialog.config.hide_passwords)) is not None:
                new = text.strip()
        elif kind == 'int':
            if text := Dialog().numeric(0, label, str(value)):
                new = max(setting.get('minimum', int(text)), min(setting.get('maximum', int(text)), int(text)))
        elif kind == 'select':  # its list under the row: `on_choice_activated()`
            options = setting.get('options', [])
            combo = self.choice
            combo.items = [opt['label'] for opt in options]
            combo.open(next((n for n, opt in enumerate(options) if opt['value'] == value), -1))
            return
        elif kind in SLIDER_KINDS:  # its slider on a card at the row: `range_committed()`
            self.range.open(tuple(value) if kind == 'range' else value)
            return
        elif kind == 'color':
            from ..color_picker import ColorPlace, pick_color
            before = value
            default = setting.get('default', '')  # its value: the default one of the picker ('')
            pick_color(ColorPlace(get=lambda: '' if (color := row.get()) in ('', default) else str(color), set=lambda color: row.set(color or default),
                                  default=row.color_default() if row.color_default is not None else None), label)
            if row.get() != before:
                self.written(pos)
            return
        elif kind == 'path':
            new = Dialog().browse(1, label, 'files', '', False, False, str(value)) or None
        if new is not None:  # None: cancelled
            self.write(pos, new)

    def write(self, pos: int, new: Any) -> None:
        """Write the new value of the row `pos` (the same one: nothing)."""
        row = self.settings[pos]
        if new != row.get():
            row.set(new)
            self.written(pos)

    def written(self, pos: int) -> None:
        """A value of the row `pos` written: the rows again (one value can show in another row), `edited`."""
        self.show(self.settings, pos)
        self.edited.emit(pos)

    def on_choice_activated(self, index: int) -> None:
        """An option of the list of a row chosen: written at once."""
        pos = self.choice.row
        if 0 <= pos < len(self.settings) and 0 <= index < len(options := self.settings[pos].setting.get('options', [])):
            self.write(pos, options[index]['value'])

    def range_committed(self, value: Sequence[Any]) -> None:
        """The slider of a row set: written at once."""
        self.write(self.range.row, list(value) if self.range.is_range() else value)

    def reset(self, pos: int) -> None:
        """Set the default of the row `pos` (the context menu)."""
        if 0 <= pos < len(self.settings):
            self.write(pos, self.settings[pos].setting['default'])

    def handle_action(self, action: Action) -> bool | None:
        """A move: the list follows its selection (the help of its row); the context menu of a row: its default (only if it has another value)."""
        from ..base import MENU_ACTIONS
        super().handle_action(action)
        if action.getId() not in MENU_ACTIONS:
            return None
        pos = self.current
        if 0 <= pos < len(self.settings) and self.settings[pos].resettable():
            from functools import partial
            from ..base import weak_callback
            from ..context import ContextMenuDialog
            ContextMenuDialog(menu=[(L(30753, 'Default'), partial(weak_callback(self.reset), pos))]).doModal()
        return True
