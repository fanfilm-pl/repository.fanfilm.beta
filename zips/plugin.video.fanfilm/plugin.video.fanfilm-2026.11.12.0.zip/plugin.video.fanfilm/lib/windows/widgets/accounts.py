"""
The page of accounts of the configuration window (`resources/skins/widgets/accounts.xml`): the list of accounts, the tools
(add, remove, up, down, sync all) and the panel of the account of the list; an icon button (the tools) and a field button.

The view of the model `lib.ff.account_admin` by the operations of the accounts (`lib.windows.accounts`: the panel, the actions,
the switches, the watch of the sync): every change is written at once and the page shows the new state.
A grayed control keeps the focus (disabled with its reason), the footer tells why. The sync runs in the service: a thread shows
its state while the window is open (it keeps the page, the page keeps the window weakly).
"""

from __future__ import annotations
from functools import partial
from threading import RLock
from typing import Any, TYPE_CHECKING
from .buttons import PushButton
from .tabs import TabPage
from ..style import tokens
from ..accounts import (ACTIONS, TOOL_ACTIONS, AccountListRow, AccountPanel, accounts_layout, cell_help_text, run_action, run_switch,
                        watch_sync_state)
from ...ff import account_admin as admin
from ...ff.accounts import LIST_MENU_IDS
from ...kolang import L
if TYPE_CHECKING:
    from xbmcgui import ControlImage
    from .views import ListView

#: The buttons of the actions on the account (the names of their widgets and of their actions): the tools, the label, the actions, "Active".
BUTTONS: tuple[admin.AccountAction, ...] = (*TOOL_ACTIONS, 'label', *ACTIONS, 'active')


class ToolButton(PushButton):
    """A button of an icon: a grayed one (disabled with its reason) has a gray icon."""

    def apply_property(self, name: str) -> None:
        """Apply the gray look to the icon."""
        if name in ('enabled', 'reason'):
            icon: ControlImage | None = self.control('icon')  # type: ignore[assignment]
            if icon is not None:
                icon.setColorDiffuse(tokens().color.icon if self.enabled else tokens().color.text.disabled)
        super().apply_property(name)


class FieldButton(PushButton):
    """A button of a value to change (a text field look)."""


class AccountsPage(TabPage):
    """The page of accounts."""

    WIDGET = 'accounts_page'
    DEFAULT = 'list'
    TOP = 'label'  # the top of the panel (its moves up go to "Close")
    BOTTOM = f'menu_{len(LIST_MENU_IDS) - 1}'  # the last menu of lists, above "Close"

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """The structure of the page (`accounts_layout()`), the sync property of the service, the texts."""
        from ...ff.sync import SYNC_PROPERTY
        return {'ACCOUNTS_LAYOUT': accounts_layout(), 'ACCOUNTS_SYNC_PROPERTY': SYNC_PROPERTY,
                'ACCOUNTS_LABEL': L(32869, 'Account label'), 'ACCOUNTS_SHOWN_IN': L(30197, 'Shown in')}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        lay = accounts_layout()
        #: The rows of the list (of the model).
        self.rows: list[admin.AccountRow] = []
        #: The panel of the account of the list (the cell bindings of the template read it).
        self.panel: AccountPanel = AccountPanel()
        #: The account to select when the page is filled (None: the first one).
        self.select_id: str | None = None
        #: The switch cells by the names of their widgets (the grid, the menus).
        self.cells: dict[str, str] = {
            **{f'cell_{cap.index}_{d.index}': f'{cap.name}.{d.name}' for cap in lay.capabilities for d in lay.directions},
            **{f'menu_{menu.index}': f'menu.{menu.name}' for menu in lay.menus}}
        #: The capabilities by the names of their labels (grayed if the account has none of their cells).
        self.capabilities: dict[str, str] = {f'capability_{cap.index}': cap.name for cap in lay.capabilities}
        #: The directions.
        self.directions: tuple[str, ...] = tuple(d.name for d in lay.directions)
        self._showing: bool = False  # the page sets the list (not the user)
        self._lock: RLock = RLock()  # the panel is shown by the window and by the watch of the sync

    @property
    def list_view(self) -> ListView:
        """Return the list of accounts."""
        return self.find('list')  # type: ignore[return-value]

    def built(self) -> None:
        """The buttons and the switches connected, the help of the list, the texts of the labels of the switches (grayed when disabled)."""
        self.list_view.help = L(32911, 'The accounts in their order: the order is the priority, the first account of a service is its default one.')
        for name, cell in self.cells.items():
            if cell.startswith('menu.'):
                self.find(name).text = admin.menu_label(cell.partition('.')[2])  # type: ignore[attr-defined]
        for name, capability in self.capabilities.items():
            self.find(name).text = admin.capability_label(capability)  # type: ignore[attr-defined]
        for action in BUTTONS:
            if action != 'active':
                self.find(action).clicked.connect(partial(run_action, self, action))
        for name, cell in {'active': 'active', **self.cells}.items():
            self.find(name).toggled.connect(partial(run_switch, self, cell))  # type: ignore[attr-defined]

    def fill(self) -> None:
        """Fill the list and the panel (the controls exist now), watch the sync."""
        from ...ff.threads import Thread
        self.show_accounts(select=self.select_id)
        Thread(target=watch_sync_state, args=(self, self._update_if_open), name='accounts-sync-watch', daemon=True).start()

    def refresh(self) -> None:
        """Show the accounts again (shown again after a change)."""
        self.show_accounts(select=self.panel.account.id if self.panel.account else None)

    # --- the view ---

    def show_accounts(self, *, select: str | None = None) -> None:
        """Show the accounts again (after a change) with the account `select` (else the same place in the list)."""
        with self._lock:
            self.rows = admin.account_rows()
            view = self.list_view
            index = view.current
            if select is not None:
                index = next((i for i, row in enumerate(self.rows) if row.account.id == select), index)
            self._showing = True
            try:
                view.rows = [AccountListRow.of(row) for row in self.rows]
                view.current = max(0, min(index, len(self.rows) - 1))
            finally:
                self._showing = False
            self._show_panel()

    def show_panel(self) -> None:
        """Show the panel of the account selected in the list."""
        with self._lock:
            self._show_panel()

    def focus_action(self, action: admin.AccountAction) -> None:
        """Move the focus to the button of the action of the panel (only while the window is open)."""
        with self._lock:
            if self.win.wait_ready(0):
                self.win.set_focus(self.find(action).id)

    def _update_if_open(self) -> None:
        """Show the panel again for the watch of the sync (its thread): only while the window is open (no Kodi call after it closed)."""
        with self._lock:
            if self.win.wait_ready(0):
                self._show_panel()

    def _show_panel(self) -> None:
        """Show the panel of the account selected in the list (under the lock)."""
        current = self.list_view.current
        self.panel = panel = AccountPanel.of(self.rows[current].account) if 0 <= current < len(self.rows) else AccountPanel()
        acc = panel.account
        self.find('icon').texture = panel.icon  # type: ignore[attr-defined]
        self.find('title').text = panel.title  # type: ignore[attr-defined]
        self.find('info').text = panel.info  # type: ignore[attr-defined]
        self.find('summary').text = panel.summary  # type: ignore[attr-defined]
        for action in BUTTONS:
            button = self.find(action)
            view = panel.actions.get(action)
            available = view is not None and view.available
            button.help = view.help if view is not None else ''
            button.reason = '' if available else button.help
            button.enabled = available
            if view is not None and (action in ACTIONS or action == 'active'):
                button.text = view.label  # type: ignore[attr-defined]
        self.find('label').text = panel.label  # type: ignore[attr-defined]
        self.find('active').checked = acc is not None and acc.active  # type: ignore[attr-defined]
        self.find('sync_queued').visible = bool(panel.sync) and panel.sync != 'running'
        self.find('sync_running').visible = panel.sync == 'running'
        for name, cell in self.cells.items():
            box = self.find(name)
            view = panel.cells.get(cell)
            box.checked = view is not None and view.value  # type: ignore[attr-defined]
            box.help = cell_help_text(cell, view) if view is not None else ''
            box.enabled = view is not None and view.available
            box.reason = '' if box.enabled else box.help or admin.cell_label(cell)  # a cell the account has not: grayed, keeps the focus
        for name, capability in self.capabilities.items():
            self.find(name).enabled = any(f'{capability}.{d}' in panel.cells for d in self.directions)
        self.win.bindings.refresh()  # the cells shown (the bindings read the panel)
        self.win.on_focus(self.win.focused_id())  # the help of the focused control may have changed

    # --- events ---

    def on_list_current_changed(self, index: int) -> None:
        """A move in the list shows the panel of the new account."""
        if not self._showing:
            self.show_panel()
