"""
The page of the appearance of the configuration window (`resources/skins/widgets/appearance.xml`): the active themes in their order
(the base one last, fixed) with the tools add / remove / up / down, the variant of the themes, the switch of the colours of the skin
(`theme.skin_colors_chosen()`) and the adjustable tokens of the style
(`Token.adjustable`, in the order of `TOKENS`: a colour - the colour picker, a factor - a slider in a field, a font - a combo box) with the mark "modified"
while the local style sets them, a line about the other tokens the local style changes.

Every change is written at once (the themes, the variant: `lib.ff.theme`; a token: `set_local_token()`) and the window is opened
again (`BaseDialog.reopen()`): its XML is generated of the new style, the focus on the changed row, the same theme selected.
"""

from __future__ import annotations
from functools import partial
from math import ceil
from typing import Any, TYPE_CHECKING, cast
from typing_extensions import Literal, TypeAlias
from attrs import frozen
from .tabs import TabPage
from .views import ComboItem
from ..scale import Scale, ScaleValue
from ..style import (SKIN, TOKENS, Layer, Style, StyleError, Token, TokenValue, check_style, layered_style, local_style_files, read_layer, remove_local_tokens,
                     set_local_token, skin_accent, style_files, tokens)
from ...ff import theme
from ...kolang import L
if TYPE_CHECKING:
    from .basic import FormField, Image, Slider, TextBox
    from .buttons import CheckBox
    from .views import ComboBox, ListView

#: The kind of a row of the form: the variant of the themes, the switch of the colours of the skin (a check box), the kind of its
#: token - a colour (its button, the colour picker), a factor (a slider in a field), a font (a combo box).
RowKind: TypeAlias = Literal['variant', 'switch', 'color', 'factor', 'font']
#: The tools of the list of the themes: the names of their widgets -> their icons, in their order.
TOOLS: dict[str, str] = {'add': 'plus', 'remove': 'minus', 'up': 'up', 'down': 'down'}
#: The values of a factor token to choose (`space.density`: the density of the spacing).
FACTORS: tuple[float, ...] = (.8, .9, 1.0, 1.1, 1.25)
#: The name of the row of the variant of the themes (its widget).
VARIANT_ROW: str = 'variant'
#: The name of the row of the switch of the colours of the skin (its widget).
SKIN_COLORS_ROW: str = 'skin_colors'
#: The width of the list of the themes.
LIST_WIDTH: int = 480


@frozen(kw_only=True)
class FormRow:
    """A row of the form of the page (the template vars): the variant of the themes, the colours of the skin or an adjustable token."""

    #: The name of its widget (a form field).
    name: str
    #: The label.
    label: str
    #: The kind of its field.
    kind: RowKind
    #: The token ('' the variant of the themes, the colours of the skin).
    token: str = ''

    @property
    def field(self) -> str:
        """
        Return the path of the focusable control of the row in the page: the button of a colour, the field of a slider, the check
        box, the field of a combo box.
        """
        return f'{self.name}.value' if self.kind in ('color', 'factor', 'switch') else f'{self.name}.value.field'

    @property
    def help(self) -> str:
        """Return the help of the field of the row (the language of the call)."""
        helps = {'variant': L(30562, 'The variant of the themes: automatic by the brightness of the text of the skin, or one of the variants of the themes.'),
                 'switch': L(30812, 'The colour of the focus of the skin as the accent of the windows (made readable), the rest of the variant.'),
                 'color': L(30571, 'OK: choose the colour and its opacity; "Default" of the colour picker: the colour of the themes.'),
                 'factor': L(30563, 'The spacing of the windows (100 %: as designed).'),
                 'font': L(30570, 'The size of the text of the windows (a font of the skin); the small text and the titles follow it.')}
        return helps[self.kind]


@frozen(kw_only=True)
class ThemeRow:
    """A row of the list of the active themes as shown."""

    #: The add-on ID.
    id: str
    #: The name (a theme not installed: its ID).
    title: str
    #: A theme not installed: its title in the background text (`row_text`).
    dim: bool
    #: The description and the note (not installed, disabled in Kodi, the base one always the last one).
    info: str
    #: The preview image ('' none).
    icon: str

    @classmethod
    def of(cls, theme_id: str, themes: dict[str, theme.ThemeInfo]) -> ThemeRow:
        """Return the shown row of the active theme (`themes`: the installed ones by their IDs)."""
        info = themes.get(theme_id)
        note = theme.theme_note(theme_id, themes)
        return ThemeRow(id=theme_id, title=info.name if info is not None else theme_id, dim=info is None, info=' · '.join(text for text in (info.description if info else '', note) if text),
                        icon=info.window_image if info is not None else '')


def form_rows() -> list[FormRow]:
    """
    Return the rows of the form: the variant of the themes, the switch of the colours of the skin, the adjustable tokens in their order (a
    colour: its button, a factor: a slider, else a combo box; a value of the colours of the skin told by its label).
    """
    origins = tokens().origins

    def label(token: Token) -> str:
        """Return the label of the row of the token."""
        text = token.label() if token.label else token.name
        return L(30814, '{label} (skin colour)', label=text) if origins[token.name] == SKIN else text

    return [FormRow(name=VARIANT_ROW, label=L(30509, 'Variant'), kind='variant'),
            FormRow(name=SKIN_COLORS_ROW, label=L(30813, 'Skin colours'), kind='switch'),
            *(FormRow(name=token.name.replace('.', '_'), label=label(token), kind=cast(RowKind, token.kind), token=token.name)
              for token in TOKENS if token.adjustable)]


def factor_scale(value: float) -> Scale:
    """Return the scale of a factor token: the values to choose (`FACTORS`) and its value now (e.g. one set by hand), in percent."""
    return Scale(values=tuple(ScaleValue(factor, f'{round(factor * 100)} %') for factor in sorted({*FACTORS, value})))


def lower_style() -> Style:
    """
    Return the style of the layers under the local style (the declaration, the colours of the skin, the themes) of the chosen variant: a
    token as it is without the local style.
    """
    variant = theme.chosen_variant()
    local = set(local_style_files(variant))
    return layered_style((Layer(path, read_layer(path)) for path in style_files(variant) if path not in local), variant, skin_accent())


def write_token(name: str, value: TokenValue | None) -> None:
    """Write the value of the token into the local style; its value without the local style (or None) removes it from there."""
    set_local_token(name, None if value is None or value == lower_style().values[name] else value)


class AppearancePage(TabPage):
    """The page of the appearance: the themes, the variant, the colours of the skin, the adjustable tokens of the style."""

    WIDGET = 'appearance_page'
    DEFAULT = 'list'
    DEFAULTS = (theme.THEMES_CONFIG, theme.VARIANT_CONFIG, theme.SKIN_COLORS_CONFIG)

    @classmethod
    def top_path(cls) -> str:
        """Return the top control of the page: the field of its first row (the variant)."""
        return form_rows()[0].field

    @classmethod
    def bottom_path(cls) -> str:
        """Return the bottom control of the page: the field of its last row."""
        return form_rows()[-1].field

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """
        The rows of the form, the scales of their factors (by the tokens: their values now), the width of their labels (the longest one in
        the normal font), of their fields (two buttons: a long variant label), of the list of the themes.
        """
        from ..skinfonts import text_metrics
        rows = form_rows()
        width_of, _ = text_metrics('normal')
        style = tokens()
        return {'APPEARANCE_ROWS': rows, 'APPEARANCE_TOOLS': TOOLS, 'APPEARANCE_LIST_WIDTH': LIST_WIDTH,
                'APPEARANCE_SCALES': {row.token: factor_scale(float(style.values[row.token])) for row in rows if row.kind == 'factor'},
                'APPEARANCE_LABEL_WIDTH': ceil(max(width_of(row.label) for row in rows)) + style.space.l,
                'APPEARANCE_FIELD_WIDTH': 2 * style.metric.button.width}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet (the themes are read when it is shown)."""
        super().__init__(*args, **kwargs)
        #: The installed themes by their IDs.
        self.themes: dict[str, theme.ThemeInfo] = {}
        #: The rows of the list of the themes.
        self.rows: list[ThemeRow] = []
        #: The theme selected in the list (None: the first one).
        self.select_id: str | None = None
        #: The themes the add tool offers (installed, not active).
        self.free: list[theme.ThemeInfo] = []
        self._showing: bool = False  # the page sets the list (not the user)

    @property
    def list_view(self) -> ListView:
        """Return the list of the themes."""
        return self.find('list')  # type: ignore[return-value]

    def combo(self, row: FormRow) -> ComboBox:
        """Return the combo box of a row of a choice."""
        return self.find(f'{row.name}.value')  # type: ignore[return-value]

    def switch(self, row: FormRow) -> CheckBox:
        """Return the check box of a row of a switch."""
        return self.find(row.field)  # type: ignore[return-value]

    def slider(self, row: FormRow) -> Slider:
        """Return the slider of a row of a factor."""
        return self.find(f'{row.name}.value')  # type: ignore[return-value]

    def built(self) -> None:
        """The tools, the colour buttons, the sliders and the combo boxes connected; the helps."""
        self.list_view.help = L(30557, 'The active themes in their order: an image, a style token of the first one which has it; '
                                       'the base one is always the last one.')
        self.find('add').help = L(30558, 'Add an installed theme at the top (the most important one).')
        self.find('remove').help = L(30559, 'Remove the theme (its add-on stays installed).')
        self.find('up').help = L(30560, 'Move the theme up (more important).')
        self.find('down').help = L(30561, 'Move the theme down (less important).')
        for name in TOOLS:
            self.find(name).clicked.connect(self.offer_themes if name == 'add' else partial(self.tool, name))
        self.find('add_theme').activated.connect(self.add_chosen)  # type: ignore[attr-defined]
        for row in form_rows():
            if row.kind == 'color':
                button = self.find(row.field)
                button.help = row.help
                button.clicked.connect(partial(self.pick_color, row.token, row.label))
            elif row.kind == 'factor':
                self.slider(row).help = row.help
                self.slider(row).committed.connect(partial(self.choose_factor, row))  # type: ignore[attr-defined]
            elif row.kind == 'switch':
                self.switch(row).help = row.help
                self.switch(row).toggled.connect(partial(self.choose_switch, row))
            else:
                self.combo(row).help = row.help
                self.combo(row).activated.connect(partial(self.choose, row))  # type: ignore[attr-defined]

    def fill(self) -> None:
        """Read the installed themes, show the list and the form (the controls exist now)."""
        self.themes = {info.id: info for info in theme.found_themes()}
        self.show_themes()
        self.show_form()

    def refresh(self) -> None:
        """Show the page again (another page changed something)."""
        self.fill()

    def reopen_state(self) -> dict[str, Any]:
        """Return the state of the page of an open again: the selected theme."""
        return {'theme': self.select_id or ''}

    def restore(self, state: dict[str, Any]) -> None:
        """Select the theme of the closed window."""
        self.select_id = state.get('theme') or None

    def reopen(self, focus: str) -> None:
        """
        Open the window again with the focus on a control of the page (after a choice of a drop-down list: the focus goes back to its
        field later, the list has it now).
        """
        self.win.reopen({**self.win.reopen_state(), 'focus': self.find(focus).path, 'control': ''})

    # --- the themes ---

    def show_themes(self) -> None:
        """Show the active themes (the base one last) with the theme `select_id` selected (else the first one), the tools of its row."""
        self.rows = [ThemeRow.of(theme_id, self.themes) for theme_id in (*theme.active_themes(), theme.BASE_THEME)]
        self.free = theme.free_themes(self.themes.values())
        view = self.list_view
        self._showing = True
        try:
            view.rows = self.rows
            view.current = current = next((i for i, row in enumerate(self.rows) if row.id == self.select_id), 0)
        finally:
            self._showing = False
        self.select_id = self.rows[current].id
        self.show_tools()

    def show_tools(self) -> None:
        """The tools of the selected theme: a grayed one keeps the focus, the footer tells why."""
        current, last = self.list_view.current, len(self.rows) - 2  # the last active theme (the base one after it)
        base = L(30576, 'The base theme is always the last one.')
        reasons = {'add': '' if self.free else L(30578, 'No other theme is installed.'),
                   'remove': base if current > last else '',
                   'up': base if current > last else L(30579, 'The theme is the first one.') if current == 0 else '',
                   'down': base if current > last else L(30580, 'The theme is the last active one.') if current == last else ''}
        for name, reason in reasons.items():
            tool = self.find(name)
            tool.reason = reason
            tool.enabled = not reason
        self.win.on_focus(self.win.focused_id())  # the help of the focused control may have changed

    def selected(self) -> str | None:
        """Return the ID of the selected active theme (None: the base one, none)."""
        current = self.list_view.current
        return self.rows[current].id if 0 <= current < len(self.rows) - 1 else None

    def offer_themes(self) -> None:
        """The add tool: the list of the installed themes which are not active (a choice adds one)."""
        if self.free:
            combo: ComboBox = self.find('add_theme')  # type: ignore[assignment]
            combo.items = [ComboItem(label=info.name, value=info.id, icon=info.small_image) for info in self.free]
            combo.open(-1)

    def add_chosen(self, index: int) -> None:
        """A theme chosen to add: at the top, selected, the window again."""
        if 0 <= index < len(self.free):
            self.select_id = self.free[index].id
            theme.add_theme(self.select_id)
            self.reopen('add')

    def tool(self, name: str) -> None:
        """A tool on the selected theme (a grayed one does nothing): remove it (the next row selected), move it up / down; the window again."""
        if (theme_id := self.selected()) is None or not self.find(name).enabled:
            return
        if name == 'remove':
            current = self.list_view.current
            self.select_id = self.rows[current + 1].id  # the next row (the base one at least)
            theme.remove_theme(theme_id)
        else:
            theme.move_theme(theme_id, -1 if name == 'up' else 1)
        self.win.reopen()

    # --- the form ---

    def show_form(self) -> None:
        """Show the rows of the form: the values of the style now, the mark "modified" of a token the local style sets, the info line."""
        style = check_style()
        local = local_style_files()
        for row in form_rows():
            field: FormField = self.find(row.name)  # type: ignore[assignment]
            if row.kind == 'variant':
                variants = theme.variant_choices(self.themes)
                self.set_items(row, [ComboItem(label=theme.variant_label(name), value=name) for name in variants], theme.configured_variant())
                field.modified = theme.configured_variant() != theme.AUTO_VARIANT
                continue
            if row.kind == 'switch':
                self.switch(row).checked = field.modified = theme.skin_colors_chosen()
                continue
            value = style.values[row.token]
            field.modified = style.origins[row.token] in local
            if row.kind == 'color':
                self.find(row.field).text = str(value)  # type: ignore[attr-defined]
                sample: Image = self.find(f'{row.name}_sample')  # type: ignore[assignment]
                sample.color = str(value)
            elif row.kind == 'factor':
                self.slider(row).value = float(value)
            else:
                self.set_items(row, self.font_items(str(value)), str(value))
        others = {name for path in local for name in read_layer(path)} - {token.name for token in TOKENS if token.adjustable}
        files = [path.name for path in local if others & read_layer(path).keys()]
        info: TextBox = self.find('info')  # type: ignore[assignment]
        info.text = L(30586, 'The local style changes {n} more token ({files}).|||The local style changes {n} more tokens ({files}).',
                      n=len(others), files=', '.join(files)) if others else ''

    @staticmethod
    def font_items(current: str) -> list[ComboItem]:
        """Return the items of the text sizes: the normal fonts of the skin (`normal_fonts()`), the current one too."""
        from ..skinfonts import normal_fonts, window_fonts
        fonts, _ = window_fonts()
        items = [ComboItem(label=L(30587, '{size} px ({font})', size=font.size, font=font.name), value=font.name) for font in normal_fonts(fonts)]
        if all(item.value != current for item in items):
            items.append(ComboItem(label=current, value=current))
        return items

    def set_items(self, row: FormRow, items: list[ComboItem], current: Any) -> None:
        """Set the items of the combo box of a row and its current one (by its value)."""
        combo = self.combo(row)
        combo.items = items
        combo.current_index = next((n for n, item in enumerate(items) if item.value == current), -1)

    def choose(self, row: FormRow, index: int) -> None:
        """An item of a combo box chosen: the variant or the token written, the window again."""
        records = self.combo(row).records()
        if not 0 <= index < len(records):
            return
        value = records[index].data
        if row.kind == 'variant':
            theme.set_variant(value)
        elif not self.write(row.token, value):
            return
        self.reopen(row.field)

    def choose_switch(self, row: FormRow, checked: bool | None) -> None:
        """The switch of the colours of the skin toggled: written, the window again (the style of the windows changes)."""
        theme.set_skin_colors(bool(checked))
        self.reopen(row.field)

    def choose_factor(self, row: FormRow, value: float) -> None:
        """A factor chosen by its slider: the token written, the window again."""
        if self.write(row.token, value):
            self.reopen(row.field)

    def pick_color(self, name: str, heading: str = '') -> None:
        """The colour picker of a colour token (its colour and its opacity written; "Default": the value of the themes); the window again."""
        from ..color_picker import ColorPlace, pick_color
        before = check_style().values[name]
        place = ColorPlace(get=lambda: str(check_style().values[name]), set=partial(self.write_color, name), alpha=True,
                           default=str(lower_style().values[name]))
        pick_color(place, heading)
        if check_style().values[name] != before:
            self.win.reopen()

    def write_color(self, name: str, color: str) -> None:
        """Write a colour of the colour picker (ARGB: its opacity too; every value a colour, '' the default one: removed)."""
        self.write(name, color.upper() or None)

    def write(self, name: str, value: TokenValue | None) -> bool:
        """Write the token into the local style (`write_token()`); an error told (a broken file stays). Return True if written."""
        try:
            write_token(name, value)
        except StyleError as exc:
            self.tell(exc)
            return False
        return True

    def tell(self, exc: StyleError) -> None:
        """Tell the error of a local style file (a broken one stays as it is)."""
        from ...ff.ui import ui
        ui.notify(self.TITLE(), str(exc), error=True)

    # --- the defaults ---

    def customized(self) -> bool:
        """Return True if the themes, the variant, the colours of the skin or a token of the page are not the default ones."""
        style = check_style()
        local = local_style_files()
        return super().customized() or any(style.origins[row.token] in local for row in form_rows() if row.token)

    def defaults_note(self) -> str:
        """Return what else restoring the defaults does: the tokens of the page removed from the local style (its other tokens stay)."""
        return L(30590, 'The colours, the density and the text size of the local style too (its other tokens stay).')

    def restore_defaults(self) -> None:
        """
        Remove the tokens of the page from every local style file in effect (also a token written there by hand), the themes and the
        variant; the window again. A broken file told (the themes stay).
        """
        try:
            remove_local_tokens(row.token for row in form_rows() if row.token)
        except StyleError as exc:
            self.tell(exc)
            return
        super().restore_defaults()
        self.win.reopen()

    # --- events ---

    def on_list_current_changed(self, index: int) -> None:
        """A move in the list: the selected theme, its tools."""
        if not self._showing and 0 <= index < len(self.rows):
            self.select_id = self.rows[index].id
            self.show_tools()
