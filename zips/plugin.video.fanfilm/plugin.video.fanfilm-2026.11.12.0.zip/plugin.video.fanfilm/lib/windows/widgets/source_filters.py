"""
The panel of the selection of the user of the sources (its model: `lib.windows.source_panel`, the state: `lib.ff.source_filters`): the tabs of
the filter and of the sort, the sets under them (`resources/skins/widgets/source_filters.xml`). A window hooks it as a whole: the move left
out of it (`onleft`), its geometry, what it edits (`media`), the sources (`sources`), `open()` when shown, `changed` and `current_changed`.
"""

from __future__ import annotations
from copy import deepcopy
from functools import partial
from typing import Any, ClassVar, Iterable, Sequence, TYPE_CHECKING
from attrs import frozen
from . import Widget
from .basic import Slider
from .buttons import CheckBox, PushButton
from .tabs import Page, TabWidget
from .setting_list import SettingList, SettingRow
from .views import ComboBox, TreeView as TreeWidget
from ..scale import Scale, ScaleValue
from ..source_panel import (FilterTree, SortList, FILTER_HELP, FILTER_PAGES, FILTER_SCALES, FILTER_TEXTS, SORT_BUTTONS, SORT_HEADINGS, SetEntry, range_value,
                            state_range, new_criterion, numeric, sort_keys, criterion_action, criterion_help, set_entries)
from ...ff import control
from ...ff.control import yesnoDialog
from ...ff.signals import ClassSignal
from ...ff.source_filters import (CurrentSelection, current_state, set_current_state, set_previous_state, set_state, user_languages, factory_filter,
                                  same_filter,
                                  is_modified, set_names, previous_state, remember_previous, load_set, load_previous, save_set, delete_set)
from ...ff.source_filters import (LegacyCut, ANY_CACHE, LEGACY_CUTS, LEGACY_CUSTOM_SORT, LEGACY_QUALITIES, LEGACY_SETTINGS, representable, simple_state,
                                  simple_values)
from ...ff.source_keys import SOURCE_KEYS, KEY_LABELS, FilterState, Selection, SelectionState, SortCriterion, SourceKey, SourceView, compile_selection
from ...ff.types import EllipsisType
from ...kolang import L
from ...sources.natives import CatalogSetting, ProviderSetting, SettingOption, catalog_setting
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action
    from ...ff.item import FFItem
    from ...ff.menu import ContextMenuItem
    from ...ff.source_filters import SelectionMedia
    from ...sources import Source


@frozen(kw_only=True)
class SourceFiltersVars:
    """The data of the template of the panel."""

    #: The pages of its tabs.
    pages: tuple[Page, ...]
    #: The scales of the ranges by their paths.
    scales: dict[str, Scale]
    #: The texts of its controls.
    texts: dict[str, str]
    #: The buttons of a row of the criteria of the sort.
    sort_buttons: tuple[str, ...]
    #: The keys of the ranges by their paths.
    labels: dict[str, SourceKey]


class SelectionPanel(Widget):
    """The panel of the selection of the user: what the views of it share (`SourceFilters`, `SourceFiltersSimple`), a change is written at once."""

    #: The selection changed: the window shows what it changes.
    changed = ClassSignal()
    #: Another row or tab of the panel, or the row changed: its help (`help_text()`) is another one.
    current_changed = ClassSignal()

    #: The advanced view (the tree of the values): the menu of a source changes the filter.
    ADVANCED: ClassVar[bool] = True
    #: The edges of the pages (plain Kodi buttons `edge.<name>`) by what their focus does: the page `sort` (right from the filter), `filter` (left
    #: from the sort), the bottom, the top of the page (up, down from the tabs: the moves wrap).
    EDGES: ClassVar[tuple[str, ...]] = ('sort', 'filter', 'bottom', 'top')

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The panel: nothing shown yet, the selection of the movies."""
        super().__init__(*args, **kwargs)
        #: The media of the selection edited.
        self.media: SelectionMedia = 'movie'
        #: A change is written (the configuration window, the sources window with the setting on); else it lasts in the window.
        self.persistent: bool = True
        #: The selection of the window, not stored (None: no change).
        self.transient: CurrentSelection | None = None
        #: The sources (the values and the counts of the trees), None: no search.
        self.sources: Sequence[Source] | None = None
        #: The panel is shown (`open()`).
        self.opened: bool = False
        #: The tree of the filter of the advanced view (None: none, made again for new sources).
        self.filter_tree: FilterTree | None = None
        #: The selection of the user before the changes in this window is kept as the previous one (`keep_previous()`).
        self.previous_kept: bool = False

    def built(self) -> None:
        """The list of the sets (no set in the simple view with `simple_hides_sets`)."""
        from ..base import weak_callback
        super().built()
        if 'set' in self.children:
            self.find('set', ComboBox).activated.connect(weak_callback(self.set_activated))

    def open(self) -> None:
        """The panel is shown: the state of the user in it."""
        raise NotImplementedError

    def show_selection(self) -> None:
        """The whole selection of the user replaced: the panel and the sources of it."""
        raise NotImplementedError

    def focus_end(self, *, bottom: bool) -> None:
        """Focus the bottom or the top of the shown page."""
        raise NotImplementedError

    def help_text(self) -> str:
        """Return the help of the focused control of the panel, '' none."""
        raise NotImplementedError

    def back(self) -> bool:
        """Back: nothing of the panel ends. Return True if something did."""
        return False

    def refresh_filter(self) -> None:
        """The filter changed out of the panel: only the advanced view has a tree of it."""

    def refresh_filter_tree(self) -> None:
        """New sources: only the advanced view counts them."""

    def set_names(self) -> list[str]:
        """Return the names of the sets of the list of the sets."""
        return set_names()

    @property
    def tabs(self) -> TabWidget:
        """Return the tabs of the pages."""
        return self.find('tabs', TabWidget)

    def state(self) -> CurrentSelection:
        """Return the selection edited (of the window: not stored, else the current one of the media)."""
        return deepcopy(self.transient) if self.transient is not None else current_state(self.media)

    def write(self, state: SelectionState, *, base: str | None | EllipsisType = ...) -> None:
        """Write the selection edited (`base`: the set it comes from now; of the window: only here, kept as the previous one of the media)."""
        if self.persistent:
            set_current_state(self.media, state, base=base)
            return
        self.transient = CurrentSelection(base=self.state().get('base') if base is ... else base, filter=state.get('filter', {}), sort=state.get('sort', []))
        set_previous_state(self.media, self.transient)

    def load_set(self, name: str) -> None:
        """Make a set the selection edited."""
        if self.persistent:
            load_set(self.media, name)
        else:
            self.write(set_state(name), base=name)

    def load_previous(self) -> None:
        """Swap the selection edited and the previous one."""
        if self.persistent:
            load_previous(self.media)
        elif (previous := previous_state(self.media)) is not None:
            set_previous_state(self.media, self.state())
            self.transient = previous

    def show_count(self, passed: int, total: int) -> None:
        """Show the number of the sources the filter lets through and of all of them."""
        self.find('tabs.count').text = f'{passed} / {total}' if self.transient is None else f'{passed} / {total} • {L(30964, "Changes only for this window")}'

    def handle_focus(self, control_id: int) -> None:
        """An edge of the pages got the focus: another page, the bottom or the top of the page."""
        super().handle_focus(control_id)
        edge = next((name for name in self.EDGES if control_id == self.control_id(f'edge.{name}')), '')
        if edge in ('bottom', 'top'):
            self.focus_end(bottom=edge == 'bottom')
        elif edge:
            self.show_page(edge)

    def show_page(self, name: str) -> None:
        """Show a page of the panel, the focus in it (on its control focused last, else its first one)."""
        tabs = self.tabs
        tabs.current = name
        self.win.set_focus_shown(tabs.control_id(f'page.{name}'))

    def keep_previous(self) -> None:
        """Keep the selection of the user as the previous one before its first change in this window (the next ones: one backup, as `file~`)."""
        if self.persistent and not self.previous_kept:
            self.previous_kept = True
            remember_previous(self.media)

    def show_sets(self) -> None:
        """Show the sets of the user in the panel: the items of the list, the current one in its field (changed: `*`)."""
        combo = self.find('set', ComboBox)
        base = self.state().get('base')
        combo.items = items = set_entries(self.set_names(), base=base, modified=is_modified(self.media, self.state()),
                                          has_previous=previous_state(self.media) is not None, read_only=not self.persistent)
        combo.current_index = next((n for n, item in enumerate(items) if item.value.kind == 'none' or item.value.name == base), -1)

    def ask_set_name(self) -> str:
        """Return the name of a new set from the keyboard of Kodi ('' canceled; the name of an existing set: overwriting it confirmed)."""
        kb = control.keyboard('', L(30942, 'Name of the set'))
        kb.doModal()
        name = kb.getText().strip() if kb.isConfirmed() else ''
        if name in set_names() and not yesnoDialog(L(30943, 'The set “{name}” exists. Overwrite it?', name=name), heading=FILTER_TEXTS['set']):
            return ''
        return name

    def set_activated(self, index: int) -> None:
        """An item of the list of the sets: a set loaded (the current one not changed: nothing), or an action on the current selection."""
        entry: SetEntry = self.find('set', ComboBox).records()[index].value
        base = self.state().get('base') or ''
        if entry.kind == 'set' and (entry.name != base or is_modified(self.media, self.state())):
            self.load_set(entry.name)
            self.show_selection()
        elif entry.kind == 'restore':
            self.load_set(base)
            self.show_selection()
        elif entry.kind == 'previous':
            self.load_previous()
            self.show_selection()
        elif entry.kind in ('save', 'save_as') and (name := base if entry.kind == 'save' and base in set_names() else self.ask_set_name()):
            save_set(self.media, name)
        elif entry.kind == 'delete' and yesnoDialog(L(30944, 'Delete the set “{name}”?', name=base), heading=FILTER_TEXTS['set']):
            delete_set(base)
        self.show_sets()

    def on_tabs_bar_current_changed(self, index: int) -> None:
        """Another tab of the panel: its help."""
        self.current_changed.emit()


class SourceFilters(SelectionPanel):
    """The advanced view of the panel: the filter on the tree of the values, the sort on its criteria, the sets."""

    #: The window property of the features of a criterion of the sort chosen (the template: `choosing`).
    CHOOSING: ClassVar[str] = 'sort.choosing'
    @classmethod
    def template_vars(cls) -> SourceFiltersVars:
        """Return the data of the template of the panel."""
        return SourceFiltersVars(pages=FILTER_PAGES, scales=FILTER_SCALES, texts=FILTER_TEXTS, sort_buttons=SORT_BUTTONS, labels=KEY_LABELS)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The panel: nothing shown yet."""
        super().__init__(*args, **kwargs)
        #: The expanded nodes of the whole tree of the filter by their keys (kept when it is made again).
        self.tree_expanded: set[str] = set()
        #: The rows of the criteria of the sort (None: not shown yet).
        self.sort_list: SortList | None = None
        #: The tree of the features of a criterion of the sort being chosen (None: none chosen).
        self.feature_tree: FilterTree | None = None
        #: The index of the criterion of the sort whose features are chosen (the tree of the features shown), None: none.
        self.chosen: int | None = None

    def views(self, selection: Selection) -> Iterable[SourceView] | None:
        """Return the views of the sources by the selection (None: no search)."""
        return None if self.sources is None else (selection.view(src) for src in self.sources)

    def open(self) -> None:
        """The panel is shown: the state of the user in it."""
        self.show_filter_controls()
        self.show_sort()
        self.show_sets()
        self.opened = True

    def back(self) -> bool:
        """Back: the end of the choice of the features of a criterion. Return True if there was one."""
        if self.chosen is None:
            return False
        self.end_choosing()
        return True

    def handle_action(self, action: Action) -> bool | None:
        """The context menu of the switch of the filter: the reset (the filter as in a new installation)."""
        from ..base import MENU_ACTIONS
        from ..context import ContextMenuDialog
        if action.getId() not in MENU_ACTIONS or self.win.focused_id() != self.find('tabs.on').id:
            return None
        if not same_filter(self.state().get('filter', {}), factory_filter(langs=user_languages())):
            ContextMenuDialog(menu=[(L(30926, 'Reset'), self.reset_filter)]).doModal()
        return True

    def help_text(self) -> str:
        """
        Return the help of the focused control of the panel, '' none (a row of the tree: `FilterTree.help()`, of the features:
        `FilterTree.feature_help()`).
        """
        focused, text = self.win.focused_id(), ''
        tabs = self.tabs
        tree = self.find('tabs.tree', TreeWidget)
        features = self.find('tabs.features', TreeWidget)
        sort = self.find('tabs.sort', TreeWidget)
        if focused == tabs.bar.id:
            text = next((page.help for page in FILTER_PAGES if page.name == tabs.current), '')
        elif (self.sort_list is not None and sort.view is not None and sort.view.in_list(focused)
              and 0 <= (pos := sort.view.position()) < len(sort.view.model.rows)):
            text = criterion_help(self.sort_list.criteria[id(sort.view.model.rows[pos].item)])
        elif (self.filter_tree is not None and tree.view is not None and tree.view.in_list(focused)
              and 0 <= (pos := tree.view.position()) < len(tree.view.model.rows)):
            text = self.filter_tree.help(tree.view.model.rows[pos].item, tree.view.model, self.state().get('filter', {}))
        elif (self.feature_tree is not None and features.view is not None and features.view.in_list(focused)
              and 0 <= (pos := features.view.position()) < len(features.view.model.rows)):
            text = self.feature_tree.feature_help(features.view.model.rows[pos].item, features.view.model)
        elif self.win._widget_tree is not None:
            widget = self.win._widget_tree.widget_of(focused)
            while widget is not None and widget.entry is not None and not text:
                text, widget = FILTER_HELP.get(widget.path.partition(f'{self.path}.')[2], ''), widget.parent
        return text

    def filters_tree(self) -> FilterTree:
        """Return the tree of the panel of the filter (made for the sources and the state now if there is none)."""
        if self.filter_tree is None:
            state = self.state()
            selection = compile_selection(state, langs=user_languages())
            self.filter_tree = FilterTree(self.views(selection), langs=user_languages(), state=state.get('filter', {}))
            self.show_filter_tree()
        return self.filter_tree

    def show_filter_tree(self) -> None:
        """Show the whole tree of the filter by the filter of the user (its nodes expanded before)."""
        assert self.filter_tree is not None
        model = self.filter_tree.model(self.state().get('filter', {}))
        model.expanded = {id(item) for item in model.items() if model.keys[id(item)] in self.tree_expanded}
        model.rows = model.flatten()
        self.find('tabs.tree', TreeWidget).set_model(model, dimmed=self.filter_tree.dimmed)

    def remember_tree_expanded(self) -> None:
        """Remember the expanded nodes of the tree of the filter by their keys."""
        if (model := self.find('tabs.tree', TreeWidget).model) is not None:
            self.tree_expanded = {model.keys[key] for key in model.expanded}

    def show_filter_controls(self) -> None:
        """Show the filter of the user in the panel: its tree, its switch, its ranges."""
        state = self.state().get('filter', {})
        self.filters_tree()
        self.find('tabs.on', CheckBox).checked = state.get('on', True)
        for path in FILTER_SCALES:
            self.find(f'tabs.{path}', Slider).value = range_value(state, path)

    def refresh_filter(self) -> None:
        """The filter changed out of its tree (the menu of a source, the reset): the panel shows it (the tree made again at its next open if closed)."""
        self.remember_tree_expanded()
        self.filter_tree = None
        if self.opened:
            self.show_filter_controls()

    def reset_filter(self) -> None:
        """Set the filter as in a new installation (asked first; the sort stays)."""
        title = next(page.title for page in FILTER_PAGES if page.name == 'filter')
        if yesnoDialog(L(30229, 'Restore the settings of "{tab}" as after a new installation?').format(tab=title), heading=title):
            self.previous_kept = False  # the state before the reset kept, whatever the changes before it
            self.change_filter(**factory_filter(langs=user_languages()))
            self.refresh_filter()

    def page_control(self) -> str:
        """Return the path of the main control of the shown page of the panel: the tree of the filter, of the features, the criteria of the sort."""
        if self.tabs.current != 'sort':
            return 'tabs.tree'
        if self.chosen is not None:
            return 'tabs.features'
        return 'tabs.sort' if self.state().get('sort') else 'tabs.add'

    def focus_end(self, *, bottom: bool) -> None:
        """
        Focus the bottom of the shown page of the panel (up from the tabs: the last row of its tree, "Add…" of the sort) or its top (down
        from the tabs: the filter on, the first row of the criteria - none: "Add…" - or of the features).
        """
        path = self.page_control()
        if path == 'tabs.tree' and not bottom:
            path = 'tabs.on'
        elif path == 'tabs.sort' and bottom:
            path = 'tabs.add'
        widget = self.find(path)
        if isinstance(widget, TreeWidget) and widget.view is not None and (rows := len(widget.view.model.rows)):
            pos = rows - 1 if bottom else 0
            widget.view.list_control().selectItem(pos)
            widget.view.track(pos)
        self.win.setFocusId(widget.id)

    def change_filter(self, **changes: Any) -> None:
        """Change the filter of the current selection of the user (its keys of `changes`), show the sources of it."""
        self.keep_previous()
        state = self.state()
        state['filter'] = FilterState(**{**state.get('filter', {}), **changes})
        self.write(state)
        self.changed.emit()
        self.show_sets()

    def show_selection(self) -> None:
        """The whole selection of the user replaced: the panel and the sources of it."""
        self.previous_kept = True  # kept with the replacement: not again for the next changes
        self.refresh_filter()
        self.show_sort()
        self.changed.emit()
        self.show_sets()

    def on_tabs_tree_current_changed(self, pos: int) -> None:
        """Another row of the tree of the filter: its help."""
        self.current_changed.emit()

    def on_tabs_sort_current_changed(self, pos: int) -> None:
        """Another criterion of the sort: its help."""
        self.current_changed.emit()

    def on_tabs_tree_checked_changed(self, items: Sequence[FFItem]) -> None:
        """The user checked / unchecked values in the tree: the filter of the tree."""
        tree = self.filters_tree()
        model = self.find('tabs.tree', TreeWidget).model
        assert model is not None
        self.change_filter(keys=tree.state(model, self.state().get('filter', {})).get('keys', {}))
        self.current_changed.emit()

    def on_tabs_on_clicked(self) -> None:
        """The filter on / off (off: all sources, the cut ones greyed out)."""
        self.change_filter(on=bool(self.find('tabs.on', CheckBox).checked))

    def on_tabs_quality_committed(self, value: Sequence[Any]) -> None:
        """The range of the quality."""
        self.change_range('quality', value)

    def on_tabs_size_committed(self, value: Sequence[Any]) -> None:
        """The range of the size."""
        self.change_range('size', value)

    def show_sort(self, pos: int = 0) -> None:
        """Show the criteria of the sort of the user in the panel, the row `pos` selected."""
        self.sort_list = SortList(self.state().get('sort', []))
        widget = self.find('tabs.sort', TreeWidget)
        widget.set_model(self.sort_list.model(), marks=self.sort_list.marks, extra_menu=self.sort_menu)
        if widget.view is not None and self.opened:
            widget.view.show_rows(pos)

    def sort_state(self) -> list[SortCriterion]:
        """Return the criteria of the rows of the list of the sort (moved, removed by the user)."""
        model = self.find('tabs.sort', TreeWidget).model
        assert self.sort_list is not None and model is not None
        return self.sort_list.state(model)

    def change_sort(self, sort: list[SortCriterion], *, pos: int | None = None) -> None:
        """Change the criteria of the sort of the current selection of the user, show the sources in its order (`pos`: the criteria again, that row)."""
        self.keep_previous()
        state = self.state()
        state['sort'] = sort
        self.write(state)
        self.changed.emit()
        self.show_sets()
        if pos is not None:
            self.show_sort(pos)

    def on_tabs_sort_moved(self, item: FFItem) -> None:
        """A criterion of the sort moved up / down."""
        self.change_sort(self.sort_state())

    def on_tabs_sort_row_button_clicked(self, name: str, item: FFItem) -> None:
        """
        A button of a row of the criteria: removed (up / down: `on_tabs_sort_moved()`) - the focus on the row in its place (down from the
        last one: "Add…"), no criterion left: on "Add…".
        """
        if name == 'remove':
            self.change_sort(sort := self.sort_state())
            self.win.setFocusId(self.find('tabs.sort' if sort else 'tabs.add').id)

    def sort_menu(self, pos: int) -> list[ContextMenuItem]:
        """Return the entry of the context menu of a criterion of the sort: what OK does (none: nothing)."""
        model = self.find('tabs.sort', TreeWidget).model
        if self.sort_list is None or model is None or not 0 <= pos < len(model.rows):
            return []
        item = model.rows[pos].item
        action = criterion_action(self.sort_list.criteria[id(item)])
        return [(action, partial(self.on_tabs_sort_activated, item))] if action else []

    def on_tabs_sort_activated(self, item: FFItem) -> None:
        """OK on a criterion: its features chosen again, a number in the other direction (a key in its own order: nothing)."""
        model = self.find('tabs.sort', TreeWidget).model
        assert model is not None
        index = next(i for i, it in enumerate(model.roots) if it is item)
        sort = self.sort_state()
        if 'any' in sort[index]:
            self.choose_features(index)
        elif (key := SOURCE_KEYS.get(sort[index].get('key', ''))) is not None and numeric(key):
            sort[index]['desc'] = not sort[index].get('desc')
            self.change_sort(sort, pos=index)

    def on_tabs_add_clicked(self) -> None:
        """Add a criterion at the top: any of the features or an order (a key not in the sort yet) chosen in the tree."""
        self.choose_features(None)

    def on_tabs_features_activated(self, item: FFItem) -> None:
        """An order chosen in the tree of a new criterion: the criterion of the key in its natural order (a number: the biggest first), the choice ends."""
        if self.feature_tree is None or self.chosen is None or (key := self.feature_tree.orders.get(id(item))) is None:
            return
        sort = list(self.state().get('sort', []))
        sort[self.chosen] = new_criterion(key)
        self.change_sort(sort)
        self.end_choosing()

    def choose_features(self, index: int | None) -> None:
        """
        Choose the features of a criterion of the sort (its index; None: a new one at the top, empty - no criterion - until a feature is
        chosen, or an order: the node "Order" of the keys not in the sort) in the tree of the keys (the values of the sources, two values:
        chosen or not; the nodes of the chosen ones expanded), its heading: what is chosen; Back ends it (`end_choosing()`).
        """
        state = self.state()
        sort = list(state.get('sort', []))
        order = sort_keys(sort) if index is None else ()
        if index is None:
            sort.insert(0, SortCriterion(any={}))
            index = 0
            self.change_sort(sort)
        chosen = FilterState(keys={path: {value: True for value in values} for path, values in sort[index].get('any', {}).items()})
        selection = compile_selection(state, langs=user_languages())
        self.feature_tree = FilterTree(self.views(selection), langs=user_languages(), state=chosen, order=order)
        self.find('tabs.heading').text = SORT_HEADINGS['new'] if order else SORT_HEADINGS['edit'].format(n=index + 1)
        self.find('tabs.features', TreeWidget).set_model(self.feature_tree.model(chosen, tristate=False), dimmed=self.feature_tree.dimmed,
                                                            marks=self.feature_tree.marks)
        self.chosen = index
        self.win.setProperty(self.CHOOSING, 'true')
        self.win.set_focus_shown(self.find('tabs.features').id, shown=self.tabs.id)

    def on_tabs_features_checked_changed(self, items: Sequence[FFItem]) -> None:
        """The features of the criterion chosen: the sources in the new order at once."""
        model = self.find('tabs.features', TreeWidget).model
        assert self.feature_tree is not None and model is not None and self.chosen is not None
        sort = list(self.state().get('sort', []))
        sort[self.chosen] = SortCriterion(any=self.feature_tree.features(model))
        self.change_sort(sort)
        self.current_changed.emit()

    def on_tabs_features_current_changed(self, pos: int) -> None:
        """Another row of the tree of the features: its help."""
        self.current_changed.emit()

    def end_choosing(self) -> None:
        """End the choice of the features of a criterion (none chosen: no criterion), the criteria again, the focus on it."""
        index, self.chosen, self.feature_tree = self.chosen, None, None
        self.win.setProperty(self.CHOOSING, 'false')
        sort = list(self.state().get('sort', []))
        if index is not None and index < len(sort) and 'any' in sort[index] and not sort[index]['any']:
            del sort[index]
        self.change_sort(sort, pos=min(index or 0, max(0, len(sort) - 1)))
        self.win.setFocusId(self.find('tabs.sort' if sort else 'tabs.add').id)

    def change_range(self, path: str, value: Sequence[Any]) -> None:
        """Change the range of a key of the filter (both ends open: no range)."""
        ranges = dict(self.state().get('filter', {}).get('ranges', {}))
        if (span := state_range(path, value)) == [None, None]:
            ranges.pop(path, None)
        else:
            ranges[path] = span
        self.change_filter(ranges=ranges)

    def refresh_filter_tree(self) -> None:
        """Make the tree of the filter again for the sources now, its selected row kept."""
        widget = self.find('tabs.tree', TreeWidget)
        key = None
        if widget.view is not None and 0 <= (pos := widget.view.position()) < len(rows := widget.view.model.rows):
            key = widget.view.model.keys[id(rows[pos].item)]
        self.remember_tree_expanded()
        self.filter_tree = None
        self.filters_tree()
        if key is not None and widget.view is not None:
            model = widget.view.model
            widget.view.show_rows(next((n for n, row in enumerate(model.rows) if model.keys[id(row.item)] == key), 0))


#: The old file filters of the simple view by their settings (a switch which blocks; `DV.mode` is a list).
SIMPLE_CUTS: dict[str, LegacyCut] = {cut.setting: cut for cut in LEGACY_CUTS if cut.setting != 'DV.mode'}
#: The scale of the range of the quality of the simple view: the steps of the old settings (the cinema copies: a switch of their own).
SIMPLE_QUALITY_SCALE: Scale = Scale(values=tuple(ScaleValue(quality, quality) for quality in LEGACY_QUALITIES))


def simple_switch(key: str, label: str, *, negative: bool = True) -> CatalogSetting:
    """Return a switch of the simple view (`negative`: on it does not matter, off it blocks; else on: only that)."""
    return catalog_setting(ProviderSetting(key=key, kind='bool', label=label, default=True, negative=negative))


def simple_list(key: str, label: str, options: Sequence[tuple[str, str]], *, help: str = '') -> CatalogSetting:
    """Return a list of the simple view: its options (values, labels), the first one the default."""
    return catalog_setting(ProviderSetting(key=key, kind='select', label=label, default=options[0][0], help=help,
                                           options=tuple(SettingOption(value=value, label=text) for value, text in options)))


#: The options of an element of the old custom sort.
SORT_ELEMENT_OPTIONS: tuple[tuple[str, str], ...] = (('0', L(32663, 'service')), ('1', L(32664, 'language')), ('2', L(32665, 'quality')),
                                                     ('3', L(32666, 'size')),
                                                     ('4', L(32667, 'none')))
#: The rows of the filter of the simple view under its switch and ranges.
SIMPLE_FILTER_ROWS: tuple[CatalogSetting, ...] = (
    simple_list('source.sound.lang', L(32839, 'Source language'),
                (('0', L(32840, 'All')), ('1', L(32841, 'Only PL')), ('2', L(32842, 'PL + Multi')), ('3', L(32843, 'Only EN')), ('4', L(32844, 'EN + MULTI'))),
                help=L(30977, 'The language of the audio or the subtitles.')),
    simple_list('DV.mode', L(30602, 'DV (Dolby Vision)'), (('0', L(30605, 'Show')), ('1', L(30606, 'Only with HDR10 / HDR')), ('2', L(30607, 'Hide')))),
    simple_switch('cached.only', L(30965, 'Only cached torrents'), negative=False),
    simple_switch('HDR.allowed', L(30245, 'HDR format')),
    simple_switch('AV1.allowed', L(30247, 'AV1 codec')),
    simple_switch('HEVC.allowed', L(30249, 'HEVC codec')),
    simple_switch('H264.10bit.disallowed', L(30966, 'H.264 10-bit (Hi10P)')),
    simple_switch('F3D.allowed', L(30246, '3D format')),
    simple_switch('AI.video.disallowed', L(30967, 'AI-processed video')),
    simple_switch('AVI.allowed', L(30589, 'AVI sources')),
    simple_switch('CAM.disallowed', L(30968, 'CAM quality')),
    simple_switch('source.premium.no_transfer', L(30969, 'Sources with too little transfer')),
    simple_switch('SUBTITLES.disallowed', L(30970, 'Subtitles without Polish audio')),
    simple_switch('subtitles.burned.allowed', L(30971, 'Burned-in subtitles')),
    simple_switch('LEKTORAI.disallowed', L(30838, 'AI voice')),
    simple_switch('MD.sound.disallowed', L(30973, 'Sound recorded in a cinema')),
)
#: The rows of the sort of the simple view.
SIMPLE_SORT_ROWS: tuple[CatalogSetting, ...] = (
    simple_list('hosts.sort', L(32622, 'Sort by'),
                (('0', L(32643, 'Providers')), ('1', L(32644, 'Hostings')), ('2', L(32645, 'Size')), ('3', L(32646, 'Custom'))),
                help=L(30978, 'Criteria 1-4 after choosing the custom ones.')),
    *(simple_list(f'hosts.sort.elem{n}', label, SORT_ELEMENT_OPTIONS)
      for n, label in enumerate((L(32809, 'criterion 1'), L(32810, 'criterion 2'), L(32811, 'criterion 3'), L(32812, 'criterion 4')), 1)),
)


@frozen(kw_only=True)
class SimpleFiltersVars:
    """The data of the template of the simple view."""

    #: The pages of its tabs.
    pages: tuple[Page, ...]
    #: The rows of the filter.
    filter_rows: tuple[CatalogSetting, ...]
    #: The rows of the sort.
    sort_rows: tuple[CatalogSetting, ...]
    #: The scale of the quality.
    quality: Scale
    #: The scale of the size.
    size: Scale
    #: The texts of its controls.
    texts: dict[str, str]
    #: The keys of the ranges by their paths.
    labels: dict[str, SourceKey]
    #: No sets: "Previous" in their place.
    hide_sets: bool


class SourceFiltersSimple(SelectionPanel):
    """The simple view of the panel: the switches and the lists of the old settings (the selection: `simple_state()`)."""

    ADVANCED = False

    @classmethod
    def template_vars(cls) -> SimpleFiltersVars:
        """Return the data of the template of the simple view."""
        return SimpleFiltersVars(pages=FILTER_PAGES, filter_rows=SIMPLE_FILTER_ROWS, sort_rows=SIMPLE_SORT_ROWS, quality=SIMPLE_QUALITY_SCALE,
                                 size=FILTER_SCALES['size'],
                                 texts={**FILTER_TEXTS, 'previous': L(30941, 'Previous')}, labels=KEY_LABELS, hide_sets=const.sources.filters.simple_hides_sets)

    def built(self) -> None:
        """The button "Previous" (only without the list of the sets)."""
        from ..base import weak_callback
        super().built()
        if 'previous' in self.children:
            self.find('previous', PushButton).clicked.connect(weak_callback(self.previous_clicked))

    def set_names(self) -> list[str]:
        """Return the names of the sets the simple view shows without a loss."""
        return [name for name in super().set_names() if representable(set_state(name), langs=user_languages())]

    def values(self) -> dict[str, str]:
        """Return the values of the rows of the selection edited."""
        return simple_values(self.state(), langs=user_languages())

    def apply_values(self, values: dict[str, str]) -> None:
        """Write the selection of the values (the switch of the filter stays), show it."""
        state = simple_state(values, langs=user_languages())
        state['filter']['on'] = self.state().get('filter', {}).get('on', True)
        self.keep_previous()
        self.write(state)
        self.show_selection()

    def row_value(self, key: str) -> Any:
        """Return the value of a row: a switch (True: lets through), a list."""
        values = self.values()
        if key == 'cached.only':
            return values.get(key) != ANY_CACHE
        if key in SIMPLE_CUTS:
            return values.get(key) != SIMPLE_CUTS[key].value
        return values.get(key, LEGACY_SETTINGS[key])

    def set_row(self, key: str, value: Any) -> None:
        """Change the value of a row."""
        values = self.values()
        if key == 'cached.only':
            values.pop(key, None)
            if not value:
                values[key] = ANY_CACHE
        elif key in SIMPLE_CUTS:
            values.pop(key, None)
            if not value:
                values[key] = SIMPLE_CUTS[key].value
        else:
            values[key] = value
        self.apply_values(values)

    @staticmethod
    def row_reason(key: str, values: dict[str, str]) -> str:
        """Return why a row can not be used now ('' it can)."""
        if key == 'CAM.disallowed' and int(values['hosts.quality.min']):
            return L(30974, 'The minimum quality hides them anyway.')
        return ''

    def rows(self, settings: Sequence[CatalogSetting], values: dict[str, str]) -> list[SettingRow]:
        """Return the rows of the settings."""
        return [SettingRow(setting=setting, get=partial(self.row_value, setting['key']), set=partial(self.set_row, setting['key']),
                           usable=not (reason := self.row_reason(setting['key'], values)), reason=reason) for setting in settings]

    def show_state(self) -> None:
        """Show the selection edited: the switch of the filter, the ranges, the rows."""
        state, values = self.state(), self.values()
        self.find('tabs.on', CheckBox).checked = state.get('filter', {}).get('on', True)
        self.find('tabs.quality', Slider).value = tuple(LEGACY_QUALITIES[int(values[f'hosts.quality.{end}'])] for end in ('min', 'max'))
        self.find('tabs.size', Slider).value = range_value(state.get('filter', {}), 'size')
        self.find('tabs.filter', SettingList).show(self.rows(SIMPLE_FILTER_ROWS, values))
        custom = int(values['hosts.sort']) == LEGACY_CUSTOM_SORT  # its criteria: only then
        self.find('tabs.sort', SettingList).show(self.rows(SIMPLE_SORT_ROWS if custom else SIMPLE_SORT_ROWS[:1], values))
        if 'previous' in self.children:
            previous = previous_state(self.media)
            self.find('previous', PushButton).enabled = previous is not None and representable(previous, langs=user_languages())

    def open(self) -> None:
        """The panel is shown: the state of the user in it."""
        self.show_state()
        if 'set' in self.children:
            self.show_sets()
        self.opened = True

    def show_selection(self) -> None:
        """The whole selection of the user replaced: the panel and the sources of it."""
        self.show_state()
        self.changed.emit()
        if 'set' in self.children:
            self.show_sets()

    def previous_clicked(self) -> None:
        """"Previous": swap the selection edited and the previous one."""
        self.load_previous()
        self.show_selection()

    def help_text(self) -> str:
        """Return the help of the focused control of the panel, '' none (a row: its own)."""
        focused, tabs = self.win.focused_id(), self.tabs
        if focused == tabs.bar.id:
            return next((page.help for page in FILTER_PAGES if page.name == tabs.current), '')
        tree = self.win._widget_tree
        if tree is None:
            return ''
        widget = tree.widget_of(focused)
        while widget is not None and widget.entry is not None:
            if text := FILTER_HELP.get(widget.path.partition(f'{self.path}.')[2], ''):
                return text
            widget = widget.parent
        return tree.help_of(focused)

    def focus_end(self, *, bottom: bool) -> None:
        """Focus the bottom of the shown page (up from the tabs: its last row) or its top (down from the tabs: the switch; the first row of the sort)."""
        name = self.tabs.current
        if name != 'sort' and not bottom:
            self.win.setFocusId(self.find('tabs.on').id)
            return
        rows = self.find(f'tabs.{name}', SettingList)
        rows.current = len(rows.settings) - 1 if bottom else 0
        self.win.setFocusId(rows.id)

    def on_tabs_on_clicked(self) -> None:
        """The filter on / off."""
        state = self.state()
        state.setdefault('filter', FilterState())['on'] = bool(self.find('tabs.on', CheckBox).checked)
        self.keep_previous()
        self.write(state)
        self.changed.emit()

    def on_tabs_quality_committed(self, value: Sequence[Any]) -> None:
        """The range of the quality."""
        ends = (str(LEGACY_QUALITIES.index(end)) for end in value)
        self.apply_values({**self.values(), **dict(zip(('hosts.quality.min', 'hosts.quality.max'), ends))})

    def on_tabs_size_committed(self, value: Sequence[Any]) -> None:
        """The range of the size."""
        low, high = state_range('size', value)
        self.apply_values({**self.values(), 'source.size.min': str(low or 0), 'source.size.max': str(high or 0)})

    def on_tabs_filter_current_changed(self, pos: int) -> None:
        """Another row of the filter: its help."""
        self.current_changed.emit()

    def on_tabs_sort_current_changed(self, pos: int) -> None:
        """Another row of the sort: its help."""
        self.current_changed.emit()
