"""
Widgets of the FF windows, the Python side. A window made of widgets (its source in `resources/skins/widgets`) gets
the manifest of its widgets from the XML generator (`WidgetEntry`: path, widget and its bases, families, control IDs);
every widget gets an object of its class: the class of its name in PascalCase (`push_button` -> `PushButton`) in the
module of its family (`lib/windows/widgets/<family>.py`), else the one of its nearest base which has a class, else
`Widget`. Nothing is imported by hand: a widget used in the XML brings its class.

A widget has properties (`Property`: a value and its signal `<name>_changed`, applied to the Kodi controls when the
window shows them) and signals (`ClassSignal`, e.g. `clicked`). A slot is connected explicitly (`widget.clicked.connect(f)`)
or by its name: a method `on_<path>_<signal>` of the window (or of a parent widget, the path relative to it) is connected
to the signal of the widget (`on_ok_clicked`, `on_tabs_accounts_add_clicked`); a method `on_…` which is no slot of a
widget and no handler of the window is an error.

A widget keeps its window weakly (`WindowRef`, see `AbstractWindow`); a slot catching the window (a lambda, a partial)
must not keep it: `weak_callback()`.
"""

from __future__ import annotations
from typing import Any, ClassVar, Generic, Iterable, Iterator, TypeVar, overload, TYPE_CHECKING
from importlib import import_module
from functools import lru_cache
from ...ff.signals import ClassSignal
from ..base import WindowRef
from ..style import tokens
if TYPE_CHECKING:
    from typing_extensions import Self
    from xbmcgui import Action, Control
    from ...ff.signals import Signal
    from ..base import AbstractWindow
    from ..xgui import WidgetEntry

#: The type of a property value.
T = TypeVar('T')
#: The type of a widget (a subclass of `Widget`).
W = TypeVar('W', bound='Widget')

#: The manifest data of a widget: the values of its properties in its template - the parameters of the same names (a property
#: empty in Python shows the one of its template: `Widget.template_value()`).
TEMPLATE_VALUES: str = 'template'

#: The widget (a base of a widget) whose subtree is created the first time it is needed (a page of tabs; `Widget.child()`): a window pays
#: for what it shows only, the page module is not imported before.
DEFERRED_WIDGET: str = 'tab_page'

#: The manifest data of a group node of the focus lines (`lib/windows/focus_lines.py`): the IDs of the controls inside it; its
#: line (`line_property()`) is cleared when the focus is on none of them (a group has no `onunfocus`, a move inside keeps the line).
LINE_GROUP: str = 'line_group'


def gray_text(text: str, enabled: bool) -> str:
    """
    Return a text of Python as Kodi shows it: grayed if its widget is disabled (`color.text.disabled`). Kodi grays a disabled control
    by itself (its `disabledcolor`), but a disabled widget with its reason keeps the focus: its Kodi control stays enabled.
    """
    return text if enabled or not text else f'[COLOR {tokens().color.text.disabled}]{text}[/COLOR]'


class Property(Generic[T]):
    """
    A property of a widget: its value (the default until set) and its change signal `<name>_changed(value)` declared by
    the property itself; a change is applied to the Kodi controls (`Widget.apply_property()`) once the window shows them,
    the bindings of the window are refreshed (in a Kodi callback of the window: once at its end, `WindowBindings.batch()`).
    """

    def __init__(self, default: T) -> None:
        """The property with its default value."""
        #: The default value.
        self.default: T = default
        #: The name of the property (the attribute of the widget class).
        self.name: str = ''

    def __set_name__(self, owner: type, name: str) -> None:
        """Remember the name, declare the change signal of the property in the widget class."""
        self.name = name
        setattr(owner, f'{name}_changed', ClassSignal(name=f'{name}_changed'))

    @overload
    def __get__(self, obj: None, owner: type | None = None) -> Self: ...

    @overload
    def __get__(self, obj: object, owner: type | None = None) -> T: ...

    def __get__(self, obj: object | None, owner: type | None = None) -> T | Self:
        """Return the value (the property itself on the class)."""
        if obj is None:
            return self
        return obj.__dict__.get(self.name, self.default)

    def __set__(self, obj: Widget, value: T) -> None:
        """Set the value: a change is applied and signalled."""
        if obj.__dict__.get(self.name, self.default) == value:
            return
        obj.__dict__[self.name] = value
        obj.property_changed(self.name)
        getattr(obj, f'{self.name}_changed').emit(value)

    def __delete__(self, obj: Widget) -> None:
        """Reset to the default value: a change is applied and signalled."""
        self.__set__(obj, self.default)


class Widget:
    """A widget of a window: its controls (by their IDs of the manifest), properties, signals, children."""

    #: The name of the property a data mapping uses by default ('' none): the value of the widget.
    VALUE: ClassVar[str] = ''
    #: The positions of its list the widget keeps (a focus line member `@path:<name>` enters it there): the 0-based index of
    #: the item in the window property `ffw.<id>.<name>` (`position_property()`, `lib/windows/focus_lines.py`).
    FOCUS_POSITIONS: ClassVar[frozenset[str]] = frozenset()
    #: The control of the editing ('' none: its name in the template): Python focuses it (OK on the widget control), no key reaches it -
    #: the focus lines leave it out (a scale widget, `ScaleWidget`).
    EDIT_CONTROL: ClassVar[str] = ''

    #: The window, kept weakly (the window keeps the widget).
    win: WindowRef[AbstractWindow] = WindowRef()

    #: The help of the widget (the footer of the window when the widget has the focus).
    help: Property[str] = Property('')
    #: Why the widget is disabled (its help tells it; '' none): a disabled widget with a reason keeps the focus.
    reason: Property[str] = Property('')
    #: The widget is enabled.
    enabled: Property[bool] = Property(True)
    #: The widget is visible.
    visible: Property[bool] = Property(True)

    #: A child widget of a deferred subtree is built (`DEFERRED_WIDGET`; the argument: the child).
    child_built: ClassSignal = ClassSignal()
    #: The widget control is clicked.
    clicked: ClassSignal = ClassSignal()
    #: The widget control got the focus.
    focused: ClassSignal = ClassSignal()

    def __init__(self, win: AbstractWindow, entry: WidgetEntry | None = None, parent: Widget | None = None) -> None:
        """The widget of the window (`entry`: its manifest entry, None for the root: the window)."""
        self.win = win
        #: The manifest entry (None: the root of the window).
        self.entry: WidgetEntry | None = entry
        #: The parent widget (None: the root).
        self.parent: Widget | None = parent
        #: The child widgets by their names.
        self.children: dict[str, Widget] = {}

    def __repr__(self) -> str:
        """Return the class and the path."""
        return f'{type(self).__name__}({self.path!r})'

    @property
    def path(self) -> str:
        """Return the path of the widget in the window ('' the root)."""
        return self.entry.path if self.entry is not None else ''

    @property
    def name(self) -> str:
        """Return the name of the widget (the last part of its path)."""
        return self.path.rpartition('.')[2]

    @property
    def id(self) -> int:
        """Return the control ID of the widget (0 the root)."""
        return self.entry.id if self.entry is not None else 0

    def control_id(self, name: str = '') -> int:
        """Return a control ID of the widget by its name in the widget template (`id_of(name)`; '' the widget control)."""
        if self.entry is None:
            raise KeyError(f'The root has no control {name!r}')
        return self.entry.ids[name]

    def control(self, name: str = '') -> Control | None:
        """Return a Kodi control of the widget by its name (None before the window shows it)."""
        return self.win.get_control(self.control_id(name))

    @overload
    def find(self, path: str) -> Widget: ...

    @overload
    def find(self, path: str, cls: type[W]) -> W: ...

    def find(self, path: str, cls: type[W] | None = None) -> Any:
        """Return the widget by its path relative to this one (`KeyError` if there is none)."""
        widget = self
        for name in path.split('.') if path else ():
            if (child := widget.child(name)) is None:
                raise KeyError(f'No widget {path!r} in {self.path or type(self.win).__name__!r}')
            widget = child
        if cls is not None and not isinstance(widget, cls):
            raise TypeError(f'Widget {widget.path!r} is not a {cls.__name__}')
        return widget

    def child(self, name: str) -> Widget | None:
        """Return the child widget of the name (a deferred one: built now), None: no such child."""
        if (child := self.children.get(name)) is None and (tree := self.win._widget_tree) is not None:
            return tree.build_deferred(self, name)
        return child

    def walk(self) -> Iterator[Widget]:
        """Yield the widget and all its descendants built so far (in the document order)."""
        yield self
        for child in self.children.values():
            yield from child.walk()

    def help_of(self, control_id: int) -> str:
        """Return the help of a control of the widget (why it is disabled first, else its help; a widget of more controls computes it)."""
        return self.reason or self.help

    def built(self) -> None:
        """The widgets of the window exist (the children too; no Kodi controls yet; a deferred page: built at its first need): connect to the children here."""

    # --- events (the window gives a widget the events of its controls) ---

    def handle_click(self, control_id: int) -> bool | None:
        """A control of the widget is clicked: `clicked` for the widget control. Return True if handled (the window not)."""
        if control_id == self.id:
            self.clicked.emit()
        return None

    def handle_focus(self, control_id: int) -> None:
        """A control of the widget got the focus: `focused` for the widget control."""
        if control_id == self.id:
            self.focused.emit()

    def handle_focus_out(self, control_id: int) -> None:
        """The focus went from the controls of the widget to another control (`control_id`: of another widget or of none)."""

    def handle_action(self, action: Action) -> bool | None:
        """An action while a control of the widget has the focus (its parents get it next). Return True if handled."""
        return None

    # --- properties ---

    def template_value(self, name: str) -> Any:
        """Return the value of the property in the template: its parameter of the same name ('' none); Python shows it while the property is empty."""
        return self.entry.data.get(TEMPLATE_VALUES, {}).get(name, '') if self.entry is not None else ''

    @property
    def window_text(self) -> bool:
        """Return True if the template shows the text of the window property `ffw.<id>.text` (no text in the template)."""
        return self.entry is not None and self.entry.data.get('static_text') is False

    def property_changed(self, name: str) -> None:
        """
        A property is changed: apply it if the controls exist (from `onInit()` on), refresh the bindings of the window; before,
        only its window properties (no controls needed: shown with the first frame of the window).
        """
        win = self.win
        if (tree := win._widget_tree) is not None and tree.shown:
            self.apply_property(name)
            win.bindings.refresh()
        else:
            self.apply_window_property(name)

    def apply_window_property(self, name: str) -> None:
        """Apply the part of the property shown by the window properties of the widget (`ffw.<id>.*`, the controls may not exist yet)."""

    def apply_property(self, name: str) -> None:
        """Apply the property to the Kodi controls (the window shows them): `enabled`, `reason`, `visible`."""
        if self.entry is None:
            return
        if name in ('enabled', 'reason'):
            self.win.set_control_enabled(self.id, self.enabled, focusable=bool(self.reason))
        elif name == 'visible' and (control := self.control()) is not None:
            control.setVisible(self.visible)

    def apply(self) -> None:
        """Apply the properties changed before the window showed the widget."""
        for name in list(vars(self)):
            if isinstance(getattr(type(self), name, None), Property):
                self.apply_property(name)


def position_property(cid: int, name: str) -> str:
    """
    Return the window property `ffw.<id>.<name>` of the widget of the control ID: a position it keeps (`Widget.FOCUS_POSITIONS`:
    the 0-based index of its item), the state of a focus line node (`line_property()`).
    """
    return f'ffw.{cid}.{name}'


def line_property(cid: int) -> str:
    """Return the window property of a focus line node (`lib/windows/focus_lines.py`): the key of the line the focus came by."""
    return position_property(cid, 'line')


def widget_class(entry: WidgetEntry) -> type[Widget]:
    """Return the class of the widget: of its name in its family, else of its nearest base which has one, else `Widget`."""
    for wtype, family in zip(entry.types, entry.families):
        try:
            module = import_module(f'{__name__}.{family}')
        except ModuleNotFoundError as exc:
            if exc.name != f'{__name__}.{family}':
                raise  # an import of the family failed, not the family
            continue
        cls = getattr(module, ''.join(word.capitalize() for word in wtype.split('_')), None)
        if isinstance(cls, type) and issubclass(cls, Widget):
            return cls
    return Widget


@lru_cache(maxsize=None)
def property_names(cls: type) -> frozenset[str]:
    """Return the names of the properties of the class (its `Property` attributes; once per class)."""
    return frozenset(name for name in dir(cls) if isinstance(getattr(cls, name, None), Property))


@lru_cache(maxsize=None)
def signal_names(cls: type) -> tuple[str, ...]:
    """Return the names of the signals of the class (its `ClassSignal` attributes; once per class)."""
    return tuple(name for name in dir(cls) if isinstance(getattr(cls, name, None), ClassSignal))


@lru_cache(maxsize=None)
def slot_names(cls: type) -> frozenset[str]:
    """Return the names of the `on_…` methods of the class which are no handlers of the window classes / `Widget` (once per class)."""
    from ..base import AbstractWindow, BaseDialog, BaseWindow
    handlers = {name for base in (AbstractWindow, BaseDialog, BaseWindow, Widget) for name in dir(base) if name.startswith('on_')}
    return frozenset(name for name in dir(cls) if name.startswith('on_') and name not in handlers)


class WidgetTree:
    """The widgets of a window from its manifest: the root (the window itself), the widgets by their control IDs."""

    def __init__(self, win: AbstractWindow, entries: tuple[WidgetEntry, ...]) -> None:
        """Create the widgets of the window, connect the slots by their names."""
        #: The root: the window itself (its children: the top widgets).
        self.root: Widget = Widget(win)
        #: The widgets by their control IDs (every ID of a widget).
        self.by_id: dict[int, Widget] = {}
        #: The Kodi controls exist (`onInit()` started): a property change is applied at once.
        self.shown: bool = False
        #: The widget of the focused control (None: none, a control of no widget).
        self.focused: Widget | None = None
        #: The group nodes of the focus lines by their IDs: the controls inside them (`LINE_GROUP`).
        self.line_groups: dict[int, frozenset[int]] = {entry.id: frozenset(ids) for entry in entries if (ids := entry.data.get(LINE_GROUP))}
        #: The entries of the deferred subtrees not built yet by the paths of their roots (`DEFERRED_WIDGET`), the root first.
        self.deferred: dict[str, list[WidgetEntry]] = {}
        #: The root of the deferred subtree of a control ID (a built one: its ID is in `by_id`).
        self.deferred_ids: dict[int, str] = {}
        built: list[Widget] = []
        root = ''
        for entry in entries:  # in the document order: a parent before its children
            if root and not entry.path.startswith(f'{root}.'):
                root = ''
            if not root and DEFERRED_WIDGET in entry.types:
                root, self.deferred[entry.path] = entry.path, []
            if root:
                self.deferred[root].append(entry)
                self.deferred_ids.update(dict.fromkeys(entry.ids.values(), root))
            else:
                built.append(self._create(win, entry))
        for widget in built:
            widget.built()
        self._connect_by_name(win, built)

    def _create(self, win: AbstractWindow, entry: WidgetEntry) -> Widget:
        """Create the widget of the entry (its parent exists), return it."""
        parent_path, _, name = entry.path.rpartition('.')
        parent = self.root.find(parent_path)
        widget = widget_class(entry)(win, entry, parent)
        parent.children[name] = widget
        for cid in entry.ids.values():
            self.by_id[cid] = widget
        return widget

    def build_deferred(self, parent: Widget, name: str) -> Widget | None:
        """
        Create the deferred subtree of the child `name` of the widget (`DEFERRED_WIDGET`: its widgets, their `built()`, their slots), tell its
        parent (`child_built`); no such subtree: None. A change of a shown window is applied by the properties themselves (`Widget.property_changed()`).
        """
        path = f'{parent.path}.{name}' if parent.path else name
        if (entries := self.deferred.pop(path, None)) is None:
            return None
        win = self.root.win
        widgets = [self._create(win, entry) for entry in entries]
        for widget in widgets:
            widget.built()
        self._connect_by_name(win, widgets, widgets[0])
        if self.shown:
            win.bindings.refresh()  # the bindings of the subtree (skipped until now, `not_built()`)
        parent.child_built.emit(widgets[0])
        return widgets[0]

    def not_built(self, path: str) -> bool:
        """Return True if the widget of the path lies in a deferred subtree not built yet."""
        return any(path == root or path.startswith(f'{root}.') for root in self.deferred)

    def _connect_by_name(self, win: AbstractWindow, widgets: list[Widget], root: Widget | None = None) -> None:
        """
        Connect the slots `on_<path>_<signal>` of the window and of the parent widgets to the `widgets`; an unknown `on_…` is an error. `root`: the
        root of a deferred subtree (`widgets`, built now): its parents have only the slots of this subtree checked now, the others - theirs were
        passed over; with no `root` the slots of the deferred subtrees are passed over.
        """
        holders: list[Widget | AbstractWindow] = [win, *(w for w in widgets if w.entry is not None)]
        used: dict[int, set[str]] = {id(holder): set() for holder in holders}
        for widget in widgets:
            if widget.entry is None:
                continue
            for holder in [win, *self._parents(widget)]:
                if not (slots := slot_names(type(holder))):
                    continue
                prefix = '' if holder is win else f'{holder.path}.'  # type: ignore[union-attr]
                rel = widget.path[len(prefix):].replace('.', '_')
                for signal in signal_names(type(widget)):
                    if f'on_{rel}_{signal}' in slots and (slot := getattr(holder, f'on_{rel}_{signal}', None)) is not None:
                        sig: Signal = getattr(widget, signal)
                        sig.connect(slot)
                        used.setdefault(id(holder), set()).add(f'on_{rel}_{signal}')
        for holder in (*holders, *(self._parents(root) if root is not None else ())):
            if root is not None and (holder is win or holder not in widgets):  # a parent of the subtree: only the slots of the subtree
                unknown = self._slots_under(win, holder, (root.path,)) - used.get(id(holder), set())
            else:
                unknown = slot_names(type(holder)) - used[id(holder)] - self._slots_under(win, holder, self.deferred)
            if unknown:
                where = type(holder).__name__ if holder is win else repr(holder)
                raise AttributeError(f'{where}: no widget signal for the slot(s) {", ".join(sorted(unknown))}')

    @staticmethod
    def _slots_under(win: AbstractWindow, holder: Widget | AbstractWindow, roots: Iterable[str]) -> set[str]:
        """Return the slots of the holder of the widgets under the paths `roots` (`on_<path>_…`, the paths relative to the holder)."""
        prefix = '' if holder is win else f'{holder.path}.'  # type: ignore[union-attr]
        names = tuple(f'on_{root[len(prefix):].replace(".", "_")}_' for root in roots if root.startswith(prefix))
        return {slot for slot in slot_names(type(holder)) if slot.startswith(names)}

    @staticmethod
    def _parents(widget: Widget) -> Iterator[Widget]:
        """Yield the parent widgets of the widget (not the root)."""
        parent = widget.parent
        while parent is not None and parent.entry is not None:
            yield parent
            parent = parent.parent

    def focus(self, control_id: int) -> None:
        """
        A control got the focus: the widget which had it learns it is gone (`handle_focus_out()`), a group node of the focus lines
        left forgets its line, the widget of the control gets it.
        """
        widget = self.widget_of(control_id)
        if self.focused is not None and self.focused is not widget:
            self.focused.handle_focus_out(control_id)
        self.focused = widget
        for gid, inside in self.line_groups.items():
            if control_id not in inside:  # the focus left the group node: its exit move read the line already (Kodi moves before onFocus)
                # ponytail: a key back into the group between the window's check of the focus (onFocus) and here loses that entry's line (the rest then)
                self.root.win.clearProperty(line_property(gid))  # type: ignore[attr-defined]
        if widget is not None:
            widget.handle_focus(control_id)

    def widget_of(self, control_id: int) -> Widget | None:
        """Return the widget of the control (None: no widget; a control of a deferred subtree: built now)."""
        if control_id not in self.by_id and (root := self.deferred_ids.get(control_id)):
            parent_path, _, name = root.rpartition('.')
            self.build_deferred(self.root.find(parent_path), name)
        return self.by_id.get(control_id)

    def help_of(self, control_id: int) -> str:
        """Return the help of the control: of its widget (why it is disabled first) or of a parent widget ('' none)."""
        widget = self.widget_of(control_id)
        while widget is not None and widget.entry is not None:
            if text := widget.help_of(control_id):
                return text
            widget = widget.parent
        return ''

    def apply(self) -> None:
        """The window shows the widgets: apply their properties changed before (a change from now on is applied at once)."""
        self.shown = True
        for widget in list(self.root.walk()):  # a page shown now is built (and applied) in the walk
            widget.apply()
