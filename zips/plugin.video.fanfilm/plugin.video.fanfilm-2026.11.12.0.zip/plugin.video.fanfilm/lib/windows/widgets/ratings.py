"""The ratings (`resources/skins/widgets/ratings.xml`): the bar of the rating buttons."""

from __future__ import annotations
from functools import partial
from ...ff.signals import ClassSignal
from . import Widget


class RatingBar(Widget):
    """The rating buttons (the children `rate<N>`): a click of one is `rated(rating)`."""

    #: A rating button is clicked: its rating.
    rated: ClassSignal = ClassSignal()

    def built(self) -> None:
        """Connect the buttons: a click is the rating of the button."""
        assert self.entry is not None
        for rating, button in zip(self.entry.data['ratings'], self.children.values()):
            button.clicked.connect(partial(self.rated.emit, rating))

    def button(self, rating: int) -> Widget:
        """Return the button of the rating (`KeyError` if there is none)."""
        return self.find(f'rate{rating}')
