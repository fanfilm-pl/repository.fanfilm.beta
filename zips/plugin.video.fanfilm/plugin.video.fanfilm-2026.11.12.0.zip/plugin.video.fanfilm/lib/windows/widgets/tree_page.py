"""
The base of a page of the configuration window with a tree (the widget `tree` of the page: `tree_view`) shown by the logic of
its tab (`lib.windows.menus.MenusTabLogic`, `lib.windows.external_addons.ProvidersTabLogic`): the help of the focused control
follows the selected row of the tree.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from .tabs import TabPage
if TYPE_CHECKING:
    from ..tree import TreeView as Tree
    from .views import TreeView


class TreePage(TabPage):
    """A page with a tree (`tree`): its help computed for the focused control (`help_of()`), shown again when another row is selected."""

    DEFAULT = 'tree'

    @property
    def tree(self) -> TreeView:
        """Return the tree widget."""
        return self.find('tree')  # type: ignore[return-value]

    @property
    def view(self) -> Tree:
        """Return the tree of the model (the page is filled: `set_model()`)."""
        view = self.tree.view
        assert view is not None, 'the tree has no model yet'
        return view

    @property
    def help(self) -> str:  # type: ignore[override]  # computed, not set: the window reads it for the controls without their own help
        """Return the help of the focused control (it follows the selected row of the tree)."""
        if self.tree.view is None:
            return ''
        return self.help_of(self.win.focused_id())

    def help_of(self, control_id: int) -> str:
        """Return the help of the control of the page ('' none)."""
        return ''

    def show_help(self) -> None:
        """Show the help of the focused control again (the window shows it when a control gets the focus; the selected row changed)."""
        win = self.win
        win.find('help').text = win.help_of(win.focused_id())  # type: ignore[attr-defined]  # the window of the tabs

    def row_selected(self) -> None:
        """Another row of the tree may be selected (a move, the rows shown again): the help of the focused control."""
        self.show_help()

    def on_tree_current_changed(self, pos: int) -> None:
        """Another row of the tree selected (a move)."""
        self.row_selected()

    def on_tree_changed(self) -> None:
        """The rows of the tree shown again (a filter, expand / collapse) or their states changed."""
        self.row_selected()
