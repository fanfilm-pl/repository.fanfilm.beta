"""
The tabs and the pages (`resources/skins/widgets/tabs.xml`; Qt: QTabWidget, QTabBar, QStackedWidget, QToolBox): a tab widget (its
tab bar, its pages, the shown one) and the base of its pages (a page filled the first time it is shown, refreshed when shown again;
its defaults restored from the context menu of its tab button), a tab bar (a list of tabs on a side of their panel), a stack of pages
(one shown), a tool box (an accordion of pages under their headers).
"""

from __future__ import annotations
from functools import partial
from typing import Any, Callable, ClassVar, Mapping, Sequence, TYPE_CHECKING
from attrs import evolve, frozen
from . import Property, Widget
from .views import ListView
from ..gui import tab_margin
from ..style import GROUP_ALIGNS, TAB_SHAPES, Surface, surface, tokens
from ...ff.signals import ClassSignal
from ...kolang import L
if TYPE_CHECKING:
    from xbmcgui import Action


@frozen(kw_only=True)
class Page:
    """
    A page of a tab widget, a stack, a tool box in the template data (`TabWidget.page_of()`; a page declared in a template: its name
    and title, its content the place `<name>` of the use) and a static tab of a tab bar (its title).
    """

    #: The name: the path of the page in its widget, the window property `ffw.<id>.tab` / `ffw.<id>.current`.
    name: str
    #: The label of its tab (`MENU_TITLE`, else `TITLE`), its header.
    title: str = ''
    #: The widget of the page (its type in the template), '': the content `<name>` of the use.
    widget: str = ''
    #: The path of the control a click of its tab enters (in the page).
    default: str = ''
    #: The path of the control a move down from below the tabs (e.g. "Close") goes to: the top of the page (the moves wrap).
    top: str = ''
    #: The path of the control a move up from below the tabs goes to: the bottom of the page.
    bottom: str = ''
    #: The level of its tab: 0 a top one, 1 under the tab of its parent page before it (its title indented).
    level: int = 0
    #: The help of its tab (the window shows it while the tab is focused), '' none.
    help: str = ''

    def shown(self, n: int, stack_id: int, index: str = '') -> str:
        """
        Return the Kodi condition of the page shown, the `n`-th one (0-based) of its stack (the control `stack_id`: a stack, a tab
        widget, a tool box): the window property of its current page (`ffw.<stack_id>.current`), or - `index`, a Kodi info of the
        1-based index of the shown page - the page of that index.
        """
        if index:
            return f'Integer.IsEqual({index},{n + 1})'
        return f'String.IsEqual(Window.Property(ffw.{stack_id}.current),{self.name})'


@frozen(kw_only=True)
class TabRect:
    """A place in the row of a tab (`TabBarVars`): the tab, its body (its label, its focus ring)."""

    #: The left edge in the row.
    left: int
    #: The top edge in the row.
    top: int
    #: The width.
    width: int
    #: The height.
    height: int


@frozen(kw_only=True)
class TabBarVars:
    """
    The template data of a tab bar (`TabBar.template_bar()`): the side of its panel, the kind of its tabs, their sizes; the places in
    a row of the list (a tab and the gap after it) of a current tab (joined to its panel: over its edge) and of the others (behind it).
    """

    #: The side of the panel the bar is on (`TAB_SIDES`: W, N, E, S).
    side: str
    #: The kind of the tabs (`TAB_SHAPES`, resolved).
    shape: str
    #: Flat tabs (no texture: buttons by a line).
    flat: bool
    #: Tabs of a line (no panel: each tab draws its piece of the line beside the bar, the current one its outline open to the pages).
    line: bool
    #: A tab along the bar (its flare margins too).
    size: int
    #: A tab across the bar, behind its panel.
    depth: int
    #: How far a current tab lies over the edge of its panel (its width: a box; tabs of a line: the width of the line), 0 none.
    inset: int
    #: The gap between the tabs.
    spacing: int
    #: The margin of a tab texture along the bar at each end (the place of the flare).
    margin: int
    #: The text offset in the body of a tab.
    pad: int
    #: The title in its tab (`GROUP_ALIGNS`: left, center, right).
    align: str = 'center'
    #: A scrolled bar: the current tab at the edge of the view (`edge`: a Kodi list) or held at its start (`start`: a fixed list).
    scroll: str = 'edge'
    #: The free room before the start of the bar (out of its list: its mark of more tabs there if it fits, `more_marks`).
    room_start: int = 0
    #: The free room after the end of the bar.
    room_end: int = 0
    #: A static tab is a child of the one before it (`Page.level`): the titles of the children indented.
    nested: bool = False

    @property
    def vertical(self) -> bool:
        """Return True for a bar on the side W or E (a vertical list)."""
        return self.side in 'WE'

    @property
    def edge(self) -> bool:
        """Return True if a tab draws the edge of its panel (a textured tab of a panel with an edge)."""
        return not self.flat and not self.line and self.inset > 0

    @property
    def row_width(self) -> int:
        """Return the width of a row of the list (a tab and its gap)."""
        return self.depth + self.inset if self.vertical else self.size + self.spacing

    @property
    def row_height(self) -> int:
        """Return the height of a row of the list."""
        return self.size + self.spacing if self.vertical else self.depth + self.inset

    def place(self, current: bool) -> TabRect:
        """Return the place of a tab in its row: a current one across the whole row (over the edge of its panel), else behind it."""
        across = self.depth + (self.inset if current else 0)
        start = self.inset if not current and self.side in 'ES' else 0  # a tab behind its panel ends at its edge
        if self.vertical:
            return TabRect(left=start, top=0, width=across, height=self.size)
        return TabRect(left=0, top=start, width=self.size, height=across)

    def line_piece(self, start: int, end: int) -> TabRect:
        """Return the piece of the line of tabs of a line in a row, from `start` to `end` along the bar: on the edge towards the pages."""
        across = 0 if self.side in 'ES' else self.depth
        if self.vertical:
            return TabRect(left=across, top=start, width=self.inset, height=end - start)
        return TabRect(left=start, top=across, width=end - start, height=self.inset)

    def line_pieces(self, current: bool) -> tuple[TabRect, ...]:
        """
        Return the pieces of the line a row draws (tabs of a line; else none): a tab which is not current - along the whole row (the tab
        and its gap), the current one (its outline breaks the line) - along its gap only.
        """
        start, end = (self.size if current else 0), self.size + self.spacing
        return (self.line_piece(start, end),) if self.line and end > start else ()

    def line_tail(self) -> TabRect:
        """
        Return the line on from the end of a row as long as the window (`WINDOW_SIZE`; tabs of a line: the last row draws it, the list clips
        it at its end) - the line under the tabs of a bar longer than they are.
        """
        from ..geometry import WINDOW_SIZE
        end = self.size + self.spacing
        return self.line_piece(end, end + (WINDOW_SIZE.height if self.vertical else WINDOW_SIZE.width))

    def body(self, current: bool) -> TabRect:
        """Return the body of a tab in its row (its place without the flare margins along the bar): its label, its focus ring."""
        place = self.place(current)
        if self.vertical:
            return TabRect(left=place.left, top=self.margin, width=place.width, height=place.height - 2 * self.margin)
        return TabRect(left=self.margin, top=place.top, width=place.width - 2 * self.margin, height=place.height)


@frozen(kw_only=True)
class Place:
    """The place of a part of a widget in it: the Kodi geometry tags it has (None: not given)."""

    #: The left edge.
    left: int | None = None
    #: The top edge.
    top: int | None = None
    #: The right edge (from the right of the parent).
    right: int | None = None
    #: The bottom edge (from the bottom of the parent).
    bottom: int | None = None
    #: The width.
    width: int | None = None
    #: The height.
    height: int | None = None


@frozen(kw_only=True)
class TabWidgetVars:
    """
    The template data of a tab widget (`TabWidget.template_tabs()`): its tab bar, the look of its pane, the places of its parts, the
    move from the bar into the pages.
    """

    #: The tab bar.
    bar: TabBarVars
    #: The look of the pane (`surface()` of a panel).
    look: Surface
    #: The move from the bar towards the pages (`onright`: a bar on the side W ...).
    into: str
    #: The place of the bar.
    bar_place: Place
    #: The place of the content (the pages).
    content: Place
    #: The place of the pane (textured tabs; None: none).
    pane: Place | None = None
    #: The place of the line beside the bar (flat tabs; None: none - tabs of a line draw it themselves).
    line: Place | None = None


class TabPage(Widget):
    """A page of a tab widget: filled the first time it is shown (`fill()`), refreshed when shown again after a change."""

    #: The title of the page (the language of the call): the title of the window, its tab button (no `MENU_TITLE`; a page of the
    #: configuration: of its declaration `PAGE_REFS`, known with no import of the page).
    TITLE: ClassVar[Callable[[], str]] = staticmethod(lambda: '')  # type: ignore[assignment]
    #: The label of the tab button of the page (None: `TITLE`).
    MENU_TITLE: ClassVar[Callable[[], str] | None] = None
    #: The widget of the page in the template.
    WIDGET: ClassVar[str] = ''
    #: The path of the control a click of its tab enters (in the page).
    DEFAULT: ClassVar[str] = ''
    #: The path of the top control of the page (a move down from below the tabs; '': `DEFAULT`).
    TOP: ClassVar[str] = ''
    #: The path of the bottom control of the page (a move up from below the tabs; '': `DEFAULT`).
    BOTTOM: ClassVar[str] = ''
    #: The configuration branches of the page (`config.json` pointers): its defaults restored = these removed.
    DEFAULTS: ClassVar[tuple[str, ...]] = ()
    #: The name of the page this one is under (its tab after the one of the parent, its title indented), '' a top page.
    PARENT: ClassVar[str] = ''

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """A page of the configuration: its titles and its parent from its declaration (`PAGE_REFS`)."""
        from ..config_dialog import page_ref
        super().__init_subclass__(**kwargs)
        if (ref := page_ref(cls.__name__)) is not None:
            cls.TITLE = staticmethod(ref.title)  # type: ignore[assignment]
            cls.MENU_TITLE = staticmethod(ref.tab) if ref.tab is not None else None  # type: ignore[assignment]
            cls.PARENT = ref.parent

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """Return the template vars of the page (merged with the ones of the window and of the other pages: unique names)."""
        return {}

    @classmethod
    def default_path(cls) -> str:
        """Return the path of the control a click of its tab enters (`DEFAULT`; a page of data-made controls computes it)."""
        return cls.DEFAULT

    @classmethod
    def top_path(cls) -> str:
        """Return the path of the top control of the page (`TOP`, else the default one; a page of data-made controls computes it)."""
        return cls.TOP or cls.default_path()

    @classmethod
    def bottom_path(cls) -> str:
        """Return the path of the bottom control of the page (`BOTTOM`, else the default one; a page of data-made controls computes it)."""
        return cls.BOTTOM or cls.default_path()

    @classmethod
    def page_of(cls, name: str) -> Page:
        """Return the template data of the page of the name."""
        return Page(name=name, title=(cls.MENU_TITLE or cls.TITLE)(), widget=cls.WIDGET, default=cls.default_path(), top=cls.top_path(),
                    bottom=cls.bottom_path(), level=1 if cls.PARENT else 0)

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page: not filled yet."""
        super().__init__(*args, **kwargs)
        #: The changes of the window the page was refreshed at (None: not filled yet).
        self.refreshed: int | None = None
        #: The current rows of the lists of the page to restore after its fill (`restore()`) by the paths of the lists.
        self.restored_lists: dict[str, int] = {}

    def show(self, changes: int) -> None:
        """The page is shown: fill it the first time, refresh it after a change since its last refresh (`changes`: of the window)."""
        if self.refreshed != changes:
            first, self.refreshed = self.refreshed is None, changes
            if first:
                self.fill()
                for view in self.walk():
                    if isinstance(view, ListView) and view.path in self.restored_lists:
                        view.current = self.restored_lists[view.path]
            else:
                self.refresh()

    def fill(self) -> None:
        """Fill the page (the first time it is shown; the controls exist)."""

    def refresh(self) -> None:
        """Refresh the page (shown again after a change)."""

    def customized(self) -> bool:
        """Return True if the configuration of the page is not the default one (some of its `DEFAULTS` branches stored)."""
        from ...ff.config import config
        return any(config.get(pointer) is not None for pointer in self.DEFAULTS)

    def defaults_note(self) -> str:
        """Return what else restoring the defaults of the page does (the question asks it; none: '')."""
        return ''

    def restore_defaults(self) -> None:
        """Restore the configuration of the page as after a new installation (remove its `DEFAULTS` branches), show it again."""
        from ...ff.config import config
        config.remove(*self.DEFAULTS)
        self.refresh()

    def reopen_state(self) -> dict[str, Any]:
        """Return the state of the page the window opened again restores (`BaseDialog.reopen()`: only texts, numbers): the current rows of its lists."""
        return {'lists': {view.path: view.current for view in self.walk() if isinstance(view, ListView) and view.current > 0}}

    def restore(self, state: dict[str, Any]) -> None:
        """Restore the state of the page of the closed window (`reopen_state()`) before the page is filled: its lists after the fill."""
        self.restored_lists = state.get('lists', {})


class TabWidget(Widget):
    """
    A tab widget (Qt: QTabWidget): its tab bar (`bar`), the shown page (`current`, its name; the current tab of the bar), entered by a
    click of its tab, its defaults from the context menu of the bar. Dynamic tabs (the rows of the window on the bar): one page, always
    shown, its content changed by the window for the current tab (`bar.current_changed`).
    """

    #: The value: the shown page.
    VALUE = 'current'

    #: The name of the shown page ('' none).
    current: Property[str] = Property('')

    #: A tab with no page in this window (a page of another card) is clicked: its name.
    activated: ClassSignal = ClassSignal()

    @classmethod
    def template_tabs(cls, pages: Sequence[Page], tabs: Sequence[Page], side: str, shape: str, elide: str, size: int, depth: int, spacing: int,
                      gap: int, *, align: str = '', scroll: str = '', level: int = 1, margins: Mapping[str, int] | None = None,
                      length: int = 0) -> TabWidgetVars:
        """
        Return the template data of a tab widget: its tab bar (`TabBar.template_bar()` of the static tabs `tabs`; none: dynamic - one of
        `pages`) on the edge of its side, the places of its parts. Textured tabs: the bar cut to the side between its corners
        (`tab_offset()` at both ends: more tabs scroll in the list, the current one always in view), a current tab over the edge of the
        pane (the surface of its frame `level`), the pages in the padding of the pane. Flat tabs: the bar at the corner, a line in the
        middle of 2 gaps beside it, the pages a gap and `space.s` after the line. Tabs of a line: the bar at the corner, the line on the
        edge of its tabs (drawn by them), the pages a gap and `space.s` after it. The free room beyond the ends of the bar (its marks of
        more tabs there if it fits): from the edge of the widget (`tab_offset()`, textured tabs) and its free margins in its parent (`margins`:
        its geometry tags left, top, right, bottom less the parts of the parent there - `use_room()`; none: 0). `length`: the static tabs
        share the length of the widget along the bar (Qt `QTabBar.expanding`; less the ends of a textured bar and a gap a tab), 0 - their sizes.
        """
        from ..gui import TAB_SIDES, tab_offset
        if not tabs and len(pages) != 1:
            raise ValueError(f'Dynamic tabs (no static ones) show one page, not {len(pages)}')
        style = tokens()
        bar = TabBar.template_bar(tabs, side, shape, elide, size, depth, spacing, align=align, scroll=scroll, level=level)
        edge = TAB_SIDES[side].edge
        other = {'left': 'right', 'right': 'left', 'top': 'bottom', 'bottom': 'top'}[edge]
        into = {'left': 'onright', 'right': 'onleft', 'top': 'ondown', 'bottom': 'onup'}[edge]  # from the bar towards the pages
        along = ('top', 'bottom') if bar.vertical else ('left', 'right')
        across = 'width' if bar.vertical else 'height'
        look = surface(level)

        def ends(bar: TabBarVars) -> tuple[int, int]:
            """Return the ends of the bar off the edges of the widget: textured tabs between the corners of the pane, else none."""
            if bar.flat or bar.line:
                return 0, 0
            current = bar.place(True)
            start, end = (tab_offset(side, style.texture.panel, width=current.width, height=current.height, shape=bar.shape, end=end)
                          for end in (False, True))
            return start, end

        start, end = ends(bar)
        for _ in range(2 if length and tabs else 0):  # expanding: the ends of the bar by the size of a tab, again with the new size
            bar = TabBar.template_bar(tabs, side, shape, elide, (length - start - end) // len(tabs) - spacing, depth, spacing,
                                      align=align, scroll=scroll, level=level)
            start, end = ends(bar)
        margins = margins or {}
        bar = evolve(bar, room_start=start + margins.get(along[0], 0), room_end=end + margins.get(along[1], 0))
        if bar.flat or bar.line:  # no pane: the line beside the bar
            line = bar.depth + (gap if bar.flat else 0)
            return TabWidgetVars(bar=bar, look=look, into=into,
                                 bar_place=Place(**{edge: 0, across: bar.depth + bar.inset, along[0]: 0, along[1]: 0}),
                                 line=Place(**{edge: line, along[0]: 0, along[1]: 0}) if bar.flat else None,
                                 content=Place(**{edge: line + gap + style.space.s, other: 0, along[0]: 0, along[1]: 0}))
        pad = look.pad
        return TabWidgetVars(bar=bar, look=look, into=into,
                             bar_place=Place(**{edge: 0, across: bar.depth + bar.inset, along[0]: start, along[1]: end}),
                             pane=Place(**{edge: bar.depth, other: 0, along[0]: 0, along[1]: 0}),
                             content=Place(**{edge: bar.depth + pad, other: pad, along[0]: pad, along[1]: pad}))

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The tab widget: no change made yet."""
        super().__init__(*args, **kwargs)
        #: The changes made in the window (a shown page is refreshed after a change since its last refresh).
        self.changes: int = 0

    @property
    def bar(self) -> TabBar:
        """Return the tab bar."""
        return self.children['bar']  # type: ignore[return-value]

    def names(self) -> tuple[str, ...]:
        """Return the names of the pages of this window in the order of their tabs."""
        return tuple(self.entry.data.get('pages', ())) if self.entry is not None else ()

    def tab_names(self) -> tuple[str, ...]:
        """Return the names of the static tabs of the bar: of the pages of this window and of the other cards (dynamic tabs: none)."""
        return tuple(self.entry.data.get('tabs', ())) if self.entry is not None else ()

    @property
    def other_tab(self) -> str:
        """Return the name of the current tab of the bar if it has no page in this window (a page of another card), else ''."""
        names = self.tab_names()
        name = names[self.bar.current] if 0 <= self.bar.current < len(names) else ''
        return '' if name in self.names() else name

    @property
    def dynamic(self) -> bool:
        """Return True for dynamic tabs (the rows of the window on the bar, one page): no current page from the current tab."""
        return self.entry is not None and bool(self.entry.data.get('dynamic'))

    def page(self, name: str) -> TabPage | None:
        """Return the page of the name (built now if it was not needed yet), None: no such page."""
        return page if isinstance(page := self.child(name), TabPage) else None

    def built(self) -> None:
        """The current tab of the bar is the current page, a click of a tab enters its page."""
        from ..base import weak_callback
        super().built()
        self.bar.current_changed.connect(weak_callback(self._tab_changed))
        self.bar.activated.connect(weak_callback(self._tab_activated))

    def _tab_changed(self, index: int) -> None:
        """Another tab is the current one: its page is shown (dynamic tabs: the one page stays; a tab of another card: no page of this window)."""
        if not self.dynamic and 0 <= index < len(names := self.tab_names()) and names[index] in self.names():
            self.current = names[index]

    def _tab_activated(self, index: int) -> None:
        """A click of a tab enters its page (its default control); a tab of another card: `activated`."""
        if tab := self.other_tab:
            self.activated.emit(tab)
        elif (page := self.page(self.current)) is not None and (default := page.default_path()):
            self.win.setFocusId(page.find(default).id)  # type: ignore[attr-defined]

    def page_of_tab(self, control_id: int) -> TabPage | None:
        """Return the page of the current tab if the control is the tab bar (None: another control, a tab of another card)."""
        return self.page(self.current) if control_id == self.bar.id and not self.other_tab else None

    def apply_window_property(self, name: str) -> None:
        """The current page: the window property of the template (`ffw.<id>.tab`), the current tab of the bar."""
        if name == 'current':
            self.win.setProperty(f'ffw.{self.id}.tab', self.current)  # type: ignore[attr-defined]
            if not self.dynamic and self.current in (names := self.tab_names()):
                self.bar.current = names.index(self.current)
        super().apply_window_property(name)

    def apply_property(self, name: str) -> None:
        """Show the current page, fill or refresh it."""
        if name == 'current':
            self.apply_window_property(name)
            if (page := self.page(self.current)) is not None:
                page.show(self.changes)
        else:
            super().apply_property(name)

    def handle_action(self, action: Action) -> bool | None:
        """The context menu of the tab bar: restore the defaults of the current page (only if they are changed)."""
        from ..base import MENU_ACTIONS
        if action.getId() in MENU_ACTIONS and (page := self.page_of_tab(self.win.focused_id())) is not None:
            if page.customized():
                from ..context import ContextMenuDialog
                ContextMenuDialog(menu=[(L(30100, 'Restore defaults'), partial(self.restore_defaults, page))]).doModal()
            return True
        return None

    def restore_defaults(self, page: TabPage) -> None:
        """Ask, then restore the configuration of the page as after a new installation (the other pages are refreshed when shown)."""
        from ...ff.control import yesnoDialog
        question = L(30229, 'Restore the settings of "{tab}" as after a new installation?').format(tab=page.TITLE())
        if not yesnoDialog(*(text for text in (question, page.defaults_note()) if text), heading=page.TITLE()):
            return
        self.changes += 1
        page.restore_defaults()
        page.refreshed = self.changes


class TabBar(ListView):
    """
    A tab bar (Qt: QTabBar): a list of tabs (`rows`; the static tabs of the template are its rows at the start), the current one
    (`current`, `current_changed`) joined to its panel, a click of a tab (`activated(index)`).
    """

    @classmethod
    def template_bar(cls, tabs: Sequence[Page], side: str, shape: str, elide: str, size: int, depth: int, spacing: int, *,
                     align: str = '', scroll: str = '', level: int = 1) -> TabBarVars:
        """
        Return the template data of a tab bar on the side of its panel (`side`), its kind (`shape`, '' the style `tab.shape`), its sizes
        (0 derived): a tab along the bar (`size`) and across it (`depth`) - the side the text runs along is as long as the longest title
        of the static tabs (`tabs`) with its padding if the style or the use do not elide it (`elide` none, '' the style `text.elide`:
        the given size is the least one, as Qt `ElideNone`), else the given one or the longest title up to `metric.tab.width` (the
        text cut with an ellipsis: Kodi's label); with no static tab (the rows of Python) the given one, else a vertical tab of a row
        (`metric.row`) along and of a button (`metric.button.width`) across, a horizontal one of a tag (`metric.tag.height`) across and
        of a button along. A current tab lies over the edge of its panel (`level`: of the surface of that frame). Its title at `align`
        ('' the style `tab.align`), the bar scrolled with the current tab at the edge of the view or at its start (`scroll`, '' the style
        `tab.scroll`).
        """
        from ..skinfonts import text_metrics
        style = tokens()
        align, scroll = align or style.tab.align, scroll or style.tab.scroll
        if align not in GROUP_ALIGNS or scroll not in ('edge', 'start'):
            raise ValueError(f'Unknown align {align!r} or scroll {scroll!r} of a tab bar')
        shape = shape or style.tab.shape
        look, elide = TAB_SHAPES[shape], elide or style.text.elide
        vertical, pad = side in 'WE', style.space.l
        inset = 0 if look.flat else style.metric.separator.group if look.line else surface(level).edge_width  # a line: its width
        width_of, _ = text_metrics('normal')
        text = max((round(width_of(tab.title)) + tab.level * style.space.l for tab in tabs), default=0)  # a child: its title indented
        if elide != 'none':  # a longer title elided by Kodi
            text = min(text, style.metric.tab.width)
        margin = 0
        if vertical:
            size = size or style.metric.row
            margin = tab_margin(side, width=depth or style.metric.button.width, height=size, shape=shape)
            need = text + 2 * pad if text else 0
            depth = max(depth, need) if elide == 'none' and need else depth or need or style.metric.button.width
        else:
            depth = depth or style.metric.tag.height
            margin = tab_margin(side, width=size or style.metric.button.width, height=depth, shape=shape)
            need = text + 2 * (pad + margin) if text else 0
            size = max(size, need) if elide == 'none' and need else size or need or style.metric.button.width
        return TabBarVars(side=side, shape=shape, flat=look.flat, line=look.line, size=size, depth=depth, inset=inset, spacing=spacing, margin=margin,
                          pad=pad, align=align, scroll=scroll, nested=any(tab.level for tab in tabs))

    def built(self) -> None:
        """The static tabs of the template are the rows."""
        super().built()
        if self.entry is not None and (tabs := self.entry.data.get('tabs')):
            self.rows = tabs


class Stack(Widget):
    """
    A stack of pages (Qt: QStackedWidget): one page shown, the current one (`current`, its name; the first one at the start) - unless
    the template shows the page of an index of Kodi (the param `index`: e.g. the current item of a list), then the page follows it.
    """

    #: The value: the shown page.
    VALUE = 'current'

    #: The name of the shown page ('' the first one).
    current: Property[str] = Property('')

    def pages(self) -> tuple[str, ...]:
        """Return the names of the pages in their order."""
        return tuple(self.entry.data.get('pages', ())) if self.entry is not None else ()

    def built(self) -> None:
        """The first page shown at the start."""
        super().built()
        if not self.current and (pages := self.pages()):
            self.current = pages[0]

    def apply_window_property(self, name: str) -> None:
        """Show the current page (the window property of the template: no controls needed)."""
        if name == 'current':
            self.win.setProperty(f'ffw.{self.id}.current', self.current)  # type: ignore[attr-defined]
        super().apply_window_property(name)

    def apply_property(self, name: str) -> None:
        """Show the current page."""
        if name == 'current':
            self.apply_window_property(name)
        else:
            super().apply_property(name)


class ToolBox(Stack):
    """
    A tool box (Qt: QToolBox): the pages in a column under their headers (the buttons `head_<name>`), the current one open
    (`current`), a click of a header opens its page.
    """

    def built(self) -> None:
        """The first page open at the start; a click of a header opens its page."""
        from ..base import weak_callback
        super().built()
        for name in self.pages():
            self.children[f'head_{name}'].clicked.connect(partial(weak_callback(self.open), name))

    def open(self, name: str) -> None:
        """Open the page (its header clicked)."""
        self.current = name
