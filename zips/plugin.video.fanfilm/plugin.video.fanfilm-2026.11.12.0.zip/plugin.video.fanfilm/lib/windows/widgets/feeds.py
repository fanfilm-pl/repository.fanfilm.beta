"""
The page of the data providers of the configuration window: who gives the data of the fixed entries of `/movie` and `/show`
(`lib.ff.lists_config.FEEDS`: one service of a row; a service not available now gives the base, TMDB) and the VOD services of
the user (the subscriptions: new VOD titles of them only).
"""

from __future__ import annotations
from functools import partial
from typing import Any
from attrs import frozen
from .buttons import ButtonGroup, CheckBox
from .tabs import TabPage
from ...ff import lists_config as lc
from ...kolang import L


def feed_services() -> list[str]:
    """Return the services of the columns: of all the fixed entries, in their order (the base last)."""
    out: list[str] = []
    for fd in lc.FEEDS:
        out.extend(srv for srv in fd.services if srv not in out)
    return out


def subscriptions_text(count: int) -> str:
    """Return the text of the button of the VOD services of the user (their count)."""
    return L(32976, 'My VOD services ({n})').format(n=count)


def feed_rows() -> list[lc.Feed]:
    """Return the fixed entries of the rows: the ones with a choice (more providers)."""
    return [fd for fd in lc.FEEDS if len(fd.services) > 1]


@frozen(kw_only=True)
class FeedRow:
    """The template vars of a row: a fixed entry, the columns of its providers."""

    #: The position of the row (from 0).
    index: int
    #: The label.
    label: str
    #: The columns (the services) the entry can take its data from.
    columns: frozenset[int]


@frozen(kw_only=True)
class FeedColumn:
    """The template vars of a column: its service (the value of its switches), its label."""

    #: The service.
    service: str
    #: The label.
    label: str


class FeedsPage(TabPage):
    """The page of the data providers."""

    WIDGET = 'feeds_page'
    DEFAULTS = (lc.FEEDS_CONFIG, lc.SUBSCRIPTIONS_CONFIG)
    BOTTOM = 'subscriptions'

    @classmethod
    def default_path(cls) -> str:
        """Return the path of the first switch (the default control of the page)."""
        services = feed_services()
        return next((f'cell_{r}_{c}' for r, fd in enumerate(feed_rows()) for c, srv in enumerate(services) if srv in fd.services),
                    'subscriptions')

    @classmethod
    def xml_vars(cls) -> dict[str, Any]:
        """
        The structure of the page: the columns (services), the rows (fixed entries) and the columns of their providers, the width of
        the button of the VOD services by its text (of two digits) in its font.
        """
        from math import ceil
        from ...ff.accounts import SERVICE_TYPES
        from ..skinfonts import text_metrics
        from ..style import tokens
        services = feed_services()
        width_of, _ = text_metrics('normal')  # the font of a button
        return {'FEED_COLS': [FeedColumn(service=srv, label=SERVICE_TYPES[srv].label if srv in SERVICE_TYPES else srv) for srv in services],
                'FEED_ROWS': [FeedRow(index=r, label=fd.label(), columns=frozenset(c for c, srv in enumerate(services) if srv in fd.services))
                              for r, fd in enumerate(feed_rows())],
                'FEED_VOD': L(32975, 'VOD services'),
                'FEED_VOD_WIDTH': max(tokens().metric.button.height, ceil(width_of(subscriptions_text(99))) + 2 * tokens().space.l)}

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """The page, there are no Kodi controls yet."""
        super().__init__(*args, **kwargs)
        self.services: list[str] = feed_services()
        self.rows: list[lc.Feed] = feed_rows()

    def built(self) -> None:
        """The groups of the rows connected, the help of the controls."""
        for r, fd in enumerate(self.rows):
            self.find(f'row_{r}', cls=ButtonGroup).changed.connect(partial(self.choose, r))
            for c, srv in enumerate(self.services):
                if srv in fd.services:
                    self.find(f'cell_{r}_{c}', cls=CheckBox).help = self.cell_help(r, c)
        self.find('subscriptions').help = L(32979, 'The VOD services you have: "New VOD releases" shows the new titles of them only.')

    def fill(self) -> None:
        """Set the switches (the controls exist now)."""
        self.refresh()

    def refresh(self) -> None:
        """Set the switches from the user settings, the number of the VOD services."""
        for r, fd in enumerate(self.rows):
            self.find(f'row_{r}', ButtonGroup).value = lc.feed(fd.key)
        self.find('subscriptions').text = subscriptions_text(len(lc.subscriptions()))

    def choose(self, r: int, service: str) -> None:
        """A provider of a row chosen (its button group), written at once."""
        lc.set_feed(self.rows[r].key, service)
        self.refresh()

    def on_subscriptions_clicked(self) -> None:
        """Choose the VOD services of the user (a multi choice of the services of the country, JustWatch), written at once."""
        from xbmcgui import Dialog
        from ...api.justwatch import JustWatchError, justwatch_app
        from ...ff.control import busy_section, infoDialog
        try:
            with busy_section():
                packages = justwatch_app.packages()
        except (JustWatchError, OSError) as exc:
            from ...ff.logs import fflog
            fflog(f'[FEEDS] JustWatch services: {exc}')
            infoDialog(L(32977, 'JustWatch does not answer, try again later'), icon='ERROR')
            return
        mine = lc.subscriptions()
        known = {short for short, _ in packages}
        packages.extend((short, short) for short in sorted(mine - known))  # a service of the user JustWatch does not list now
        chosen = Dialog().multiselect(L(32978, 'My VOD services'), [name for _, name in packages],
                                      preselect=[i for i, (short, _) in enumerate(packages) if short in mine])
        if chosen is None:  # canceled
            return
        lc.set_subscriptions(packages[i][0] for i in chosen)
        self.refresh()

    def cell_help(self, r: int, c: int) -> str:
        """Return the help of a switch."""
        from ...ff.accounts import SERVICE_TYPES, general_available
        srv = self.services[c]
        name = SERVICE_TYPES[srv].label if srv in SERVICE_TYPES else srv
        text = L(32980, '{entry} from {service}.').format(entry=self.rows[r].label(), service=name)
        if srv != self.rows[r].services[-1] and not general_available(srv):
            text += ' ' + L(30186, 'Not available now (an account or a key is needed): TMDB gives them.')
        return text
