"""
The debrid services of the configuration window (its page: `lib.windows.widgets.debrid`): the debrids of ResolveURL in their
priority order (up, down) and the panel of the debrid of the list (its account: authorize, revoke, enabled, the settings of
ResolveURL). ResolveURL keeps the accounts, the view shows them and changes them at once (`lib.ff.debrid`); the account info
(the user, the end of premium) is asked from the services in the background while the window is open.
"""

from __future__ import annotations
from math import ceil
from string import ascii_uppercase
from typing import Any, Callable
from typing_extensions import Literal, Protocol, TypeAlias, get_args
from attrs import frozen, field
from .base import WindowRef
from .style import tokens
from ..ff import debrid
from ..ff.debrid import DEBRIDS, INITIALS, DebridAccount, DebridInfo
from ..kolang import L

#: An action on a debrid in the view.
DebridActionName: TypeAlias = Literal['up', 'down', 'authorize', 'revoke', 'settings', 'active']
#: A switch of the view: "Active" of the debrid, "Use debrid services".
DebridSwitch: TypeAlias = Literal['active', 'allowed']
#: The actions of the controls of the panel and the tools (in their order).
CONTROL_ACTIONS: tuple[DebridActionName, ...] = get_args(DebridActionName)


@frozen(kw_only=True)
class DebridAction:
    """An action on a debrid in the view: may it run now, its label and its help (what it does or why it can not)."""

    #: True if the action can run now.
    available: bool = False
    #: The label (a button).
    label: str = ''
    #: What it does, or why it can not run now.
    help: str = ''


@frozen(kw_only=True)
class DebridPanel:
    """The panel of a debrid (the page shows it)."""

    #: The debrid account (None: no debrid).
    account: DebridAccount | None = None
    #: The title: the name and the user.
    title: str = ''
    #: The short name, the state.
    info: str = ''
    #: The premium (the end of it).
    summary: str = ''
    #: The actions by name.
    actions: dict[DebridActionName, DebridAction] = field(factory=dict)


def state_label(account: DebridAccount, allowed: bool) -> str:
    """Return the label of the state of the debrid account (`allowed`: ResolveURL uses the debrid services)."""
    if not account.authorized:
        return L(30723, 'not authorized')
    if not allowed:
        return L(30747, 'debrid services off')
    return L(30715, 'active') if account.enabled else L(32887, 'off')


def premium_label(info: DebridInfo | None) -> str:
    """Return the label of the premium of the account, '' if not known."""
    from ..ff.calendar import from_timestamp
    if info is None:
        return ''
    if not info.premium:
        return L(30724, 'No premium: the debrid opens nothing or little')
    if info.until:
        return L(30725, 'Premium until {date}').format(date=from_timestamp(info.until).strftime('%Y-%m-%d'))
    return L(30301, 'Premium')


def panel_of(account: DebridAccount, info: DebridInfo | None, index: int, count: int, allowed: bool) -> DebridPanel:
    """Return the panel of the debrid account (`index` of `count`: its place in the priority order, `allowed`: the debrid services used)."""
    user = info.user if info else ''
    authorize_help = L(30726, 'Authorize the account in ResolveURL (a code or a PIN on the page of the service).')
    actions: dict[DebridActionName, DebridAction] = {
        'up': DebridAction(available=index > 0, label=L(32863, 'Move up'),
                           help=L(30727, 'Move the debrid up: the order is the priority (ResolveURL), the first one opens a source first.')
                           if index > 0 else L(30728, 'The debrid is the first one.')),
        'down': DebridAction(available=index < count - 1, label=L(32866, 'Move down'),
                             help=L(30729, 'Move the debrid down: the order is the priority (ResolveURL), the first one opens a source first.')
                             if index < count - 1 else L(30730, 'The debrid is the last one.')),
        'authorize': DebridAction(available=account.can_authorize, label=L(30731, 'Authorize again…') if account.authorized else L(30732, 'Authorize…'),
                                  help=authorize_help if account.can_authorize else L(30733, 'The account is set in the settings of ResolveURL.')),
        'revoke': DebridAction(available=account.can_revoke, label=L(32925, 'Revoke…'),
                               help=L(30734, 'Forget the authorization of the account in ResolveURL.') if account.can_revoke
                               else L(30735, 'Not available: the account is not authorized')),
        'settings': DebridAction(available=True, label=L(30748, 'ResolveURL…'),
                                 help=L(30737, 'The settings of ResolveURL: torrents, cached only, the cloud of the services and more.')),
        'active': DebridAction(available=account.authorized, label=L(32881, 'Active'),
                               help=L(30738, 'An inactive debrid keeps its account and opens nothing.') if account.authorized
                               else L(30735, 'Not available: the account is not authorized')),
    }
    return DebridPanel(account=account, title=f'{account.name} ({user})' if user else account.name,
                       info=' · '.join((account.short, state_label(account, allowed))), summary=premium_label(info), actions=actions)


@frozen(kw_only=True)
class DebridLayout:
    """The structure of the page: the sizes, the texts of the template."""

    #: The gap between the list, the tools and the panel.
    gap: int
    #: The width of the list.
    list_width: int = 450
    #: The width (and the height) of a tool button.
    tool_width: int
    #: The width of the initials of a debrid in its row (the widest ones in their font).
    badge_width: int
    #: The label of "Active".
    active_label: str = ''
    #: The label of "Use debrid services".
    allowed_label: str = ''
    #: The text of no debrid at all.
    none_label: str = ''

    @property
    def panel_left(self) -> int:
        """Return the start of the panel (after the list and the tools)."""
        return self.list_width + self.gap + self.tool_width + self.gap


def debrid_layout() -> DebridLayout:
    """Return the structure of the page (the language of the call)."""
    from .skinfonts import text_metrics
    width_of, _ = text_metrics('heading')  # the font of the initials (debrid.xml)
    badge_width = ceil(max(INITIALS * max(width_of(c) for c in ascii_uppercase), *(width_of(srv.short) for srv in DEBRIDS)))
    return DebridLayout(gap=tokens().space.l, tool_width=tokens().metric.button.height, badge_width=badge_width, active_label=L(32881, 'Active'),
                        allowed_label=L(30741, 'Use debrid services'), none_label=L(30742, 'ResolveURL has no debrid services.'))


def row_info(account: DebridAccount, info: DebridInfo | None, allowed: bool) -> str:
    """Return the second line of the row of the debrid: its state and its user (`info`: its account info, None not known yet)."""
    return ' · '.join(t for t in (state_label(account, allowed), info.user if info else '') if t)


@frozen(kw_only=True)
class DebridListRow:
    """A row of the list of the debrids as shown (a debrid not active or not used: grayed)."""

    #: The name of the debrid.
    name: str
    #: The state and the user.
    info: str
    #: The initials.
    initials: str
    #: A debrid not active or not used: its name and its initials in the background text.
    dim: bool

    @classmethod
    def of(cls, account: DebridAccount, info: DebridInfo | None, allowed: bool) -> DebridListRow:
        """Return the shown row of the debrid (`info`: its account info, `allowed`: the debrid services used)."""
        return DebridListRow(name=account.name, info=row_info(account, info, allowed), initials=account.initials,
                             dim=not (account.active and allowed))


def action_account(panel: DebridPanel, action: DebridActionName) -> DebridAccount | None:
    """Return the debrid of the panel if the action can run now, else None (a grayed control: a dead key, the footer tells why)."""
    if (acc := panel.account) is None or action not in panel.actions or not panel.actions[action].available:
        return None
    return acc


class DebridView(Protocol):
    """A view of the debrids (the page of the configuration window): what the operations of the view use."""

    #: The debrids in their priority order.
    accounts: list[DebridAccount]
    #: The account info by the debrid name (asked in the background).
    infos: dict[str, DebridInfo | None]
    #: The panel of the debrid of the list.
    panel: DebridPanel

    #: The window, kept weakly (`WindowRef`).
    win: WindowRef[Any]

    def show_debrids(self, *, select: str | None = None) -> None:
        """Show the debrids again (after a change) with the debrid `select` (else the same place in the list)."""

    def ask_infos(self) -> None:
        """Ask the account info of the authorized debrids in the background."""


def run_action(view: DebridView, action: DebridActionName, account: DebridAccount | None) -> None:
    """A button: the action on the debrid (written at once in ResolveURL, the view shows the new state); `account` None: none."""
    from ..ff.ui import ui
    if action == 'settings':
        from resolveurl.lib import kodi
        kodi.show_settings()  # waits for the dialog
        debrid.invalidate()
        view.infos.clear()
        view.show_debrids()
        view.ask_infos()
    elif account is None:
        return
    elif action in ('up', 'down'):
        if debrid.move(account, -1 if action == 'up' else 1):
            view.show_debrids(select=account.name)
    elif action == 'authorize':
        view.infos.pop(account.name, None)
        if not debrid.authorize(account):
            # ResolveURL tells nothing: a cancel and a failure (e.g. a token not stored) look the same
            ui.notify(account.name, L(30750, 'ResolveURL has not stored the authorization (canceled or failed in ResolveURL)'), error=True)
        view.show_debrids(select=account.name)
        view.ask_infos()
    elif action == 'revoke':
        if ui.confirm(L(30745, 'Forget the authorization of {name} in ResolveURL?').format(name=account.name), heading=L(32925, 'Revoke…')):
            debrid.revoke(account)
            view.infos.pop(account.name, None)
            view.show_debrids(select=account.name)


def run_switch(view: DebridView, name: DebridSwitch, value: bool) -> None:
    """A switch clicked: "Active" of the debrid or "Use debrid services" (a grayed one keeps its state: shown again)."""
    if name == 'active':
        if (acc := action_account(view.panel, 'active')) is not None:
            debrid.set_enabled(acc, value)
    else:
        debrid.set_debrids_allowed(value)
    view.show_debrids(select=view.panel.account.name if view.panel.account else None)


def ask_infos_in_thread(view: DebridView, show: Callable[[str], None]) -> None:
    """Ask the account info of the authorized debrids in a thread (into `view.infos`), `show(name)` after each while the window is open."""
    from ..ff.threads import Thread

    def ask() -> None:
        """Ask the infos one by one."""
        try:
            if not view.win.wait_ready():
                return
            for acc in list(view.accounts):
                if acc.authorized and acc.name not in view.infos:
                    view.infos[acc.name] = debrid.account_info(acc)
                    if view.win.wait_ready(0):
                        show(acc.name)
        except ReferenceError:  # the window is gone (the view keeps it weakly)
            return

    Thread(target=ask, name='debrid-info', daemon=True).start()
