"""
The widget demo (a developer tool, like Qt's `qtdemo`): a page of every widget (`DemoPage`, declared by its caller, the dev
route `lib/indexers/dev/widgets.py`) with a sample of the widget, its template parameters (a change closes the window, the
caller opens it again with the new values: `WidgetDemo.do_modal()` returns them) and its properties (changed live). It tells the
active themes (their style is the one of all the windows: `lib.ff.theme.theme_folders()`, the base one last); the
page of the style shows its colours: the tokens and the colour functions of them (`DEMO_COLORS`), the page of the textures the tab
shapes (`DEMO_TAB_SHAPES`) and the frame shapes (`FRAME_SHAPES`), the pages of the kinds of a slider and of a spin box their scales
(`DEMO_SLIDERS`, `DEMO_SPIN_BOXES`), the page of a slider in a field its sliders (`DEMO_FIELD_SLIDERS`, `DEMO_ROW_SLIDERS`) and the
settings of its list (`DEMO_SETTINGS`), the page of a switch its switches (`DEMO_SWITCHES`).
"""

from __future__ import annotations
from functools import partial
from math import ceil
from reprlib import Repr
from typing import Any, Callable, ClassVar, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import TypeAlias
from attrs import Factory, evolve, field, frozen
from .base import BaseDialog, weak_callback
from .scale import Scale, ScaleValue
from .style import RX_PART, TAB_SHAPES, evaluate, tokens
from .xgui import CONTENT_ANCHORED
from .widgets.tabs import Page
from ..kolang import L
if TYPE_CHECKING:
    from .widgets import Widget

#: The prefix of the add-on IDs of the themes (left out of their names in the tag of the active themes).
THEME_PREFIX: str = 'script.fanfilm.theme.'

#: The values of the template parameters of the pages: the name of a page -> its parameter -> its value.
DemoValues: TypeAlias = 'Mapping[str, Mapping[str, Any]]'


def value_text(value: Any) -> str:
    """
    Return the text of a value in a combo box: a text as it is (no quotes; '' quoted: the empty one), a sequence of records their number and
    kind (`15 × ComboItem`: their reprs too long to tell them apart), else its short form (`SHORT`).
    """
    if isinstance(value, str) and value:
        return value
    if isinstance(value, (tuple, list)) and value and not isinstance(value[0], (str, int, float)):
        return f'{len(value)} × {type(value[0]).__name__}'
    return SHORT.repr(value)


def switched(values: Sequence[Any]) -> bool:
    """Return True for the values of a switch (False, True in any order): a check box, else a combo box chooses one."""
    return len(values) == 2 and set(values) == {False, True}


@frozen
class DemoParam:
    """A template parameter of a sample: its values (its combo box chooses one, a check box switches two; the window opens again)."""

    #: The parameter of the widget.
    name: str
    #: Its values (the first one: the value of the sample at the start).
    choices: tuple[Any, ...]

    @property
    def switch(self) -> bool:
        """Return True if a check box switches the values (on / off), else a combo box chooses one."""
        return switched(self.choices)

    @property
    def texts(self) -> tuple[str, ...]:
        """Return the texts of the values (the items of its combo box: the values alone, the parameter is its caption)."""
        return tuple(value_text(value) for value in self.choices)


@frozen
class DemoProp:
    """A property (`Property`) of a sample: its values (its combo box sets one at once, a check box switches two)."""

    #: The property of the widget class.
    name: str
    #: Its values (the first one: set when the window opens).
    values: tuple[Any, ...]

    @property
    def switch(self) -> bool:
        """Return True if a check box switches the values (on / off), else a combo box chooses one."""
        return switched(self.values)

    @property
    def texts(self) -> tuple[str, ...]:
        """Return the texts of the values (the items of its combo box: the values alone, the property is its caption)."""
        return tuple(value_text(value) for value in self.values)


@frozen(kw_only=True)
class DemoPage:
    """A page of the demo: a sample of one widget, its template parameters, its properties."""

    #: The widget (its name in the catalog).
    widget: str
    #: The name of the page (in the list of the pages, in the paths of its widgets): the widget by default.
    name: str = field(default=Factory(lambda self: self.widget, takes_self=True))
    #: The fixed parameters of the sample (the required ones, the data of the template).
    args: Mapping[str, Any] = field(factory=dict)
    #: The template parameters to change (the window opens again).
    params: tuple[DemoParam, ...] = ()
    #: The properties to change live (besides `COMMON_PROPS`).
    props: tuple[DemoProp, ...] = ()
    #: The width of the place of the sample (the geometry of the use).
    width: int = 400
    #: The height of the place of the sample.
    height: int = 70
    #: The look of a widget whose look comes from its use: a define of the demo template (the children of the use, '' none).
    look: str = ''
    #: Prepare the sample when the window opens (data which is no property, e.g. the model of a tree; None: nothing).
    setup: Callable[[Widget], None] | None = field(default=None, repr=False, eq=False)

    def value(self, param: DemoParam, values: DemoValues) -> Any:
        """Return the value of the template parameter of the page (`values`: of all the pages)."""
        return values.get(self.name, {}).get(param.name, param.choices[0])

    def sample_args(self, values: DemoValues) -> dict[str, Any]:
        """Return the parameters of the sample: the fixed ones, the values of the template parameters."""
        return {**self.args, **{param.name: self.value(param, values) for param in self.params}}

    def bar_move(self, values: DemoValues) -> str:
        """
        Return the move from the content of a page of the sample to its tab bar (a tab widget of a side: towards it - `onleft` for W ...),
        '' none.
        """
        from .focus_lines import COLUMN, ROW
        from .gui import TAB_SIDES
        if self.widget != 'tab_widget' or not (side := self.sample_args(values).get('side', '')):
            return ''
        edge = TAB_SIDES[side].edge
        return next(axis.backward if edge == axis.start else axis.forward for axis in (ROW, COLUMN) if edge in (axis.start, axis.end))

    def all_props(self) -> tuple[DemoProp, ...]:
        """Return the properties to change live: the own ones, the ones of every widget."""
        return (*self.props, *COMMON_PROPS)

    def tristate(self, prop: DemoProp, values: DemoValues) -> bool:
        """Return True if the check box of the property has a third value: the value of a tristate check box (its param `tristate`)."""
        from .widgets.buttons import CheckBox
        return prop.switch and prop.name == CheckBox.VALUE and bool(self.sample_args(values).get('tristate'))


@frozen
class DemoColor:
    """A colour of the style shown by the demo: its expression (`style.evaluate()`), its value, the colour it is made of."""

    #: The expression: a reference to a token or a colour function of them.
    expression: str

    @property
    def value(self) -> str:
        """Return the value of the expression in the style of the windows."""
        return str(evaluate(self.expression, tokens().values.__getitem__))

    @property
    def base(self) -> str:
        """Return the value of the first token of the expression (the colour it is made of)."""
        return str(tokens().values[next(part[1:-1] for part in RX_PART.findall(self.expression) if part[0] == '{')])


#: The colours of the page of the style: the surfaces of the levels and the states of a card (tokens), the colour functions of
#: base tokens (lighter / darker in points and in percent, alpha, mix).
DEMO_COLORS: tuple[DemoColor, ...] = tuple(DemoColor(expression) for expression in (
    '{color.bg.dialog}', '{color.bg.panel}', '{color.bg.card}', '{color.bg.card.focused}', '{color.bg.card.selected}', '{color.bg.tag}',
    '{color.accent}', 'lighter({color.accent}, 20)', 'lighter({color.accent}, 20%)', 'darker({color.accent}, 20)',
    'darker({color.accent}, 50%)', 'alpha({color.accent}, 40%)', 'mix({color.accent}, {color.error}, 50%)',
    '{color.bg.panel}', 'lighter({color.bg.panel}, 10)', 'lighter({color.bg.panel}, 10%)', 'mix({color.bg.panel}, {color.accent}, 25%)',
    'alpha({color.text}, 66)',
))

#: The pages of a stack, a tool box, a tab widget, a tree as a tab bar (their contents: the places of the demo template of their names).
DEMO_STACK_PAGES: tuple[Page, ...] = (Page(name='alpha', title='Alpha'), Page(name='beta', title='Beta'),
                                      Page(name='gamma', title='Gamma of a longer title'))

#: The pages of a tab widget with more and longer tabs than its side (the bar scrolls, long titles elided): no content.
DEMO_MANY_PAGES: tuple[Page, ...] = tuple(Page(name=f'page{n}', title=f'Page {n} of a rather long title of a tab of the demo' if n % 3 else f'Page {n}')
                                          for n in range(1, 13))

#: The scale of the sample of a slider: percents, a tick every 5, a labelled one every 25.
DEMO_SCALE: Scale = Scale(minimum=0, maximum=100, step=5, minor=1, major=5, format='{} %')


#: The scale of a range: sizes, off at both ends (no bound).
DEMO_RANGE_SCALE: Scale = Scale(minimum=1, maximum=50, step=1, major=10, low=(ScaleValue(0, 'off'),), high=(ScaleValue(0, 'off'),), format='{} GB')

#: The scales of the spin boxes of the bounds of a range (`DEMO_RANGE_SCALE`): the minimum one off at the low end, the maximum one off at the
#: high end (the positions of the knobs of the range: `Scale.knob_positions()`).
DEMO_RANGE_BOUNDS: dict[str, Scale] = {
    'low': Scale(minimum=1, maximum=50, step=1, major=10, low=(ScaleValue(0, 'off'),), format='{} GB'),
    'high': Scale(minimum=1, maximum=50, step=1, major=10, high=(ScaleValue(0, 'off'),), format='{} GB'),
}

#: The scale of the sample of a spin box: sizes, a big step (Page up / down) to every ten.
DEMO_SPIN_SCALE: Scale = Scale(minimum=0, maximum=100, step=1, major=10, format='{} GB')


@frozen(kw_only=True)
class DemoSlider:
    """A slider of the page of the kinds of a slider (a spin box of the page of the kinds of a spin box): its scale and its look."""

    #: The caption of the slider.
    caption: str
    #: The scale.
    scale: Scale
    #: The value at the start.
    value: Any = None
    #: The mode of a slider (`SLIDER_MODES`, '' by the scale).
    mode: str = ''
    #: The fill from this value (None: from the end).
    origin: Any = None
    #: A meter (no focus).
    readonly: bool = False


#: The horizontal sliders of the page of the kinds of a slider (the vertical one: `DEMO_SCALE`).
DEMO_SLIDERS: tuple[DemoSlider, ...] = (
    DemoSlider(caption='log 1-2-5', scale=Scale(minimum=1, maximum=1000, log=(1, 2, 5), format='{} MB'), value=20),
    DemoSlider(caption='enum (value)', scale=Scale(values=(ScaleValue('lo', 'Low'), ScaleValue('mid', 'Middle'), ScaleValue('hi', 'High'))), value='mid'),
    DemoSlider(caption='off at the end', scale=Scale(minimum=1, maximum=50, step=1, major=10, high=(ScaleValue(0, 'off'),), format='{} GB'), value=0),
    DemoSlider(caption='min', scale=Scale(minimum=1, maximum=50, step=1, major=10, low=(ScaleValue(0, 'off'),), format='{} GB'), value=5, mode='min'),
    DemoSlider(caption='range', scale=DEMO_RANGE_SCALE, value=(5, 20), mode='range'),
    DemoSlider(caption='two-sided', scale=Scale(minimum=-10, maximum=10, step=1, minor=1, major=5), value=-4, origin=0),
    DemoSlider(caption='meter', scale=DEMO_SCALE, value=60, readonly=True),
)

#: The sliders in a field of the page of a slider in a field by their names (`caption`: the label of the field).
DEMO_FIELD_SLIDERS: dict[str, DemoSlider] = {
    'percent': DemoSlider(caption='Opacity:', scale=DEMO_SCALE, value=40),
    'range': DemoSlider(caption='Size:', scale=DEMO_RANGE_SCALE, value=(5, 20), mode='range'),
}

#: The sliders in a field in the rows of the list of the page of a slider in a field by their names (`DemoSetting.slider`): a density (a
#: factor of the spacing: fixed values with their labels), a size (a range).
DEMO_ROW_SLIDERS: dict[str, DemoSlider] = {
    'density': DemoSlider(caption='', scale=Scale(values=tuple(ScaleValue(factor, f'{round(factor * 100)} %') for factor in (.8, .9, 1.0, 1.1, 1.25))),
                          mode='value'),
    'size': DemoSlider(caption='', scale=DEMO_RANGE_SCALE, mode='range'),
}


@frozen(kw_only=True)
class DemoSetting:
    """A row of the list of the page of a slider in a field: a setting edited by the slider of its kind on a card at the row."""

    #: The label of the row.
    label: str
    #: The slider of the row (its name in the row, its scale): `density`, `size` (a range).
    slider: str
    #: The value at the start.
    value: Any


#: The rows of the list of the page of a slider in a field.
DEMO_SETTINGS: tuple[DemoSetting, ...] = (
    DemoSetting(label='Density', slider='density', value=1.0),
    DemoSetting(label='Size of a source', slider='size', value=(1, 20)),
    DemoSetting(label='Density of a list', slider='density', value=.9),
    DemoSetting(label='Size of a download', slider='size', value=(0, 0)),
)

@frozen
class DemoFilter:
    """A row of the list of the page of the toggle switches: a filter of three values (`CheckBox.checked`: must, must not, any)."""

    #: The label of the row.
    label: str
    #: Must (True), must not (False), any (None): the check state of the row (`views.CHECK_PROPERTY`).
    checked: bool | None = None


#: The rows of the list of the page of the toggle switches (OK on a row: its next value).
DEMO_FILTERS: tuple[DemoFilter, ...] = (DemoFilter('Lector'), DemoFilter('Subtitles', True), DemoFilter('Dubbing', False), DemoFilter('3D'))

#: The spin boxes of the page of the kinds of a spin box of a scale of the template (besides them: one of a scale of Python).
DEMO_SPIN_BOXES: tuple[DemoSlider, ...] = (
    DemoSlider(caption='log 1-2-5', scale=Scale(minimum=1, maximum=1000, log=(1, 2, 5), format='{} MB'), value=20),
    DemoSlider(caption='off at the low end', scale=Scale(minimum=1, maximum=50, step=1, major=10, low=(ScaleValue(0, 'off'),), format='{} GB'), value=0),
)

#: The textures of the switches of the page of a switch (`switch_texture()`): the family of their count of positions (`count`).
DEMO_SWITCH_LOOK: str = 'dialogs/dial{count}'

#: The switches of the page of a switch: 2, 3, 4 positions (a slider of the look `DEMO_SWITCH_LOOK`, its value label after the knob).
DEMO_SWITCHES: tuple[DemoSlider, ...] = (
    DemoSlider(caption='2 positions', scale=Scale(values=(ScaleValue(False, 'Off'), ScaleValue(True, 'On')))),
    DemoSlider(caption='3 positions', scale=Scale(values=(ScaleValue('lo', 'Low'), ScaleValue('mid', 'Middle'), ScaleValue('hi', 'High'))), value='mid'),
    DemoSlider(caption='4 positions', scale=Scale(values=tuple(ScaleValue(n, f'Speed {n}') for n in range(4))), value=3),
)


#: The short form of a value in a combo box (a long text, many rows: their start).
SHORT: Repr = Repr()
SHORT.maxstring, SHORT.maxtuple, SHORT.maxlist = 20, 1, 1

#: The properties of every widget (`Widget`), changed live on every page.
COMMON_PROPS: tuple[DemoProp, ...] = (DemoProp('enabled', (True, False)), DemoProp('visible', (True, False)))


@frozen(kw_only=True)
class DemoState:
    """What the demo shows when it opens: the values of the template parameters, the page, the focused button."""

    #: The values of the template parameters.
    values: DemoValues = field(factory=dict)
    #: The name of the shown page ('': the first one).
    page: str = ''
    #: The path of the widget with the focus ('': the list of the pages).
    focus: str = ''


class WidgetDemo(BaseDialog[DemoState]):
    """The widget demo: the result is the state to open it again with (a template parameter changed), None: closed."""

    #: The title of the window.
    TITLE: ClassVar[str] = L(30315, 'Widget demo')

    @classmethod
    def xml_vars(cls, *, pages: Sequence[DemoPage] = (), state: DemoState | None = None, **kwargs: Any) -> dict[str, Any]:
        """
        Return the pages and the values of their template parameters, the colours of the style, the tab shapes (textured), the pages
        of the samples of a stack (and the many ones of a tab bar too long for its side), the widgets anchored to their host
        (`CONTENT_ANCHORED`: their samples on a card), the scales of the sliders and the spin boxes, the switches,
        the texts (the active themes - their names without the prefix of a theme add-on, the tag as wide as its text), the band of a
        caption over a combo box of a value.
        """
        from ..ff.theme import theme_folders
        from .skinfonts import text_metrics
        text_width, line = text_metrics('small')
        themes = L(30340, 'Themes: {themes}', themes=', '.join(folder.name.replace(THEME_PREFIX, '', 1) for folder in theme_folders()))
        return {
            'DEMO_PAGES': tuple(pages),
            'DEMO_COLORS': DEMO_COLORS,
            'DEMO_TAB_SHAPES': tuple(name for name, shape in TAB_SHAPES.items() if shape.joined),
            'DEMO_STACK_PAGES': DEMO_STACK_PAGES,
            'DEMO_MANY_PAGES': DEMO_MANY_PAGES,
            'DEMO_ANCHORED': tuple(sorted(tag.partition('}')[2] for tag in CONTENT_ANCHORED)),
            'DEMO_SCALE': DEMO_SCALE,
            'DEMO_SLIDERS': DEMO_SLIDERS,
            'DEMO_SPIN_BOXES': DEMO_SPIN_BOXES,
            'DEMO_FIELD_SLIDERS': DEMO_FIELD_SLIDERS,
            'DEMO_ROW_SLIDERS': DEMO_ROW_SLIDERS,
            'DEMO_RANGE_SCALE': DEMO_RANGE_SCALE,
            'DEMO_RANGE_BOUNDS': DEMO_RANGE_BOUNDS,
            'DEMO_SETTINGS': DEMO_SETTINGS,
            'DEMO_FILTERS': DEMO_FILTERS,
            'DEMO_SWITCH_LOOK': DEMO_SWITCH_LOOK,
            'DEMO_SWITCHES': DEMO_SWITCHES,
            'DEMO_VALUES': {} if state is None else state.values,
            'DEMO_TITLE': cls.TITLE,
            'DEMO_PARAMS_LABEL': L(30324, 'Template'),
            'DEMO_PROPS_LABEL': L(30325, 'Live'),
            'DEMO_HINT': L(30334, 'A template parameter opens the window again, a live property changes at once.'),
            'DEMO_STYLE': themes,
            'DEMO_STYLE_WIDTH': ceil(text_width(themes)) + 2 * tokens().space.pad.tag + tokens().space.m,  # its text, the padding, a margin
            'DEMO_CAPTION': round(line),
        }

    def __init__(self, *args: Any, pages: Sequence[DemoPage] = (), state: DemoState | None = None, **kwargs: Any) -> None:
        """The pages, the state to show."""
        super().__init__(*args, **kwargs)
        #: The pages of the demo.
        self.pages: tuple[DemoPage, ...] = tuple(pages)
        #: The state the window opened with.
        self.state: DemoState = DemoState() if state is None else state

    def on_init(self) -> None:
        """Fill the list of the pages, prepare the samples and the combo boxes of their values, focus the one of the last change."""
        pages = self.find('list')
        pages.rows = self.pages
        pages.current = next((i for i, page in enumerate(self.pages) if page.name == self.state.page), 0)
        for page in self.pages:
            sample = self.find(f'pages.{page.name}.panel.sample')
            if page.setup is not None:
                page.setup(sample)
            for param in page.params:
                chooser = self.find(f'pages.{page.name}.params.{param.name}')
                index = param.choices.index(page.value(param, self.state.values))
                if param.switch:
                    chooser.checked = param.choices[index]  # type: ignore[attr-defined]
                    chooser.toggled.connect(partial(weak_callback(self.switch_param), page, param))  # type: ignore[attr-defined]
                else:  # its items the values (`DemoParam.texts`, of the template)
                    chooser.current_index = index  # type: ignore[attr-defined]
                    chooser.activated.connect(partial(weak_callback(self.change_param), page, param))  # type: ignore[attr-defined]
            for prop in page.all_props():
                chooser = self.find(f'pages.{page.name}.props.{prop.name}')
                if prop.switch:
                    chooser.checked = prop.values[0]  # type: ignore[attr-defined]
                    chooser.toggled.connect(partial(weak_callback(self.switch_prop), sample, prop))  # type: ignore[attr-defined]
                else:  # its items the values (`DemoProp.texts`, of the template)
                    chooser.current_index = 0  # type: ignore[attr-defined]
                    chooser.activated.connect(partial(weak_callback(self.set_prop), sample, prop))  # type: ignore[attr-defined]
                self.set_prop(sample, prop, 0)
                getattr(sample, f'{prop.name}_changed').connect(partial(weak_callback(self.show_prop), chooser, prop))
        if self.state.focus:  # else the list of the pages (the default control)
            self.setFocusId(self.find(self.state.focus).id)

    def on_focus(self, control_id: int) -> None:
        """The help of the focused control in the hint of the shown page (none, the focus out of the pages: the hint of the demo)."""
        if (widgets := self._widget_tree) is None or not 0 <= (index := self.find('list').current) < len(self.pages):  # type: ignore[attr-defined]
            return
        self.find(f'pages.{self.pages[index].name}.hint').text = widgets.help_of(control_id)  # type: ignore[attr-defined]

    def switch_prop(self, sample: Widget, prop: DemoProp, checked: bool | None) -> None:
        """Set the property of the sample switched (a check box: on / off; of a tristate sample also neither, `DemoPage.tristate()`)."""
        setattr(sample, prop.name, checked)

    def show_prop(self, chooser: Widget, prop: DemoProp, value: Any) -> None:
        """The property of the sample changed (also by the sample itself, e.g. a click on a check box): its chooser shows the value (none of no value)."""
        if prop.switch:
            chooser.checked = value  # type: ignore[attr-defined]
        else:
            chooser.current_index = prop.values.index(value) if value in prop.values else -1  # type: ignore[attr-defined]

    def switch_param(self, page: DemoPage, param: DemoParam, checked: bool) -> None:
        """Take the template parameter switched (a check box: on / off): the window opens again with it."""
        self.change_param(page, param, param.choices.index(checked))

    def set_prop(self, sample: Widget, prop: DemoProp, index: int) -> None:
        """Set the value of the property of the sample (its index in the values; a text of no value: none)."""
        if 0 <= index < len(prop.values):
            setattr(sample, prop.name, prop.values[index])

    def change_param(self, page: DemoPage, param: DemoParam, index: int) -> None:
        """Take the chosen value of the template parameter (its index): close, the caller opens the window again with it."""
        if not 0 <= index < len(param.choices) or param.choices[index] == page.value(param, self.state.values):
            return
        values = {**self.state.values, page.name: {**self.state.values.get(page.name, {}), param.name: param.choices[index]}}
        self.close(evolve(self.state, values=values, page=page.name, focus=f'pages.{page.name}.params.{param.name}'))
