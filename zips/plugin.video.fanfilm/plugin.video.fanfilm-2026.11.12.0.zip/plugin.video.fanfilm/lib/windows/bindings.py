"""
Template bindings: values shown in a window, computed at runtime from the window objects.

A template field `{=expr}` is a binding. The XML generator (xgui) puts a window property reference in its place
(`$INFO[Window.Property(ffb.N)]`, or a condition in `<visible>` etc.) and keeps the binding in the window data
(`CustomXmlData.bindings`, cached with the generated XML). The window computes it (`win.bindings.refresh()`): names are
taken from the template values captured at generation (e.g. a loop variable), then from the window attributes (and
`win`), then the template names (`const`, `L`...) and Python builtins. A binding of a template of a theme is restricted
(`Binding.restricted`: `xgui.theme_code()`, its calls only of the functions a theme may call, e.g. no method of the window).

A Kodi callback of the window (`onInit()`, `onAction()`, `onClick()`, `onFocus()`: the widgets, the slots) runs in
a batch (`win.bindings.batch()`): its refreshes are deferred to one at its end (a slot changes many properties at once).
"""

from __future__ import annotations
from typing import Any, Generator, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal
import ast
import builtins
import re
from contextlib import contextmanager
from threading import get_ident
from types import CodeType
from attrs import frozen, field
from ..ff.format import SafeFormatter, Sections
from ..ff.logs import fflog
if TYPE_CHECKING:
    from .base import AbstractWindow

#: Binding kind: a text (label, color, texture...) or a condition (visible, enable, selected).
BindingKind = Literal['text', 'condition']

#: Binding field mark in a template text: `{=expr}` (not `{{` escape).
RX_BINDING_FIELD = re.compile(r'(?<!\{)\{=')


@frozen(kw_only=True)
class Binding:
    """Single binding of a window (kept in the XML cache, so its values must be picklable)."""

    #: Window property name.
    prop: str
    #: Text to format (`{expr}` fields) for a text binding, Python expression for a condition.
    text: str
    #: Binding kind.
    kind: BindingKind = 'text'
    #: Template text of the binding, shown on the screen when the binding fails.
    source: str = ''
    #: Template values used by the binding, captured at generation (names of the template scope).
    captured: dict[str, Any] = field(factory=dict)
    #: A binding of a list row (a role): a property of every list item (`row` is the row object), not of the window.
    row: bool = False
    #: A binding of a template of a theme: its code restricted (`xgui.theme_code()`, `xgui.theme_template_names()`).
    restricted: bool = False

    def reference(self) -> str:
        """Kodi XML text referencing the binding value."""
        source = 'ListItem' if self.row else 'Window'
        if self.kind == 'condition':
            return f'String.IsEqual({source}.Property({self.prop}),1)'
        return f'$INFO[{source}.Property({self.prop})]'


def free_names(expr: str) -> set[str]:
    """Names an expression reads (not bound in it, e.g. by a comprehension or a lambda)."""
    tree = ast.parse(expr.strip(), mode='eval')
    bound: set[str] = set()
    used: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            (used if isinstance(node.ctx, ast.Load) else bound).add(node.id)
        elif isinstance(node, ast.arg):
            bound.add(node.arg)
    return used - bound


class _BindingNamespace(dict):
    """Names of a binding at runtime (the dict itself keeps `__builtins__` only; of a theme its own names, `xgui.theme_template_names()`)."""

    def __init__(self, window: AbstractWindow, captured: Mapping[str, Any], names: Mapping[str, Any], *, restricted: bool = False) -> None:
        if restricted:
            from .xgui import theme_template_names
            super().__init__(theme_template_names())
        else:
            super().__init__(__builtins__=builtins)
        #: The code of a theme (`Binding.restricted`).
        self.restricted: bool = restricted
        self._window: AbstractWindow = window
        self._captured: Mapping[str, Any] = captured
        self._names: Mapping[str, Any] = names

    def __getitem__(self, key: str) -> Any:
        if dict.__contains__(self, key):
            return dict.__getitem__(self, key)
        if key in self._captured:
            return self._captured[key]
        if key == 'win':
            return self._window
        try:
            return getattr(self._window, key)
        except AttributeError:
            pass
        return self._names[key]  # KeyError: Python takes a builtin or raises NameError

    def code(self, expr: str) -> CodeType:
        """Return the compiled expression (of a theme: restricted, `xgui.theme_code()`)."""
        from .xgui import compile_code, theme_code
        return theme_code(expr.strip()) if self.restricted else compile_code(expr.strip(), 'eval')


class _BindingFormatter(SafeFormatter):
    """
    Format a text binding: fields are Python expressions in the binding namespace.

    The formatter is shared (by windows and threads), so it keeps no state: the namespace comes in `format()` kwargs.
    """

    def __init__(self) -> None:
        super().__init__(evaluate=False, extended=True, sections=Sections.ESCAPED)

    def get_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> tuple[Any, Any]:
        """Evaluate the field expression in the binding namespace (`__ns__` of the kwargs)."""
        namespace = kwargs['__ns__']
        return eval(namespace.code(field_name), namespace), ()


class WindowBindings:
    """Bindings of a window. A short-lived helper (`win.bindings`), it does not keep the window."""

    _formatter: _BindingFormatter | None = None

    def __init__(self, window: AbstractWindow) -> None:
        self._window: AbstractWindow = window

    def refresh(self) -> None:
        """Compute all bindings of the window, set the changed window properties (in a batch of this thread: at its end)."""
        bindings = self._window.custom_xml_data.bindings
        if not bindings:
            return
        if (ident := get_ident()) in (batches := self._window._binding_batches):
            batches[ident] = True  # refreshed at the end of the batch
            return
        from .xgui import template_names
        names = template_names()
        values = self._window._binding_values
        tree = self._window._widget_tree
        for binding in bindings.values():
            if tree is not None and tree.not_built(binding.captured.get('path', '')):
                continue  # a widget of a page not built yet: computed when it is built
            value = self.value(binding, names=names)
            if values.get(binding.prop) != value:
                self._window.setProperty(binding.prop, value)  # type: ignore[reportAttributeAccessIssue]
                values[binding.prop] = value

    @contextmanager
    def batch(self) -> Generator[None, None, None]:
        """
        Defer the refreshes of this thread to one at the end of the batch (none: no refresh); a nested batch is a part
        of the outer one. Another thread (e.g. an update of the window) refreshes at once, as without a batch.
        """
        batches = self._window._binding_batches
        if (ident := get_ident()) in batches:
            yield
            return
        batches[ident] = False
        try:
            yield
        finally:
            if batches.pop(ident):
                self.refresh()

    def value(self, binding: Binding, *, names: Mapping[str, Any] | None = None, row: Any = None) -> str:
        """Compute the binding value (a role: of the `row` object). An error shows the template text (on the screen) and is logged."""
        from .xgui import template_names
        captured = {**binding.captured, 'row': row} if binding.row else binding.captured
        namespace = _BindingNamespace(self._window, captured, template_names() if names is None else names, restricted=binding.restricted)
        try:
            if binding.kind == 'condition':
                return '1' if eval(namespace.code(binding.text), namespace) else ''
            fmt = WindowBindings._formatter
            if fmt is None:
                fmt = WindowBindings._formatter = _BindingFormatter()
            return fmt.format(binding.text, __ns__=namespace)
        except Exception as exc:
            fflog.warning(f'Binding {binding.prop} {binding.source!r} of {type(self._window).__name__} failed: {exc!r}')
            return binding.source
