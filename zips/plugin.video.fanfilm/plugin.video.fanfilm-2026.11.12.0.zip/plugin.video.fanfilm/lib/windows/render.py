"""
The generated windows of FF from the command line (fake Kodi): `render` one window (the output XML, its widgets by their
paths, the problems of its controls), `check` every generated window in all its variants (the same code as the tests; the
warnings of the generation - layout, focus lines, frames - under their window; `--dump` writes each output XML and its data
to a folder: two folders compared by `diff -r`), `catalog` the reference of the widgets and of the style tokens (Markdown,
all of it from their declarations).

    python -m lib.windows.render render AddToDialog [-o /tmp/add_to.xml]
    python -m lib.windows.render check [--theme test/themes/script.fanfilm.theme.navy] [--variant light] [--dump /tmp/windows]
    python -m lib.windows.render catalog [push_button | color.text] [-o /tmp/catalog.md]
"""

from __future__ import annotations
from typing import Any, Collection, Iterable, Iterator, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, get_origin
from collections import Counter
from functools import lru_cache
from inspect import Parameter, getsourcelines, signature
from itertools import product
from importlib import import_module
from pathlib import Path
import logging
from logging.handlers import BufferingHandler
import re
import sys
from xml.etree import ElementTree as ET
from attrs import fields, frozen
from .base import AbstractWindow
from .geometry import overconstrained_controls, overlapping_row_labels
from .gui import (MEDIA_URL, RX_INFO_AFFIXES, RX_NOT_A_FILE, TEXTURE_ATTRS, TEXTURE_TAGS, WIDGETS_FOLDER, CustomXmlRequest, CustomXmlData, affix_folders,
                  render_xml, remote_textures, texture_file, theme_textures)
from ..ff.types import TypeForm, eval_annotations, get_args, remove_optional
if TYPE_CHECKING:
    from typing_extensions import TypeAlias
    from .style import Style
    from .widgets import Widget
    from .xgui import WidgetEntry

#: The add-on folder.
ROOT: Path = Path(__file__).resolve().parents[2]
#: The modules with the generated windows (their classes are found there), all of them (the checks and the tests take every window from
#: here); their order is the order the worker prepares the windows in the background (`base.prepare_windows()`): the most needed first -
#: the sources (opened by every play), the configuration.
WINDOW_MODULES: tuple[str, ...] = (
    'lib.windows.sources', 'lib.windows.config_dialog', 'lib.windows.source_filters_dialog', 'lib.windows.tree', 'lib.windows.ratings', 'lib.windows.new_list',
    'lib.windows.add_to', 'lib.windows.gallery', 'lib.windows.site_auth', 'lib.windows.color_picker', 'lib.windows.dialogs', 'lib.windows.context',
    'lib.windows.backup',
)
#: The navigation tags of a control.
NAV_TAGS: tuple[str, ...] = ('onup', 'ondown', 'onleft', 'onright', 'onback')
#: The containers whose controls are not the controls of the window: the list item layouts (their IDs repeat).
NOT_WINDOW_CONTROLS: tuple[str, ...] = ('itemlayout', 'focusedlayout')
#: The depth of the groups of a row of a list (in its layout) a control with an ID may not lie at: Kodi 21 registers the IDs of the
#: cloned descendants of a row in the lookup of its source and frees them twice when the window closes (SIGSEGV; fixed in Kodi 22).
ROW_ID_DEPTH: int = 2
#: A relative name of an image (`ControlProblems.relative_textures`): a text or an attribute of any tag.
RX_RELATIVE_IMAGE: re.Pattern[str] = re.compile(r'\w[\w.,/-]*\.(?:png|jpg|gif)')

#: The folder of the widget families and of the generated windows.
WIDGETS: Path = ROOT / 'resources' / 'skins' / WIDGETS_FOLDER
#: The style tokens (`lib/windows/style.py`): their declaration, its source.
STYLE_SOURCE: Path = ROOT / 'lib' / 'windows' / 'style.py'
#: A style token in a template: a field `{tokens.color.text}` or a name in an expression (`tokens.space.s * 2`).
RX_TEMPLATE_TOKEN: re.Pattern[str] = re.compile(r'\btokens\.([a-z][a-z.]*[a-z])')
#: A style token in Python: `tokens().color.text`.
RX_PYTHON_TOKEN: re.Pattern[str] = re.compile(r'\btokens\(\)\.([a-z][a-z.]*[a-z])')
#: A token declaration with its comment: `Token('color.text', 'B3FFFFFF'),  # plain text ...`; a long one without it (its comment `#:` over it).
RX_TOKEN_LINE: re.Pattern[str] = re.compile(r"^\s*Token\('([a-z.]+)'(?:.*#\s*(.*)|.*)$")
#: The end of the first part of a widget description (its summary in the table of the widgets): `.`, `:`, `;` or a parenthesis.
RX_SUMMARY_END: re.Pattern[str] = re.compile(r'[.:;]\s|\s\(')
#: The comment at the head of a template file (before its root element).
RX_HEAD_COMMENT: re.Pattern[str] = re.compile(r'\s*(?:<\?xml[^>]*\?>\s*)?<!--(.*?)-->', re.DOTALL)
#: A quoted name (a token name in the code of the style).
RX_QUOTED_NAME: re.Pattern[str] = re.compile(r"'([a-z]+(?:\.[a-z]+)+)'")
#: An attribute of a class body (its `#:` comment above it): `name: type = ...` or `name = ...`.
RX_CLASS_ATTR: re.Pattern[str] = re.compile(r'(\w+)\s*[:=]')

#: A window class.
WindowClass: TypeAlias = 'type[AbstractWindow]'


@frozen(kw_only=True)
class ControlProblems:
    """The problems of the controls of a generated window (each set empty: none)."""

    #: Control IDs used by more controls of the window.
    repeated_ids: frozenset[str]
    #: Navigation targets (control IDs) with no control.
    missing_targets: frozenset[str]
    #: Textures of the add-on with no file.
    missing_textures: frozenset[str]
    #: Images named by a relative name (`gui.window_texture()` not applied): Kodi looks such a name up in the skin first.
    relative_textures: frozenset[str] = frozenset()
    #: Control IDs in a row of a list nested in its groups (`ROW_ID_DEPTH`: Kodi 21 crashes when the window closes).
    nested_row_ids: frozenset[str] = frozenset()
    #: The infos of the states of a check box (`prefix*postfix`) with the files of an active theme and of FF mixed (the ones of FF shown).
    mixed_textures: frozenset[str] = frozenset()
    #: The widgets of the window an active theme replaces with an incompatible one (`xgui.rejected_widgets()`: the ones of FF shown).
    rejected_widgets: frozenset[str] = frozenset()
    #: The textures the widgets of the active themes wrote naming no local file (`gui.remote_textures()`: dropped, `<theme>: <value>`).
    remote_textures: frozenset[str] = frozenset()
    #: The left and the right label of one group of a row of a list overlapping in place (`geometry.overlapping_row_labels()`: Kodi cuts
    #: them), `<left label> | <right label>`.
    overlapping_row_labels: frozenset[str] = frozenset()
    #: The controls with more than two dimensions on an axis (`geometry.overconstrained_controls()`: Kodi drops the others),
    #: `<type> <id or the ID of its nearest ancestor>: <tags>`.
    overconstrained: frozenset[str] = frozenset()

    def __bool__(self) -> bool:
        """Return True if there is a problem."""
        return bool(self.repeated_ids or self.missing_targets or self.missing_textures or self.relative_textures or self.nested_row_ids
                    or self.mixed_textures or self.rejected_widgets or self.remote_textures or self.overlapping_row_labels
                    or self.overconstrained)


@frozen(kw_only=True)
class ParamInfo:
    """A parameter of a widget (`<ff:param>`) in the catalog."""

    #: The name.
    name: str
    #: The type ('' any: a text or the value of an expression).
    type: str
    #: The default as written ('' none).
    default: str
    #: The use must give it (no default).
    required: bool
    #: The widget declaring it (the widget itself or a base).
    widget: str
    #: The comment on its line.
    doc: str


@frozen(kw_only=True)
class MemberInfo:
    """A property (`Property`) or a signal (`ClassSignal`) of a widget class in the catalog."""

    #: The name.
    name: str
    #: The type of the value of a property ('' a signal).
    type: str
    #: The default value of a property (repr; '' a signal).
    default: str
    #: The class declaring it.
    owner: str
    #: Its `#:` comment.
    doc: str


@frozen(kw_only=True)
class UseInfo:
    """A use of a widget in a generated window."""

    #: The window class.
    window: str
    #: The path of the widget in the window.
    path: str
    #: The position of the use in the source (`path:line`).
    src: str


@frozen(kw_only=True)
class WidgetInfo:
    """A widget in the catalog: its declaration, its Python class, its uses."""

    #: The name (`<gui:name>`).
    name: str
    #: The family (`resources/skins/widgets/<family>.xml`, `lib/windows/widgets/<family>.py`).
    family: str
    #: The position of the declaration (`path:line`).
    src: str
    #: The comment above the declaration (none: the one of its family if it is the only widget there).
    doc: str
    #: The comment above `<ff:widgets>` of its family.
    family_doc: str
    #: The bases, the nearest first.
    bases: tuple[str, ...]
    #: The widgets based on this one (its other forms).
    forms: tuple[str, ...]
    #: The parameters (with the ones of the bases).
    params: tuple[ParamInfo, ...]
    #: The places of the content of a use (`<ff:content>`): '' the default one, else its name; with its tag filter.
    contents: tuple[str, ...]
    #: The names of the controls of the widget and its bases besides the widget control (`id_of(name)`; the Python class finds them by these).
    controls: tuple[str, ...]
    #: The style tokens of its template and of the templates of its bases.
    tokens: tuple[str, ...]
    #: The Python class (`module.Class`).
    cls: str
    #: The Python class and its bases down to `Widget`.
    cls_chain: tuple[str, ...]
    #: The docstring of the Python class (its own one, '' none).
    cls_doc: str
    #: The property of the value of the widget (`Widget.VALUE`, '' none).
    value: str
    #: The positions of its list the widget keeps (`Widget.FOCUS_POSITIONS`).
    focus_positions: tuple[str, ...]
    #: The properties.
    properties: tuple[MemberInfo, ...]
    #: The signals.
    signals: tuple[MemberInfo, ...]
    #: The uses in the generated windows.
    uses: tuple[UseInfo, ...]


@frozen(kw_only=True)
class TokenInfo:
    """A style token in the catalog."""

    #: The name (`color.text.focused`).
    name: str
    #: The kind (`Token.kind`).
    kind: str
    #: The default as declared (a literal or a reference).
    default: str
    #: The default of the light variant as declared (`Token.light`), '' the same as `default`.
    light: str
    #: The value of the resolved style.
    value: str
    #: The user may change it.
    adjustable: bool
    #: The comment of its declaration.
    doc: str
    #: The values of a named choice (`Token.choices`), () another kind.
    choices: tuple[str, ...] = ()
    #: The widgets and the windows (their sources) of the templates using it.
    templates: tuple[str, ...]
    #: The Python modules using it.
    modules: tuple[str, ...]


@frozen(kw_only=True)
class Catalog:
    """The catalog of the widgets and the style tokens."""

    #: The widgets by their names.
    widgets: dict[str, WidgetInfo]
    #: The tokens by their names.
    tokens: dict[str, TokenInfo]


def window_classes() -> list[WindowClass]:
    """Return the classes of the generated windows (a source in the widgets folder)."""
    found: dict[str, WindowClass] = {}
    for name in WINDOW_MODULES:
        for value in vars(import_module(name)).values():
            if (isinstance(value, type) and issubclass(value, AbstractWindow) and value.__module__ == name
                    and value.widget_source(str(ROOT)).exists()):
                found[value.__qualname__] = value
    return list(found.values())


def window_sources(cls: WindowClass) -> list[Path]:
    """Return the sources of the window."""
    return [cls.widget_source(str(ROOT))]


def variant_values(ann: TypeForm) -> tuple[Any, ...]:
    """Return the values of a template variant parameter of the annotation: `bool`: False, True; a `Literal` (also optional): its values; else none."""
    ann = remove_optional(ann)
    if ann is bool:
        return (False, True)
    if get_origin(ann) is Literal:
        return get_args(ann)
    return ()


def window_requests(cls: WindowClass) -> Iterator[CustomXmlRequest | None]:
    """
    Yield the template requests of the window variants: the product of the values of the keyword parameters of
    `xml_vars()` of the window (`variant_values()` of their annotations: the arguments its template depends on).
    Only these annotations are evaluated (the other ones may name types of `TYPE_CHECKING` only).
    """
    module = sys.modules[cls.xml_vars.__module__].__dict__
    axes: dict[str, tuple[Any, ...]] = {}
    for name, param in signature(cls.xml_vars).parameters.items():
        if param.kind in (Parameter.POSITIONAL_OR_KEYWORD, Parameter.KEYWORD_ONLY) and param.annotation is not Parameter.empty:
            if values := variant_values(eval_annotations(param.annotation, globalns=module)):
                axes[name] = values
    for values in product(*axes.values()):
        yield cls.xml_request(**dict(zip(axes, values)))


def window_controls(root: ET.Element) -> Iterator[ET.Element]:
    """Yield the controls of the window (not the ones of `NOT_WINDOW_CONTROLS`)."""
    for child in root:
        if child.tag in NOT_WINDOW_CONTROLS:
            continue
        if child.tag == 'control':
            yield child
        yield from window_controls(child)


def row_controls(elem: ET.Element, depth: int = 0) -> Iterator[tuple[ET.Element, int]]:
    """Yield the controls of a row of a list (`elem`: its layout) with their depths: the number of the groups around them in the row."""
    for child in elem:
        if child.tag == 'control':
            yield child, depth
            yield from row_controls(child, depth + 1)


#: The least contrast of a text (WCAG 1.4.3, AA).
TEXT_CONTRAST: float = 4.5
#: The least contrast of a mark (a non-text element: WCAG 1.4.11): the focus ring, the accent, the mark "modified", the boundary of a control.
MARK_CONTRAST: float = 3.0
#: The backdrop of the FF windows by the variant of the themes (the usual background of a skin of it: a dark one, AZ2 Light), else dark.
CONTRAST_BACKDROPS: dict[str, str] = {'dark': 'FF202020', 'light': 'FFEDEDED'}


@frozen
class ContrastPair:
    """
    A colour token of a text or a mark on a surface of the windows (`contrast_surfaces()`), its least contrast; the boundary of a control
    (`fill`, WCAG 1.4.11): its fill or its edge (the token) on the surface under it.
    """

    #: The colour token.
    token: str
    #: The surface (a key of `contrast_surfaces()`).
    surface: str
    #: The least contrast (`TEXT_CONTRAST`, `MARK_CONTRAST`).
    least: float = TEXT_CONTRAST
    #: A control on the surface (a key of `contrast_surfaces()`, '' none): its fill or its edge (the token) enough.
    fill: str = ''


#: The texts and the marks of the windows on their surfaces (the contrast check of a style: `contrast_problems()`).
CONTRAST_PAIRS: tuple[ContrastPair, ...] = (
    ContrastPair('color.text', 'dialog'), ContrastPair('color.text.title', 'dialog'), ContrastPair('color.link', 'dialog'),
    ContrastPair('color.code', 'dialog'), ContrastPair('color.text', 'panel'), ContrastPair('color.text.strong', 'panel'),
    ContrastPair('color.text.dim', 'panel'), ContrastPair('color.warning', 'panel'), ContrastPair('color.error', 'panel'),
    ContrastPair('color.text', 'field'), ContrastPair('color.text.hint', 'field'), ContrastPair('color.text.focused', 'field.focused'),
    ContrastPair('color.text', 'button'), ContrastPair('color.text.focused', 'button.focused'), ContrastPair('color.text', 'card'),
    ContrastPair('color.text.strong', 'card'), ContrastPair('color.text.match', 'card'), ContrastPair('color.text.row.focused', 'card.focused'),
    ContrastPair('color.text.strong.focused', 'card.focused'), ContrastPair('color.text.dim.focused', 'card.focused'),
    ContrastPair('color.text.row.focused', 'card.selected'), ContrastPair('color.text', 'tag'), ContrastPair('color.text.row.focused', 'tag.focused'),
    ContrastPair('color.accent', 'panel', MARK_CONTRAST),
    ContrastPair('color.focus', 'panel', MARK_CONTRAST), ContrastPair('color.modified', 'field', MARK_CONTRAST),
    ContrastPair('color.modified.focused', 'field.focused', MARK_CONTRAST),
    ContrastPair('color.separator.row', 'card', MARK_CONTRAST),
    # the boundaries of the controls (the edge of a focused one: its focus ring); a row (a card) without the focus none - its text tells it
    ContrastPair('color.frame.button', 'dialog', MARK_CONTRAST, fill='button'), ContrastPair('color.frame.button', 'panel', MARK_CONTRAST, fill='button'),
    ContrastPair('color.focus', 'panel', MARK_CONTRAST, fill='button.focused'), ContrastPair('color.frame.field', 'panel', MARK_CONTRAST, fill='field'),
    ContrastPair('color.focus', 'panel', MARK_CONTRAST, fill='field.focused'), ContrastPair('color.focus', 'panel', MARK_CONTRAST, fill='card.focused'),
)


def contrast_surfaces(style: Style) -> dict[str, str]:
    """
    Return the colours of the surfaces of the windows of the style (opaque `AARRGGBB`, `gui.tinted_surface()`; a texture of an unknown
    colour: '') - the backdrop of its variant (`CONTRAST_BACKDROPS`) dimmed, a dialog on it, a panel in it, the fields, the buttons and
    the cards (rows) in their states on the panel, the tags on the cards (a card of an unknown colour: on the panel).
    """
    from .gui import tinted_surface
    values = {name: str(value) for name, value in style.values.items()}
    dim = tinted_surface(values['color.bg.overlay'], under=CONTRAST_BACKDROPS.get(style.variant, CONTRAST_BACKDROPS['dark']))
    dialog = tinted_surface(values['color.bg.under'], under=dim)
    panel = tinted_surface(values['color.bg.panel'], under=dialog)
    surfaces = {'dialog': dialog, 'panel': panel}
    for name, tint, texture in (('field', 'color.bg.field', ''), ('field.focused', 'color.bg.field.focused', ''),
                                ('button', 'color.bg.button', 'texture.button'), ('button.focused', 'color.bg.button.focused', 'texture.button.focused'),
                                ('card', 'color.bg.card', 'texture.card'), ('card.focused', 'color.bg.card.focused', 'texture.card.focused'),
                                ('card.selected', 'color.bg.card.selected', 'texture.card.selected')):
        surfaces[name] = tinted_surface(values[tint], values[texture] if texture else '', under=panel)
    for name, tint, host in (('tag', 'color.bg.tag', 'card'), ('tag.focused', 'color.bg.tag.focused', 'card.focused')):  # a tag on a card
        surfaces[name] = tinted_surface(values[tint], values['texture.tag'], under=surfaces[host] or panel)
    return surfaces


def contrast_problems(style: Style) -> list[str]:
    """
    Return the texts, the marks and the controls of the style with too little contrast on their surfaces (`CONTRAST_PAIRS`; a surface of
    an unknown colour skipped): `<token> on <surface>: <ratio> < <least>`, a control `<fill> on <surface>` (the better of its fill and
    its edge).
    """
    from .gui import contrast_ratio
    surfaces = contrast_surfaces(style)

    def ratio(pair: ContrastPair, surface: str) -> float | None:
        """Return the contrast of the pair on the colour of its surface (a control: the better of its fill and its edge), None unknown."""
        ratios = [contrast_ratio(str(style.values[pair.token]), surface)]
        if pair.fill and (fill := surfaces[pair.fill]):
            ratios.append(contrast_ratio(fill, surface))
        elif pair.fill and not any(value >= pair.least for value in ratios):
            return None  # a fill of an unknown colour (a picture) may be enough
        return max(ratios)

    return [f'{pair.fill or pair.token} on {pair.surface}: {value:.2f} < {pair.least}' for pair in CONTRAST_PAIRS
            if (surface := surfaces[pair.surface]) and (value := ratio(pair, surface)) is not None and value < pair.least]


def control_name(ctl: ET.Element, parents: Mapping[ET.Element, ET.Element]) -> str:
    """Return the name of a control in a problem: its type and ID, else the ID of its nearest ancestor with one (`in <id>`)."""
    if cid := ctl.get('id'):
        return f'{ctl.get("type")} {cid}'
    elem = ctl
    while (elem := parents.get(elem)) is not None and not elem.get('id'):
        pass
    return f'{ctl.get("type")} in {elem.get("id") if elem is not None else "the window"}'


def control_problems(root: ET.Element, widgets: Iterable[WidgetEntry] = ()) -> ControlProblems:
    """
    Return the problems of the controls of a generated window: repeated IDs, navigation to nowhere, missing textures (`gui.texture_file()`),
    images named by a relative name (`gui.window_texture()` not applied), IDs nested in the groups of a row of a list, the states of a
    check box of the active themes and of FF mixed (`gui.affix_folders()`), its widgets (`widgets`: its manifest) a theme replaces with an
    incompatible one or one failing in it (`xgui.rejected_widgets()`), the textures of the widgets of the themes naming no local file
    (`gui.remote_textures()` of the last generated window: dropped), the left and the right label of one group of a row of a list
    overlapping in place (`geometry.overlapping_row_labels()`), the controls with more than two dimensions on an axis
    (`geometry.overconstrained_controls()`).
    """
    from .xgui import rejected_widgets
    counts = Counter(ctl.get('id') for ctl in window_controls(root) if ctl.get('id'))
    ids = {elem.get('id') for elem in root.iter() if elem.get('id')}
    targets = {text for tag in NAV_TAGS for elem in root.iter(tag) if (text := (elem.text or '').strip()).isdecimal()}
    texts = {text.strip() for tag in TEXTURE_TAGS for elem in root.iter(tag) for text in (elem.text or '', *(elem.get(name, '') for name in TEXTURE_ATTRS))}
    files = {text: path for text in texts if text and (path := texture_file(text)) is not None}
    # the prefixes and postfixes of the infos (`RX_INFO_AFFIXES`), a prefix of FF relative again (`affix_folders()`)
    infos = {(mch[2][len(MEDIA_URL) + 1:] if mch[2].startswith(f'{MEDIA_URL}/') else mch[2], mch[3])
             for text in texts for mch in RX_INFO_AFFIXES.finditer(text)}
    relative = {value.strip() for elem in root.iter() for value in (elem.text, *elem.attrib.values()) if value and RX_RELATIVE_IMAGE.fullmatch(value.strip())}
    relative.update(f'{mch[2]}*{mch[3]}' for text in texts for mch in RX_INFO_AFFIXES.finditer(text) if not RX_NOT_A_FILE.search(mch[2]))
    themed = theme_textures()
    mixed = {f'{prefix}*{postfix}' for prefix, postfix in infos if len(affix_folders(prefix, postfix, themed)) > 1}
    parents = {child: parent for parent in root.iter() for child in parent}
    nested = {ctl.get('id', '') for tag in NOT_WINDOW_CONTROLS for layout in root.iter(tag) for ctl, depth in row_controls(layout)
              if depth >= ROW_ID_DEPTH and ctl.get('id')}
    return ControlProblems(repeated_ids=frozenset(cid for cid, count in counts.items() if count > 1 and cid),
                           missing_targets=frozenset(targets - ids),  # type: ignore[operator]
                           missing_textures=frozenset(text for text, path in files.items() if not path.exists()),
                           relative_textures=frozenset(relative),
                           nested_row_ids=frozenset(nested), mixed_textures=frozenset(mixed),
                           rejected_widgets=frozenset(f'{name} ({why})' for name, why in rejected_widgets().items()
                                                      if any(name in entry.types for entry in widgets)),
                           remote_textures=frozenset(remote_textures()),
                           overlapping_row_labels=frozenset(f'{left.findtext("label")} | {right.findtext("label")}'
                                                            for left, right in overlapping_row_labels(root)),
                           overconstrained=frozenset(f'{control_name(ctl, parents)}: {"+".join(tags)}' for ctl, tags in overconstrained_controls(root)))


def render_window(cls: WindowClass, source: Path | None = None, request: CustomXmlRequest | None = None) -> tuple[bytes, CustomXmlData]:
    """Generate the window (its first source, the default request), return the output XML and its data."""
    return render_xml(source or window_sources(cls)[0], cls.xml_request() if request is None else request)


def data_lines(data: CustomXmlData) -> Iterator[str]:
    """Yield the data of a generated window as text lines: its fields, an item of a dict or of a tuple on a line of its own."""
    for attr in fields(CustomXmlData):
        value = getattr(data, attr.name)
        if isinstance(value, (dict, tuple)):
            yield f'{attr.name}:'
            yield from (f'    {key!r}: {item!r}' for key, item in (value.items() if isinstance(value, dict) else enumerate(value)))
        else:
            yield f'{attr.name}: {value!r}'


def comment_text(elem: ET.Element) -> str:
    """Return the text of a comment of a source as one paragraph (its lines joined)."""
    return ' '.join((elem.text or '').split())


def template_texts(elem: ET.Element) -> Iterator[str]:
    """Yield the texts and the attribute values of the elements of a template (not of its comments)."""
    if elem.tag is not ET.Comment:
        yield from elem.attrib.values()
        yield elem.text or ''
        for child in elem:
            yield from template_texts(child)
    yield elem.tail or ''


def declared_token(name: str, names: Collection[str]) -> str:
    """Return the token of a name read in a template or in Python: the longest declared prefix ('' none, e.g. `tokens().values`)."""
    while name and name not in names:
        name = name.rpartition('.')[0]
    return name


@lru_cache(maxsize=None)
def attribute_docs(cls: type) -> dict[str, str]:
    """Return the `#:` comments of the attributes of the class body (its own source) by the attribute names."""
    try:
        lines, _ = getsourcelines(cls)
    except (OSError, TypeError):
        return {}
    docs: dict[str, str] = {}
    comment: list[str] = []
    indent = None
    for line in lines[1:]:
        text = line.strip()
        if not text:
            continue
        if indent is None:
            indent = len(line) - len(line.lstrip())
        if len(line) - len(line.lstrip()) != indent:  # a method body, a nested class
            comment = []
            continue
        if text.startswith('#:'):
            comment.append(text[2:].strip())
            continue
        if comment and (mch := RX_CLASS_ATTR.match(text)):
            docs[mch[1]] = ' '.join(comment)
        comment = []
    return docs


def class_members(cls: type[Widget]) -> tuple[tuple[MemberInfo, ...], tuple[MemberInfo, ...]]:
    """Return the properties and the signals of the widget class, the ones of `Widget` first."""
    from .widgets import Property, signal_names
    chain = [klass for klass in reversed(cls.__mro__) if klass is not object]
    props: dict[str, MemberInfo] = {}
    for klass in chain:
        for name, value in vars(klass).items():
            if isinstance(value, Property):
                ann = str(vars(klass).get('__annotations__', {}).get(name, ''))
                props[name] = MemberInfo(name=name, type=ann.partition('[')[2].rpartition(']')[0], default=repr(value.default),
                                         owner=klass.__name__, doc=attribute_docs(klass).get(name, ''))
    signals: list[MemberInfo] = []
    for name in signal_names(cls):
        owner = next(klass for klass in chain if name in vars(klass))
        if (prop := name[:-len('_changed')]) in props and name.endswith('_changed'):
            doc = f'The property `{prop}` changed: its value.'
        else:
            doc = attribute_docs(owner).get(name, '')
        signals.append(MemberInfo(name=name, type='', default='', owner=owner.__name__, doc=doc))
    order = {klass.__name__: i for i, klass in enumerate(chain)}
    signals.sort(key=lambda sig: order[sig.owner])
    return tuple(props.values()), tuple(signals)


def widget_uses() -> dict[str, set[UseInfo]]:
    """Return the uses of the widgets in the generated windows (all their variants) by the widget names."""
    uses: dict[str, set[UseInfo]] = {}
    for cls in window_classes():
        for source in window_sources(cls):
            for request in window_requests(cls):
                _xml, data = render_xml(source, request)
                for entry in data.widgets:
                    uses.setdefault(entry.types[0], set()).add(UseInfo(window=cls.__name__, path=entry.path, src=entry.src))
    return uses


def build_catalog() -> Catalog:
    """Return the catalog of the widgets (the index of the generator, the sources as written, the Python classes, the uses) and the tokens."""
    from .xgui import DELEGATE_CONTENT, RX_ID_OF, SRC_ATTR, WidgetEntry, XmlManager, parse_template
    from .widgets import Widget, widget_class
    from .style import TOKENS, tokens
    index = XmlManager(folder=WIDGETS).widget_index()
    token_names = {token.name: token for token in TOKENS}
    templates: dict[str, set[str]] = {}

    def template_tokens(elem: ET.Element, user: str) -> tuple[str, ...]:
        """Return the tokens of the template element (and remember its user)."""
        found = {name for text in template_texts(elem) for mch in RX_TEMPLATE_TOKEN.finditer(text)
                 if (name := declared_token(mch[1], token_names))}
        for name in found:
            templates.setdefault(name, set()).add(user)
        return tuple(sorted(found))

    written: dict[str, ET.Element] = {}
    docs: dict[str, str] = {}
    family_docs: dict[str, str] = {}
    widget_tokens: dict[str, tuple[str, ...]] = {}
    for path in sorted(WIDGETS.glob('*.xml')):
        root = parse_template(path, root=WIDGETS.parent, as_written=True)
        if root.tag != '{ff}widgets':
            template_tokens(root, path.name)  # a window, a module of definitions
            continue
        mch = RX_HEAD_COMMENT.match(path.read_text(encoding='utf-8'))  # the comments out of the root element are not parsed
        family_docs[path.stem] = ' '.join(mch[1].split()) if mch else ''
        doc = ''
        for elem in root:
            if elem.tag is ET.Comment:
                doc = comment_text(elem)
                continue
            if elem.tag == '{ff}widget':
                name = elem.get('name', '')
                written[name], docs[name] = elem, doc
                widget_tokens[name] = template_tokens(elem, name)
            doc = ''
        if len(names := [elem.get('name', '') for elem in root if elem.tag == '{ff}widget']) == 1 and not docs[names[0]]:
            docs[names[0]] = family_docs[path.stem]  # the family of one widget: its description is the one of the widget
    uses = widget_uses()
    widgets: dict[str, WidgetInfo] = {}
    manager = XmlManager(folder=WIDGETS)
    for name, xdef in index.items():
        chain = manager.widget_chain(xdef)
        elem = written[name]
        params: dict[str, ParamInfo] = {}
        for item in reversed(chain):
            children = list(written[item.name])
            for i, child in enumerate(children):
                if child.tag == '{ff}param':
                    after = children[i + 1] if i + 1 < len(children) else None
                    same_line = after is not None and after.tag is ET.Comment and after.get(SRC_ATTR) == child.get(SRC_ATTR)
                    params[child.get('name', '')] = ParamInfo(
                        name=child.get('name', ''), type=child.get('type', ''), default=child.get('value', ''),
                        required=child.get('value') is None, widget=item.name, doc=comment_text(after) if same_line and after is not None else '')
        contents = []
        for parent in elem.iter():
            for child in parent:
                if child.tag == '{ff}content' and not str(parent.tag).startswith('{gui}'):  # a filler of a use is a child of the use
                    flt = ''.join(f' {attr}={child.get(attr)}' for attr in ('tags', 'exclude') if child.get(attr))
                    contents.append(f'{child.get("name", "") or "(default)"}{flt}')
                elif child.tag == '{ff}delegate':
                    contents.append(f'{DELEGATE_CONTENT} (a row of the list, drawn twice: focused and not)')
        cls = widget_class(WidgetEntry(path=name, types=tuple(item.name for item in chain), families=tuple(item.module.name for item in chain), ids={}))
        props, signals = class_members(cls)
        widgets[name] = WidgetInfo(
            name=name, family=xdef.module.name, src=elem.get(SRC_ATTR, ''), doc=docs[name], family_doc=family_docs[xdef.module.name],
            bases=tuple(item.name for item in chain[1:]), forms=tuple(other.name for other in index.values() if other.base == name),
            params=tuple(params.values()), contents=tuple(dict.fromkeys(contents)),
            controls=tuple(dict.fromkeys(mch[1] for item in reversed(chain) for text in template_texts(written[item.name]) for mch in RX_ID_OF.finditer(text))),
            tokens=tuple(sorted({token for item in chain for token in widget_tokens[item.name]})), cls=f'{cls.__module__}.{cls.__qualname__}',
            cls_chain=tuple(klass.__name__ for klass in cls.__mro__ if issubclass(klass, Widget)), cls_doc=cls.__dict__.get('__doc__') or '',
            value=cls.VALUE, focus_positions=tuple(sorted(cls.FOCUS_POSITIONS)), properties=props, signals=signals,
            uses=tuple(sorted(uses.get(name, ()), key=lambda use: (use.window, use.src, use.path))))
    modules: dict[str, set[str]] = {}
    for path in sorted((ROOT / 'lib').rglob('*.py')):
        if '3rd' in path.parts or path in (STYLE_SOURCE, Path(__file__).resolve()):  # this module names tokens in its texts
            continue
        module = '.'.join(path.relative_to(ROOT).with_suffix('').parts)
        for mch in RX_PYTHON_TOKEN.finditer(path.read_text(encoding='utf-8')):
            if name := declared_token(mch[1], token_names):
                modules.setdefault(name, set()).add(module)
    token_docs: dict[str, str] = {}
    over: list[str] = []  # the comment `#:` over the next line
    for line in STYLE_SOURCE.read_text(encoding='utf-8').splitlines():
        if line.lstrip().startswith('#:'):
            over.append(line.lstrip()[2:].strip())
            continue
        doc, over = ' '.join(over), []
        if mch := RX_TOKEN_LINE.match(line):
            token_docs[mch[1]] = mch[2] if mch[2] is not None else doc
        elif not line.lstrip().startswith(('Token(', '#')):  # the code of the style: e.g. the resolver reads `space.density`
            for mch in RX_QUOTED_NAME.finditer(line):
                if mch[1] in token_names:
                    modules.setdefault(mch[1], set()).add('lib.windows.style')
    values = tokens().values
    return Catalog(widgets=widgets, tokens={
        token.name: TokenInfo(name=token.name, kind=token.kind, default=str(token.default), light='' if token.light is None else str(token.light),
                              value=str(values[token.name]),
                              adjustable=token.adjustable, doc=token_docs.get(token.name, ''), choices=token.choices,
                              templates=tuple(sorted(templates.get(token.name, ()))), modules=tuple(sorted(modules.get(token.name, ()))))
        for token in TOKENS})


def md_table(head: Sequence[str], rows: Iterable[Sequence[str]]) -> list[str]:
    """Return the lines of a Markdown table, its columns aligned (`|` in a cell escaped)."""
    cells = [list(head), *([str(cell).replace('|', '\\|') for cell in row] for row in rows)]
    widths = [max(len(row[col]) for row in cells) for col in range(len(head))]
    lines = [f'| {" | ".join(cell.ljust(width) for cell, width in zip(row, widths))} |' for row in cells]
    lines.insert(1, f'|{"|".join("-" * (width + 2) for width in widths)}|')
    return lines


def code(text: str) -> str:
    """Return the text as Markdown code ('' stays empty)."""
    return f'`{text}`' if text else ''


def widget_lines(info: WidgetInfo) -> list[str]:
    """Return the Markdown section of a widget."""
    lines = [f'## {info.name}', '']
    if info.doc:
        lines += [info.doc, '']
    lines.append(f'- Source: `{info.src}`')
    if info.family_doc and info.family_doc != info.doc:
        lines.append(f'- Family `{info.family}`: {info.family_doc}')
    if info.bases:
        lines.append(f'- Bases: {" → ".join(code(base) for base in info.bases)}')
    if info.forms:
        lines.append(f'- Forms (widgets based on it): {", ".join(code(form) for form in info.forms)}')
    lines.append(f'- Class: `{info.cls}` ({" → ".join(info.cls_chain)})')
    if info.cls_doc:
        lines.append(f'- Class doc: {" ".join(info.cls_doc.split())}')
    if info.value:
        lines.append(f'- Value property: `{info.value}`')
    if info.focus_positions:
        lines.append(f'- Focus positions: {", ".join(code(pos) for pos in info.focus_positions)}')
    lines.append(f'- Content places: {", ".join(code(content) for content in info.contents) or "none"}')
    lines.append(f'- Controls: the widget control `{{id}}`{"".join(f", {code(name)}" for name in info.controls)}')
    if info.tokens:
        lines.append(f'- Style tokens: {", ".join(code(token) for token in info.tokens)}')
    if info.params:
        lines += ['', '### Parameters', '']
        lines += md_table(('Name', 'Type', 'Default', 'From', 'Description'),
                          ((code(p.name), p.type, 'required' if p.required else code(p.default), '' if p.widget == info.name else code(p.widget), p.doc)
                           for p in info.params))
    lines += ['', '### Properties', '']
    lines += md_table(('Name', 'Type', 'Default', 'From', 'Description'),
                      ((code(m.name), code(m.type), code(m.default), m.owner, m.doc) for m in info.properties))
    lines += ['', '### Signals', '']
    lines += md_table(('Name', 'Slot', 'From', 'Description'),
                      ((code(m.name), code(f'on_<path>_{m.name}'), m.owner, m.doc) for m in info.signals))
    lines += ['', '### Uses', '']
    places: dict[tuple[str, str], list[str]] = {}  # a use in a loop: one place of more paths
    for use in info.uses:
        places.setdefault((use.window, use.src), []).append(use.path)
    lines += [f'- {window} `{paths[0]}`{f" and {len(paths) - 1} more" if len(paths) > 1 else ""} — `{src}`'
              for (window, src), paths in places.items()] or ['- none (a base of other widgets only)' if info.forms else '- none']
    return [*lines, '']


def token_lines(infos: Iterable[TokenInfo]) -> list[str]:
    """Return the Markdown tables of the tokens, one per kind."""
    lines: list[str] = []
    by_kind: dict[str, list[TokenInfo]] = {}
    for info in infos:
        by_kind.setdefault(info.kind, []).append(info)
    for kind, group in by_kind.items():
        lines += [f'## {kind}', '']
        lines += md_table(('Token', 'Default', 'Light', 'Value', 'Adjustable', 'Description', 'Templates', 'Python'),
                          ((code(t.name), code(t.default), code(t.light) if t.light else '', code(t.value) if t.value != t.default else '',
                            'yes' if t.adjustable else '',
                            f'{t.doc} (one of: {", ".join(t.choices)})' if t.choices else t.doc,
                            ', '.join(t.templates) or ('**unused**' if not t.modules else ''), ', '.join(t.modules)) for t in group))
        lines.append('')
    return lines


#: The head of the catalog.
CATALOG_HEAD: str = """\
# FF widgets and style tokens

The reference of the widgets of the FF windows and of the tokens of their style, generated from their declarations:
the widget families `resources/skins/widgets/<family>.xml` (`<ff:widget>`, the comments above the widgets and on the
lines of the parameters), their Python classes `lib/windows/widgets/<family>.py` (`Property`, `ClassSignal`, the `#:`
comments), the tokens `lib/windows/style.py` and the uses in the generated windows. How to write a window: `docs/gui/windows.md`.

    python -m lib.windows.render catalog [widget | token] [-o file.md]
"""


def catalog_lines(catalog: Catalog, name: str = '') -> list[str]:
    """Return the Markdown of the catalog: all of it, or one widget / one token."""
    if name in catalog.widgets:
        return widget_lines(catalog.widgets[name])
    if name in catalog.tokens:
        return token_lines([catalog.tokens[name]])
    lines = [CATALOG_HEAD, '# Widgets', '']
    lines += md_table(('Widget', 'Family', 'Description'),
                      ((code(w.name), w.family, RX_SUMMARY_END.split(w.doc, 1)[0]) for w in catalog.widgets.values()))
    lines.append('')
    for info in catalog.widgets.values():
        lines += widget_lines(info)
    lines += ['# Style tokens', '',
              'A template reads a token as `{tokens.color.text}`, Python as `tokens().color.text`. A default may be an expression: a reference',
              '(`{color.text}`, any number of levels) or a colour function (`alpha({color.accent}, 99)`, `lighter({c}, N)`, `darker({c}, N%)`,',
              '`mix({a}, {b}, N%)`; the column Value: its result); the spacing steps (`space.*`) are multiplied by `space.density`. The column',
              'Light: the default of the light variant of the themes (empty: the same default).', '']
    lines += token_lines(catalog.tokens.values())
    return lines


def _main() -> None:
    """Run the command line."""
    from argparse import ArgumentParser
    parser = ArgumentParser(prog='python -m lib.windows.render', description='The generated windows of FF.')
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('render', help='generate one window')
    p.add_argument('window', help='the window class name (e.g. AddToDialog)')
    p.add_argument('-o', '--output', type=Path, help='the output XML file')
    p = commands.add_parser('check', help='generate every window in all its variants, show the problems of the controls')
    p.add_argument('--theme', type=Path, action='append', metavar='FOLDER',
                   help='the folder of an active theme of this run, the most important first (default: the configuration)')
    p.add_argument('--dump', type=Path, metavar='FOLDER', help='write the output XML and the data of every window variant there')
    p.add_argument('--variant', metavar='NAME', help='the chosen variant of the themes of this run, e.g. light (default: the configuration)')
    p.add_argument('--skin', type=Path, metavar='FOLDER', help='the skin of this run, its colours chosen (its text: the variant auto; its accent)')
    p.add_argument('--colour-theme', default='SKINDEFAULT', metavar='NAME', help='the colour theme of the skin of this run, e.g. midnight')
    p.add_argument('--skin-label', action='append', default=[], metavar='EXPRESSION=VALUE',
                   help='the value of an expression of the skin of this run (Kodi getInfoLabel), e.g. $VAR[ColorHighlight]=ff283ba8')
    p = commands.add_parser('catalog', help='the reference of the widgets and the style tokens (Markdown)')
    p.add_argument('name', nargs='?', default='', help='one widget or one token (e.g. push_button, color.text)')
    p.add_argument('-o', '--output', type=Path, help='the output Markdown file')
    from .. import cmdline_argv  # the arguments of the command line (`sys.argv` is the one of the fake plugin call)
    args = parser.parse_args(cmdline_argv[1:])
    if args.command == 'catalog':
        catalog = build_catalog()
        if args.name and args.name not in catalog.widgets and args.name not in catalog.tokens:
            parser.error(f'unknown widget or token {args.name!r}, the widgets: {", ".join(catalog.widgets)}')
        text = '\n'.join(catalog_lines(catalog, args.name))
        if args.output:
            args.output.write_text(text, encoding='utf-8')
            print(f'{args.output}: {len(text.splitlines())} lines')
        else:
            print(text)
        return
    if getattr(args, 'theme', None):
        from ..ff import theme
        folders = (*(folder.resolve() for folder in args.theme), theme.base_path())
        theme.theme_folders = lambda: folders  # the themes of this run (as the tests switch them)
    if (variant := getattr(args, 'variant', None)) is not None:
        from ..ff import theme
        theme.chosen_variant = lambda: variant  # the variant of this run
    if skin := getattr(args, 'skin', None):  # the colours of the skin of this run (as Kodi gives them)
        from xbmcvfs import translatePath
        from ..ff import theme
        from . import skinfonts
        seeds = skinfonts.skin_seeds(skin.resolve(), args.colour_theme, system=Path(translatePath('special://xbmc')) / 'system' / 'colors.xml')
        labels = dict(label.partition('=')[::2] for label in args.skin_label)
        skinfonts.active_skin_seeds = lambda: seeds
        skinfonts.active_skin_accent = lambda: skinfonts.skin_accent(seeds, lambda expression: labels.get(expression, ''))
        theme.skin_colors_chosen = lambda: True
    classes = {cls.__name__: cls for cls in window_classes()}
    if args.command == 'render':
        if (cls := classes.get(args.window)) is None:
            parser.error(f'unknown window {args.window!r}, one of: {", ".join(sorted(classes))}')
        xml, data = render_window(cls)
        if args.output:
            args.output.write_bytes(xml)
            print(f'{args.output}: {len(xml)} bytes')
        else:
            print(xml.decode('utf-8'))
        for path, cid in data.widget_ids().items():
            print(f'{cid:6d}  {path}')
        if problems := control_problems(ET.fromstring(xml), data.widgets):
            print(problems)
        return
    if args.dump:
        args.dump.mkdir(parents=True, exist_ok=True)
    from ..ff.logs import use_logging
    use_logging()  # the developer warnings of the generation go to `logging`: kept, shown under their window
    warnings = BufferingHandler(capacity=sys.maxsize)
    warnings.setLevel(logging.WARNING)
    logging.getLogger().addHandler(warnings)
    from .style import check_style
    contrast = contrast_problems(check_style())  # the style of the run (before the windows: a window may change the layers)
    failed = 0
    for cls in window_classes():
        for variant, (source, request) in enumerate((source, request) for source in window_sources(cls) for request in window_requests(cls)):
            xml, data = render_xml(source, request)
            if args.dump:  # <class>.<variant>: the variants in the order of `window_requests()`
                (args.dump / f'{cls.__name__}.{variant}.xml').write_bytes(xml)
                (args.dump / f'{cls.__name__}.{variant}.data').write_text(''.join(f'{line}\n' for line in data_lines(data)), encoding='utf-8')
            problems = control_problems(ET.fromstring(xml), data.widgets)
            failed += bool(problems)
            print(f'{source.name:28} {len(xml):7d} B  {len(data.widgets):4d} widgets  {problems if problems else "ok"}')
            for record in warnings.buffer:
                print(f'    warning: {record.getMessage()}')
            warnings.flush()
    for problem in contrast:  # for the authors of a theme: the texts of its style readable
        print(f'contrast: {problem}')
    raise SystemExit(1 if failed else 0)


if __name__ == '__main__':
    _main()
