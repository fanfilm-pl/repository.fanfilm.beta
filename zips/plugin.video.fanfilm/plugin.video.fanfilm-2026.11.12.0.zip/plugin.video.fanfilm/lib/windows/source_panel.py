"""
The panel of the filter of the sources window, two pages (`FILTER_PAGES`). The filter: the tree of the keys of the filter
(`lib.ff.source_keys`) with the values of the sources (a leaf of three values: must, must not, any; the unknown value of every key),
the ranges of the quality and the size (sliders), the filter on / off. The sort: the list of its criteria (`SortList`: a row a
criterion, moved up / down, removed), a criterion of any of the features chosen in the same tree of the keys (two values: chosen or
not). The state of the selection of the user (`FilterState`, the criteria) is the state of the panel: a row comes from the state, a
change of the panel is a new state. Pure Python but the tree model (no Kodi).
"""

from __future__ import annotations
from collections import Counter
from copy import deepcopy
from typing import Any, Iterable, Iterator, Sequence
from attrs import evolve, frozen
from ..ff.item import FFItem
from ..ff.source_keys import (SOURCE_KEYS, FACT_TYPES, KEY_LABELS, UNKNOWN, OTHER_LANGUAGE, SUBTITLES_WAY, QUALITY_SCALE,
                              TRUE, FALSE, SourceKey, SourceView, FilterState, SortCriterion)
from ..ff.source_facts import FACT_LABELS
from ..ff.source_filters import factory_filter
from ..sdk.facts import TrackKind, SubtitleKind
from ..kolang import L
from .scale import Scale, ScaleValue
from .tree import RowMarks, TreeModel
from .widgets.tabs import Page
from .widgets.views import ComboItem
from const import const


#: The scales of the ranges of the panel (the sliders): the quality by its values, the size in GB (logarithmic, round steps of about the same
#: ratio - 1, 1.5, 2, 3, 5, 7 a decade -, no bound at both ends).
FILTER_SCALES: dict[str, Scale] = {
    'quality': Scale(values=tuple(ScaleValue(quality, quality) for quality in QUALITY_SCALE)),
    'size': Scale(minimum=0.5, maximum=100, log=(1, 1.5, 2, 3, 5, 7), low=(ScaleValue(None, L(32887, 'off')),), high=(ScaleValue(None, L(32887, 'off')),),
                  format='{:g} GB', tick_format='{:g}'),
}

#: The texts of the panel in its template: the button which opens it, the switch of the filter, the button adding a criterion of the sort.
FILTER_TEXTS: dict[str, str] = {
    'button': L(30866, 'Filters'),
    'on': L(30867, 'Filter on'),
    'add': L(30890, 'Add…'),
    'done': L(30931, 'Done'),
    'stop': L(30945, 'Stop the search'),
    'set': L(30935, 'Set'),
}

#: The pages of the panel (its tab widget `tabs`): the filter, the sort; the help of their tabs.
FILTER_PAGES: tuple[Page, ...] = (
    Page(name='filter', title=FILTER_TEXTS['button'],
         help=L(30912, 'What is shown: a value required, hidden or any, the ranges of the quality and the size. Right: the sort.')),
    Page(name='sort', title=L(30891, 'Sort'), help=L(30892, 'The first criterion decides, the next one only among equal sources.')),
)

#: The page of the change of the filter by the values of one source (its tab widget `source_filter`, over the whole panel).
SOURCE_FILTER_PAGES: tuple[Page, ...] = (
    Page(name='edit', title=L(30932, 'Change the filter'), help=L(30933, 'The values of this source: OK changes one at once; the list behind follows.')),
)

#: The help of "Done" of the change of the filter by the values of one source.
SOURCE_FILTER_DONE_HELP: str = L(30934, 'Back to the list of the sources.')

#: The help of the controls of the panel by their paths in it; the rows of the trees: `FilterTree.help()`, `FilterTree.feature_help()`.
FILTER_HELP: dict[str, str] = {
    'tabs.on': L(30880, 'On: only the sources the filter lets through. Off: all of them, the cut ones greyed out.'),
    'tabs.quality': L(30881, 'The qualities of the sources shown, from - to.'),
    'tabs.size': L(30882, 'The sizes of the sources shown, from - to (none: any).'),
    'tabs.add': L(30898, 'A new criterion at the top: any of the features or an order (the tree).'),
}

#: The buttons of a row of the list of the criteria of the sort.
SORT_BUTTONS: tuple[str, ...] = ('up', 'down', 'remove')
#: The heading of the tree of the features of a criterion of the sort (`FilterTree(order=...)`): a new one, the one of a row (its number).
SORT_HEADINGS: dict[str, str] = {
    'new': L(30899, 'New criterion: features or an order'),
    'edit': L(30900, 'Criterion {n}: any of the features'),
}

#: The keys of the tree out of the facts (the group "Source"), in their order.
SOURCE_GROUP_KEYS: tuple[str, ...] = ('provider', 'hosting', 'route', 'cached', 'premium', 'pack', 'transfer_short')

#: The labels of the ways a language is given (the kinds of the audio tracks, the subtitles; the unknown way).
WAY_LABELS: dict[str, str] = {
    **{kind.value: FACT_LABELS[kind] for kind in TrackKind},
    SUBTITLES_WAY: FACT_LABELS[SubtitleKind.FULL],
    UNKNOWN: L(30868, 'way unknown'),
}


@frozen
class SetEntry:
    """What an item of the list of the sets of the panel does: a set loaded, an action on the current one."""

    #: The action: set, none (the current selection of no set), save, save_as, restore, delete, previous.
    kind: str
    #: The name of the set (`set`).
    name: str = ''


def set_entries(names: Sequence[str], *, base: str | None, modified: bool, has_previous: bool, read_only: bool = False) -> list[ComboItem]:
    """
    Return the items of the list of the sets: the sets (the current one with `*` if changed; of no set: its own first item), a separator, the
    actions which change something: save (changed), save as, restore (changed, of a set), delete (of a set, not the first one), previous;
    `read_only`: the changes of the sets left out (only the configuration writes then).
    """
    known = base in names
    items = [] if known else [ComboItem(label=L(30936, '(no set)'), value=SetEntry('none'))]
    items += [ComboItem(label=f'{name} *' if name == base and modified else name, value=SetEntry('set', name)) for name in names]
    actions = [] if read_only else [ComboItem(label=L(30937, 'Save as…'), value=SetEntry('save_as'))]
    if modified and not read_only:
        actions.insert(0, ComboItem(label=L(30938, 'Save'), value=SetEntry('save')))
    if known and modified:
        actions.append(ComboItem(label=L(30939, 'Restore'), value=SetEntry('restore')))
    if known and base != names[0] and not read_only:
        actions.append(ComboItem(label=L(30940, 'Delete “{name}”', name=base), value=SetEntry('delete')))
    if has_previous:
        actions.append(ComboItem(label=L(30941, 'Previous'), value=SetEntry('previous')))
    return [*items, *(evolve(item, separator='') if not n else item for n, item in enumerate(actions))]


@frozen
class FilterLeaf:
    """A leaf of the filter tree: a value of a key."""

    #: The path of the key.
    path: str
    #: The value (`UNKNOWN`: unknown).
    value: str


def range_value(state: FilterState, path: str) -> tuple[Any, Any]:
    """Return the range of a key of a state as the value of its slider (an open end: the special value of the scale, the quality: its end)."""
    low, high = state.get('ranges', {}).get(path) or (None, None)
    if path == 'quality':
        return low or QUALITY_SCALE[0], high or QUALITY_SCALE[-1]
    return low, high


def state_range(path: str, value: Sequence[Any]) -> list[Any]:
    """Return the range of a key of the value of its slider (an end of the scale is open: None)."""
    low, high = value
    if path == 'quality':
        return [None if low == QUALITY_SCALE[0] else low, None if high == QUALITY_SCALE[-1] else high]
    return [low, high]


class FilterTree:
    """
    The tree of the filter of the sources: the groups (the language, the video, the audio, the subtitles, the release, the source),
    the keys, their values (a vocabulary: all of them; the values of the sources and of the state otherwise) and the unknown one,
    the number of the sources of every value (in the label of its leaf; none: dimmed).
    """

    def __init__(self, views: Iterable[SourceView] | None, *, langs: Sequence[str], state: FilterState, order: Sequence[SourceKey] = (),
                 source: SourceView | None = None) -> None:
        """
        Make the tree of the sources (`views`; None: no search - no counts, nothing dimmed, the values the keys know and the ones of the state), the
        languages of the user and the values of the state; `order`: the keys of a criterion of
        their own (a new criterion of the sort: the node "Order" last, its leaves actions - `orders`); `source`: only the values of that source
        (`source_leaves()`), counted in all of them.
        """
        #: The languages of the user (the first nodes of the language).
        self.langs: tuple[str, ...] = tuple(langs)
        #: The tree counts the sources (there was a search).
        self.counted: bool = views is not None
        #: The number of the sources of every value.
        self.counts: Counter[FilterLeaf] = Counter()
        for view in views or ():
            for path in self.paths():
                key = SOURCE_KEYS[path]
                for value in key.get(view) or (UNKNOWN,):
                    self.counts[FilterLeaf(path, value)] += 1
        #: The values of the state by the paths of the keys.
        self.state_values: dict[str, set[str]] = {path: set(values) for path, values in state.get('keys', {}).items()}
        #: The leaf of an item (by `id()`).
        self.leaves: dict[int, FilterLeaf] = {}
        #: The key of an item among its siblings (by `id()`).
        self.keys: dict[int, str] = {}
        #: The label of an item without the number of its sources (by `id()`): the path of a row in the help.
        self.labels: dict[int, str] = {}
        #: The key of a leaf of the node "Order" (by `id()`).
        self.orders: dict[int, SourceKey] = {}
        #: The roots of the tree.
        self.roots: list[FFItem] = self.source_leaves(source) if source is not None else list(self.groups())
        #: The leaves set in a new installation (the default selection of the tree).
        self.factory: set[FilterLeaf] = {FilterLeaf(path, value) for path, values in factory_filter(langs=langs).get('keys', {}).items()
                                         for value, on in values.items() if on is True}
        if order:
            self.roots.append(self.item(L(30901, 'Order'), 'order', [self.order_leaf(key) for key in order]))

    def order_leaf(self, key: SourceKey) -> FFItem:
        """Return the leaf of the node "Order" of a key (OK: the criterion of the key in its natural order)."""
        item = self.item(criterion_label(new_criterion(key)), key.path)
        self.orders[id(item)] = key
        return item

    def marks(self, item: FFItem) -> RowMarks:
        """Return the marks of a row: the direction of a number of the node "Order" (a new one: the biggest first)."""
        key = self.orders.get(id(item))
        return RowMarks(symbol='descending') if key is not None and numeric(key) else RowMarks()

    @staticmethod
    def paths() -> Iterator[str]:
        """Iterate over the paths of the keys of the tree: the localization, the facts, the keys of the source (no range, no number)."""
        yield 'lang'
        for path, key in SOURCE_KEYS.items():
            if key.group and key.filtered and key.kind != 'range':
                yield path
        yield from SOURCE_GROUP_KEYS

    def item(self, label: str, key: str, children: list[FFItem] | None = None) -> FFItem:
        """Return an item of the tree (a node with `children`)."""
        item = FFItem(label)
        item.children_items = children
        self.keys[id(item)] = key
        self.labels[id(item)] = label
        return item

    def leaf(self, path: str, value: str, label: str) -> FFItem:
        """Return the leaf of a value (its label with the number of its sources, if counted)."""
        leaf = FilterLeaf(path, value)
        item = self.item(f'{label} ({self.counts[leaf]})' if self.counted else label, value or '?')
        self.leaves[id(item)] = leaf
        self.labels[id(item)] = label
        return item

    def values(self, key: SourceKey) -> list[str]:
        """Return the values of a key in the tree: its own ones, else of the sources and of the state by their labels; the unknown one last."""
        values = list(key.values)
        if not values:
            found = {leaf.value for leaf in self.counts if leaf.path == key.path} | self.state_values.get(key.path, set())
            values = sorted(found - {UNKNOWN}, key=lambda value: key.value_label(value).lower())
        return [*values, UNKNOWN]

    def key_node(self, key: SourceKey) -> FFItem:
        """
        Return the item of a key: the node of its values, a flag one leaf of its set value (must: set, must not: not set; an unknown value
        passes either way).
        """
        if key.kind == 'flag':
            return self.leaf(key.path, TRUE, key.leaf_label or key.label)
        return self.item(key.label, key.path, [self.leaf(key.path, value, key.value_label(value)) for value in self.values(key)])

    def lang_node(self) -> FFItem:
        """Return the node of the localization: the languages of the user, other ones, unknown (each in the ways of `const`), no way known."""
        ways = tuple(const.sources.filters.ways)
        nodes = [self.item(language_label(lang), lang or '?', [self.leaf('lang', f'{lang}/{way}', WAY_LABELS.get(way, way)) for way in ways])
                 for lang in (*self.langs, OTHER_LANGUAGE, UNKNOWN)]
        key = SOURCE_KEYS['lang']
        return self.item(key.label, 'lang', [*nodes, self.leaf('lang', UNKNOWN, key.value_label(UNKNOWN))])

    def source_leaves(self, view: SourceView) -> list[FFItem]:
        """
        Return the leaves of the values of one source, flat (the hosting and the provider first: what is hidden most, the unknown ones left
        out, a flag only set); the key named at the hosting and the provider (`const.sources.filters.short_source_values` False: at all).
        """
        first = ('hosting', 'provider')
        leaves: list[FFItem] = []
        for path in (*first, *(path for path in self.paths() if path not in first)):
            key = SOURCE_KEYS[path]
            labels = {value: feature_label(path, value) for value in key.get(view) if key.kind != 'flag' or value == TRUE}
            for value, label in sorted(labels.items(), key=lambda pair: pair[1].short.lower()):
                named = label.node and path != 'lang' and (path in first or not const.sources.filters.short_source_values)
                leaves.append(self.leaf(path, value, f'{label.node}: {label.leaf}' if named else label.short))
        return leaves

    def groups(self) -> Iterator[FFItem]:
        """Iterate over the groups of the tree: the localization, the groups of the facts, the source."""
        yield self.lang_node()
        for group in FACT_TYPES:
            keys = [key for key in SOURCE_KEYS.values() if key.group == group and key.filtered and key.kind != 'range']
            yield self.item(KEY_LABELS[group].label, group, [self.key_node(key) for key in keys])
        yield self.item(L(30871, 'Source'), 'source', [self.key_node(SOURCE_KEYS[path]) for path in SOURCE_GROUP_KEYS])

    def model(self, state: FilterState, *, tristate: bool = True) -> TreeModel:
        """
        Return the model of the tree of a state: the must values selected, the must not ones rejected (`tristate`; else two values: the
        features of a criterion of the sort chosen, their nodes expanded).
        """
        keys = state.get('keys', {})
        selected: list[FFItem] = []
        rejected: list[FFItem] = []
        for item in self.all_items():
            if (leaf := self.leaves.get(id(item))) is None:
                continue
            values = keys.get(leaf.path, {})
            on = values.get(leaf.value)
            if on is None and SOURCE_KEYS[leaf.path].kind == 'flag' and (off := values.get(FALSE)) is not None:
                on = not off  # a flag not set must not: the set one must (an unknown passes both)
            if on is True:
                selected.append(item)
            elif on is False:
                rejected.append(item)
        chosen = {id(item) for item in selected}
        expanded = [] if tristate else [item for item in self.all_items() if item.children_items and self.has_any(item, chosen)]
        return TreeModel(self.roots, selected=selected, rejected=rejected, tristate=tristate, key=lambda item: self.keys[id(item)],
                         actions=[item for item in self.all_items() if id(item) in self.orders], expanded=expanded,
                         defaults=[item for item in self.all_items() if self.leaves.get(id(item)) in self.factory] if tristate else None)

    @staticmethod
    def has_any(item: FFItem, ids: set[int]) -> bool:
        """Check if the branch of an item has one of the items (by `id()`)."""
        return id(item) in ids or any(FilterTree.has_any(child, ids) for child in item.children_items or ())

    def all_items(self) -> Iterator[FFItem]:
        """Iterate over all items of the tree (depth first)."""
        stack = list(reversed(self.roots))
        while stack:
            item = stack.pop()
            yield item
            stack.extend(reversed(item.children_items or ()))

    def state(self, model: TreeModel, state: FilterState) -> FilterState:
        """Return the filter state of the model: the values of the leaves (the keys out of the tree kept), the rest of the state kept."""
        keys = {path: dict(values) for path, values in state.get('keys', {}).items()}
        for item in self.all_items():
            if (leaf := self.leaves.get(id(item))) is None:
                continue
            values = keys.setdefault(leaf.path, {})
            if SOURCE_KEYS[leaf.path].kind == 'flag':
                values.pop(FALSE, None)  # one leaf of a flag: its value set only
            if (on := model.value(item)) is None:
                values.pop(leaf.value, None)
            else:
                values[leaf.value] = on
        return FilterState(**{**state, 'keys': {path: values for path, values in keys.items() if values}})

    def features(self, model: TreeModel) -> dict[str, list[str]]:
        """Return the chosen features of the model of two values (`SortCriterion.any`): the chosen values by the paths of their keys."""
        keys = self.state(model, FilterState()).get('keys', {})
        return {path: [value for value, on in values.items() if on] for path, values in keys.items() if any(values.values())}

    def path_label(self, item: FFItem, model: TreeModel) -> str:
        """Return the path of a row in the tree (the labels of its ancestors and its own, without the numbers of the sources)."""
        return ' › '.join(self.labels.get(id(it), it.getLabel()) for it in (*reversed(list(model.ancestors(item))), item))

    def feature_help(self, item: FFItem, model: TreeModel) -> str:
        """Return the help of a row of the tree of the features of a criterion of the sort: its path, a chosen feature, an order."""
        path = self.path_label(item, model)
        if (key := self.orders.get(id(item))) is not None:
            about = key_about(key)
            return f'{path}: {about + " • " if about else ""}{L(30902, "OK: the criterion of this order")}'
        if id(item) in self.leaves and model.value(item):
            return f'{path}: {L(30895, "chosen: the sources with any of the chosen features first")}'
        return path

    def help(self, item: FFItem, model: TreeModel, state: FilterState) -> str:
        """
        Return the help of a row: its path in the tree, the decision of a leaf (required - with the other required values of its key, an
        alternative: OR -, hidden, any - or hidden by the required other values of its key: of the filter `state`, not only the rows), the
        reset of a node not as in a new installation.
        """
        path = self.path_label(item, model)
        if (leaf := self.leaves.get(id(item))) is None:
            return f'{path}: {L(30883, "0: reset it")}' if not model.is_default(item) else path
        key = SOURCE_KEYS[leaf.path]
        others = [value for value, on in state.get('keys', {}).get(leaf.path, {}).items() if on is True and value != leaf.value]
        required = self.required_text(leaf.path, others)
        if (on := model.value(item)) is True:
            text = L(30884, 'required: only the sources with it')
            if others:
                text += f' • {L(30885, "or: {values}", values=required)}'
        elif on is False:
            text = L(30886, 'hidden: the sources with it are not shown')
            if others:
                text += f' • {L(30913, "also with the required {values}", values=required)}'
        elif others and leaf.value != UNKNOWN:
            text = L(30887, 'not required: hidden, {key} requires {values}', key=key.label, values=required)
        else:
            text = L(30889, 'any: not filtered by it')
        return f'{path}: {text}'

    @staticmethod
    def required_text(path: str, values: Sequence[str], *, most: int = 3) -> str:
        """Return the required values of a key as the help names them (`PL voice-over, EN subtitles`; more than `most`: `+n`)."""
        labels = [feature_label(path, value).short for value in values]
        return ', '.join((*labels[:most], *((f'+{len(labels) - most}',) if len(labels) > most else ())))

    def dimmed(self, item: FFItem) -> bool:
        """Check if an item is dimmed: a value of no source (not in the state)."""
        leaf = self.leaves.get(id(item))
        return self.counted and leaf is not None and not self.counts[leaf] and leaf.value not in self.state_values.get(leaf.path, ())


def language_label(lang: str) -> str:
    """Return the label of a language of the localization: a language of the user (its code), other ones, unknown."""
    return {OTHER_LANGUAGE: L(30869, 'other languages'), UNKNOWN: L(30870, 'language unknown')}.get(lang) or lang.upper()


@frozen
class FeatureLabel:
    """The label of a feature of a criterion of the sort: its node in the tree of the keys, its leaf, the feature among other keys."""

    #: The node of the feature (the key, a language of the localization), '' none (a flag).
    node: str
    #: The leaf (the value).
    leaf: str
    #: The feature among the ones of other nodes (a language: its code and the way).
    short: str


def feature_label(path: str, value: str) -> FeatureLabel:
    """Return the label of a feature (a value of a key) as the tree of the keys names it."""
    key = SOURCE_KEYS[path]
    if path == 'lang' and value != UNKNOWN:
        lang, _, way = value.partition('/')
        leaf = WAY_LABELS.get(way, way)
        return FeatureLabel(f'{key.label} {language_label(lang)}', leaf, f'{language_label(lang)} {leaf}')
    if key.kind == 'flag':
        label = key.leaf_label or key.label
        leaf = label if value == TRUE else f'{label}: {key.value_label(value)}'
        return FeatureLabel('', leaf, leaf)
    leaf = key.value_label(value)
    return FeatureLabel(key.label, leaf, f'{key.label}: {leaf}' if value == UNKNOWN else leaf)


def sort_keys(sort: Sequence[SortCriterion] = ()) -> tuple[SourceKey, ...]:
    """
    Return the keys of a criterion of their own (`SortCriterion.key`, the node "Order" of a new criterion): the numbers (the quality, the
    size, the origin, the priority), the flags of the source (1 / 0; the facts: features), the localization in its default order, the
    keys of no values of their own (the provider, the hosting: by their names); without the keys of the criteria of the sort (a second
    one changes nothing).
    """
    used = {crit.get('key') for crit in sort}
    return tuple(key for key in SOURCE_KEYS.values() if key.path not in used and not key.group
                 and (key.kind in ('range', 'number', 'pair', 'flag') or (key.kind == 'enum' and not key.values)))


def numeric(key: SourceKey) -> bool:
    """Check if a key is a number in a criterion of the sort (its direction; a flag: 1 set, 0 not)."""
    return key.kind in ('range', 'number', 'flag')


def new_criterion(key: SourceKey) -> SortCriterion:
    """Return a new criterion of a key of its own (`sort_keys()`): a number the biggest first, else the natural order of the key."""
    return SortCriterion(key=key.path, desc=True) if numeric(key) else SortCriterion(key=key.path)


def key_about(key: SourceKey) -> str:
    """Return what a key of a criterion of the sort is (`KeyLabel.about`; the localization: with its ways in their order), '' its label says it."""
    about = KEY_LABELS[key.path].about if key.path in KEY_LABELS else ''
    if key.kind == 'pair':
        about = about.format(ways=', '.join(WAY_LABELS.get(way, way) for way in const.sources.filters.ways))
    return about


def criterion_action(crit: SortCriterion) -> str:
    """Return what OK on a criterion of the sort does (the features edited, a number in the other direction), '' nothing (a key in its order)."""
    if 'any' in crit:
        return L(30914, 'Edit the features…')
    if (key := SOURCE_KEYS.get(crit.get('key', ''))) is not None and numeric(key):
        return L(30915, 'Reverse the direction')
    return ''


def criterion_help(crit: SortCriterion) -> str:
    """
    Return the help of a criterion of the sort: what it does (the features first, the direction of a number, of a flag), what its key is
    (`key_about()`), what OK does.
    """
    key = SOURCE_KEYS.get(crit.get('key', ''))
    if 'any' in crit:
        text = L(30916, 'the sources with any of the features first')
    elif key is None:
        text = ''
    elif key.kind == 'flag':
        text = L(30917, 'with it first') if crit.get('desc') else L(30918, 'without it first')
    elif numeric(key):
        text = L(30919, 'the biggest first') if crit.get('desc') else L(30920, 'the smallest first')
    else:
        text = ''
    about = key_about(key) if key is not None else ''
    action = criterion_action(crit)
    return ' • '.join(part for part in (criterion_label(crit), text, about, f'OK: {action[:1].lower()}{action[1:]}' if action else '') if part)


def criterion_label(crit: SortCriterion) -> str:
    """
    Return the label of a criterion of the sort: the features of one node by it (`Language PL: voice-over | dubbing`), of more nodes each
    (`PL voice-over | EN voice-over`); a number (its direction: a mark of its row, `SortList.marks()`); a key in its natural order.
    """
    if 'any' in crit:
        labels = [feature_label(path, value) for path, values in crit['any'].items() for value in values]
        nodes = {label.node for label in labels}
        if len(nodes) == 1 and (node := nodes.pop()):
            return f'{node}: {" | ".join(label.leaf for label in labels)}'
        return ' | '.join(label.short for label in labels)
    if (key := SOURCE_KEYS.get(crit.get('key', ''))) is None:
        return crit.get('key', '')
    if numeric(key):
        return f'{key.label} ({L(30896, "unknown first")})' if crit.get('unknown_first') else key.label
    if key.kind == 'pair':
        return f'{key.label} ({L(30897, "default order")})'
    return f'{key.label} ({L(30903, "by name")})'


class SortList:
    """The list of the criteria of the sort (a flat tree: a row a criterion): the rows of the criteria of a state, the state of the rows."""

    def __init__(self, criteria: Sequence[SortCriterion]) -> None:
        """Make the rows of the criteria."""
        #: The criterion of a row (by `id()`).
        self.criteria: dict[int, SortCriterion] = {}
        #: The rows.
        self.roots: list[FFItem] = [self.item(crit) for crit in criteria]

    def item(self, crit: SortCriterion) -> FFItem:
        """Return the row of a criterion."""
        item = FFItem(criterion_label(crit))
        self.criteria[id(item)] = deepcopy(crit)
        return item

    def model(self) -> TreeModel:
        """Return the model of the list."""
        return TreeModel(self.roots)

    def marks(self, item: FFItem) -> RowMarks:
        """Return the marks of a row: the direction of a number (↓ the biggest first, ↑ the smallest)."""
        crit = self.criteria.get(id(item), {})
        if (key := SOURCE_KEYS.get(crit.get('key', ''))) is None or not numeric(key):
            return RowMarks()
        return RowMarks(symbol='descending' if crit.get('desc') else 'ascending')

    def state(self, model: TreeModel) -> list[SortCriterion]:
        """Return the criteria of the rows of the model in their order."""
        return [deepcopy(self.criteria[id(item)]) for item in model.roots]
