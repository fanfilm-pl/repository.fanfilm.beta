"""
The layout of the windows made of widgets: rows, columns and grids of Kodi controls computed by the generator (Qt-like).

A container (`<control type="group" ff:layout="row|column|grid|free">`) has `ff:spacing="N"`, `ff:margins="N"` or
`"top,right,bottom,left"`, `ff:wrap="true"` (the navigation wraps), `ff:reflow="false"` (a static layout though its
children have `<visible>` or a text box of `ff:lines` in a column; in a row of a list, where Kodi has no grouplist, a hidden
child frees its place by conditional `slide` animations: the children between it and the spacer move into it, with no spacer
the ones after it; a stretched child instead of the spacer has a copy of each combination of the visibility of the others, as
wide as they leave it - a text ends before them; up to 3 of them, no ID in it, the containers in it laid out in each copy); its children
`ff:stretch="N"` (a share of the free space of the main axis), `ff:policy` (main axis: `fixed` - its size, `preferred` -
grows when nothing expands, shrinks to its minimum, `expanding` - takes the free space; default: fixed with an explicit size,
else preferred), `ff:align` (cross axis: `start`, `center`, `end`, `fill` - the default; a child of an explicit cross size
is centered), `ff:chars="N"` (a text unknown at the generation: N average characters), `ff:lines="N"` (a text of N lines: N lines of its
font high; a text box: up to N lines - Kodi sizes it by its text, `<height max="…">auto</height>`, a longer one scrolls; its column
a grouplist: the children after it follow its height); `<ff:stretch factor="N"/>` is a spacer (Qt `addStretch`).
A row / column of changing sizes is a Kodi grouplist: it stacks its children one after another, so it has no spacer; a stretched
(expanding) child there has its size with all of them at their largest (shown, a text box of all its lines), Kodi only moves it.

A grid (`ff:layout="grid"`, Qt `QGridLayout`) has its children in rows of `ff:columns="N"` (the row-major order), a child
takes `ff:span="N"` columns, `<ff:cell/>` is a hole (`<ff:cell span="N"/>`: of more columns; no control, the positions and
the navigation keep it); `ff:spacing="N"` or `"horizontal,vertical"`, `ff:margins` as above. A column is as wide as its widest
cell, a row as high as its highest one; the free width goes to the columns of the cells of `ff:stretch="N"` (shared by their
columns), the free height nowhere. A cell `ff:align` in its area on both axes (`fill` - the default; an explicit size of an
axis centered). The navigation goes to the nearest focusable cell in the direction (holes and labels passed), out of the grid
by the navigation of the grid itself (its own tags, else the ones the outer layout gives it), else around (`ff:wrap="true"`).

A label `ff:rotate="DEG"` (0 < DEG <= 90: up to the right) is drawn turned around its center (a Kodi animation): the bottom
corner of the start of the turned text at the bottom center of its area (a column head), its size hint is the height of the
turned text and the width a column needs not to touch the text of the next one; the text goes on over the next columns (the
grid is wider by what passes its last column, unless only columns after it are stretched: it goes over them).
`<wrapmultiline>true</wrapmultiline>` with a `<width>`: a text wider than that is broken into two lines of the most even
widths. `ff:width="N"`: the width of its cell (a column step kept though the turned text would need more). DEG 0: a flat
label (no turn), its text broken the same way, the size hints of its text, centered at the bottom of its area.
"""

from __future__ import annotations
from typing import Callable, Iterator, Sequence
from typing_extensions import Literal, TypeAlias
import re
from copy import copy, deepcopy
from itertools import product
from math import ceil, cos, radians, sin
from string import ascii_letters
from pathlib import Path
from xml.etree import ElementTree as ET
from attrs import frozen
from ..ff.logs import fflog
from ..ff.types import TRUE_VALUES, FALSE_VALUES
from .gui import GEOM_TAGS, png_size, texture_path
from .xgui import SIZED_ATTR, SRC_ATTR, TemplateError
from .geom import Rect, Point, Size


class FControl:

    def __init__(self):
        pass

    def alloc(self, rect: Rect) -> None:
        pass


class FLayout(FControl):

    def __init__(self):
        super().__init__()
        self.items = []

    @classmethod
    def from_str(cls, layout: str) -> 'FLayout':
        pass

    def add(self, item: FControl) -> None:
        self.items = []


class FVBox(FLayout):

    def add(self, item: FControl) -> None:
        self.items.append(item)


# --- the layout pass of the generated XML ---

#: The layouts of a container (`ff:layout`): side by side, one under another, in rows of columns, the children at their own positions.
Layout: TypeAlias = Literal['row', 'column', 'grid', 'free']
#: The size policies on the main axis (`ff:policy`).
Policy: TypeAlias = Literal['fixed', 'preferred', 'expanding']
#: The alignments on the cross axis (`ff:align`).
Align: TypeAlias = Literal['start', 'center', 'end', 'fill']

#: The layouts (`ff:layout`).
LAYOUTS: tuple[Layout, ...] = ('row', 'column', 'grid', 'free')
#: The size policies (`ff:policy`).
POLICIES: tuple[Policy, ...] = ('fixed', 'preferred', 'expanding')
#: The alignments (`ff:align`).
ALIGNS: tuple[Align, ...] = ('start', 'center', 'end', 'fill')
#: The control types of a layout container.
CONTAINER_TYPES: frozenset[str] = frozenset({'group', 'grouplist'})
#: The control types measured by their text (`<label>`, its font, twice `<textoffsetx>`).
TEXT_TYPES: frozenset[str] = frozenset({'label', 'fadelabel', 'button', 'togglebutton'})
#: The control types which can have the focus (the ports of the navigation); a grouplist leads the focus inside itself.
FOCUSABLE_TYPES: frozenset[str] = frozenset({'button', 'togglebutton', 'radiobutton', 'selectbutton', 'colorbutton', 'edit', 'spincontrol',
                                             'spincontrolex', 'slider', 'sliderex', 'list', 'panel', 'wraplist', 'fixedlist', 'grouplist',
                                             'scrollbar', 'epggrid'})
#: The layouts of the rows of a Kodi list (no grouplist there).
LIST_LAYOUTS: frozenset[str] = frozenset({'itemlayout', 'focusedlayout'})
#: The children of changing visibility beside a stretched one in a row / column of a list row: its copies (one of each combination
#: of their visibility, `2 ** n`) at most.
MAX_VARIANT_CONDITIONS: int = 3
#: The position tags of a laid out control which the layout replaces (by `left`, `top`, `width`, `height`).
POSITION_TAGS: frozenset[str] = frozenset({*GEOM_TAGS, 'posx', 'posy'})
#: A text not known at the generation: Kodi info labels (`$INFO[…]`, `$LOCALIZE[…]`), a binding, a string ID.
RX_UNKNOWN_TEXT = re.compile(r'\$[A-Z]+\[|\{|^\d+$')
#: The template attribute of a laid out grid: the areas of its cells in it (its holes too), `left,top,width,height` each, space separated
#: (the outline of the layout, `outline.py`).
CELLS_ATTR: str = '{ff}cells'
#: The default style (`ff:style`) of a text without a font (Kodi: font13).
DEFAULT_STYLE: str = 'normal'
#: A line break of a Kodi label.
LINE_BREAK: str = '[CR]'


@frozen
class Extent:
    """The size hints of a control on one axis."""

    #: The preferred size (Qt `sizeHint`).
    size: int
    #: The minimum size.
    minimum: int
    #: The control has an explicit numeric size (`<width>`, `<height>`).
    explicit: bool = False
    #: The size is known at the generation (not a text of `$INFO[…]` nor a texture missing).
    known: bool = True


@frozen
class Hints:
    """The size hints of a control."""

    #: The horizontal hints.
    width: Extent
    #: The vertical hints.
    height: Extent

    def main(self, row: bool) -> Extent:
        """Return the hints of the main axis (of a row: the width)."""
        return self.width if row else self.height

    def cross(self, row: bool) -> Extent:
        """Return the hints of the cross axis (of a row: the height)."""
        return self.height if row else self.width


@frozen
class Margins:
    """The margins of a container (`ff:margins`)."""

    #: The top margin.
    top: int = 0
    #: The right margin.
    right: int = 0
    #: The bottom margin.
    bottom: int = 0
    #: The left margin.
    left: int = 0

    def main(self, row: bool) -> int:
        """Return the margins of the main axis."""
        return self.left + self.right if row else self.top + self.bottom

    def cross(self, row: bool) -> int:
        """Return the margins of the cross axis."""
        return self.top + self.bottom if row else self.left + self.right

    def main_start(self, row: bool) -> int:
        """Return the margin of the main axis start."""
        return self.left if row else self.top

    def cross_start(self, row: bool) -> int:
        """Return the margin of the cross axis start."""
        return self.top if row else self.left


@frozen(kw_only=True)
class Item:
    """A child of a row / column: a control or a spacer (`<ff:stretch/>`)."""

    #: The control (or the spacer element).
    elem: ET.Element
    #: The element is a spacer.
    spacer: bool
    #: The size hints.
    hints: Hints
    #: The size policy on the main axis.
    policy: Policy
    #: The share of the free space on the main axis.
    stretch: int
    #: The alignment on the cross axis.
    align: Align

    @property
    def grows(self) -> bool:
        """Return True if the item takes the free space of the main axis (a spacer, a stretch, an expanding control)."""
        return bool(self.stretch) or self.policy == 'expanding'


@frozen(kw_only=True)
class Cell:
    """A cell of a grid: a control or a hole (`<ff:cell/>`) at its row and column."""

    #: The control (or the hole element).
    elem: ET.Element
    #: The cell is a hole.
    hole: bool
    #: The row (from 0).
    row: int
    #: The first column (from 0).
    column: int
    #: The number of the columns of the cell.
    span: int
    #: The size hints.
    hints: Hints
    #: The share of the free width of its columns.
    stretch: int
    #: The alignment in its area (both axes).
    align: Align


@frozen(kw_only=True)
class Grid:
    """The cells of a grid and the sizes of its columns and rows from them."""

    #: The number of the columns.
    columns: int
    #: The number of the rows.
    rows: int
    #: The cells in the row-major order.
    cells: list[Cell]
    #: The widths of the columns: the widest cell (a cell of more columns widens them evenly).
    widths: list[int]
    #: The heights of the rows: the highest cell.
    heights: list[int]
    #: The gaps between the columns (width) and the rows (height).
    spacing: Size
    #: The width of the turned texts after the last column.
    overhang: int


@frozen
class Turned:
    """A turned label (`ff:rotate`): its text and the size of its control before the turn."""

    #: The angle (degrees, up to the right; 0: a flat label).
    angle: float
    #: The text (broken into lines).
    label: str
    #: The width of the control.
    width: int
    #: The height of the control.
    height: int
    #: The text is known at the generation.
    known: bool

    def reach(self) -> float:
        """Return how far right of the center of its area the text goes (turned: from its bottom start corner; flat: centered)."""
        return self.width * cos(radians(self.angle)) if self.angle else self.width / 2


@frozen(kw_only=True)
class Direction:
    """A direction of the navigation in a grid."""

    #: The navigation tag.
    tag: str
    #: The step of the row.
    dr: int
    #: The step of the column.
    dc: int


#: The directions of the navigation in a grid.
DIRECTIONS: tuple[Direction, ...] = (Direction(tag='onup', dr=-1, dc=0), Direction(tag='ondown', dr=1, dc=0),
                                     Direction(tag='onleft', dr=0, dc=-1), Direction(tag='onright', dr=0, dc=1))


@frozen
class Port:
    """The focusable controls of a child of a layout where the navigation comes in and goes out."""

    #: The first focusable control (in the document order).
    first: ET.Element
    #: The last focusable control.
    last: ET.Element
    #: Where the navigation back (left / up) out of the child is set: the first control, a grid itself (it passes it on to its edge).
    head: ET.Element
    #: Where the navigation forward (right / down) out of the child is set: the last control, a grid itself.
    tail: ET.Element


@frozen(kw_only=True)
class Exit:
    """A move out of a grid: a control at the edge, its navigation tag (from the grid itself, else around the grid)."""

    #: The control.
    control: ET.Element
    #: The navigation tag.
    tag: str
    #: The control around the grid (`ff:wrap`; None: no wrap or no other control there).
    around: ET.Element | None


def _error(elem: ET.Element, message: str) -> TemplateError:
    """Return an error of the template at the element."""
    return TemplateError(message, src=elem.get(SRC_ATTR, ''))


def _warn(elem: ET.Element, message: str) -> None:
    """Log a layout problem depending on the environment (skin, language): the window is still generated."""
    fflog.warning(f'Layout: {message} at {elem.get(SRC_ATTR, "?")}')


def _number(text: str | None) -> int | None:
    """Return a numeric size (rounded), None if it is not one (missing, a percent, `auto`)."""
    try:
        return round(float(text or ''))
    except ValueError:
        return None


def _attr_int(elem: ET.Element, name: str, default: int, *, attr: str = '') -> int:
    """Return the non-negative integer template attribute (`ff:<name>`, or the attribute `attr` of a template element)."""
    value = elem.get(attr or f'{{ff}}{name}')
    if value is None:
        return default
    try:
        number = int(value)
    except ValueError:
        number = -1
    if number < 0:
        raise _error(elem, f'{attr or "ff:" + name} must be a non-negative integer, not {value!r}')
    return number


def _attr_choice(elem: ET.Element, name: str, choices: Sequence[str], default: str) -> str:
    """Return the template attribute (`ff:<name>`), one of the choices."""
    value = elem.get(f'{{ff}}{name}', default)
    if value not in choices:
        raise _error(elem, f'ff:{name} must be one of {", ".join(choices)}, not {value!r}')
    return value


def _attr_bool(elem: ET.Element, name: str, default: bool) -> bool:
    """Return the boolean template attribute (`ff:<name>`)."""
    value = elem.get(f'{{ff}}{name}')
    if value is None:
        return default
    if value.lower() in TRUE_VALUES:
        return True
    if value.lower() in FALSE_VALUES:
        return False
    raise _error(elem, f'ff:{name} must be true or false, not {value!r}')


def _margins(elem: ET.Element) -> Margins:
    """Return the margins of the container (`ff:margins="N"` or `"top,right,bottom,left"`)."""
    value = elem.get('{ff}margins', '0')
    try:
        numbers = [int(v) for v in value.split(',')]
    except ValueError:
        numbers = []
    if len(numbers) == 1:
        numbers *= 4
    if len(numbers) != 4 or min(numbers) < 0:
        raise _error(elem, f'ff:margins must be "N" or "top,right,bottom,left", not {value!r}')
    return Margins(*numbers)


def _share(amount: int, weights: Sequence[float]) -> list[int]:
    """Split the amount by the weights into whole numbers (their sum is the amount, none if all the weights are zero)."""
    total = sum(weights)
    if not total:
        return [0] * len(weights)
    parts: list[int] = []
    acc = 0.0
    done = 0
    for weight in weights:
        acc += weight
        part = round(amount * acc / total) - done
        parts.append(part)
        done += part
    return parts


def _main_sizes(items: Sequence[Item], avail: int, row: bool) -> list[int]:
    """
    Return the sizes of the items on the main axis (Qt-like): the free space goes to the items of a stretch, else to the
    expanding ones, else to the preferred ones (fixed never grows); a missing space shrinks the not fixed ones to their minimum.
    """
    sizes = [item.hints.main(row).size for item in items]
    free = avail - sum(sizes)
    growing = [item.policy != 'fixed' for item in items]
    if free >= 0:
        if any(grow and item.stretch for grow, item in zip(growing, items)):
            weights = [item.stretch if grow else 0 for grow, item in zip(growing, items)]
        elif any(grow and item.policy == 'expanding' for grow, item in zip(growing, items)):
            weights = [1 if grow and item.policy == 'expanding' else 0 for grow, item in zip(growing, items)]
        else:
            weights = [1 if grow else 0 for grow in growing]
        return [size + extra for size, extra in zip(sizes, _share(free, weights))]
    capacity = [item.hints.main(row).size - item.hints.main(row).minimum if grow else 0 for grow, item in zip(growing, items)]
    return [size - cut for size, cut in zip(sizes, _share(min(-free, sum(capacity)), capacity))]


def _set_tag(elem: ET.Element, tag: str, value: object, *, index: int | None = None) -> None:
    """Set the text of the child element (created if missing: at the index, else appended)."""
    node = elem.find(tag)
    if node is None:
        node = ET.Element(tag)
        if index is None:
            elem.append(node)
        else:
            node.tail = elem.text  # the indent of the first child
            elem.insert(index, node)
    node.text = str(value)


def _place(elem: ET.Element, rect: Rect) -> None:
    """Write the position and the size of the control (its other position tags removed)."""
    for node in [node for node in elem if node.tag in POSITION_TAGS - {'left', 'top', 'width', 'height'}]:
        elem.remove(node)
    _set_tag(elem, 'left', rect.left, index=0)
    _set_tag(elem, 'top', rect.top, index=1)
    _set_tag(elem, 'width', rect.size.width, index=2)
    _set_tag(elem, 'height', rect.size.height, index=3)


def _ports(elem: ET.Element) -> Iterator[ET.Element]:
    """
    Yield the focusable controls (with an ID) of the control in the document order (not inside a grouplist: Kodi leads there; not in an
    overlay: it lies over the window, `geometry.apply_overlays()`).
    """
    if elem.tag != 'control' or elem.get('{ff}overlay'):
        return
    if elem.get('type') in FOCUSABLE_TYPES:
        if elem.get('id'):
            yield elem
            return
        if elem.get('type') != 'grouplist':
            return
    for child in elem:
        yield from _ports(child)


def _port(elem: ET.Element) -> Port | None:
    """Return the port of the child of a layout, None if it has no focusable control."""
    controls = list(_ports(elem))
    if not controls:
        return None
    grid = elem.get('{ff}layout') == 'grid'
    return Port(controls[0], controls[-1], elem if grid else controls[0], elem if grid else controls[-1])


def _spacing(elem: ET.Element) -> Size:
    """Return the gaps of the grid (`ff:spacing="N"` or `"horizontal,vertical"`)."""
    value = elem.get('{ff}spacing', '0')
    try:
        numbers = [int(v) for v in value.split(',')]
    except ValueError:
        numbers = []
    if len(numbers) == 1:
        numbers *= 2
    if len(numbers) != 2 or min(numbers) < 0:
        raise _error(elem, f'ff:spacing of a grid must be "N" or "horizontal,vertical", not {value!r}')
    return Size(*numbers)


def _fit(hint: Extent, area: int, align: Align) -> int:
    """Return the size of a control of the hint in the area (`fill`: the area, unless the size is explicit)."""
    return area if align == 'fill' and not hint.explicit else min(hint.size, area)


def _offset(size: int, area: int, align: Align) -> int:
    """Return the position of a control of the size in the area (`fill` of an explicit size: centered)."""
    return max(0, {'start': 0, 'center': (area - size) // 2, 'end': area - size, 'fill': (area - size) // 2}[align])


def _auto_height(elem: ET.Element) -> bool:
    """
    Return True for a text box of `ff:lines`: Kodi sizes its height by its text up to the `max` of `<height>auto</height>`
    (`CGUITextBox::UpdateInfo()`, the grouplist stacks it by that height: `GetHeight()`).
    """
    return elem.get('type') == 'textbox' and _attr_int(elem, 'lines', 0) > 0


def _visible_condition(elem: ET.Element) -> str:
    """Return the condition of the visibility of the control (its `<visible>` tags: Kodi ANDs them), '' if it is always shown."""
    conditions = [text for node in elem.findall('visible') if (text := (node.text or '').strip())]
    return conditions[0] if len(conditions) == 1 else f'[{" + ".join(conditions)}]' if conditions else ''


def _negate(condition: str) -> str:
    """Return the negation of the Kodi condition: of a single term `x` / `!x` the other one, else `![…]`."""
    condition = condition.strip()
    depth = 0
    for char in condition:
        if char in '([':
            depth += 1
        elif char in ')]':
            depth -= 1
        elif char in '+|' and not depth:
            return f'![{condition}]'
    return condition[1:] if condition.startswith('!') else f'!{condition}'


def _navigate(elem: ET.Element, *, tag: str, target: ET.Element) -> None:
    """Set the navigation of the control to the target control (an explicit one wins)."""
    if elem.find(tag) is None:
        ET.SubElement(elem, tag).text = target.get('id', '')


class LayoutPass:
    """The layout of a generated window: measure the controls bottom-up, allocate their geometry top-down (Qt-like)."""

    def __init__(self, *, media: Path | None, font_styles: dict[str, str]) -> None:
        """Prepare the pass: the textures in `media`, the fonts of the template styles."""
        #: The media folder of the window (the textures).
        self.media: Path | None = media
        #: `ff:style` -> font name.
        self.font_styles: dict[str, str] = font_styles
        #: The hints of the measured controls.
        self._hints: dict[ET.Element, Hints] = {}
        #: The laid out containers.
        self._done: set[ET.Element] = set()
        #: The parents of the elements of the tree (`run()`).
        self._parents: dict[ET.Element, ET.Element] = {}
        #: The cells of the measured grids.
        self._grids: dict[ET.Element, Grid] = {}
        #: The measured turned labels.
        self._turned: dict[ET.Element, Turned] = {}
        #: The moves out of the laid out grids.
        self._exits: dict[ET.Element, list[Exit]] = {}

    def run(self, root: ET.Element) -> None:
        """
        Lay out every container of the tree; a container not inside another one keeps its position, gets its size if missing:
        stretched between both edges of its parent (left and right / top and bottom given): the room its parents give it (laid
        out in it, not written: Kodi takes it from the edges), else its content.
        """
        self._parents = {child: parent for parent in root.iter() for child in parent}
        containers = [elem for elem in root.iter() if '{ff}layout' in elem.attrib]
        for elem in containers:
            self._allocate_outer(elem)
        # the outer layouts gave the grids their navigation (after the grids were laid out): an outer grid first
        for elem in containers:
            self._exit_grid(elem)
        if (spacer := next(root.iter('{ff}stretch'), None)) is not None:
            raise _error(spacer, '<ff:stretch> out of a row / column')
        if (hole := next(root.iter('{ff}cell'), None)) is not None:
            raise _error(hole, '<ff:cell> out of a grid')

    def _allocate_outer(self, elem: ET.Element) -> None:
        """
        Lay out the container not inside another one (not laid out yet): its position kept, its size if missing (`run()`); a
        stretched one gets none (Kodi takes it from both edges: a third number of the axis would over-constrain it).
        """
        if elem in self._done:
            return
        hints = self.hints(elem)
        width, height = self._stretched(elem, True), self._stretched(elem, False)  # the room between both edges (None: not stretched)
        size = Size(width or hints.width.size, height or hints.height.size)
        for tag, value, edges in (('width', size.width, width), ('height', size.height, height)):
            if edges is None and _number(elem.findtext(tag)) is None:
                _set_tag(elem, tag, value)
        self.allocate(elem, size)

    def _stretched(self, elem: ET.Element, horizontal: bool) -> int | None:
        """Return the size of a container stretched between both edges of its parent (no numeric size, start and end given), else None."""
        start_tag, end_tag, size_tag = ('left', 'right', 'width') if horizontal else ('top', 'bottom', 'height')
        if _number(elem.findtext(size_tag)) is not None or not elem.findtext(start_tag) or not elem.findtext(end_tag):
            return None
        return self._room(elem, horizontal)

    def _room(self, elem: ET.Element, horizontal: bool) -> int | None:
        """
        Return the size Kodi gives the control on the axis: its numeric size, else its parent size less its start / end
        (no end: less its start); None if it is unknown (a percent, a centred control, no numeric parent size).
        """
        size_tag, start_tag, end_tag = ('width', 'left', 'right') if horizontal else ('height', 'top', 'bottom')
        if (size := _number(elem.findtext(size_tag))) is not None:
            return size
        if elem.tag == 'window':
            return _number(elem.findtext(f'coordinates/{size_tag}')) or (1920 if horizontal else 1080)
        if (parent := self._parents.get(elem)) is None:
            return None
        if elem.tag in LIST_LAYOUTS:  # its own size (Kodi: none or 0 - the size of the list)
            return _number(elem.get(size_tag)) or self._room(parent, horizontal)
        if elem.tag != 'control':  # <controls>
            return self._room(parent, horizontal)
        if any(elem.findtext(tag) for tag in (('centerleft', 'centerright') if horizontal else ('centertop', 'centerbottom'))):
            return None
        if (room := self._room(parent, horizontal)) is None:
            return None
        start, end = elem.findtext(start_tag), elem.findtext(end_tag)
        if (start and _number(start) is None) or (end and _number(end) is None):  # a percent
            return None
        return room - (_number(start) or 0) - (_number(end) or 0)

    # --- measure ---

    def hints(self, elem: ET.Element) -> Hints:
        """Return the size hints of the control: an explicit numeric size is fixed, else its content."""
        hints = self._hints.get(elem)
        if hints is None:
            hints = self._measure(elem)
            if '{ff}rotate' in elem.attrib:  # its explicit size is of the text before the turn, `ff:width` the one of its cell
                if width := _attr_int(elem, 'width', 0):
                    hints = Hints(Extent(width, width, explicit=True), hints.height)
                self._hints[elem] = hints
                return hints
            if (width := _number(elem.findtext('width'))) is not None:
                hints = Hints(Extent(width, width, explicit=True), hints.height)
            if (height := _number(elem.findtext('height'))) is not None:
                hints = Hints(hints.width, Extent(height, height, explicit=True))
            for tag in elem.get(SIZED_ATTR, '').split():  # a widget of a size of its layout (Qt: the size policy Ignored): no hint of its content
                unknown = Extent(0, 0, known=False)
                hints = Hints(unknown, hints.height) if tag == 'width' else Hints(hints.width, unknown)
            self._hints[elem] = hints
        return hints

    def _measure(self, elem: ET.Element) -> Hints:
        """Return the size hints of the content of the control."""
        layout = self.layout(elem)
        if layout in ('row', 'column'):
            return self._box_hints(elem, layout == 'row')
        if layout == 'grid':
            return self._grid_hints(elem)
        ctype = elem.get('type', '')
        if '{ff}rotate' in elem.attrib:
            return self._turned_hints(elem)
        if ctype in TEXT_TYPES:
            return self._text_hints(elem)
        if ctype == 'textbox':  # its text broken to its width: the height of its lines only
            return Hints(Extent(0, 0, known=False), self._text_hints(elem).height)
        if ctype == 'image':
            return self._image_hints(elem)
        if layout == 'free' or ctype in CONTAINER_TYPES:
            return self._free_hints(elem)
        return Hints(Extent(0, 0, known=False), Extent(0, 0, known=False))

    def _box_hints(self, elem: ET.Element, row: bool) -> Hints:
        """Return the hints of a row / column: the sums of its children on the main axis, the largest one on the cross axis."""
        items = self.items(elem, row)
        margins = _margins(elem)
        gaps = _attr_int(elem, 'spacing', 0) * max(0, sum(not item.spacer for item in items) - 1) + margins.main(row)
        main = [item.hints.main(row) for item in items]
        cross = [item.hints.cross(row) for item in items] or [Extent(0, 0)]
        main_extent = Extent(gaps + sum(ext.size for ext in main), gaps + sum(ext.minimum for ext in main))
        cross_extent = Extent(margins.cross(row) + max(ext.size for ext in cross), margins.cross(row) + max(ext.minimum for ext in cross))
        return Hints(main_extent, cross_extent) if row else Hints(cross_extent, main_extent)

    def _grid_hints(self, elem: ET.Element) -> Hints:
        """Return the hints of a grid: its columns and rows (the gaps between them), the turned texts after its last column."""
        grid = self.grid(elem)
        margins = _margins(elem)
        width = margins.main(True) + sum(grid.widths) + grid.spacing.width * max(0, grid.columns - 1) + grid.overhang
        height = margins.main(False) + sum(grid.heights) + grid.spacing.height * max(0, grid.rows - 1)
        return Hints(Extent(width, width), Extent(height, height))

    def grid(self, elem: ET.Element) -> Grid:
        """Return the cells of the grid in its rows and the sizes of its columns and rows."""
        grid = self._grids.get(elem)
        if grid is not None:
            return grid
        if elem.get('type') != 'group':
            raise _error(elem, f'ff:layout="grid" of <control type={elem.get("type")!r}>, a group only')
        columns = _attr_int(elem, 'columns', 0)
        if not columns:
            raise _error(elem, 'a grid needs ff:columns="N" (N > 0)')
        spacing = _spacing(elem)
        cells: list[Cell] = []
        pos = 0
        for child in elem:
            hole = child.tag == '{ff}cell'
            if not hole and child.tag != 'control':
                continue
            span = _attr_int(child, 'span', 1, attr='span' if hole else '')
            column = pos % columns
            if not 0 < span <= columns - column:
                raise _error(child, f'{"span" if hole else "ff:span"}={span} does not fit the row at its column {column + 1} of {columns}')
            hints = Hints(Extent(0, 0), Extent(0, 0)) if hole else self.hints(child)
            cells.append(Cell(elem=child, hole=hole, row=pos // columns, column=column, span=span, hints=hints,
                              stretch=0 if hole else _attr_int(child, 'stretch', 0),
                              align='fill' if hole else _attr_choice(child, 'align', ALIGNS, 'fill')))  # type: ignore[arg-type]
            pos += span
        rows = -(-pos // columns)
        widths = [0] * columns
        heights = [0] * rows
        for cell in cells:
            heights[cell.row] = max(heights[cell.row], cell.hints.height.size)
            if cell.span == 1:
                widths[cell.column] = max(widths[cell.column], cell.hints.width.size)
        for cell in cells:  # a cell of more columns widens them evenly if they are too narrow for it
            cols = range(cell.column, cell.column + cell.span)
            if (missing := cell.hints.width.size - sum(widths[c] for c in cols) - spacing.width * (cell.span - 1)) > 0:
                for c, extra in zip(cols, _share(missing, [1] * cell.span)):
                    widths[c] += extra
        total = sum(widths) + spacing.width * max(0, columns - 1)
        overhang = 0
        for cell in cells:
            if cell.elem in self._turned:
                left = sum(widths[:cell.column]) + spacing.width * cell.column
                area = sum(widths[cell.column:cell.column + cell.span]) + spacing.width * (cell.span - 1)
                overhang = max(overhang, ceil(left + area / 2 + self._turned[cell.elem].reach()) - total)
        grid = Grid(columns=columns, rows=rows, cells=cells, widths=widths, heights=heights, spacing=spacing, overhang=overhang)
        self._grids[elem] = grid
        return grid

    def _free_hints(self, elem: ET.Element) -> Hints:
        """Return the hints of a group of controls at their own positions: the box of its children."""
        children = [child for child in elem if child.tag == 'control' and not child.get('{ff}overlay')]  # an overlay: over the window
        width = max((_number(child.findtext('left')) or 0) + self.hints(child).width.size for child in children) if children else 0
        height = max((_number(child.findtext('top')) or 0) + self.hints(child).height.size for child in children) if children else 0
        return Hints(Extent(width, width), Extent(height, height))

    def _metrics(self, elem: ET.Element) -> tuple[Callable[[str], float], float]:
        """Return the text width function and the line height of the font of the text control (`skinfonts.text_metrics()`)."""
        from .skinfonts import text_metrics
        font = elem.find('font')
        style = DEFAULT_STYLE
        if font is not None:
            style = font.get('{ff}style') or next((st for st, name in self.font_styles.items() if name == font.text), '')
            if not style:
                _warn(elem, f'font {font.text!r} without ff:style, measured as {DEFAULT_STYLE!r}')
                style = DEFAULT_STYLE
        return text_metrics(style)

    def _text(self, elem: ET.Element) -> str:
        """Return the text of the text control (`$INFO[` for an `<info>` one)."""
        text = elem.findtext('label')
        if text is None and elem.find('info') is not None:
            text = '$INFO['
        return text or ''

    def _text_hints(self, elem: ET.Element, text: str | None = None) -> Hints:
        """Return the hints of a text control: its text (its lines, `ff:lines`) in its font, twice `textoffsetx` (Kodi: on both sides)."""
        measure, line_height = self._metrics(elem)
        offset_x = _number(elem.findtext('textoffsetx')) or 0
        offset_y = _number(elem.findtext('textoffsety')) or 0
        if text is None:
            text = self._text(elem)
        lines = text.split(LINE_BREAK)
        height = ceil(line_height * (_attr_int(elem, 'lines', 0) or len(lines))) + 2 * offset_y
        if (chars := _attr_int(elem, 'chars', 0)) > 0:
            width = ceil(chars * measure(ascii_letters) / len(ascii_letters)) + 2 * offset_x
        elif RX_UNKNOWN_TEXT.search(text):
            return Hints(Extent(0, 0, known=False), Extent(height, height))
        else:
            width = ceil(max(measure(line) for line in lines)) + 2 * offset_x
        return Hints(Extent(width, width), Extent(height, height))

    def _turned_hints(self, elem: ET.Element) -> Hints:
        """
        Return the hints of a turned label (`ff:rotate`): the height of the turned text, the width its column needs not to
        touch the turned text of the next one (the lines are perpendicular to the columns) and to keep it inside when centered.
        """
        turned = self.turned(elem)
        if not turned.angle:  # flat: the size of its text
            return Hints(Extent(turned.width, turned.width, known=turned.known), Extent(turned.height, turned.height, known=turned.known))
        angle = radians(turned.angle)
        width = ceil(max(turned.height / sin(angle), 2 * turned.height * sin(angle)))
        height = ceil(turned.width * sin(angle) + turned.height * cos(angle))
        return Hints(Extent(width, width, known=turned.known), Extent(height, height, known=turned.known))

    def turned(self, elem: ET.Element) -> Turned:
        """Return the turned label (`ff:rotate`): its text broken (`<wrapmultiline>` and a `<width>`), the size of its control."""
        turned = self._turned.get(elem)
        if turned is not None:
            return turned
        value = elem.get('{ff}rotate', '')
        try:
            angle = float(value)
        except ValueError:
            angle = -1  # not an angle: the error below
        if not 0 <= angle <= 90:
            raise _error(elem, f'ff:rotate must be an angle 0 <= DEG <= 90, not {value!r}')
        if elem.get('type') != 'label':
            raise _error(elem, f'ff:rotate of <control type={elem.get("type")!r}>, a label only')
        text = self._text(elem)
        width = _number(elem.findtext('width'))
        wrap = (elem.findtext('wrapmultiline') or '').lower() in TRUE_VALUES
        if wrap and width is not None and not RX_UNKNOWN_TEXT.search(text):
            from .skinfonts import break_label
            measure, _line_height = self._metrics(elem)
            text = break_label(text, measure, width)
        hints = self._text_hints(elem, text)
        if not wrap and width is not None:
            hints = Hints(Extent(width, width, explicit=True), hints.height)
        if (height := _number(elem.findtext('height'))) is not None:
            hints = Hints(hints.width, Extent(height, height, explicit=True))
        turned = Turned(angle, text, hints.width.size, hints.height.size, hints.width.known)
        self._turned[elem] = turned
        return turned

    def _image_hints(self, elem: ET.Element) -> Hints:
        """Return the hints of an image: the size of its texture (PNG) in the media folder (of an active theme which has it: `texture_path()`)."""
        texture = elem.findtext('texture') or ''
        size = png_size(texture_path(texture, self.media)) if self.media is not None and texture and not RX_UNKNOWN_TEXT.search(texture) else None
        if size is None:
            return Hints(Extent(0, 0, known=False), Extent(0, 0, known=False))
        width, height = size
        return Hints(Extent(width, width), Extent(height, height))

    def layout(self, elem: ET.Element) -> Layout | None:
        """Return the layout of the container (`ff:layout`), None if the element is no container."""
        if '{ff}layout' not in elem.attrib:
            return None
        layout = _attr_choice(elem, 'layout', LAYOUTS, '')
        if elem.tag != 'control' or elem.get('type') not in CONTAINER_TYPES:
            raise _error(elem, f'ff:layout of <{elem.tag} type={elem.get("type")!r}>, a group only')
        return layout  # type: ignore[return-value]

    def items(self, elem: ET.Element, row: bool) -> list[Item]:
        """Return the items of the row / column: its controls and spacers."""
        items: list[Item] = []
        for child in elem:
            if child.tag == '{ff}stretch':
                items.append(Item(elem=child, spacer=True, hints=Hints(Extent(0, 0), Extent(0, 0)), policy='expanding',
                                  stretch=_attr_int(child, 'factor', 0, attr='factor'), align='fill'))
            elif child.tag == 'control':
                hints = self.hints(child)
                policy = _attr_choice(child, 'policy', POLICIES, 'fixed' if hints.main(row).explicit else 'preferred')
                items.append(Item(elem=child, spacer=False, hints=hints, policy=policy,  # type: ignore[arg-type]
                                  stretch=_attr_int(child, 'stretch', 0), align=_attr_choice(child, 'align', ALIGNS, 'fill')))  # type: ignore[arg-type]
        return items

    # --- allocate ---

    def allocate(self, elem: ET.Element, size: Size) -> None:
        """Lay out the children of the container of the size (a row / column; a free one keeps its children)."""
        self._done.add(elem)
        layout = self.layout(elem)
        if layout == 'grid':
            self._allocate_grid(elem, size)
            return
        if layout not in ('row', 'column'):
            return
        row = layout == 'row'
        items = self.items(elem, row)
        for item in items:
            if item.spacer:
                elem.remove(item.elem)
        margins = _margins(elem)
        spacing = _attr_int(elem, 'spacing', 0)
        controls = [item for item in items if not item.spacer]
        reflow = elem.get('type') == 'grouplist' or (_attr_bool(elem, 'reflow', True) and any(
            item.elem.find('visible') is not None or (not row and _auto_height(item.elem)) for item in controls))  # sizes known by Kodi only
        shifts = reflow and self._in_list_row(elem)  # no grouplist in a list row: the hidden children shifted by animations
        variants: dict[frozenset[int], ET.Element] = {}  # the copies of the stretched child (before it is laid out)
        if shifts:
            if elem.get('type') == 'grouplist':
                raise _error(elem, 'a grouplist in a row of a list (Kodi has none there)')
            if sum(item.grows for item in items) > 1:
                raise _error(elem, 'a row / column of changing visibility in a list row has one spacer or one stretched child at most')
            variants = self._variants(items)
        elif reflow:
            for item in items:  # a stretched child has its size with all at their largest (Kodi moves it), a spacer would be lost
                if item.spacer:
                    raise _error(item.elem, 'a spacer in a row / column of changing sizes (a grouplist stacks its children one after another)')
        main_size = size.width if row else size.height
        cross_avail = (size.height if row else size.width) - margins.cross(row)
        avail = main_size - margins.main(row) - spacing * max(0, len(controls) - 1)
        sizes = _main_sizes(items, avail, row)
        if sum(sizes) > avail and elem.get('type') != 'grouplist':  # a grouplist of a template scrolls
            _warn(elem, f'the {layout} needs {sum(sizes) - avail} more')
        pos = margins.main_start(row)
        first = True
        grown = Rect(Point(0, 0), Size(0, 0))  # the area of the stretched child (its copies from it)
        for item, main in zip(items, sizes):
            if item.spacer:
                pos += main
                continue
            if not first:
                pos += spacing
            hint_main, hint_cross = item.hints.main(row), item.hints.cross(row)
            if not hint_main.known and item.policy != 'expanding' and not item.stretch:
                _warn(item.elem, f'the {"width" if row else "height"} is not known at the generation: give it a size, ff:chars or ff:policy="expanding"')
            if not hint_cross.known and item.align != 'fill':
                _warn(item.elem, f'the {"height" if row else "width"} is not known at the generation: give it a size or ff:align="fill"')
            cross = _fit(hint_cross, cross_avail, item.align)
            if hint_cross.minimum > cross_avail:
                _warn(item.elem, f'the {layout} is {hint_cross.minimum - cross_avail} too small for it')
                cross = hint_cross.size
            cross_pos = margins.cross_start(row) + _offset(cross, cross_avail, item.align)
            main_pos = (pos if first else 0) if reflow and not shifts else pos  # a grouplist places them itself (each after the previous one)
            if row:
                rect = Rect(Point(main_pos, cross_pos), Size(main, cross))
            else:
                rect = Rect(Point(cross_pos, main_pos), Size(cross, main))
            self._place(item.elem, rect)
            if self.layout(item.elem) is not None:
                self.allocate(item.elem, rect.size)
            if item.grows:
                grown = rect
            pos += main
            first = False
        if variants:
            self._place_variants(elem, items, sizes, spacing, row, grown, variants)
        if shifts:
            self._shift(items, sizes, spacing, row)
        elif reflow:
            elem.set('type', 'grouplist')
            _set_tag(elem, 'orientation', 'horizontal' if row else 'vertical')
            _set_tag(elem, 'itemgap', spacing)
            _set_tag(elem, 'usecontrolcoords', 'true')
        else:
            self._navigate(controls, row, wrap=_attr_bool(elem, 'wrap', False))

    def _in_list_row(self, elem: ET.Element) -> bool:
        """Return True if the control is in a row of a list (`itemlayout`, `focusedlayout`)."""
        while (elem := self._parents.get(elem)) is not None:  # type: ignore[assignment]
            if elem.tag in LIST_LAYOUTS:
                return True
        return False

    def _variants(self, items: Sequence[Item]) -> dict[frozenset[int], ET.Element]:
        """
        Return the copies of the stretched child of a row / column of changing visibility in a list row (Kodi has no grouplist
        nor a label of a changing width there): one of each combination of the visibility of the other children but all shown
        (the child itself), by the indexes of the hidden ones; none without a stretched child. Copied before the child is laid out.
        """
        index = next((i for i, item in enumerate(items) if item.grows and not item.spacer), None)
        if index is None:
            return {}
        stretched = items[index].elem
        if _visible_condition(stretched):
            raise _error(stretched, 'a stretched child of changing visibility in a list row (its copies have the visibility of the others)')
        if (control := next((node for node in stretched.iter('control') if node.get('id')), None)) is not None:
            raise _error(control, 'a control with an ID in a stretched child in a list row (copied: its ID twice)')
        conditional = [i for i, item in enumerate(items) if _visible_condition(item.elem)]
        if len(conditional) > MAX_VARIANT_CONDITIONS:
            raise _error(stretched, f'a stretched child beside {len(conditional)} children of changing visibility in a list row '
                                    f'({MAX_VARIANT_CONDITIONS} at most: a copy of each combination)')
        return {frozenset(i for i, shown in zip(conditional, combination) if not shown): deepcopy(stretched)
                for combination in product((True, False), repeat=len(conditional)) if not all(combination)}

    def _place_variants(self, container: ET.Element, items: Sequence[Item], sizes: Sequence[int], spacing: int, row: bool,
                        area: Rect, variants: dict[frozenset[int], ET.Element]) -> None:
        """
        Place the copies of the stretched child (laid out in its area: all shown) beside it, each in the area it has when its
        hidden children free their sizes and gaps (as `_shift()` moves the others); every copy (the child too) is shown by the
        visibility of its combination. The containers inside them are laid out (also the ones in a group of no layout).
        """
        index = next(i for i, item in enumerate(items) if item.grows)
        stretched = items[index].elem
        conditions = {i: condition for i, item in enumerate(items) if (condition := _visible_condition(item.elem))}
        position = list(container).index(stretched)
        for hidden, copied in {frozenset(): stretched, **variants}.items():
            if copied is not stretched:
                freed = {i: sizes[i] + spacing for i in hidden}
                before = sum(size for i, size in freed.items() if i < index)
                if row:
                    rect = Rect(Point(area.left - before, area.top), Size(area.size.width + sum(freed.values()), area.size.height))
                else:
                    rect = Rect(Point(area.left, area.top - before), Size(area.size.width, area.size.height + sum(freed.values())))
                position += 1
                container.insert(position, copied)
                self._parents.update({child: parent for parent in copied.iter() for child in parent})
                self._parents[copied] = container
                self._place(copied, rect)
                if self.layout(copied) is not None:
                    self.allocate(copied, rect.size)
            for i, condition in conditions.items():
                ET.SubElement(copied, 'visible').text = _negate(condition) if i in hidden else condition
            for node in copied.iter():
                if '{ff}layout' in node.attrib:
                    self._allocate_outer(node)

    def _shift(self, items: Sequence[Item], sizes: Sequence[int], spacing: int, row: bool) -> None:
        """
        Shift the children of a row / column in a list row by conditional animations (Kodi has no grouplist there): a hidden
        child frees its size and a gap, the children between it and the spacer (or the stretched child: its copies are wider,
        `_place_variants()`) move into its place (none: the ones after it).
        """
        spacer = next((i for i, item in enumerate(items) if item.grows), None)
        for hidden, (item, size) in enumerate(zip(items, sizes)):
            if item.spacer or not (shown := _visible_condition(item.elem)):
                continue
            condition = _negate(shown)
            freed = size + spacing
            if spacer is not None and spacer < hidden:
                moved, step = range(spacer + 1, hidden), freed
            else:
                moved, step = range(hidden + 1, len(items) if spacer is None else spacer), -freed
            for i in moved:
                end = f'{step},0' if row else f'0,{step}'
                ET.SubElement(items[i].elem, 'animation', effect='slide', end=end, time='0', condition=condition).text = 'Conditional'

    def _navigate(self, controls: Sequence[Item], row: bool, *, wrap: bool) -> None:
        """Set the navigation between the children (an explicit one wins): a row left / right, a column up / down."""
        back, forward = ('onleft', 'onright') if row else ('onup', 'ondown')
        ports = [port for port in (_port(item.elem) for item in controls) if port is not None]
        pairs = list(zip(ports, ports[1:]))
        if wrap and len(ports) > 1:
            pairs.append((ports[-1], ports[0]))
        for prev, nxt in pairs:
            _navigate(prev.tail, tag=forward, target=nxt.first)
            _navigate(nxt.head, tag=back, target=prev.last)

    def _place(self, elem: ET.Element, area: Rect) -> None:
        """Write the geometry of the control in its area (a turned label: its bottom start corner at the bottom center)."""
        turned = self._turned.get(elem)
        if turned is None:
            _place(elem, area)
            if _auto_height(elem):  # up to its lines (no more than its area)
                height = elem.find('height')
                assert height is not None
                height.text = 'auto'
                height.set('max', str(min(area.size.height, self.hints(elem).height.size)))
            return
        if not turned.angle:  # flat: its text centered at the bottom of its area
            _place(elem, Rect(Point(area.left + (area.size.width - turned.width) // 2, area.top + area.size.height - turned.height),
                              Size(turned.width, turned.height)))
            _set_tag(elem, 'label', turned.label)
            if elem.find('align') is None:
                _set_tag(elem, 'align', 'center')
            return
        angle = radians(turned.angle)
        # the center of the control (the turn is around it) from the corner: up the text by its half, up its lines by their half
        x = area.left + area.size.width / 2 + turned.width / 2 * cos(angle) - turned.height / 2 * sin(angle)
        y = area.top + area.size.height - turned.width / 2 * sin(angle) - turned.height / 2 * cos(angle)
        _place(elem, Rect(Point(round(x - turned.width / 2), round(y - turned.height / 2)), Size(turned.width, turned.height)))
        _set_tag(elem, 'label', turned.label)
        if elem.find('aligny') is None:
            _set_tag(elem, 'aligny', 'center')
        ET.SubElement(elem, 'animation', effect='rotate', end=f'{turned.angle:g}', center='auto', time='0', condition='true').text = 'Conditional'

    def _allocate_grid(self, elem: ET.Element, size: Size) -> None:
        """Lay out the cells of the grid of the size (the free width to the columns of the stretched cells), remove its holes (`CELLS_ATTR`: the areas)."""
        grid = self.grid(elem)
        margins = _margins(elem)
        spacing = grid.spacing
        widths = list(grid.widths)
        room = size.width - margins.main(True) - sum(widths) - spacing.width * max(0, grid.columns - 1)
        weights = [0.0] * grid.columns
        for cell in grid.cells:
            for c in range(cell.column, cell.column + cell.span):
                weights[c] = max(weights[c], cell.stretch / cell.span)
        # the turned texts go on over the stretched columns after them (only there): no width of their own then
        after = max((cell.column + cell.span for cell in grid.cells if cell.elem in self._turned), default=0)
        free = room if any(weights[after:]) and not any(weights[:after]) else room - grid.overhang
        if free > 0:
            widths = [width + extra for width, extra in zip(widths, _share(free, weights))]
        if room < grid.overhang:
            _warn(elem, f'the grid needs {grid.overhang - room} more width')
        if (missing := sum(grid.heights) + spacing.height * max(0, grid.rows - 1) + margins.main(False) - size.height) > 0:
            _warn(elem, f'the grid needs {missing} more height')
        lefts = [margins.left + sum(widths[:c]) + spacing.width * c for c in range(grid.columns)]
        tops = [margins.top + sum(grid.heights[:r]) + spacing.height * r for r in range(grid.rows)]
        areas: list[str] = []
        for cell in grid.cells:
            area_width = sum(widths[cell.column:cell.column + cell.span]) + spacing.width * (cell.span - 1)
            area_height = grid.heights[cell.row]
            areas.append(f'{lefts[cell.column]},{tops[cell.row]},{area_width},{area_height}')
            if cell.hole:
                elem.remove(cell.elem)
                continue
            for hint, area, axis in ((cell.hints.width, area_width, 'width'), (cell.hints.height, area_height, 'height')):
                if not hint.known and not area:
                    _warn(cell.elem, f'the {axis} is not known at the generation and nothing else in its grid line gives it: give it a size or ff:chars')
            width = _fit(cell.hints.width, area_width, cell.align)
            height = _fit(cell.hints.height, area_height, cell.align)
            if cell.elem in self._turned:
                self._place(cell.elem, Rect(Point(lefts[cell.column], tops[cell.row]), Size(area_width, area_height)))
            else:
                self._place(cell.elem, Rect(Point(lefts[cell.column] + _offset(width, area_width, cell.align),
                                                  tops[cell.row] + _offset(height, area_height, cell.align)), Size(width, height)))
            if self.layout(cell.elem) is not None:
                self.allocate(cell.elem, Size(width, height))
        elem.set(CELLS_ATTR, ' '.join(areas))
        self._navigate_grid(elem, grid)

    def _navigate_grid(self, elem: ET.Element, grid: Grid) -> None:
        """
        Set the navigation between the cells (an explicit one wins): to the nearest focusable cell in the direction (holes
        and the cells with no focus passed); the moves out of the grid are kept for `_exit_grid()`.
        """
        table: list[list[Port | None]] = [[None] * grid.columns for _ in range(grid.rows)]
        ports: list[tuple[Cell, Port]] = []
        for cell in grid.cells:
            if not cell.hole and (port := _port(cell.elem)) is not None:
                ports.append((cell, port))
                for c in range(cell.column, cell.column + cell.span):
                    table[cell.row][c] = port

        def find(port: Port, r: int, c: int, way: Direction, *, around: bool) -> Port | None:
            """Return the nearest other port from the slot in the direction (around: past the edge from the other side)."""
            for _step in range(grid.columns if way.dc else grid.rows):
                r, c = r + way.dr, c + way.dc
                if around:
                    r, c = r % grid.rows, c % grid.columns
                elif not (0 <= r < grid.rows and 0 <= c < grid.columns):
                    return None
                if (other := table[r][c]) is not None and other is not port:
                    return other
            return None

        wrap = _attr_bool(elem, 'wrap', False)
        exits: list[Exit] = []
        for cell, port in ports:
            for way in DIRECTIONS:
                forward = way.dr + way.dc > 0
                source = port.tail if forward else port.head
                column = cell.column + cell.span - 1 if way.dc > 0 else cell.column
                if (other := find(port, cell.row, column, way, around=False)) is not None:
                    _navigate(source, tag=way.tag, target=other.first if forward else other.last)
                else:
                    around = find(port, cell.row, column, way, around=True) if wrap else None
                    exits.append(Exit(control=source, tag=way.tag, around=None if around is None else around.first if forward else around.last))
        self._exits[elem] = exits

    def _exit_grid(self, elem: ET.Element) -> None:
        """Set the moves out of the grid (an explicit one wins): the navigation of the grid itself, else around it (`ff:wrap`)."""
        for move in self._exits.get(elem, ()):
            if move.control.find(move.tag) is not None:
                continue
            if own := elem.findall(move.tag):
                for node in own:
                    out = copy(node)
                    out.tail = None
                    move.control.append(out)
            elif move.around is not None:
                _navigate(move.control, tag=move.tag, target=move.around)


def apply_grouplist_moves(root: ET.Element) -> None:
    """
    Give the moves Kodi gives the children of a grouplist (`CGUIControlGroupList::AddControl()`) to the one control of a child group
    (a widget drawn as a group: a button with its focus ring). Kodi sets them on the child itself - along the grouplist the IDs of its
    neighbours (at the ends the moves of the grouplist, none or to itself: round), across it the ones of the grouplist - but a move
    leaves the focused control by its own actions only, never by its group; the group has an ID, so the moves into it work. A group of
    more controls (a field and its button across the grouplist): the moves along it on each one, across it the one back on the first and
    the one forward on the last. The own tags of the controls win (the moves of a focus line written before).
    """
    for grouplist in root.iter('control'):
        if grouplist.get('type') != 'grouplist':
            continue
        children = grouplist.findall('control')
        vertical = (grouplist.findtext('orientation') or 'vertical').strip() != 'horizontal'
        before, after, *across = ('onup', 'ondown', 'onleft', 'onright') if vertical else ('onleft', 'onright', 'onup', 'ondown')
        for n, child in enumerate(children):
            if child.get('type') != 'group' or not (ports := list(_ports(child))):
                continue
            for port in ports:  # a row of controls across the grouplist (a field and its button): each one leaves along it
                for tag, neighbour, end in ((before, n - 1, -1), (after, n + 1, 0)):
                    if port.find(tag) is not None:
                        continue
                    if 0 <= neighbour < len(children):
                        if target := children[neighbour].get('id'):
                            ET.SubElement(port, tag).text = target
                    elif (own := grouplist.findall(tag)) and not all(el.text == grouplist.get('id') for el in own):
                        port.extend(copy(el) for el in own)
                    elif target := children[end].get('id'):  # round
                        ET.SubElement(port, tag).text = target
            for tag, port in zip(across, (ports[0], ports[-1])):  # across: out of the first one back, of the last one forward
                if port.find(tag) is None:
                    port.extend(copy(el) for el in grouplist.findall(tag))


def apply_layout(root: ET.Element, *, media: Path | None, font_styles: dict[str, str]) -> None:
    """Lay out the containers (`ff:layout`) of the generated window (the template attributes are still there)."""
    LayoutPass(media=media, font_styles=font_styles).run(root)
