"""
The filter and the sort of the sources edited with no search (the configuration window opens it): the panel of the selection of the user
(`SourceFilters`) in a window of its own, no sources: the values of the trees are the known ones and the ones set, no counts.
"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from .base import BaseDialog, CANCEL_ACTIONS
from .widgets.source_filters import SelectionPanel
from ..ff.source_filters import simple_view
if TYPE_CHECKING:
    from xbmcgui import Action
    from ..ff.source_filters import SelectionMedia


class SourceFiltersDialog(BaseDialog):
    """The window of the panel of the selection of the user."""

    @classmethod
    def xml_vars(cls, simple: bool = False, **kwargs: Any) -> dict[str, Any]:
        """The view of the panel (`simple`: a variant of the window; of a real window: of its media)."""
        return {'SIMPLE_VIEW': simple_view(kwargs['media']) if 'media' in kwargs else simple}

    def __init__(self, *args: Any, media: SelectionMedia = 'movie', **kwargs: Any) -> None:
        """The window, `media`: the selection edited."""
        super().__init__(*args)
        self.filters.media = media

    @property
    def filters(self) -> SelectionPanel:
        """Return the panel."""
        return self.find('filters', SelectionPanel)

    def on_init(self) -> None:
        """Show the selection of the user, the focus on the tabs."""
        self.filters.open()
        self.setFocusId(self.filters.tabs.bar.id)

    def on_action(self, action: Action) -> bool | None:
        """Back: the end of the choice of the features of a criterion, else the window closes."""
        return True if action.getId() in CANCEL_ACTIONS and self.filters.back() else None

    def on_close_clicked(self) -> None:
        """Close the window (every change is saved at once)."""
        self.close()

    def on_focus(self, control_id: int) -> None:
        """The help of the focused control."""
        self.show_help()

    def on_filters_current_changed(self) -> None:
        """Another row or tab of the panel: its help."""
        self.show_help()

    def show_help(self) -> None:
        """Show the help of the focused control of the panel in the foot."""
        self.find('help').text = self.filters.help_text()
