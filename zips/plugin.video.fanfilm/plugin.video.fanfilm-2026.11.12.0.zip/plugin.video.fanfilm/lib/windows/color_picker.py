"""
The colour picker: a dialog of a colour (ARGB) of no place of its own - the colours of the palettes (the last one: the colours of the style),
an own colour (its hue, saturation and brightness), the default colour ('', if given), the opacity if wanted; the choice follows the focus, its signal
`changed` at every choice, its result at Close (Back cancels it). The colour of a place (a setting, a value of a provider, a style token) is
picked by `pick_color()` with the `ColorPlace` of the caller.
"""

from __future__ import annotations
import colorsys
import re
from typing import Any, Callable, Sequence
from attrs import asdict, evolve, fields_dict, frozen, field, Factory

from .base import BaseDialog
from .scale import Scale
from .style import RX_COLOR, TOKENS, tokens
from .widgets.basic import Slider
from .widgets.buttons import PushButton
from .widgets.views import ComboBox, PanelView, RowLayout
from ..ff.control import keyboard
from ..ff.signals import ClassSignal
from ..kolang import L


#: The colours of the palette Simple.
palette_basic = [
    'FFE8E8E8', 'FFF7D6D4', 'FFFCE1D0', 'FFEBE2DA', 'FFFBFBD6', 'FFDEEFD8', 'FFD5F6D8', 'FFD2ECE4', 'FFDDF3F3',
    'FFD5E8F2', 'FFD6DFED', 'FFE5DCED', 'FFEDD2E1', 'FFF8E5EA', 'FFD1D1D1', 'FFEFADA9', 'FFF9C3A2', 'FFD8C5B6',
    'FFF7F7AD', 'FFBCDFB1', 'FFABECB1', 'FFA5D8C9', 'FFBAE7E7', 'FFABD1E5', 'FFAEBEDC', 'FFCBB9DA', 'FFDBA4C3',
    'FFF2CCD5', 'FFBABABA', 'FFE7847F', 'FFF6A673', 'FFC4A891', 'FFF4F483', 'FF9BD08A', 'FF80E389', 'FF78C5AE',
    'FF98DCDC', 'FF81BAD8', 'FF859ECB', 'FFB096C8', 'FFCA76A6', 'FFECB2C0', 'FFA4A4A4', 'FFDF5B54', 'FFF38844',
    'FFB08B6C', 'FFF0F05A', 'FF7AC063', 'FF56DA62', 'FF4AB293', 'FF76D0D0', 'FF57A4CB', 'FF5D7EBA', 'FF9673B6',
    'FFB84988', 'FFE699AB', 'FF8D8D8D', 'FFD73229', 'FFF16A15', 'FF9D6E48', 'FFEDED31', 'FF59B03C', 'FF2CD13B',
    'FF1D9F78', 'FF54C4C4', 'FF2D8DBE', 'FF345DA9', 'FF7C50A4', 'FFA71B6A', 'FFE07F96', 'FF727272', 'FFAF2820',
    'FFC55610', 'FF7F5939', 'FFC1C127', 'FF479030', 'FF23AB2F', 'FF168161', 'FF43A0A0', 'FF23729B', 'FF294B89',
    'FF654085', 'FF881556', 'FFB7677A', 'FF575757', 'FF851E19', 'FF95410C', 'FF61442C', 'FF92921D', 'FF366D24',
    'FF1A8124', 'FF11624A', 'FF337979', 'FF1B5776', 'FF1F3968', 'FF4C3165', 'FF671041', 'FF8A4E5C', 'FF3B3B3B',
    'FF5A1511', 'FF652C08', 'FF422E1E', 'FF636314', 'FF254A19', 'FF125818', 'FF0C4232', 'FF235252', 'FF123B50',
    'FF152747', 'FF342145', 'FF460B2C', 'FF5E353F', 'FF181818', 'FF300B09', 'FF351805', 'FF231810', 'FF35350B',
    'FF14270D', 'FF0A2E0D', 'FF06231B', 'FF132C2C', 'FF0A1F2A', 'FF0B1525', 'FF1C1224', 'FF250618', 'FF321C21'
]

#: The colours of the palette Material Design.
palette_material_design = [
    'FFFFEBEE', 'FFFFCDD2', 'FFEF9A9A', 'FFE57373', 'FFEF5350', 'FFF44336', 'FFE53935', 'FFD32F2F', 'FFC62828',
    'FFB71C1C', 'FFFF8A80', 'FFFF5252', 'FFFF1744', 'FFD50000', 'FFFCE4EC', 'FFF8BBD0', 'FFF48FB1', 'FFF06292',
    'FFEC407A', 'FFE91E63', 'FFD81B60', 'FFC2185B', 'FFAD1457', 'FF880E4F', 'FFFF80AB', 'FFFF4081', 'FFF50057',
    'FFC51162', 'FFF3E5F5', 'FFE1BEE7', 'FFCE93D8', 'FFBA68C8', 'FFAB47BC', 'FF9C27B0', 'FF8E24AA', 'FF7B1FA2',
    'FF6A1B9A', 'FF4A148C', 'FFEA80FC', 'FFE040FB', 'FFD500F9', 'FFAA00FF', 'FFEDE7F6', 'FFD1C4E9', 'FFB39DDB',
    'FF9575CD', 'FF7E57C2', 'FF673AB7', 'FF5E35B1', 'FF512DA8', 'FF4527A0', 'FF311B92', 'FFB388FF', 'FF7C4DFF',
    'FF651FFF', 'FF6200EA', 'FFE8EAF6', 'FFC5CAE9', 'FF9FA8DA', 'FF7986CB', 'FF5C6BC0', 'FF3F51B5', 'FF3949AB',
    'FF303F9F', 'FF283593', 'FF1A237E', 'FF8C9EFF', 'FF536DFE', 'FF3D5AFE', 'FF304FFE', 'FFE3F2FD', 'FFBBDEFB',
    'FF90CAF9', 'FF64B5F6', 'FF42A5F5', 'FF2196F3', 'FF1E88E5', 'FF1976D2', 'FF1565C0', 'FF0D47A1', 'FF82B1FF',
    'FF448AFF', 'FF2979FF', 'FF2962FF', 'FFE1F5FE', 'FFB3E5FC', 'FF81D4FA', 'FF4FC3F7', 'FF29B6F6', 'FF03A9F4',
    'FF039BE5', 'FF0288D1', 'FF0277BD', 'FF01579B', 'FF80D8FF', 'FF40C4FF', 'FF00B0FF', 'FF0091EA', 'FFE0F7FA',
    'FFB2EBF2', 'FF80DEEA', 'FF4DD0E1', 'FF26C6DA', 'FF00BCD4', 'FF00ACC1', 'FF0097A7', 'FF00838F', 'FF006064',
    'FF84FFFF', 'FF18FFFF', 'FF00E5FF', 'FF00B8D4', 'FFE0F2F1', 'FFB2DFDB', 'FF80CBC4', 'FF4DB6AC', 'FF26A69A',
    'FF009688', 'FF00897B', 'FF00796B', 'FF00695C', 'FF004D40', 'FFA7FFEB', 'FF64FFDA', 'FF1DE9B6', 'FF00BFA5',
    'FFE8F5E9', 'FFC8E6C9', 'FFA5D6A7', 'FF81C784', 'FF66BB6A', 'FF4CAF50', 'FF43A047', 'FF388E3C', 'FF2E7D32',
    'FF1B5E20', 'FFB9F6CA', 'FF69F0AE', 'FF00E676', 'FF00C853', 'FFF1F8E9', 'FFDCEDC8', 'FFC5E1A5', 'FFAED581',
    'FF9CCC65', 'FF8BC34A', 'FF7CB342', 'FF689F38', 'FF558B2F', 'FF33691E', 'FFCCFF90', 'FFB2FF59', 'FF76FF03',
    'FF64DD17', 'FFF9FBE7', 'FFF0F4C3', 'FFE6EE9C', 'FFDCE775', 'FFD4E157', 'FFCDDC39', 'FFC0CA33', 'FFAFB42B',
    'FF9E9D24', 'FF827717', 'FFF4FF81', 'FFEEFF41', 'FFC6FF00', 'FFAEEA00', 'FFFFFDE7', 'FFFFF9C4', 'FFFFF59D',
    'FFFFF176', 'FFFFEE58', 'FFFFEB3B', 'FFFDD835', 'FFFBC02D', 'FFF9A825', 'FFF57F17', 'FFFFFF8D', 'FFFFFF00',
    'FFFFEA00', 'FFFFD600', 'FFFFF8E1', 'FFFFECB3', 'FFFFE082', 'FFFFD54F', 'FFFFCA28', 'FFFFC107', 'FFFFB300',
    'FFFFA000', 'FFFF8F00', 'FFFF6F00', 'FFFFE57F', 'FFFFD740', 'FFFFC400', 'FFFFAB00', 'FFFFF3E0', 'FFFFE0B2',
    'FFFFCC80', 'FFFFB74D', 'FFFFA726', 'FFFF9800', 'FFFB8C00', 'FFF57C00', 'FFEF6C00', 'FFE65100', 'FFFFD180',
    'FFFFAB40', 'FFFF9100', 'FFFF6D00', 'FFFBE9E7', 'FFFFCCBC', 'FFFFAB91', 'FFFF8A65', 'FFFF7043', 'FFFF5722',
    'FFF4511E', 'FFE64A19', 'FFD84315', 'FFBF360C', 'FFFF9E80', 'FFFF6E40', 'FFFF3D00', 'FFDD2C00', 'FFEFEBE9',
    'FFD7CCC8', 'FFBCAAA4', 'FFA1887F', 'FF8D6E63', 'FF795548', 'FF6D4C41', 'FF5D4037', 'FF4E342E', 'FF3E2723',
    'FF7F7F7F', 'C07F7F7F', '817F7F7F', '417F7F7F', 'FFFAFAFA', 'FFF5F5F5', 'FFEEEEEE', 'FFE0E0E0', 'FFBDBDBD',
    'FF9E9E9E', 'FF757575', 'FF616161', 'FF424242', 'FF212121', 'FFFFFFFF', 'C0FFFFFF', '81FFFFFF', '41FFFFFF',
    'FFECEFF1', 'FFCFD8DC', 'FFB0BEC5', 'FF90A4AE', 'FF78909C', 'FF607D8B', 'FF546E7A', 'FF455A64', 'FF37474F',
    'FF263238', 'FF000000', 'C0000000', '81000000', '41000000'
]

#: The colours of the palette Rainbow.
palette_rainbow = [
    'FFFFFFE3', 'FFFFFAE6', 'FFFEF5E6', 'FFFEF0E5', 'FFFEEBE5', 'FFFFEFEF', 'FFFFE6EA', 'FFFFE6F1', 'FFFEE6F4',
    'FFFFE6FB', 'FFFEE6FE', 'FFFAE6FF', 'FFF4E6FF', 'FFF0E6FF', 'FFEAE7FC', 'FFE6E7FC', 'FFE6EBFF', 'FFE7F0FF',
    'FFE7F5FF', 'FFE7FAFF', 'FFE6FFFF', 'FFE6FFFB', 'FFE7FEF4', 'FFE7FFF1', 'FFE6FFEA', 'FFE7FFE7', 'FFEBFFF3',
    'FFF1FFE6', 'FFF5FFE6', 'FFFBFFE6', 'FFFFFFFF', 'FFFFFFCB', 'FFFEFACA', 'FFFFEACB', 'FFFFE0CC', 'FFFED6CC',
    'FFFFCACD', 'FFFFCCD5', 'FFFFCDE0', 'FFFFCCEB', 'FFFFCBF5', 'FFFECCFD', 'FFF6CBFF', 'FFECCCFE', 'FFE0CCFF',
    'FFD6CCFE', 'FFCCCCFE', 'FFCDD6FF', 'FFCAE1FF', 'FFCCEBFF', 'FFCEF4FD', 'FFCAFFFF', 'FFCCFFF6', 'FFCBFEEB',
    'FFCCFFE0', 'FFCCFFD6', 'FFCDFFCC', 'FFD7FFCB', 'FFE1FFCD', 'FFEBFFCC', 'FFF5FFCB', 'FFEFEFEF', 'FFFEFFB3',
    'FFFFF1B2', 'FFFFE0B2', 'FFFDD2B2', 'FFFFC2B3', 'FFFFB3B3', 'FFFFB2C2', 'FFFFB3D1', 'FFFFB3E1', 'FFFFB2F4',
    'FFFFB3FE', 'FFF0B3FF', 'FFE1B2FF', 'FFD2B3FF', 'FFC1B3FE', 'FFB4B3FF', 'FFB3C1FE', 'FFB2D1FF', 'FFB3E0FF',
    'FFB2F0FF', 'FFB3FFFF', 'FFB3FFF0', 'FFB4FFE0', 'FFB3FFD1', 'FFB4FEC3', 'FFB3FFB4', 'FFC2FFB2', 'FFD1FFB4',
    'FFE0FFB3', 'FFF1FFB4', 'FFE0E0E0', 'FFFEFF99', 'FFFFEB9A', 'FFFED699', 'FFFFC299', 'FFFFAD98', 'FFFF9899',
    'FFFF99AE', 'FFFF99C1', 'FFFE99D5', 'FFFF99EC', 'FFFF99FF', 'FFEB99FF', 'FFD699FF', 'FFC299FF', 'FFAE99FF',
    'FF9A99FF', 'FF98ADFE', 'FF9AC2FF', 'FF98D6FF', 'FF99EBFF', 'FF99FFFF', 'FF99FFEA', 'FF99FFD7', 'FF9AFFC3',
    'FF99FFAC', 'FF99FF99', 'FFADFF99', 'FFC2FF98', 'FFD6FF99', 'FFEAFF98', 'FFD0D0D0', 'FFFFFF80', 'FFFFE681',
    'FFFFCC80', 'FFFFB381', 'FFFF9980', 'FFFE8081', 'FFFF8199', 'FFFF80B3', 'FFFF80CD', 'FFFF80E7', 'FFFC81FE',
    'FFE680FF', 'FFCC7FFF', 'FFB380FF', 'FF9980FF', 'FF807FFE', 'FF8099FE', 'FF7FB3FF', 'FF80CCFE', 'FF80E6FF',
    'FF7FFFFE', 'FF7FFEE0', 'FF80FFCC', 'FF80FFB2', 'FF80FF98', 'FF81FF81', 'FF99FF80', 'FFB3FF80', 'FFCCFF80',
    'FFE6FF80', 'FFC0C0C0', 'FFFFFF6B', 'FFFEE066', 'FFFFC267', 'FFFFA366', 'FFFF8566', 'FFFF6766', 'FFFF6685',
    'FFFF66A4', 'FFFF66C1', 'FFFF66E0', 'FFFF66FF', 'FFE166FF', 'FFC366FF', 'FFA366FF', 'FF8566FF', 'FF6665FE',
    'FF6785FF', 'FF66A3FE', 'FF65C2FF', 'FF65E0FF', 'FF65FFFF', 'FF66FFE0', 'FF65FFC1', 'FF66FFA4', 'FF65FF85',
    'FF66FF66', 'FF84FF66', 'FFA2FF66', 'FFC2FF66', 'FFE0FF66', 'FFAFAFAF', 'FFFFFF4D', 'FFFFDB4E', 'FFFFB84E',
    'FFFF944C', 'FFFF714D', 'FFFF4D4D', 'FFFF4D6F', 'FFFE4D93', 'FFFE4DB7', 'FFFE4DDB', 'FFFF4DFF', 'FFDC4DFF',
    'FFB84DFF', 'FF944EFF', 'FF704DFF', 'FF4D4CFF', 'FF4D70FE', 'FF4D94FE', 'FF4DB8FF', 'FF4DDBFF', 'FF4DFFFF',
    'FF4DFFDB', 'FF4EFFB9', 'FF4EFF95', 'FF4DFE70', 'FF4CFF4C', 'FF70FF4D', 'FF94FF4D', 'FFB8FE4D', 'FFDAFF4D',
    'FF8C8C8C', 'FFFFFF33', 'FFFFD634', 'FFFFAD33', 'FFFF8532', 'FFFF5C33', 'FFFF3334', 'FFFF335C', 'FFFF3287',
    'FFFF33AE', 'FFFF33D6', 'FFFE33FF', 'FFD633FE', 'FFAD34FF', 'FF8534FF', 'FF5D33FF', 'FF3233FF', 'FF325CFE',
    'FF3285FF', 'FF33ADFF', 'FF33D6FF', 'FF33FFFE', 'FF32FFD6', 'FF34FFAD', 'FF33FF84', 'FF32FF5C', 'FF34FF33',
    'FF5CFF34', 'FF85FE33', 'FFADFE33', 'FFD5FF33', 'FF7C7C7C', 'FFFFFF19', 'FFFFD119', 'FFFFA418', 'FFFF751A',
    'FFFF4719', 'FFFF1919', 'FFFF1947', 'FFFF1874', 'FFFF19A3', 'FFFF19D1', 'FFFF19FF', 'FFD019FF', 'FFA219FF',
    'FF751AFE', 'FF4719FF', 'FF1819FF', 'FF1947FF', 'FF1974FF', 'FF19A3FE', 'FF18D1FF', 'FF19FFFF', 'FF19FFD1',
    'FF19FFA4', 'FF18FF75', 'FF19FF47', 'FF19FF19', 'FF48FF19', 'FF76FF19', 'FFA3FE1A', 'FFD1FF19', 'FF6B6B6B',
    'FFFFFF00', 'FFFFCC00', 'FFFE9900', 'FFFF6600', 'FFFF3300', 'FFFE0000', 'FFFE0032', 'FFFF0066', 'FFFF0198',
    'FFFF00CC', 'FFFF00FE', 'FFCC00FF', 'FF9A00FF', 'FF6601FF', 'FF3300FF', 'FF0000FE', 'FF0033FF', 'FF0166FF',
    'FF0097FE', 'FF00CCFF', 'FF00FFFF', 'FF01FFCD', 'FF00FF99', 'FF00FE67', 'FF00FF33', 'FF00FF01', 'FF33FF00',
    'FF65FF00', 'FF99FE00', 'FFCCFF00', 'FF5D5D5D', 'FFE8E500', 'FFE6B800', 'FFE68B00', 'FFE65C01', 'FFE72E00',
    'FFE60000', 'FFE6002E', 'FFE6005B', 'FFE80183', 'FFE600B8', 'FFE600E6', 'FFB700E6', 'FF8900E6', 'FF5C01E5',
    'FF2E00E6', 'FF0000E6', 'FF012EE1', 'FF005BE7', 'FF008AE5', 'FF00B8E6', 'FF00E6E6', 'FF00E6B7', 'FF00E78B',
    'FF00E65F', 'FF00E532', 'FF00E600', 'FF2FE600', 'FF5DE600', 'FF8AE501', 'FFB8E600', 'FF4F4F4F', 'FFCDCC00',
    'FFCDA301', 'FFCA7B02', 'FFCC5200', 'FFCC2900', 'FFCC0001', 'FFCD0029', 'FFCE0052', 'FFCC007B', 'FFCD00A3',
    'FFCB00CC', 'FFA300CB', 'FF7A01CC', 'FF5201CC', 'FF2A00D0', 'FF0000CC', 'FF0029CB', 'FF0052CC', 'FF007ACD',
    'FF00A3CC', 'FF00CCCB', 'FF00CCA3', 'FF01CC7A', 'FF03CB51', 'FF00CC29', 'FF01CC00', 'FF29CC01', 'FF52CB00',
    'FF7ACB00', 'FFA2CC00', 'FF434343', 'FFB4B300', 'FFB38E00', 'FFB36B00', 'FFB34700', 'FFB32501', 'FFB30101',
    'FFB40025', 'FFB40047', 'FFB4006B', 'FFB5008B', 'FFB300B3', 'FF8F00B2', 'FF6B00B2', 'FF4700B4', 'FF2300B2',
    'FF0000B2', 'FF0025B4', 'FF0047B3', 'FF006BB3', 'FF008EB2', 'FF00B3B2', 'FF00B38E', 'FF00B36C', 'FF00B346',
    'FF00B324', 'FF00B300', 'FF24B301', 'FF47B200', 'FF6CB201', 'FF90B301', 'FF373737', 'FF999A00', 'FF987A00',
    'FF995C01', 'FF9A3D00', 'FF9A1F00', 'FF990100', 'FF99001F', 'FF9A003E', 'FF99005B', 'FF9A007A', 'FF990099',
    'FF7B0099', 'FF5D0099', 'FF3D0099', 'FF1F0099', 'FF000098', 'FF011F99', 'FF003D98', 'FF005C99', 'FF007A99',
    'FF009999', 'FF00997A', 'FF00995B', 'FF00993E', 'FF00991F', 'FF009900', 'FF1E9900', 'FF3C9900', 'FF5C9900',
    'FF7A9900', 'FF2E2E2E', 'FF7F8000', 'FF7F6601', 'FF804C00', 'FF803201', 'FF801A01', 'FF800000', 'FF800019',
    'FF800033', 'FF80004B', 'FF810065', 'FF81007F', 'FF660080', 'FF4C007F', 'FF33007F', 'FF1A0080', 'FF010080',
    'FF011A7F', 'FF003480', 'FF004C80', 'FF00667F', 'FF008081', 'FF008067', 'FF037F4B', 'FF008033', 'FF00801B',
    'FF008001', 'FF1A8000', 'FF338000', 'FF4C8001', 'FF668100', 'FF242424', 'FF656600', 'FF675201', 'FF653D00',
    'FF672900', 'FF661400', 'FF660000', 'FF660015', 'FF660028', 'FF65003C', 'FF660053', 'FF660066', 'FF550069',
    'FF3D0067', 'FF290066', 'FF150067', 'FF010066', 'FF001465', 'FF012966', 'FF003D66', 'FF005267', 'FF006766',
    'FF006651', 'FF00663E', 'FF01662A', 'FF006613', 'FF006600', 'FF146600', 'FF296600', 'FF3D6600', 'FF516600',
    'FF181818', 'FF4B4C00', 'FF4C3E01', 'FF4D2E00', 'FF4C1F00', 'FF4D0F00', 'FF4C0000', 'FF4C000F', 'FF4B001F',
    'FF4C002E', 'FF4C003E', 'FF4C004B', 'FF3D004D', 'FF2E004B', 'FF1F004C', 'FF0E004B', 'FF01004C', 'FF000E4B',
    'FF001F4D', 'FF012E4D', 'FF003D4C', 'FF004C4C', 'FF004D3D', 'FF004C2E', 'FF004C1E', 'FF004C0E', 'FF004C01',
    'FF0F4C00', 'FF204C01', 'FF2D4C00', 'FF3E4C01', 'FF000000'
]

#: The colours of the palette Web.
palette_web = [
    'FF5D8AA8', 'FFF0F8FF', 'FFE32636', 'FFEFDECD', 'FFE52B50', 'FFFFBF00', 'FFFF7E00', 'FFFF033E', 'FF9966CC',
    'FFA4C639', 'FFF2F3F4', 'FFCD9575', 'FF915C83', 'FFFAEBD7', 'FF008000', 'FF8DB600', 'FFFBCEB1', 'FF00FFFF',
    'FF7FFFD4', 'FF4B5320', 'FFE9D66B', 'FFB2BEB5', 'FF87A96B', 'FFFF9966', 'FFA52A2A', 'FFFDEE00', 'FF6E7F80',
    'FFFF2052', 'FF007FFF', 'FFF0FFFF', 'FF89CFF0', 'FFA1CAF1', 'FFF4C2C2', 'FF21ABCD', 'FFFAE7B5', 'FFFFE135',
    'FF848482', 'FF98777B', 'FFBCD4E6', 'FF9F8170', 'FFF5F5DC', 'FFFFE4C4', 'FF3D2B1F', 'FFFE6F5E', 'FF000000',
    'FFFFEBCD', 'FF318CE7', 'FFACE5EE', 'FFFAF0BE', 'FF0000FF', 'FF0093AF', 'FF0087BD', 'FF333399', 'FF0247FE',
    'FFA2A2D0', 'FF6699CC', 'FF0D98BA', 'FF8A2BE2', 'FFDE5D83', 'FF79443B', 'FF0095B6', 'FFCC0000', 'FF873260',
    'FF0070FF', 'FFB5A642', 'FFCB4154', 'FF1DACD6', 'FF66FF00', 'FFBF94E4', 'FFC32148', 'FFFF007F', 'FF08E8DE',
    'FFD19FE8', 'FFF4BBFF', 'FFFF55A3', 'FFFB607F', 'FF004225', 'FFCD7F32', 'FF964B00', 'FFA52A2A', 'FFFFC1CC',
    'FFE7FEFF', 'FFF0DC82', 'FF480607', 'FF800020', 'FFDEB887', 'FFCC5500', 'FFE97451', 'FF8A3324', 'FFBD33A4',
    'FF702963', 'FF536872', 'FF5F9EA0', 'FF91A3B0', 'FF006B3C', 'FFED872D', 'FFE30022', 'FFFFF600', 'FFA67B5B',
    'FF4B3621', 'FF1E4D2B', 'FFA3C1AD', 'FFC19A6B', 'FF78866B', 'FFFFEF00', 'FFFF0800', 'FFE4717A', 'FF00BFFF',
    'FF592720', 'FFC41E3A', 'FF00CC99', 'FFFF0040', 'FFEB4C42', 'FFFF0038', 'FFFFA6C9', 'FFB31B1B', 'FF99BADD',
    'FFED9121', 'FFACE1AF', 'FFB2FFFF', 'FF4997D0', 'FFDE3163', 'FFEC3B83', 'FF007BA7', 'FF2A52BE', 'FF007AA5',
    'FFE03C31', 'FFA0785A', 'FFFAD6A5', 'FF36454F', 'FFDFFF00', 'FF7FFF00', 'FFFFB7C5', 'FFCD5C5C', 'FF7B3F00',
    'FFD2691E', 'FFFFA700', 'FF98817B', 'FFE34234', 'FFD2691E', 'FFE4D00A', 'FFFBCCE7', 'FF0047AB', 'FFD2691E',
    'FF6F4E37', 'FF9BDDFF', 'FF002E63', 'FF8C92AC', 'FFB87333', 'FF996666', 'FFFF3800', 'FFFF7F50', 'FFF88379',
    'FFFF4040', 'FF893F45', 'FFFBEC5D', 'FFB31B1B', 'FF6495ED', 'FFFFF8DC', 'FFFFF8E7', 'FFFFBCD9', 'FFFFFDD0',
    'FFDC143C', 'FFBE0032', 'FF00FFFF', 'FF00B7EB', 'FFFFFF31', 'FFF0E130', 'FF011222', 'FF654321', 'FF5D3954',
    'FFA40000', 'FF08457E', 'FF986960', 'FFCD5B45', 'FF008B8B', 'FF536878', 'FFB8860B', 'FFA9A9A9', 'FF013220',
    'FF1A2421', 'FFBDB76B', 'FF483C32', 'FF734F96', 'FF8B008B', 'FF003366', 'FF556B2F', 'FFFF8C00', 'FF9932CC',
    'FF779ECB', 'FF03C03C', 'FF966FD6', 'FFC23B22', 'FFE75480', 'FF003399', 'FF872657', 'FF8B0000', 'FFE9967A',
    'FF560319', 'FF8FBC8F', 'FF3C1414', 'FF483D8B', 'FF2F4F4F', 'FF177245', 'FF918151', 'FFFFA812', 'FF483C32',
    'FFCC4E5C', 'FF00CED1', 'FF9400D3', 'FF00693E', 'FF555555', 'FFD70A53', 'FFA9203E', 'FFEF3038', 'FFE9692C',
    'FFDA3287', 'FFFAD6A5', 'FFB94E48', 'FF704241', 'FFC154C1', 'FF004B49', 'FF9955BB', 'FFCC00CC', 'FFFFCBA4',
    'FFFF1493', 'FFFF9933', 'FF00BFFF', 'FF1560BD', 'FFC19A6B', 'FFEDC9AF', 'FF696969', 'FF1E90FF', 'FFD71868',
    'FF85BB65', 'FF967117', 'FF00009C', 'FFE1A95F', 'FFC2B280', 'FF614051', 'FFF0EAD6', 'FF1034A6', 'FF7DF9FF',
    'FFFF003F', 'FF00FFFF', 'FF00FF00', 'FF6F00FF', 'FFF4BBFF', 'FFCCFF00', 'FFBF00FF', 'FF3F00FF', 'FF8F00FF',
    'FFFFFF00', 'FF50C878', 'FF96C8A2', 'FFC19A6B', 'FF801818', 'FFB53389', 'FFF400A1', 'FFE5AA70', 'FF4D5D53',
    'FF4F7942', 'FFFF2800', 'FF6C541E', 'FFB22222', 'FFCE2029', 'FFE25822', 'FFFC8EAC', 'FFF7E98E', 'FFEEDC82',
    'FFFFFAF0', 'FFFFBF00', 'FFFF1493', 'FFCCFF00', 'FFFF004F', 'FF014421', 'FF228B22', 'FFA67B5B', 'FF0072BB',
    'FF86608E', 'FFF64A8A', 'FFFF00FF', 'FFFF77FF', 'FFE48400', 'FFCC6666', 'FFDCDCDC', 'FFE49B0F', 'FFF8F8FF',
    'FFB06500', 'FF6082B6', 'FFE6E8FA', 'FFD4AF37', 'FFFFD700', 'FF996515', 'FFFCC200', 'FFFFDF00', 'FFDAA520',
    'FFA8E4A0', 'FF808080', 'FF7F7F7F', 'FFBEBEBE', 'FF465945', 'FF00FF00', 'FF008000', 'FF00A877', 'FF009F6B',
    'FF00A550', 'FF66B032', 'FFADFF2F', 'FFA99A86', 'FF00FF7F', 'FF663854', 'FF446CCF', 'FF5218FA', 'FFE9D66B',
    'FF3FFF00', 'FFC90016', 'FFDA9100', 'FF808000', 'FFDF73FF', 'FFF400A1', 'FFF0FFF0', 'FF007000', 'FFFF1DCE',
    'FFFF69B4', 'FF355E3B', 'FFFCF75E', 'FFB2EC5D', 'FF138808', 'FFCD5C5C', 'FFE3A857', 'FF00416A', 'FF4B0082',
    'FF002FA7', 'FFFF4F00', 'FF5A4FCF', 'FFF4F0EC', 'FF009000', 'FFFFFFF0', 'FF00A86B', 'FFF8DE7E', 'FFD73B3E',
    'FFA50B5E', 'FFFADA5E', 'FFBDDA57', 'FF29AB87', 'FF4CBB17', 'FFC3B091', 'FFF0E68C', 'FFE8000D', 'FF087830',
    'FFD6CADD', 'FF26619C', 'FFFEFE22', 'FFA9BA9D', 'FFCF1020', 'FFB57EDC', 'FFE6E6FA', 'FFCCCCFF', 'FFFFF0F5',
    'FFC4C3D0', 'FF9457EB', 'FFEE82EE', 'FFE6E6FA', 'FFFBAED2', 'FF967BB6', 'FFFBA0E3', 'FF7CFC00', 'FFFFF700',
    'FFFFFACD', 'FFFDD5B1', 'FFADD8E6', 'FFB5651D', 'FFE66771', 'FFF08080', 'FF93CCEA', 'FFF56991', 'FFE0FFFF',
    'FFF984EF', 'FFFAFAD2', 'FFD3D3D3', 'FF90EE90', 'FFF0E68C', 'FFB19CD9', 'FFFFB6C1', 'FFFFA07A', 'FFFF9999',
    'FF20B2AA', 'FF87CEFA', 'FF778899', 'FFB38B6D', 'FFE68FAC', 'FFFFFFED', 'FFC8A2C8', 'FFBFFF00', 'FF00FF00',
    'FF32CD32', 'FF195905', 'FFFAF0E6', 'FFC19A6B', 'FF534B4F', 'FFE62020', 'FFFF00FF', 'FFCA1F7B', 'FFFF0090',
    'FFAAF0D1', 'FFF8F4FF', 'FFC04000', 'FF00B8FF', 'FFFBEC5D', 'FF6050DC', 'FF0BDA51', 'FF979AAA', 'FFFF8243',
    'FF74C365', 'FF800000', 'FFB03060', 'FFE0B0FF', 'FF915F6D', 'FFEF98AA', 'FF73C2FB', 'FFE5B73B', 'FF66DDAA',
    'FF0000CD', 'FFE2062C', 'FFAF4035', 'FFF3E5AB', 'FF035096', 'FF1C352D', 'FFDDA0DD', 'FFBA55D3', 'FF0067A5',
    'FF9370DB', 'FFBB3385', 'FF3CB371', 'FF7B68EE', 'FFC9DC87', 'FF00FA9A', 'FF674C47', 'FF0054B4', 'FF48D1CC',
    'FFC71585', 'FFFDBCB4', 'FF191970', 'FF004953', 'FFFFC40C', 'FF3EB489', 'FFF5FFFA', 'FF98FF98', 'FFFFE4E1',
    'FFFAEBD7', 'FF967117', 'FF73A9C2', 'FFAE0C00', 'FFADDFAD', 'FF30BA8F', 'FF997A8D', 'FFC54B8C', 'FFF2F3F4',
    'FFFFDB58', 'FF21421E', 'FF18453B', 'FFF6ADC6', 'FF2A8000', 'FFFADA5E', 'FFFFDEAD', 'FF000080', 'FFFFA343',
    'FFFE59C2', 'FF39FF14', 'FFA4DDED', 'FF059033', 'FF0077BE', 'FFCC7722', 'FF008000', 'FFCFB53B', 'FFFDF5E6',
    'FF796878', 'FF673147', 'FFC08081', 'FF808000', 'FF6B8E23', 'FF3C341F', 'FF9AB973', 'FF0F0F0F', 'FFB784A7',
    'FFFB9902', 'FFFFA500', 'FFFF9F00', 'FFFF4500', 'FFDA70D6', 'FF654321', 'FF414A4C', 'FFFF6E4A', 'FF002147',
    'FF990000', 'FF006600', 'FF273BE2', 'FF682860', 'FFBCD4E6', 'FFAFEEEE', 'FF987654', 'FFAF4035', 'FF9BC4E2',
    'FFDDADAF', 'FFDA8A67', 'FFABCDEF', 'FFE6BE8A', 'FFEEE8AA', 'FF98FB98', 'FFDCD0FF', 'FFF984E5', 'FFFADADD',
    'FFDDA0DD', 'FFDB7093', 'FF96DED1', 'FFC9C0BB', 'FFECEBBD', 'FFBC987E', 'FFDB7093', 'FF78184A', 'FFFFEFD5',
    'FF50C878', 'FFAEC6CF', 'FF836953', 'FFCFCFC4', 'FF77DD77', 'FFF49AC2', 'FFFFB347', 'FFFFD1DC', 'FFB39EB5',
    'FFFF6961', 'FFCB99C9', 'FFFDFD96', 'FF800080', 'FF40404F', 'FFFFE5B4', 'FFFFCC99', 'FFFFDAB9', 'FFFADFAD',
    'FFD1E231', 'FFEAE0C8', 'FF88D8C0', 'FFE6E200', 'FFCCCCFF', 'FF1C39BB', 'FF00A693', 'FF32127A', 'FFD99058',
    'FFF77FBE', 'FF701C1C', 'FFCC3333', 'FFFE28A2', 'FFDF00FF', 'FF000F89', 'FF123524', 'FFFDDDE6', 'FF01796F',
    'FFFFC0CB', 'FFFF9966', 'FFE7ACCF', 'FFF78FA7', 'FF93C572', 'FFE5E4E2', 'FF8E4585', 'FFDDA0DD', 'FFFF5A36',
    'FFB0E0E6', 'FFFF8F00', 'FF701C1C', 'FF003153', 'FFDF00FF', 'FFCC8899', 'FFFF7518', 'FF800080', 'FF9F00C5',
    'FFA020F0', 'FF69359C', 'FF9678B6', 'FFFE4EDA', 'FF50404D', 'FF51484F', 'FFFF355E', 'FFE30B5D', 'FF915F6D',
    'FFE25098', 'FFB3446C', 'FF826644', 'FFFF33CC', 'FFE3256B', 'FFFF0000', 'FFF2003C', 'FFC40233', 'FFED1C24',
    'FFFE2712', 'FFA52A2A', 'FFC71585', 'FFAB4E52', 'FF004040', 'FFF1A7FE', 'FFD70040', 'FF0892D0', 'FFA76BCF',
    'FFB666D2', 'FFB03060', 'FF414833', 'FF00CCCC', 'FFFF007F', 'FFF9429E', 'FF674846', 'FFB76E79', 'FFE32636',
    'FFFF66CC', 'FFAA98A9', 'FF905D5D', 'FFAB4E52', 'FF65000B', 'FFD40000', 'FFBC8F8F', 'FF0038A8', 'FF002366',
    'FF4169E1', 'FFCA2C92', 'FF7851A9', 'FFE0115F', 'FFFF0028', 'FFBB6528', 'FFE18E96', 'FFA81C07', 'FF80461B',
    'FFB7410E', 'FF00563F', 'FF8B4513', 'FFFF6700', 'FFF4C430', 'FF23297A', 'FFFF8C69', 'FFFF91A4', 'FFC2B280',
    'FF967117', 'FFECD540', 'FFF4A460', 'FF967117', 'FF507D2A', 'FF0F52BA', 'FFCBA135', 'FFFF2400', 'FFFFD800',
    'FF76FF7A', 'FF2E8B57', 'FF321414', 'FFFFF5EE', 'FFFFBA00', 'FF704214', 'FF8A795D', 'FF009E60', 'FFFC0FC0',
    'FF882D17', 'FFC0C0C0', 'FFCB410B', 'FF007474', 'FF87CEEB', 'FFCF71AF', 'FF6A5ACD', 'FF708090', 'FF003399',
    'FF933D41', 'FF100C08', 'FFFFFAFA', 'FF0FC0FC', 'FFFEFDFF', 'FFA7FC00', 'FF00FF7F', 'FF4682B4', 'FFFADA5E',
    'FF990000', 'FFE4D96F', 'FFFFCC33', 'FFFAD6A5', 'FFD2B48C', 'FFF94D00', 'FFF28500', 'FFFFCC00', 'FF483C32',
    'FF8B8589', 'FFD0F0C0', 'FFF88379', 'FFF4C2C2', 'FF008080', 'FF367588', 'FF006D5B', 'FFCD5700', 'FFE2725B',
    'FFD8BFD8', 'FFDE6FA1', 'FFFC89AC', 'FF0ABAB5', 'FFE08D3C', 'FFDBD7D2', 'FFEEE600', 'FFFF6347', 'FF746CC0',
    'FFFFC87C', 'FFFD0E35', 'FF808080', 'FF00755E', 'FF0073CF', 'FF417DC1', 'FFDEAA88', 'FFB57281', 'FF30D5C8',
    'FF00FFEF', 'FFA0D6B4', 'FF66424D', 'FF8A496B', 'FF66023C', 'FF0033AA', 'FFD9004C', 'FF8878C3', 'FF536895',
    'FFFFB300', 'FF3CD070', 'FF120A8F', 'FF4166F5', 'FFFF6FFF', 'FF635147', 'FF5B92E5', 'FFB78727', 'FFFFFF66',
    'FF014421', 'FF7B1113', 'FFAE2029', 'FFE1AD21', 'FF990000', 'FFFFCC00', 'FFD3003F', 'FFF3E5AB', 'FFC5B358',
    'FFC80815', 'FF43B3AE', 'FFE34234', 'FFA020F0', 'FF8F00FF', 'FF7F00FF', 'FF8601AF', 'FFEE82EE', 'FF40826D',
    'FF922724', 'FF9F1D35', 'FFDA1D81', 'FFFFA089', 'FF9F00FF', 'FF004242', 'FF645452', 'FFF5DEB3', 'FFFFFFFF',
    'FFF5F5F5', 'FFA2ADD0', 'FFFF43A4', 'FFFC6C85', 'FF722F37', 'FFC9A0DC', 'FF738678', 'FF0F4D92', 'FFFFFF00',
    'FFEFCC00', 'FFFFD300', 'FFFFEF00', 'FFFEFE33', 'FF9ACD32', 'FFFFAE42', 'FF0014A8', 'FF2C1608'
]


@frozen
class Palette:
    """A palette of the picker: its name (the window property `current_palette`), its colours (opaque ARGB), its label (the combo box)."""

    #: The name.
    name: str
    #: The colours.
    colors: Sequence[str]
    #: The label, '' the name.
    label: str = field(default=Factory(lambda self: self.name, takes_self=True))


#: The palettes before the one of the style (`theme_palette()`), in the order of the combo box.
PALETTES: tuple[Palette, ...] = (
    Palette('Rainbow', palette_rainbow, L(30780, 'Rainbow')),
    Palette('Simple', palette_basic, L(30781, 'Simple')),
    Palette('Material Design', palette_material_design),
    Palette('Web', palette_web),
)


def theme_palette() -> Palette:
    """Return the palette of the style of now: the colours of its colour tokens opaque, each once, the ones the user may change first."""
    values = tokens().values
    ordered = sorted((token for token in TOKENS if token.kind == 'color'), key=lambda token: not token.adjustable)
    colors = dict.fromkeys(f'FF{value[2:]}'.upper() for token in ordered if RX_COLOR.fullmatch(value := str(values[token.name])))
    return Palette('Theme', list(colors), L(32918, 'Theme'))


def palette_shown(*names: str) -> str:
    """Return the Kodi condition: one of the palettes (their names) is shown (the window property `current_palette`)."""
    return ' | '.join(f'String.IsEqual(Window.Property(current_palette),{name})' for name in names)


@frozen(kw_only=True)
class PaletteCells(RowLayout):
    """The cells of palettes (the rows of the panel `colors`): the palettes shown by them, their size, the zoom of the focused one."""

    #: The names of the palettes shown by these cells.
    palettes: tuple[str, ...]
    #: The zoom of the focused cell (percent).
    zoom: int
    #: The Kodi condition of the layouts: one of the palettes is shown.
    condition: str = field(default=Factory(lambda self: palette_shown(*self.palettes), takes_self=True))


#: The cells of the palettes (a pair of item layouts of the panel each), the shown palette picks them.
PALETTE_CELLS: tuple[PaletteCells, ...] = (
    PaletteCells(width=97, height=75, zoom=120, palettes=('Theme', 'Simple')),
    PaletteCells(width=97, height=44, zoom=120, palettes=('Material Design',)),
    PaletteCells(width=44, height=44, zoom=140, palettes=('Web', 'Rainbow')),
)


#: The scale of the opacity of a colour in the column (the small slider of a colour with its transparency, `ColorPlace.alpha`; 5 % a step,
#: Page up / down: 25 %); the slider of an own colour: `PERCENT`.
OPACITY: Scale = Scale(minimum=0, maximum=100, step=5, major=5, format='{} %')


#: The scale of the hue of an own colour (degrees; Page up / down: 30°).
HUE: Scale = Scale(minimum=0, maximum=360, major=30, format='{}°')
#: The scale of the saturation and the brightness of an own colour (percent; Page up / down: 25 %).
PERCENT: Scale = Scale(minimum=0, maximum=100, major=25, format='{} %')


@frozen
class Hsv:
    """An opaque colour by its hue (degrees), saturation and brightness (percent): the sliders of an own colour."""

    #: The hue (0..360°).
    hue: int
    #: The saturation (0..100 %).
    saturation: int
    #: The brightness (the value of HSV, 0..100 %).
    brightness: int

    @classmethod
    def of(cls, color: str) -> Hsv:
        """Return the hue, saturation and brightness of an ARGB colour (its alpha left out)."""
        hue, saturation, brightness = colorsys.rgb_to_hsv(*(int(color[i:i + 2], 16) / 255 for i in (2, 4, 6)))
        return cls(round(hue * 360) % 360, round(saturation * 100), round(brightness * 100))

    def color(self) -> str:
        """Return the opaque ARGB colour."""
        rgb = colorsys.hsv_to_rgb(self.hue / 360, self.saturation / 100, self.brightness / 100)
        return 'FF' + ''.join(f'{round(c * 255):02X}' for c in rgb)


#: The tint of an image in its own colours (Kodi multiplies a texture by its colordiffuse): white.
UNTINTED: str = Hsv(0, 0, 100).color()


def opacity_of(color: str) -> int:
    """Return the opacity of an ARGB colour in percent (its position on `OPACITY`)."""
    return round(int(color[:2], 16) * 100 / 255)


def nearest_color(color: str, colors: Sequence[str]) -> int:
    """
    Return the index of the colour of `colors` nearest to an ARGB colour (-1: no colours; the first of the nearest ones): the "redmean"
    weighted distance of their RGB (the alpha left out; 0: the same RGB), a cheap approximation of the difference seen.
    """
    def rgb(argb: str) -> tuple[int, ...]:
        """Return the red, green and blue of an ARGB colour."""
        return tuple(int(argb[i:i + 2], 16) for i in (2, 4, 6))

    r1, g1, b1 = rgb(color)

    def distance(other: str) -> float:
        """Return the squared redmean distance of the colour `other` to `color`."""
        r2, g2, b2 = rgb(other)
        mean = (r1 + r2) / 2
        return (2 + mean / 256) * (r1 - r2) ** 2 + 4 * (g1 - g2) ** 2 + (2 + (255 - mean) / 256) * (b1 - b2) ** 2

    return min(range(len(colors)), key=lambda i: distance(colors[i]), default=-1)


def code_of(color: str, alpha: bool = True) -> str:
    """
    Return the code of an ARGB colour under its sample: an opaque one or one of a place without its transparency (`alpha` False) without
    its alpha (`RRGGBB`), else all of it (`AARRGGBB`).
    """
    return color[2:] if not alpha or color[:2].upper() == 'FF' else color


def alpha_of(percent: int) -> str:
    """Return the alpha of an ARGB colour (two hex digits) of the opacity in percent."""
    return f'{round(percent * 255 / 100):02X}'


@frozen
class ColorPlace:
    """
    Where a colour of the caller of the picker is kept (`pick_color()`): read, written ('' the default one, every other value a colour,
    also `00000000`: black of 0 % opacity), with its transparency or not, the colour shown for the default one.
    """

    #: Read it ('' the default one).
    get: Callable[[], str]
    #: Write it ('' the default one).
    set: Callable[[str], None]
    #: The place keeps the transparency of the colour (ARGB, e.g. a colour token of the style): the opacity slider of the picker, a chosen
    #: colour written with it.
    alpha: bool = False
    #: The colour shown for the default one (''), None: no default one (no button Default).
    default: str | None = None


class ColorPicker(BaseDialog[str]):
    """
    The colour picker (see the module): the colors of a palette (`colors`) or the sliders of an own colour and its code (`code`), the column
    of the buttons (`buttons`): the old colour (`old`: chosen again) beside the new one, the palettes (`palette`), Own color / Palette (`own`),
    Default (`default`, only with a default colour), Close. The choice follows the focus (a color, a slider), OK on a color goes to Close.
    Its result (`do_modal()`): the colour chosen ('' the default one) at Close, None at Back (cancelled) or with no change.
    """

    #: A colour chosen (ARGB, '' the default one): the focus moved to a color, a move of a slider, Default, the old colour, a colour typed;
    #: the old colour again at a cancel of a change (Back).
    changed: ClassSignal = ClassSignal()

    #: The sliders of an own colour (their widget names: the fields of `Hsv`).
    OWN_SLIDERS: tuple[str, ...] = tuple(fields_dict(Hsv))
    #: The opacity sliders of a colour with its transparency (one value, two views): the small one of the column, the one of an own colour.
    OPACITY_SLIDERS: tuple[str, ...] = ('opacity', 'own_opacity')
    #: A colour typed (any letter case): its alpha (none: the current one) and its RGB.
    rx_color: re.Pattern[str] = re.compile(r'(?P<alpha>[0-9A-F]{2})?(?P<rgb>[0-9A-F]{6})', flags=re.IGNORECASE)

    def __init__(self, *args: Any, value: str | None = None, default: str | None = None, alpha: bool = False, heading: str = '',
                 **kwargs: Any) -> None:
        """
        The colour `value` (ARGB; '', None: the default one); `default`: the colour shown for the default one (None, '': no default one -
        no button Default); `alpha`: the colour has its transparency (the opacity slider, a colour chosen with it); `heading`: the title (none: the
        title of the picker).
        """
        super().__init__()
        #: The palettes: the one of the style of now last.
        self.palettes: tuple[Palette, ...] = (*PALETTES, theme_palette())
        #: The palette shown (its index in `palettes`).
        self.current_palette: int = 0
        #: The colour shown for the default one (''), None: no default one.
        self.default: str | None = default or None
        # if not color or self.rx_def_color.fullmatch(color):
        #     color = self.DEFAULT
        #: The colour has its transparency: the opacity slider, a colour chosen with it.
        self.keeps_alpha: bool = alpha
        #: The title, none: the title of the picker.
        self.heading: str = heading
        #: The colour at the open ('' the default one): the old one, kept at a cancel.
        self.start: str = value or ''
        #: The colour of now ('' the default one): the start one, then the one chosen last.
        self.value: str = self.start
        #: Close clicked: the colour of now is the result (`on_close()`), else the choice is cancelled.
        self.committed: bool = False
        #: The alpha of the colour chosen (two hex digits; a colour with its transparency: its opacity sliders, a typed one kept exactly).
        self.alpha: str = 'FF'
        #: The current colour shown (the new one: ARGB).
        self.choice: str = ''
        #: An own colour is shown (its sliders instead of the colors of the palette).
        self.own: bool = False

    @classmethod
    def xml_vars(cls, *, alpha: bool = False, **kwargs: Any) -> dict[str, Any]:
        """
        The cells of the palettes (the item layouts of the panel); the opacity slider of a colour with its transparency (`alpha`: the
        generated variants: also the one of an own colour), its scale; the sliders of an own colour, their scales; the labels.
        """
        return {'PALETTE_CELLS': PALETTE_CELLS, 'ALPHA': alpha, 'OPACITY': OPACITY, 'HUE': HUE, 'PERCENT': PERCENT, 'UNTINTED': UNTINTED,
                'LABELS': {'hue': L(30776, 'Hue'), 'saturation': L(30777, 'Saturation'), 'brightness': L(30778, 'Brightness'),
                           'own_opacity': L(30785, 'Opacity'), 'code': L(30782, 'Code'), 'palette': L(30784, 'Palette:'), 'default': L(30753, 'Default')}}

    def on_init(self) -> None:
        """
        Show the title, the old colour, the default one (none: no button Default), the first palette with the colors on the cell of the
        colour (marked) or, if the palette has it not, on the nearest one (not marked; the window focuses the colors, its default control);
        nothing chosen.
        """
        self.setProperty('heading', self.title())
        shown = self.shown(self.start)
        self.setProperty('old_choice', shown)
        self.setProperty('old_code', self.code(shown))
        self.setProperty('default_color', self.default or '')
        if self.keeps_alpha:
            for name in self.OPACITY_SLIDERS:
                self.find(name, Slider).changed.connect(self.opacity_moved)
            self.show_opacity(shown or UNTINTED)  # no colour: the colours chosen opaque
        for name in self.OWN_SLIDERS:
            self.find(name, Slider).changed.connect(self.own_moved)
        palettes = self.find('buttons.palette', ComboBox)
        palettes.items = [palette.label for palette in self.palettes]
        self.show_palette()
        self.show_own_button()

    def choose(self, color: str) -> None:
        """Choose the colour ('' the default one): shown (the colors: its cell), the colour of now, `changed` emitted."""
        self.value = color
        self.set_current_choice(color)
        if not self.own:
            self.show_chosen()
        self.changed.emit(color)

    def choose_shown(self, color: str) -> None:
        """Choose the colour of a button (the default one '', the old one): its opacity by the slider, its sliders of an own colour."""
        if self.keeps_alpha:
            self.show_opacity(self.shown(color))
        self.choose(color)
        if self.own:
            self.show_own(self.choice)

    def on_close(self) -> None:
        """
        The result at every close: the colour of now at Close if it changed, else None; a change cancelled (Back) shows the old colour again
        (`changed`: e.g. a caller writing every choice).
        """
        changed = self.value != self.start
        self.set_result(self.value if self.committed and changed else None)
        if changed and not self.committed:
            self.changed.emit(self.start)

    def on_colors_current_changed(self, index: int) -> None:
        """The focus moved to a color (the window shown, the panel focused - not a fill): chosen (with the opacity of the slider)."""
        colors = self.find('colors', PanelView)
        if self._ready and self.focused_id() == colors.id and 0 <= index < len(colors.rows):
            if (color := self.with_alpha(colors.rows[index])) != self.choice:
                self.choose(color)

    def on_colors_activated(self, index: int) -> None:
        """A color is clicked: chosen (with the opacity of the slider), the focus on Close (OK again closes)."""
        self.choose(self.with_alpha(self.find('colors', PanelView).rows[index]))
        self.set_focus(self.find('buttons.close').id)

    def opacity_moved(self, percent: int) -> None:
        """An opacity slider moved: the other one shows it too, the current colour chosen with it (no colour: none chosen)."""
        self.alpha = alpha_of(percent)
        for name in self.OPACITY_SLIDERS:
            self.find(name, Slider).value = percent
        if self.choice:
            self.choose(self.with_alpha(self.choice))

    def own_moved(self, value: int) -> None:
        """A slider of an own colour moved: the colour of the sliders chosen (with the opacity of the slider)."""
        hsv = Hsv(**{name: self.find(name, Slider).value for name in self.OWN_SLIDERS})
        self.choose(self.with_alpha(hsv.color()))
        self.show_tracks(hsv)

    def show_own(self, color: str) -> None:
        """Show the colour (ARGB; '' no colour: the sliders at their start) by the sliders of an own colour (shown)."""
        hsv = Hsv.of(color) if color else Hsv(0, 0, 0)
        for name, value in asdict(hsv).items():
            self.find(name, Slider).value = value
        self.show_tracks(hsv)

    def show_tracks(self, hsv: Hsv) -> None:
        """
        Tint the tracks of the saturation and the brightness by the colour: its grey, its full colour; its black, its colour of full
        brightness.
        """
        self.setProperty('saturation_low', evolve(hsv, saturation=0).color())
        self.setProperty('saturation_high', evolve(hsv, saturation=100).color())
        self.setProperty('brightness_low', evolve(hsv, brightness=0).color())
        self.setProperty('brightness_high', evolve(hsv, brightness=100).color())

    def show_opacity(self, color: str) -> None:
        """
        Show the opacity of the colour (ARGB) by the sliders (a value off the steps of one: its knob at the nearest one, its own text), its
        alpha exactly the one of the colours chosen from now (till a slider moves).
        """
        self.alpha = color[:2].upper()
        for name in self.OPACITY_SLIDERS:
            self.find(name, Slider).value = opacity_of(color)

    def with_alpha(self, color: str) -> str:
        """Return the colour (`FFRRGGBB`) with the alpha of the opacity sliders (a colour with its transparency, else as it is; '' none)."""
        return f'{self.alpha}{color[2:]}' if self.keeps_alpha and color else color

    def on_buttons_old_clicked(self) -> None:
        """The old colour chosen again."""
        self.choose_shown(self.start)

    def on_buttons_palette_activated(self, index: int) -> None:
        """A palette chosen: shown on the cell of the current colour (an own colour shown: back to the palette)."""
        if 0 <= index < len(self.palettes):
            self.current_palette = index
            self.show_palette_mode()

    def on_buttons_default_clicked(self) -> None:
        """The default colour chosen: the colour shown for it (its opacity by the slider)."""
        self.choose_shown('')

    def on_buttons_own_clicked(self) -> None:
        """Own color: the sliders of the current colour, the focus on the first one; Palette (an own colour shown): back to the palette."""
        if self.own:
            self.show_palette_mode()
        else:
            self.show_own_mode()

    def on_buttons_close_clicked(self) -> None:
        """Close: the colour of now is the result."""
        self.committed = True
        self.close()

    def on_code_clicked(self) -> None:
        """The code of an own colour: typed."""
        self.custom_color()

    def show_own_mode(self) -> None:
        """Show an own colour: its sliders of the current colour, the focus on the first one."""
        self.own = True
        self.setProperty('own_color', 'true')
        self.show_own(self.choice)
        self.show_own_button()
        self.set_focus_shown(self.find(self.OWN_SLIDERS[0]).id)  # shown by the window property `own_color`

    def show_palette_mode(self) -> None:
        """Show the colors of the current palette (on the cell of the current colour) instead of an own colour."""
        self.own = False
        self.setProperty('own_color', '')
        self.show_palette()
        self.show_own_button()

    def show_own_button(self) -> None:
        """Name the button of the modes by the one it goes to: Own color (the colors shown), Palette (an own colour shown)."""
        self.find('buttons.own', PushButton).text = L(30783, 'Palette') if self.own else L(30109, 'Own color')

    def show_palette(self) -> None:
        """Show the current palette: its name, the current colour, its colors on the cell of the current colour (`show_chosen()`)."""
        palette = self.palettes[self.current_palette]
        self.setProperty('current_palette', palette.name)
        self.find('buttons.palette', ComboBox).current_index = self.current_palette
        self.set_current_choice(self.value)
        self.find('colors', PanelView).rows = palette.colors
        self.show_chosen()

    def show_chosen(self) -> None:
        """
        Make the cell of the current colour (opaque) the current one of the colors: the current cell if it has the colour, else the first
        one with it, else the nearest one (`nearest_color()`); marked (the window property `chosen_in_palette`) only if it has the colour.
        No colour: none marked, the current cell kept (none yet: the first one).
        """
        colors = self.find('colors', PanelView)
        rows, chosen = colors.rows, self.choice[2:]
        if not self.choice:
            if not 0 <= colors.current < len(rows):
                colors.current = 0 if rows else -1
            self.setProperty('chosen_in_palette', '')
            return
        if not 0 <= colors.current < len(rows) or rows[colors.current][2:] != chosen:
            colors.current = nearest_color(self.choice, rows)  # -1: no colors yet (the window not shown)
        self.setProperty('chosen_in_palette', 'true' if rows and rows[colors.current][2:] == chosen else '')

    def custom_color(self) -> None:
        """
        Type an own colour (hex; Kodi's keyboard has no length limit) - a colour with its transparency: `AARRGGBB` (its alpha by the opacity
        sliders) or `RRGGBB` (the current alpha kept), the current colour to edit all of it; opaque: `RRGGBB` (`AARRGGBB`: its alpha cut):
        chosen, shown by the sliders of an own colour; no code (a text of no hex colour) told, nothing typed: no change.
        """
        if self.keeps_alpha:
            title = L(30786, 'Type your own colour: AARRGGBB or RRGGBB (hex)')
        else:
            title = L(30779, 'Type your own colour: RRGGBB (hex)')
        kb = keyboard(self.edit_code(self.choice), title)
        kb.doModal()
        if not kb.isConfirmed() or not (text := kb.getText().strip()):
            return
        if not (typed := self.rx_color.fullmatch(text)):
            from ..ff.ui import ui
            ui.notify(self.title(), L(30787, 'Not a colour code: {code}', code=text), error=True)
            return
        rgb = typed['rgb'].upper()
        if typed['alpha'] and self.keeps_alpha:
            self.show_opacity(f'{typed["alpha"]}{rgb}')
        self.choose(self.with_alpha(f'FF{rgb}'))
        if self.own:
            self.show_own(self.choice)

    def set_current_choice(self, color: str) -> None:
        """
        Show the colour ('' the default one) as the new one (with its transparency: the alpha of the slider; opaque: its gradient), its
        code (the field of an own colour); no colour: all of them empty (the samples not drawn).
        """
        self.choice = self.with_alpha(self.shown(color))
        self.setProperty('current_choice', self.choice)
        self.setProperty('current_code', self.code(self.choice))
        self.setProperty('current_color', f'FF{self.choice[2:]}' if self.choice else '')
        self.find('code', PushButton).text = self.edit_code(self.choice)

    def title(self) -> str:
        """Return the title: the heading given, else the one of the picker."""
        return self.heading or L(30105, 'Choose a color')

    def shown(self, color: str) -> str:
        """Return the colour shown for a colour (the default one '': `default`), its digits in upper case; no colour: ''."""
        return (color or self.default or '').upper()

    def code(self, shown: str) -> str:
        """Return the code under the sample of a colour shown (ARGB; `code_of()` by the place; '' no colour: none)."""
        return code_of(shown, self.keeps_alpha) if shown else ''

    def edit_code(self, shown: str) -> str:
        """
        Return the code of a colour shown (ARGB; '' no colour: none) to edit (the field of an own colour, the keyboard): a place with its
        transparency `AARRGGBB`, else `RRGGBB`.
        """
        return shown if self.keeps_alpha else shown[2:]


def pick_color(place: ColorPlace, heading: str = '', *, live: bool = False) -> str | None:
    """
    Open the colour picker of the colour of the place (its transparency, the colour shown for the default one) and write the colour chosen
    once at Close (`live`: at every choice, e.g. a preview - the old colour again at Back). Return it ('' the default one), None if none was
    chosen (Back, no change).
    """
    win = ColorPicker(value=place.get(), default=place.default, alpha=place.alpha, heading=heading)
    if live:
        win.changed.connect(place.set)
    color = win.do_modal()
    del win
    if color is not None and not live:
        place.set(color)
    return color
