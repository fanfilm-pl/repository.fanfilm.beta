"""
The outline of the layout of a generated window (a developer view, `const.dev.outline`): Kodi draws the marks of its layout over
it, so the places the layout gave the controls are seen in Kodi itself, with the animations and the scrolling of the window.

The marks of a control (`_marks()`, the colours: the tokens `dev.outline.*`, no theme changes them), in their drawing order:

- a row / column (`ff:layout`): the fills of the spacing between its children (`ff:spacing`) and of its free space (a spacer
  `<ff:stretch/>`, the room no child takes) - derived from the places of its children, between its margins; a stretched child
  (`ff:stretch`, `ff:policy="expanding"`) filled as a free space too;
- a grid: the frames of the areas of its cells (its holes too: `layout.CELLS_ATTR`);
- a container with margins (`ff:margins`): the inner frame (its margins outside it);
- a grouplist: its frame and the mark of its direction at its end (`more_texture()`);
- the frame of the control: of a widget (its outermost control), else of a grouplist, else of any control;
- with `const.dev.outline.labels` the path of a widget at its top left corner (the font of the role `tiny`);
- the widget selected in the inspector (the window property `ffw.outline.selected`: its path, `select_widget()`): its frame thicker and
  its path (also with no `const.dev.outline.labels`) in the colour `dev.outline.selected`, the path on its background `dev.outline.label`
  as wide as its text (out of a narrow widget; at the right edge of the screen moved left to end there) - a group of its own over the
  window (below), shown with the outline hidden too (a clean window and the one widget selected).

The pass (the last one of `render_xml()`: the layout, the overlays and the moves done) gives every control (also the controls of the
rows of a list, in their item layouts) a group of its marks at its place, the marks in it at their places in the control:

- a control of a plain group (or of the window, of a row of a list) has it in the same parent, after the other children (over them):
  it goes on moving, scrolling and hiding with its parents, its own `visible` conditions and conditional slides copied to it
  (`geometry._kept_conditions()` of the control alone);
- a child of a grouplist (there the group would take a place in the stack) has it over the window at the end of its controls, at its
  absolute place (`geometry`: the grouplist not scrolled, its children shown), with the conditions of the child and of its ancestors
  (as an overlay, `geometry.apply_overlays()`): the scroll of the grouplist and a hidden child before it are not followed;
- the highlight of the selected widget is over the window after all the marks (nothing hides it, its frame and its path together), at its
  absolute place with the conditions of the widget and of its ancestors, as a child of a grouplist: the scroll and the moves of its
  parents (but the conditional slides) are not followed; a widget in the rows of a list has it in every row after its marks (a row has
  no one place over the window).

Every group of the marks (not the highlight of the selected widget) is shown while the Home window property `ffw.outline.hidden` is not
set (`SHOWN`): one state of all the FF windows (a dialog opens in it), the outline seen at once; the key `const.dev.outline.key` in
a window and the inspector (its page, `POST /outline`) hide it and show it again with no new XML (`toggle_outline()`). The Kodi debug
info (`Skin.ToggleDebug`: the window, the mouse, the focused control) follows it: on while an FF window with the outline is shown and
the outline is not hidden, off else - at a toggle, at the open of the first window and at the close of the last one (`track_window()`,
the windows counted in Home).

Without the switch the pass does not run: the windows are the same bytes.
"""

from __future__ import annotations
from copy import deepcopy
from typing import Sequence, TYPE_CHECKING
from xml.etree import ElementTree as ET
from ..ff.threads import Lock
from .geometry import _Box, _controls, _kept_conditions, _window_box
from .gui import focus_texture, more_texture
from .layout import CELLS_ATTR, LIST_LAYOUTS, _attr_int, _margins
from .skinfonts import NORMAL_FONT, text_metrics, window_fonts
from .style import tokens
from const import const
if TYPE_CHECKING:
    from xbmcgui import Window
    from .base import AbstractWindow
    from .xgui import WidgetEntry

#: The font role of the path of a widget (`const.dev.outline.labels`).
LABEL_STYLE: str = 'tiny'
#: The Home window property which hides the outline of all the FF windows (set: hidden).
HIDDEN_PROPERTY: str = 'ffw.outline.hidden'
#: The condition of the marks: shown while the Home window property `HIDDEN_PROPERTY` is not set.
SHOWN: str = f'String.IsEmpty(Window(Home).Property({HIDDEN_PROPERTY}))'
#: The Home window property set while the outline has turned the Kodi debug info on (Kodi tells no state of `Skin.ToggleDebug`, global).
DEBUG_PROPERTY: str = 'ffw.outline.debug'
#: The Home window property of the number of the shown FF windows with the outline (of all the interpreters).
WINDOWS_PROPERTY: str = 'ffw.outline.windows'
#: The lock of the count of the windows (`track_window()`: the window threads of the interpreter).
_lock: Lock = Lock()
#: The window property of the path of the widget selected in the inspector (its marks highlighted; one window, its own selection).
SELECTED_PROPERTY: str = 'ffw.outline.selected'


def _place(elem: ET.Element, box: _Box) -> None:
    """Set the place of the control in its parent (the position and the size, rounded)."""
    for tag, value in (('left', box.x), ('top', box.y), ('width', box.width), ('height', box.height)):
        ET.SubElement(elem, tag).text = str(round(value))


def _frame(box: _Box, color: str) -> ET.Element:
    """Return the frame of the box in the colour (a square outline with no fill, `focus_texture()`)."""
    image = focus_texture()
    frame = ET.Element('control', type='image')
    _place(frame, box)
    ET.SubElement(frame, 'texture', border=image.border, infill='false', colordiffuse=color).text = image.name
    return frame


def _fill(box: _Box, color: str) -> ET.Element:
    """Return the fill of the box in the colour."""
    fill = ET.Element('control', type='image')
    _place(fill, box)
    ET.SubElement(fill, 'texture', colordiffuse=color).text = 'white.png'
    return fill


def _label(box: _Box, path: str, color: str) -> ET.Element:
    """Return the path of a widget at the top left corner of the box, cut to its width, in the colour (the font role `LABEL_STYLE`, the shadow of the style)."""
    label = ET.Element('control', type='label')
    _place(label, _Box(box.x, box.y, box.width, text_metrics(LABEL_STYLE)[1]))
    ET.SubElement(label, 'font').text = window_fonts()[1].get(LABEL_STYLE, NORMAL_FONT)
    ET.SubElement(label, 'textcolor').text = color
    ET.SubElement(label, 'shadowcolor').text = tokens().color.shadow
    ET.SubElement(label, 'label').text = path
    return label


def _selected(place: _Box, path: str, room: float) -> ET.Element:
    """
    Return the highlight of the widget of the place and the path, shown while the inspector has it selected (`SELECTED_PROPERTY`; the outline
    hidden too): its frame of a double pen (`metric.focus`) and its path, in the colour `dev.outline.selected`, the path on its background
    `dev.outline.label` as wide as its text (`space.xs` on its sides) - `room`: from the left of the place to the right edge of the screen
    (of the row of a list), a wider path moved left to end there.
    """
    color, pen = tokens().dev.outline.selected, tokens().metric.focus
    width, height = text_metrics(LABEL_STYLE)
    pad = tokens().space.xs
    wide = width(path) + 2 * pad
    box = _Box(0, 0, place.width, place.height)
    group = ET.Element('control', type='group')
    _place(group, place)
    group.append(_frame(box, color))
    group.append(_frame(_Box(pen, pen, max(0, box.width - 2 * pen), max(0, box.height - 2 * pen)), color))
    tag = ET.SubElement(group, 'control', type='group')
    _place(tag, _Box(min(0, room - wide), 0, wide, height))
    tag.append(_fill(_Box(0, 0, wide, height), tokens().dev.outline.label))
    tag.append(_label(_Box(pad, 0, wide - pad, height), path, color))
    ET.SubElement(group, 'visible').text = f'String.IsEqual(Window.Property({SELECTED_PROPERTY}),{path})'
    return group


def _inner(elem: ET.Element, box: _Box) -> _Box:
    """Return the room of a laid out container of the box between its margins (`ff:margins`), in the box."""
    margins = _margins(elem)
    return _Box(margins.left, margins.top, box.width - margins.left - margins.right, box.height - margins.top - margins.bottom)


def _free_spaces(elem: ET.Element, box: _Box, children: Sequence[_Box]) -> list[ET.Element]:
    """
    Return the fills of a row / column of the box (its laid out children, the document order): the spacing before every child but the
    first (`ff:spacing`), the rest of the room between the margins no child takes (a spacer, a room left), across between the margins.
    """
    row = elem.get('{ff}layout') == 'row'
    spacing = _attr_int(elem, 'spacing', 0)
    room = _inner(elem, box)

    def fill(start: float, end: float, color: str) -> ET.Element:
        """Return the fill of the part of the main axis (in the box) across the room between the margins."""
        if row:
            return _fill(_Box(start, room.y, end - start, room.height), color)
        return _fill(_Box(room.x, start, room.width, end - start), color)

    fills: list[ET.Element] = []
    pos = room.x if row else room.y
    for n, child in enumerate(children):
        start, size = (child.x - box.x, child.width) if row else (child.y - box.y, child.height)
        gap = spacing if n else 0
        if start - gap > pos:
            fills.append(fill(pos, start - gap, tokens().dev.outline.stretch))
        if gap and start > pos:
            fills.append(fill(max(pos, start - gap), start, tokens().dev.outline.spacing))
        pos = max(pos, start + size)
    if (end := (room.x + room.width) if row else (room.y + room.height)) > pos:
        fills.append(fill(pos, end, tokens().dev.outline.stretch))
    return fills


def _marks(elem: ET.Element, box: _Box, children: Sequence[_Box], widget: str | None) -> list[ET.Element]:
    """
    Return the marks of a control of the box, at their places in it (the module docstring); `children` - the boxes of its child
    controls, `widget` - the path of the widget it is the outermost control of (None: none).
    """
    marks: list[ET.Element] = []
    whole = _Box(0, 0, box.width, box.height)
    layout = elem.get('{ff}layout')
    if layout in ('row', 'column'):
        marks.extend(_free_spaces(elem, box, children))
    if _attr_int(elem, 'stretch', 0) or elem.get('{ff}policy') == 'expanding':
        marks.append(_fill(whole, tokens().dev.outline.stretch))
    for area in (elem.get(CELLS_ATTR) or '').split():
        left, top, width, height = (float(v) for v in area.split(','))
        marks.append(_frame(_Box(left, top, width, height), tokens().dev.outline.cell))
    if layout is not None and (inner := _inner(elem, box)) != whole:
        marks.append(_frame(inner, tokens().dev.outline.margin))
    grouplist = elem.get('type') == 'grouplist'
    if grouplist:
        vertical = (elem.findtext('orientation') or 'vertical').strip() != 'horizontal'
        image, across = more_texture('S' if vertical else 'E'), tokens().space.s  # the size of the marks of more rows (`more_marks`)
        mark = ET.Element('control', type='image')
        if vertical:  # in the middle of its bottom edge, pointing down
            _place(mark, _Box((box.width - 2 * across) / 2, box.height - across, 2 * across, across))
        else:  # in the middle of its right edge, pointing right
            _place(mark, _Box(box.width - across, (box.height - 2 * across) / 2, across, 2 * across))
        ET.SubElement(mark, 'texture', flipx=str(image.flipx).lower(), flipy=str(image.flipy).lower(),
                      colordiffuse=tokens().dev.outline.grouplist).text = image.name
        marks.append(mark)
    frame = tokens().dev.outline.widget if widget is not None else tokens().dev.outline.grouplist if grouplist else tokens().dev.outline.control
    marks.append(_frame(whole, frame))
    if widget is not None and const.dev.outline.labels:
        marks.append(_label(whole, widget, tokens().dev.outline.widget))
    return marks


def apply_outline(root: ET.Element, entries: Sequence[WidgetEntry]) -> None:
    """
    Add the outline of the layout to the generated window (after all the passes; `entries`: its widgets): the group of the marks of every
    control, in its parent after its children - in a grouplist: at the end of the window controls, at its absolute place; the highlights of
    the widgets after all of them (the module docstring).
    """
    controls = root.find('controls')
    if controls is None:
        return
    window = _window_box(root)
    spaces: dict[ET.Element, _Box] = {controls: window}  # the parents of no box of their own: the window, the item layouts of the lists
    boxes = dict(_controls(controls, window, None))
    rows: dict[ET.Element, float] = {}  # the controls of the rows of the lists (their boxes in the row): the widths of their rows
    for lst in list(boxes):
        for layout in (node for node in lst if node.tag in LIST_LAYOUTS):  # a row at the start of its list (its parts: in the row)
            spaces[layout] = space = _Box(0, 0, float(layout.get('width') or boxes[lst].width), float(layout.get('height') or boxes[lst].height))
            row = dict(_controls(layout, space, None))
            boxes.update(row)
            rows.update(dict.fromkeys(row, space.width))
    parents = {child: parent for parent in root.iter() for child in parent}
    by_id = {str(cid): entry.path for entry in entries for cid in entry.ids.values()}  # the controls of the widgets
    paths: dict[ET.Element, str] = {}  # the first control of every widget: its outermost one (the document order)
    for elem in boxes:
        if (path := by_id.get(elem.get('id') or '')) is not None and path not in paths.values():
            paths[elem] = path
    highlights: list[ET.Element] = []  # over the window after all the marks
    for elem, box in list(boxes.items()):
        parent = parents[elem]
        absolute = _Box(box.x - window.x, box.y - window.y, box.width, box.height)  # over the window, the conditions of its ancestors too
        if parent.get('type') == 'grouplist':
            place, kept, target = absolute, _kept_conditions(elem, parents), controls
        else:  # in its parent after its children
            base = boxes.get(parent) or spaces[parent]
            place = _Box(box.x - base.x, box.y - base.y, box.width, box.height)
            kept, target = _kept_conditions(elem, {}), parent
        path = paths.get(elem)
        group = ET.Element('control', type='group')
        _place(group, place)
        group.extend(_marks(elem, box, [boxes[child] for child in elem if child in boxes], path))
        group.extend(kept)
        ET.SubElement(group, 'visible').text = SHOWN
        target.append(group)
        if path is not None and elem in rows:  # the highlight of a widget of a row over its marks in every row (its path to the end of the row)
            highlight = _selected(place, path, rows[elem] - box.x)
            highlight.extend(deepcopy(cond) for cond in kept)
            target.append(highlight)
        elif path is not None:  # the highlight of a widget over the window, the outline hidden too
            highlight = _selected(absolute, path, window.width - box.x)  # its path to the right edge of the screen
            highlight.extend(_kept_conditions(elem, parents))
            highlights.append(highlight)
    controls.extend(highlights)


def _follow_debug(home: Window) -> None:
    """
    Turn the Kodi debug info on while an FF window with the outline is shown and the outline is not hidden, off else (`Skin.ToggleDebug`,
    only the one the outline has turned on: Kodi tells no state of it).
    """
    from xbmc import executebuiltin
    want = not home.getProperty(HIDDEN_PROPERTY) and int(home.getProperty(WINDOWS_PROPERTY) or 0) > 0
    if want != bool(home.getProperty(DEBUG_PROPERTY)):
        home.setProperty(DEBUG_PROPERTY, 'true' if want else '')
        executebuiltin('Skin.ToggleDebug')


def outline_shown() -> bool:
    """Return True if the outline of the FF windows is shown (not hidden)."""
    from ..ff.control import window as home_window
    return not home_window().getProperty(HIDDEN_PROPERTY)


def toggle_outline() -> bool:
    """
    Hide the shown outline of all the FF windows, show the hidden one (the Home property `HIDDEN_PROPERTY`, no new XML), the Kodi debug info
    with it. Return True if shown.
    """
    from ..ff.control import window as home_window
    home = home_window()
    shown = bool(home.getProperty(HIDDEN_PROPERTY))
    home.setProperty(HIDDEN_PROPERTY, '' if shown else 'true')
    _follow_debug(home)
    return shown


def select_widget(win: AbstractWindow, path: str) -> None:
    """Highlight the widget of the path in the outline of the window ('' none; no widget of the path: `KeyError`)."""
    if path:
        win.find(path)
    win.setProperty(SELECTED_PROPERTY, path)  # type: ignore[attr-defined]


def track_window(shown: bool) -> None:
    """
    An FF window with the outline is shown (or closed): count it in Home, the Kodi debug info follows (on with the first one shown, off
    after the last one closed). Nothing at the Kodi exit or the stop of the script (Kodi keeps neither the properties nor the debug info).
    """
    from ..ff.control import window as home_window
    from ..ff.kotools import kodi_abort_event
    from ..info import script_aborted
    if script_aborted() or kodi_abort_event.is_set():  # ponytail: a window still open then keeps its count; a next toggle is still right
        return
    with _lock:  # ponytail: the interpreters race on the count of Home (their windows open / close at the same moment: never seen)
        home = home_window()
        home.setProperty(WINDOWS_PROPERTY, str(max(0, int(home.getProperty(WINDOWS_PROPERTY) or 0) + (1 if shown else -1))))
        _follow_debug(home)
