
from __future__ import annotations
from typing import Any, List, Mapping, Sequence, Iterable, Iterator, ClassVar, Callable, cast, overload, TYPE_CHECKING
from typing_extensions import LiteralString, Literal, TypeAlias
from pathlib import Path
# from lxml import etree as ET
import xml.etree.ElementTree as ET
from inspect import Signature, Parameter
import ast
import re
from functools import lru_cache, partial
from textwrap import dedent
from types import BuiltinMethodType, CodeType, MappingProxyType, MethodType, ModuleType
from sys import version_info
import builtins
from attrs import define, frozen, field
from ..ff.format import FormatField, FormatLiteral, FormatNode, FormatNodes, SafeFormatter, Sections, fparser
from ..ff.types import Args, KwArgs, mk_bool
from ..ff.tricks import IterableItemInfo, MissingType, MISSING, DEFAULT_FUNCTIONS, DEFAULT_NAMES
from ..ff.logs import fflog
from ..kolang import L
from .gui import (GEOM_TAGS, SEPARATOR_BITS, TEXTURE_TAGS, THEME_IMAGE_TAGS, TOGGLE, TOGGLE_TIME, bevel_images, box_edge, box_texture, filter_shown, focus_texture,
                  group_alignment, group_band, line_height, more_texture, popup_edge, popup_fill, popup_texture, separator_zoom, shape_fill, switch_icon_height,
                  switch_icon_width, tab_offset, tab_texture, tag_room, decor_images, texture_border, texture_corners, texture_inset, toggle_vars)
from .skinfonts import symbol
from .style import FOCUSED_ICON, FRAME_SHAPES, NO_TINT, SURFACES, Style, alpha, focused_image_variant, surface, tokens
from .bindings import Binding, BindingKind, RX_BINDING_FIELD, free_names
from .. import FAKE
if TYPE_CHECKING:
    from .widgets import Widget
from const import const

#: The attribute of a parsed template element: its position in the source (`path:line`), never in the output.
SRC_ATTR: str = '{ff}src'
#: The attribute of the first output control of a widget use: the path of the widget (its outermost control; the sizes the layout gave
#: it, `XmlManager.layout_sizes()`), never in the output.
USE_ATTR: str = '{ff}use'
#: The attribute of the outermost control of a widget use: the geometry tags of the use its layout gives it (`XmlManager.layout_tags()`,
#: read by its template: `use_value()`), space separated - no size hint of its content there (`layout.LayoutEngine.hints()`).
SIZED_ATTR: str = '{ff}sized'
#: The attribute of an output texture element made by a widget of a theme (its add-on ID; never in the output): `gui.drop_remote_textures()`.
THEME_ATTR: str = '{ff}theme'
#: The namespace prefixes of the templates: the URI is the prefix (`{ff}if`, `{gui}push_button`); the parser needs no declaration,
#: the widget sources declare them in the root (`xmlns:ff="ff" xmlns:gui="gui"`: well-formed XML for editors, kolang).
TEMPLATE_NAMESPACES: tuple[str, ...] = ('ff', 'gui')
#: The attributes of a widget use which are not its parameters (`name`: its name in the window, a part of its path).
WIDGET_ATTRS: tuple[str, ...] = ('name',)
#: The attributes of a use of a computed widget `<gui:widget>` which are not its parameters: the widget, its computed parameters.
COMPUTED_WIDGET_ATTRS: tuple[str, ...] = ('type', 'args')
#: The names of a widget body besides its parameters (no parameter of these names): its control ID, its path.
WIDGET_NAMES: tuple[str, ...] = ('name', 'id', 'path')
#: The window IDs of Kodi (xbmc/guilib/WindowIDs.h of K21 and K22: WINDOW_HOME 10000 .. WINDOW_ADDON_END 14099; xbmcgui has no
#: constants of them). No control ID of a window is one of them: a builtin addressed by a control ID (`SetFocus(<id>)`) reaches
#: the window of that ID too, under a dialog (Kodi `CGUIWindowManager::SendMessage`) - `SetFocus(10000)` hangs Kodi on WINDOW_HOME.
KODI_WINDOW_IDS: range = range(10000, 14100)
#: The first control ID given to the widgets of a window (the IDs written by hand are below): a round number above `KODI_WINDOW_IDS`.
WIDGET_IDS: int = 20000
#: The content tags of `<ff:content tags="geometry"/>`: the position, the size, the visibility, the animations of a control.
CONTENT_GEOMETRY: frozenset[str] = frozenset({*GEOM_TAGS, 'posx', 'posy', 'visible', 'animation'})
#: The content tags of `<ff:content tags="anchored"/>`: the uses of the widgets anchored to the edge of their host (a frame draws them on
#: its edge, not inside its padding).
CONTENT_ANCHORED: frozenset[str] = frozenset({'{gui}tag', '{gui}edge_mark'})
#: The content place of the rows of a list widget (`<ff:delegate>`): `<ff:content name="row">` of the use draws a row.
DELEGATE_CONTENT: str = 'row'
#: The widgets which are frames (also the bases of their forms: a group box): their nesting is their level (`frame_level()`); a tab widget
#: is a frame of its pages (its pane: a panel at the top).
FRAME_WIDGETS: frozenset[str] = frozenset({'frame', 'tab_widget'})
#: The frame of a window (level 0, the window itself): its own widgets and the ones of its content are named in the window (its use
#: is no part of their paths: `close`, not `window_frame1.close`).
WINDOW_FRAME_WIDGET: str = 'window_frame'
#: A template field of a style token alone (`{tokens.color.text}`, not in an expression): `fold_tokens()`.
RX_TOKEN_FIELD: re.Pattern[bytes] = re.compile(rb'\{tokens\.([a-z.]+)\}')
#: A control of a widget by its name in the widget template: `id_of('group')`.
RX_ID_OF: re.Pattern[str] = re.compile(r'''\bid_of\(['"](\w+)['"]\)''')
#: The control elements (`<ff:if if="…">`, also a bare tag of `<ff:statement>`: `<if if="…">`) -> their attribute of an expression.
CODE_ATTRS: dict[str, str] = {'if': 'if', 'elif': 'if', 'else': 'if', 'while': 'if', 'for': 'in', 'set': 'value', 'breakpoint': 'if'}
#: The name of the guard of the calls of the code of a theme (`theme_code()`, `theme_call()`): in its namespace only (a name of a theme never
#: starts with `_`: no template value hides it).
THEME_CALL: str = '__ff_call__'
#: The Python builtins of the code of a theme: the ones computing a value (the code of FF has all of them; no `open`, `getattr`, `eval` …).
THEME_BUILTINS: frozenset[str] = frozenset({'abs', 'all', 'any', 'bool', 'dict', 'divmod', 'enumerate', 'filter', 'float', 'frozenset', 'int',
                                            'isinstance', 'len', 'list', 'map', 'max', 'min', 'range', 'repr', 'reversed', 'round', 'set',
                                            'sorted', 'str', 'sum', 'tuple', 'zip'})
#: The template names of FF the code of a theme may not call (`template_names()`): they write (the log, a dict in place).
THEME_WRITERS: frozenset[str] = frozenset({'fflog', 'dict_update', 'dict_update_r'})
#: The prefix of the class methods of a widget class giving the data of its templates (`widget_class().template_tree(…)`).
TEMPLATE_METHOD: str = 'template_'
#: The package of the windows: the frozen records of its modules are the template data (`surface(1).forced(…)`, `t.info(…)`).
WINDOWS_PACKAGE: str = __name__.rpartition('.')[0]
#: The attributes the code of a theme may not read: the private ones, the internals of Python (`__class__`), the frames and the code of
#: the generators, coroutines, tracebacks and functions (`gi_frame`, `f_globals` …: the namespaces of FF).
RX_THEME_HIDDEN: re.Pattern[str] = re.compile(r'_|(?:gi|cr|ag|f|tb|co|func)_')
#: The syntax of the code of a theme (`theme_code()`): names, attributes, subscripts, literals and displays, operators, comparisons,
#: `if … else`, f-strings, comprehensions, `:=` (the templates of FF use it), calls (through the guard `THEME_CALL`). No lambda, no
#: statement (`<ff:vars>`), no change of an attribute or an item (a comprehension target).
THEME_SYNTAX: tuple[type[ast.AST], ...] = (
    ast.Expression, ast.Constant, ast.Name, ast.Attribute, ast.Subscript, ast.Slice, ast.Starred, ast.Tuple, ast.List, ast.Set, ast.Dict,
    ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare, ast.IfExp, ast.Call, ast.keyword, ast.JoinedStr, ast.FormattedValue, ast.NamedExpr,
    ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp, ast.comprehension, ast.expr_context, ast.operator, ast.unaryop, ast.boolop,
    ast.cmpop,
    *((ast.Index, ast.ExtSlice) if version_info < (3, 9) else ()),  # the subscripts of Python 3.8
)
#: The methods of the values the code of a theme may call: all of an immutable value (no `format`, `format_map`: their fields read any
#: attribute, `'{0.__class__}'`), of a mutable container the ones its immutable counterpart has too (no change in place).
THEME_VALUE_METHODS: dict[type, frozenset[str]] = {
    kind: frozenset(name for name in dir(kind) if name[0] != '_' and name not in ('format', 'format_map') and hasattr(like, name))
    for kind, like in ((str, str), (int, int), (float, float), (tuple, tuple), (frozenset, frozenset), (list, tuple), (set, frozenset),
                       (dict, MappingProxyType))
}
#: The builtins of the code of a theme (`THEME_BUILTINS`).
_theme_builtins: dict[str, Any] = {name: vars(builtins)[name] for name in THEME_BUILTINS}


@frozen(kw_only=True)
class WidgetEntry:
    """A widget of a generated window (the manifest, kept with the XML): where it is and the control IDs it got."""

    #: The path in the window: the names of the widget and its parents (`tabs.accounts.add`).
    path: str
    #: The widget (`push_button`) and its bases (`abstract_button`, ...), the widget first.
    types: tuple[str, ...]
    #: The families of `types`: the modules of their declarations (`resources/skins/widgets/<family>.xml`, the Python
    #: classes in `lib/windows/widgets/<family>.py`).
    families: tuple[str, ...]
    #: The control IDs by their names in the widget (`id_of(name)`); '' is the widget control (`id`).
    ids: dict[str, int]
    #: The position of the use in the source (`path:line`).
    src: str = ''
    #: The roles of the rows of a list widget (its delegate bindings `{=row.…}`): list item property -> binding.
    roles: dict[str, Binding] = field(factory=dict)
    #: The template data of the widget for its class (`widget_data(name=value)`; picklable: the manifest is cached with the XML).
    data: dict[str, Any] = field(factory=dict)
    #: It lies in a row of a list (`widget_place()` row): its controls are the ones of the list item layouts, none of the window's.
    row: bool = False

    @property
    def id(self) -> int:
        """Return the control ID of the widget."""
        return self.ids['']


@define(kw_only=True)
class XmlContent:
    """The content of a widget use: its child elements and the frame they belong to (the caller's one)."""

    #: The child elements of the use (`<ff:content name="...">` among them fill the named places).
    elems: list[ET.Element]
    #: The frame of the use (the content is the caller's template), None: the current one.
    frame: XmlCallFrame | None


@frozen(kw_only=True)
class UseItem:
    """An element of a place of a widget use read by its template (`use_items()`): a static item, a separator ..."""

    #: The tag (`item`, `separator`).
    tag: str
    #: The attributes, formatted.
    attrs: Mapping[str, str]
    #: The text, formatted and stripped.
    text: str


#: Where a widget lies (`XmlManager.widget_place()`): in a row of a list, a child of a grouplist, any other place.
WidgetPlace: TypeAlias = Literal['row', 'grouplist', 'fixed']


@define(kw_only=True)
class _WidgetUse:
    """A widget being generated: its manifest entry, the counters of its anonymous children."""

    #: The manifest entry.
    entry: WidgetEntry
    #: The anonymous children by their widget (`push_button1`, `push_button2` ...).
    counts: dict[str, int] = field(factory=dict)
    #: The level of a frame (`frame_level()`: known when its template asks for it), None: no frame or not asked yet.
    level: int | None = None
    #: The content of the use (its child elements and its frame), None: not known yet.
    content: XmlContent | None = None
    #: The bands of its edges its own parts take (the head and the foot of a window frame: `edge_bands()`), by the edge (`top` ...).
    edges: dict[str, int] = field(factory=dict)
    #: The geometry tags the layout of its parent gives it (`XmlManager.layout_tags()`): a missing one is a size of the layout.
    layout_tags: frozenset[str] = frozenset()
    #: The template attributes of the use (its layout in the parent: `ff:stretch` ...) and its path (`USE_ATTR`) for its outermost control:
    #: set on it when it is made (`take_outermost()`; the widgets in it see the layout of their parent), None: set.
    attrs: dict[str, str] | None = None
    #: Its outermost control (its first one), None: not made yet.
    outermost: ET.Element | None = None


class TemplateError(ValueError):
    """An error of a template: its cause, the position of the element and the includes leading to it (the outermost first)."""

    def __init__(self, message: str, *, src: str = '', chain: Sequence[str] = ()) -> None:
        #: The cause.
        self.message: str = message
        #: The position of the element (`path:line`).
        self.src: str = src
        #: The positions of the includes leading to the element, the outermost first.
        self.chain: tuple[str, ...] = tuple(chain)
        #: The widget of a theme replacing one of FF (`<theme>:<name>`) the error arose in, '' none: `gui.render_xml()` generates the window
        #: again with the one of FF.
        self.widget: str = ''
        super().__init__(message)

    def locate(self, src: str, chain: Sequence[str]) -> None:
        """Set the position of the error (only the first, the innermost one counts)."""
        if not self.src:
            self.src, self.chain = src, tuple(chain)

    def __str__(self) -> str:
        """Return the cause and the positions like a traceback (the innermost last)."""
        return '\n'.join((self.message, *(f'  at {pos}' for pos in (*self.chain, self.src) if pos)))


def fold_tokens(source: bytes) -> bytes:
    """
    Return the template source with its token fields (`RX_TOKEN_FIELD`) replaced by the values of the style: a constant of the
    generation (the style is in the stamp of the generated windows) costs what a literal does. An unknown token stays a field
    (its error at the generation, with its position); the tokens in expressions are read at the generation (`template_names()`).
    """
    values = tokens().values

    def value(match: re.Match[bytes]) -> bytes:
        """Return the value of the token of the field (the field itself: an unknown token, an escaped text `{{tokens.…}}`)."""
        found = values.get(match.group(1).decode('ascii'))
        if found is None or source[match.start() - 1:match.start()] == b'{':
            return match.group(0)
        return str(found).encode('utf-8')

    return RX_TOKEN_FIELD.sub(value, source)


@frozen(kw_only=True)
class ParsedTemplate:
    """A template parsed for the generation (`parse_template()`), kept in the interpreter."""

    #: The source as read (a changed file is parsed again).
    source: bytes
    #: The stamp of the style of the folded tokens (`Style.stamp`).
    style: str
    #: The parsed tree: shared by the generations, which never change it (they make new elements).
    root: ET.Element


#: The templates parsed for the generation: (path, root) -> the parsed template. A worker or a warm interpreter generating
#: several windows parses the widget families once (on a Pi ~90 ms each generation).
_parsed: dict[tuple[Path, Path | None], ParsedTemplate] = {}


def source_comment(src: str, *names: str) -> ET.Element | None:
    """
    Return the comment of the source of the output that follows it (the position `SRC_ATTR` of the source, the name of the widget or
    the define, the path of the use) in the developer mode (`const.dev.outline`: the generated XML read by people), else None: Kodi reads
    no comment and the output is a quarter smaller without them and the indents (`gui.strip_whitespace()`).
    """
    if not const.dev.outline.enabled:
        return None
    return ET.Comment(f' {src} {" ".join(names)} ')


def parse_template(path: Path, *, root: Path | None = None, as_written: bool = False) -> ET.Element:
    """
    Parse a template keeping the position of every element (`SRC_ATTR`: the path relative to `root`, the line).
    The prefixes `ff:` and `gui:` (`TEMPLATE_NAMESPACES`) are known without their declaration (the sources declare them in the
    root for editors and kolang, on the line of the root tag: the positions stay), the comments of the source are dropped, the
    token fields replaced by their values (`fold_tokens()`). `as_written`: the source as it is written (the catalog of the widgets):
    the comments kept (`ET.Comment` with their positions), the token fields not folded.
    The tree for the generation is kept (`_parsed`): the same source and style give the same tree again, never to be changed.
    """
    data = path.read_bytes()
    style = tokens().stamp
    if not as_written and (parsed := _parsed.get((path, root))) is not None and parsed.source == data and parsed.style == style:
        return parsed.root
    from xml.parsers import expat
    name = str(path.relative_to(root)) if root is not None else path.name
    builder = ET.TreeBuilder(insert_comments=as_written)
    parser = expat.ParserCreate()

    def comment(text: str) -> None:
        """Keep a comment with its position (inside the root element only)."""
        if (elem := builder.comment(text)) is not None:
            elem.set(SRC_ATTR, f'{name}:{parser.CurrentLineNumber}')

    def qname(tag: str) -> str:
        """Return the ElementTree name of a prefixed name (`ff:if` -> `{ff}if`)."""
        prefix, sep, local = tag.partition(':')
        return f'{{{prefix}}}{local}' if sep and prefix in TEMPLATE_NAMESPACES else tag

    def start(tag: str, attrs: dict[str, str]) -> None:
        """Start an element with its position."""
        attrib = {qname(key): value for key, value in attrs.items() if key != 'xmlns' and not key.startswith('xmlns:')}
        attrib[SRC_ATTR] = f'{name}:{parser.CurrentLineNumber}'
        builder.start(qname(tag), attrib)

    parser.StartElementHandler = start
    parser.EndElementHandler = lambda tag: builder.end(qname(tag))
    parser.CharacterDataHandler = builder.data
    if as_written:
        parser.CommentHandler = comment
    try:
        parser.Parse(data if as_written else fold_tokens(data), True)
    except expat.ExpatError as exc:
        raise TemplateError(f'XML error: {expat.ErrorString(exc.code)}', src=f'{name}:{exc.lineno}') from exc
    tree = builder.close()
    if not as_written:
        _parsed[path, root] = ParsedTemplate(source=data, style=style, root=tree)
    return tree


def get_signature(func: str) -> Signature | None:
    try:
        a = ast.parse(func)  # parse
    except SyntaxError:
        return None
    if not a.body:
        return None
    a = a.body[0]  # skip module
    if type(a) is not ast.FunctionDef:
        return None

    def default(expr: ast.expr | None) -> Any:
        if type(expr) is ast.Constant:
            return expr.value
        return Parameter.empty

    params = []
    d = len(a.args.defaults) - len(a.args.posonlyargs) - len(a.args.args)
    for arg in a.args.posonlyargs:
        params.append(Parameter(arg.arg, Parameter.POSITIONAL_ONLY,
                                default=default(None if d < 0 else a.args.defaults[d])))
        d += 1
    for arg in a.args.args:
        params.append(Parameter(arg.arg, Parameter.POSITIONAL_OR_KEYWORD,
                                default=default(None if d < 0 else a.args.defaults[d])))
        d += 1
    if a.args.vararg is not None:
        params.append(Parameter(a.args.vararg.arg, Parameter.VAR_POSITIONAL))
    for arg, df in zip(a.args.kwonlyargs, a.args.kw_defaults):
        params.append(Parameter(arg.arg, Parameter.KEYWORD_ONLY, default=default(df)))
    if a.args.kwarg is not None:
        params.append(Parameter(a.args.kwarg.arg, Parameter.VAR_KEYWORD))
    return Signature(params)


@frozen
class LoopInfo(IterableItemInfo):
    """Information about current loop iteration. info.last is not set for infinite loops."""

    var: str | None
    depth: int
    _template: XmlTemplate = field(kw_only=True, alias='template', repr=False)

    @property
    def parent(self) -> LoopInfo | None:
        if 0 <= self.depth - 1 < len(self._template._loops):
            return self._template._loops[self.depth - 1]
        return None


def loop_iter(iterable, var: str | None, template: XmlTemplate, *, infinite: bool = False) -> Iterator[tuple[LoopInfo, Any]]:
    """s -> (info0, s0), (info1, s1), ..."""
    depth = len(template._loops) - 1
    if infinite:
        for i, item in enumerate(iterable):
            yield LoopInfo(i, False, var=var, depth=depth, template=template), item
        return
    i, it = 0, iter(iterable)
    try:
        prev = next(it)
    except StopIteration:
        return
    while True:
        try:
            item = next(it)
        except StopIteration:
            yield LoopInfo(i, True, var=var, depth=depth, template=template), prev
            return
        yield LoopInfo(i, False, var=var, depth=depth, template=template), prev
        prev = item
        i += 1


@frozen(kw_only=True)
class Info:
    # _template: XmlTemplate = field(alias='template', repr=False)
    _manager: XmlManager = field(alias='manager', repr=False)

    _PERMANENT_OBJECT = True

    def get_frame(self, depth: int = 0) -> XmlCallFrame | None:
        if 0 <= depth < len(self._manager.frames):
            return self._manager.frames[-1 - depth]
        return None

    @property
    def locals(self) -> dict[str, Any]:
        frame = self._manager.current_frame
        assert frame is not None
        return frame.locals

    @property
    def globals(self) -> dict[str, Any]:
        frame = self._manager.current_frame
        assert frame is not None
        return frame.globals

    @property
    def module(self) -> XmlModule:
        frame = self._manager.current_frame
        assert frame is not None
        return frame.module

    @property
    def loop(self) -> LoopInfo | None:
        frame = self._manager.current_frame
        assert frame is not None
        templ = frame.module.xml
        if templ is None:
            return None
        if templ._loops:
            return templ._loops[-1]
        return None


class TextNode(ET.Element):

    def __init__(self, text: str) -> None:
        super().__init__('_')
        self.text = text


class ElementChildren:

    def __init__(self, parent: ET.Element) -> None:
        self.parent: ET.Element = parent
        self.index: int = 0

    def __iter__(self) -> Iterator[ET.Element]:
        return self

    def __next__(self) -> ET.Element:
        if 0 <= self.index < len(self.parent):
            index = self.index
            self.index += 1
            return self.parent[index]
        else:
            raise StopIteration()

    def back(self) -> Iterator[ET.Element]:
        if self.index > 0:
            self.index -= 1
        return self

    def current(self) -> ET.Element | None:
        if 0 <= self.index - 1 < len(self.parent):
            return self.parent[self.index - 1]
        return None

    def current_ff_tag(self, *, bare: bool = False) -> str:
        """Return the `ff:` name of the current element ('' other one), `bare`: also a tag without namespace (`<if>` in `<ff:statement>`)."""
        if 0 <= self.index - 1 < len(self.parent):
            tag = self.parent[self.index - 1].tag or ''
            if tag.startswith('{ff}'):
                return tag.partition('}')[2]
            if bare and '}' not in tag:
                return tag
        return ''


@lru_cache(maxsize=4096)
def compile_code(source: str, mode: Literal['eval', 'exec']) -> CodeType:
    """Compile template code once (the same expressions are evaluated again and again)."""
    return compile(source, '<xgui>', mode)


class _GuardedCalls(ast.NodeTransformer):
    """The calls of the code of a theme through its guard (`THEME_CALL`: `f(x)` -> `__ff_call__(f, x)`)."""

    def visit_Call(self, node: ast.Call) -> ast.Call:
        """Return the call of the guard with the function and the arguments of the call."""
        self.generic_visit(node)
        return ast.copy_location(ast.Call(func=ast.Name(id=THEME_CALL, ctx=ast.Load()), args=[node.func, *node.args], keywords=node.keywords),
                                 node)


@lru_cache(maxsize=4096)
def theme_code(source: str) -> CodeType:
    """
    Compile an expression of a template of a theme once (its namespace: `theme_namespace()`): only its syntax (`THEME_SYNTAX`), no name of
    `_`, no attribute `RX_THEME_HIDDEN`, no call of a writer (`THEME_WRITERS`) or of a builtin not in `THEME_BUILTINS` (`open()`), its calls
    through the guard (`theme_call()`); a construct not allowed: a `TemplateError`.
    """
    tree = ast.parse(source, mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node, THEME_SYNTAX):
            fault = f'{type(node).__name__}'
        elif isinstance(node, ast.Name) and node.id[:1] == '_':
            fault = f'the name {node.id!r}'
        elif isinstance(node, ast.Attribute) and RX_THEME_HIDDEN.match(node.attr):
            fault = f'the attribute {node.attr!r}'
        elif isinstance(node, (ast.Attribute, ast.Subscript)) and not isinstance(node.ctx, ast.Load):
            fault = 'a change of an attribute or an item'
        elif (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
              and (node.func.id in THEME_WRITERS or (node.func.id in vars(builtins) and node.func.id not in THEME_BUILTINS))):
            fault = f'the call of {node.func.id!r}'  # `theme_call()` refuses it too: known before the generation
        else:
            continue
        raise TemplateError(f'Not allowed in a theme: {fault} in {source!r}')
    return compile(ast.fix_missing_locations(_GuardedCalls().visit(tree)), '<theme>', 'eval')


def theme_callable(allowed: Mapping[int, Any], func: Any) -> bool:
    """
    Return True if the code of a theme may call the function: a function FF gives to the templates (`allowed`, by its identity:
    `theme_callables()`), a method of a value (`THEME_VALUE_METHODS`), a method of a frozen record of the windows (the template data:
    `surface(1).forced(…)`), a class method `template_*` of a widget class (`widget_class().template_tag(…)`).
    """
    if id(func) in allowed:
        return True
    if isinstance(func, BuiltinMethodType):
        owner = func.__self__
        return any(isinstance(owner, kind) and func.__name__ in names for kind, names in THEME_VALUE_METHODS.items())
    if isinstance(func, MethodType):
        owner = func.__self__
        cls = owner if isinstance(owner, type) else type(owner)
        # a frozen attrs record (attrs has no public test of it: the name of its setattr; another attrs version - not allowed, never broken)
        if getattr(cls.__setattr__, '__name__', '') == '_frozen_setattrs' and cls.__module__.startswith(f'{WINDOWS_PACKAGE}.'):
            return True
        from .widgets import Widget
        return isinstance(owner, type) and issubclass(owner, Widget) and func.__name__.startswith(TEMPLATE_METHOD)
    return False


def theme_call(allowed: Mapping[int, Any], func: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Any:
    """
    Call the function for the code of a theme (`THEME_CALL`) when it may (`theme_callable()`), its callable arguments too (`map()`,
    the `key` of `sorted()` call them), else a `TemplateError`.
    """
    for value in (func, *args, *kwargs.values()):
        if (value is func or callable(value)) and not theme_callable(allowed, value):
            raise TemplateError(f'A theme may not call {getattr(value, "__qualname__", type(value).__name__)}')
    return func(*args, **kwargs)


def theme_callables(*spaces: Mapping[str, Any]) -> dict[int, Any]:
    """
    Return the functions the code of a theme may call by their identities (`theme_callable()`): the ones of the name spaces given to the
    templates (`spaces`; the functions of a module there: `math.floor`) and `THEME_BUILTINS`, the writers left out (`THEME_WRITERS`: the
    functions of these names, under any name).
    """
    allowed: dict[int, Any] = {id(value): value for value in _theme_builtins.values()}
    for space in spaces:
        for value in space.values():
            if isinstance(value, ModuleType):
                allowed.update((id(item), item) for key, item in vars(value).items() if key[:1] != '_' and callable(item))
            elif callable(value):
                allowed[id(value)] = value
    for space in spaces:
        for name in THEME_WRITERS.intersection(space):
            allowed.pop(id(space[name]), None)
    return allowed


def theme_namespace(*spaces: Mapping[str, Any]) -> dict[str, Any]:
    """Return the own names of a namespace of the code of a theme: its builtins (`THEME_BUILTINS`), its guard of the calls (`THEME_CALL`)."""
    return {'__builtins__': _theme_builtins, THEME_CALL: partial(theme_call, theme_callables(*spaces))}


def theme_template_names() -> dict[str, Any]:
    """Return the own names of the code of a theme with the template names (`theme_namespace()` of `template_names()`: a binding)."""
    return _theme_template_names(tokens())


@lru_cache(maxsize=1)
def _theme_template_names(style: Style) -> dict[str, Any]:
    """Return the own names of the code of a theme with the template names of the style (`theme_template_names()`)."""
    return theme_namespace(_template_names(style))


@frozen(kw_only=True)
class TemplateCode:
    """The code of a template the generation evaluates (`template_code()`)."""

    #: The position of its element (`path:line`).
    src: str
    #: An expression (Python statements: `statements`).
    text: str
    #: Python statements (`<ff:vars>`).
    statements: bool = False


def template_code(root: ET.Element) -> Iterator[TemplateCode]:
    """
    Yield the code of the template the generation evaluates: the expressions of the control elements (`CODE_ATTRS`, the `ff:set` text,
    the names `with` of `ff:delegate`, `ff:breakpoint`, `ff:args` of `ff:include`, the text of a parameter of the type `expr`), the fields
    of the texts and the attributes (`{expr}`, `{=binding}`, the ones in a format spec), the statements of `<ff:vars>`. A text made by the
    generation and evaluated (a field of a parameter of the type `expr`) is known then only (`XmlEval` restricts it the same way).
    """
    def fields(src: str, text: str | None) -> Iterator[TemplateCode]:
        """Yield the fields of the template text of the element at `src` (the ones in a format spec too)."""
        if text and '{' in text:
            for _literal, name, spec, _conversion in fparser(text):
                if name:
                    yield TemplateCode(src=src, text=name[1:] if name[:1] == '=' else name)
                yield from fields(src, spec)

    bare = {child for statement in root.iter('{ff}statement') for child in statement}  # `<if if="…">` in `<ff:statement>`
    for elem in root.iter():
        if not isinstance(elem.tag, str):
            continue
        src = elem.get(SRC_ATTR, '')
        tag = elem.tag[4:] if elem.tag.startswith('{ff}') else elem.tag if elem in bare else ''
        code = CODE_ATTRS.get(tag)
        for name, value in elem.attrib.items():
            if name == code or name == '{ff}breakpoint':
                yield TemplateCode(src=src, text=value)
            elif tag == 'delegate' and name == 'with':
                yield from (TemplateCode(src=src, text=var) for var in value.replace(',', ' ').split())
            elif name == '{ff}args':
                yield TemplateCode(src=src, text=f'___call({value})')
            elif tag == 'param' and name in ('value', 'expr') and elem.get('type') in ('expr', 'eval') and '{' not in value:
                yield TemplateCode(src=src, text=value)
            elif name != SRC_ATTR:
                yield from fields(src, value)
        if tag == 'vars':
            yield TemplateCode(src=src, text=elem.text or '', statements=True)
        elif tag == 'set' and 'value' not in elem.attrib:
            yield TemplateCode(src=src, text=elem.text or '')
        else:
            yield from fields(src, elem.text)
        yield from fields(src, elem.tail)


def theme_fault(root: ET.Element) -> str:
    """Return why the template of a theme is not allowed (its code, `template_code()`, by `theme_code()`: the position, the cause), '' it is."""
    for code in template_code(root):
        try:
            if code.statements:
                raise TemplateError('Not allowed in a theme: Python statements (<ff:vars>)')
            theme_code(code.text.strip())
        except (ValueError, SyntaxError) as exc:  # `TemplateError` is a `ValueError`
            return f'{code.src}: {exc}'
    return ''


def template_names() -> dict[str, Any]:
    """Names available in template code (and bindings), besides the template variables and Python builtins: `tokens` the style now."""
    return _template_names(tokens())


@lru_cache(maxsize=1)  # a style changed (a preview, the variant of another skin): its names again
def _template_names(style: Style) -> dict[str, Any]:
    """Return the names of the template code of the style (`template_names()`)."""
    from ..kodi import KODI, version_info as kodi_version_info
    return {
        **DEFAULT_FUNCTIONS,
        'fflog': fflog,
        'L': L,
        **DEFAULT_NAMES,
        'KODI': KODI,
        'kodi_version': kodi_version_info,
        'const': const,
        'box_texture': box_texture,
        'texture_border': texture_border,
        'decor_images': decor_images,
        'texture_corners': texture_corners,
        'texture_inset': texture_inset,
        'tab_texture': tab_texture,
        'tab_offset': tab_offset,
        'tag_room': tag_room,
        'filter_shown': filter_shown,
        'more_texture': more_texture,
        'popup_texture': popup_texture,
        'popup_edge': popup_edge,
        'popup_fill': popup_fill,
        'group_band': group_band,
        'line_height': line_height,
        'group_alignment': group_alignment,
        'SEPARATOR_BITS': SEPARATOR_BITS,
        'separator_zoom': separator_zoom,
        'bevel_images': bevel_images,
        'box_edge': box_edge,
        'focus_texture': focus_texture,
        'shape_fill': shape_fill,
        'switch_icon_width': switch_icon_width,
        'switch_icon_height': switch_icon_height,
        'TOGGLE': TOGGLE,
        'TOGGLE_TIME': TOGGLE_TIME,
        'toggle_vars': toggle_vars,
        'tokens': style,
        'surface': surface,
        'alpha': alpha,
        'focused_image_variant': focused_image_variant,
        'FOCUSED_ICON': FOCUSED_ICON,
        'FRAME_SHAPES': FRAME_SHAPES,
        'NO_TINT': NO_TINT,
        'symbol': symbol,
    }


#: Elements (and `@attributes`) with a Kodi condition: a binding there is a condition.
CONDITION_TAGS = {'visible', 'enable', 'selected', '@condition'}
#: Elements fixed when Kodi loads the window (geometry): no binding there.
FIXED_TAGS = {*GEOM_TAGS, 'posx', 'posy'}


class XmlNamespace(dict):
    """
    Names of the template code (Python builtins and the template scope).

    The dict itself keeps its own names only (`__builtins__`; of the code of a theme: `theme_namespace()`). A name is read from the call
    extra names and the template (`XmlManager._get_eval_name()`), an assignment goes to the current template frame.
    """

    def __init__(self, manager: XmlManager, own: Mapping[str, Any] | None = None) -> None:
        super().__init__(own or {'__builtins__': builtins})
        #: The own names (they stay in the dict).
        self._own: frozenset[str] = frozenset(self)
        #: The template manager (frames, variables).
        self._manager: XmlManager = manager
        #: Extra names of the current call (e.g. format() keyword arguments).
        self.extra: Mapping[str, Any] = {}

    def __getitem__(self, key: str) -> Any:
        if dict.__contains__(self, key):  # the own names and a direct write (`STORE_GLOBAL`, e.g. `:=` in a comprehension)
            return dict.__getitem__(self, key)
        if key in self.extra:
            return self.extra[key]
        return self._manager._get_eval_name(key)  # KeyError: Python takes a builtin or raises NameError

    def __setitem__(self, key: str, value: Any) -> None:
        if key in self._own:
            return dict.__setitem__(self, key, value)
        if key == 'FF':
            raise NameError('Variable name "FF" is reserved')
        if (frame := self._manager.current_frame) is None:
            raise NameError(f'Assign variable {key!r} without frame')
        frame.locals[key] = value

    def flush(self) -> None:
        """Move names written directly to the dict (Python does it for `:=` in a comprehension) to the current frame."""
        if len(self) > len(self._own):
            names = {k: v for k, v in self.items() if k not in self._own}
            for key in names:
                dict.__delitem__(self, key)
            if (frame := self._manager.current_frame) is not None:
                frame.locals.update(names)

    def __delitem__(self, key: str) -> None:
        if (frame := self._manager.current_frame) is None or key not in frame.locals:
            raise KeyError(key)
        del frame.locals[key]


class XmlEval:
    """
    Template code evaluator, compiled once: Python code (the templates of FF are trusted, from the add-on only), the code of a template of
    a theme restricted (`XmlManager.restricted`: `theme_code()`, `theme_namespace()`; no statements).
    """

    def __init__(self, manager: XmlManager) -> None:
        #: The template manager.
        self.manager: XmlManager = manager
        #: Names of the template code.
        self.namespace: XmlNamespace = XmlNamespace(manager)
        #: Names of the code of a theme (`theme_namespace()` of the names of the manager: made at its first use).
        self._theme_namespace: XmlNamespace | None = None

    def eval(self, expr: str, *, extra: Mapping[str, Any] | None = None) -> Any:
        """Evaluate the expression (the extra names for this call only, direct dict writes moved to the template frame after it)."""
        if self.manager.restricted:
            namespace, code = self.theme_namespace(), theme_code(expr.strip())
        else:
            namespace, code = self.namespace, compile_code(expr.strip(), 'eval')
        old, namespace.extra = namespace.extra, extra or {}
        try:  # not a context manager: thousands of calls a window
            return eval(code, namespace)
        finally:
            namespace.extra = old
            namespace.flush()

    def theme_namespace(self) -> XmlNamespace:
        """Return the names of the code of a theme: the functions of the template names, of the manager and of its variables may be called."""
        if self._theme_namespace is None:
            manager = self.manager
            self._theme_namespace = XmlNamespace(manager, theme_namespace(manager.e_names, manager.e_functions, manager.vars))
        return self._theme_namespace

    def exec(self, code: str, *, extra: Mapping[str, Any] | None = None) -> None:
        """Execute statements (assignments go to the current template frame; the extra names and the direct writes as `eval()`)."""
        if self.manager.restricted:
            raise TemplateError('Not allowed in a theme: Python statements (<ff:vars>)')
        namespace = self.namespace
        old, namespace.extra = namespace.extra, extra or {}
        try:
            exec(compile_code(dedent(code).strip(), 'exec'), namespace)
        finally:
            namespace.extra = old
            namespace.flush()


class TemplateText(List[FormatNode]):
    """The parsed template text (`XmlFormatter.build_nodes()`): its nodes and its plain parts beside them, cached and dropped together."""

    #: The literal texts and the plain fields of a text of nothing else (joined by `XmlFormatter.vformat()`), () for the generic
    #: rendering: a binding, a section, a conversion, a field or a default (`!!`) in the spec, an auto-numbered or a positional field.
    flat: tuple[str | FormatField, ...] = ()


class XmlFormatter(SafeFormatter):
    """
    Format `{expr}` fields of the template text, `\\[...\\]` sections like in Kodi labels.
    A context manager of the element formatted (`with manager.formatter(node=elem) as fmt:`, the element for the errors).
    """

    #: The texts of the templates (a few hundred a window) are parsed once.
    max_cache: int = 4096
    #: The parsed texts of all the generations in the interpreter: the nodes depend on the text only (the mode of the formatter is fixed).
    nodes_cache: dict[Any, FormatNodes] = {}

    def __init__(self, evaluator: XmlEval) -> None:
        super().__init__(evaluate=False, extended=True, sections=Sections.ESCAPED)
        self.nodes_cache = XmlFormatter.nodes_cache  # the shared one (`SafeFormatter` gives a formatter its own)
        #: Template code evaluator.
        self.xml_eval: XmlEval = evaluator
        self._string_to_format: str = ''
        #: The template elements being formatted (`XmlManager.formatter()`), the innermost last.
        self._xml_nodes: list[ET.Element[str] | None] = [None]
        #: Tag of the element which content is formatted (`@name` for an attribute, None for none), for bindings.
        self.xml_tag: str | None = None

    def __enter__(self) -> XmlFormatter:
        """Return the formatter, its element is in place (`XmlManager.formatter()`)."""
        return self

    def __exit__(self, *exc_info: object) -> None:
        """Drop the element of `XmlManager.formatter()`."""
        self._xml_nodes.pop()

    def vformat(self, format_string: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> str:
        self._string_to_format = format_string
        # a text of plain fields joined: the same text as the generic rendering (`get_field()` here never gives a missing field)
        if parts := cast(TemplateText, self.cached_nodes(format_string)).flat:
            out: list[str] = []
            for part in parts:
                if isinstance(part, str):
                    out.append(part)
                else:
                    value, _key = self.get_field(part.name, args, kwargs)
                    try:
                        out.append(format(value, part.spec))
                    except (ValueError, TypeError):
                        out.append(self.format_field(value, part.spec))  # the spec kept in the text
            return ''.join(out)
        if RX_BINDING_FIELD.search(format_string) and self.xml_tag not in CONDITION_TAGS:
            return self._text_binding(format_string)
        return super().vformat(format_string, args, kwargs)

    def build_nodes(self, format_string: str) -> TemplateText:
        """Parse the text (once: `cached_nodes()`), its plain parts beside the nodes (`TemplateText.flat`)."""
        nodes = TemplateText(super().build_nodes(format_string))
        if not RX_BINDING_FIELD.search(format_string):
            parts: list[str | FormatField] = []
            for node in nodes:
                if isinstance(node, FormatLiteral):
                    parts.append(node.text)
                elif (isinstance(node, FormatField) and node.conversion is None and node.name and not node.name.isdigit()
                      and node.name[0] != '=' and '{' not in node.spec and '!!' not in node.spec):
                    parts.append(node)
                else:
                    break
            else:
                nodes.flat = tuple(parts)
        return nodes

    def _text_binding(self, format_string: str) -> str:
        """The whole text with a `{=expr}` field is computed at runtime, return the reference to it."""
        if self.xml_tag in FIXED_TAGS:
            raise ValueError(f'Binding {format_string!r} in <{self.xml_tag}>: Kodi fixes it when it loads the window')
        exprs = [name.lstrip('=') for _, name, _, _ in self.parse(format_string) if name]
        binding = self.xml_eval.manager.add_binding('text', RX_BINDING_FIELD.sub('{', format_string), source=format_string, exprs=exprs)
        return binding.reference()

    def get_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> tuple[Any, Any]:
        """Evaluate the field expression in the template scope (keyword arguments are extra names)."""
        if field_name.startswith('='):  # a binding in a condition: the condition of its own, other fields are generated
            expr = field_name[1:]
            return self.xml_eval.manager.add_binding('condition', expr, source=f'{{{field_name}}}', exprs=[expr]).reference(), ()
        try:
            return self.xml_eval.eval(field_name, extra=kwargs), ()
        except Exception as exc:
            node_str = f' node <{node.tag}>' if (node := self._xml_nodes[-1]) is not None else ''
            fflog.error(f'Error in field {{{field_name}}} in xml{node_str} in {self._string_to_format!r}: {exc!r}')
            raise


class XmlTemplate:

    def __init__(self, *,
                 module: XmlModule,
                 # vars: dict[str, Any] | None = None,
                 ) -> None:
        self.module: XmlModule = module
        self.src_path: Path | None = None
        self.src_tree: ET.ElementTree[ET.Element[str]] | None = None
        self.src_root: ET.Element[str] | None = None
        self.dst_root: ET.Element[str] | None = None
        # self.vars: dict[str, Any] = {} if vars is None else dict(vars)
        self._loops: list[LoopInfo | None] = []
        #: Tags of the output elements which content is being built (text and tails of the nodes go there), for bindings.
        self._content_tags: list[str] = []
        #: The contents of the widget uses being generated (`<ff:content>` takes the last one).
        self._contents: list[XmlContent] = []
        #: The tag filters (tags, exclude) of the contents being generated (a passed content is filtered by them too).
        self._content_filters: list[tuple[str | None, str | None]] = []

    @property
    def manager(self) -> XmlManager:
        return self.module.manager

    # def __iter__(self) -> Self:
    #     return self

    @property
    def vars(self) -> dict[str, Any]:
        frame = self.manager.current_frame
        if frame is None:
            raise RuntimeError('No current frame in template')
        return frame.locals

    def eval(self, expr: str, *, assignment: bool = False) -> Any:
        return self.module.manager.eval(expr, assignment=assignment)

    def var_assign(self, var: str, value: Any) -> Any:
        return self.module.manager.var_assign(var, value)

    def load(self,
             src: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str],
             /, *,
             path: Path | None = None):
        if isinstance(src, ET.ElementTree):
            self.src_tree = src
            self.src_root = self.src_tree.getroot()
        elif isinstance(src, ET.Element):
            self.src_tree = None
            self.src_root = src
        else:
            if path is None:
                path = src
            # positions of the elements (`SRC_ATTR`), relative to the skins folder
            folder = self.manager.folder
            self.src_root = parse_template(path, root=folder.parent if folder is not None else None)
            self.src_tree = ET.ElementTree(self.src_root)
        self.src_path = path

    def do(self,
           src: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str] | None = None,
           /, *,
           path: Path | None = None,
           ) -> ET.Element[str] | None:
        if self.src_root is None:
            if self.src_tree is None:
                if src is None:
                    fflog.error('No source to process')
                    return None
                self.load(src, path=path)
                assert self.src_root is not None
            else:
                self.src_root = self.src_tree.getroot()
        it = iter(self._process(self.src_root))
        new_root = next(it, None)
        self.dst_root = new_root
        try:
            next(it)
        except StopIteration:
            pass
        else:
            self.manager.problem('Too many root items')
        return self.dst_root

    # def _format(self, e: ET.Element) -> None:
    #     fargs = self.vars
    #     with self.manager.formatter(node=e) as fmt:
    #         attrib = dict(e.attrib)
    #         e.attrib.clear()
    #         e.attrib.update((fmt.format(a, **fargs), fmt.format(v, **fargs)) for a, v in attrib.items())
    #         if e.text is not None:
    #             e.text = fmt.format(e.text, **fargs)
    #         if e.tail is not None:
    #             e.tail = fmt.format(e.tail, **fargs)

    def _format_in(self, fmt: XmlFormatter, text: str, xml_tag: str | None) -> str:
        """Format the text of the content of `xml_tag` (`@name` for an attribute): a binding there is a condition or a text."""
        if '{' not in text and '}' not in text and '\\' not in text:  # no field, no binding, no escaped section: the text itself
            return text
        old, fmt.xml_tag = fmt.xml_tag, xml_tag
        try:
            return fmt.format(text)
        finally:
            fmt.xml_tag = old

    @property
    def _content_tag(self) -> str | None:
        """Tag of the output element which content is being built (text and tails of the nodes go there)."""
        return self._content_tags[-1] if self._content_tags else None

    def _new(self, e: ET.Element) -> ET.Element:
        with self.manager.formatter(node=e) as fmt:
            attrs = e.attrib
            if tag := attrs.get('{ff}tag'):
                tag = fmt.format(tag)
            if not tag:
                tag = e.tag
            text = e.text  # the source is never changed (its parsed tree is shared, `parse_template()`)
            if tag == 'font' and (style := attrs.get('{ff}style')) and (font := self.manager.font_styles.get(fmt.format(style))):
                text = font  # the role may come from a widget parameter (`ff:style="{style}"`)
            # a namespaced name (`{ff}style`) is not a field
            new = ET.Element(tag, {a if a[:1] == '{' else fmt.format(a): self._format_in(fmt, v, f'@{a}')
                                   for a, v in attrs.items() if a != '{ff}tag'})
            if text is not None:
                new.text = self._format_in(fmt, text, tag)
            if e.tail is not None:
                new.tail = self._format_in(fmt, e.tail, self._content_tag)  # the tail is in the parent content
            if tag in THEME_IMAGE_TAGS and (frame := self.manager.current_frame) is not None and frame.theme:
                new.set(THEME_ATTR, frame.theme)  # a texture of a theme: local files only (`gui.drop_remote_textures()`)
            return new

    @overload
    def _attr_var(self, elem: ET.Element, default: str | MissingType = MISSING) -> str: ...

    @overload
    def _attr_var(self, elem: ET.Element, default: None) -> str | None: ...

    def _attr_var(self, elem: ET.Element, default: str | MissingType | None = MISSING) -> str | None:
        var = elem.attrib.get('var', default)
        if var is MISSING:
            raise KeyError(f'Attribute "var" is missing in element: {elem.tag}')
        if var == 'FF':
            fflog.error(f'Variable name "FF" is reserved (element: {elem.tag})')
            return None
        if TYPE_CHECKING:
            assert isinstance(var, str) or var is None
        return var

    def _process(self, elem: ET.Element) -> Iterator[ET.Element]:
        """Process the element: its output elements; any error is a `TemplateError` with the position of the element."""
        try:
            yield from self._dispatch(elem)
        except TemplateError as exc:
            exc.locate(elem.get(SRC_ATTR, ''), self.manager.call_chain())
            raise
        except Exception as exc:
            raise TemplateError(f'{type(exc).__name__}: {exc}', src=elem.get(SRC_ATTR, ''), chain=self.manager.call_chain()) from exc

    def _dispatch(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Process the element by its handler (`<ff:…>`) or as an output element."""
        # print(f'src: {elem}')
        if not isinstance(elem.tag, str):
            return ()
        # print(f'Element {elem.tag} text: {None if elem_text is None else elem_text.text!r}')
        if FAKE and (cond := elem.get('{ff}breakpoint')) and self.eval(cond):
            breakpoint()  # break here on <xxx ff:breakpoint="CONDITION">
        if elem.tag.startswith('{ff}'):
            tag = elem.tag.partition('}')[2]
            handler = getattr(self, f'_handle_ff_{tag}', None)
            if handler is not None:
                return handler(elem)
            self.manager.problem(f'Unknown element <ff:{tag}>')
        elif elem.tag.startswith('{gui}'):
            return self._handle_widget(elem)
        return self._process_normal(elem)

    def _handle_widget(self, elem: ET.Element) -> Iterator[ET.Element]:
        """
        Generate a widget use `<gui:widget name="…" param="…">…</gui:widget>`: the attributes are its parameters (in the
        caller's names), the children its content (`<ff:content/>` in the widget), `name` its name in the window;
        `<gui:widget type="…">` is a widget of a computed name, `args="{mapping}"` its computed parameters (besides the attributes;
        a text value is a template text as an attribute, another object is the value itself).
        """
        manager = self.manager
        wtype = elem.tag[len('{gui}'):]
        if wtype == 'widget':  # `<gui:widget type="{page.widget}">`: a widget of a computed name (from the data)
            with manager.formatter(node=elem) as fmt:
                wtype = fmt.format(elem.get('type', ''))
        xdef = manager.widget(wtype, manager.current_module.namespace if manager.current_module is not None else '')
        params = manager.widget_params(xdef)
        given: dict[str, Any] = {}
        with manager.formatter(node=elem) as fmt:
            for attr, value in elem.attrib.items():
                if attr[:1] == '{' or attr in WIDGET_ATTRS or (attr in COMPUTED_WIDGET_ATTRS and elem.tag == '{gui}widget'):
                    continue
                if (param := params.get(attr)) is None:
                    raise TemplateError(f'Unknown parameter {attr!r} of widget {xdef.name!r}')
                given[attr] = self._parse_arg(fmt, value, param.type, given)
            if elem.tag == '{gui}widget' and (args := elem.get('args')):
                for attr, value in self._parse_arg(fmt, args, None, given).items():
                    if (param := params.get(attr)) is None:
                        raise TemplateError(f'Unknown parameter {attr!r} of widget {xdef.name!r}')
                    given[attr] = self._parse_arg(fmt, value, param.type, given) if isinstance(value, str) else value
            name = fmt.format(elem.get('name', ''))
        # the template attributes of the use (the layout of the widget in its parent: `ff:stretch`, `ff:align` ...) go to its
        # first control, the ones of the use win
        with manager.formatter(node=elem) as fmt:  # `ff:span="{n}"`: formatted in the caller's names
            use_attrs = {attr: fmt.format(value) for attr, value in elem.attrib.items() if attr.startswith('{ff}') and attr != SRC_ATTR}
        layout_tags = manager.layout_tags(use_attrs)  # before the widget: its parent is the last output control
        entry = manager.begin_widget(xdef, name, src=elem.get(SRC_ATTR, ''))
        self._contents.append(content := XmlContent(elems=list(elem), frame=manager.current_frame))
        manager._widget_uses[-1].content = content  # its template reads it (`use_items()`, `use_value()`)
        manager._widget_uses[-1].layout_tags = layout_tags
        manager._widget_uses[-1].attrs = {**use_attrs, USE_ATTR: entry.path}
        use = manager._widget_uses[-1]
        # a use in a filtered content (a widget in a frame: `exclude="geometry"`) filters only its own content (its geometry stays)
        filters, self._content_filters = self._content_filters, []
        try:
            if (comment := source_comment(xdef.root.get(SRC_ATTR, ''), xdef.name, entry.path)) is not None:
                yield comment
            for out in self._expand_widget(xdef, given, entry, call_src=elem.get(SRC_ATTR, '')):
                if use.outermost is None and isinstance(out.tag, str) and not isinstance(out, TextNode):  # not a text before it
                    manager.take_outermost(out)
                yield out
            if use.outermost is not None and (sized := manager.layout_reads.get(entry.path)):
                use.outermost.set(SIZED_ATTR, ' '.join(sorted(sized)))
            if use.outermost is None and use_attrs:
                raise TemplateError(f'Widget {xdef.name!r} has no control for the attributes {", ".join(sorted(use_attrs))}')
        finally:
            self._content_filters = filters
            self._contents.pop()
            manager.end_widget()

    def _expand_widget(self, xdef: XmlDefine, given: dict[str, Any], entry: WidgetEntry, *, call_src: str) -> Iterator[ET.Element]:
        """
        Generate the body of the widget in its own frame: the given parameters, the defaults of the others (a required one
        missing is an error), `id`, `path`; a widget with a base is the base used with this body as its content.
        """
        manager = self.manager
        frame = XmlCallFrame(module=xdef.module, define=xdef, globals=xdef.module.globals, call_src=call_src, theme=manager.frame_theme(xdef.module))
        kwargs = dict(given)
        manager.frames.append(frame)
        try:
            with manager.formatter(node=xdef.root) as fmt:
                for param in xdef.params.values():
                    if param.name in kwargs:
                        continue
                    if param.required:
                        raise TemplateError(f'Missing parameter {param.name!r} of widget {xdef.name!r}')
                    if param.expr:
                        kwargs[param.name] = self._parse_arg(fmt, param.expr, param.type, kwargs)
                    else:
                        kwargs[param.name] = param.type() if isinstance(param.type, type) else None
            manager.keep_template_values(entry, kwargs)
            frame.locals.update(kwargs, id=entry.id, path=entry.path)
            if xdef.base:
                base = manager.widget_base(xdef)
                base_params = manager.widget_params(base)
                # a derived widget with no body passes the content of its use on to its base as it is (its named contents too)
                if xdef.elems:
                    self._contents.append(XmlContent(elems=xdef.elems, frame=frame))
                try:
                    yield from self._expand_widget(base, {k: v for k, v in kwargs.items() if k in base_params}, entry,
                                                   call_src=xdef.root.get(SRC_ATTR, ''))
                finally:
                    if xdef.elems:
                        self._contents.pop()
            else:
                for el in xdef.elems:
                    yield from self._process(el)
        except Exception as exc:
            if not (xdef.module.namespace and xdef.name in manager._replaced):
                raise
            # an error in a widget of a theme replacing one of FF (its code, a template of FF it uses, a content in it): the window again
            # with the one of FF (`gui.render_xml()`); the innermost such widget
            error = exc if isinstance(exc, TemplateError) else TemplateError(f'{type(exc).__name__}: {exc}', src=xdef.root.get(SRC_ATTR, ''),
                                                                              chain=manager.call_chain())
            if not error.widget:
                error.widget = f'{xdef.module.namespace}:{xdef.name}'
            if error is exc:
                raise
            raise error from exc
        finally:
            manager.frames.pop()

    def _handle_ff_content(self, elem: ET.Element) -> Iterator[ET.Element]:
        """
        The content of the widget use: `<ff:content/>` its children (besides the named fillers), `<ff:content name="x"/>` the
        children of its `<ff:content name="x">` (none: the own children of this element, the default content); the name of the place
        is formatted in the widget (`name="{page.name}"`: places named by the data).
        The content is generated in the caller's frame; a content inside it takes the next outer use.
        """
        if not self._contents:
            raise TemplateError('<ff:content> out of a widget')
        if '{' in (name := elem.get('name', '')):
            with self.manager.formatter(node=elem) as fmt:
                name = fmt.format(name)
        content = self._contents.pop()
        try:
            frame = content.frame
            if name:
                fill = next((el for el in content.elems if el.tag == '{ff}content' and el.get('name') == name), None)
                if fill is None:
                    elems, frame = list(elem), None
                else:
                    elems = list(fill)
            else:
                elems = [el for el in content.elems if not (el.tag == '{ff}content' and el.get('name'))]
            # the filters of this element and of the contents passing this one on (`<ff:content/>` of a derived widget)
            filters = [*self._content_filters, (elem.get('tags'), elem.get('exclude'))]
            elems = self._content_filter(filters, elems)
            if frame is not None:
                self.manager.frames.append(frame)
            self._content_filters.append((elem.get('tags'), elem.get('exclude')))
            try:
                for el in elems:
                    yield from self._process(el)
            finally:
                self._content_filters.pop()
                if frame is not None:
                    self.manager.frames.pop()
        finally:
            self._contents.append(content)

    def _process_normal(self, elem: ET.Element) -> Iterable[ET.Element]:
        new = self._new(elem)
        if new.tag == 'control' and self.manager._widget_uses and self.manager._widget_uses[-1].outermost is None:
            self.manager.take_outermost(new)  # before its children: the widgets in it see its layout
        self._content_tags.append(new.tag)  # text and tails of the children (e.g. of <ff:if>) are in its content
        self.manager._outputs.append(new)
        try:
            for el in elem:
                self._append_output(new, self._process(el))
        finally:
            self.manager._outputs.pop()
            self._content_tags.pop()
        return (new, )

    @staticmethod
    def _append_output(new: ET.Element, sub: Iterable[ET.Element | str]) -> None:
        """Append the output of a processed element to the new element (a text goes to its text or to the tail of its last child)."""
        p = new[-1] if len(new) else None
        for e in sub:
            if type(e) is TextNode:
                e = e.text or ''
            if isinstance(e, str):
                if p is None:
                    # print(f'Append {e!r} to {new.tag} text')
                    new.text = (new.text or '') + e
                else:
                    # print(f'Append {e!r} to {p.tag} tail')
                    p.tail = (p.tail or '') + e
            else:
                new.append(e)
                p = e

    def _process_text(self, elem: ET.Element) -> Iterable[ET.Element]:
        if text := elem.text:
            with self.manager.formatter(node=elem) as fmt:
                text = self._format_in(fmt, text, self._content_tag)
            yield TextNode(text)

    def _process_tail(self, elem: ET.Element) -> Iterable[ET.Element]:
        if text := elem.tail:
            with self.manager.formatter(node=elem) as fmt:
                text = self._format_in(fmt, text, self._content_tag)
            yield TextNode(text)

    def _process_children(self, elem: ET.Element) -> Iterable[ET.Element]:
        yield from self._process_text(elem)
        for el in elem:
            yield from self._process(el)
            if self._loops and not self._loops[-1]:
                break

    def _close_loop(self, elem: ET.Element, *, broken: bool, empty: bool) -> Iterable[ET.Element]:
        if not broken:
            hit = False
            for el in elem:
                if el.tag == '{ff}else':
                    hit = True
                elif el.tag == '{ff}empty':
                    hit = False
                elif hit:
                    for sub in self._process(el):
                        empty = False
                        yield sub
        if empty:
            hit = False
            for el in elem:
                if el.tag == '{ff}else':
                    hit = False
                elif el.tag == '{ff}empty':
                    hit = True
                elif hit:
                    yield from self._process(el)

    def _loop(self, elem: ET.Element, loop: Iterable[Any], *, var: str | None = None, infinite: bool = False) -> Iterable[ET.Element]:
        assert var != 'FF'
        empty, broken = True, False
        self._loops.append(None)  # to handle "break"
        for info, v in loop_iter(loop, var=var, template=self, infinite=infinite):
            self._loops[-1] = info
            if var is not None:
                self.var_assign(var, v)
            yield from self._process_text(elem)
            for el in elem:
                if el.tag in ('{ff}else', '{ff}empty'):
                    break
                for sub in self._process(el):
                    empty = False
                    yield sub
                if not self._loops[-1]:
                    broken = True
                    break
            if broken:
                break
        self._loops.pop()
        yield from self._close_loop(elem, broken=broken, empty=empty)
        if var is not None:
            self.vars.pop(var, None)
        yield from self._process_tail(elem)

    # --- ff:node handlers ---

    def _handle_ff_set(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Set variable.
        <ff:set var="name" value="expr"/>
        <ff:set var="name"> expr </ff:set>
        """
        var = self._attr_var(elem)
        if (val_str := elem.get('value')) is None:
            val_str = elem.text or ''
        val = self.eval(val_str)
        self.var_assign(var, val)
        return ()

    def _handle_ff_del(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Delete variable.
        <ff:del var="name" />
        """
        var = self._attr_var(elem)
        self.vars.pop(var, None)
        return ()

    def _handle_ff_vars(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Set multiple variables.
        <ff:vars> var1 = expr1 \n var2 = expr2 \n ... </ff:vars>
        """
        self.eval(elem.text or '', assignment=True)
        return ()

    def _handle_ff_if(self, elem: ET.Element) -> Iterable[ET.Element]:
        """If condition.
        <ff:if if="cond" [var="name"]> ... <ff:elif if="cond"/> ... <ff:else> ... </ff:if>
        """
        cond = self.eval(elem.attrib['if'])
        self.vars['if'] = cond
        if var := self._attr_var(elem, None):
            self.vars[var] = cond
        if hit := bool(cond):
            yield from self._process_text(elem)
        for el in elem:
            if el.tag in ('{ff}elif', '{ff}else'):
                if hit:  # end of hit section, any elif/else couldn't hit
                    break
                if 'if' in el.attrib:
                    self.vars['if'] = cond = self.eval(el.attrib['if'])
                    hit = bool(cond)
                elif el.tag == '{ff}elif':
                    self.manager.problem('<elif> without if="..."')
                    break
                else:
                    hit = not hit
                if hit:
                    if el.text:
                        self.manager.problem(f'Text {el.text!r} inside <{el.tag}> is ignored, append it after </{el.tag}>')
                    yield from self._process_tail(el)
            elif hit:
                yield from self._process(el)
        self.vars.pop('if', None)
        yield from self._process_tail(elem)  # formatted as the tail of other `ff:*` elements

    def _handle_ff_break(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Break from loop.
        <ff:break [number="N"] />
        """
        num = int(elem.get('number') or 1)
        if 0 < num <= len(self._loops):
            for i in range(num):
                self._loops[-i-1] = None
        else:
            self.manager.problem('Nothing to break')
        return ()

    def _handle_ff_for(self, elem: ET.Element) -> Iterable[ET.Element]:
        """For loop.
        <ff:for var="item" in="iterable">...</ff:for>
        """
        var = self._attr_var(elem)
        loop = self.eval(elem.attrib['in'])
        yield from self._loop(elem, loop, var=var)

    def _handle_ff_while(self, elem: ET.Element) -> Iterable[ET.Element]:
        """While loop.
        <ff:while if="cond">...</ff:while>
        """
        def loop() -> Iterable[bool]:
            while cond := self.eval(expr):
                self.vars['while'] = self.vars['if'] = cond
                yield True
        expr = elem.attrib['if']
        yield from self._loop(elem, loop(), infinite=True)
        self.vars.pop('if', None)
        self.vars.pop('while', None)

    def _handle_ff_statement(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Block with control flow.
        <ff:statement>  <!-- single line from example below -->
            <ff:if if="cond">...</ff:if>  <ff:elif if="cond">...</ff:elif>  <ff:else>...</ff:else>
            <ff:for var="item" in="iterable">...</ff:for>  <ff:else>...</ff:else>  <ff:empty>...</ff:empty>
            <ff:while if="cond">...</ff:while>             <ff:else>...</ff:else>  <ff:empty>...</ff:empty>
        </ff:statement>
        """

        def check_garbage_text(it: ElementChildren) -> None:
            el = it.current()
            if el is not None and el.tail and (text := el.tail.strip()):
                tag = it.current_ff_tag(bare=True)
                self.manager.problem(f'Text {text!r} after <ff:statement> <ff:{tag}> is ignored, put it into sub-element')

        def process_loop(el: ET.Element, loop: Iterable[Any], *, var: str | None = None, infinite: bool = False) -> Iterable[ET.Element]:
            self._loops.append(None)  # to handle "break"
            empty, broken = True, False
            for info, v in loop_iter(loop, var=var, template=self, infinite=infinite):
                self._loops[-1] = info
                if var is not None:
                    self.var_assign(var, v)
                if subs := tuple(self._process_children(el)):
                    empty = False
                yield from subs
                if not self._loops[-1]:
                    broken = True
                    break
            self._loops[-1] = LoopInfo(-1, False, var=var, depth=len(self._loops) - 1, template=self)  # ignore "break" in "else" and "empty"
            else_elem = None
            empty_elem = None
            for el in it:
                check_garbage_text(it)
                tag = it.current_ff_tag(bare=True)
                if tag == 'else':
                    else_elem = el
                elif tag == 'empty':
                    empty_elem = el
            if not broken and else_elem is not None:
                if subs := tuple(self._process_children(else_elem)):
                    ...  # I've changed my mind, yield <ff:empty> even if <ff:else> produced something
                    # empty = False
                yield from subs
            if empty and empty_elem is not None:
                yield from self._process_children(empty_elem)
            if var:
                self.vars.pop(var, None)
            self._loops.pop()

        if elem.text and (text := elem.text.strip()):
            self.manager.problem(f'Text {text!r} after <ff:statement> is ignored, put it into sub-element')
        it = ElementChildren(elem)
        for el in it:
            tag = it.current_ff_tag(bare=True)
            check_garbage_text(it)

            if tag in ('set', 'del', 'vars'):
                list(self._process(el))  # run it (a generator; these yield nothing)
                continue

            if tag == 'if':
                it.back()
                for i, el in enumerate(it):
                    if i:
                        check_garbage_text(it)
                    tag = it.current_ff_tag(bare=True)
                    if tag == 'elif' or (tag in ('if', 'else') and 'if' in el.attrib):
                        cond = self.vars['if'] = cond = self.eval(el.attrib['if'])
                        if var := self._attr_var(el, None):
                            self.vars[var] = cond
                        if cond:
                            yield from self._process_children(el)
                            break
                    elif tag == 'else':
                        yield from self._process_children(el)
                        break
                    else:
                        self.manager.problem(f'Unsupported tag {el.tag} in block/if')
                        break
                else:
                    continue  # no any tag hit (all false conditions)
                break  # hit condition, break <ff:block> lookup

            elif tag == 'for':
                var = self._attr_var(el, None)
                yield from process_loop(el, self.eval(el.attrib['in']), var=var)

            elif tag == 'while':
                def loop() -> Iterable[bool]:
                    while cond := self.eval(expr):
                        self.vars['while'] = self.vars['if'] = cond
                        yield True
                expr = el.attrib['if']
                var = self._attr_var(el, None)
                yield from process_loop(el, loop(), infinite=True)

            else:
                self.manager.problem(f'Unsupported <{el.tag}> in <ff:statement>, ignored')

        yield from self._process_tail(elem)

    def _handle_ff_include(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Include definition from module.
        <ff:include module="modulename" name="defname" [args="arg1, arg2, ..."] />
        """
        with self.manager.formatter(node=elem) as fmt:
            def parse_arg(expr: str, xtype: type[Any] | Callable[[Any], Any] | None = None) -> Any:
                """Return the value of an argument (the names: the arguments so far)."""
                return self._parse_arg(fmt, expr, xtype, kwargs)

            ff_name = elem.get('{ff}name')
            ff_module = elem.get('{ff}module')
            if ff_name is not None:
                ff_name = fmt.format(ff_name)
            if ff_module is not None:
                ff_module = fmt.format(ff_module)
            if xdef := self.manager.include(ff_module, ff_name):
                module = xdef.module
                frame = XmlCallFrame(module=module, define=xdef, locals={}, globals=module.globals, call_src=elem.get(SRC_ATTR, ''),
                                     theme=self.manager.frame_theme(module))
                # self.manager.frames.append(frame)
                pushed = False  # the frame of the definition is on the stack (popped only then: an error keeps the caller's one)
                try:
                    args_str = elem.get('{ff}args') or ''
                    if mod := elem.attrib.get('{ff}module'):
                        def_name = f'{mod}.{elem.get("{ff}name")}'
                    else:
                        def_name = elem.get('{ff}name') or ''
                    try:
                        # work with caller context (no arguments: none, nothing evaluated)
                        args, kwargs = ((), {})
                        if args_str:
                            self.eval(f'___call({args_str})')
                            args, kwargs = self.module.manager.call_func_args()
                        # print(f'>>> >>> include {def_name} with args: {args}, kwargs: {kwargs}')  # XXX
                        if xdef.sig is not None:
                            for param in xdef.sig.parameters.values():
                                if (param.name not in kwargs and param.kind in (Parameter.POSITIONAL_OR_KEYWORD, Parameter.KEYWORD_ONLY)
                                        and (val := elem.get(param.name)) is not None):
                                    ann = param.annotation if param.annotation is not Parameter.empty else xdef.params.get(param.name, XmlDefineParam(param.name)).type
                                    if not callable(ann):
                                        ann = None
                                    kwargs[param.name] = parse_arg(val, ann)
                        # switch to called define context
                        self.manager.frames.append(frame)
                        pushed = True
                        # print(f'>>> >>> include {def_name} with args: {args}, kwargs: {kwargs}')  # XXX
                        # default <ff:param/> parameters
                        for param in xdef.params.values():
                            if param.name not in kwargs:
                                if param.expr:
                                    kwargs[param.name] = parse_arg(param.expr, param.type)
                                elif param.type:
                                    if isinstance(param.type, type):
                                        kwargs[param.name] = param.type()
                                    else:
                                        kwargs[param.name] = None  # callable type without default value, pass None
                                else:
                                    self.manager.problem(f'Missing argument {param.name!r} for definition {xdef.name!r} in {repr(mod) if mod else "current"} module')
                        # print(f'>>> >>> include {def_name} with args: {args}, kwargs: {kwargs}')  # XXX
                        frame.locals.update(kwargs)
                        if xdef.sig:
                            bind = xdef.sig.bind(*args, **kwargs)
                            bind.apply_defaults()
                            frame.locals.update(bind.arguments)
                    except Exception as exc:
                        raise ValueError(f'Incorrect include call of {def_name!r}: {exc}') from exc
                    if (comment := source_comment(xdef.root.get(SRC_ATTR, ''), def_name)) is not None:
                        yield comment
                    for el in xdef.elems:
                        yield from self._process(el)
                finally:
                    if pushed:
                        self.manager.frames.pop()

    def _parse_arg(self, fmt: XmlFormatter, expr: str, xtype: type[Any] | Callable[[Any], Any] | None, names: Mapping[str, Any]) -> Any:
        """
        Return the value of an argument of a definition (`expr`: its text with `{…}` fields, `names`: the extra names).
        A single field is the object itself (not its text); the type converts it, without a type a number or a bool is guessed.
        """
        nodes = fmt.cached_nodes(expr or '')
        if len(nodes) == 1 and isinstance(node := nodes[0], FormatField) and node.name and not node.spec and not node.conversion:
            # a single "{expr}" field: the object itself, not its text
            val = self.manager.evaluator.eval(node.name, extra=names)
            if not isinstance(val, str):
                if isinstance(xtype, type) and not isinstance(val, xtype):
                    return xtype(val)
                return val
        else:
            val = fmt.format(expr or '', **names)
        if xtype is not None and not isinstance(xtype, str):
            if xtype is bool:
                return mk_bool(val)
            return xtype(val)
        if val == 'True':
            return True
        if val == 'False':
            return False
        try:
            val = int(val)  # check if it's a integer
        except ValueError:
            try:
                val = float(val)  # check if it's a number
            except ValueError:
                pass  # other as string
        return val

    def _handle_ff_log(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Log message.
        <ff:log level="info|warning|error|debug">MESSAGE</ff:log>
        """
        level = elem.get('level', 'info').lower()
        with self.manager.formatter(node=elem) as fmt:
            try:
                message = fmt.format(elem.text or '')
            except Exception as exc:
                message = f'Formatting log message {elem.text!r} error: {exc}'
        if level in ('debug', 'info', 'warning', 'error'):
            getattr(fflog, level)(message)
        else:
            fflog(message)
        return ()

    def _handle_ff_define(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Define reusable block.
        <ff:define name="defname" [args="arg1, arg2, ..."]> ... </ff:define>
        """
        if self.manager.current_module is not None:
            self.manager.current_module.define(elem)
        return ()

    def _handle_ff_breakpoint(self, elem: ET.Element) -> Iterable[ET.Element]:
        """Debug breakpoint. <ff:breakpoint/>"""
        if FAKE:
            if cond := elem.get('if'):
                if not self.eval(cond):
                    return ()
            breakpoint()  # break here on <ff:breakpoint/>
        return ()

    @staticmethod
    def _content_filter(filters: Sequence[tuple[str | None, str | None]], elems: list[ET.Element]) -> list[ET.Element]:
        """
        Select the content elements by their tags: `<ff:content tags="geometry"/>` only these, `exclude="geometry"` the others
        (`geometry`: the position, the size, `visible`, `animation` - of a widget made of more controls: they go to its group; `anchored`:
        the uses of the tags and the edge marks - on the edge of a frame);
        `filters`: (tags, exclude) of the element and of the contents it passes on; a passed content (`<ff:content/>`) is
        kept, its elements are filtered when it is generated.
        """
        def tags(value: str) -> set[str]:
            """Return the tag names of the attribute value."""
            names = {name.strip() for name in value.split(',') if name.strip()}
            if 'geometry' in names:
                names |= CONTENT_GEOMETRY
            if 'anchored' in names:
                names |= CONTENT_ANCHORED
            return names

        for only, exclude in filters:
            if only is not None:
                wanted = tags(only)
                elems = [el for el in elems if el.tag in wanted or el.tag == '{ff}content']
            if exclude is not None:
                unwanted = tags(exclude)
                elems = [el for el in elems if el.tag not in unwanted]
        return elems

    def _handle_ff_delegate(self, elem: ET.Element) -> Iterator[ET.Element]:
        """
        The rows of a list widget `<ff:delegate height="…" width="…">default</ff:delegate>`: the content `row` of the use
        (`<ff:content name="row">`, none: the children of this element) twice, as `<itemlayout>` and `<focusedlayout>` (the
        attributes of both, `focused-x` of the focused one, an empty one is left out), `focused` false / true; a binding there
        (`{=row.…}`) is a role of the rows of the widget. `with="a, b"`: the names of the widget (e.g. its loop variable) the
        content sees too (`<ff:for var="layout" in="layouts"><ff:delegate … with="layout"/></ff:for>`). `focus`: a Kodi condition
        (the focus of the list) the focused layout has its look by - its content `focused` true while it holds, else false, the look
        of the other rows (Kodi gives the current row its focused layout also with the focus elsewhere); '' always the focused look.
        """
        from .geometry import ROW_LOOK_ATTR  # geometry -> layout -> xgui
        manager = self.manager
        if not manager._widget_uses or not self._contents:
            raise TemplateError('<ff:delegate> out of a widget')
        entry = manager._widget_uses[-1].entry
        content = self._contents[-1]
        caller = content.frame
        with manager.formatter(node=elem) as fmt:
            attrs = {name: fmt.format(value) for name, value in elem.attrib.items() if name[:1] != '{'}
        passed = {name: self.eval(name) for name in attrs.pop('with', '').replace(',', ' ').split()}
        focus = attrs.pop('focus', '')
        attrs = {name: value for name, value in attrs.items() if value}
        # `focused-height="121"`: an attribute of the focused layout only (it overrides `height`)
        layout_attrs = {False: {name: value for name, value in attrs.items() if not name.startswith('focused-')},
                        True: {name: value for name, value in attrs.items() if not name.startswith('focused-')}}
        layout_attrs[True].update({name[len('focused-'):]: value for name, value in attrs.items() if name.startswith('focused-')})
        placeholder = ET.Element('{ff}content', {'name': DELEGATE_CONTENT})
        placeholder.extend(list(elem))
        manager._row_roles.append(entry.roles)
        manager._row_widgets.append(set())
        manager._row_lists.append(entry.id)
        manager._row_widths.append(int(float(attrs.get('width') or 0)) or manager.use_value('width'))  # its width, else the list's (Kodi's)
        manager._row_focused.append(False)
        manager._row_outputs.append(len(manager._outputs))
        try:
            for tag, focused in (('itemlayout', False), ('focusedlayout', True)):
                layout = ET.Element(tag, layout_attrs[focused])
                # the looks of the layout: (focused, its Kodi condition - '' none: the layout itself)
                looks = ((True, focus), (False, f'![{focus}]')) if focused and focus else ((focused, ''),)
                for look, condition in looks:
                    manager._row_focused[-1] = look
                    frame = None if caller is None else XmlCallFrame(module=caller.module, define=caller.define, globals=caller.globals,
                                                                     locals={**caller.locals, **passed, 'focused': look}, call_src=caller.call_src,
                                                                     theme=caller.theme)
                    self._contents[-1] = XmlContent(elems=content.elems, frame=frame)
                    if (current := manager.current_frame) is not None:
                        current.locals['focused'] = look  # the default content (of the widget) sees it too
                    place = layout
                    if condition:
                        place = ET.SubElement(layout, 'control', {'type': 'group'})
                        ET.SubElement(place, 'visible', {ROW_LOOK_ATTR: '1'}).text = condition
                    self._append_output(place, self._handle_ff_content(placeholder))
                yield layout
        finally:
            self._contents[-1] = content
            manager._row_roles.pop()
            manager._row_widgets.pop()
            manager._row_lists.pop()
            manager._row_widths.pop()
            manager._row_focused.pop()
            manager._row_outputs.pop()

    def _handle_ff_stretch(self, elem: ET.Element) -> Iterable[ET.Element]:
        """A spacer of a row / column `<ff:stretch factor="N"/>` (Qt `addStretch`): kept for the layout pass, which removes it."""
        return self._process_normal(elem)

    def _handle_ff_cell(self, elem: ET.Element) -> Iterable[ET.Element]:
        """A hole of a grid `<ff:cell span="N"/>` (no control): kept for the layout pass, which removes it."""
        return self._process_normal(elem)

    def _handle_ff_focus_line(self, elem: ET.Element) -> Iterable[ET.Element]:
        """
        A focus line `<ff:focus_line path="@a @X @b"/>` (also `ff:focus_row`, `ff:focus_column`; the path formatted): kept for the
        focus lines pass (`focus_lines.apply_focus_lines()`), which removes it. Only `path`, no content.
        """
        if extra := sorted(name for name in elem.attrib if name not in ('path', SRC_ATTR)):
            raise TemplateError(f'Unknown attributes of <{elem.tag.replace("{ff}", "ff:")}>: {", ".join(extra)}')
        if len(elem) or (elem.text or '').strip():
            raise TemplateError(f'<{elem.tag.replace("{ff}", "ff:")}> has no content')
        return self._process_normal(elem)

    _handle_ff_focus_row = _handle_ff_focus_column = _handle_ff_focus_line


@frozen
class XmlDefineParam:
    name: str
    type: type[Any] | None = None
    expr: str = ''
    #: A widget parameter without a value: the use must give it.
    required: bool = False
    #: The type is written in the declaration (`type="int"`), not derived from the value.
    declared: bool = False

    @classmethod
    def parse_type(cls, name: str | None, *, manager: XmlManager) -> type[Any] | None:
        """Parse type from string. Supported types: str, int, float, bool, expr (eval). Other types are an error."""
        if name is None:
            return None
        # TODO: check tests.find_arg_descr for supported types
        if not name:  # empty str
            return str
        if name in ('expr', 'eval'):
            return manager.eval  # type: ignore[return-value]  # pseudo-type for eval function
        if name in ('str', 'int', 'float', 'bool'):
            return eval(name)
        raise TemplateError(f'Unknown parameter type {name!r}')


@define(kw_only=True)
class XmlDefine:
    """Definition for including in template, whole module too (name is '')."""
    name: str
    root: ET.Element
    elems: list[ET.Element] = field(factory=list)
    args: str = ''
    sig: Signature | None = None
    params: dict[str, XmlDefineParam] = field(factory=dict)
    module: XmlModule
    #: A widget (`<ff:widget>`, used as `<gui:name>`), not an include definition.
    widget: bool = False
    #: The base widget: this one is its use with the body as the content and own defaults of the parameters.
    base: str = ''


@define(kw_only=True)
class XmlCallFrame:
    """Call frame for included definition."""
    module: XmlModule
    define: XmlDefine  # name='' for module
    args: tuple[Any, ...] = field(factory=tuple)
    kwargs: dict[str, Any] = field(factory=dict)
    locals: dict[str, Any] = field(factory=dict)
    globals: dict[str, Any] = field(factory=dict)
    #: The position of the include element of the call (`path:line`).
    call_src: str = ''
    #: The theme (its add-on ID) whose template gives the values of this frame: of its file, of a template of FF it uses (a base, an
    #: include, a widget), '' of FF (the content of a use of FF in a widget of a theme: the frame of FF).
    theme: str = ''


@define(kw_only=True)
class XmlModule:
    name: str
    manager: XmlManager
    #: The theme of the module (its add-on ID: its widgets and modules are seen in its files only, `XmlManager.widget()`), '' of FF.
    namespace: str = ''
    xml: XmlTemplate | None = None
    defines: dict[str, XmlDefine] = field(factory=dict)
    globals: dict[str, Any] = field(factory=dict)

    def load(self, src: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str], /, ) -> bool:
        self.xml = XmlTemplate(module=self)
        self.xml.load(src)
        if self.xml.src_root is None:
            return False
        if self.xml.src_root.tag in ('{ff}defines', '{ff}widgets'):
            for elem in self.xml.src_root:
                self.process(elem)
        return True

    def define(self, elem: ET.Element) -> None:
        if elem.tag not in ('{ff}define', '{ff}widget'):
            self.manager.problem(f'Incorrect definition element: {elem.tag!r}, expected <ff:define> or <ff:widget>')
            return
        widget = elem.tag == '{ff}widget'
        xdef = XmlDefine(name=elem.attrib['name'], root=elem, module=self, widget=widget, base=elem.get('base', ''))
        try:
            if args := elem.get('args'):
                xdef.args = args
                xdef.sig = get_signature(f'def _({args}): ...')
            for el in elem:
                if el.tag == '{ff}param':
                    param_name = el.attrib['name']
                    if widget and param_name in WIDGET_NAMES:
                        self.manager.problem(f'Parameter name {param_name!r} of widget {xdef.name!r} is reserved')
                    if param_name in xdef.params:
                        self.manager.problem(f'Duplicate parameter name {param_name!r} in definition {xdef.name!r}')
                    else:
                        expr = el.attrib.get('expr')
                        if not expr:
                            expr = el.attrib.get('value', el.text)
                        if not expr and xdef.sig is not None and (par := xdef.sig.parameters.get(param_name)) and par.default is not par.empty:
                            expr = repr(par.default)
                        xtype = XmlDefineParam.parse_type(el.attrib.get('type'), manager=self.manager)
                        # a widget parameter without a value is required (an include one: an empty string)
                        required = widget and 'value' not in el.attrib and 'expr' not in el.attrib and not el.text
                        if xtype is None and expr == '' and not required:  # empty expression means empty string by default
                            xtype = str
                        xdef.params[param_name] = XmlDefineParam(name=param_name, expr=expr or '', type=xtype, required=required,
                                                                 declared='type' in el.attrib)
            if xdef.sig is None and xdef.params:
                xdef.sig = Signature(parameters=[Parameter(param.name, Parameter.KEYWORD_ONLY, default=..., annotation=param.type or Parameter.empty)
                                                 for param in xdef.params.values()])
            for el in elem:
                if el.tag != '{ff}param':
                    xdef.elems.append(el)
        except Exception as exc:
            self.manager.problem(f'Incorrect include definition: {exc}')
        if xdef.name:
            if xdef.name in self.defines:
                self.manager.problem(f'Duplicate definition name {xdef.name!r} in module {self.name!r}')
            self.defines[xdef.name] = xdef

    def process(self, elem: ET.Element) -> None:
        if elem.tag in ('{ff}define', '{ff}widget'):
            self.define(elem)
        elif elem.tag == '{ff}vars':
            if self.xml is not None:
                self.xml._handle_ff_vars(elem)

    def include(self, name: str) -> XmlDefine | None:
        return self.defines.get(name)


@frozen(kw_only=True)
class WidgetFace:
    """
    What the uses of a widget and its Python class rely on, derived from its declaration and the ones of its bases
    (`XmlManager.widget_face()`): a widget of a theme replaces the one of FF only when it keeps its face (`misfit()`).
    """

    #: The family (the Python class of the widget is found in it).
    family: str
    #: The parameters with the ones of the bases.
    params: dict[str, XmlDefineParam]
    #: The places of the content of a use (`<ff:content name="…">`: '' the default one, `DELEGATE_CONTENT` the rows of a list).
    places: frozenset[str]
    #: The names of its controls (`id_of(name)`): the Python class finds them by these.
    controls: frozenset[str]
    #: The type of the widget control (`<control type="…" id="{id}">`), '' not written in its templates.
    control: str

    def misfit(self, ff: WidgetFace) -> str:
        """Return why this face (of a widget of a theme) does not keep the face `ff` (of the widget of FF it replaces), '' it does."""
        if self.family != ff.family:
            return f'not in the family {ff.family!r}'
        if missing := sorted(ff.params.keys() - self.params.keys()):
            return f'no parameters {", ".join(missing)}'
        if required := sorted(name for name, param in self.params.items() if param.required and not (name in ff.params and ff.params[name].required)):
            return f'parameters {", ".join(required)} required'  # a use of FF leaves them out
        if typed := sorted(name for name, param in ff.params.items()
                           if param.declared and not (self.params[name].declared and self.params[name].type == param.type)):
            return f'parameters {", ".join(typed)} not of the declared types of FF'  # a use of FF gives its values of these types
        if missing := sorted(ff.places - self.places):  # a new place: no use of FF fills it, its default content shown
            return f'no content places {missing}'
        if missing := sorted(ff.controls - self.controls):
            return f'no controls {", ".join(missing)}'
        if ff.control and self.control != ff.control:
            return f'the control type {self.control!r}, not {ff.control!r}'
        return ''


#: The widgets of the active themes not used, of the last `XmlManager.widget_index()`: the name -> why (`WidgetFace.misfit()`).
_rejected_widgets: dict[str, str] = {}


def widget_stamp() -> str:
    """Return the stamp of the widget families of the active themes (a part of the key of the generated windows), '' none."""
    from ..ff.theme import skin_widgets
    if not (themes := skin_widgets()):
        return ''
    from ..ff.filecache import mtime_stamp
    # the order of the themes (the most important one wins), the files (their changes, appearing, disappearing)
    return repr((tuple(str(folder) for folder in themes), mtime_stamp(path for paths in themes.values() for path in paths)))


def rejected_widgets() -> dict[str, str]:
    """Return the widgets of the active themes not used (of the last index of the widgets): the name -> why."""
    return _rejected_widgets


class XmlManager:

    PATH: ClassVar[Sequence[Path]] = [
        # templates are Python code, so they are loaded from the add-on only (a manager without its folder: the tests, the CLI)
        Path(__file__).parent.parent.parent / 'resources' / 'skins' / 'widgets',
    ]

    def __init__(self, *,
                 vars: dict[str, Any] | None = None,
                 font_styles: dict[str, str] | None = None,
                 folder: Path | None = None,
                 faulty: Mapping[str, str] | None = None,
                 sizes: Mapping[str, Mapping[str, int]] | None = None,
                 ):
        #: The folder of the template modules (a window: the folder of its source; None: `PATH`).
        self.folder: Path | None = folder
        #: The widgets of the themes failing in an earlier generation of the window (`<theme>:<name>` -> the error, `TemplateError.widget`):
        #: the ones of FF used (`add_theme_widgets()`).
        self.faulty: Mapping[str, str] = faulty or {}
        #: The sizes the layout of an earlier generation of the window gave the widgets (`layout_sizes()`): path -> tag -> size.
        self.sizes: Mapping[str, Mapping[str, int]] = sizes or {}
        #: The geometry tags of the widget uses read by their templates and missing there, given by the layout (`use_value()`): path -> tags.
        self.layout_reads: dict[str, set[str]] = {}
        self.modules: dict[str, XmlModule] = {}
        self.main_module: XmlModule | None = None
        #: `ff:style` -> font name (the skin fonts of the window roles).
        self.font_styles: dict[str, str] = font_styles or {}
        self.frames: list[XmlCallFrame] = []
        self.vars: dict[str, Any] = vars or {}
        #: Variables from `vars` the template has read: name -> repr() of the value at the first read (the cache key),
        #: an empty string for a name the template has looked for and not found (`vars` with it would give other XML).
        self.deps: dict[str, str] = {}
        self._fake_func_args: tuple[Args, KwArgs] = ((), {})
        self._ff_info = Info(manager=self)
        self.e_names = {
            **template_names(),
            'FF': self._ff_info,
        }
        self.e_functions = {
            '___call': self._fake_call,
            'id_of': self.id_of,
            'widget_class': self.widget_class,
            'widget_data': self.widget_data,
            'frame_level': self.frame_level,
            'widget_place': self.widget_place,
            'row_list': self.row_list,
            'row_focused': self.row_focused,
            'list_row_width': self.list_row_width,
            'use_items': self.use_items,
            'use_value': self.use_value,
            'use_tags': self.use_tags,
            'use_room': self.use_room,
            'field_offset': self.field_offset,
            'field_gutter': self.field_gutter,
            'edge_bands': self.edge_bands,
        }
        #: Bindings (`{=expr}` fields) of the generated XML: window property -> binding.
        self.bindings: dict[str, Binding] = {}
        #: The widgets of the window (the manifest) in the document order.
        self.widget_entries: list[WidgetEntry] = []
        #: The widgets being generated (the innermost last).
        self._widget_uses: list[_WidgetUse] = []
        #: The next control ID for a widget.
        self._next_id: int = WIDGET_IDS
        #: The widget declarations by their names (the families of `folder`, read at the first use).
        self._widget_index: dict[str, XmlDefine] | None = None
        #: The widgets of FF replaced by the ones of the active themes (the base of a theme widget of its own name).
        self._replaced: dict[str, XmlDefine] = {}
        #: The roles of the list delegates being generated (a binding there is a role of the list rows), the innermost last.
        self._row_roles: list[dict[str, Binding]] = []
        #: The paths of the widgets used in the rows of the list delegates being generated (a row is drawn twice: its widgets are
        #: the same ones then, `begin_widget()`), the innermost last.
        self._row_widgets: list[set[str]] = []
        #: The lists of the delegates being generated (their control IDs: `row_list()`), the innermost last.
        self._row_lists: list[int] = []
        #: The widths of the rows of the delegates being generated (`list_row_width()`; 0 unknown), the innermost last.
        self._row_widths: list[int] = []
        #: The layouts of the delegates being generated: the focused one (`row_focused()`), the innermost last.
        self._row_focused: list[bool] = []
        #: The output elements around the rows of the delegates being generated (their number in `_outputs`), the innermost last.
        self._row_outputs: list[int] = []
        #: The output elements being built, the innermost last (where a widget lies: `widget_place()`).
        self._outputs: list[ET.Element] = []
        #: Template code evaluator.
        self.evaluator: XmlEval = XmlEval(self)
        self.fmt = XmlFormatter(self.evaluator)
        try:
            # hack checking if namespace is registered
            ET.register_namespace._namespace_map['ff']  # type: ignore [reportFunctionMemberAccess]
        except Exception:
            self.startup()

    @property
    def current_frame(self) -> XmlCallFrame | None:
        return self.frames[-1] if self.frames else None

    def problem(self, message: str) -> None:
        """Report a fault of the template: an error (`TemplateError`, `_process()` adds the position of the element)."""
        raise TemplateError(message)

    def call_chain(self) -> list[str]:
        """Return the positions of the include calls of the current frames, the outermost first."""
        return [frame.call_src for frame in self.frames if frame.call_src]

    def widget_index(self) -> dict[str, XmlDefine]:
        """
        Return the declarations of the widgets by their names (the families are the modules of `folder` with `<ff:widgets>`; read once),
        with the widgets of the active themes (`add_theme_widgets()`).
        """
        if self._widget_index is None:
            if self.folder is None:
                raise TemplateError('Widgets out of the widgets folder')
            index: dict[str, XmlDefine] = {}
            for path in sorted(self.folder.glob('*.xml')):
                for xdef in self.module(path.stem).defines.values():
                    if xdef.widget:
                        if (other := index.get(xdef.name)) is not None:
                            raise TemplateError(f'Widget {xdef.name!r} declared again (first in {other.module.name!r})',
                                                src=xdef.root.get(SRC_ATTR, ''))
                        index[xdef.name] = xdef
            self._widget_index = index
            from ..ff.theme import skin_widgets
            if themes := skin_widgets():
                self.add_theme_widgets(themes)
            elif _rejected_widgets:
                _rejected_widgets.clear()
        return self._widget_index

    def add_theme_widgets(self, themes: dict[Path, tuple[Path, ...]]) -> None:
        """
        Add the widgets of the active themes to the index (`themes`: their folders, the most important first -> their widget families,
        `theme.skin_widgets()`). A widget of the name of a widget of FF replaces it when it keeps its face (`widget_face()`: the
        parameters, the content places, the control names, the control type, the family - all of the declaration of FF; the most important
        theme wins) and it has not failed in the generation of the window (`faulty`), else the one of FF stays (a warning,
        `rejected_widgets()`). Another widget of a theme is its own one: in the index under `<theme>:<name>`, seen in the files of that
        theme only (`widget()`), as the modules of a theme (`include()`). A broken family file of a theme is skipped (a warning), also one
        with code a theme may not have (`theme_fault()`: its widgets of FF names rejected).
        """
        index = self.widget_index()
        replacing: list[XmlDefine] = []
        rejected: dict[str, str] = {}
        for folder, paths in reversed(themes.items()):  # the least important one first: a more important one replaces it
            namespace = folder.name
            for path in paths:
                try:
                    root = parse_template(path, root=folder.parent)
                    if fault := theme_fault(root):
                        rejected.update((name, f'{namespace}: {fault}') for elem in root if elem.tag == '{ff}widget'
                                        and (name := elem.get('name', '')) in index)
                        raise TemplateError(fault)
                    module = self.load_module(path.stem, root, namespace=namespace)
                except TemplateError as exc:
                    fflog.warning(f'Widgets of the theme {namespace}: {exc}, skipped')
                    continue
                self.modules[f'{namespace}:{path.stem}'] = module
                for xdef in module.defines.values():
                    if xdef.widget:
                        if xdef.name in index:
                            replacing.append(xdef)
                        else:
                            index[f'{namespace}:{xdef.name}'] = xdef
        # the faces of FF before any replacement (the bases of a widget of FF may be replaced too)
        faces = {name: self.widget_face(index[name]) for name in {xdef.name for xdef in replacing}}
        fitting: list[XmlDefine] = []
        for xdef in replacing:
            if misfit := self.faulty.get(f'{xdef.module.namespace}:{xdef.name}') or self.widget_face(xdef).misfit(faces[xdef.name]):
                fflog.warning(f'Widget {xdef.name!r} of the theme {xdef.module.namespace}: {misfit}, the one of FF used')
                rejected[xdef.name] = f'{xdef.module.namespace}: {misfit}'
            else:
                fitting.append(xdef)
        for xdef in fitting:
            self._replaced.setdefault(xdef.name, index[xdef.name])
            index[xdef.name] = xdef
        _rejected_widgets.clear()
        _rejected_widgets.update(rejected)

    def theme_widgets(self, src: str) -> set[str]:
        """Return the widgets replacing the ones of FF (`<theme>:<name>`) of the theme of the position (`path:line` in a file of a theme)."""
        namespace = Path(src).parts[0] if src else ''  # the files of a theme: relative to the folder of the themes (`parse_template()`)
        return {key for name in self._replaced if (key := f'{self.widget_index()[name].module.namespace}:{name}').startswith(f'{namespace}:')}

    def widget_face(self, xdef: XmlDefine) -> WidgetFace:
        """Return the face of the widget (`WidgetFace`) from its declaration and the ones of its bases."""
        chain = self.widget_chain(xdef)
        places: set[str] = set()
        controls: set[str] = set()
        control = ''
        for item in reversed(chain):  # the base first: its control is the widget control (a derived body is its content)
            for parent in item.root.iter():
                for child in parent:
                    if child.tag == '{ff}content' and not str(parent.tag).startswith('{gui}'):  # a filler of a use is a child of the use
                        places.add(child.get('name', ''))
                    elif child.tag == '{ff}delegate':
                        places.add(DELEGATE_CONTENT)
                controls.update(mch[1] for text in (*parent.attrib.values(), parent.text or '') for mch in RX_ID_OF.finditer(text))
                if not control and parent.get('id') == '{id}':
                    control = parent.get('type', '')
        return WidgetFace(family=xdef.module.name, params=self.widget_params(xdef), places=frozenset(places), controls=frozenset(controls),
                          control=control)

    def widget(self, name: str, namespace: str = '') -> XmlDefine:
        """Return the declaration of the widget (`widget_index()`); `namespace`: the theme of the file using it - its own widget first."""
        if self.folder is None:
            raise TemplateError(f'Widget {name!r} out of the widgets folder')
        index = self.widget_index()
        if namespace and (xdef := index.get(f'{namespace}:{name}')) is not None:
            return xdef
        try:
            return index[name]
        except KeyError:
            raise TemplateError(f'Unknown widget {name!r}') from None

    def widget_base(self, xdef: XmlDefine) -> XmlDefine:
        """Return the base of the widget (`base=`; of a widget of a theme: its own widget first, the base of its own name is the one of FF)."""
        if xdef.base == xdef.name and xdef.module.namespace and (base := self._replaced.get(xdef.name)) is not None:
            return base
        return self.widget(xdef.base, xdef.module.namespace)

    def widget_chain(self, xdef: XmlDefine) -> list[XmlDefine]:
        """Return the widget and its bases, the widget first."""
        chain = [xdef]
        while chain[-1].base:
            if (base := self.widget_base(chain[-1])) in chain:
                raise TemplateError(f'Widget {xdef.name!r}: a cycle of bases', src=xdef.root.get(SRC_ATTR, ''))
            chain.append(base)
        return chain

    def widget_params(self, xdef: XmlDefine) -> dict[str, XmlDefineParam]:
        """Return the parameters of the widget with the ones of its bases (a widget redefines a parameter of its base)."""
        params: dict[str, XmlDefineParam] = {}
        for item in reversed(self.widget_chain(xdef)):
            params.update(item.params)
        return params

    def begin_widget(self, xdef: XmlDefine, name: str, *, src: str) -> WidgetEntry:
        """Start a widget use: its path (an anonymous one: its widget and a number), its control ID, its manifest entry."""
        # the frame of the window is the window: its widgets and its content are named in the parent of its use
        parent = next((use for use in reversed(self._widget_uses) if WINDOW_FRAME_WIDGET not in use.entry.types), None)
        if not name:
            if parent is not None:
                parent.counts[xdef.name] = count = parent.counts.get(xdef.name, 0) + 1
            else:
                count = sum(1 for entry in self.widget_entries if '.' not in entry.path and entry.types[0] == xdef.name) + 1
            name = f'{xdef.name}{count}'
        path = f'{parent.entry.path}.{name}' if parent is not None else name
        if (old := next((entry for entry in self.widget_entries if entry.path == path), None)) is not None:
            if self._row_widgets and path in self._row_widgets[-1]:  # the other layout of the same row: the same widget
                self._widget_uses.append(_WidgetUse(entry=old))
                return old
            raise TemplateError(f'Widget name {path!r} used again')
        if self._row_widgets:
            self._row_widgets[-1].add(path)
        chain = self.widget_chain(xdef)
        entry = WidgetEntry(path=path, types=tuple(item.name for item in chain), families=tuple(item.module.name for item in chain),
                            ids={'': self._new_id()}, src=src, row=self.widget_place() == 'row')
        self.widget_entries.append(entry)
        self._widget_uses.append(_WidgetUse(entry=entry))
        return entry

    def end_widget(self) -> None:
        """End the current widget use."""
        self._widget_uses.pop()

    def _new_id(self) -> int:
        """Return a new control ID for a widget."""
        self._next_id += 1
        return self._next_id - 1

    def id_of(self, name: str = '') -> int:
        """Return the control ID of the current widget by its name (the same name: the same ID; '': the widget control)."""
        if not self._widget_uses:
            raise TemplateError(f'id_of({name!r}) out of a widget')
        ids = self._widget_uses[-1].entry.ids
        if name not in ids:
            ids[name] = self._new_id()
        return ids[name]

    def widget_class(self) -> type[Widget]:
        """Return the Python class of the current widget (`widgets.widget_class()`): its class methods may make the template data."""
        if not self._widget_uses:
            raise TemplateError('widget_class() out of a widget')
        from .widgets import widget_class
        return widget_class(self._widget_uses[-1].entry)

    def frame_level(self, level: int | str = '') -> int:
        """
        Return the level of the innermost frame being generated (`FRAME_WIDGETS` and their forms among the widget uses): the level its
        use forces (`level`: the parameter of the frame asking for its own level, '' derived), else the one of the frame around it
        + 1 (its content is generated inside the use: a frame in a frame is one level deeper, also under a forced level), 1 the
        outermost one (a panel), 0 none (the window and its frame); over the last level of `SURFACES` the last one and a warning.
        """
        frames = [use for use in self._widget_uses if FRAME_WIDGETS.intersection(use.entry.types)]
        if not frames:
            return 0
        use = frames[-1]
        if use.level is None:  # its template asks first, before its content: the frame around has its level
            outer = frames[-2].level if len(frames) > 1 and frames[-2].level is not None else len(frames) - 1
            use.level = int(level) if level != '' else outer + 1
            if use.level >= len(SURFACES):
                fflog.warning(f'Frame: level {use.level} is over the last one ({SURFACES[-1]}), drawn as that at {use.entry.src}')
                use.level = len(SURFACES) - 1
        return use.level

    def widget_place(self) -> WidgetPlace:
        """
        Return where the current widget lies (asked before its own controls): `row` - in a row of a list (its delegate: no focus there;
        not in an overlay of the row - `OVERLAY_ATTR`: it goes out of the row to the window), `grouplist` - a child of a grouplist (Kodi
        stacks its shown children), `fixed` - any other place (its own position).
        """
        from .geometry import OVERLAY_ATTR  # geometry -> layout -> xgui
        if self._row_roles and not any(elem.get(OVERLAY_ATTR) for elem in self._outputs[self._row_outputs[-1]:]):
            return 'row'
        parent = self._parent_control()
        return 'grouplist' if parent is not None and parent.get('type') == 'grouplist' else 'fixed'

    def take_outermost(self, elem: ET.Element) -> None:
        """Make the element the outermost control of the current widget use: the template attributes of the use on it."""
        use = self._widget_uses[-1]
        use.outermost = elem
        elem.attrib.update(use.attrs or {})
        use.attrs = None

    def _parent_control(self) -> ET.Element | None:
        """Return the output control the next control goes in (None: none, the window)."""
        return next((elem for elem in reversed(self._outputs) if elem.tag == 'control'), None)

    def layout_tags(self, use_attrs: Mapping[str, str]) -> frozenset[str]:
        """
        Return the geometry tags the layout of the parent gives a widget use of the template attributes (asked before the widget): the
        cross axis of a row / column filled (`ff:align` fill, the default), its main axis stretched (`ff:stretch`, `ff:policy` expanding),
        both in a grid cell filled; none out of a layout and in a row of a list.
        """
        parent = self._parent_control()
        layout = parent.get('{ff}layout') if parent is not None else None
        if layout not in ('row', 'column', 'grid') or self.widget_place() == 'row':
            return frozenset()
        fill = use_attrs.get('{ff}align', 'fill') == 'fill'
        if layout == 'grid':
            return frozenset(('width', 'height')) if fill else frozenset()
        main, cross = ('width', 'height') if layout == 'row' else ('height', 'width')
        grows = float(use_attrs.get('{ff}stretch') or 0) > 0 or use_attrs.get('{ff}policy') == 'expanding'
        return frozenset(tag for tag, given in ((cross, fill), (main, grows)) if given)

    def layout_sizes(self, root: ET.Element) -> dict[str, dict[str, int]]:
        """
        Return the sizes the layout gave the widgets whose templates read them missing in their uses (`use_value()`; the output root after
        the layout): path -> tag -> size, the outermost control of each one (`USE_ATTR`).
        """
        sizes: dict[str, dict[str, int]] = {}
        for elem in root.iter('control'):
            if (tags := self.layout_reads.get(path := elem.get(USE_ATTR, ''))) and path not in sizes:
                sizes[path] = {tag: int(text) for tag in tags if (text := elem.findtext(tag) or '').isdigit()}
        return sizes

    def row_list(self) -> int:
        """Return the control ID of the list whose row is being generated (`widget_place()` row), 0 none."""
        return self._row_lists[-1] if self._row_lists else 0

    def list_row_width(self) -> int:
        """Return the width of the row being generated (`widget_place()` row): of its layout, else the width of the use of its list; 0 none, unknown."""
        return self._row_widths[-1] if self._row_widths else 0

    def row_focused(self) -> bool:
        """Return True in the focused layout of the row being generated (a widget in a row: its focusable part there only)."""
        return bool(self._row_focused and self._row_focused[-1])

    def _use_content(self) -> XmlContent:
        """Return the content of the current widget use."""
        if not self._widget_uses or (content := self._widget_uses[-1].content) is None:
            raise TemplateError('The content of a widget use read out of a widget')
        return content

    def _format_use(self, content: XmlContent, text: str) -> str:
        """Return a text of the use formatted in its names (the caller's frame)."""
        if content.frame is not None:
            self.frames.append(content.frame)
        try:
            return self.format(text) if '{' in text else text
        finally:
            if content.frame is not None:
                self.frames.pop()

    def use_items(self, place: str) -> tuple[UseItem, ...]:
        """
        Return the elements of the place `place` of the current widget use - the static items of a widget declared in the template
        (`<ff:content name="items"><item value="a">Alpha</item><separator label="More"/></ff:content>`): their tags, attributes and
        texts formatted in the names of the use.
        """
        content = self._use_content()
        fill = next((el for el in content.elems if el.tag == '{ff}content' and el.get('name') == place), None)
        return tuple(UseItem(tag=str(el.tag), attrs={name: self._format_use(content, value) for name, value in el.attrib.items() if name[:1] != '{'},
                             text=self._format_use(content, (el.text or '').strip()))
                     for el in (() if fill is None else fill) if isinstance(el.tag, str))

    def use_value(self, tag: str) -> int:
        """
        Return the number of a child tag of the current widget use (its geometry: `width`), 0 if it has none (or no number). A geometry
        tag the use has not and its layout gives it (`layout_tags()`) is the size of the layout: the one of an earlier generation of the
        window (`sizes`), else the size of the window for now - the layout takes no hint of the content of the widget there (`SIZED_ATTR`),
        the window is generated again with the sizes of the layout (`gui.render_xml()`).
        """
        content = self._use_content()
        elem = next((el for el in content.elems if el.tag == tag), None)
        if elem is None and tag in (use := self._widget_uses[-1]).layout_tags:
            from .geometry import WINDOW_SIZE  # geometry -> layout -> xgui
            self.layout_reads.setdefault(use.entry.path, set()).add(tag)
            return self.sizes.get(use.entry.path, {}).get(tag) or (WINDOW_SIZE.width if tag == 'width' else WINDOW_SIZE.height)
        try:
            return int(float(self._format_use(content, (elem.text or '').strip()))) if elem is not None else 0
        except ValueError:
            return 0

    def use_tags(self) -> tuple[str, ...]:
        """Return the tags of the child elements of the current widget use (no comments), in their order."""
        return tuple(str(el.tag) for el in self._use_content().elems if isinstance(el.tag, str))

    def use_room(self, tag: str) -> int:
        """
        Return the free room beyond an edge of the current widget use in its parent (asked before its own controls): its geometry tag
        `tag` (`use_value()`: `left`, `top`, `right`, `bottom`) less the band the widget holding it takes there with its own parts
        (`edge_bands()`: the head, the foot of a window frame), 0 at least.
        """
        # ponytail: the bands of the holding widget only, not the siblings (their places are known after the layout pass)
        parent = self._parent_control()
        holder = next((use for use in reversed(self._widget_uses[:-1]) if parent is not None and parent.get('id') == str(use.entry.id)), None)
        return max(0, self.use_value(tag) - (holder.edges.get(tag, 0) if holder is not None else 0))

    def field_gutter(self) -> int:
        """
        Return the gutter of the mark of the form row holding the field (`form_field`: the band of its left edge, `edge_bands(left=…)`),
        0 none: the parts of the field right of it (a spin box: its arrow ‹).
        """
        # ponytail: the nearest use with a left band holds the field (only `form_field` keeps one); a field nested deeper in it gets it too
        return next((use.edges['left'] for use in reversed(self._widget_uses) if 'left' in use.edges), 0)

    def field_offset(self) -> int:
        """Return the left of the text of a field (a text edit, a field button): after the gutter of its form row (`field_gutter()`), else `space.l`."""
        return self.field_gutter() or tokens().space.l

    def edge_bands(self, **bands: int) -> str:
        """
        Keep the bands of the edges of the current widget its own parts take (`top`, `right`, `bottom`, `left`: e.g. the head and the
        foot of a window frame): its content has no free room there (`use_room()`); return '' (usable in a field).
        """
        if not self._widget_uses:
            raise TemplateError('edge_bands() out of a widget')
        self._widget_uses[-1].edges.update(bands)
        return ''

    def keep_template_values(self, entry: WidgetEntry, kwargs: Mapping[str, Any]) -> None:
        """
        Keep the template values of the properties of the widget class (`widgets.TEMPLATE_VALUES`): its parameters of the same names
        (a widget with a base: its own values before the ones of the base).
        """
        from .widgets import TEMPLATE_VALUES, property_names, widget_class
        if names := property_names(widget_class(entry)) & kwargs.keys():
            values = entry.data.setdefault(TEMPLATE_VALUES, {})
            for name in names:
                values.setdefault(name, kwargs[name])

    def widget_data(self, **values: Any) -> str:
        """Keep the template data of the current widget for its class (`WidgetEntry.data`); return '' (usable in a field)."""
        if not self._widget_uses:
            raise TemplateError('widget_data() out of a widget')
        self._widget_uses[-1].entry.data.update(values)
        return ''

    @property
    def current_module(self) -> XmlModule | None:
        return self.frames[-1].module if self.frames else None

    def frame_theme(self, module: XmlModule) -> str:
        """Return the theme of a new frame of a template of the module (`XmlCallFrame.theme`): of the module, else of the current frame."""
        return module.namespace or (self.frames[-1].theme if self.frames else '')

    @property
    def restricted(self) -> bool:
        """The current template is of a theme (its module, `XmlModule.namespace`): its code is restricted (`XmlEval`)."""
        frames = self.frames
        return bool(frames) and bool(frames[-1].module.namespace)

    @property
    def globals(self) -> dict[str, Any]:
        return self.main_module.globals if self.main_module else {}

    def load_module(self,
                    name: str,
                    src: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str],
                    /, *,
                    path: Path | None = None,
                    namespace: str = '',
                    ) -> XmlModule:
        """Create and load module, don't register the module (`namespace`: the theme of the module, registered as `<theme>:<name>`)."""
        if module := self.modules.get(f'{namespace}:{name}' if namespace else name):
            return module
        # if self.auto_register and not self.widgets:
        #     self.register_widgets(XWidget._widget_classes.values())
        module = XmlModule(name=name, manager=self, namespace=namespace)
        # frame for loading module (nodes on global level), frame.globals is module.globals
        frame = XmlCallFrame(module=module, define=XmlDefine(name='', root=ET.Element(''), module=module),
                             locals=module.globals, globals=module.globals)
        self.frames.append(frame)
        try:
            if path is None and isinstance(src, Path):
                path = src
            module.load(src)
            return module
        finally:
            self.frames.pop()

    def module(self,
               name: str,
               *,
               source: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str] | None = None,
               ) -> XmlModule:
        if module := self.modules.get(name):
            return module
        if source is None:
            for path in ((self.folder,) if self.folder is not None else self.PATH):
                path = path / f'{name}.xml'
                if path.exists():
                    module = self.load_module(name, path)
                    break
            else:
                raise ImportError(f'Module {name!r} not found in paths: {", ".join(str(p) for p in self.PATH)}')
        else:
            module = self.load_module(name, source)
        self.modules[name] = module
        return module

    def include(self, module: str | None, name: str | None) -> XmlDefine | None:
        if (current := self.current_module) is not None and current.namespace:  # a file of a theme: its modules first, then the ones of FF
            own = current if module is None else self.modules.get(f'{current.namespace}:{module}')
            if own is not None and (xdef := own.include(name or '')) is not None:
                return xdef
            try:
                return self.module(module or current.name).include(name or '')
            except ImportError:
                if module is None:  # a module of the theme only: no such definition
                    return None
                raise
        if module is None:
            if name is None or self.current_module is None:
                return None
            self.current_module.defines.get(name)
            return self.current_module.defines.get(name)
        if mod := self.module(module):
            return mod.include(name or '')
        return None

    def run(self,
            src: Path | ET.ElementTree[ET.Element[str]] | ET.Element[str] | None,
            /,
            vars: dict[str, Any] | None = None,
            ) -> ET.Element[str] | None:
        """Run template from source and return root element."""
        if src is None:
            module = self.modules.get('__main__')
        else:
            module = self.load_module('__main__', src)
            self.modules['__main__'] = module
        if module is None or module.xml is None or module.xml.src_root is None:
            fflog.warning('No source provided and no __main__ module loaded or no XML')
            return None
        self.main_module = module
        frame = XmlCallFrame(module=module, define=XmlDefine(name='', root=module.xml.src_root, module=module),
                             locals=module.globals, globals=module.globals)
        self.frames.append(frame)
        if vars is not None:
            module.globals.update(vars)
        return module.xml.do()

    # def template(self) -> XmlTemplate:
    #     template = XmlTemplate(manager=self)
    #     return template

    def eval(self, expr: str, *, assignment: bool = False) -> Any:
        """
        Evaluate expression in current context.

        If assignment is True, the expression is treated as statements (Python code, assignments go to the current frame).
        """
        try:
            if assignment:
                return self.evaluator.exec(expr)
            return self.evaluator.eval(expr)
        except Exception as exc:
            fflog.error(f'Error in xml {"code" if assignment else "expression"} {expr!r}: {exc!r}')
            raise

    def var_assign(self, var: str, value: Any) -> Any:
        """Assign value to the variable (or to more variables: "a, b") in the current frame."""
        if (frame := self.current_frame) is None:
            self.problem(f'Assign variable {var!r} without frame')
            return None
        if ',' in var and self.restricted:  # no statement of a theme (`XmlEval.exec()`): the names alone
            names = [name.strip() for name in var.split(',')]
            values = tuple(value)
            if len(names) != len(values) or not all(name.isidentifier() for name in names):
                raise TemplateError(f'Cannot assign {len(values)} values to {var!r}')
            frame.locals.update(zip(names, values))
        elif ',' in var:
            self.evaluator.exec(f'{var} = __value__', extra={'__value__': value})
        else:
            frame.locals[var] = value
        return value

    @overload
    def format(self, format_string: LiteralString, /, *args: LiteralString, **kwargs: LiteralString) -> LiteralString: ...

    @overload
    def format(self, format_string: str, /, *args: Any, **kwargs: Any) -> str: ...

    def format(self, format_string: str, /, *args: Any, **kwargs: Any) -> str:
        """Format string in current context."""
        return self.fmt.format(format_string, *args, **kwargs)

    def formatter(self, *, node: ET.Element | None = None) -> XmlFormatter:
        """Return the formatter of the current context with the element (for the errors): always `with manager.formatter(node=elem) as fmt:`."""
        self.fmt._xml_nodes.append(node)
        return self.fmt

    def _fake_call(self, *args, **kwargs) -> None:
        self._fake_func_args = (args, kwargs)

    def call_func_args(self) -> tuple[Args, KwArgs]:
        return self._fake_func_args

    def _get_eval_name(self, key: str) -> Any:
        if key == 'FF':
            return self._ff_info
        base = {'None': None, 'True': True, 'False': False}
        if (val := base.get(key, ...)) is not ...:
            return val
        if not self.frames:
            return self.e_names[key]
        try:
            return self.template_value(key)
        except KeyError:
            pass
        for container in (self.e_names, self.e_functions):
            try:
                return container[key]
            except KeyError:
                continue
        if not hasattr(builtins, key):  # a builtin is found by Python itself
            self.deps.setdefault(key, '')
        raise KeyError(f'Name {key!r} is not defined in current context')

    def template_value(self, key: str) -> Any:
        """Return value of a template variable (frame, template vars), raise KeyError if there is none."""
        if (frame := self.current_frame) is not None:
            for container in (frame.locals, frame.globals):
                try:
                    return container[key]
                except KeyError:
                    pass
        value = self.vars[key]
        if key not in self.deps:
            self.deps[key] = repr(value)
        return value

    def add_binding(self, kind: BindingKind, text: str, *, source: str, exprs: Sequence[str]) -> Binding:
        """
        Add a binding, capture template values the expressions read (other names are runtime names); a binding of a theme is restricted
        (`Binding.restricted`: its expressions checked now, `theme_code()`).
        """
        if restricted := self.restricted:
            for expr in exprs:
                theme_code(expr.strip())
        captured: dict[str, Any] = {}
        for name in {name for expr in exprs for name in free_names(expr)}:
            try:
                captured[name] = self.template_value(name)
            except KeyError:
                if name not in self.e_names and name != 'win' and not hasattr(builtins, name):
                    self.deps.setdefault(name, '')  # template vars with it would capture it
        if self._row_roles:  # a role of the list rows: the same one in both layouts of a row
            roles = self._row_roles[-1]
            if (same := next((b for b in roles.values()
                              if (b.kind, b.text, b.captured, b.restricted) == (kind, text, captured, restricted)), None)) is not None:
                return same
            binding = Binding(prop=f'ffr.{len(roles) + 1}', text=text, kind=kind, source=source, captured=captured, row=True,
                              restricted=restricted)
            roles[binding.prop] = binding
            return binding
        binding = Binding(prop=f'ffb.{len(self.bindings) + 1}', text=text, kind=kind, source=source, captured=captured, restricted=restricted)
        self.bindings[binding.prop] = binding
        return binding

    # def _make_evaluator(self) -> XmlEval:
    #     evaluator = XmlEval()
    #     evaluator.names.update(self.e_names)
    #     evaluator.functions.update(self.e_functions)
    #     return evaluator

    @classmethod
    def startup(cls) -> None:
        ET.register_namespace('ff', 'ff')
        ET.register_namespace('gui', 'gui')


if __name__ == '__main__':
    from ..ff.cmdline import DebugArgumentParser
    from .geom import Rect, Size, Point

    def parse_var(s: str) -> tuple[str, Any]:
        """Parse variable from command line."""
        from ast import literal_eval
        name, sep, val = s.partition('=')
        if not sep:
            return name, True
        if val.lower() == 'true':
            return name, True
        if val.lower() == 'false':
            return name, False
        return name, literal_eval(val)

    p = DebugArgumentParser()
    p.add_argument('path', nargs='?', type=Path, metavar='PATH',
                   default=Path(__file__).parent.parent / 'resources/skins/Default/1080i/dev.xml')
    p.add_argument('-v', '--var', action='append', default=[], type=parse_var, metavar='NAME[:TYPE]=VALUE', help='variable')
    args = p.parse_args()

    # ET.register_namespace('ff', 'ff')
    # ET.register_namespace('gui', 'gui')
    # path = Path('/tmp/a.xml').expanduser()
    path = args.path.expanduser()

    # XmlManager.startup()
    manager = XmlManager(vars=dict(args.var))
    # mod = manager.module('dev', source=path)
    # x = mod.xml
    if 1:
        root = manager.run(path)
        if root is not None:
            ET.dump(root)
            # if x.dst_root is not None:
            #     from io import BytesIO
            #     # ET.dump(x.dst_root)
            #     tree = ET.ElementTree(x.dst_root)
            #     f = BytesIO()
            #     tree.write(f, encoding='utf-8', xml_declaration=True)
            #     print(f.getvalue().decode('utf-8'))
        print(f'-----\n# {manager.globals = }')
    elif 0:
        x.load(path)
        for e in x:
            print(e, e.attrib)
    elif 1:
        assert x
        x.do(path)
        # ET.dump(x.src_root)
        if x.dst_root is not None:
            from io import BytesIO
            # ET.dump(x.dst_root)
            tree = ET.ElementTree(x.dst_root)
            f = BytesIO()
            tree.write(f, encoding='utf-8', xml_declaration=True)
            print(f.getvalue().decode('utf-8'))
        print(f'# {x.vars = }')
    elif 0:
        wdg = XWidget(geometry=Rect((1, 2), (3, 4)), template=None)
        print(wdg.to_xml())
    elif 0:
        class XAaa(XWidget):
            NAME = 'aaa'
        class Xbbb(XWidget):
            NAME = 'bbb'
        print(XWidget._widget_classes)
