from __future__ import annotations
from typing import Optional, Union, Any, Tuple, Dict, Sequence, Callable, Type, ClassVar, cast, overload, TYPE_CHECKING
from typing_extensions import Self, TypeVar, Generic, Literal
from threading import Thread, Condition
from pathlib import Path
from inspect import ismethod
from functools import wraps
from contextlib import ExitStack
from weakref import ref as weak_ref, WeakMethod, finalize
import hashlib
from time import monotonic, sleep
from attrs import define, frozen, field
from xbmcgui import Window, WindowXML, WindowXMLDialog, Control, ControlList
from xbmcgui import (
    ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_STOP, ACTION_NAV_BACK,
    ACTION_MOUSE_RIGHT_CLICK, ACTION_MOUSE_LONG_CLICK, ACTION_CONTEXT_MENU,
    ACTION_JUMP_SMS2, ACTION_JUMP_SMS9, REMOTE_0, REMOTE_9,
)
from ..ff import control
from ..ff.tricks import MISSING, MissingType, make_mutable_metaclass
from ..ff.threads import Queue, Event
from ..ff.logs import fflog, fflog_exc
from ..service.exc import KodiExit
# from ..ff.debug import logtime
from const import const
if TYPE_CHECKING:
    from xbmcgui import ListItem, Action
    from .gui import CustomXmlData, CustomXmlRequest
    from .bindings import WindowBindings
    from .widgets import Widget, WidgetTree, W as WDG


T = TypeVar('T')
B = TypeVar('B', 'BaseWindow', 'BaseDialog')
#: The window type of `WindowRef`.
W = TypeVar('W', bound='AbstractWindow')
#: A callback (`weak_callback()`, `closes_on_kodi_exit()`).
C = TypeVar('C', bound=Callable[..., Any])
Args = Tuple[Type[T], ...]
KwArgs = Dict[str, Any]
RESULT = TypeVar('RESULT')

Errors = Literal['strict', 'ignore']

#: A frame of Kodi (60 fps): the step of a wait for its next frame (`AbstractWindow.set_focus_shown()`).
KODI_FRAME: float = 1 / 60

#: Type letter in edit-control (on Linux).
ACTION_EDIT_TYPING = 61952
ACTION_EDIT_BACKSPACE = 61448
ACTION_EDIT_DELETE = 61575
EDIT_ACTIONS = {
    ACTION_EDIT_TYPING,
    ACTION_EDIT_BACKSPACE,
    ACTION_EDIT_DELETE,
}

#: Actions (keys) to close / cancel / escape.
CANCEL_ACTIONS = {
    ACTION_PARENT_DIR,
    ACTION_PREVIOUS_MENU,
    # ACTION_PAUSE,
    ACTION_STOP,
    ACTION_NAV_BACK,
}

#: Actions (keys) for context-menu.
MENU_ACTIONS = {
    ACTION_MOUSE_RIGHT_CLICK,
    ACTION_MOUSE_LONG_CLICK,
    ACTION_CONTEXT_MENU,
}


class WindowRef(Generic[W]):
    """
    The window of a helper (a tab of a window, a tree in a window), held weakly (see `AbstractWindow`): reading gives
    the window itself, `ReferenceError` if it is gone.
    """

    def __set_name__(self, owner: type, name: str) -> None:
        """Remember the attribute of the weak reference in the helper."""
        #: The attribute of the weak reference in the helper.
        self.attr: str = f'_{name}_ref'

    @overload
    def __get__(self, obj: None, owner: type | None = None) -> Self: ...

    @overload
    def __get__(self, obj: object, owner: type | None = None) -> W: ...

    def __get__(self, obj: object | None, owner: type | None = None) -> W | Self:
        """Return the window (the descriptor itself on the class)."""
        if obj is None:
            return self
        if (win := getattr(obj, self.attr)()) is None:
            raise ReferenceError(f'The window of {type(obj).__name__} is gone')
        return win

    def __set__(self, obj: object, win: W) -> None:
        """Keep the window weakly."""
        setattr(obj, self.attr, weak_ref(win))


def number_button(action: Action) -> int | None:
    """Return the digit of the action (a remote digit, `JumpSMS<n>` of a remote, the keyboard), None for another action."""
    aid = action.getId()
    if ACTION_JUMP_SMS2 <= aid <= ACTION_JUMP_SMS9:
        return aid - ACTION_JUMP_SMS2 + 2
    if REMOTE_0 <= aid <= REMOTE_9:
        return aid - REMOTE_0
    return None


def weak_callback(func: C | None) -> C | None:
    """
    Return the callback holding its object weakly if it is a bound method (e.g. of the window, see `AbstractWindow`),
    a call of a dead one does nothing (None); other callables (and None) as they are.
    """
    if not ismethod(func):
        return func
    method = WeakMethod(func)

    def call(*args: Any, **kwargs: Any) -> Any:
        """Call the method if its object lives."""
        if (bound := method()) is not None:
            return bound(*args, **kwargs)
        return None

    return cast(C, call)


def closes_on_kodi_exit(callback: C) -> C:
    """
    Decorate a Kodi callback of the window: a Kodi exit in it (e.g. a sign-in waits in `xsleep()`) closes the window
    (`AbstractWindow.kodi_exit()`), Kodi would report it as an error of the callback.
    """
    @wraps(callback)
    def call(self: AbstractWindow, *args: Any, **kwargs: Any) -> Any:
        """Call the callback, a Kodi exit closes the window."""
        try:
            return callback(self, *args, **kwargs)
        except KodiExit as exc:
            fflog(f'[WINDOW] {type(self).__name__}: Kodi exit in {callback.__name__}()')
            self.kodi_exit(exc)
            return None

    return cast(C, call)


#: Aspect ratio mode for ControlImage. 0 = stretch (default)
ASPECT_RATIO_FILL = ASPECT_RATIO_STRETCH = 0
#: Aspect ratio mode for ControlImage. 1 = scale up (crops)
ASPECT_RATIO_CROP = ASPECT_RATIO_SCALE_UP = 1
#: Aspect ratio mode for ControlImage. 2 = scale down (black bar)
ASPECT_RATIO_KEEP = ASPECT_RATIO_SCALE_DOWN = 2


@frozen
class WindowCommand:
    method: Callable
    args: Args
    kwargs: KwArgs


class WindowThread(Thread, Generic[B]):
    """Thread to call window's do_modal() in thread (non blocking)."""

    def __init__(self,
                 win_class: Type[B],
                 name: Optional[str] = None,
                 args: Args = (),
                 kwargs: KwArgs = {},  # noqa: B006
                 ) -> None:
        super().__init__(name=name)
        #: Window class to create the window.
        self.win_class = win_class
        #: Arguments for window create.
        self.args: Args = args
        #: Keyword arguments for window create.
        self.kwargs: KwArgs = kwargs
        #: The window.
        self.win: B | None = None
        #: Thread condition variable for window creation.
        self.win_ready = Condition()
        #: Window commands (do_modal/doModal) queue.
        self.win_commands: Queue[WindowCommand | None] = Queue()
        #: The exception of the window constructor (the creator waiting for the window raises it).
        self.exc: BaseException | None = None

    def run(self) -> None:
        """Do job. Main thread proc."""
        from ..ff.kotools import KodiMonitor
        if const.debug.log_gui:
            fflog.debug(f'••• [TH] create win {self.win_class}, {self.args}, {self.kwargs}')
        try:
            self.win = self.win_class(*self.args, **self.kwargs)
        except BaseException as exc:
            self.exc = exc
        finally:
            if const.debug.log_gui:
                fflog.debug('••• [TH] notify')
            with self.win_ready:
                self.win_ready.notify()
        if self.win is None:
            return
        try:
            # Kodi exit stops the thread (the window closes) for the whole life of the thread, not only of a command
            with KodiMonitor.instance().abort_context(self.stop):
                while True:
                    fflog.debug('••• [TH] wait for command')
                    cmd = self.win_commands.get()
                    fflog.debug(f'••• [TH] {cmd=}')
                    if not cmd:
                        break
                    cmd.method(*cmd.args, **cmd.kwargs)
                    self.win_commands.task_done()
        finally:
            if const.debug.log_gui:
                fflog.debug('••• [TH] close')
            self.win.close()
            # the window keeps its thread (`_thread`): the thread must not keep the window (see `AbstractWindow`)
            self.win = None
        if const.debug.log_gui:
            fflog.debug('••• [TH] finished')

    def command(self, method: Callable, *args, **kwargs) -> None:
        """Postpone window method call."""
        self.win_commands.put(WindowCommand(method, args, kwargs))

    def stop(self) -> None:
        """Stop the window thread."""
        self.win_commands.put(None)


class _WindowMetaClass(type):
    """Base Window meta-class to modify __init__ arguments."""

    def __call__(self, *args, **kwargs):
        return super().__call__(*args, **kwargs).__wrapped__


@frozen
class XmlWindowsArgs:
    xml_filename: str
    script_path: str
    default_skin: str
    default_res: str
    xml_source: Path
    xml_path: Path
    customized_xml: bool
    custom_data: CustomXmlData
    #: The stamp of the environment of the XML (`_customize_xml_stamp()`), '' unknown or not generated.
    env: str = ''

    @property
    def media_path(self) -> Path:
        """Path to media folder for XML."""
        return self.xml_path.parent.parent / 'media'


class AbstractWindow:
    """
    Mix-in class for Window and Dialog with custom XML support.

    Nothing the window keeps may keep the window: the attributes of a Kodi window (a SWIG object) are invisible to
    the GC, a cycle through the window (window → helper → window) is never collected and the window with all it keeps
    (its items) outlives the script (Kodi: "has left several classes in memory"). A helper keeps the window by
    `WindowRef`, a callback of the window by `weak_callback()`.
    """

    XML: ClassVar[str] = ''
    DEFAULT_ACTIONS_ENABLED: ClassVar[bool] = True
    #: The widgets of a window made of them (None: an old window).
    _widget_tree: WidgetTree | None = None
    #: The state of a window opened again (`restore()`): its focus is set after `on_init()`; None: not opened again.
    _reopened: dict[str, Any] | None = None
    #: Python asked for the focus of a control (`setFocusId()`, `setFocus()`) in the open of the window (`onInit()`).
    _focus_asked: bool = False

    if TYPE_CHECKING:
        ff_xml_args: XmlWindowsArgs
        custom_xml_data: CustomXmlData
        #: The window is shown (`onInit()` done) and not closed yet, its controls exist.
        _ready: bool
        #: Set on `onInit()` and on close, see `wait_ready()`.
        _ready_event: Event
        #: Last values of the bindings (window property -> value).
        _binding_values: dict[str, str]
        #: The batches of the bindings (`WindowBindings.batch()`): thread ident -> a refresh is deferred to the end.
        _binding_batches: dict[int, bool]
        #: Last enabled state set by `set_control_enabled()` (control ID -> enabled).
        _control_enabled: dict[int, bool]
        #: The end of the busy section of the open (`_open_busy()`): at the show of the window (`onInit()`), once.
        _end_busy: Callable[[], None]

        def getControl(self, iControlId: int) -> Control: ...

    def setFocus(self, pControl: Control) -> None:
        """Focus the control (Kodi), noted for the default control of the open (`onInit()`)."""
        self._focus_asked = True
        super().setFocus(pControl)  # type: ignore[misc]

    def setFocusId(self, iControlId: int) -> None:
        """Focus the control of the ID (Kodi), noted for the default control of the open (`onInit()`)."""
        self._focus_asked = True
        super().setFocusId(iControlId)  # type: ignore[misc]

    @classmethod
    def widget_source(cls, script_path: str) -> Path:
        """
        Return the source of the window made of widgets: its class name in snake case (`ConfigDialog` -> `config_dialog.xml`);
        a class with no source of its own takes the one of its nearest base class with a source (a variant of a window).
        """
        from ..ff.routing import camel_to_snake
        from .gui import WIDGETS_FOLDER
        folder = Path(script_path) / 'resources' / 'skins' / WIDGETS_FOLDER
        for klass in cls.__mro__:
            if issubclass(klass, AbstractWindow) and (path := folder / f'{camel_to_snake(klass.__name__)}.xml').exists():
                return path
        return folder / f'{camel_to_snake(cls.__name__)}.xml'

    @classmethod
    def xml_vars(cls, **kwargs) -> dict[str, Any] | None:
        """Get custom XML variables for window/dialog to apply in GUI templates."""
        return None

    @classmethod
    def xml_request(cls, **kwargs) -> CustomXmlRequest | None:
        """Get custom XML request for window/dialog."""
        xml_vars = cls.xml_vars(**kwargs)
        if xml_vars is None:
            request = None
        else:
            from .gui import CustomXmlRequest
            request = CustomXmlRequest(vars=xml_vars)
        return kwargs.pop('xml_request', request)

    @classmethod
    def _resolve_args(cls,
                      xmlFilename: Optional[str] = None,
                      scriptPath: Optional[str] = None,
                      defaultSkin: Optional[str] = None,
                      defaultRes: Optional[str] = None,
                      *args,
                      **kwargs,
                      ) -> XmlWindowsArgs:
        """Return the arguments of the Kodi window, its XML generated if not cached (a window of widgets)."""
        if xmlFilename is None:
            xmlFilename = cls.XML
        if scriptPath is None:
            scriptPath = control.addonPath
        if defaultSkin is None:
            defaultSkin = 'Default'
        if defaultRes is None:
            defaultRes = '1080i'  # kodi default: 720p
        xml_folder = Path(scriptPath) / 'resources' / 'skins' / defaultSkin / defaultRes
        xml_source = xml_folder / xmlFilename
        customized_xml = False
        env = ''
        if not xmlFilename and (widget_source := cls.widget_source(scriptPath)).exists():  # a window of widgets
            xml_source, customized_xml = widget_source, True
        if customized_xml:
            # the output next to the default skin XML files: Kodi finds it there with the media folder of the window
            from .skinfonts import fonts_frozen
            with fonts_frozen():  # the fonts of the skin once for the template vars and the generation
                env = _customize_xml_stamp()  # first: it checks the style, the template vars read the style of now (`tokens()`)
                xmlFilename, custom_data = _customize_xml(xml_source, request=cls.xml_request(**kwargs), folder=xml_folder, env=env)
            xml_path = xml_folder / xmlFilename
        else:
            from .gui import CustomXmlData
            xml_path = xml_source
            custom_data = CustomXmlData()
        return XmlWindowsArgs(xmlFilename, scriptPath, defaultSkin, defaultRes, xml_source, xml_path, customized_xml, custom_data, env=env)

    @property
    def widgets(self) -> Widget:
        """Return the root of the widgets of the window (its children: the top widgets; `KeyError` for an old window)."""
        if self._widget_tree is None:
            raise KeyError(f'{type(self).__name__} is not made of widgets')
        return self._widget_tree.root

    @overload
    def find(self, path: str) -> Widget: ...

    @overload
    def find(self, path: str, cls: type[WDG]) -> WDG: ...

    def find(self, path: str, cls: type[WDG] | None = None) -> Any:
        """Return the widget of the window by its path (`KeyError` if there is none)."""
        return self.widgets.find(path) if cls is None else self.widgets.find(path, cls)

    @property
    def bindings(self) -> WindowBindings:
        """Bindings of the window (`{=expr}` template fields), call `refresh()` after the shown data changes (`batch()`: once)."""
        from .bindings import WindowBindings
        return WindowBindings(self)

    @property
    def can_reopen(self) -> bool:
        """Return True if `reopen()` opens the window again (a modal dialog of `BaseDialog.__new__()`); none of this class does."""
        return False

    @property
    def reopening(self) -> bool:
        """Return True if the window is closed by `reopen()` to be opened again at once; none of this class is."""
        return False

    def reopen_state(self) -> dict[str, Any]:
        """
        Return the state of the window an open again restores (`BaseDialog.reopen()`, `restore()`): the path of the widget with the
        focus and the name of its control (no widget: none). A window with its own state extends it (only texts, numbers: never
        the window or its parts).
        """
        if self._widget_tree is None or (widget := self._widget_tree.widget_of(cid := self.focused_id())) is None or widget.entry is None:
            return {}
        return {'focus': widget.path, 'control': next(name for name, wid in widget.entry.ids.items() if wid == cid)}

    def restore(self, state: dict[str, Any]) -> None:
        """
        Restore the state of the window opened again (`reopen_state()` of the closed one) before Kodi shows it (no Kodi controls yet,
        as in `__init__()`); the focus is set after `on_init()`. A window with its own state extends it.
        """
        self._reopened = state

    def _restore_focus(self, state: dict[str, Any]) -> None:
        """Focus the control of the state (`reopen_state()`) if its widget is there and visible, else the focus of the window stays."""
        if not (path := state.get('focus')):
            return
        try:
            widget = self.find(path)
            cid = widget.control_id(state.get('control', ''))
        except KeyError:  # not there any more, an old window
            return
        parent: Widget | None = widget
        while parent is not None and parent.entry is not None:
            if not parent.visible:
                return
            parent = parent.parent
        self.setFocusId(cid)

    def on_closing(self) -> bool | None:
        """Custom function called when window going to close. Custom callback. Return False to cancel software closing."""

    def on_close(self) -> bool | None:
        """Custom function called on window close. Custom callback."""

    def on_init(self) -> bool | None:
        """Kodi call it on window initialization, access to XML controls is allowed from now. Custom callback."""

    def default_action(self, action: Action) -> bool:
        """Handle default action."""
        action_id = action.getId()
        if action_id in CANCEL_ACTIONS:
            self.close()
            return True
        return False

    def on_action(self, action: Action) -> bool | None:
        """Kodi sent the action. Custom callback."""
        if self.default_action(action) is True:
            return True
        return None

    def on_click(self, control_id: int) -> bool | None:
        """Kodi sent the control's click. Custom callback."""

    def on_focus(self, control_id: int) -> bool | None:
        """Kodi sent the control's focus. Custom callback."""

    def on_control(self, control: Control) -> bool | None:
        """Kodi sent all click events on owned and selected controls when the control itself doesn't handle the message. Custom callback."""

    def on_notification(self, sender: str, method: str, data: str) -> bool | None:
        """Kodi notification handler. Custom callback."""

    def on_edit_finished(self, control_id: int) -> bool | None:
        """FanFilm sent the edit control finished editing. Custom callback."""

    def on_number_button(self, button: int) -> bool:
        """FanFilm sent the number button pressed. Custom callback. Return True if handled."""
        return False

    def _base_on_notification(self, sender: str, method: str, data: str) -> None:
        """Kodi notification handler."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onNotification: {sender=}, {method=}, {data=}')
        self.on_notification(sender, method, data)
        if sender == 'xbmc' and method == 'Input.OnInputFinished':
            self.on_edit_finished(self.focused_id())

    def _already_closed(self) -> None:
        """Cleanup if already closed (by Kodi)."""
        from ..ff.kotools import KodiMonitor
        KodiMonitor.instance().remove_watcher(self._base_on_notification)
        self._set_ready(False)
        self.on_close()

    def _close_window(self) -> None:
        """Close the Kodi window and clean up: the one way of a close `on_closing()` let through."""
        super().close()  # type: ignore[reportAttributeAccessIssue]
        self._already_closed()

    def close(self) -> bool:
        if self.on_closing() is False:
            return False
        self._close_window()
        return True

    def kodi_exit(self, exc: KodiExit) -> None:
        """Kodi exits in a callback of the window (`closes_on_kodi_exit()`): close the window."""
        self.close()

    @closes_on_kodi_exit
    def onInit(self) -> None:
        """Kodi call it on window initialization, access to XML controls is allowed from now."""
        from ..ff.kotools import KodiMonitor
        if const.debug.log_gui:
            fflog(' +++++++++ onInit:')
        # Kodi keeps its cancellable busy dialog under a window opened while it waits for the plugin (e.g. play).
        # When this window closes, a quick Back hits the busy dialog and Kodi stops the script, processing other
        # messages meanwhile; a queued plugin call then deadlocks Kodi (K21, K22: CScriptInvocationManager::Stop
        # holds its lock in CPythonInvoker::stop). This window replaces the busy dialog anyway.
        self._end_busy()  # the one of the open, if it opened one
        control.close_busy_dialog()
        self.bindings.refresh()  # at once: `on_init()` may focus a control a binding shows
        self._focus_asked = False
        with self.bindings.batch():
            if self._widget_tree is not None:
                self._widget_tree.apply()
            self.on_init()
            if (state := self._reopened) is not None:  # opened again: the focus of the closed one, over the one of `on_init()`
                self._reopened = None
                self._restore_focus(state)
        if not self._focus_asked and (default := self.custom_xml_data.default_focus):  # a list Kodi could not focus: its items now
            self.setFocusId(default)
        KodiMonitor.instance().add_watcher(self._base_on_notification)
        self._set_ready(True)
        request_windows(self.ff_xml_args.env)  # shown: a worker of the other windows of a new environment no longer competes with it

    def _set_ready(self, ready: bool) -> None:
        """
        Set the window is shown (or closed), wake threads in `wait_ready()`; the inspector keeps the shown windows, the outline of the layout
        counts the generated ones (the Kodi debug info with them).
        """
        was, self._ready = self._ready, ready
        self._ready_event.set()
        if const.dev.inspector.enabled:
            from .inspector import track
            track(self, ready)
        if const.dev.outline.enabled and ready != was and self.ff_xml_args.customized_xml:
            from .outline import track_window
            track_window(ready)

    def wait_ready(self, timeout: Optional[float] = None) -> bool:
        """
        Wait until Kodi shows the window. Return True if it is shown, False if closed (or never shown), on timeout or Kodi exit.

        Kodi loads the window XML and calls `onInit()` only after `doModal()` / `show()`, a thread which updates
        the window must not touch its controls before (they do not exist yet).
        """
        self._ready_event.wait(timeout)
        return self._ready

    @closes_on_kodi_exit
    def onAction(self, action: Action) -> None:
        """Kodi sent the action."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onAction: id = {action.getId()!r}, amount = {action.getAmount1()!r}, {action.getAmount2()!r},'
                  f' button = {action.getButtonCode()!r}')
        if const.dev.inspector.enabled:
            from .inspector import on_action
            if on_action(self, action):
                return
        if const.dev.outline.enabled and action.getId() == const.dev.outline.key:
            from .outline import toggle_outline
            toggle_outline()
            return
        with self.bindings.batch():
            if (btn := number_button(action)) is not None:
                if const.debug.log_gui:
                    fflog(f' +++++++++ onAction / on_number_button: {btn = }')
                if self.on_number_button(btn) is True:
                    return
            if self._widget_tree is not None:  # the widget of the focused control, then its parents
                widget = self._widget_tree.widget_of(self.focused_id())
                while widget is not None and widget.entry is not None:
                    if widget.handle_action(action) is True:
                        return
                    widget = widget.parent
            if self.on_action(action) is True:
                return
            if self.DEFAULT_ACTIONS_ENABLED:
                self.default_action(action)

    @closes_on_kodi_exit
    def onClick(self, controlId: int) -> None:
        """Kodi sent the control's click."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onClick: {controlId = }')
        with self.bindings.batch():
            if self._widget_tree is not None and (widget := self._widget_tree.widget_of(controlId)) is not None:
                if widget.handle_click(controlId) is True:
                    return
            self.on_click(controlId)

    @closes_on_kodi_exit
    def onFocus(self, controlId: int) -> None:
        """Kodi sent the control's focus."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onFocus: {controlId = }')
        if controlId != self.focused_id():  # the focus moved on (e.g. a held key, the window lags behind): its own event comes
            return
        with self.bindings.batch():
            if self._widget_tree is not None:
                self._widget_tree.focus(controlId)
            self.on_focus(controlId)

    @closes_on_kodi_exit
    def onControl(self, control: Control) -> None:
        """Kodi sent all click events on owned and selected controls when the control itself doesn't handle the message."""
        if const.debug.log_gui:
            fflog(f' +++++++++ onControl: {control = }')
        self.on_control(control)

    def focused_id(self) -> int:
        """Return ID of focused control or zero if no focus."""
        try:
            return self.getFocusId()  # type: ignore[reportAttributeAccessIssue]
        except RuntimeError:  # from kodi docs: raises RuntimeError if no control has focus
            return 0

    def get_control(self, control_id: int, type: type[T] = Control) -> T | None:
        """Get control by ID or None if not found."""
        try:
            ctl = cast(T, self.getControl(control_id))
            if type and isinstance(ctl, type):
                return ctl
            return None
        except RuntimeError:
            return None

    def set_control_enabled(self, control_id: int, enabled: bool, *, focusable: bool = False, errors: Errors = 'ignore') -> None:
        """
        Enable or disable control by ID. A disabled `focusable` control looks disabled (a check box) but keeps the focus
        (its help can tell why it is disabled), the window ignores its clicks.
        """
        if self._control_enabled.get(control_id) != (state := bool(enabled or focusable)):  # a Kodi call waits for the GUI lock
            try:
                control = self.getControl(control_id)
            except RuntimeError:
                if errors == 'strict':
                    msg = f'No control {control_id!r} in {self.__class__.__name__}'
                    fflog(msg)
                    raise KeyError(msg)
                return
            self._control_enabled[control_id] = state
            control.setEnabled(state)

    def set_focus(self, control: Control | int) -> None:
        """Set focus to control by ID or Control."""
        if isinstance(control, int):
            self.setFocusId(control)
        else:
            self.setFocus(control)

    def set_focus_shown(self, control_id: int, *, shown: int = 0) -> None:
        """
        Set the focus to a control a window property just shows (its `<visible>`, `shown`: the one of its group - `Control.IsVisible()` of
        Kodi is of the control itself, not of its parents): Kodi shows it at its next frame and refuses the focus of a hidden one (the focus
        lost or moved on: another control has it), so the focus waits till Kodi shows it (at most `const.tune.gui.set_xml_value_lag`).
        """
        from xbmc import getCondVisibility
        end = monotonic() + const.tune.gui.set_xml_value_lag
        while not getCondVisibility(f'Control.IsVisible({shown or control_id})') and monotonic() < end:
            sleep(KODI_FRAME)
        self.setFocusId(control_id)

    def add_items(self, control_id: int, items: Sequence[Union[str, ListItem]]) -> None:
        """
        Set the items of the control list `control_id` (the old ones are removed).

        The list shares a `ListItem` with Kodi, a shown row gets its layout bound to the list. Kodi 21 frees the layouts
        of the rows in the list with the window only: a removed row must not outlive the window (give the list new items,
        keep the removed ones in no cache / cycle), freed after it, it crashes Kodi (`RemoveLookup()` of a freed list).
        """
        control = self.getControl(control_id)
        if isinstance(control, ControlList):
            control.reset()
            control.addItems(items)  # type: ignore[reportArgumentType]  # ControlList.addItems() accepts Sequence[]


class BaseWindow(AbstractWindow, WindowXML, metaclass=make_mutable_metaclass(WindowXML)):

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: str = control.addonPath,
                defaultSkin: str = 'Default',
                defaultRes: str = '1080i',  # '720p',
                *args,
                **kwargs) -> Self:
        t = monotonic()
        obj: BaseWindow
        end_busy = _open_busy()
        try:
            xml_args = cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
            obj = super().__new__(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args)
        except BaseException:
            end_busy()
            raise
        obj._end_busy = end_busy
        finalize(obj, end_busy)  # a window never shown
        obj._ready = False
        obj._ready_event = Event()
        obj._binding_values = {}
        obj._binding_batches = {}
        obj._control_enabled = {}
        obj.custom_xml_data = xml_args.custom_data
        obj.ff_xml_args = xml_args
        obj._widget_tree = _widget_tree(obj, xml_args.custom_data)
        obj.__init__(xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args, **kwargs)
        fflog(f'XML Window {cls.__name__} created in {monotonic() - t:.3f} seconds')
        return obj


class BaseDialog(AbstractWindow, WindowXMLDialog, Generic[RESULT], metaclass=make_mutable_metaclass(WindowXMLDialog)):

    if TYPE_CHECKING:
        _result: RESULT | None
        _exception: Optional[BaseException]
        _closed: bool
        _thread: WindowThread | None
        #: The call which created the dialog (its class, the arguments as given): `reopen()` creates a new one by it; None unknown
        #: (a class of its own `__new__()`: the arguments given to it are not these ones).
        _creation: WindowCommand | None
        #: The state of an open again asked by `reopen()` (`do_modal()` opens it), None not asked.
        _reopen: dict[str, Any] | None

    def __new__(cls,
                xmlFilename: Optional[str] = None,
                scriptPath: Optional[str] = None,
                defaultSkin: Optional[str] = None,
                defaultRes: Optional[str] = None,
                *args,
                modal: bool = True,
                busy: bool = True,
                _call_init: bool = False,
                **kwargs) -> Self:
        t = monotonic()
        obj: Self
        if const.debug.log_gui:
            fflog.debug(f'BaseDialog.__new__({cls=}, {xmlFilename=}, {scriptPath=}, {defaultSkin=}, {defaultRes=}, {args=}, {modal=}, {_call_init=}, ...)')
        # fflog.debug(f'BaseDialog.__new__({cls=}, {xmlFilename=}, {scriptPath=}, {defaultSkin=}, {defaultRes=}, {args=}, {modal=}, {_call_init=}, {kwargs=})')
        end_busy = _open_busy(busy)
        try:
            xml_args = cls._resolve_args(xmlFilename, scriptPath, defaultSkin, defaultRes, *args, **kwargs)
            if modal:
                obj = super().__new__(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res)
                obj._thread = None
            else:
                # for non-blocking dialogs, window is created in thread
                th = WindowThread[Self](super().__new__, name=f'WindowThread.{xml_args.xml_filename}',
                                        args=(cls, xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args))
                if const.debug.log_gui:
                    fflog.debug(f'••• start thread {th}')
                th.start()
                with th.win_ready:
                    if const.debug.log_gui:
                        fflog.debug('••• wait for window')
                    th.win_ready.wait_for(lambda: th.win is not None or th.exc is not None)
                if th.win is None:
                    raise RuntimeError(f'Window {cls.__name__} can not be created: {th.exc!r}') from th.exc
                obj = th.win
                obj._thread = th
        except BaseException:
            end_busy()
            raise
        obj._end_busy = end_busy
        finalize(obj, end_busy)  # a window never shown
        obj._closed = False
        obj._result = None
        obj._exception = None
        obj._creation = None
        if cls.__new__ is BaseDialog.__new__ and modal and not _call_init:  # the defaults: given as they are
            obj._creation = WindowCommand(cls, (xmlFilename, scriptPath, defaultSkin, defaultRes, *args), kwargs if busy else {**kwargs, 'busy': busy})
        obj._reopen = None
        obj._ready = False
        obj._ready_event = Event()
        obj._binding_values = {}
        obj._binding_batches = {}
        obj._control_enabled = {}
        obj.custom_xml_data = xml_args.custom_data
        obj.ff_xml_args = xml_args
        obj._widget_tree = _widget_tree(obj, xml_args.custom_data)
        if _call_init:
            if const.debug.log_gui:
                fflog.debug('••• init')
            obj.__init__(xml_args.xml_filename, xml_args.script_path, xml_args.default_skin, xml_args.default_res, *args, **kwargs)
        if const.debug.log_gui:
            fflog.debug('••• created')
        fflog(f'XML Window {cls.__name__} created in {monotonic() - t:.3f} seconds')
        return obj
        # return ObjectProxy(obj)  # to avoid __init__ call, _WindowMetaClass will remove ObjectProxy

    def __init__(self, *args, **kwargs) -> None:
        """Useless, because WindowXMLDialog uses __new__ only."""
        pass

    def raise_exception(self, exception: BaseException) -> None:
        """Set exception to raise from do_modal() / doModal()."""
        self._exception = exception

    def kodi_exit(self, exc: KodiExit) -> None:
        """
        Kodi exits in a callback: close the dialog, a modal one raises the exit from `do_modal()` (the caller ends as
        without the window); a modeless one only closes (no one waits in `do_modal()`, a kept exception would keep
        its traceback, i.e. the window).
        """
        if self.is_modal():
            self.raise_exception(exc)
        self.close()

    def result(self) -> RESULT | None:
        """Get result of dialog."""
        if self._closed:
            return self._result
        raise RuntimeError('Dialog is not closed yet, call do_modal() or close() first.')

    def set_result(self, result: Any) -> None:
        """Explicit set the result. Useful with do_modal() / doModal()."""
        self._result = result

    def close(self, result: RESULT | MissingType | None = MISSING) -> bool:
        fflog.debug(f'••• going to close (closed={self._closed})')
        if self._closed:
            return True
        if result is not MISSING:
            if TYPE_CHECKING:
                assert not isinstance(result, MissingType)
            self._result = result
        if self.on_closing() is False:
            fflog.debug('••• close cancelled')
            return False  # not closed: the next close() is not a no-op
        self._closed = True
        if self._thread:
            if const.debug.log_gui:
                fflog.debug('••• postpone exit')
            self._thread.stop()
        if const.debug.log_gui:
            fflog.debug('••• close')
        self._close_window()  # not super().close(): it would ask on_closing() again and call on_close() twice
        if const.debug.log_gui:
            fflog.debug('••• finished')
        return True

    @property
    def can_reopen(self) -> bool:
        """Return True if `reopen()` opens the dialog again (a modal one of `BaseDialog.__new__()`), False if it only closes it."""
        return self._creation is not None

    @property
    def reopening(self) -> bool:
        """Return True if the dialog is closed by `reopen()` to be opened again at once (its `do_modal()` opens the new one)."""
        return self._reopen is not None

    def reopen(self, state: dict[str, Any] | None = None) -> None:
        """
        Close the dialog to open it again at once with the state (None: `reopen_state()`): its `do_modal()` creates a new window of
        its class with the same arguments (the window XML generated again: e.g. of a new style), restores the state (`restore()`) and
        returns the result of the new one. Only a modal dialog created by `BaseDialog.__new__()`; another one only closes (logged).
        """
        if self.can_reopen:
            self._reopen = self.reopen_state() if state is None else state
        else:
            fflog(f'[WINDOW] {type(self).__name__}: not opened again (a modeless dialog or its own __new__()), only closed')
        if not self.close():  # `on_closing()` keeps it open: no open again
            self._reopen = None

    def do_modal(self) -> RESULT | None:
        """
        Execute the window. Call do_modal() / doModal() direct (modal) or in thread (modeless). A modal dialog closed by `reopen()`
        is opened again: a new window, its result returned (the caller sees one call).
        """
        result = self._do_modal()
        creation, state, self._reopen = self._creation, self._reopen, None
        while state is not None and creation is not None:  # a local only: neither window keeps the other one (`AbstractWindow`)
            win = creation.method(*creation.args, **creation.kwargs)
            win.restore(state)
            result = win._do_modal()
            state, win._reopen = win._reopen, None
            del win
        return result

    def _do_modal(self) -> RESULT | None:
        """Execute the window once (see `do_modal()`)."""
        if self._thread:
            self.show()
            if const.debug.log_gui:
                fflog.debug(f'••• postpone {self.doModal}')
            if 1 or type(self) is BaseDialog:
                parent_do_modal = super().doModal
            else:
                parent_do_modal = super().do_modal  # type: ignore[reportAttributeAccessIssue]  # called in derived class, then do_modal exists
            fflog.debug(f'••• sending {parent_do_modal}')
            self._thread.command(parent_do_modal)  # the thread itself stops on Kodi exit (`WindowThread.run()`)
            if const.debug.log_gui:
                fflog.debug(f'••• sent {parent_do_modal}')
        else:
            super().doModal()
            self._end_busy()  # closed without its show (no `onInit()`)
            if not self._closed:
                self._closed = True
                self._already_closed()
        if (exc := self._exception) is not None:
            # The dialog must not keep the exception: its traceback holds this frame (and `self`), that cycle
            # runs through a Kodi object, GC can not see it and the dialog with its items leaks (Kodi warns
            # "left several classes in memory" on the interpreter exit).
            self._exception = None
            try:
                raise exc
            finally:
                del exc
        return self._result

    def doModal(self) -> Any:
        """Execute the window. Call doModal direct (modal) or in thread (modeless)."""
        return self.do_modal()

    def is_modal(self) -> bool:
        """Return True if dialog is modal."""
        return not self._thread

    def destroy(self) -> None:
        """Close and clean up."""
        self.close()
        if self._thread:
            self._thread.join()


def _open_busy(busy: bool = True) -> Callable[[], None]:
    """
    Start the busy section of a window open (from the creation of the window to its show: the XML generated if not cached, Kodi loads
    it): the dialog only if the open still runs after `const.tune.gui.xml_busy_delay` (0: never; `busy` False: never, e.g. a window with
    the one under it for its wait). Return its end (once, later calls do nothing): the show of the window (`onInit()`), an error of the
    creation, the window closed or collected without its show.
    """
    stack = ExitStack()
    if busy and (delay := const.tune.gui.xml_busy_delay):
        stack.enter_context(control.busy_section(delay=delay))
    return stack.close


def _widget_tree(win: AbstractWindow, data: CustomXmlData) -> WidgetTree | None:
    """Return the widgets of the window from the manifest of its XML (None: an old window, no widgets)."""
    if not data.widgets:
        return None
    from .widgets import WidgetTree
    return WidgetTree(win, data.widgets)


def _customize_xml(xml_source: Path, *, request: CustomXmlRequest | None = None, folder: Path | None = None,
                   env: str | None = None) -> tuple[str, CustomXmlData]:
    """
    Fix window/dialog source XML to handle what kodi can not. Return the output XML file name and its data. `env`: the stamp of the
    environment (`_customize_xml_stamp()`, None: taken now) - taken before the request of the template vars, which read the style it checks.

    The processing is slow (1-2 s for the sources dialog), the output is cached (a variant for each different template data).
    An output which can not be written is an error: the source is a template (`ff:*`, `{…}`), Kodi can not show it.
    """
    from .gui import CustomXmlRequest, render_xml
    from .xmlcache import customized_xml
    if request is None:
        request = CustomXmlRequest()
    try:
        return customized_xml(xml_source, request, env=_customize_xml_stamp() if env is None else env, render=render_xml,
                              limit=const.tune.gui.xml_variants, folder=folder, instance=_XML_INSTANCE, foreign_ttl=const.tune.gui.xml_foreign_ttl)
    except IOError as exc:
        raise RuntimeError(f'Window XML {xml_source.name} can not be generated: {exc}') from exc


#: Instance (Kodi profile) of the customized XML files: Kodi instances and profiles share the add-on folder.
_XML_INSTANCE: str = hashlib.sha1(control.dataPath.encode('utf-8')).hexdigest()[:8]

#: The file of the profile data with the environment of the last complete `prepare_windows()` (the digest of its stamp).
PREPARED_WINDOWS_FILE: str = 'windows-prepared.stamp'
#: Home window property: the environment (digest) a worker prepares the windows for now (one worker of it in a Kodi session).
PREPARING_WINDOWS_PROPERTY: str = 'fanfilm.windows.preparing'
#: The argument of the worker script (`worker.py`) of the windows only, at once: a window of a new environment was shown, the service
#: started (`environment_hint()`).
WINDOWS_JOB: str = 'windows'
#: The second argument of the worker of the windows: every window again, prepared for the environment or not (the template data of a
#: window changed, e.g. a setting of the sources in the Configuration: a new variant of the same environment).
WINDOWS_AGAIN: str = 'again'


def _prepared_env() -> str:
    """Return the environment (digest) of the last complete `prepare_windows()`, '' never."""
    try:
        return (Path(control.dataPath) / PREPARED_WINDOWS_FILE).read_text(encoding='utf-8')
    except OSError:
        return ''


def request_windows(stamp: str, *, again: bool = False) -> None:
    """
    Start the worker of the windows (`WINDOWS_JOB`) if they are not prepared for the environment of the stamp (a window of it
    is shown: `onInit()`), nor a worker prepares them; any change of the environment, in FF (the Appearance page writes, the
    Configuration opens again) or not (the skin, its colours, the language, a new FF), so the other windows open from the cache.
    `again`: prepared or not (`WINDOWS_AGAIN`: the template data changed in the same environment, the configuration written).
    """
    if not stamp or not const.tune.gui.xml_prepare_delay:
        return  # an old window, unknown dependencies, never prepared
    from .xmlcache import env_digest
    env = env_digest(stamp)
    if not again and (env == _prepared_env() or Window(control.HOME_WINDOW).getProperty(PREPARING_WINDOWS_PROPERTY) == env):
        return
    fflog(f'[WINDOWS] start the worker of the windows ({env}{", again" if again else ""})')
    start_windows_worker(again=again)


def start_windows_worker(*, again: bool = False) -> None:
    """
    Start the worker script of the windows (`WINDOWS_JOB`, `again`: `WINDOWS_AGAIN`). A start of a script ends the reuse of the plugin
    interpreter (the next call is a cold one), the call of this one and its window go on.
    """
    control.execute(f'RunScript({control.plugin_id},{WINDOWS_JOB}{f",{WINDOWS_AGAIN}" if again else ""})')


def environment_hint() -> tuple[str, ...]:
    """
    Return what the service watches of the environment of the windows (`_customize_xml_stamp()`), cheap and changed out of FF: the skin
    of the fonts (`font_stamp()`: Kodi, the skin, its version and files, its font, the symbol font), its colour theme, the language. A change
    starts the worker of the windows, which takes the whole stamp.
    """
    from xbmc import getInfoLabel, getLanguage
    from .skinfonts import font_stamp
    return (*font_stamp(), getInfoLabel('Skin.CurrentColourTheme'), getLanguage())


def prepare_windows(*, requested: bool = False, again: bool = False) -> int:
    """
    Generate the default variant (no arguments: what the routes open) of every window of widgets into the XML cache
    of the instance, as its first open would (`_resolve_args()`: the same stamp, instance and folder). Run by the worker
    script after a FanFilm update, `const.tune.gui.xml_prepare_delay` after its call (Kodi has its own start to do; 0: never),
    `requested` (a window of a new environment shown, `request_windows()`; the service: its start, a change of the skin...): at once.
    Nothing to do if the last complete run was of the same environment (`PREPARED_WINDOWS_FILE`) or a worker of it runs, unless `again`
    (the template data changed: a window with its variant cached costs the read of its manifest); a worker of another
    environment (a newer one) ends this one. After every window the worker waits as long as the window took (half of a core
    at most); the Kodi exit ends it at once in a wait, after the window of the moment in a generation: its announcement (`System.OnQuit`,
    the FF monitor of the worker sees it) comes long before the abort of the scripts (Kodi stops the services first, all the Python
    of Kodi shares one GIL). A change of the environment (`environment_hint()`, after every window) ends it without the stamp: the check
    of the service starts the worker of the new one. Return the number of the windows done (generated or found cached).
    """
    from .. import info
    from ..ff.kotools import kodi_abort_event
    from ..ff.threads import xsleep_until_exit
    if (monitor := info.script_monitor) is None or monitor.abortRequested() or kodi_abort_event.is_set():  # the worker watches both from its start
        return 0
    if not (delay := const.tune.gui.xml_prepare_delay) or (not requested and xsleep_until_exit(delay)):
        return 0  # never (the first open of a window generates it) or Kodi exits
    hint = environment_hint()  # before the stamp: a change between them ends the worker after its first window
    if not (stamp := _customize_xml_stamp()):
        return 0  # unknown dependencies: nothing is cached
    from .xmlcache import env_digest
    env = env_digest(stamp)
    prepared = Path(control.dataPath) / PREPARED_WINDOWS_FILE
    if not again and _prepared_env() == env:
        fflog(f'[WINDOWS] prepared already ({env})')
        return 0
    home = Window(control.HOME_WINDOW)
    if not again and home.getProperty(PREPARING_WINDOWS_PROPERTY) == env:
        fflog(f'[WINDOWS] a worker of this Kodi session took them ({env})')
        return 0
    # Checked, then set: two workers started at the same moment both run (the cache takes it). One attempt of an environment in a Kodi
    # session: an error (the worker logs it) keeps the property - it would come again, a worker started by every shown window
    # (`request_windows()`) would end the reuse of the plugin interpreter each time; the first open of a window generates it, the next
    # session tries again.
    home.setProperty(PREPARING_WINDOWS_PROPERTY, env)
    from .render import window_classes
    from .skinfonts import fonts_frozen
    started = monotonic()
    count = 0
    with fonts_frozen():  # the fonts of the skin once for all the windows
        for cls in window_classes():
            if home.getProperty(PREPARING_WINDOWS_PROPERTY) != env:
                fflog(f'[WINDOWS] {count} windows prepared, a worker of another environment goes on')
                return count
            start = monotonic()
            try:
                cls._resolve_args()
            except Exception:
                fflog_exc()
            count += 1
            # ponytail: the window of the moment is never cut (a Pi 4: up to 2.8 s, the configuration), a check inside the generation if it matters
            if xsleep_until_exit(monotonic() - start):
                fflog(f'[WINDOWS] {count} windows prepared, Kodi exits')
                return count  # no Kodi call: the stopping Kodi holds the GUI lock (a window property waits for it)
            if environment_hint() != hint:  # the next windows would be of another environment, under the stamp of this one
                if home.getProperty(PREPARING_WINDOWS_PROPERTY) == env:
                    home.clearProperty(PREPARING_WINDOWS_PROPERTY)  # this environment may come back (the skin switched back)
                fflog(f'[WINDOWS] {count} windows prepared, the environment changed (the service starts its worker)')
                return count
    try:
        prepared.parent.mkdir(parents=True, exist_ok=True)
        prepared.write_text(env, encoding='utf-8')
    except OSError:
        fflog_exc()
    home.clearProperty(PREPARING_WINDOWS_PROPERTY)
    fflog(f'[WINDOWS] {count} windows prepared ({env}) in {monotonic() - started:.2f} s')
    return count


def _customize_xml_stamp() -> str:
    """Return stamp of the environment the customized XML depends on, or empty string if unknown."""
    try:
        import cdefs
        from xbmc import getLanguage
        from ..kodi import version_info
        from .skinfonts import font_stamp
        from .style import check_style
        from .gui import texture_stamp
        from .xgui import widget_stamp
        from ..ff.filecache import mtime_stamp
        addon = Path(control.addonPath)
        # only the XML files (`rglob('*')` made a Path of every texture and output file: half of every cached window open)
        files = [path for path in (addon / 'resources' / 'skins').rglob('*.xml') if not path.name.startswith('tmp--')]
        files.extend(Path(__file__).parent.glob('*.py'))
        files.extend((Path(__file__).parent / 'widgets').glob('*.py'))  # the widget classes: their template data (`frames.py` ...)
        files.extend((addon / 'lib' / 'ff' / 'tricks.py', addon / 'lib' / 'ff' / 'format.py', addon / 'lib' / 'kolang.py',
                      addon / 'const.py', addon / 'cdefs.py'))
        files.extend((addon / 'resources' / 'language').rglob('*.po'))  # L() texts
        if cdefs.local_path is not None and cdefs.local_path.is_file():
            files.append(cdefs.local_path)
        if not (mtimes := mtime_stamp(files)):
            return ''
        # font_stamp(): skin, fontset; check_style(): the style files read again if changed; texture_stamp(): the textures of the themes
        # (after the style: the variant of their surface); widget_stamp(): the widgets of the themes
        return repr((control.addonInfo('version'), font_stamp(), check_style().stamp, texture_stamp(), widget_stamp(), getLanguage(),
                     tuple(version_info), mtimes))
    except Exception:
        fflog_exc()
        return ''
