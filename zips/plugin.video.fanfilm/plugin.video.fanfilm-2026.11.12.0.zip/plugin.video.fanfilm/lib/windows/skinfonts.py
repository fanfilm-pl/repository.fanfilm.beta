"""
Fonts of the active skin and text metrics, as Kodi computes them; the colours of the skin FF may take (its text, its accent).

Kodi has no API for fonts nor for text measuring. Here the font declarations are read like `GUIFontManager` does
(skin `Font.xml` with the skin includes, the active fontset, add-on fonts of `kodi.resource.font` since Kodi 22)
and the width of a text is computed from the TTF tables like `CGUIFontTTF` does (advance rounded to pixels per glyph,
synthetic bold / light, no kerning in the width).
"""

from __future__ import annotations

import os
import re
import struct
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
from typing import Generator, TYPE_CHECKING
from contextlib import contextmanager
from xml.etree import ElementTree as ET

from attrs import asdict, frozen, field
from ..ff.utils import RX_LABEL_TAG, strip_label_tags

if TYPE_CHECKING:
    from typing import Callable, Iterable, Iterator, TypeAlias

#: Condition evaluator of skin includes (`condition` attribute), e.g. `xbmc.getCondVisibility`.
Condition: TypeAlias = 'Callable[[str], bool]'
#: Include parameters: name -> value.
Params: TypeAlias = 'dict[str, str]'

#: Kodi `GLYPH_STRENGTH_BOLD` (embolden strength divider).
GLYPH_STRENGTH_BOLD: int = 24
#: Kodi `GLYPH_STRENGTH_LIGHT` (negative embolden for "lighten").
GLYPH_STRENGTH_LIGHT: int = -48

#: $PARAM[name] reference in include definitions.
RX_PARAM = re.compile(r'\$PARAM\[([^\]]*)\]')
#: Label tags as font styles.
LABEL_STYLES: dict[str, str] = {'B': 'bold', 'I': 'italics', 'LIGHT': 'lighten',
                                'UPPERCASE': 'uppercase', 'LOWERCASE': 'lowercase', 'CAPITALIZE': 'capitalize'}


# --- TrueType tables ---


@frozen
class FontFile:
    """Metrics of a TrueType font file (only what the text width and the line height need)."""

    #: Font file path.
    path: Path
    #: Font units per em.
    units_per_em: int
    #: hhea ascender (font units).
    ascender: int
    #: hhea descender (font units, negative).
    descender: int
    #: hhea line gap (font units).
    line_gap: int
    #: Code point -> glyph index.
    cmap: dict[int, int] = field(repr=False)
    #: Glyph index -> advance width (font units); glyphs past the list use the last one.
    advances: tuple[int, ...] = field(repr=False)

    @classmethod
    def load(cls, path: Path | str) -> FontFile:
        """Read the font file (the first font of a collection)."""
        return _load_font_file(str(path))

    def glyph(self, ch: str) -> int:
        """Return glyph index of the character (0 is the "missing" glyph)."""
        return self.cmap.get(ord(ch), 0)

    def advance(self, ch: str) -> int:
        """Return the advance width of the character in font units."""
        gid = self.glyph(ch)
        return self.advances[min(gid, len(self.advances) - 1)]

    def missing(self, text: str) -> str:
        """Return the characters of the text the font has no glyph for (Kodi draws a box), without duplicates."""
        return ''.join(dict.fromkeys(ch for ch in text if not ch.isspace() and ord(ch) not in self.cmap))


@lru_cache(maxsize=32)
def _load_font_file(path: str) -> FontFile:
    """Parse head, hhea, hmtx and cmap of a TTF (or the first font of a TTC)."""
    data = Path(path).read_bytes()
    base = struct.unpack_from('>I', data, 12)[0] if data[:4] == b'ttcf' else 0
    num_tables = struct.unpack_from('>H', data, base + 4)[0]
    tables: dict[bytes, int] = {}
    for i in range(num_tables):
        tag, _checksum, offset, _length = struct.unpack_from('>4sIII', data, base + 12 + 16 * i)
        tables[tag] = offset
    units_per_em = struct.unpack_from('>H', data, tables[b'head'] + 18)[0]
    ascender, descender, line_gap = struct.unpack_from('>hhh', data, tables[b'hhea'] + 4)
    num_hmetrics = struct.unpack_from('>H', data, tables[b'hhea'] + 34)[0]
    advances = tuple(struct.unpack_from('>H', data, tables[b'hmtx'] + 4 * i)[0] for i in range(num_hmetrics))
    num_glyphs = struct.unpack_from('>H', data, tables[b'maxp'] + 4)[0]
    cmap = {code: gid for code, gid in _read_cmap(data, tables[b'cmap']).items() if gid < num_glyphs}  # FreeType drops the others
    return FontFile(path=Path(path), units_per_em=units_per_em, ascender=ascender, descender=descender, line_gap=line_gap,
                    cmap=cmap, advances=advances)


def _read_cmap(data: bytes, cmap: int) -> dict[int, int]:
    """Read the best unicode cmap subtable: format 12 (full unicode) before format 4 (BMP)."""
    count = struct.unpack_from('>H', data, cmap + 2)[0]
    subtables: dict[int, int] = {}
    for i in range(count):
        platform, encoding, offset = struct.unpack_from('>HHI', data, cmap + 4 + 8 * i)
        if platform == 0 or (platform == 3 and encoding in (1, 10)):
            fmt = struct.unpack_from('>H', data, cmap + offset)[0]
            subtables.setdefault(fmt, cmap + offset)
    if 12 in subtables:
        pos = subtables[12]
        groups = struct.unpack_from('>I', data, pos + 12)[0]
        result: dict[int, int] = {}
        for g in range(groups):
            start, end, gid = struct.unpack_from('>III', data, pos + 16 + 12 * g)
            result.update(zip(range(start, end + 1), range(gid, gid + end - start + 1)))
        return result
    if 4 in subtables:
        pos = subtables[4]
        seg_x2 = struct.unpack_from('>H', data, pos + 6)[0]
        ends = pos + 14
        starts = ends + seg_x2 + 2
        deltas = starts + seg_x2
        ranges = deltas + seg_x2
        result = {}
        for s in range(0, seg_x2, 2):
            end, start = struct.unpack_from('>H', data, ends + s)[0], struct.unpack_from('>H', data, starts + s)[0]
            delta, range_offset = struct.unpack_from('>h', data, deltas + s)[0], struct.unpack_from('>H', data, ranges + s)[0]
            for code in range(start, min(end, 0xFFFE) + 1):
                if range_offset:
                    gid = struct.unpack_from('>H', data, ranges + s + range_offset + 2 * (code - start))[0]
                    gid = (gid + delta) & 0xFFFF if gid else 0
                else:
                    gid = (code + delta) & 0xFFFF
                if gid:
                    result[code] = gid
        return result
    return {}


# --- font declarations ---


@frozen
class SkinFont:
    """Font declared in a fontset (`<font>` of Font.xml)."""

    #: Font name used by the controls (`<font>font13</font>`).
    name: str
    #: Declared file name (as in Font.xml).
    filename: str
    #: Size in the skin resolution units (em height).
    size: int = 20
    #: Styles: bold, italics, lighten, uppercase, lowercase, capitalize.
    styles: frozenset[str] = frozenset()
    #: Horizontal aspect.
    aspect: float = 1.0
    #: Line spacing factor.
    linespacing: float = 1.0
    #: Resolved font file (None if not found: Kodi uses arial.ttf then).
    path: Path | None = None

    @property
    def file(self) -> FontFile | None:
        """Font file metrics, None if the file is not found."""
        return FontFile.load(self.path) if self.path else None

    def text_width(self, text: str, *, px_scale: float | None = None) -> float:
        """Text width in GUI units, see `text_width()`."""
        return text_width(text, self, px_scale=px_scale)

    def line_height(self, *, px_scale: float | None = None) -> float:
        """Line height in GUI units (Kodi `GetLineHeight`: linespacing × face height)."""
        ff = self.file
        if ff is None:
            return float(self.size) * self.linespacing
        height = (ff.ascender - ff.descender + ff.line_gap) * self.size / ff.units_per_em
        if px_scale:
            height = round(height * px_scale) / px_scale
        return height * self.linespacing

    def missing(self, text: str) -> str:
        """Characters of the text without a glyph in this font (Kodi has no fallback font: a box is drawn)."""
        ff = self.file
        return ff.missing(strip_label_tags(text)) if ff else ''


def text_width(text: str, font: SkinFont, *, px_scale: float | None = None) -> float:
    """
    Return the width of a single line label in GUI units (the units of the font size).

    Kodi formatting tags ([B], [LIGHT], [UPPERCASE], [COLOR] …) are applied. Kodi rounds the advance of every glyph
    to screen pixels: give `px_scale` (screen pixels per GUI unit, e.g. screen width / window width) to get the same
    rounding, without it the exact value is returned. Not counted: kerning (Kodi does not count it either),
    the overhang of the last glyph, tabs, ligatures.
    """
    ff = font.file
    if ff is None:
        return 0.0
    scale = px_scale or 1.0
    ppem = font.size * scale  # em in pixels (ponytail: square pixels, Kodi takes the embolden strength from the vertical scale)
    total = 0.0
    for part, styles in _label_parts(text, font.styles):
        part = _transform(part, styles)
        dx = 0.0  # advance change of the synthetic bold / light (Kodi SetGlyphStrength, measured live)
        if 'bold' in styles:
            dx += ppem / GLYPH_STRENGTH_BOLD
        if 'lighten' in styles:
            dx += ppem / GLYPH_STRENGTH_LIGHT
        for ch in part:
            adv = ff.advance(ch) * ppem * font.aspect / ff.units_per_em
            if px_scale:
                total += round(round(adv) + dx)
            else:
                total += adv + dx
    return total / scale


def _label_parts(text: str, styles: frozenset[str]) -> Iterator[tuple[str, frozenset[str]]]:
    """Split a label to (text, styles) parts by the Kodi formatting tags ([CR] counts as nothing: one line only)."""
    current = set(styles)
    pos = 0
    for mch in RX_LABEL_TAG.finditer(text):
        if mch.start() > pos:
            yield text[pos:mch.start()], frozenset(current)
        pos = mch.end()
        style = LABEL_STYLES.get(mch[2].upper())
        if style:
            if mch[1]:
                current.discard(style)
            else:
                current.add(style)
    if pos < len(text):
        yield text[pos:], frozenset(current)


def _transform(text: str, styles: frozenset[str]) -> str:
    """Apply the case styles."""
    if 'uppercase' in styles:
        return text.upper()
    if 'lowercase' in styles:
        return text.lower()
    if 'capitalize' in styles:
        return text.title()
    return text


# --- skin includes (GUIIncludes subset: what Font.xml needs) ---


class SkinIncludes:
    """Include definitions of a skin and their resolution like Kodi `CGUIIncludes` (no constants, expressions, defaults)."""

    def __init__(self, folder: Path, *, condition: Condition | None = None) -> None:
        #: Skin resolution folder (the base of `file` includes).
        self.folder: Path = folder
        #: Condition evaluator; without it every condition is false (like Kodi with an unknown condition).
        self.condition: Condition = condition or (lambda cond: False)
        #: Include name -> (definition body, default parameters).
        self.includes: dict[str, tuple[ET.Element, Params]] = {}
        #: Control type -> its default values (`<default type="label">`, Kodi `m_defaultNodes`).
        self.defaults: dict[str, ET.Element] = {}
        #: Loaded files.
        self.files: set[Path] = set()

    def load(self, path: Path) -> None:
        """Load include definitions from a file (`<includes>`), nested `<include file>` too."""
        if path in self.files or not path.is_file():
            return
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError:
            return  # ponytail: TinyXML of Kodi accepts some broken XML (raw `&`, `--->`), the definitions of such a file are lost
        if root.tag.lower() != 'includes':
            return
        self.files.add(path)
        for child in root.findall('include'):
            name = child.get('name')
            if name and (len(child) or (child.text or '').strip()):
                definition = child.find('definition')
                params = self._params(child, 'default')
                if params and definition is None:
                    continue  # Kodi: invalid include definition
                self.includes.setdefault(name, (child if definition is None else definition, params))
            elif child.get('file'):
                cond = child.get('condition')
                if not cond or self.condition(cond):
                    self.load(self.folder / child.get('file', ''))
        for child in root.findall('default'):
            if kind := child.get('type'):
                self.defaults.setdefault(kind, child)

    def resolve(self, node: ET.Element) -> None:
        """Resolve includes in the node and its children (in place)."""
        self._resolve_includes(node)
        for child in list(node):
            self.resolve(child)

    def _resolve_includes(self, node: ET.Element) -> None:
        """Replace `<include>` children of the node by the definitions."""
        skip: set[int] = set()
        while True:
            include = next((ch for ch in node if ch.tag == 'include' and id(ch) not in skip), None)
            if include is None:
                return
            if include.get('file'):
                self.load(self.folder / include.get('file', ''))
            cond = include.get('condition')
            if cond and not self.condition(cond):
                skip.add(id(include))
                continue
            if include.get('content'):
                name, params = include.get('content', ''), self._params(include, 'value')
            else:
                name, params = (include.text or '').strip(), {}
            found = self.includes.get(name)
            if found is None:
                skip.add(id(include))
                continue
            body, defaults = found
            params = {**defaults, **params}
            index = list(node).index(include)
            for i, child in enumerate(ch for ch in body if ch.tag != 'param'):
                inserted = deepcopy(child)
                node.insert(index + i, inserted)
                self._resolve_params(inserted, params, node)
            node.remove(include)

    @staticmethod
    def _params(include: ET.Element, attr: str) -> Params:
        """Collect `<param name="x" value|default="…">` or `<param name="x">…</param>`."""
        params: Params = {}
        for param in include.findall('param'):
            name = param.get('name')
            if name:
                params.setdefault(name, param.get(attr, param.text or ''))
        return params

    def _resolve_params(self, node: ET.Element, params: Params, parent: ET.Element) -> None:
        """Replace $PARAM[…] in attributes, text and children; drop a `<param>` forwarding an undefined param."""
        for key, value in node.attrib.items():
            if (new := self._subst(value, params)) is None:
                if node.tag == 'param' and key == 'value' and parent.tag == 'include':
                    parent.remove(node)
                    return
                new = ''
            node.set(key, new)
        if node.text and '$PARAM[' in node.text:
            if (new := self._subst(node.text, params)) is None:
                if node.tag == 'param' and parent.tag == 'include':
                    parent.remove(node)
                    return
                new = ''
            node.text = new
        for child in list(node):
            self._resolve_params(child, params, node)

    @staticmethod
    def _subst(value: str, params: Params) -> str | None:
        """Substitute params; None if the value is exactly one undefined `$PARAM[x]` (Kodi special case)."""
        mch = RX_PARAM.fullmatch(value)
        if mch and mch[1] not in params:
            return None
        return RX_PARAM.sub(lambda m: params.get(m[1], ''), value)


# --- skin fonts ---


@frozen
class FontPaths:
    """Where Kodi looks for a font file not given by a full path (in this order)."""

    #: Skin `fonts/` folder.
    skin: Path
    #: `special://home/media/Fonts`, `special://xbmc/media/Fonts`.
    media: tuple[Path, ...] = ()
    #: `resources/` folders of the `kodi.resource.font` add-ons.
    resources: tuple[Path, ...] = ()
    #: Add-ons folders, for `resource://<addon>/<file>`.
    addons: tuple[Path, ...] = ()

    def find(self, filename: str) -> Path | None:
        """Return the font file path or None."""
        if filename.startswith('resource://'):
            addon, _, file = filename[len('resource://'):].partition('/')
            return next((p for p in (_find_nocase(a / addon / 'resources', file) for a in self.addons) if p), None)
        if Path(filename).is_absolute():
            return Path(filename) if Path(filename).is_file() else None
        name = Path(filename).name
        for folder in (self.skin, *self.media, *self.resources):
            if (path := _find_nocase(folder, name if folder != self.skin else filename)):
                return path
        return None


def _find_nocase(folder: Path, name: str) -> Path | None:
    """Find a file like Kodi `TranslatePathConvertCase` (exact name, then any case of the file name)."""
    path = folder / name
    if path.is_file():
        return path
    if path.parent.is_dir():
        lower = path.name.lower()
        return next((p for p in path.parent.iterdir() if p.name.lower() == lower and p.is_file()), None)
    return None


def skin_resolution_folders(skin_path: Path) -> list[Path]:
    """Return resolution folders of the skin (`<res folder>` of addon.xml), the default one first."""
    root = ET.parse(skin_path / 'addon.xml').getroot()
    res = sorted(root.iter('res'), key=lambda r: r.get('default', '').lower() != 'true')
    folders = [skin_path / r.get('folder', '') for r in res if r.get('folder')]
    return [f for f in folders if f.is_dir()] or [skin_path / 'xml']


def skin_files_stamp(skin_path: Path) -> str:
    """
    Return a stamp of the files the skin fonts and colours are read from (every XML of the resolution folders: `Font.xml` and the
    include files; `fonts/*.xml`, `colors/*.xml`): their number and the latest change. A skin edited in place (a git branch) keeps
    its version. '' unknown.
    """
    try:
        files = [entry for folder in (*skin_resolution_folders(skin_path), skin_path / 'fonts', skin_path / 'colors') if folder.is_dir()
                 for entry in os.scandir(folder) if entry.name.lower().endswith('.xml')]
        return f'{len(files)}:{max((entry.stat().st_mtime_ns for entry in files), default=0)}'
    except (OSError, ET.ParseError):
        return ''


def read_fontset(root: ET.Element, fontset: str) -> tuple[ET.Element | None, str]:
    """Return the fontset element with the id (case insensitive) and the id of the first fontset."""
    first = ''
    for fs in root.findall('fontset'):
        fid = fs.get('id', '')
        first = first or fid
        if fid.lower() == fontset.lower():
            return fs, first
    return None, first


def parse_fonts(fontset: ET.Element, paths: FontPaths) -> Iterator[SkinFont]:
    """Yield `.ttf` fonts of a fontset element (includes already resolved)."""
    for node in fontset.findall('font'):
        name, filename = (node.findtext('name') or '').strip(), (node.findtext('filename') or '').strip()
        if not name or not filename.lower().endswith('.ttf'):
            continue
        yield SkinFont(name=name, filename=filename, size=_num(node.findtext('size'), int, 20),
                       styles=frozenset((node.findtext('style') or '').split()),
                       aspect=_num(node.findtext('aspect'), float, 1.0), linespacing=_num(node.findtext('linespacing'), float, 1.0),
                       path=paths.find(filename) or paths.find('arial.ttf'))


def _num(text: str | None, kind: Callable[[str], int | float], default: int | float) -> int | float:
    """Convert number or return default (Kodi XMLUtils::GetInt / GetFloat)."""
    try:
        return kind((text or '').strip())
    except ValueError:
        return default


def skin_fonts(skin_path: Path, fontset: str, paths: FontPaths, *, condition: Condition | None = None,
               addon_font_files: Iterable[Path] = ()) -> dict[str, SkinFont]:
    """
    Return fonts of the skin fontset like Kodi `GUIFontManager::LoadFonts` (the first declaration of a name wins).

    The fontset is searched in Font.xml, then in `fonts/*.xml` of the skin, then the first fontset is used.
    `addon_font_files` are `resources/Font.xml` of the enabled `kodi.resource.font` add-ons (Kodi 22+): the fontset
    named like the skin one first, then their first (base) fontset.
    """
    fonts: dict[str, SkinFont] = {}

    def add(fs: ET.Element) -> None:
        for font in parse_fonts(fs, paths):
            fonts.setdefault(font.name, font)

    folders = skin_resolution_folders(skin_path)
    includes = SkinIncludes(folders[0], condition=condition)
    candidates = [f / 'Font.xml' for f in folders if (f / 'Font.xml').is_file()][:1]
    candidates += sorted((skin_path / 'fonts').glob('*.xml'))
    first = ''
    for path in candidates:
        root = ET.parse(path).getroot()
        if root.find('.//include') is not None:
            includes.load(folders[0] / 'Includes.xml')  # only when needed: big skins have many include files
            includes.resolve(root)
        fs, fid = read_fontset(root, fontset)
        first = first or fid
        if fs is not None:
            add(fs)
            break
    else:
        if first:
            return skin_fonts(skin_path, first, paths, condition=condition, addon_font_files=addon_font_files)
    for path in addon_font_files:
        root = ET.parse(path).getroot()
        fs, fid = read_fontset(root, fontset)
        if fs is not None:
            add(fs)
        base, _ = read_fontset(root, fid)
        if base is not None:
            add(base)
    return fonts


# --- skin colours ---


#: The default colour theme of a skin (`Skin.CurrentColourTheme`): only `colors/defaults.xml`.
DEFAULT_COLOUR_THEME: str = 'SKINDEFAULT'
#: An ARGB colour (`AARRGGBB`).
RX_ARGB: re.Pattern[str] = re.compile(r'[0-9A-Fa-f]{8}')
#: A colour value Kodi evaluates (`CGUIInfoColor::Parse`): a skin variable `$VAR[…]`, an info label `$INFO[…]`.
RX_COLOR_EXPRESSION: re.Pattern[str] = re.compile(r'\$(?:VAR|INFO)\[', re.IGNORECASE)
#: The file of the colours of the active skin (`SkinSeeds`) in the FF profile folder (a cold interpreter does not read the skin).
SKIN_COLOR_FILE: str = 'skin_text_color.json'
#: The default text colour of a label of a skin (`<default type>/<tag>[@<attribute>]` of its includes).
TEXT_SOURCE: str = 'label/textcolor'
#: The sources of the accent of a skin (the colour of its focus) in their order, the first one fit wins (`fit_accent()`): the tint of
#: the focus texture of a button, of an edit field, the colour of a selected label.
ACCENT_SOURCES: tuple[str, ...] = ('button/texturefocus@colordiffuse', 'edit/texturefocus@colordiffuse', 'label/selectedcolor')
#: The least opacity of an accent of a skin (less: a shade, e.g. a dimmed focus of a list).
ACCENT_OPACITY: int = 0x80
#: The geometry tags of a control (its place and size, as Kodi reads them: `CGUIControlFactory::Create`): missing, Kodi takes the
#: place and the size of its parent - unless the defaults of the skin give one (`SkinSeeds.blocked`).
GEOMETRY_TAGS: tuple[str, ...] = ('left', 'right', 'centerleft', 'centerright', 'width', 'posx',
                                  'top', 'bottom', 'centertop', 'centerbottom', 'height', 'posy', 'offsetx', 'offsety')
#: The tags of a control FF never takes from the defaults of the skin (`SkinSeeds.blocked`): its geometry (FF lays the windows out) and
#: the tint of all its textures (`colordiffuse`, e.g. Mimic LR: a button, a radio button in the colour of its focus over the FF ones).
BLOCKED_TAGS: tuple[str, ...] = (*GEOMETRY_TAGS, 'colordiffuse')


@frozen
class SkinColor:
    """A colour of a skin and where it is from."""

    #: Its source (`ACCENT_SOURCES`).
    source: str
    #: The colour (`AARRGGBB`) or an expression Kodi evaluates (`RX_COLOR_EXPRESSION`, `skin_accent()`).
    value: str


@frozen(kw_only=True)
class SkinSeeds:
    """
    What FF takes from a skin (`skin_seeds()`): its colours, the tags of the defaults of its controls FF blocks; read once for the skin,
    its version and its colour theme (`SKIN_COLOR_FILE`).
    """

    #: The default text colour of a label (`AARRGGBB`), '' unknown.
    text: str = ''
    #: The candidates of the accent in their order (`ACCENT_SOURCES`): a colour fit as an accent (`fit_accent()`) or an expression.
    accents: tuple[SkinColor, ...] = ()
    #: The named colours of the colour theme (the value of an expression may be a name), {} without an expression.
    colors: dict[str, str] = field(factory=dict, hash=False)
    #: The tags FF blocks (`BLOCKED_TAGS`) the defaults of the controls give: control type -> its tags (Kodi adds them to a control lacking them).
    blocked: dict[str, tuple[str, ...]] = field(factory=dict, hash=False)


#: The colours of the active skin: (skin, its version, its colour theme) and its seeds.
_skin_seeds: tuple[tuple[str, ...], SkinSeeds] | None = None


def skin_colors(skin_path: Path, colour_theme: str, *, system: Path | None = None) -> dict[str, str]:
    """
    Return the named colours of the skin like Kodi `CGUIColorManager`: the colours of Kodi (`system`: `special://xbmc/system/colors.xml`,
    None none), `colors/defaults.xml` of the skin over them, the colour theme (its file) over it.
    """
    folder = skin_path / 'colors'
    files = [system, _find_nocase(folder, 'defaults.xml')]  # any case (Kodi lists the colour themes so)
    if colour_theme and colour_theme.upper() != DEFAULT_COLOUR_THEME:
        files.append(_find_nocase(folder, colour_theme if colour_theme.lower().endswith('.xml') else f'{colour_theme}.xml'))
    colors: dict[str, str] = {}
    for path in files:
        try:
            root = ET.parse(path).getroot() if path is not None else None
        except (OSError, ET.ParseError):
            continue
        for color in (root.iter('color') if root is not None else ()):
            if (name := color.get('name')) and (value := (color.text or '').strip()):
                colors[name] = value
    return colors


def named_color(value: str, colors: dict[str, str]) -> str:
    """Return the colour (`AARRGGBB`) of a colour value of the skin: a named colour (`colors`; a name of a name too) or ARGB; '' unknown."""
    for _ in range(len(colors)):  # a named colour may name another one
        if value not in colors:
            break
        value = colors[value]
    return value.upper() if RX_ARGB.fullmatch(value) else ''


def fit_accent(color: str, text: str) -> bool:
    """Return True for a colour (`AARRGGBB`, '' none) fit as an accent of a skin: opaque enough (`ACCENT_OPACITY`), another one than the text."""
    return bool(color) and int(color[:2], 16) >= ACCENT_OPACITY and color[2:] != text[2:]


def skin_seeds(skin_path: Path, colour_theme: str, *, condition: Condition | None = None, system: Path | None = None) -> SkinSeeds:
    """
    Return the colours of the skin FF may take, of the defaults of its controls (`<default type>` of its includes) and its named colours
    (`skin_colors()`): the default text colour of a label, the candidates of the accent (`ACCENT_SOURCES`; an expression kept: Kodi
    evaluates it at its use, `skin_accent()`); the tags of the defaults FF blocks (`BLOCKED_TAGS`).
    """
    folder = skin_resolution_folders(skin_path)[0]
    includes = SkinIncludes(folder, condition=condition)
    if (path := _find_nocase(folder, 'Includes.xml')) is not None:
        includes.load(path)
    colors = skin_colors(skin_path, colour_theme, system=system)

    def value(source: str) -> str:
        """Return the value of the source in the defaults of the controls, '' none."""
        kind, _, place = source.partition('/')
        tag, _, attribute = place.partition('@')
        if (default := includes.defaults.get(kind)) is None:
            return ''
        includes.resolve(default)
        if (node := default.find(tag)) is None:
            return ''
        return (node.get(attribute, '') if attribute else node.text or '').strip()

    text = named_color(value(TEXT_SOURCE), colors)
    accents: list[SkinColor] = []
    for source in ACCENT_SOURCES:
        if RX_COLOR_EXPRESSION.match(seed := value(source)):
            accents.append(SkinColor(source, seed))
        elif fit_accent(color := named_color(seed, colors), text):
            accents.append(SkinColor(source, color))
    expressions = any(RX_COLOR_EXPRESSION.match(accent.value) for accent in accents)
    blocked: dict[str, tuple[str, ...]] = {}
    for kind, default in includes.defaults.items():
        includes.resolve(default)
        if tags := tuple(tag for tag in BLOCKED_TAGS if default.find(tag) is not None):
            blocked[kind] = tags
    return SkinSeeds(text=text, accents=tuple(accents), colors=colors if expressions else {}, blocked=blocked)


def skin_accent(seeds: SkinSeeds, info_label: Callable[[str], str]) -> SkinColor | None:
    """
    Return the accent of the skin of the seeds: the first candidate fit (`fit_accent()`), an expression evaluated by `info_label` (Kodi
    `getInfoLabel()`: a skin setting changes it at once) and its named colour; None none.
    """
    for seed in seeds.accents:
        color = named_color(info_label(seed.value).strip(), seeds.colors) if RX_COLOR_EXPRESSION.match(seed.value) else seed.value
        if fit_accent(color, seeds.text):
            return SkinColor(seed.source, color)
    return None


def skin_text_color(skin_path: Path, colour_theme: str, *, condition: Condition | None = None) -> str:
    """
    Return the default text colour of a label of the skin (`<default type="label"><textcolor>` of its includes, a named colour of
    the colour theme resolved): `AARRGGBB`, '' unknown (no default, an expression).
    """
    return skin_seeds(skin_path, colour_theme, condition=condition).text


def active_skin_seeds() -> SkinSeeds:
    """
    Return the colours of the active skin FF may take (`skin_seeds()`), kept while the skin, its version and its colour theme are the
    same (a cold interpreter reads them from `SKIN_COLOR_FILE` while the skin files and the colours of Kodi are the same).
    """
    global _skin_seeds
    from xbmc import getCondVisibility, getInfoLabel, getSkinDir
    skin, colour_theme = getSkinDir(), getInfoLabel('Skin.CurrentColourTheme')
    key = (skin, getInfoLabel(f'System.AddonVersion({skin})'), colour_theme)
    if _skin_seeds is not None:
        known, seeds = _skin_seeds
        if known == key:  # ponytail: a skin edited in place is seen by a new interpreter (the stamp of its files), not by a warm one
            return seeds
    from xbmcvfs import translatePath
    from ..ff import control
    from ..ff.filecache import cached_json, mtime_stamp
    from ..ff.logs import fflog_exc
    skin_path = Path(translatePath('special://skin'))
    system = Path(translatePath('special://xbmc')) / 'system' / 'colors.xml'
    code = mtime_stamp([Path(__file__), *((system,) if system.is_file() else ())])  # the reading of the skin is this module
    files = skin_files_stamp(skin_path)
    try:
        data = cached_json(Path(control.dataPath) / SKIN_COLOR_FILE, repr((key, files, code)) if code and files else '',
                           lambda: asdict(skin_seeds(skin_path, colour_theme, condition=getCondVisibility, system=system)))
        seeds = SkinSeeds(text=data['text'], accents=tuple(SkinColor(**accent) for accent in data['accents']), colors=data['colors'],
                          blocked={kind: tuple(tags) for kind, tags in data['blocked'].items()})
    except Exception:
        fflog_exc()
        seeds = SkinSeeds()
    _skin_seeds = key, seeds
    return seeds


def active_skin_text_color() -> str:
    """Return the default text colour of a label of the active skin (`active_skin_seeds()`), '' unknown."""
    return active_skin_seeds().text


def active_skin_accent() -> SkinColor | None:
    """Return the accent of the active skin (`skin_accent()`: an expression evaluated by Kodi now), None none."""
    from xbmc import getInfoLabel
    return skin_accent(active_skin_seeds(), getInfoLabel)


# --- font roles (`ff:style`) ---


#: The font every skin has (Kodi falls back to it): the "normal" role.
NORMAL_FONT: str = 'font13'
#: The sizes of the normal font to choose (`normal_fonts()`): the least and the most ratio to the size of font13 (a bigger one: the
#: switches of the accounts page do not fit, `render check`).
NORMAL_FONT_RANGE: tuple[float, float] = (.8, 1.2)
#: Names of the symbol fonts (resource.font.fanfilm, Kodi 22+): `fanfilm_symbol_<size>`.
RX_SYMBOL_FONT = re.compile(r'fanfilm_symbol_(\d+)')
#: Suffix of a symbol style (`normal.symbol`): the symbol font of the size of the role font.
SYMBOL_SUFFIX: str = '.symbol'
#: Styles changing the letters or slanting, not for a role font.
ODD_STYLES: frozenset[str] = frozenset({'uppercase', 'lowercase', 'capitalize', 'italics'})
#: Font file weights by the file name: (regex, weight), the first match wins; regular is 0.
FILE_WEIGHTS: tuple[tuple[re.Pattern[str], int], ...] = (
    (re.compile(r'black|heavy|extrabold|ultrabold', re.IGNORECASE), 3),
    (re.compile(r'semibold|demibold|medium', re.IGNORECASE), 1),
    (re.compile(r'bold', re.IGNORECASE), 2),
    (re.compile(r'thin|extralight|light', re.IGNORECASE), -1),
)


def font_family(font: SkinFont) -> str:
    """Family of the font: the file name before the first `-` / `_` (ponytail: no name table, the file names are regular)."""
    return re.split(r'[-_.]', Path(font.filename).name.lower(), maxsplit=1)[0]


def font_weight(font: SkinFont) -> int:
    """Weight of the font: from the file name, bold style is bold (2)."""
    weight = next((w for rx, w in FILE_WEIGHTS if rx.search(Path(font.filename).stem)), 0)
    return max(weight, 2) if 'bold' in font.styles else weight


def font_roles(fonts: dict[str, SkinFont], roles: dict[str, tuple[float, bool]], tolerance: float, normal_font: str = NORMAL_FONT) -> dict[str, str]:
    """
    Return `ff:style` -> font name: `normal` is `normal_font` (a skin font, font13 if the skin has no such font), the other roles the
    nearest font of its family.

    `roles` are role -> (size ratio to the normal font, bold). A role font is in `tolerance` of the target size, without
    case or italic styles, the nearest weight first (bold, or the normal one), then the nearest size; without one
    it is the normal font. Every role has its `<role>.symbol` style too: the symbol font
    of the nearest size if there is one (Kodi 22 + resource.font.fanfilm), otherwise the role font.
    """
    if normal_font not in fonts:
        normal_font = NORMAL_FONT
    result = {'normal': normal_font, **{role: normal_font for role in roles}}
    normal = fonts.get(normal_font)
    if normal is not None:
        family = font_family(normal)
        candidates = [f for f in fonts.values() if font_family(f) == family and not (f.styles & ODD_STYLES)]
        for role, (ratio, bold) in roles.items():
            target, weight = normal.size * ratio, 2 if bold else font_weight(normal)
            near = [f for f in candidates if abs(f.size - target) <= tolerance * target]
            near.sort(key=lambda f: (abs(font_weight(f) - weight), abs(f.size - target), f.styles != normal.styles,
                                     not f.name.startswith('font'), f.name))
            if near:
                result[role] = near[0].name
    symbols = {int(m[1]): name for name in fonts if (m := RX_SYMBOL_FONT.fullmatch(name))}
    for role, name in list(result.items()):
        size = fonts[name].size if name in fonts else 30
        result[f'{role}{SYMBOL_SUFFIX}'] = symbols[min(symbols, key=lambda s: abs(s - size))] if symbols else name
    return result


def normal_fonts(fonts: dict[str, SkinFont]) -> list[SkinFont]:
    """
    Return the fonts the normal role may be (the text size of the windows, the token `font.normal`): the fonts of the family, weight,
    styles and aspect of font13 within `NORMAL_FONT_RANGE` of its size, one of a size (a `font…` name first), by their sizes; none
    without font13.
    """
    if (base := fonts.get(NORMAL_FONT)) is None:
        return []
    least, most = (ratio * base.size for ratio in NORMAL_FONT_RANGE)
    sizes: dict[int, SkinFont] = {}
    for font in sorted(fonts.values(), key=lambda f: (not f.name.startswith('font'), f.name)):
        if (least <= font.size <= most and font.styles == base.styles and font.aspect == base.aspect and font_family(font) == font_family(base)
                and font_weight(font) == font_weight(base)):
            sizes.setdefault(font.size, font)
    return [sizes[size] for size in sorted(sizes)]


def choose_symbol(variants: Iterable[str], font: SkinFont | None) -> str:
    """Return the first variant the font can draw (no missing glyph), the last one when none (a text fallback)."""
    variants = tuple(variants)
    if font is not None:
        for text in variants:
            if not font.missing(text):
                return text
    return variants[-1]


# --- Kodi glue ---


def kodi_font_paths() -> FontPaths:
    """Font search folders of the running Kodi."""
    from xbmcvfs import translatePath
    home, xbmc_root = Path(translatePath('special://home')), Path(translatePath('special://xbmc'))
    addons = (home / 'addons', xbmc_root / 'addons')
    resources = tuple(p / 'resources' for a in addons for p in sorted(a.glob('resource.font.*')))
    return FontPaths(skin=Path(translatePath('special://skin')) / 'fonts', media=(home / 'media' / 'Fonts', xbmc_root / 'media' / 'Fonts'),
                     resources=resources, addons=addons)


def kodi_addon_font_files() -> list[Path]:
    """`resources/Font.xml` of the enabled `kodi.resource.font` add-ons, Kodi 22+ only (older Kodi ignores them)."""
    import json
    from xbmc import executeJSONRPC, getInfoLabel
    from xbmcvfs import translatePath
    try:
        if int(getInfoLabel('System.BuildVersion').split('.', 1)[0]) < 22:
            return []
    except ValueError:
        return []
    query = {'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
             'params': {'type': 'kodi.resource.font', 'enabled': True, 'properties': ['path']}}
    addons = json.loads(executeJSONRPC(json.dumps(query))).get('result', {}).get('addons', [])
    files = (Path(translatePath(a['path'])) / 'resources' / 'Font.xml' for a in addons)
    return [f for f in files if f.is_file()]


def active_skin_fonts() -> dict[str, SkinFont]:
    """Fonts of the active skin and fontset (the skin and add-on declarations), as loaded by Kodi."""
    from xbmc import getCondVisibility, getInfoLabel
    from xbmcvfs import translatePath
    return skin_fonts(Path(translatePath('special://skin')), getInfoLabel('Skin.Font'), kodi_font_paths(),
                      condition=getCondVisibility, addon_font_files=kodi_addon_font_files())


def screen_px_scale(window_width: int = 1920) -> float:
    """Screen pixels per GUI unit of a window of the width (1080i: 1920), for `text_width(px_scale=…)`."""
    from xbmcgui import getScreenWidth
    return getScreenWidth() / window_width


#: The add-on with the symbol fonts (`fanfilm_symbol_<size>`, Kodi 22+).
SYMBOL_ADDON: str = 'resource.font.fanfilm'

#: The file of the fonts of the active skin in the FF profile folder, kept by `font_stamp()`: a cold interpreter does not
#: read the skin (`Font.xml` and the include files of a big skin are most of the cold open of a window).
FONTS_FILE: str = 'skin_fonts.json'

#: Window fonts cache: (font stamp and the font roles of the style, fonts, `ff:style` -> font name).
_window_fonts: tuple[tuple[object, ...], dict[str, SkinFont], dict[str, str]] | None = None
#: The window fonts are frozen (`fonts_frozen()`): the cache is used without checking its stamp.
_frozen: int = 0


@contextmanager
def fonts_frozen() -> Generator[None, None, None]:
    """
    Keep the window fonts as they are for the block (one window generation and its template vars): `font_stamp()` asks Kodi
    five times (each waits for the GUI lock), a generation measures hundreds of texts. The outermost block checks the stamp
    once (the fonts of a changed skin read), a nested one costs nothing.
    """
    global _frozen
    if not _frozen:
        window_fonts()
    _frozen += 1
    try:
        yield
    finally:
        _frozen -= 1


def font_stamp() -> tuple[str, ...]:
    """What the window fonts depend on: Kodi, skin and its version, its font files (`skin_files_stamp()`), fontset, the symbol font add-on."""
    from xbmc import getCondVisibility, getInfoLabel, getSkinDir
    from xbmcvfs import translatePath
    skin = getSkinDir()
    return (getInfoLabel('System.BuildVersion'), skin, getInfoLabel(f'System.AddonVersion({skin})'),
            skin_files_stamp(Path(translatePath('special://skin'))), getInfoLabel('Skin.Font'),
            str(getCondVisibility(f'System.AddonIsEnabled({SYMBOL_ADDON})')))


def window_fonts() -> tuple[dict[str, SkinFont], dict[str, str]]:
    """Return fonts of the active skin and `ff:style` -> font name, kept while `font_stamp()` and the font roles of the style are the same."""
    global _window_fonts
    if _frozen and _window_fonts is not None:
        return _window_fonts[1], _window_fonts[2]
    from .style import tokens
    stamp = font_stamp()
    roles = style_roles()
    normal = str(tokens().font.normal)
    key = (stamp, sorted(roles.items()), normal)  # another style (its files changed) may have other roles, another normal font
    if _window_fonts is None or _window_fonts[0] != key:
        from const import const
        from ..ff.logs import fflog_exc
        try:
            fonts = stored_skin_fonts(stamp)
        except Exception:
            fflog_exc()
            fonts = {}  # every role is font13 then
        _window_fonts = (key, fonts, font_roles(fonts, roles, const.tune.gui.font_role_tolerance, normal))
    return _window_fonts[1], _window_fonts[2]


def style_roles() -> dict[str, tuple[float, bool]]:
    """
    Return the font roles of the windows (`ff:style`): the font tokens of the style of a size ratio (`font.<role>`: `font.group` too),
    the tuning of `const.tune.gui.font_roles` over them.
    """
    from const import const
    from .style import tokens
    roles = {name[len('font.'):]: value for name, value in tokens().values.items() if name.startswith('font.') and isinstance(value, tuple)}
    return {**roles, **const.tune.gui.font_roles}


def stored_skin_fonts(stamp: tuple[str, ...]) -> dict[str, SkinFont]:
    """Return the fonts of the active skin (`active_skin_fonts()`) kept in `FONTS_FILE` while the font stamp and this module are the same."""
    from ..ff import control
    from ..ff.filecache import cached_json, mtime_stamp
    code = mtime_stamp([Path(__file__)])  # the reading of the skin is this module
    data = cached_json(Path(control.dataPath) / FONTS_FILE, repr((stamp, code)) if code else '',
                       lambda: [{**asdict(font, recurse=False), 'styles': sorted(font.styles), 'path': str(font.path) if font.path else None}
                                for font in active_skin_fonts().values()])
    return {font['name']: SkinFont(**{**font, 'styles': frozenset(font['styles']), 'path': Path(font['path']) if font['path'] else None}) for font in data}


def symbol_variants() -> dict[str, tuple[str, ...]]:
    """Symbols: name -> variants, the first one the font draws is used, the last one is the text fallback."""
    from ..kolang import L
    return {
        'check': ('✔', '✓', L(30698, 'yes')),
        'cross': ('✘', '✗', L(30699, 'no')),
        'star': ('★', '*'),
        'star_half': ('⯨', '½'),
        'star_empty': ('☆', '-'),
        'play': ('⏵', '▶', '>'),
        'pause': ('⏸', '||'),
        'stop': ('⏹', '■', '[]'),
        'warning': ('⚠', '!'),
        'info': ('ⓘ', 'i'),
        'bullet': ('•', '-'),
        'square': ('■', '◼', '█', '●', '•', '#'),  # a color sample ([COLOR] of the text)
        'plus': ('＋', '+'),
        'minus': ('−', '-'),
        'up': ('▲', '↑', '^'),
        'down': ('▼', '↓', 'v'),
        'ascending': ('↑↑', '^^'),   # the direction of a sort
        'descending': ('↓↓', 'vv'),
        'left': ('◀', '←', '<'),
        'right': ('▶', '→', '>'),
        'sync': ('⟳', '↻', '@'),
        'edit': ('✎', '*'),
        'cached': ('⚡', '↯', '+'),
    }


def style_font(style: str) -> SkinFont | None:
    """Return the font of the `ff:style` (an unknown style: font13) in the active skin, None if its file is not known (no measuring)."""
    fonts, styles = window_fonts()
    font = fonts.get(styles.get(style, NORMAL_FONT))
    return font if font is not None and font.path is not None else None


def text_metrics(style: str) -> tuple[Callable[[str], float], float]:
    """
    Return the text width function and the line height (GUI units) of the font of the template style (`ff:style`), as Kodi
    draws (rounded to the screen pixels).
    """
    from functools import partial
    if (font := style_font(style)) is None:
        return (lambda text: len(text) * 11.0), 30.0  # no skin fonts (CLI without a skin), no font file: an estimate
    px_scale = screen_px_scale()
    return partial(font.text_width, px_scale=px_scale), font.line_height(px_scale=px_scale)


def break_label(label: str, width: Callable[[str], float], limit: float) -> str:
    """Return the label broken (`[CR]`) into two lines of the most even widths if it is wider than the limit (else as it is)."""
    if width(label) <= limit or ' ' not in label:
        return label
    words = label.split(' ')
    cuts = [(' '.join(words[:i]), ' '.join(words[i:])) for i in range(1, len(words))]
    first, second = min(cuts, key=lambda cut: max(width(cut[0]), width(cut[1])))
    return f'{first}[CR]{second}'


def symbol(name: str, style: str = 'normal') -> str:
    """
    Return the symbol for a text in the `ff:style` font: the first variant the font draws.

    In our windows `<role>.symbol` is the symbol font (Kodi 22 + resource.font.fanfilm) or the role font, a plugin
    list (skin controls) is about `normal` (font13).
    """
    fonts, styles = window_fonts()
    return choose_symbol(symbol_variants()[name], fonts.get(styles.get(style, NORMAL_FONT)))
