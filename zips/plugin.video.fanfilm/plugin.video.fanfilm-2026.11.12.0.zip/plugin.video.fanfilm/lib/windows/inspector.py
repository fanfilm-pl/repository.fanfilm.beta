"""
The inspector of the FF windows (a developer tool, `const.dev.inspector`): the snapshot of a window (its widgets: paths,
classes, control IDs, sources, properties, signals with their slots, rectangles, the Kodi state, the window properties,
the style tokens) as JSON, a small HTTP server for the page in a browser and for the command line (the windows, a snapshot,
a Kodi screenshot, a property change, the outline of the layout shown / hidden, the selected widget highlighted in it, a style token
tried in the preview layer, saved into the local style or dropped: the window opened again shows it), the key in a window (a snapshot
to a file).

The server runs in its own thread from the first shown FF window of the interpreter until the last one closes or Kodi
aborts (it never keeps the interpreter). It never touches a window: a snapshot and a property change are commands run in
the window thread - Kodi calls the window back with the action `noop` sent to it (`on_action()`); the request waits for
them shortly.

    python -m lib.windows.inspector tree <snapshot.json | http://127.0.0.1:8387/>
    python -m lib.windows.inspector diff <a.json | url> <b.json | url>
    python -m lib.windows.inspector get <url> [-o snapshot.json]
    python -m lib.windows.inspector set <url> <widget path> <property> <JSON value>
    python -m lib.windows.inspector token <url> <token> <JSON value | null>
    python -m lib.windows.inspector token-save <url>
    python -m lib.windows.inspector token-drop <url>
"""

from __future__ import annotations
from typing import Any, Callable, Iterable, Iterator, TYPE_CHECKING
from typing_extensions import TypeAlias
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, HTTPServer
from ipaddress import ip_address
from itertools import count
from pathlib import Path
from time import monotonic, strftime
from urllib.parse import parse_qsl, urlsplit
from weakref import ref as weak_ref
import hmac
import json
import re
import sys
from xml.etree import ElementTree as ET
from attrs import define, field
from xbmcgui import ACTION_NOOP
from ..ff.logs import fflog, fflog_exc
from ..ff.threads import Event, Lock, Thread
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action
    from .base import AbstractWindow
    from .style import Origin
    from .widgets import Widget

#: A snapshot of a window, a list of the windows (JSON data).
Snapshot: TypeAlias = 'dict[str, Any]'

#: A window property the generated XML reads: `Window.Property(ffw.20010.text)`.
RX_WINDOW_PROPERTY: re.Pattern[str] = re.compile(r'Window\.Property\(([\w.]+)\)')
#: How long a request waits for the window thread (seconds).
COMMAND_TIMEOUT: float = 3.0
#: How long a request waits for the Kodi screenshot (seconds).
SCREENSHOT_TIMEOUT: float = 5.0
#: The end of a PNG file (its IEND chunk): the screenshot is written whole.
PNG_END: bytes = b'IEND\xaeB`\x82'
#: A longer list / mapping value of a property is shown by its size only.
MAX_ITEMS: int = 50
#: The page of the inspector.
PAGE: Path = Path(__file__).resolve().parents[2] / 'resources' / 'inspector.html'


@define
class _Command:
    """A command for the window thread: its call (it gets the window), its result or its error once done."""

    #: The call of the command (the window as its argument).
    call: Callable[[AbstractWindow], Any]
    #: Set when the command is done (or dropped).
    done: Event = field(factory=Event)
    #: The result of the call.
    result: Any = None
    #: The error of the call ('' none).
    error: str = ''
    #: The HTTP status of the error (an `InspectorError` of the call tells its own).
    status: int = 409


@define
class _Entry:
    """A shown window: its key in the inspector, the window (weakly), what is known of it without touching it."""

    #: The key of the window in the inspector (the windows of the page, `?window=`).
    key: int
    #: The window, kept weakly.
    win: weak_ref
    #: The window class name.
    cls: str
    #: The source of the window (`widgets/config_dialog.xml`).
    source: str
    #: The generated XML (its variant).
    xml: str
    #: The Kodi window ID.
    kodi_id: int
    #: The commands waiting for the window thread.
    commands: list[_Command] = field(factory=list)
    #: The window thread runs the commands (a new one waits for none: a slow window must not pile them up).
    running: bool = False

    def info(self) -> Snapshot:
        """Return the window in the list of the windows."""
        return {'key': self.key, 'class': self.cls, 'source': self.source, 'xml': self.xml, 'kodi_id': self.kodi_id}


#: The shown FF windows by their keys, the last one shown last.
_windows: dict[int, _Entry] = {}
#: The lock of the shown windows and of their commands (the window threads and the server thread).
_lock: Lock = Lock()
#: The keys of the windows.
_keys: Iterator[int] = count(1)
#: The running server (None: none).
_server: Inspector | None = None


# --- the snapshot ---

@lru_cache(maxsize=None)
def property_names(cls: type) -> tuple[str, ...]:
    """Return the names of the properties (`Property`) of the widget class, the ones of `Widget` first."""
    from .widgets import Property
    return tuple(dict.fromkeys(name for klass in reversed(cls.__mro__) for name, value in vars(klass).items() if isinstance(value, Property)))


@lru_cache(maxsize=None)
def template_tokens() -> dict[str, frozenset[str]]:
    """Return the style tokens read by the template of every widget (not by its bases) by the widget names."""
    from .render import RX_TEMPLATE_TOKEN, WIDGETS, declared_token, template_texts
    from .style import TOKENS
    from .xgui import parse_template
    names = {token.name for token in TOKENS}
    found: dict[str, frozenset[str]] = {}
    for path in sorted(WIDGETS.glob('*.xml')):
        root = parse_template(path, root=WIDGETS.parent, as_written=True)
        for elem in root if root.tag == '{ff}widgets' else ():
            if elem.tag == '{ff}widget':
                found[elem.get('name', '')] = frozenset(token for text in template_texts(elem) for mch in RX_TEMPLATE_TOKEN.finditer(text)
                                                        if (token := declared_token(mch[1], names)))
    return found


def json_value(value: Any) -> Any:
    """Return the value as JSON data: a plain one as it is, a short list / mapping of them, else its text (a long one: its size)."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple, dict, set, frozenset)) and len(value) > MAX_ITEMS:
        return f'<{type(value).__name__} of {len(value)}>'
    if isinstance(value, (list, tuple, set, frozenset)):
        return [json_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): json_value(item) for key, item in value.items()}
    return repr(value)


def slot_name(slot: Any) -> str:
    """Return the name of a slot: the class and the method of a bound method, the qualified name of a function."""
    if (owner := getattr(slot, '__self__', None)) is not None:
        return f'{type(owner).__name__}.{slot.__name__}'
    return getattr(slot, '__qualname__', repr(slot))


def kodi_booleans(conditions: Iterable[str]) -> dict[str, bool]:
    """
    Return the values of the skin conditions in the active window (the top one) by one JSON-RPC call: a Kodi call reading
    the GUI waits for the end of a frame (40 ms in K21), one for each condition of a big window took seconds.
    """
    from xbmc import executeJSONRPC
    if not (asked := list(dict.fromkeys(conditions))):
        return {}
    answer = json.loads(executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'XBMC.GetInfoBooleans', 'params': {'booleans': asked}})))
    result = answer.get('result') if isinstance(answer, dict) else None
    return {name: bool(value) for name, value in result.items()} if isinstance(result, dict) else {}


def shown(elem: ET.Element, parents: dict[ET.Element, ET.Element], states: dict[str, bool]) -> bool:
    """
    Return True if the control is shown: it and all its parent controls are visible (Kodi tells the visibility of a control
    by itself only: a control of a hidden page is visible); a control by its Kodi state, else by its `<visible>` conditions.
    """
    node: ET.Element | None = elem
    while node is not None:
        if node.tag == 'control':
            if (state := states.get(f'Control.IsVisible({node.get("id")})')) is None:
                state = all(states.get(text, True) for vis in node.findall('visible') if (text := (vis.text or '').strip()))
            if not state:
                return False
        node = parents.get(node)
    return True


def snapshot(win: AbstractWindow) -> Snapshot:
    """
    Return the snapshot of the window. Call it in the window thread: it reads the window properties and the Kodi state of
    the controls. The Kodi state (shown, enabled) and the rectangles in the window state (its skin conditions) are known for
    the window on top only; under another window: no Kodi state, the rectangles as if all controls were shown.
    """
    from xbmcgui import getCurrentWindowDialogId, getCurrentWindowId
    from .geometry import control_rects
    from .outline import SHOWN, outline_shown
    from .style import DECLARATION, RX_EXPRESSION, TOKENS, preview_tokens, tokens
    from .widgets import signal_names
    start = monotonic()
    args = win.ff_xml_args
    with _lock:
        kodi_id = next((entry.kodi_id for entry in _windows.values() if entry.win() is win), None)
    if kodi_id is None:
        kodi_id = kodi_window_id(win)
    top = kodi_id in (getCurrentWindowDialogId(), getCurrentWindowId())
    entries = [widget.entry for widget in win.widgets.walk() if widget.entry is not None] if win._widget_tree is not None else []
    try:
        text = args.xml_path.read_text(encoding='utf-8')
        root = ET.fromstring(text)
    except (OSError, ET.ParseError):
        fflog_exc()
        text, root = '', None
    states: dict[str, bool] = {}
    if top:  # the conditions the geometry asks (all of them: the recorder holds every one), the state of the widget controls
        asked: list[str] = []

        def record(cond: str) -> bool:
            """Remember the condition, hold it (every one is asked then)."""
            asked.append(cond)
            return True

        if root is not None:
            control_rects(root, condition=record)  # its slides, the visibility of the grouplist children (their places)
            asked += [cond for elem in root.iter('control') for vis in elem.findall('visible') if (cond := (vis.text or '').strip())]  # `shown()`
        asked += [f'Control.{state}({entry.id})' for entry in entries for state in ('IsVisible', 'IsEnabled')]
        states = kodi_booleans(asked)
    rects = control_rects(root, condition=(lambda cond: states.get(cond, True)) if top else None) if root is not None else {}
    parents = {child: parent for parent in root.iter() for child in parent} if root is not None and top else {}
    elems: dict[str, ET.Element] = {}
    for elem in parents:
        if elem.tag == 'control' and elem.get('id'):
            elems.setdefault(elem.get('id', ''), elem)  # the window control first (a list item layout repeats IDs)
    props = {name: win.getProperty(name) for name in sorted(set(RX_WINDOW_PROPERTY.findall(text)))}  # type: ignore[attr-defined]
    focus = win.focused_id()
    style = tokens()
    origins = {origin: origin_text(origin) for origin in set(style.origins.values())}
    widget_props: set[str] = set()
    widgets: list[Snapshot] = []
    for entry in entries:
        widget = win.find(entry.path)
        cls = type(widget)
        rect = rects.get(entry.id)
        own = {name: value for name, value in props.items() if any(name.startswith(f'ffw.{cid}.') for cid in entry.ids.values())}
        widget_props.update(own)
        widgets.append({
            'path': entry.path, 'class': f'{cls.__module__}.{cls.__qualname__}', 'types': list(entry.types), 'families': list(entry.families),
            'ids': entry.ids, 'src': entry.src,
            'properties': {name: json_value(getattr(widget, name)) for name in property_names(cls)},
            'signals': {name: [slot_name(slot) for slot in getattr(widget, name).slots()] for name in signal_names(cls)},
            'rect': None if rect is None else {'x': rect.left, 'y': rect.top, 'width': rect.size.width, 'height': rect.size.height},
            'kodi': {'visible': states.get(f'Control.IsVisible({entry.id})'), 'enabled': states.get(f'Control.IsEnabled({entry.id})'),
                     'shown': shown(elem, parents, states) if (elem := elems.get(str(entry.id))) is not None else None,
                     'focused': focus in entry.ids.values()},
            'window_properties': own,
            'tokens': {name: {'value': json_value(style.values[name]), 'origin': origins[style.origins[name]]}
                       for name in sorted(set().union(*(template_tokens().get(wtype, ()) for wtype in entry.types)))},
        })
    try:
        source = args.xml_source.relative_to(Path(args.script_path) / 'resources' / 'skins').as_posix()
    except ValueError:
        source = args.xml_source.name
    return {'class': f'{type(win).__module__}.{type(win).__qualname__}', 'source': source, 'xml': args.xml_filename,
            'vars': json_value(win.custom_xml_data.request.vars), 'kodi_id': kodi_id, 'top': top, 'focus': focus,
            'outline': outline_shown() if SHOWN in text else None,  # the outline of the layout of the FF windows shown (None: not in the XML)
            'window_properties': {name: value for name, value in props.items() if name not in widget_props},
            'preview': json_value(preview_tokens()),
            # every declared token (any of them may be tried in the preview), the expression of a declared value (its references)
            'style': {token.name: {'value': json_value(style.values[token.name]), 'origin': origins[style.origins[token.name]],
                                   **({'expr': default} if style.origins[token.name] == DECLARATION
                                      and isinstance(default := token.default_of(style.variant), str) and RX_EXPRESSION.search(default) else {})}
                      for token in TOKENS},
            'time': round(monotonic() - start, 3), 'widgets': widgets}


def origin_text(origin: Origin) -> str:
    """
    Return the origin of a token value (`Style.origins`) shortly: a style file of the add-on profile `profile/<file>`, of a theme
    `<theme add-on>/<file>`; a layer of no file by its name (`declaration`, `preview`).
    """
    from ..ff.control import dataPath
    from ..ff.theme import theme_folders
    if not isinstance(origin, Path):
        return origin
    for folder, prefix in ((Path(dataPath), 'profile'), *((folder, folder.name) for folder in theme_folders())):
        try:
            return f'{prefix}/{origin.relative_to(folder).as_posix()}'
        except ValueError:
            pass
    return str(origin)


def set_property(win: AbstractWindow, path: str, name: str, value: Any) -> Any:
    """Set the property of the widget of the window (in the window thread), return its new value."""
    widget: Widget = win.find(path)
    if name not in property_names(type(widget)):
        raise KeyError(f'{widget!r} has no property {name!r}')
    setattr(widget, name, value)
    return json_value(getattr(widget, name))


def preview_token(win: AbstractWindow, name: str, value: Any) -> Snapshot:
    """
    Set the token in the preview layer (None: remove it) and open the window again (in the window thread): its new XML shows the
    style. A window which can not be opened again is not closed: the token is not set (409); a wrong token or value: 400.
    """
    from .style import StyleError, set_preview_token
    if not win.can_reopen:
        raise InspectorError(409, f'{type(win).__name__} can not be opened again (a modeless dialog or its own __new__()), the token is not set')
    try:
        set_preview_token(name, tuple(value) if isinstance(value, list) else value)
    except StyleError as exc:
        raise InspectorError(400, str(exc)) from None
    win.reopen()
    return {'reopened': True}


def save_preview(win: AbstractWindow) -> Snapshot:
    """
    Write the tokens of the preview layer into the local style (in the window thread; the file by the kind of the token), a written
    one leaves the preview; open the window again if anything is written and it can. Return the written files.
    """
    from .style import StyleError, preview_tokens, set_local_token, set_preview_token
    files: list[str] = []
    for name, value in preview_tokens().items():
        try:
            path = set_local_token(name, value)
        except StyleError as exc:  # a broken file: the rest stays in the preview
            raise InspectorError(409, f'{exc} (written: {", ".join(files) or "none"})') from None
        set_preview_token(name, None)
        files = list(dict.fromkeys((*files, str(path))))
    return {'files': files, 'reopened': _reopen(win, bool(files))}


def drop_preview(win: AbstractWindow) -> Snapshot:
    """Remove every token of the preview layer (in the window thread), open the window again if there were any and it can."""
    from .style import clear_preview, preview_tokens
    dropped = list(preview_tokens())
    clear_preview()
    return {'dropped': dropped, 'reopened': _reopen(win, bool(dropped))}


def _reopen(win: AbstractWindow, changed: bool) -> bool:
    """Open the window again if the style changed and it can (else it shows the old style until it is opened next time), return True if so."""
    if changed and win.can_reopen:
        win.reopen()
        return True
    return False


# --- the windows (their hooks in `AbstractWindow`) ---

def kodi_window_id(win: AbstractWindow) -> int:
    """
    Return the Kodi window ID of the window on top (a Python window can not tell its ID): the topmost modal dialog for
    a dialog, else the active window.
    """
    from xbmcgui import WindowXMLDialog, getCurrentWindowDialogId, getCurrentWindowId
    return getCurrentWindowDialogId() if isinstance(win, WindowXMLDialog) else getCurrentWindowId()


def track(win: AbstractWindow, shown: bool) -> None:
    """The window is shown (or closed): keep it (or forget it), start the server with the first window, stop it with the last one."""
    global _server
    stop: Inspector | None = None
    with _lock:
        for entry in list(_windows.values()):
            if entry.win() is win or entry.win() is None:
                del _windows[entry.key]
                _drop(entry.commands, 'the window is closed')
        if shown:
            args = win.ff_xml_args
            entry = _Entry(key=next(_keys), win=weak_ref(win), cls=type(win).__name__, source=args.xml_source.name, xml=args.xml_filename,
                           kodi_id=kodi_window_id(win))  # shown now: on top
            _windows[entry.key] = entry
            if _server is None:
                _server = Inspector.start()
        elif not _windows and _server is not None and not win.reopening:  # opened again: the new window keeps the server
            stop, _server = _server, None
    if stop is not None:
        stop.stop()


def on_action(win: AbstractWindow, action: Action) -> bool:
    """
    The window got an action: run the commands of the inspector waiting for it (`noop`: their wake-up, handled); the inspector
    key saves the snapshot of the window. Return True if the action is handled.
    """
    from ..info import script_aborted
    from ..ff.kotools import kodi_abort_event
    with _lock:
        entry = next((entry for entry in _windows.values() if entry.win() is win), None)
        commands, entry.commands = (entry.commands, []) if entry is not None else ([], [])
        if entry is not None:
            entry.running = bool(commands)
    if script_aborted() or kodi_abort_event.is_set():  # a Kodi call reading the GUI would wait for the Kodi exit, which waits for us
        _drop(commands, 'Kodi exits')
    for cmd in commands:
        try:
            cmd.result = cmd.call(win)
        except InspectorError as exc:
            cmd.error, cmd.status = str(exc), exc.status
        except Exception as exc:
            fflog_exc()
            cmd.error = f'{type(exc).__name__}: {exc}'
        finally:
            cmd.done.set()
    if entry is not None:
        with _lock:
            entry.running = False
    aid = action.getId()
    if aid == ACTION_NOOP:
        return bool(commands)
    if aid == const.dev.inspector.key:
        save_snapshot(win)
        return True
    return False


def save_snapshot(win: AbstractWindow) -> Path:
    """Save the snapshot of the window to a file in the add-on profile (`inspector/`), tell its path and the page address."""
    from ..ff.control import dataPath, infoDialog
    folder = Path(dataPath) / 'inspector'
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f'{type(win).__name__}-{strftime("%Y%m%d-%H%M%S")}.json'
    path.write_text(json.dumps(snapshot(win), indent=1, ensure_ascii=False), encoding='utf-8')
    url = _server.url if _server is not None else ''
    fflog(f'[INSPECTOR] snapshot {path}, {url}')
    infoDialog(L(30300, 'Snapshot: {path}[CR]{url}').format(path=path, url=url), time=10000)
    return path


def _drop(commands: list[_Command], why: str) -> None:
    """End the waiting commands undone."""
    for cmd in commands:
        cmd.error = why
        cmd.done.set()
    commands.clear()


# --- the server ---

class InspectorError(Exception):
    """An error of a request: its HTTP status."""

    def __init__(self, status: int, message: str) -> None:
        """The error of the status."""
        super().__init__(message)
        #: The HTTP status.
        self.status: int = status


class _Handler(BaseHTTPRequestHandler):
    """A request to the inspector (one at a time: a silent client must not hold the server long)."""

    #: The socket timeout of a request.
    timeout = 5
    if TYPE_CHECKING:
        server: _HttpServer

    def do_GET(self) -> None:
        """Answer a GET request."""
        self._answer()

    def do_POST(self) -> None:
        """Answer a POST request."""
        self._answer()

    def log_message(self, format: str, *args: Any) -> None:
        """Log the request (developer logs)."""
        fflog.debug(f'[INSPECTOR] {self.address_string()} {format % args}')

    def _answer(self) -> None:
        """Answer the request by its route."""
        inspector = self.server.inspector
        url = urlsplit(self.path)
        params = dict(parse_qsl(url.query))
        status, ctype, body = 200, 'application/json', b''
        try:
            if inspector.token and not hmac.compare_digest(params.get('token', ''), inspector.token):
                raise InspectorError(403, 'a token is needed')
            if (route := ROUTES.get((self.command, url.path))) is None:
                raise InspectorError(404, f'no {self.command} {url.path}')
            data = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}') if self.command == 'POST' else None
            result = route(inspector, params, data)
            if isinstance(result, tuple):
                ctype, body = result
            else:
                body = json.dumps(result, ensure_ascii=False).encode('utf-8')
        except InspectorError as exc:
            status, body = exc.status, json.dumps({'error': str(exc)}).encode('utf-8')
        except Exception as exc:
            fflog_exc()
            status, body = 500, json.dumps({'error': f'{type(exc).__name__}: {exc}'}).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)


class _HttpServer(HTTPServer):
    """The HTTP server of the inspector."""

    def __init__(self, address: tuple[str, int], inspector: Inspector) -> None:
        """Listen on the address."""
        super().__init__(address, _Handler)
        #: The inspector which serves.
        self.inspector: Inspector = inspector

    def handle_error(self, request: Any, client_address: Any) -> None:
        """Log a client gone before its answer (a closed page during a slow snapshot) shortly, a traceback of any other error."""
        if isinstance(exc := sys.exc_info()[1], ConnectionError):
            fflog.debug(f'[INSPECTOR] {client_address}: the client is gone ({exc})')
        else:
            super().handle_error(request, client_address)


def is_local(host: str) -> bool:
    """Return True if the host is this device only (a loopback address)."""
    try:
        return host == 'localhost' or ip_address(host).is_loopback
    except ValueError:
        return False


class Inspector:
    """The server of the inspector: its thread serves the requests until it is stopped or Kodi aborts."""

    def __init__(self, host: str, port: int, token: str) -> None:
        """Listen on the address (an `OSError` if it can not)."""
        #: The access token ('' none: this device only).
        self.token: str = token
        #: Set to stop the server.
        self.stopped: Event = Event()
        #: The HTTP server.
        self.http: _HttpServer = _HttpServer((host, port), self)
        self.http.timeout = const.tune.event_step  # `handle_request()` waits that long: the stop and the abort are seen
        if host in ('', '0.0.0.0', '::'):
            from xbmc import getIPAddress
            host = getIPAddress()
        #: The address of the page.
        self.url: str = f'http://{host}:{self.http.server_address[1]}/' + (f'?token={token}' if token else '')
        #: The thread of the server.
        self.thread: Thread = Thread(target=self._serve, name='FF inspector')

    @classmethod
    def start(cls) -> Inspector | None:
        """Start the server of `const.dev.inspector` (None: it can not)."""
        cfg = const.dev.inspector
        if not is_local(cfg.host) and not cfg.token:
            fflog(f'[INSPECTOR] no token for the host {cfg.host!r}: not started')
            return None
        try:
            server = cls(cfg.host, cfg.port, '' if is_local(cfg.host) else cfg.token)
        except OSError as exc:
            fflog(f'[INSPECTOR] {cfg.host}:{cfg.port}: {exc}')
            return None
        server.thread.start()
        fflog(f'[INSPECTOR] started: {server.url}')
        return server

    def stop(self) -> None:
        """Stop the server, wait for its thread."""
        self.stopped.set()
        self.thread.join(COMMAND_TIMEOUT + 1)
        fflog('[INSPECTOR] stopped')

    def _serve(self) -> None:
        """Serve the requests until the server is stopped or Kodi aborts (the thread must not keep the interpreter)."""
        from ..info import script_aborted
        from ..ff.kotools import kodi_abort_event
        try:
            while not self.stopped.is_set() and not script_aborted() and not kodi_abort_event.is_set():
                self.http.handle_request()
        finally:
            self.http.server_close()

    def command(self, key: int | None, call: Callable[[AbstractWindow], Any]) -> Any:
        """Run the call in the thread of the window (of its key, None: the last one), return its result."""
        from xbmc import executebuiltin
        cmd = _Command(call)
        with _lock:
            entry = self.entry(key)
            if entry.running:
                raise InspectorError(503, f'the window {entry.cls} is busy (a command)')
            entry.commands.append(cmd)
        executebuiltin(f'Action(noop,{entry.kodi_id})')  # Kodi calls the window back: `on_action()` runs the command
        end = monotonic() + COMMAND_TIMEOUT
        while not cmd.done.wait(const.tune.event_step) and not self.stopped.is_set() and monotonic() < end:
            pass
        with _lock:
            if cmd in entry.commands:
                entry.commands.remove(cmd)
        if not cmd.done.is_set():
            raise InspectorError(504, f'the window {entry.cls} does not answer')
        if cmd.error:
            raise InspectorError(cmd.status, cmd.error)
        return cmd.result

    def style_command(self, key: int | None, call: Callable[[AbstractWindow], Snapshot]) -> Snapshot:
        """
        Run the call of a style change in the thread of the window (of its key, None: the last one); a window it opened again
        (`reopened`): wait for the new one. Return the answer of the call with the key of the window now (`window`, None: the new
        one is not shown yet).
        """
        with _lock:
            entry = self.entry(key)
            key, cls = entry.key, entry.cls
        result = self.command(key, call)
        return {**result, 'window': self.reopened(key, cls) if result['reopened'] else key}

    def reopened(self, key: int, cls: str) -> int | None:
        """
        Return the key of the window of the class shown after the closed one of the key (opened again), None if none is shown in
        time; then with no window at all the server stops (it was kept for the new window).
        """
        global _server
        end = monotonic() + COMMAND_TIMEOUT
        while not self.stopped.wait(const.tune.event_step) and monotonic() < end:
            with _lock:
                if (new := next((entry.key for entry in reversed(_windows.values()) if entry.key > key and entry.cls == cls), None)) is not None:
                    return new
        with _lock:
            if not _windows and _server is self:
                _server = None
                self.stopped.set()  # its own thread: it ends after this request
        return None

    @staticmethod
    def entry(key: int | None) -> _Entry:
        """Return the shown window of the key (None: the last one), call it under the lock."""
        if (entry := _windows.get(key) if key is not None else next(reversed(list(_windows.values())), None)) is None:
            raise InspectorError(404, f'no window {key or ""}'.strip())
        return entry

    # --- the routes ---

    def page(self, params: dict[str, str], data: Any) -> tuple[str, bytes]:
        """Return the page of the inspector."""
        return 'text/html; charset=utf-8', PAGE.read_bytes()

    def windows(self, params: dict[str, str], data: Any) -> list[Snapshot]:
        """Return the shown windows (the last one shown last)."""
        with _lock:
            return [entry.info() for entry in _windows.values() if entry.win() is not None]

    def snapshot(self, params: dict[str, str], data: Any) -> Snapshot:
        """Return the snapshot of the window (`?window=<key>`, none: the last one)."""
        with _lock:
            key = self.entry(int(params['window']) if params.get('window') else None).key
        return {'key': key, **self.command(key, snapshot)}

    def screenshot(self, params: dict[str, str], data: Any) -> tuple[str, bytes]:
        """Return a new screenshot of Kodi (PNG)."""
        from xbmc import executebuiltin
        from xbmcvfs import translatePath
        path = Path(translatePath('special://temp/')) / 'ff-inspector.png'
        if path.exists():
            path.unlink()
        executebuiltin(f'TakeScreenshot({path},sync)')
        end = monotonic() + SCREENSHOT_TIMEOUT
        while not self.stopped.wait(const.tune.event_step) and monotonic() < end:
            if path.exists() and (png := path.read_bytes()).endswith(PNG_END):
                return 'image/png', png
        raise InspectorError(504, 'no screenshot')

    def set(self, params: dict[str, str], data: Any) -> Snapshot:
        """Set a property of a widget (JSON: `window` (none: the last one), `path`, `name`, `value`), return its new value."""
        if not isinstance(data, dict) or not isinstance(data.get('path'), str) or not isinstance(data.get('name'), str) or 'value' not in data:
            raise InspectorError(400, 'expected {"window": key, "path": "...", "name": "...", "value": ...}')
        value = self.command(data.get('window'), lambda win: set_property(win, data['path'], data['name'], data['value']))
        return {'path': data['path'], 'name': data['name'], 'value': value}

    def outline(self, params: dict[str, str], data: Any) -> Snapshot:
        """
        Hide the outline of the layout of the FF windows, show the hidden one (in the thread of the window: JSON `window`, none: the last one);
        return whether it is shown.
        """
        from .outline import toggle_outline
        return {'shown': self.command(data.get('window') if isinstance(data, dict) else None, lambda win: toggle_outline())}

    def select(self, params: dict[str, str], data: Any) -> Snapshot:
        """Highlight the widget in the outline of the layout of the window (JSON: `window` (none: the last one), `path`, '' none), return the path."""
        from .outline import select_widget
        if not isinstance(data, dict) or not isinstance(data.get('path'), str):
            raise InspectorError(400, 'expected {"window": key, "path": "..."}')
        self.command(data.get('window'), lambda win: select_widget(win, data['path']))
        return {'path': data['path']}

    def token(self, params: dict[str, str], data: Any) -> Snapshot:
        """
        Try a style token in the preview layer (JSON: `window` (none: the last one), `name`, `value`, null removes it), the window
        opened again shows it; return the key of the new window (`window`).
        """
        if not isinstance(data, dict) or not isinstance(data.get('name'), str) or 'value' not in data:
            raise InspectorError(400, 'expected {"window": key, "name": "color.accent", "value": "FFFF00FF" | null}')
        return self.style_command(data.get('window'), lambda win: preview_token(win, data['name'], data['value']))

    def token_save(self, params: dict[str, str], data: Any) -> Snapshot:
        """Write the tokens of the preview into the local style (JSON: `window`, none: the last one), return the written files."""
        return self.style_command(data.get('window') if isinstance(data, dict) else None, save_preview)

    def token_drop(self, params: dict[str, str], data: Any) -> Snapshot:
        """Drop the tokens of the preview (JSON: `window`, none: the last one), the window opened again; return the dropped tokens."""
        return self.style_command(data.get('window') if isinstance(data, dict) else None, drop_preview)


#: The routes of the server: (method, path) -> its method.
ROUTES: dict[tuple[str, str], Callable[[Inspector, dict[str, str], Any], Any]] = {
    ('GET', '/'): Inspector.page,
    ('GET', '/windows'): Inspector.windows,
    ('GET', '/snapshot'): Inspector.snapshot,
    ('GET', '/screenshot'): Inspector.screenshot,
    ('POST', '/set'): Inspector.set,
    ('POST', '/outline'): Inspector.outline,
    ('POST', '/select'): Inspector.select,
    ('POST', '/token'): Inspector.token,
    ('POST', '/token/save'): Inspector.token_save,
    ('POST', '/token/drop'): Inspector.token_drop,
}


# --- the command line ---

def _load(source: str, window: int | None = None) -> Snapshot:
    """Return a snapshot from a file or from the server of the URL (its window, none: the last one)."""
    if '://' not in source:
        return json.loads(Path(source).read_text(encoding='utf-8'))
    return _request(source, '/snapshot', {} if window is None else {'window': str(window)})


def _request(url: str, path: str, params: dict[str, str], data: Any = None) -> Any:
    """Return the JSON answer of the server of the URL (its token kept) to the request (POST with data)."""
    from urllib.parse import urlencode
    from urllib.request import Request, urlopen
    base = urlsplit(url)
    query = urlencode({**dict(parse_qsl(base.query)), **params})
    body = None if data is None else json.dumps(data).encode('utf-8')
    req = Request(f'{base.scheme}://{base.netloc}{path}?{query}', data=body, headers={'Content-Type': 'application/json'})
    from urllib.error import HTTPError
    try:
        with urlopen(req, timeout=COMMAND_TIMEOUT + 5) as resp:
            return json.loads(resp.read())
    except HTTPError as exc:
        raise SystemExit(f'{exc.code}: {exc.read().decode("utf-8", "replace")}') from None


def tree_lines(snap: Snapshot) -> list[str]:
    """Return the widget tree of the snapshot: one line a widget (name, class, ID, rectangle, Kodi state, properties)."""
    lines = [f'{snap["class"]}  {snap["source"]}  {snap["xml"]}  focus={snap["focus"]}']
    for widget in snap['widgets']:
        rect = widget['rect']
        where = f'{rect["x"]},{rect["y"]} {rect["width"]}x{rect["height"]}' if rect else '-'
        kodi = widget['kodi']
        state = ''.join(mark for mark, on in (('F', kodi['focused']), ('h', kodi['shown'] is False), ('d', kodi['enabled'] is False)) if on)
        props = ' '.join(f'{name}={json.dumps(value, ensure_ascii=False)[:40]}' for name, value in widget['properties'].items())
        lines.append(f'{"  " * widget["path"].count(".")}{widget["path"].rpartition(".")[2]}  {widget["class"].rpartition(".")[2]}'
                     f'  #{widget["ids"][""]}  {where}  {state or "-"}  {props}')
    return lines


def flat(data: Any, prefix: str = '') -> dict[str, Any]:
    """Return the values of the JSON data by their paths (`widgets[ok].properties.enabled`: the widgets by their paths)."""
    if isinstance(data, dict):
        items: Iterable[tuple[str, Any]] = data.items()
    elif isinstance(data, list) and data and all(isinstance(item, dict) and 'path' in item for item in data):
        items = ((f'[{item["path"]}]', item) for item in data)
    else:
        return {prefix: data}
    out: dict[str, Any] = {}
    for key, value in items:
        out.update(flat(value, f'{prefix}{key}' if key.startswith('[') or not prefix else f'{prefix}.{key}'))
    return out


def diff_lines(old: Snapshot, new: Snapshot) -> list[str]:
    """Return the differences of two snapshots: `-` gone, `+` new, `~` changed (old -> new)."""
    a, b = flat(old), flat(new)
    lines = []
    for key in dict.fromkeys([*a, *b]):
        if key not in b:
            lines.append(f'- {key}: {a[key]!r}')
        elif key not in a:
            lines.append(f'+ {key}: {b[key]!r}')
        elif a[key] != b[key]:
            lines.append(f'~ {key}: {a[key]!r} -> {b[key]!r}')
    return lines


def _json_arg(text: str) -> Any:
    """Return the value of a command line argument: JSON, else the text itself."""
    try:
        return json.loads(text)
    except ValueError:
        return text


def _main() -> None:
    """
    The command line: the tree of a snapshot, the differences of two, a snapshot from the server, a property change, a style token
    tried in the preview, the preview saved or dropped.
    """
    from argparse import ArgumentParser
    from .. import cmdline_argv  # the arguments of the command line (`sys.argv` is the one of the fake plugin call)
    parser = ArgumentParser(prog='python -m lib.windows.inspector', description='The inspector of the FF windows.')
    parser.add_argument('-w', '--window', type=int, help='the key of the window on the server (default: the last one shown)')
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('tree', help='the widget tree of a snapshot')
    p.add_argument('source', help='a snapshot file or the URL of the server')
    p = commands.add_parser('diff', help='the differences of two snapshots')
    p.add_argument('old', help='a snapshot file or the URL of the server')
    p.add_argument('new', help='a snapshot file or the URL of the server')
    p = commands.add_parser('get', help='a snapshot from the server (JSON)')
    p.add_argument('url', help='the URL of the server (with its token)')
    p.add_argument('-o', '--output', help='the file (default: the standard output)')
    p = commands.add_parser('set', help='set a property of a widget on the server')
    p.add_argument('url', help='the URL of the server (with its token)')
    p.add_argument('path', help='the path of the widget (tabs.general.ok)')
    p.add_argument('name', help='the property (enabled)')
    p.add_argument('value', help='the value as JSON (false, "text"); not JSON: a text')
    p = commands.add_parser('token', help='try a style token in the preview (the window opened again)')
    p.add_argument('url', help='the URL of the server (with its token)')
    p.add_argument('name', help='the token (color.accent)')
    p.add_argument('value', help='the value as JSON (1.1, [1.2, true], null: removed from the preview); not JSON: a text (FFFF00FF)')
    for name, text in (('token-save', 'write the preview tokens into the local style'), ('token-drop', 'drop the preview tokens')):
        p = commands.add_parser(name, help=text)
        p.add_argument('url', help='the URL of the server (with its token)')
    args = parser.parse_args(cmdline_argv[1:])
    if args.command == 'tree':
        print('\n'.join(tree_lines(_load(args.source, args.window))))
    elif args.command == 'diff':
        print('\n'.join(diff_lines(_load(args.old, args.window), _load(args.new, args.window))))
    elif args.command == 'get':
        text = json.dumps(_load(args.url, args.window), indent=1, ensure_ascii=False)
        if args.output:
            Path(args.output).write_text(text, encoding='utf-8')
        else:
            print(text)
    elif args.command == 'set':
        print(_request(args.url, '/set', {}, {'window': args.window, 'path': args.path, 'name': args.name, 'value': _json_arg(args.value)}))
    elif args.command == 'token':
        print(_request(args.url, '/token', {}, {'window': args.window, 'name': args.name, 'value': _json_arg(args.value)}))
    elif args.command in ('token-save', 'token-drop'):
        print(_request(args.url, f'/token/{args.command.partition("-")[2]}', {}, {'window': args.window}))


if __name__ == '__main__':
    _main()
