from __future__ import annotations
import re
from datetime import date, datetime, timedelta
from time import monotonic
from threading import RLock, Thread
from copy import deepcopy
from functools import partial, lru_cache
from math import ceil
from pathlib import Path
from typing import Optional, Sequence, Mapping, Any, List, Dict, Iterable, Container, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from attrs import frozen

from xbmcgui import ListItem, ControlList
from xbmcgui import (
    ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP, ACTION_MOVE_DOWN,
)

from ..ff.control import addonPath, run_plugin, settings, busy_dialog, close_busy_dialog, dataPath
from ..ff.locales import kodi_locale
from ..ff.debrid import DEBRIDS
from ..ff.logs import fflog, fflog_exc
from ..ff.kotools import xsleep
from ..ff.utils import remove_non_bmp
from ..ff.source_facts import language_type
from ..ff.types import is_literal
from ..ff import control
from ..ff.locales import flag_url
from ..ff.info import ffinfo
from ..ff.item import FFItemEpisodeGroup
from ..ff.tricks import FormatObjectGetter, Formatter
from ..sources import Source
from ..sources.source_settings import PERSISTENT_SETTING, source_setting
from ..ff.source_filters import item_media, user_languages, selected_sources, simple_view
from ..ff.source_keys import SOURCE_KEYS, Selection, FilterState, compile_selection
from .source_panel import FilterTree, SOURCE_FILTER_DONE_HELP, SOURCE_FILTER_PAGES, FILTER_TEXTS
if TYPE_CHECKING:
    from typing import Callable, ClassVar
    from xbmcgui import Action
    from ..ff.menu import ContextMenu, ContextMenuItem
    from ..ff.item import FFItem, FFVTag, FFTitleAlias, FFEpisodeGroup
    from ..ff.sources import SourceManager as SourceFactory, SourceSearchQuery, SourceSearchQueryKey
    from ..ff.source_filters import CurrentSelection, SelectionMedia
    from ..sources import ProviderModule
    from .style import Style

from ..kolang import L
from .base import BaseDialog, CANCEL_ACTIONS, MENU_ACTIONS, weak_callback
from .context import ContextMenuDialog
from .gui import contrast_ratio, texture_cache, texture_path, tinted_surface, window_texture
from .scale import Scale, ScaleValue
from .skinfonts import symbol, text_metrics
from .style import RX_COLOR, StyleError, evaluate, focused_image_variant, other_variant_style, tokens
from .widgets.accounts import FieldButton
from .widgets.basic import FormField, SpinBox
from .widgets.buttons import PushButton
from .widgets.frames import MARK_KINDS, SIDE_CORNERS, TagData, set_tags
from .widgets.views import ComboBox, ComboItem, TreeView as TreeWidget
from .widgets.tabs import TabWidget
from .widgets.source_filters import SelectionPanel
from cdefs import PlayMode, is_play_mode, SourceAttributeBadge, source_attribute_badge_key, BADGE_SLOTS, BadgeSlot, SourceItemColorMode
from const import const


def route_tag(src: Source, *, premium: bool) -> str:
    """
    Return the text of the tag of the way which opens the source (its best one; the corner of its row): the account of its provider
    `PREMIUM_TAG` if its provider shows it (`premium`: `premium_tag_providers()`), a debrid its name, '' the others.
    """
    if (best := src.resolvability and src.resolvability.best) is None:
        return ''
    return (PREMIUM_TAG if premium else '') if best.kind == 'account' else best.name if best.kind == 'debrid' else ''


def premium_tag_providers(providers: Iterable[str], module: Callable[[str], ProviderModule | None]) -> frozenset[str]:
    """
    Return the providers of the sources opened by their accounts which show the tag `PREMIUM_TAG` (`route_tag()`): every one
    (the setting `premium_tag` "always"), else the ones of premium sources among free ones (`ProviderModule.premium_mixed`; no module,
    the provider unknown: none).
    """
    always = source_setting('premium_tag') == 'always'
    return frozenset(name for name in providers if always or ((mod := module(name)) is not None and mod.premium_mixed))


def tag_text(text: str) -> str:
    """Return the text of the text tag of an item as shown: upper-cased (`const.sources_dialog.tag_uppercase`, as the provider names)."""
    return f'[UPPERCASE]{text}[/UPPERCASE]' if text and const.sources_dialog.tag_uppercase else text


def route_tag_width() -> int:
    """
    Return the width of the tag of the way which opens a source (`route_tag()`; fixed, its text of Python): the widest text of its
    known ones - `PREMIUM_TAG`, the names of the debrids FanFilm knows (`DEBRIDS`), upper-cased as shown (`tag_text()`) - in the font
    of a tag (small), its padding (as a static text tag) and a margin on each side (`space.xs`: not on the edge of the padding);
    another debrid (its ResolveURL name) may end with "…" (the focused row scrolls it).
    """
    width, style = text_metrics('small')[0], tokens()
    texts = (PREMIUM_TAG, *(srv.name for srv in DEBRIDS))
    if const.sources_dialog.tag_uppercase:
        texts = tuple(text.upper() for text in texts)
    return ceil(max(width(text) for text in texts)) + 2 * (style.space.pad.tag + style.space.xs)


def is_greyed_out(src: Source) -> bool:
    """Return True if the source is shown greyed out: no way opens it (`const.sources.resolve.unresolvable`)."""
    return const.sources.resolve.unresolvable == 'grey' and src.unresolvable


TitleQueryKey = Literal['local_title', 'english_title', 'original_title']

#: The marks of the torrent packs (the source `pack`) before the source info.
PACK_LABELS: dict[str, str] = {'season': L(30470, 'Season pack'), 'show': L(30474, 'Show pack')}


#: The hue of the first automatic colour (OKLCH degrees, `oklch()`): the first place of `const.sources.providers.auto_colors`.
AUTO_HUE: float = 25.0
#: The hue of the next place (the golden angle: the hues of any count of places spread evenly).
AUTO_HUE_STEP: float = 137.50776
#: The places of one round of the hues (more look alike): the next round lighter / darker by `AUTO_ROUND_LIGHTNESS` (as tab20).
AUTO_ROUND: int = 12
AUTO_ROUND_LIGHTNESS: float = -.1
#: The order of the badges FanFilm adds (the constant ones of the colour mode - `const.sources_dialog.const_badges` -, the tag of the
#: way which opens the source - `route_tag()`) - after every badge of the rules: a badge of a rule in that place takes its slot.
DERIVED_BADGE_ORDER: int = 1_000_000
#: The text of the tag of a source opened by the account of its provider (`route_tag()`).
PREMIUM_TAG: str = L(30815, 'PREMIUM')
#: The image of an icon badge of the rules with none (`badges/<name>.png`).
DEFAULT_BADGE_ICON: str = 'asterisk'
#: The colours of the badges of the rules with none by their kinds (`SourceAttributeBadge.type`, style tokens; a number: none - the one
#: of its tag).
BADGE_COLORS: dict[str, str] = {'icon': 'color.icon.focused', 'ribbon': 'color.badge', 'line': 'color.badge', 'bar': 'color.badge'}
#: The places of a row by their first slots (`BADGE_SLOTS`: every slot the template knows): their numbers of slots.
DECLARED_BADGE_PLACES: dict[BadgeSlot, int] = {BadgeSlot(slot.part, slot.kind, slot.place): slot.n for slot in BADGE_SLOTS}
#: The slots of the badges of a row by the kinds of their parts (`<kind>_<part>`, the template places the ones of a kind of a part: `BADGE_SLOTS['icon_left']`).
BadgeSlots: TypeAlias = 'dict[str, list[BadgeSlot]]'


def badge_slots_of(badges: Iterable[SourceAttributeBadge], *, spare: int) -> BadgeSlots:
    """
    Return the slots of a row the badges may fill (of `BADGE_SLOTS`: never one the template does not know), by the kinds of their parts
    (every key of `BADGE_SLOTS` present, the template loops over them): in every place of a badge as many slots as badges there (the
    places of their keys: `source_attribute_badge_key()`) and the ones asked by `slot`, `spare` more; an icon
    `over_item_icon` of the right part lies over the icon of the source or beside it (both parts); the text tag of the item always (the way
    which opens the source, `route_tag()`). A badge of a place of no slots is logged when it is shown (`no_badge_slot()`).
    """
    counts: dict[BadgeSlot, int] = {BadgeSlot('item', 'text', 'NE'): 1}  # a place: the number of its badges
    asked: dict[BadgeSlot, int] = {}
    for badge in badges:
        key = source_attribute_badge_key(badge)
        parts: tuple[str, ...] = (key.panel, 'over_icon') if key.type == 'icon' and key.panel == 'right' and 'E' in key.place and key.over_item_icon else (key.panel,)
        for part in parts:
            place = BadgeSlot(part, key.type, key.place)  # type: ignore[arg-type]
            counts[place] = counts.get(place, 0) + 1
            if (wanted := badge.get('slot')) is not None:
                asked[place] = max(asked.get(place, 0), wanted)
    slots: BadgeSlots = {f'{slot.kind}_{slot.part}': [] for slot in BADGE_SLOTS}
    for slot in BADGE_SLOTS:
        place = BadgeSlot(slot.part, slot.kind, slot.place)
        if (used := counts.get(place)) and slot.n <= min(DECLARED_BADGE_PLACES[place], max(used, asked.get(place, 0)) + spare):
            slots[f'{slot.kind}_{slot.part}'].append(slot)
    return slots


def window_badge_slots(items: Sequence[Source] | None = None) -> BadgeSlots:
    """
    Return the slots of the badges of the rows of the window (`badge_slots_of()`): of the badges of the rules (`const.sources.rules`), of
    the constant badges of every colour mode (`const.sources_dialog.const_badges`: the mode changes with no new window), of the badges of
    the sources given to the window (`items`: a demo, a debug), `const.sources_dialog.badge_spare_slots` spare. The template and the rows
    (`SourceDialog.badge_tags()`) use the same ones.
    """
    badges: list[SourceAttributeBadge] = [badge for attr in const.sources.rules.values() if attr and attr.badge for badge in attr.badge]
    badges.extend(badge for mode in const.sources_dialog.const_badges.values() for badge in mode.values() if badge is not None)
    badges.extend(badge for src in items or () if src.attr.badge for badge in src.attr.badge)
    return badge_slots_of(badges, spare=const.sources_dialog.badge_spare_slots)


#: The opacity of a row of a source without the focus (percent: its fade animation in the template).
ROW_FADE: int = 70
#: The parts of a row of a source: the style tokens of their textures tinted by the colour of the row (`row_texture()`: with the focus
#: `.focused`, of the colour mode accent `.accent`).
ROW_PARTS: dict[str, str] = {'left': 'texture.row.source.left', 'right': 'texture.row.source.right'}


@frozen
class RowText:
    """The colours of the texts of a part of a row of a source: of the windows, or of the other brightness (`inverse_rows()`)."""

    #: The plain text.
    text: str
    #: The stressed text.
    strong: str
    #: A match (the cached symbol).
    match: str

    @classmethod
    def of(cls, style: Style, focused: bool = False) -> RowText:
        """Return the colours of the texts of the style (`focused`: of a focused row - `*.row.focused`, its card filled by the focus)."""
        if focused:
            return cls(text=str(style.color.text.row.focused), strong=str(style.color.text.strong.focused),
                       match=str(style.color.text.match.row.focused))
        return cls(text=str(style.color.text), strong=str(style.color.text.strong), match=str(style.color.text.match))


#: The colours of the texts of a part of a row by its focus (`row_texts()`): of its own brightness, of the other one.
RowTexts: TypeAlias = 'dict[bool, tuple[RowText, RowText]]'


def auto_color(provider: str) -> str:
    """
    Return the automatic colour of the provider (the setting `auto_colors` of the sources), '' none (off, not listed): its place in
    `const.sources.providers.auto_colors` (a family of a tuple: one place) a hue, the lightness and the chroma of the style for the colour
    mode (`palette.accent.*` a bar and a name, `palette.tint.*` a background) - the same colour on every device, a new provider no change.
    """
    from .style import oklch
    if not provider or not source_setting('auto_colors'):
        return ''
    place = next((n for n, entry in enumerate(const.sources.providers.auto_colors) if provider == entry or (not isinstance(entry, str) and provider in entry)), -1)
    if place < 0:
        return ''
    part = 'accent' if source_setting('color_mode') == 'accent' else 'tint'
    values = tokens().values
    lightness = float(values[f'palette.{part}.lightness']) + (place // AUTO_ROUND) % 2 * AUTO_ROUND_LIGHTNESS
    return oklch(lightness, float(values[f'palette.{part}.chroma']), (AUTO_HUE + place * AUTO_HUE_STEP) % 360)


def row_texts() -> RowTexts:
    """
    Return the colours of the texts of a part of a row by its focus: of the windows, of the other brightness (`other_variant_style()`);
    focused - the focused ones of the windows (`RowText.of(focused=True)`: a row of the theme, filled by the focus in the light variant) and
    of the two the one of more contrast with them (a row of a colour of the other brightness: `inverse_rows()`).
    """
    own, other = RowText.of(tokens()), RowText.of(other_variant_style())
    focused = RowText.of(tokens(), focused=True)
    opaque = f'FF{focused.text[2:]}'
    return {False: (own, other), True: (focused, max((own, other), key=lambda texts: contrast_ratio(f'FF{texts.text[2:]}', opaque)))}


def row_texture(part: str, focused: bool, color_mode: SourceItemColorMode) -> str:
    """Return the texture of a part of a row of a colour of its own (`ROW_PARTS`) by its focus and the colour mode of the rows."""
    return str(tokens().values[f'{ROW_PARTS[part]}{".focused" if focused else ""}{".accent" if color_mode == "accent" else ""}'])


def inverse_rows(color: str, texts: RowTexts, color_mode: SourceItemColorMode = 'background') -> dict[str, str]:
    """
    Return the properties of the parts of a row of a source of the colour (`AARRGGBB`; another: none) which need the texts of the
    other brightness (`texts`: `row_texts()`): one choice of the whole row by its focus - the contrast of a text on the row is the one
    on its worst part (`gui.contrast_ratio()` on the surface `gui.tinted_surface()` of the texture of the part of the colour mode -
    `row_texture()`; a texture of an unknown colour: left out), the other texts when they read better and the own ones are below
    `const.sources_dialog.row_contrast.minimum` or the other ones are `gain` times better: `item.inverse.<part>` (no focus,
    `ROW_FADE`) and `.focused` - 'true' or '' (every part the same).
    """
    if not RX_COLOR.fullmatch(color):
        return {}
    limits = const.sources_dialog.row_contrast
    under = str(tokens().color.bg.under)
    inverse: dict[str, str] = {}
    for focused, (own, other) in texts.items():
        surfaces = [surface for part in ROW_PARTS
                    if (surface := tinted_surface(color, row_texture(part, focused, color_mode), under=under, fade=100 if focused else ROW_FADE))]
        mine = min((contrast_ratio(own.text, surface) for surface in surfaces), default=0)
        theirs = min((contrast_ratio(other.text, surface) for surface in surfaces), default=0)
        better = theirs > mine and (mine < limits.minimum or theirs >= limits.gain * mine)
        inverse.update({f'item.inverse.{part}{".focused" if focused else ""}': 'true' if better else '' for part in ROW_PARTS})
    return inverse


def const_badges(color_mode: SourceItemColorMode) -> list[SourceAttributeBadge]:
    """
    Return the constant badges of a source row of the colour mode (`const.sources_dialog.const_badges`: the ones of '*' updated by
    the mode's own, None removes one) with their static values once (a list of the window): a style token / an expression of the style
    (`'{color.separator.row}'`: `style.evaluate()` on the style of the windows), `order` after every badge of the rules
    (`DERIVED_BADGE_ORDER`) if none; the '=' values stay for every row (`row_badge()`). A badge of a wrong value is logged and left out.
    """
    by_mode = const.sources_dialog.const_badges
    lookup = tokens().values.__getitem__
    badges: list[SourceAttributeBadge] = []
    for name, badge in {**by_mode.get('*', {}), **by_mode.get(color_mode, {})}.items():
        if badge is not None:
            try:
                values = {key: evaluate(value, lookup) if isinstance(value, str) and value[:1] != '=' else value for key, value in badge.items()}
            except (StyleError, KeyError) as exc:
                fflog(f'The constant badge {name!r} of the sources left out: {exc!r}')
                continue
            badges.append(SourceAttributeBadge(**{'order': DERIVED_BADGE_ORDER, **values}))  # type: ignore[typeddict-item]
    return badges


def row_badge(badge: SourceAttributeBadge, names: Mapping[str, Any]) -> SourceAttributeBadge | None:
    """
    Return the constant badge (`const_badges()`) of a row: its values `=expr` evaluated (`settings.eval()` of the names of the row);
    None - a value of nothing ('', None: not shown) or a wrong one (logged by `settings.eval()`; any error: the expression is the user's).
    """
    if not any(isinstance(value, str) and value[:1] == '=' for value in badge.values()):
        return badge
    row: dict[str, Any] = dict(badge)
    for key, value in badge.items():
        if isinstance(value, str) and value[:1] == '=':
            try:
                row[key] = value = settings.eval(value[1:], names=names)
            except Exception:
                return None
            if value is None or value == '':
                return None
    return row  # type: ignore[return-value]


@texture_cache
def find_badge(name: str, folder: Path, variant: str | None = None) -> str:
    """
    Return the path of the image of a badge of the rules (its name, `.png` optional): in the user folder `folder`, else the texture
    `badges/<name>`, `<name>` of the window media (`texture_path()`: of the variant - None the one of the windows, a focused row of another
    brightness `focused_image_variant()` -, of an active theme which has it first; its full path, `window_texture()`); '' none.
    """
    if not name:
        return ''
    if not name.endswith('.png'):
        name += '.png'
    if (path := folder / name).is_file():
        return str(path)
    return next((window_texture(rel, variant=variant) for rel in (f'badges/{name}', name) if texture_path(rel, variant=variant).is_file()), '')


@lru_cache(maxsize=None)
def no_badge_slot(place: BadgeSlot) -> None:
    """Log a badge of the rules of a slot not in a row (`BADGE_SLOTS`: its kind, its part, its place, its number) once: it is not shown."""
    fflog.warning(f'A source badge {place.kind} in the place {place.place!r} of the part {place.part!r}'
                  f'{f" (slot {place.n})" if place.n != 1 else ""}: no such slot, not shown')


def badge_image(names: Sequence[str], folder: Path, variant: str | None = None) -> str:
    """Return the path of the first image of the badge names which has one (`find_badge()`: the user folder, of the variant), '' none."""
    return next((path for name in names if (path := find_badge(name, folder, variant))), '')


@lru_cache()
def addon_title(addon_id: str) -> str:
    """Return the short name of an external add-on over the provider of its source (`addon_short_name()`), e.g. `Kadr+ 2.0`, `CocoScrapers`."""
    from xbmcvfs import translatePath
    from ..sources import addon_short_name
    return addon_short_name(Path(translatePath('special://home/addons')) / addon_id)


class RescanSources(Exception):
    """Force rescan sources again."""

    def __init__(self, *, query: Optional['SourceSearchQuery'], selection: Optional['CurrentSelection'] = None) -> None:
        super().__init__()
        self.query: Optional['SourceSearchQuery'] = query
        #: The selection of the window (not stored): the next window of this search goes on with it.
        self.selection: Optional['CurrentSelection'] = selection


def endtime(duration: float, progress: float = 0) -> str:
    """Return the time (HH:MM) the video ends if played now: its duration (seconds; 0 unknown: a dash) from its resume point (`progress`, %)."""
    if not duration:
        return '–'
    end = datetime.now() + timedelta(seconds=duration * (1 - progress / 100))
    return end.strftime('%H:%M')


def clear_source(source):
    return source.rsplit(".", 1)[0]


def format_info(label):
    try:
        return re.sub(r"(\d+(?:[.,]\d+)?\s*[GMK]B)", rf"[COLOR {tokens().color.text.strong}]\1[/COLOR]", label, flags=re.I)
    except Exception:
        return label


def source_info(text: str) -> str:
    """
    Return the info of a source for its row: the words of the language type first (`language_type_priority`, any case),
    the sizes colored; the words are kept as they are (Kodi label tags are case sensitive, e.g. of an external add-on).
    """
    priority = const.sources_dialog.language_type_priority
    return format_info(' '.join(sorted(text.split(), key=lambda word: priority.get(word.lower(), 999))))


def download_info(src: Source) -> str:
    """
    Return the description of a download of a source (its file name): the language type of its facts (the words of the providers:
    `Lektor`, `Dubbing Kino`, `Napisy`...; else the word in its info) with dots (`Dubbing.Kino`: the download keeps no space), the
    language (of its audio), the quality, the extra info.
    """
    audio_type = language_type(src.facts) or next((word for word in ('Lektor', 'Dubbing', 'Napisy') if word in src.get('info', '')), '')
    return f"{'.'.join(audio_type.split())} | {src.get('language', '').upper()} | {src.get('quality', '')} |{src.get('info2', '')}"


class EditDialog(BaseDialog):
    """
    Dialog for editing search query: the rows of a form (`form_field`) named by the keys of the query, their marks "modified"; the
    fields click to edit (OK opens their editor): the titles combo boxes of the aliases of the media (the keyboard of Kodi), the year, the
    season and the episode spin boxes, the date a field of the date dialog of Kodi, the episode group a combo box of the groups of TMDB
    (loaded when its list opens). The context menu of a field: its default, a clear of a field which may be empty.
    """

    #: The fields of the query (the rows of the form are named by their keys).
    EDIT_FIELDS: ClassVar[tuple[SourceSearchQueryKey, ...]] = (
        'local_title',
        'english_title',
        'original_title',
        'year',
        'premiered',
        # 'tvshowtitle',
        'season',
        'episode',
        'episode_group',
    )

    #: The fields which may be empty (the context menu clears them): their empty values.
    CLEARED: ClassVar[dict[SourceSearchQueryKey, Any]] = {'local_title': '', 'english_title': '', 'original_title': '', 'premiered': None}

    #: The first year of the spin box of the year (the first films; its low end: no year, 0).
    FIRST_YEAR: ClassVar[int] = 1870
    #: The years of the spin box of the year after the current one (announced titles).
    YEARS_AHEAD: ClassVar[int] = 10
    #: The last season / episode of their spin boxes (a season of a year: 2024).
    LAST_NUMBER: ClassVar[int] = 9999
    #: The labels of the fields of Python (a spin box: before its number, its number dialog; the date: before it, its date dialog).
    FIELD_LABELS: ClassVar[dict[SourceSearchQueryKey, str]] = {'year': L(30261, 'Year:'), 'premiered': L(30262, 'Premiered:'),
                                                               'season': L(30264, 'Season:'), 'episode': L(30265, 'Episode:')}

    NO_EPISODE_GROUP_LABEL = L(30540, '– none –')

    def __init__(self,
                 *args,
                 query: SourceSearchQuery,
                 default_query: SourceSearchQuery | None = None,
                 raise_rescan: bool = True,
                 **kwargs,
                 ) -> None:
        super().__init__(*args, **kwargs)
        self.init_done = False
        self.raise_rescan = raise_rescan
        # Current (avtive) query.
        self.query: SourceSearchQuery = query.copy()
        # Default query, episode_group must be None.
        self.default_query: SourceSearchQuery = (query if default_query is None else default_query).copy()
        self.ffitem: FFItem | None = self.query.get('ffitem')
        if query.get('episode') is not None:
            mtype = 'episode'
        else:
            mtype = 'movie'
        #: The episode groups of the show (TMDB, sorted by their names; None: not loaded yet - the list of the field opens first).
        self.episode_groups_loaded: list[FFEpisodeGroup] | None = None
        #: The fields of an episode are shown (the season, the episode, the episode group).
        self.episode_fields: bool = mtype == 'episode'
        self.switch_episode_group(update=False)  # skip update, keep season/episode from query
        fflog(f' ... {mtype = }, {query = }, {default_query = }')
        self.setProperty('search.media_type', mtype)
        for key in self.EDIT_FIELDS:  # the scales of the spin boxes; the changes of the user: the marks
            field = self.find(key, FormField).field
            if isinstance(field, SpinBox):
                field.scale, field.heading = self.scale_of(key), self.FIELD_LABELS[key]
                field.committed.connect(weak_callback(self.field_changed))
            elif isinstance(field, ComboBox) and field.vars.editable:
                field.edit_text_changed.connect(weak_callback(self.field_changed))

    def get_query(self) -> SourceSearchQuery:
        """
        Return the query of the fields: the texts of the titles, the numbers of the spin boxes (the year; an episode: the season, the
        episode), the date and the episode group of the query (their editors write it).
        """
        query = dict(self.query)
        for key in self.EDIT_FIELDS:
            field = self.find(key, FormField).field
            if isinstance(field, ComboBox) and field.vars.editable:
                query[key] = field.edit_text
            elif isinstance(field, SpinBox) and (key == 'year' or self.episode_fields):
                query[key] = field.value
        return query  # type: ignore[reportReturnType]

    # def get_query_labels(self) -> dict[SourceSearchQueryKey, str]:
    #     query_labels: dict[SourceSearchQueryKey, str] = {k: '' if v is None else str(v) for k, v in self.query.items()}  # type: ignore[reportAttributeAccessIssue]
    #     query_labels['episode_group'] = self.NO_EPISODE_GROUP_LABEL
    #     # if self.query.get('episode') is not None:
    #     if (eg := self.query.get('episode_group')) and (group := self.episode_group_by(id=eg)) is not None:
    #         query_labels['episode_group'] = group.name
    #     return query_labels

    def query_label(self, key: SourceSearchQueryKey) -> str:
        """Get label for given query key."""
        if key == 'episode_group':
            # the group of the query (a group with no mapping of the episode is not the current group of the item): its name of the item
            # (its current group, its groups loaded), else its ID (no network)
            if not (group_id := self.query.get('episode_group')):
                return self.NO_EPISODE_GROUP_LABEL
            groups = [] if self.ffitem is None else [self.ffitem.episode_group.current, *(self.episode_groups_loaded or self.ffitem.episode_group.groups or ())]
            return next((group.name for group in groups if group is not None and group.tmdb_id == group_id), group_id)
        return str(self.query.get(key) or '')

    def update_modified(self, *, query: SourceSearchQuery | None = None) -> None:
        if self.init_done:
            if query is None:
                query = self.get_query()
            for name in self.EDIT_FIELDS:
                the_same = self.default_query.get(name) == query.get(name)
                fflog(f'   . {name}: {the_same = }, {self.default_query.get(name) = }, {query.get(name) = }')
                self.find(name, FormField).modified = not the_same
            if (ffitem := self.query.get('ffitem')) is not None and ffitem.ref.is_episode:
                if 'episode_offset' in (const.sources_dialog.edit_search.cache or ()) and ffitem.season:
                    d_episode = self.default_query['episode'] or 0
                    q_episode = query['episode'] or 0
                    episode_group = query.get('episode_group')
                    # fflog(f'    >>>>>>>>>>>>>>>>>  {d_episode=}, {q_episode=}, {ffitem.season=}, {episode_group=}')
                    if d_episode and q_episode and d_episode != q_episode:
                        query['episode_offset'].setdefault(query.get('episode_group'), {})[ffitem.season] = q_episode - d_episode
                    else:
                        if episode_offset := query['episode_offset'].get(query.get('episode_group')):
                            del episode_offset[ffitem.season]
                        if not episode_group:
                            query['episode_offset'] = {}

    def set_labels(self) -> None:
        """
        Show the query in the fields (a combo box of the titles: its current alias of the text; a spin box: its value, none 0; the date:
        its text after its label, none "–"; the episode group: its name).
        """
        for key in self.EDIT_FIELDS:
            field = self.find(key, FormField).field
            if isinstance(field, ComboBox):
                if field.vars.editable:
                    field.edit_text = self.query_label(key)
                else:
                    field.current_text = self.query_label(key)
            elif isinstance(field, SpinBox):
                field.value = self.query.get(key) or 0
            elif isinstance(field, FieldButton):
                field.text = f'{self.FIELD_LABELS[key]} {self.query_label(key) or "–"}'

    def scale_of(self, key: SourceSearchQueryKey) -> Scale:
        """Return the scale of the spin box of the field: of the year (its low end: no year, 0), of a season, of an episode."""
        label = self.FIELD_LABELS[key]
        if key == 'year':
            return Scale(minimum=self.FIRST_YEAR, maximum=date.today().year + self.YEARS_AHEAD, low=(ScaleValue(0, f'{label} –'),),
                         format=f'{label} {{}}')
        return Scale(minimum=0, maximum=self.LAST_NUMBER, format=f'{label} {{}}')

    def on_init(self) -> None:
        """The aliases of the titles, the query in the fields, the focus on Scan, the marks "modified"."""
        for key, order in self.alias_orders().items():
            self.find(f'{key}.title', ComboBox).items = [ComboItem(label=alias.title, icon=self.flag(alias))
                                                         for alias in self.title_aliases(key, order=order)]
        self.set_labels()
        self.setFocusId(self.find('scan').id)
        self.init_done = True
        self.update_modified(query=self.query)

    def on_action(self, action: Action) -> None:
        """Kodi sent the action."""
        if self.default_action(action):
            return
        action_id = action.getId()
        if action_id in CANCEL_ACTIONS:
            self.close()
        elif action_id in MENU_ACTIONS and (key := self.focused_field()) is not None:
            self.field_menu(key)

    def focused_field(self) -> SourceSearchQueryKey | None:
        """Return the field of the focused control (its key; None: no field)."""
        cid = self.focused_id()
        return next((key for key in self.EDIT_FIELDS
                     if any(cid in widget.entry.ids.values() for widget in self.find(key).walk() if widget.entry is not None)), None)

    def field_menu(self, key: SourceSearchQueryKey) -> None:
        """The context menu of the field: its default (another value shown), a clear (a field which may be empty, not empty)."""
        from .context import ContextMenuDialog
        value = self.get_query().get(key)
        menu: list[tuple[str, Callable[[], None]]] = []
        if value != self.default_query.get(key):
            menu.append((L(30753, 'Default'), partial(weak_callback(self.set_field), key, self.default_query.get(key))))
        if key in self.CLEARED and value != self.CLEARED[key]:
            menu.append((L(30817, 'Clear'), partial(weak_callback(self.set_field), key, self.CLEARED[key])))
        if menu:
            ContextMenuDialog(menu=menu).doModal()

    def set_field(self, key: SourceSearchQueryKey, value: Any) -> None:
        """Set the value of the field (the episode group: its season and episode too), the rest as the fields show it; the marks "modified"."""
        self.query = {**self.get_query(), key: value}  # type: ignore[assignment]
        if key == 'episode_group':
            self.switch_episode_group()
        self.set_labels()
        self.update_modified()

    def on_focus(self, control_id: int) -> None:
        self.update_modified()
        # self.setFocusId(self.find('episode_group.group').field_id())

    def alias_orders(self) -> dict[TitleQueryKey, list[set[str]]]:
        """Return the orders of the countries of the aliases of the title fields (an empty set: the countries of the media)."""
        lang, english = {ffinfo.tmdb.lang or 'pl_PL'}, {'en_US', 'en_GB'}
        return {'local_title': [lang, english, set()], 'english_title': [english, lang, set()], 'original_title': [set(), lang, english]}

    def title_aliases(self, key: TitleQueryKey, *, order: list[set[str]]) -> list[FFTitleAlias]:
        """
        Return the aliases of the media for the title field `key` (no network: the ones of its FFItem): the default title first (no
        country), the rest by the countries of `order` (an empty set: of the media), no title twice.
        """
        from ..ff.item import FFTitleAlias

        def country_codes(locale: Iterable[str]) -> set[str]:
            return {rx.split(loc)[-1].lower() for loc in locale}

        def order_func(a: FFTitleAlias) -> int:
            for idx, codes in enumerate(order):
                if a.country.lower() in codes:
                    return idx
            return len(order)

        rx = re.compile(r'[-_]')
        if not (ffitem := self.query.get('ffitem')):
            return []
        if show := ffitem.show_item:
            ffitem = show
        vtag = ffitem.vtag
        order = [country_codes(o if o else vtag.getCountryCodes()) for o in order]
        orig = FFTitleAlias(title=self.default_query.get(key, ''), country='')
        aliases_dict: dict[str, FFTitleAlias] = {}
        for a in (orig, *sorted(ffitem.aliases_info, key=order_func)):
            # aliases_dict.setdefault(a.title, f'[B]{a.country.upper()}[/B] | {a.title}' if a.country else a.title)
            # (the label of an item of the combo box is its title: the text of the field)
            aliases_dict.setdefault(a.title, a)
        # The current alias is the one of the text of the field (the combo box: `current_index` of its text), formerly:
        # current = [a.rpartition('|')[2] for a in aliases].index(current_title)
        # The list of the aliases is the one of the combo box, formerly the window of the alternative titles, before:
        # selected = Dialog().select(L(30528, 'Alternative titles'), aliases, preselect=current)
        # fflog(f'{key} aliases: {list(aliases_dict.values()) = }')  (formerly in the window of the alternative titles)
        return list(aliases_dict.values())

    def flag(self, alias: FFTitleAlias) -> str:
        """Return the flag of the country of the alias ('' no country: the default title)."""
        return flag_url.format(lower=alias.country.lower()) if alias.country else ''

    def on_scan_clicked(self) -> None:
        """Scan button: search with the query."""
        query = self.get_query()
        if self.raise_rescan:
            self.raise_exception(RescanSources(query=query))
        self.close(query)

    def on_cancel_clicked(self) -> None:
        """Cancel button."""
        self.close()

    def on_defaults_clicked(self) -> None:
        """Reset to defaults button."""
        self.reset()

    def field_changed(self, value: Any) -> None:
        """A field changed by the user (a title typed or an alias chosen, a spin box moved): the marks "modified"."""
        self.update_modified()

    def on_premiered_edit_clicked(self) -> None:
        """The date: the date dialog of Kodi (canceled: no change)."""
        from ..ff.ui import ui
        if (day := ui.input_date(self.FIELD_LABELS['premiered'], self.get_query().get('premiered'))) is not None:
            self.set_field('premiered', day)

    def on_episode_group_group_about_to_show(self) -> None:
        """The list of the episode groups opens: the groups of the show (TMDB, once), the current one."""
        if self.ffitem is None or self.ffitem.ref.type != 'show':
            return
        if (groups := self.episode_groups_loaded) is None:
            groups = self.episode_groups_loaded = sorted(ffinfo.get_episode_groups(self.ffitem) or [], key=lambda g: g.name)
            fflog(f' ... episode groups: {groups = }')
            self.find('episode_group.group', ComboBox).items = [self.NO_EPISODE_GROUP_LABEL, *(g.name for g in groups)]
        current_episode_group = self.query.get('episode_group')  # (also a group with no mapping of the episode: not the current one of the item)
        current = 0
        if current_episode_group:
            try:
                current = [g.tmdb_id for g in groups].index(current_episode_group) + 1
            except ValueError:
                fflog(f'episode group current not found: {current_episode_group!r}')
        self.find('episode_group.group', ComboBox).current_index = current

    def on_episode_group_group_activated(self, selected: int) -> None:
        """Choose show episode group."""
        groups = self.episode_groups_loaded or []
        if selected >= 0:
            # none selected (else some group selected)
            self.set_field('episode_group', None if selected == 0 else groups[selected - 1].tmdb_id)
            # xsleep(0.1)  # allow GUI to update

    def switch_episode_group(self, *, update: bool = True) -> None:
        """Switch to query current episode group."""
        eg = self.query.get('episode_group')
        if (ffitem := self.query.get('ffitem')) is not None and ffitem.ref.is_episode:
            ffinfo.switch_episode_group(ffitem, eg)
            if update:
                self.query['season'] = self.default_query['season'] = ffitem.season
                self.query['episode'] = self.default_query['episode'] = ffitem.episode
                if 'episode_offset' in (const.sources_dialog.edit_search.cache or ()) and ffitem.season:
                    if epoff := self.query['episode_offset'].get(eg):
                        epoff.pop(ffitem.season, None)
                        if not epoff:
                            del self.query['episode_offset'][eg]

    def reset(self) -> None:
        """Reset all fields to default values."""
        self.query = self.default_query.copy()
        self.switch_episode_group()
        self.query['episode_offset'] = self.default_query['episode_offset'] = {}
        self.set_labels()
        self.update_modified()

    def episode_groups(self) -> list[FFEpisodeGroup]:
        if ffitem := self.query.get('ffitem'):
            if show := ffitem.show_item:
                ffitem = show
            if ffitem.type == 'show':
                return ffinfo.get_episode_groups(ffitem) or []
        return []


class SourceDialog(BaseDialog):
    """
    The sources of the media (`resources/skins/widgets/source_dialog.xml`): the list `sources` (its rows are the list items
    of the sources), while searching the progress and the button `cancel`; the result is the source to play (None: nothing).
    """

    #: The font style of the symbol of a torrent cached by a debrid (`skinfonts.symbol()`: the symbol font if Kodi has it),
    #: the `ff:style` of its label in the template (read as it is, not a template field).
    CACHED_STYLE: ClassVar[str] = 'heading.symbol'

    # NO_ITEMS_LABEL = 5001
    #: The window property of the panel of the filter open (the template: `FILTERS_OPEN`).
    FILTERS_OPEN: ClassVar[str] = 'filters.open'
    #: The right edge of the right column (a plain button of Kodi, no look): its focus opens the panel of the filter.
    FILTERS_EDGE: ClassVar[int] = 5011
    #: The window property of the panel being the change of the filter by the values of one source (the template: `SOURCE_FILTER`).
    SOURCE_FILTER: ClassVar[str] = 'filters.source'

    rx_provider_rename: re.Pattern = re.compile(r'(?P<suffix>\.\d)')
    provider_suffixes = {
        '.1': '¹',
        '.2': '²',
        '.3': '³',
    }

    @classmethod
    def xml_vars(cls, *, items: Sequence[Source] | None = None, simple: bool = False, **kwargs: Any) -> dict[str, Any]:
        """
        The view of the panel of the filter (`SIMPLE_VIEW`; `simple`: a variant of the window, of a real window: of its item), the slots of the badges of a row by their kinds of their parts (`BADGE_SLOTS['icon_left']`: the template places them; the ones the
        badges of the rules, the constant ones and the ones of the given sources may fill - `window_badge_slots()`), the
        texts of the parts of a row of both brightnesses by the focus (`ROW_TEXTS[focused][inverse]`), the fade of a row without the
        focus (`ROW_FADE`), the width of the tag of the way which opens a source (`ROUTE_TAG_WIDTH`: `route_tag_width()`), the colour
        mode of the rows (`COLOR_MODE`: the setting `color_mode` - a variant of the window each: the spacing of the texts, the tint of a row
        of the theme, the textures of the parts of a row of a colour of its own - `ROW_TEXTURES[part][focused]` - of its mode), the fade of
        a row the filter cuts shown with the filter off (`FILTERED_FADE`: the opacity left by the setting `filtered_dim`, 100 none).
        """
        slots = window_badge_slots(items)
        # the texts of a part of a row: of the windows, of the other brightness (`inverse_rows()`); the fade of a row without the focus
        color_mode: SourceItemColorMode = source_setting('color_mode')
        return {'SOURCE_COUNTER': L(30113, 'Source: $INFO[Container({list}).CurrentItem,[B],[/B]]$INFO[Container({list}).NumItems, / ,]'
                                         '$INFO[Window.Property(sources.all), / ,]$INFO[Window.Property(sources.resolvable), (,)]', list='@sources'),
                'SIMPLE_VIEW': simple_view(item_media(kwargs['item'])) if 'item' in kwargs else simple,
                'FILTER_TEXTS': FILTER_TEXTS, 'SOURCE_FILTER_PAGES': SOURCE_FILTER_PAGES, 'FILTERS_EDGE': cls.FILTERS_EDGE,
                'BADGE_SLOTS': slots, 'ROW_TEXTS': row_texts(), 'ROW_FADE': ROW_FADE, 'ROUTE_TAG_WIDTH': route_tag_width(), 'COLOR_MODE': color_mode,
                'FILTERED_FADE': 100 - source_setting('filtered_dim'),
                'ROW_TEXTURES': {part: {focused: row_texture(part, focused, color_mode) for focused in (False, True)} for part in ROW_PARTS}}

    def __init__(self,
                 *args,
                 sources: SourceFactory,
                 item: FFItem,
                 items: Sequence[Source] | None = None,
                 query: SourceSearchQuery,
                 default_query: SourceSearchQuery | None = None,
                 edit_search: bool = False,
                 selection: CurrentSelection | None = None,
                 **kwargs,
                 ) -> None:
        super().__init__(*args)
        self.source_factory: SourceFactory = sources
        self.ffitem: FFItem = item
        self.ui_lang = kodi_locale()
        #: The places of the badges of a row by their first slots: their numbers of slots (the ones of the window: `window_badge_slots()`).
        self.badge_places: dict[BadgeSlot, int] = {BadgeSlot(slot.part, slot.kind, slot.place): slot.n
                                                   for slots in window_badge_slots(items).values() for slot in slots}
        #: All sources of the search (prepared: the window shows the selection of the user of them).
        self.all_sources: list[Source] = [] if items is None else self.process_debug_items(items)
        #: The shown sources (the rows of the list).
        self.sources: list[Source] = []
        self.lists: list[ListItem] = []  # Created later in on_init to avoid lag
        self.filters.media = item_media(item)
        self.filters.persistent = source_setting(PERSISTENT_SETTING)
        self.filters.transient = selection
        self.filters.sources = self.all_sources
        #: The values of one source (the change of the filter by them, over the whole panel), None: the panel as it is.
        self.source_tree: FilterTree | None = None
        #: The panel of the filter closes at the end of the change by the values of one source (it was closed before it).
        self.source_tree_closes: bool = False
        #: The source the user stands on (kept while the filter hides it), None: the first one.
        self._anchor: Source | None = None
        #: The position of the list given by the window (another one: the user moved), -1 none.
        self._shown_pos: int = -1
        self.resolved: Source | None = None
        self.focused_constrol_id: int = 0
        self.query = query.copy()
        self.default_query = query.copy() if default_query is None else default_query.copy()
        self._call_edit_search: bool = edit_search
        self._searching: bool = False  # True when actively searching for sources
        #: The list of the sources is made by the search thread and by the events of the window.
        self._list_lock: RLock = RLock()
        #: The next time the tree of the filter is made again while a search brings new sources (`show_found()`).
        self._tree_due: float = 0.0
        #: A source chosen while searching is being resolved (no end of the search shown, its sources: `_late_sources`).
        self._playing: bool = False
        #: The sources of a search ended while a chosen source was resolved.
        self._late_sources: Sequence[Source] | None = None
        self._search_canceled: bool = False  # True if user canceled search
        if items is None:
            self.start_search()  # Start search mode if no items provided

    def process_debug_items(self, items: Sequence[Source]) -> list[Source]:
        item = self.ffitem
        items = [*(Source.from_meta(ffitem=item, meta=it) for it in const.dev.sources.prepend_fake_items),
                 *items,
                 *(Source.from_meta(ffitem=item, meta=it) for it in const.dev.sources.append_fake_items)]
        return items

    def apply_source(self, resolved: Source, *, play: Optional[PlayMode] = None) -> None:
        """Apply the resolved source, return to the sources manager and player."""
        self.resolved = resolved
        if play:
            self.resolved.set_play_mode(play)
        self.close(self.resolved)

    def _set_window_title(self) -> None:
        """Show the title of the media (`const.sources_dialog.*_title_format`)."""
        ffitem = self.ffitem
        ref = ffitem.ref
        # window title
        if ref.is_episode:
            if ffitem.episode_group.current is None:
                title_format = const.sources_dialog.episode_title_format
            else:
                title_format = const.sources_dialog.episode_group_title_format
        else:
            title_format = const.sources_dialog.movie_title_format
        season = self.query['season'] or ffitem.season or 0
        episode = self.query['episode'] or ffitem.episode or 0
        fmt = Formatter()
        it = FormatObjectGetter(ffitem)
        window_title = fmt.format(title_format, label=ffitem.title,
                                  it=it, item=it, show=FormatObjectGetter(ffitem.show_item), ref=ffitem.ref,  # locale=labels,
                                  title=ffitem.title, season=season, episode=episode, year=ffitem.year, date=ffitem.date)
        self.find('title').text = window_title

    def on_init(self) -> None:
        ffitem = self.ffitem
        # window title
        self._set_window_title()

        default_color = source_setting('default_color')
        duration_in_mins = int(ffitem.vtag.getDuration() / 60)
        duration_str = str(duration_in_mins) if duration_in_mins else '–'
        the_same = all(self.query.get(k) == self.default_query.get(k) for k in self.query.keys() if k not in ('ffitem', 'episode_offset'))
        fflog(f'the same: {the_same}')
        # for k in self.query.keys():
        #     if k not in ('ffitem', 'episode_offset'):
        #         fflog(f'   . {int(self.query.get(k) == self.default_query.get(k))} {k}: {self.query.get(k)!r} == {self.default_query.get(k)!r}')

        self.setProperty('item.title', str(ffitem.title))
        self.setProperty('item.tvshowtitle', ffitem.vtag.getTvShowTitle())
        self.setProperty('item.year', str(ffitem.year))
        self.setProperty('item.season', str(ffitem.season))
        self.setProperty('item.episode', str(ffitem.episode))
        self.setProperty('item.duration', L(30111, 'Duration: [B]{duration}[/B] minute|||Duration: [B]{duration}[/B] minutes', n=duration_in_mins, duration=duration_str))
        self.setProperty('item.art.fanart', ffitem.getArt('fanart'))

        poster_item: FFItem | None = None
        if ffitem.ref.is_episode:
            if const.sources_dialog.episode_poster == 'show':
                poster_item = ffitem.show_item
            elif const.sources_dialog.episode_poster == 'season':
                poster_item = ffitem.season_item
        if poster_item is None:
            poster_item = ffitem
        self.setProperty('item.art.poster', poster_item.getArt('poster'))
        self.show_end_time()
        self.setProperty('item.colored.default', default_color)
        self.setProperty('sources.edit_button', 'true' if const.sources_dialog.edit_search.in_dialog else 'false')
        self.find('edit', FormField).modified = bool(const.sources_dialog.edit_search.in_dialog and not the_same)
        self.setProperty(self.FILTERS_OPEN, 'false')
        # items (made here, not in __init__: no lag before the dialog shows)
        if not self._searching:
            self.show_sources()
        self.setProperty('sources.time_progress_visible', 'true' if const.sources_dialog.time_progress else 'false')

        # Set focus based on state
        if self._searching:
            # During search, focus on Cancel button
            self.setFocusId(self.find('cancel').id)
        elif self.lists:
            self.setFocusId(self.find('sources').id)
        else:
            self.setFocusId(self.find('rescan').id)

        if self._call_edit_search:
            if not self.edit_search():
                self.close()  # force close on "back"

    def list_items(self, items: Iterable[Source], *, cut: Container[int] = ()) -> List[ListItem]:
        """
        Return the list items of the sources (`cut`: the ones the filter of the user cuts by their `id()`, greyed out); the window index shows
        the count of the openable ones if some is greyed out.
        """
        items = list(items)
        # Cache translations outside loop for performance
        provider_translations = const.sources.translations.providers.get(self.ui_lang, {})
        hosting_translations = const.sources.translations.hostings.get(self.ui_lang, {})
        greyed = sum(1 for item in items if is_greyed_out(item))
        self.setProperty('sources.resolvable', str(len(items) - greyed) if greyed else '')
        texts = row_texts()  # the texts of both brightnesses of a row by its focus
        badges = const_badges(source_setting('color_mode'))  # their static values once
        premium = premium_tag_providers({item.provider for item in items}, self.source_factory.provider_module)
        rows = [self.create_list_item(item, provider_translations, hosting_translations, texts, badges, premium) for item in items]
        for item, row in zip(items, rows):
            row.setProperty('item.filtered', 'true' if id(item) in cut else '')
        return rows

    # --- the selection of the user (the panel of the filter) ---

    @property
    def filters(self) -> SelectionPanel:
        """Return the panel of the filter (its view: of the template)."""
        return self.find('filters', SelectionPanel)

    @property
    def media(self) -> SelectionMedia:
        """Return the media of the selection of the sources (a movie, a show)."""
        return item_media(self.ffitem)

    def selection(self) -> Selection:
        """Return the compiled current selection of the user."""
        return compile_selection(self.filters.state(), langs=user_languages(), priority=self.source_factory.source_priority)

    def show_sources(self) -> None:
        """
        Show the sources the selection of the user lets through in its order (the filter off: all of them, the cut ones greyed out),
        the cursor on the source of the user (`cursor_source()`), the counter (all of them: when some is hidden), the text of no source.
        """
        state = self.filters.state()
        filter_on = state.get('filter', {}).get('on', True)
        state['filter'] = FilterState(**{**state.get('filter', {}), 'on': True})  # the filter off: its cut ones greyed out
        selection = compile_selection(state, langs=user_languages(), priority=self.source_factory.source_priority)
        with self._list_lock:
            anchor = self.cursor_source()
            shown = selected_sources(self.all_sources, selection, filtered=filter_on)
            cut = set() if filter_on else {id(src) for src in shown if not selection.passes(src)}
            self.sources = shown
            self.lists = self.list_items(shown, cut=cut)
            self.find('sources').rows = self.lists
            self.restore_cursor(anchor, selection)
        self.setProperty('sources.all', str(len(self.all_sources)) if len(shown) != len(self.all_sources) else '')
        self.filters.show_count(len(shown) - len(cut), len(self.all_sources))
        self.setProperty('noitem', 'false' if shown else 'true')
        hidden = not shown and bool(self.all_sources)
        self.setProperty('noitem.text', L(30946, 'Search in progress') if self._searching else
                         L(30865, 'The filter hides all {n} sources', n=len(self.all_sources)) if hidden else L(30256, 'No sources found.'))

    def cursor_source(self) -> Source | None:
        """Return the source the user stands on: the one he moved to since the list was shown, else the one kept (None: none)."""
        if self.sources and 0 <= (pos := self.item_list_widget.getSelectedPosition()) < len(self.sources) and pos != self._shown_pos:
            self._anchor = self.sources[pos]
        return self._anchor

    def restore_cursor(self, anchor: Source | None, selection: Selection) -> None:
        """
        Put the cursor on the source of the user (`anchor`): itself if shown, else the nearest shown one after it in the order of all of them
        (else before it); the source is kept (shown again later: the cursor goes back to it).
        """
        if not self.sources:
            self._shown_pos = -1
            return
        positions = {id(src): pos for pos, src in enumerate(self.sources)}
        pos = 0
        if anchor is not None:
            if (pos := positions.get(id(anchor), -1)) < 0:
                order = [id(src) for src in selection.select(self.all_sources, filtered=False)]
                at = order.index(id(anchor)) if id(anchor) in order else 0
                after = [positions[key] for key in order[at:] if key in positions]
                before = [positions[key] for key in order[:at] if key in positions]
                pos = after[0] if after else before[-1]
        self.item_list_widget.selectItem(pos)
        self._shown_pos = pos

    def show_filters(self) -> None:
        """Show the panel of the filter over the right column, the state of the user in it."""
        self.filters.open()
        self.setProperty(self.FILTERS_OPEN, 'true')

    def open_filters(self) -> None:
        """Open the panel of the filter over the right column: the focus on its tabs (then on its control focused last)."""
        self.show_filters()
        self.set_focus_shown(self.find('filters.tabs').id)

    def show_source_values(self) -> None:
        """Show the values of one source by the filter of the user."""
        assert self.source_tree is not None
        model = self.source_tree.model(self.filters.state().get('filter', {}))
        self.find('source_filter.values', TreeWidget).set_model(model, dimmed=self.source_tree.dimmed)

    def filter_of_source(self, src: Source) -> None:
        """
        Change the filter by the values of a source ("Change the filter…"): a tab of its own over the whole panel, the list of the values (they
        stay while the source is cut); "Done" / Back ends it (`end_filter_of_source()`).
        """
        if self.source_tree is None:
            self.source_tree_closes = not self.filters.opened
        state = self.filters.state()
        selection = compile_selection(state, langs=user_languages())
        if not self.filters.opened:
            self.show_filters()
        self.source_tree = FilterTree((selection.view(item) for item in self.all_sources), langs=user_languages(), state=state.get('filter', {}),
                                      source=selection.view(src))
        self.show_source_values()
        self.setProperty(self.SOURCE_FILTER, 'true')
        self.set_focus_shown(self.find('source_filter.values').id, shown=self.find('source_filter').id)

    def end_filter_of_source(self) -> None:
        """End the change of the filter by the values of one source: the panel again (closed if it was before it), the focus on the list."""
        self.source_tree = None
        self.setProperty(self.SOURCE_FILTER, '')
        self.filters.refresh_filter()
        if self.source_tree_closes:
            self.close_filters()
        else:
            self.setFocusId(self.find('sources' if self.sources else 'filters_button').id)

    def on_source_filter_done_clicked(self) -> None:
        """"Done": the end of the change of the filter by the values of one source."""
        self.end_filter_of_source()

    def on_source_filter_values_checked_changed(self, items: Sequence[FFItem]) -> None:
        """A value of the source changed: the filter of it."""
        model = self.find('source_filter.values', TreeWidget).model
        assert self.source_tree is not None and model is not None
        self.filters.change_filter(keys=self.source_tree.state(model, self.filters.state().get('filter', {})).get('keys', {}))
        self.show_filters_help()

    def on_source_filter_values_current_changed(self, pos: int) -> None:
        """Another value of the source: its help."""
        self.show_filters_help()

    def source_filter_menu(self, src: Source) -> ContextMenu:
        """Return the entries of the filter in the context menu of a source: hide / show its hosting, change the filter (none in the simple view)."""
        if not self.filters.ADVANCED:
            return []
        state = self.filters.state()
        menu: list[ContextMenuItem] = []
        key = SOURCE_KEYS['hosting']
        for value in key.get(compile_selection(state, langs=user_languages()).view(src)):
            hidden = state.get('filter', {}).get('keys', {}).get(key.path, {}).get(value) is False
            label = L(30928, 'Show hosting {hosting}', hosting=key.value_label(value)) if hidden else L(30929, 'Hide hosting {hosting}', hosting=key.value_label(value))
            menu.append((label, partial(self.set_hosting_hidden, value, not hidden)))
        menu.append((L(30930, 'Change the filter…'), partial(self.filter_of_source, src)))
        return menu

    def set_hosting_hidden(self, value: str, hidden: bool) -> None:
        """Hide a hosting by the filter of the user (must not) or show it (no decision)."""
        keys = deepcopy(self.filters.state().get('filter', {}).get('keys', {}))
        values = keys.setdefault('hosting', {})
        if hidden:
            values[value] = False
        else:
            values.pop(value, None)
        self.filters.change_filter(keys={path: decisions for path, decisions in keys.items() if decisions})
        self.filters.refresh_filter()
        if self.source_tree is not None:
            self.show_source_values()

    def close_filters(self) -> None:
        """Close the panel of the filter: the focus on the list (no source: on the button of the panel)."""
        self.filters.opened = False
        self.setProperty(self.FILTERS_OPEN, 'false')
        self.setFocusId(self.find('sources' if self.sources else 'filters_button').id)

    def show_filters_help(self) -> None:
        """Show the help of the focused control of the panel of the filter (of the change by the values of one source, else of the panel) under the list."""
        focused, text = self.focused_id(), ''
        values = self.find('source_filter.values', TreeWidget)
        if focused == self.find('source_filter', TabWidget).bar.id:
            text = SOURCE_FILTER_PAGES[0].help
        elif focused == self.find('source_filter.done').id:
            text = SOURCE_FILTER_DONE_HELP
        elif (self.source_tree is not None and values.view is not None and values.view.in_list(focused)
              and 0 <= (pos := values.view.position()) < len(values.view.model.rows)):
            text = self.source_tree.help(values.view.model.rows[pos].item, values.view.model, self.filters.state().get('filter', {}))
        else:
            text = self.filters.help_text()
        self.find('help').text = text

    def on_filters_current_changed(self) -> None:
        """Another row or tab of the panel: its help."""
        self.show_filters_help()

    def on_filters_changed(self) -> None:
        """The selection of the user changed: the sources of it."""
        self.show_sources()

    def on_filters_button_clicked(self) -> None:
        """Open the panel of the filter."""
        self.open_filters()

    def handle_source(self, *, play_mode: Optional[PlayMode] = None):
        """Try to resolve source. If success keep busy dialog active."""
        try:
            busy_dialog()
            if self._searching:  # a source chosen while searching: the search stops, the source plays
                self._playing = self._search_canceled = True
            position = self.item_list_widget.getSelectedPosition()
            auto_select = source_setting('auto_next') or source_setting('default_action') == 2
            play_mode = play_mode

            if auto_select:
                for i in range(position, len(self.sources)):
                    if resolved := self.source_factory.resolve_source(self.sources[i]):
                        fflog(f'[WIN] auto select: {position=}, {i=}, {resolved.url=}')
                        self.apply_source(resolved, play=play_mode)
                        break
                    play_mode = None
                else:
                    fflog(f'[WIN] auto select: not resolved ({position=}, len={len(self.sources)})')
                    close_busy_dialog()
                    control.infoDialog(L(32401, 'No stream available'), icon='WARNING')
            else:
                if resolved := self.source_factory.resolve_source(self.sources[position], info=True):  # it tells why it failed
                    fflog(f'[WIN] select: {position=}, {resolved.url=}')
                    self.apply_source(resolved, play=play_mode)
                else:
                    fflog(f'[WIN] select: not resolved ({position=})')
                    close_busy_dialog()
        except Exception:
            fflog_exc()
            close_busy_dialog()
        finally:
            self._playing = False
            if self._late_sources is not None:  # not resolved (no play, the window stays): the end of the search it waited with
                sources, self._late_sources = self._late_sources, None
                self.finish_search(sources)

    def handle_rescan(self):
        self.raise_exception(RescanSources(query=self.query, selection=self.filters.transient))
        self.close()
        # url = f"{control.plugin_urresolve_source.item.ffid}"
        # run_plugin(url)

    def handle_download(self):
        position = self.item_list_widget.getSelectedPosition()
        if resolved := self.source_factory.resolve_source(self.sources[position], info=True):
            downinfo = download_info(self.sources[position]) if settings.getBool('download.downinfo') else ''
            year = self.ffitem.year
            if settings.getBool('download.downlocaltitle'):
                if self.ffitem.episode:
                    dname = f"{self.ffitem.vtag.getTvShowTitle()}.S{self.ffitem.season:02d}E{self.ffitem.episode:02d}"
                    self.show_item = self.ffitem if self.ffitem.ref.is_show else self.ffitem.show_item
                    year = int(self.show_item.vtag.getYear())
                else:
                    dname = self.ffitem.title
            else:
                if self.ffitem.episode:
                    dname = f"{self.ffitem.vtag.getEnglishTvShowTitle()}.S{self.ffitem.season:02d}E{self.ffitem.episode:02d}"
                    self.show_item = self.ffitem if self.ffitem.ref.is_show else self.ffitem.show_item
                    year = int(self.show_item.vtag.getYear())
                else:
                    dname = self.ffitem.vtag.getOriginalTitle()
            from lib.ff.downloader import download
            thread = Thread(
                target=download,
                args=(
                    dname,
                    year,
                    self.getProperty('item.art.poster'),
                    downinfo,
                    resolved.url,
                ),
            )
            thread.start()

    @property
    def item_list_widget(self) -> ControlList:
        """Return the Kodi list of the sources."""
        return self.find('sources').list_control()  # type: ignore[attr-defined]

    def handle_rebuy(self):
        position = self.item_list_widget.getSelectedPosition()
        src = self.sources[position]
        if resolved := self.source_factory.resolve_source(src, info=True, for_resolve={"buy_anyway": True}):
            self.apply_source(resolved)

    # Progress dialog compatibility methods (for source searching)

    def start_search(self) -> None:
        """Start search mode - show progress UI."""
        self._searching = True
        self._search_canceled = False
        self.setProperty('searching', 'true')
        self.setProperty('search.list', '')
        self.setProperty('noitem', 'false')  # Hide "no sources" during search
        self.setProperty('search.message', '')
        self.setProperty('search.percent', '0')
        self.setProperty('search.time.percent', '0')
        self.setProperty('search.time.spend', '0')
        self.setProperty('search.time.left', '0')
        self.setProperty('search.time.total', '0')
        # Focus will be set in onInit() when window is shown

    def show_end_time(self) -> None:
        """
        Show the time the video ends if played now: from its resume point (`ffitem.progress`, the progress of the accounts: the init thread
        of the search reads it, so the window shows it again on the progress of the search and at its end - the clock goes on too).
        """
        progress = self.ffitem.progress
        self.setProperty('item.endtime', endtime(self.ffitem.vtag.getDuration(), progress.progress if progress else 0))

    def update(self, percent: int, message: str = '', *, providers: Sequence[str] | None = None) -> None:
        """Update search progress (compatible with SourcesProgressDialog API)."""
        if not self._searching:
            return
        try:
            self.show_end_time()
            # Update progress bar
            self.find('progress').percent = self.find('list_progress').percent = percent
            self.setProperty('search.percent', str(percent))
            # Split message into lines and set properties (like old SourcesProgressDialog)
            lines = message.split('\n') if message else []
            # Clear previous properties
            for prop in ['search.line.0', 'search.line.1', 'search.line.2', 'search.line.3', 'search.line.4']:
                self.setProperty(prop, '')
            # Set new lines - map lines[0-4] to properties
            for i in range(5):
                self.setProperty(f'search.line.{i}', lines[i] if i < len(lines) else '')
            # Handle remaining lines
            remaining = ''
            if providers:
                # Build remaining scrapers line
                label = L(32406, 'Remaining providers: %s')
                if len(providers) > 6:
                    remaining = label % len(providers)
                elif len(providers) > 0:
                    remaining = label % (', '.join(self.pretty_provider_name(p) for p in providers))
            self.find('remaining').text = remaining  # type: ignore[attr-defined]
        except Exception:
            fflog_exc()

    def update_time(self, spend: float, total: float) -> None:
        """Update search progress time."""
        if not self._searching:
            return
        try:
            percent = 100 * spend / (total or 1)
            percent = max(0, min(100, int(percent)))  # clamp percent to [0, 100]
            self.find('time_progress').percent = self.find('list_time').percent = percent
            self.setProperty('search.time.percent', str(percent))
            self.setProperty('search.time.spend', str(int(spend)))
            self.setProperty('search.time.left', str(int(total - spend)))
            self.setProperty('search.time.total', str(int(total)))
        except Exception:
            fflog_exc()

    def iscanceled(self) -> bool:
        """Check if search was canceled (compatible with SourcesProgressDialog API)."""
        return self._search_canceled

    def on_close(self) -> None:
        """Closing the window cancels the search: the providers stop and the play script can end soon."""
        self._search_canceled = True

    def show_found(self, sources: Sequence[Source]) -> None:
        """
        Show the sources found so far (prepared) while searching: the list instead of the window of the progress, the tree of an open panel
        made again from time to time (`const.sources_dialog.filters.refresh_interval`).
        """
        if not self._ready or not self._searching:
            return
        with self._list_lock:
            self.filters.sources = self.all_sources = self.process_debug_items(sources)
            self.show_sources()
        self.setProperty('search.list', 'true')
        if self.filters.opened and self.source_tree is None and monotonic() >= self._tree_due:
            self._tree_due = monotonic() + const.sources_dialog.filters.refresh_interval
            self.filters.refresh_filter_tree()

    def finish_search(self, sources: Sequence[Source]) -> None:
        """Finish search mode - hide progress UI, show results (`sources`: all of them prepared, the window shows the selection of the user)."""
        if not self._ready:
            return  # closed meanwhile (closing cancels the search), nothing to show
        if self._playing:  # a chosen source being resolved: this end shown if it fails (`handle_source()`)
            self._late_sources = sources
            self._searching = False
            return
        self.filters.sources = self.all_sources = self.process_debug_items(sources)  # fake items too
        self.show_end_time()
        self.filters.filter_tree = None  # new sources: their values in the tree
        self._searching = False
        self.show_sources()
        cancel, rescan = self.find('cancel').id, self.find('rescan', PushButton)
        rescan.enabled = False  # a press late by a moment on the button in the place of Cancel does not search again
        on_cancel = self.focused_id() == cancel
        if self.lists and (on_cancel or not self.focused_id()):
            # move the focus before the search UI (with the focused cancel button) hides, Kodi would fall back
            # to the default control (the cancel button, hidden then)
            self.setFocusId(self.find('sources').id)
        self.setProperty('searching', 'false')
        self.setProperty('search.list', '')
        if self.lists:
            if source_setting('default_action') == 2:
                self.handle_source()
        elif self.all_sources:  # the filter hides all of them
            self.setFocusId(self.find('filters_button').id)
        xsleep(const.sources_dialog.rescan_guard)
        if self._ready:
            rescan.enabled = True
            if not self.lists and not self.all_sources:
                self.setFocusId(rescan.id)

    def edit_search(self) -> bool:
        if query := EditDialog(query=self.query, default_query=self.default_query, raise_rescan=False).doModal():
            self.query = query
            # self._set_window_title()
            self.raise_exception(RescanSources(query=query, selection=self.filters.transient))
            self.close()
            return True
        return False

    def on_sources_activated(self, index: int) -> None:
        """A source chosen: resolve it (the selected one), play it."""
        self.handle_source()

    def on_rescan_clicked(self) -> None:
        """Search again (first edit the search: `const.sources_dialog.rescan_edit`)."""
        if const.sources_dialog.rescan_edit:
            self.edit_search()
        else:
            self.handle_rescan()

    def on_edit_button_clicked(self) -> None:
        """Edit the search (a changed one searches again)."""
        self.edit_search()

    def on_cancel_clicked(self) -> None:
        """Cancel the search."""
        self._search_canceled = True

    def on_action(self, action: Action) -> bool | None:
        """Back: close the panel of the filter, cancel the search or close; the menu of a source."""
        action_id = action.getId()
        if action_id in CANCEL_ACTIONS:
            if self.filters.back():
                return True
            if self.source_tree is not None:
                self.end_filter_of_source()
                return True
            if self.filters.opened:
                self.close_filters()
                return True
            # If searching, cancel search instead of closing window
            if self._searching:
                self._search_canceled = True
            else:
                self.close()
        elif action_id in MENU_ACTIONS and self.focused_id() == self.find('sources').id:
            context_menu_items: ContextMenu = []
            if settings.getBool("downloads"):
                context_menu_items.append((control.lang(30115), self.handle_download))
            position = self.item_list_widget.getSelectedPosition()
            if not 0 <= position < len(self.sources):
                return True
            src = self.sources[position]
            for act in src.menu_actions():
                label = src.action_label(act)
                if act == 'buy':
                    context_menu_items.append((label, self.handle_rebuy))
                elif is_play_mode(act):
                    context_menu_items.append((label, partial(self.handle_source, play_mode=act)))
            context_menu_items.extend(self.source_filter_menu(src))
            if len(context_menu_items) >= 1:
                ContextMenuDialog(menu=context_menu_items).doModal()
        # elif self.focused_constrol_id == self.find('sources').id and action_id == ACTION_MOVE_LEFT:
        #     Panel().doModal()

    def on_focus(self, control_id: int) -> None:
        """The focus moved: the right edge of the right column (a move right off the screen from its buttons) opens the panel of the filter."""
        control_id = control_id
        self.focused_constrol_id = control_id
        # fflog(f' ######### {control_id = }')
        if control_id == self.FILTERS_EDGE:
            self.open_filters()
        elif self.filters.opened and self._widget_tree is not None and self._widget_tree.widget_of(control_id) is not self.filters:  # not its edges
            self.show_filters_help()

    def pretty_provider_name(self, provider: str) -> str:
        return self.rx_provider_rename.sub(lambda mch: self.provider_suffixes.get(mch['suffix'], mch['suffix']), provider)

    @staticmethod
    def listed_badges(badges: bool | str | SourceAttributeBadge | Sequence[str | SourceAttributeBadge] | None) -> list[SourceAttributeBadge]:
        """Return the badges of the rules (`SourceAttribute.badge`: True - the default one, a name of an icon, a badge, a list) as a list."""
        if not badges:
            return []
        if badges is True:
            badges = [SourceAttributeBadge(icon=DEFAULT_BADGE_ICON)]
        elif isinstance(badges, str) or not isinstance(badges, Sequence):
            badges = [badges]
        return [SourceAttributeBadge(icon=badge) if isinstance(badge, str) else badge for badge in badges]

    def badge_tags(self, badges: bool | str | SourceAttributeBadge | Sequence[str | SourceAttributeBadge], *, source_icon: bool) -> dict[str, TagData]:
        """
        Return the data of the tags / edge marks of a row of the badges of the rules (`SourceAttribute.badge`) by their keys - the names
        of their slots (`BadgeSlot.name`, `BADGE_SLOTS`): `<kind>_<part>_<anchor>_<n>`, `n` the slot of the place (the badges of one place by their `order`,
        from 1; a badge over the slots of its place is not shown); a number its text, an icon / a ribbon its image (`find_badge()`; a
        ribbon of none: the one of the style), an engraved line its image (`line.<style>.<part>.<place>` of its style, its part and place,
        else `line.<style>.<w|e|n|s>` of its side, else `line.<style>.<v|h>` of its direction; no tint; a plain one or none such: none -
        `white.png` in its colour), the image of an edge mark on a focused row of another brightness too (the variant of
        `focused_image_variant()`, `TagData.icon_focused`), its colour (none: `BADGE_COLORS`).
        With the icon of the source (`source_icon`) the icons of the right part in its corners / side E lie beside it (their place moves
        left in the template), the ones `over_item_icon` over it.
        """
        rules = self.listed_badges(badges)
        style, focused, folder = tokens(), focused_image_variant(), Path(dataPath) / 'badges'
        taken: dict[BadgeSlot, set[int]] = {}  # the slots of a place taken
        tags: dict[str, TagData] = {}
        for badge in sorted(rules, key=lambda badge: source_attribute_badge_key(badge).order):
            key = source_attribute_badge_key(badge)
            if key.type == 'number' and badge.get('number') is None or key.type == 'text' and not badge.get('text'):
                continue
            # li.setProperty(f'tag.{place}_{n}.shown', 'true')  # a number shown (now always: `TagData.properties()` by `set_tags()`)
            over_icon = source_icon and key.type == 'icon' and key.panel == 'right' and 'E' in key.place and key.over_item_icon
            part = 'over_icon' if over_icon else key.panel
            place = BadgeSlot(part, key.type, key.place)  # its first slot: the slots of the place by their numbers
            used, count, wanted = taken.setdefault(place, set()), self.badge_places.get(place, 0), badge.get('slot')
            if not count or wanted is not None and not 1 <= wanted <= count:
                no_badge_slot(place if not count or wanted is None else BadgeSlot(part, key.type, key.place, wanted))
                continue
            n = next((n for n in range(1, count + 1) if n not in used), 0) if wanted is None else 0 if wanted in used else wanted
            if not n:  # past the slots of its place (its slot taken): not shown
                continue
            used.add(n)
            color = (badge.get('color') or style.values[BADGE_COLORS[key.type]]) if key.type in BADGE_COLORS else ''
            images: tuple[str, ...] = ()
            if key.type in ('icon', 'ribbon'):
                images = (badge.get('icon') or (DEFAULT_BADGE_ICON if key.type == 'icon' else ''),)
            elif key.type == 'line' and (line_style := badge.get('style') or 'plain') != 'plain':  # its image of its part and place, its side, its direction
                side = (f'line.{line_style}.{key.place.lower()}',) if key.place in SIDE_CORNERS else ()
                direction = f'line.{line_style}.{"v" if key.place in ("W", "E", "V") else "h"}'
                images = tuple(dict.fromkeys((f'line.{line_style}.{part}.{key.place.lower()}', *side, direction)))
            if (icon := badge_image(images, folder)) and key.type == 'line':  # no tint
                color = style.color.image
            icon_focused = badge_image(images, folder, focused) if focused and icon and key.type in MARK_KINDS else ''
            text = str(badge.get('number', '')) if key.type == 'number' else tag_text(badge.get('text', '')) if key.type == 'text' else ''
            tags[BadgeSlot(part, key.type, key.place, n).name] = TagData(text=text, icon=icon, icon_focused=icon_focused, color=str(color))
        return tags

    def create_list_item(self, item: Source, provider_translations: Dict[str, str], hosting_translations: Dict[str, str],
                         texts: RowTexts, mode_badges: Sequence[SourceAttributeBadge], premium: Container[str]) -> ListItem:
        """Return the list item of the source: its properties, its badges (`premium`: the providers which show the tag PREMIUM)."""

        def make_color(color: str | int | float | Literal[False] | None, default: str | Literal[False]) -> str:
            if color is None:
                color = default
            if color is False:
                color = '01000000'
            elif isinstance(color, (int, float)):
                if default:
                    if len(default) != 8:
                        default = f'FFFFFFFF{default}'[-8:]
                    if color > 1:
                        alpha = color
                    else:
                        alpha = int(default[:2], 16) * max(0, min(1, color))
                    alpha = max(1, min(255, int(alpha + .5)))  # round alpha and ensure it's in range 1-255
                    color = f'{int(alpha):02X}{default[2:]}'
                else:
                    color = '01000000'
            return color

        hosting = item.hosting
        if not hosting.startswith('plugin.video.'):
            hosting = clear_source(item.hosting)
        info = source_info(item.get('info') or '')
        if pack := PACK_LABELS.get(item.get('pack') or ''):
            info = f'{pack} | {info}' if info else pack
        fflog.debug(f'[WINDOWS]:  {item=}')

        provider = self.pretty_provider_name(item.provider.partition(':')[2] if item.addon else item.provider)  # the add-on in its badge
        provider = provider_translations.get(provider, provider)
        quality = (item.get('quality') or '').strip()

        li = ListItem(label=' · '.join(text for text in (provider, hosting, quality) if text))  # a plain text, the rows show its parts
        li.setProperty('item.info', remove_non_bmp(info))
        li.setProperty('item.hosting', hosting_translations.get(hosting, hosting))
        li.setProperty('item.colored', item.get('color_identify') or '')
        li.setProperty('item.colored.default', source_setting('default_color'))
        # the colour of the provider: the background of the row, or (`color_mode` accent) a bar at its left and its name - the row of
        # the setting `accent_background` ('': a row of the theme)
        color = li.getProperty('item.colored') or li.getProperty('item.colored.default') or ''
        color_mode: SourceItemColorMode = source_setting('color_mode')
        accent = color if color_mode == 'accent' else ''
        li.setProperty('item.background', source_setting('accent_background') if accent else color)
        if source_setting('row_contrast'):  # the texts of its parts by its brightness (off: the texts of the theme)
            for name, value in inverse_rows(li.getProperty('item.background'), texts, color_mode).items():
                li.setProperty(name, value)
        li.setProperty('item.addon.background', make_color(item.attr.addon_color, color))
        li.setProperty('item.unresolvable', 'true' if is_greyed_out(item) else '')
        # a debrid of the best way has the torrent cached: the symbol the font of its label draws
        li.setProperty('item.cached', symbol('cached', self.CACHED_STYLE) if item.resolvability and item.resolvability.cached else '')

        size = item.get('size')
        if size is not None:
            li.setProperty('item.size', str(size))
        fflog(f'[WINDOWS] row: {provider} | {hosting} | {quality} | {info} | {size or ""} | {item.url}')  # the whole source: debug

        li.setProperty('item.addon', addon_title(item.addon) if item.addon else '')

        expires = (item.get('on_account_expires') or L(30816, 'account')) if item.get('on_account') else ''

        provider_text = f'[COLOR {accent}]{provider}[/COLOR]' if accent else provider  # the name in the colour of its provider

        def left_lines(strong: str, focused: bool) -> list[str]:
            """
            Return the lines of the left part of the row (one label each: one line scrolls, the others end with "…"), the stressed colour;
            `focused`: the name in the colour of the text (a row filled by the focus; the colour of the provider stays on its bar).
            """
            name = provider if focused else provider_text
            left = []
            # left.append('COCO')
            if item.get('on_account'):
                left.append(f'[COLOR {strong}][UPPERCASE][B]{quality}[/B][/UPPERCASE][/COLOR] [UPPERCASE][B]{name}[/B][/UPPERCASE]')
                left.append(f'({expires})')
            else:
                if quality:
                    left.append(f'[COLOR {strong}][UPPERCASE][B]{quality}[/B][/UPPERCASE][/COLOR]')
                left.append(f'[UPPERCASE][B]{name}[/B][/UPPERCASE]')
            return left

        if expires:
            li.setProperty('item.on_account_expires', expires)
        for focused, (own, other) in texts.items():  # by the focus; inverse: on a part of the other brightness (`inverse_rows()`)
            for suffix, text in (('', own), ('.inverse', other)):
                for n, line in enumerate(left_lines(text.strong, focused), 1):
                    li.setProperty(f'item.left.{n}{".focused" if focused else ""}{suffix}', line)

        if item.transfer_short:  # the overlay "the transfer is insufficient": the account was its way (no debrid / other way opens it)
            li.setProperty('item.no_transfer', str(item.get('no_transfer')))

        # $INFO[ListItem.Property(item.quality), [COLOR ffffffff][UPPERCASE][B],[/B][/UPPERCASE][/COLOR]][CR]$INFO[ListItem.Property(item.provider), [UPPERCASE][B],[/B][/UPPERCASE]]</label>
        # $INFO[ListItem.Property(item.quality), [COLOR ffffffff][UPPERCASE][B],[/B][/UPPERCASE][/COLOR]]$INFO[ListItem.Property(item.provider), [UPPERCASE][B],[/B][/UPPERCASE]][CR]$INFO[ListItem.Property(item.on_account_expires), (,)]</label>

        for key in ['url', 'language', 'quality']:
            if item.get(key) is None:
                fflog(f'[WINDOWS]: ERORR: No key {key!r} in item {item!r} !!!')
            li.setProperty(f'item.{key}', (item.get(key) or '').strip())
        li.setProperty('item.info2', remove_non_bmp((item.get('info2') or '').strip()))
        # replace provider suffix
        li.setProperty('item.provider', provider)

        if not li.getProperty('item.info2'):
            li.setProperty('item.info', li.getProperty('item.info').lstrip('| '))

        if source_setting('file_name'):
            filename = item.file_name  # the provider's, or the one of the URL
            if filename:
                filename = remove_non_bmp(filename)  # emoji: Kodi cuts characters to 16 bits
                if hosting:
                    filename = f': {filename}'
            li.setProperty('item.id', filename)

        if source_setting('service_icons') and (icon := item.get('icon')):
            li.setProperty('item.icon', icon)

        # -- badges, ribbons and (under)lines; the constant ones of the colour mode (`const_badges()`: the bar of the colour of the
        #    provider, the separator of the parts), the tag of the way which opens it: the last ones of their places - a badge of a rule
        #    there wins --
        names = {'accent': accent, 'color': color, 'source': item}  # the names of the '=' values of the constant badges
        badges: list[SourceAttributeBadge] = self.listed_badges(item.attr.badge)
        badges.extend(row for badge in mode_badges if (row := row_badge(badge, names)) is not None)
        if tag := route_tag(item, premium=item.provider in premium):
            badges.append(SourceAttributeBadge(type='text', text=tag, order=DERIVED_BADGE_ORDER))
        if badges:
            set_tags(li, **self.badge_tags(badges, source_icon=bool(li.getProperty('item.icon'))))

        return li

# Fonts:
#   - title / heading: ~40, font40_title (Estuary), font38_title/font40 (Eestouchy), font_topbar (AH2R)
