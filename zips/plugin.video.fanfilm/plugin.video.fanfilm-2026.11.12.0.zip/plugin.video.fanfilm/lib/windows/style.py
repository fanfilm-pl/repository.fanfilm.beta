"""
The style of the FF windows: the tokens of their look (colours, spacing, metrics, font roles, textures), each declared once
here with its default (`TOKENS`), and the resolved style (`tokens()`) the widget templates (`{tokens.color.text}`) and the
window code (`tokens().color.text`) read instead of literals.

A token name is its kind, its role, its state (`color.text.focused`); a name is also the parent of the longer ones
(`tokens.color.text` is the colour, `tokens.color.text.focused` another token). A value may be an expression (`evaluate()`):
a reference to another token `{color.text}` (its value, through any number of levels) or a colour function of references
(`alpha({color.accent}, 99)`, `lighter({color.bg.panel}, 10%)`, `mix({color.accent}, {color.error}, 50%)`: `COLOR_FUNCTIONS`).
A wrong expression (a cycle, an unknown name, a bad argument) is logged and the declared default of its token is used: the
style never stops a window. The spacing steps (`space.*`) are multiplied by `space.density`. A named choice (`tab.shape`) takes
one of the values declared at its token (`choices`).

The surfaces nest in levels (`SURFACES`: the dialog frame, a panel, a card, a tag); each level has its background, edge, edge
width, inner spacing and texture (`color.bg.<level>`, `color.frame.<level>`, `metric.frame.box`, `space.pad.<level>`,
`texture.<level>`). The states of a row (a card) and of a tab: normal, focused (`.focused`), current with the focus elsewhere
(`.selected`); disabled is its text (`color.text.disabled`). A frame has a shape (`FRAME_SHAPES`, the default of its level
`frame.shape.<level>`): its fill alone, the edge of its level (a box), sunken or raised (the light and the dark halves of its edge,
`color.bevel.*`), or a line instead of a surface; a tab joins its panel in a named shape (`tab.shape`, `TAB_SHAPES`). A focused control has
the focus ring on its edge (`color.focus`, `metric.focus`, the family `texture.focus` by the corner radius of its texture).

The style is resolved from layers (`resolve()`, each one overrides the previous ones): the declaration here (the defaults of the
chosen variant of the themes: `Token.light` of the light one, `Token.default` of any other one), the style files
(`style_files()`): `resources/style.json` and `resources/style.<variant>.json` (its variant) of the active themes (`lib.ff.theme`)
from the least important one (the base theme), the local style of the user (`local-style.json` in the add-on profile) and
`local-style.<variant>.json` of the chosen variant. A style file is a flat JSON object `{"<token>": value}`:
a key `//…` is a comment, a list is a font role `[size ratio, bold]`. A wrong entry (a name not declared here, a value not of the
kind of its token, a wrong expression) is logged and its token keeps the value of the lower layers / its default; a broken file is
skipped as a whole (logged, told once in a Kodi session). The windows read the style of the files of the last `check_style()`
(the open of a window: the key of the cache of the generated windows).

The local style is written one token at a time (`set_local_token()`: the rest of the file kept), a colour into the file of the
chosen variant. Over the local style lies the preview (`set_preview_token()`: in the memory of the interpreter, the inspector
tries a value before it is saved). `Style.origins` tells the layer of the value of every token.

The colours of the skin (a switch of the user, `theme.skin_colors_chosen()`; any variant) are a layer of their own (`SKIN`, `skin_layer()`)
over the declaration, under the style files (a theme or the local style setting the accent wins): the accent of the skin
(`skinfonts.active_skin_accent()`), made lighter / darker with its hue kept until the texts and the marks are readable
(`render.contrast_problems()`, `layered_style()`); the tokens FF derives of the accent follow it.
"""

from __future__ import annotations
from typing import Any, Callable, Iterable, Mapping, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from functools import partial
from pathlib import Path
from types import SimpleNamespace
import colorsys
import hashlib
import json
import glob
import re
from attrs import Factory, evolve, field, frozen
from ..ff.config import file_stat, FileStat
from ..ff.logs import fflog
from ..ff.theme import LIGHT_VARIANT
from ..kolang import L

@frozen(kw_only=True)
class TabShape:
    """A named shape of a tab (`tab.shape`): its corners and its joint with its panel (the texture family `texture.tab`)."""

    #: The corners cut on a diagonal (else rounded).
    chamfer: bool = False
    #: The current tab flares out where it meets its panel (inverted corners: an arc, a diagonal of a chamfered one); else straight.
    flare: bool = True
    #: No tab texture: the look of a button by a line instead of a panel (the focused button, the current one `texture.row.selected`).
    flat: bool = False
    #: No panel: the line between the bar and its pages drawn by the tabs (each a piece of it), the current one an outline of the line
    #: open to the pages (`popup_texture()`) - the line broken there.
    line: bool = False

    @property
    def joined(self) -> bool:
        """Return True for a tab joined to its panel (a texture of the family `texture.tab`): neither flat nor of a line."""
        return not self.flat and not self.line


#: The named shapes of a tab (the choices of `tab.shape`): rounded with arcs to the panel, chamfered with diagonals, rounded straight,
#: flat (a button by a line: a tab bar beside a separator, no panel to join), a line (a tab stuck to the line beside the bar: the current
#: one outlined, the line broken at it).
TAB_SHAPES: dict[str, TabShape] = {
    'arc': TabShape(),
    'bevel': TabShape(chamfer=True),
    'straight': TabShape(flare=False),
    'flat': TabShape(flare=False, flat=True),
    'line': TabShape(flare=False, line=True),
}

#: The orientation of a line (`FrameShape.line`): '' none (a surface), horizontal, vertical.
LineOrientation: TypeAlias = Literal['', 'horizontal', 'vertical']


@frozen(kw_only=True)
class FrameShape:
    """
    A named shape of a frame (the parameter `shape` of a frame, the default of a level `frame.shape.<level>`; Qt: QFrame.Shape and
    QFrame.Shadow in one choice): its outline over the fill of its level, or a line instead of a surface.
    """

    #: The edge of its level around it (`color.frame.<level>`, `metric.frame.box`: under its background, an outline over a translucent one).
    box: bool = False
    #: The colour token of the top-left half of its edge lit from the top-left (`color.bevel.*`, `metric.bevel`), '' none.
    top_left: str = ''
    #: The colour token of the bottom-right half.
    bottom_right: str = ''
    #: A line across its place instead of a surface (`separator`: `color.separator`, `metric.separator`), '' a surface.
    line: LineOrientation = ''


#: The shapes of a frame: its fill alone, with the edge of its level (a box), sunken (lit from the top-left: the top-left half of its
#: edge dark, the bottom-right one light), raised (the other way); a horizontal / vertical line (no surface: a separator).
FRAME_SHAPES: dict[str, FrameShape] = {
    'none': FrameShape(),
    'box': FrameShape(box=True),
    'sunken': FrameShape(top_left='color.bevel.dark', bottom_right='color.bevel.light'),
    'raised': FrameShape(top_left='color.bevel.light', bottom_right='color.bevel.dark'),
    'hline': FrameShape(line='horizontal'),
    'vline': FrameShape(line='vertical'),
}
#: The shapes of a surface (the choices of the default of a level, `frame.shape.<level>`): not a line.
SURFACE_SHAPES: tuple[str, ...] = tuple(name for name, shape in FRAME_SHAPES.items() if not shape.line)
#: The outlines of an open popup card (the choices of `popup.shape`, `gui.popup_edge()`): closed - a box (the line between the field and the
#: card), joined - open on the side of its field (the field and the card one shape: `gui.popup_texture()`).
POPUP_SHAPES: tuple[str, ...] = ('closed', 'joined')
#: Where a label lies in its place: the label of a group of rows breaking the line of its separator across the row (`row_separator`) -
#: at the start (after a short line), in the middle, at the end (before a short line); the title of a tab (`tab.align`).
GROUP_ALIGNS: tuple[str, ...] = ('left', 'center', 'right')
#: How far a tag sticks out of its host (`gui.anchor_place()`), from the edge it lies on: up - out across that edge, side - past the
#: corner along it (across the other side of its corner), corner - both, inside - none, flush - none, in the corner itself (a tag: no
#: room to the side of its host, rounded at that corner and the opposite one - a tab of the corner).
TAG_OUTS: tuple[str, ...] = ('up', 'side', 'corner', 'inside', 'flush')
#: The edge of a tag in a corner of its host (the slots of the corner go along it): the horizontal side of the corner (N, S) or the
#: vertical one (W, E).
TAG_EDGES: tuple[str, ...] = ('horizontal', 'vertical')

#: The kind of a token: a colour (`AARRGGBB`), a spacing step (int, `space.density` scales it), a factor (float), a metric (int),
#: a font role (a skin font name, or the size ratio to the normal font and the bold flag), a texture (a file of the media folder),
#: a named choice (one of the values declared at the token).
TokenKind: TypeAlias = Literal['color', 'space', 'factor', 'metric', 'font', 'texture', 'decor', 'choice']
#: A decoration in the value of a `decor.*` token: its image and its period (months and days, inclusive).
RX_DECOR: re.Pattern[str] = re.compile(r'(?P<image>[^@,]+?)(?:@(?P<first>\d\d-\d\d)\.\.(?P<last>\d\d-\d\d))?')
#: The value of a token (also an expression: `{color.text}`, `alpha({color.accent}, 99)`).
TokenValue: TypeAlias = 'str | int | float | tuple[float, bool]'
#: The origin of a token value (`Style.origins`): `DECLARATION`, the style file of its layer, `PREVIEW`; `LAYER` a plain mapping
#: given to `resolve()` (a test, a tool).
Origin: TypeAlias = 'str | Path'

#: The local style of the user (in the add-on profile), the last layer of the files.
LOCAL_STYLE: str = 'local-style.json'
#: The origin of a value of the declaration (`TOKENS`), also the default used for a wrong value.
DECLARATION: str = 'declaration'
#: The origin of a value of the preview layer (`set_preview_token()`).
PREVIEW: str = 'preview'
#: The origin of a value of the layer of the colours of the skin (`skin_layer()`).
SKIN: str = 'skin'
#: The changes of the lightness of the accent of the skin tried in their order (`layered_style()`: a part of the way to white / black, its
#: hue kept): the first one with no new contrast problem wins.
SKIN_STEPS: tuple[str, ...] = tuple(f'{amount}%' for amount in range(0, 55, 5))
#: The origin of a value of a layer with no origin (a plain mapping).
LAYER: str = 'layer'
#: Kodi's white diffuse colour: a texture drawn as it is (a tint of this colour is no `colordiffuse`: a button, `color.bg.button`).
NO_TINT: str = 'FFFFFFFF'

#: The start of an expression (`evaluate()`): a reference `{name}` or a function `name(`; any other value is a literal.
RX_EXPRESSION: re.Pattern[str] = re.compile(r'\{|[a-z]+\(')
#: A plain argument of a function: a number, a percent, a hex alpha / colour.
RX_ARG: re.Pattern[str] = re.compile(r'[0-9A-Fa-f.]+%?')
#: The parts of an expression: a reference, a function with its bracket, a closing bracket, a comma, a plain argument; any other
#: character is a part of its own (a syntax error); the spaces are skipped.
RX_PART: re.Pattern[str] = re.compile(rf'\{{[a-z.]+\}}|[a-z]+\(|[),]|{RX_ARG.pattern}|\S')
#: An ARGB colour (`AARRGGBB`).
RX_COLOR: re.Pattern[str] = re.compile(r'[0-9A-Fa-f]{8}')
#: A number of an argument (points), with `%` a percent.
RX_NUMBER: re.Pattern[str] = re.compile(r'(\d+(?:\.\d+)?)(%?)')


@frozen
class Token:
    """A token of the style: its name, its default value."""

    #: The name: the kind, the role, the state (`color.text.focused`).
    name: str
    #: The default value (a literal or a reference to another token).
    default: TokenValue
    #: The default of the light variant of the themes (`default_of()`), None: `default` (the same on a light skin).
    light: TokenValue | None = field(default=None, kw_only=True)
    #: A focused element filled by the accent or a thing on its fill: its `light` default taken by another variant with the colours of the
    #: skin (`skin_layer()`; as a skin fills its focus).
    focus_fill: bool = field(default=False, kw_only=True)
    #: The user may change it in the settings (a few tokens; the rest: a theme or the local style).
    adjustable: bool = field(default=False, kw_only=True)
    #: The label of an adjustable token in the settings (the language of the call), None: its name.
    label: Callable[[], str] | None = field(default=None, kw_only=True, eq=False)
    #: The values of a named choice (its kind: `choice`), () another kind.
    choices: tuple[str, ...] = field(default=(), kw_only=True)
    #: The kind of the value: `choice` for a named choice, else the first part of the name by default.
    kind: TokenKind = field(default=Factory(lambda self: 'choice' if self.choices else self.name.partition('.')[0], takes_self=True), kw_only=True)
    #: The nine-slice border of a texture with no `b` part in its name (Kodi `border`, `gui.texture_border()`), '' none.
    border: str = field(default='', kw_only=True)
    #: The inset of the content in a frame texture (Kodi `bordersize`, `gui.texture_inset()`), 0 none.
    inset: int = field(default=0, kw_only=True)
    #: The corner radius (rounded) of a texture with no corner part in its name (`r` / `k`, `gui.texture_radius()`: the focus ring of its element), 0 none.
    radius: int = field(default=0, kw_only=True)

    def default_of(self, variant: str) -> TokenValue:
        """Return the default of the variant of the themes: `light` of the light one (if it has it), else `default`."""
        return self.light if variant == LIGHT_VARIANT and self.light is not None else self.default


#: The tokens of the style of the FF windows.
TOKENS: tuple[Token, ...] = (
    # the text
    #: plain text: labels, buttons without the focus, fields, rows
    Token('color.text', 'B3FFFFFF', light='E6101418', adjustable=True, label=lambda: L(30595, 'Text')),
    Token('color.text.focused', 'FFFFFFFF', adjustable=True, label=lambda: L(30596, 'Focused text')),  # the text with the focus
    Token('color.text.strong', 'FFF0F0F0', light='FF0A0D10'),  # the stressed text: the heads of panels, the labels of rows
    #: the stressed text of a focused row (a card; the current one, the focus elsewhere, too)
    Token('color.text.strong.focused', '{color.text.strong}', light='{color.text.focused}', focus_fill=True),
    Token('color.text.title', 'BFFFFFFF', light='FF1B2734'),  # the title of a dialog (the heading role)
    Token('color.text.dim', '99FFFFFF', light='F2394552'),  # the background text: summaries, states
    #: the background text of a focused row (a card), a grayed one there
    Token('color.text.dim.focused', '{color.text.dim}', light='alpha({color.text.focused}, F2)', focus_fill=True),
    #: the plain text of a focused row (a card; `color.text.focused`: a focused control)
    Token('color.text.row.focused', '{color.text}', light='{color.text.focused}', focus_fill=True),
    Token('color.text.hint', 'alpha({color.text}, 80)', light='alpha({color.text}, A6)'),  # the hint of a field, an inactive column
    Token('color.text.disabled', '4DFFFFFF', light='B3505A66'),  # disabled: a Kodi control (disabledcolor), a widget with its reason (gray_text)
    Token('color.text.match', 'FFFFD54F', light='FF00594D'),  # a match of the filter, "in cache"
    #: a match of the filter in the text of a focused row (a card)
    Token('color.text.match.row.focused', '{color.text.match}', light='FFFFE082', focus_fill=True),
    Token('color.shadow', 'FF000000', light='00000000'),  # the shadow of the text
    Token('color.link', 'FFE05555', light='FF8A1C1C'),  # a link (the sign-in)
    Token('color.code', 'FFB3B337', light='FF4F4F00'),  # a code to type (the sign-in)
    # the states
    Token('color.accent', 'FF66CCFF', light='FF00689E', adjustable=True, label=lambda: L(30597, 'Accent')),  # the selection (the tree, a focused check box)
    Token('color.accent.partial', 'mix({color.accent}, FF000000, 33%)'),  # a partial selection: the accent a third darker (opaque: read on a light card too)
    #: the selection in a focused row (a card): a checked box of a tree, a checked label, a raised mark
    Token('color.accent.row.focused', '{color.accent}', light='FFA0F0FF', focus_fill=True),
    #: a partial selection in a focused row (a card): its dash, its counter, its label
    Token('color.accent.partial.row.focused', '{color.accent.partial}', light='mix({color.accent.row.focused}, FFFFFFFF, 40%)', focus_fill=True),
    Token('color.warning', 'FFE0A84F', light='FF7A3000'),  # a warning: its text and its icon
    Token('color.error', 'FFFF6666', light='FF9C1A14'),  # an error, a not allowed value
    Token('color.modified', 'B3FFFF99', light='FF651893'),  # a changed value (the mark of a form field)
    #: the mark of a changed value in a focused field (on its focused fill)
    Token('color.modified.focused', '{color.modified}', light='FFE8C8FF', focus_fill=True),
    Token('color.badge', '{color.error}'),  # a badge with no colour of the rules
    # the icons, the boxes
    Token('color.icon', '{color.text}'),  # the icon of a tool / a row
    Token('color.icon.focused', '{color.text.focused}', light='{color.text.strong}'),  # a bright / focused icon
    #: the icon / mark of a focused row (a card): the expander and an unchecked box of a tree, ▾ of a combo box
    Token('color.icon.row.focused', '{color.icon}', light='{color.text.row.focused}', focus_fill=True),
    Token('color.icon.dim', '{color.text.dim}'),  # a dimmed icon
    Token('color.icon.disabled', '{color.text.disabled}'),  # an icon of no colour of its data: an absent / not allowed thing (a tag)
    Token('color.image', 'FFFFFFFF'),  # an image without its colour (no `colordiffuse`): no tint, as Kodi draws it
    Token('color.image.dim', 'alpha({color.image}, 99)'),  # a dimmed image (a grayed row): its transparency only, never a colour (a colour icon keeps its colours)
    Token('color.box', 'FFFFFFFF', light='FF3A4654'),  # a check box without the focus
    Token('color.box.focused', '{color.accent}'),  # a check box with the focus
    Token('color.box.disabled', '66999999', light='99808A96'),  # a disabled check box
    Token('color.slider.halo', 'alpha({color.box.focused}, 4D)'),  # the halo around the edited knob of a slider (its knob: `color.box.focused`)
    # a toggle switch (a check box of the look `toggle`): its track in the colour of its state, its knob and its mark (✓ / ✗) on it
    Token('color.state.yes', 'FF34A853'),  # checked: on, must (green)
    Token('color.state.no', 'FFD64045'),  # unchecked of a tristate box: must not (red)
    Token('color.state.off', 'FF4E5864'),  # unchecked of a two-state box (off is no "must not"), neither of a tristate one (gray)
    #: the gray of a switch in a focused row (light: lighter - seen on the accent of the row)
    Token('color.state.off.row.focused', '{color.state.off}', light='FF9AA5B1', focus_fill=True),
    Token('color.state.knob', 'FFF5F5F5'),  # the knob and the mark of the state on the track (white)
    # the backgrounds, the frames
    #: the dimming under a dialog, an overlay in a row
    Token('color.bg.overlay', '99000000', light='80E8ECF0', adjustable=True, label=lambda: L(30598, 'Dimming')),
    Token('color.bg.window', 'FF000000', light='FFE3E8ED'),  # the background of a full screen window
    Token('color.bg.art', '33FFFFFF'),  # a dimmed background art
    Token('color.bg.under', '{color.bg.dialog}'),  # the real colour of the surface of a dialog (the overlays and the contrasts); a dialog of a texture of its own colours (`color.bg.dialog` white) gives it here
    Token('color.bg.dialog', 'D9141519', light='F5F2F4F7', adjustable=True, label=lambda: L(30599, 'Window background')),  # the background of a dialog
    Token('color.bg.field', 'FF111418', light='FFFCFDFE'),  # the background of a field / a box without the focus
    Token('color.bg.field.focused', 'FF1A232A', light='{color.accent}', focus_fill=True),  # the background of a field with the focus
    Token('color.frame.dialog', 'D9202E39', light='CC8C9AA8'),  # the frame of a dialog
    Token('color.separator', '{color.frame.dialog}'),  # the separating lines, the background of a scroll bar
    Token('color.separator.group', 'alpha({color.text}, 4D)'),  # the separator of a group of rows (on a card: lighter than any level, the text translucent)
    Token('color.separator.row', 'alpha({color.text}, 99)'),  # the separator of the parts of a row (a source: solid; a mark on a card, 3:1)
    Token('color.frame.selected', '80FFFFFF', light='B3404C58'),  # the frame of the selected row (the focus elsewhere)
    Token('color.frame.focused', 'FFCCCCCC', light='FF2A3540'),  # the frame of a focused tile
    Token('color.scrollbar', 'FF555556', light='FF8A96A3'),  # the handle of a scroll bar
    Token('color.scrollbar.focused', '{color.focus}'),  # the handle with the focus (its highlight instead of the focus ring)
    Token('color.progress.track', '40407A96', light='alpha({color.accent}, 40)'),  # the track of a progress bar
    Token('color.progress.fill', 'FF407A96', light='{color.accent}'),  # the progress
    Token('color.progress.time', 'FFA30707'),  # the time left (a countdown)
    Token('color.progress.elapsed', 'FF402222', light='FFD9B8B8'),  # the elapsed time of a countdown (opaque: it covers the time left)
    # the surfaces of the levels (`SURFACES`; the dialog frame: `color.bg.dialog`, `color.frame.dialog`)
    Token('color.bg.panel', 'FF1A1B20', light='FFE2E7EC'),  # the background of a panel (a frame in a dialog)
    #: the tint of a row (`texture.row`: a filter field of a tree, the preview of a folder; FFFFFFFF: none, no colordiffuse)
    Token('color.bg.row', 'FFFFFFFF', light='FFD3DAE2'),
    #: the tint of a focused row (`texture.row.focused`: a focused filter field of a tree, its clear button)
    Token('color.bg.row.focused', 'FFFFFFFF', light='{color.accent}', focus_fill=True),
    #: the tint of the current row, the focus elsewhere (`texture.row.selected`: the current flat tab)
    Token('color.bg.row.selected', 'FFFFFFFF', light='FF5E7184'),
    Token('color.bg.card', '{color.bg.row}'),  # the background of a card (a frame in a panel, a row): the tint of its texture (a row's by default)
    Token('color.bg.card.focused', '{color.bg.row.focused}'),  # a focused card (a row)
    Token('color.bg.card.selected', '{color.bg.row.selected}'),  # the current card (a row), the focus elsewhere
    # a row of the sources window of the theme (no colour of its provider as its background, the setting "Item background" empty): the
    # tint of its texture; `.accent` - the colour mode accent (the colour of the provider a bar and its name)
    Token('color.bg.row.source', '{color.bg.row}'),
    Token('color.bg.row.source.accent', '{color.bg.row.source}'),
    Token('color.bg.button', 'FFFFFFFF', light='FFC9D2DC'),  # the tint of a button without the focus (`texture.button`; FFFFFFFF: none, no colordiffuse)
    #: the tint of a focused button (`texture.button.focused`: a row button, a flat tab)
    Token('color.bg.button.focused', 'FFFFFFFF', light='{color.accent}', focus_fill=True),
    #: the edge of a button (its outline under the focus ring: its boundary on a surface its fill blends with; transparent: none)
    Token('color.frame.button', 'FF6A6E76', light='FF707C89'),
    Token('color.frame.field', '{color.frame.button}'),  # the edge of a field (a text edit, a field button, a combo box, a spin box)
    Token('color.bg.tag', 'FF2A3346', light='FFB8C3CE'),  # the background of a tag (a small label on the edge of a card; dark: a navy grey)
    #: a tag of a focused card (its text `color.text.row.focused`)
    Token('color.bg.tag.focused', 'FF4B5263', light='darker({color.accent}, 10)', focus_fill=True),
    Token('color.frame.panel', '{color.frame.dialog}'),  # the edge of a panel (its box)
    Token('color.frame.card', '{color.frame.dialog}'),  # the edge of a card (its box)
    Token('color.frame.tag', '{color.frame.dialog}'),  # the edge of a tag (its box)
    # the tabs (a part of the edge of their panel)
    Token('color.bg.tab', 'alpha({color.bg.panel}, CC)'),  # a tab which is not the current one (behind its panel)
    Token('color.bg.tab.focused', 'FF333333', light='{color.accent}', focus_fill=True),  # the current tab with the focus
    Token('color.bg.tab.selected', 'lighter({color.bg.panel}, 6)'),  # the current tab, the focus elsewhere: joined to its panel, lighter (no focus colour)
    #: the current tab of a line (`tab.shape` line) with the focus: its fill in its outline (transparent: none)
    Token('color.bg.tab.line.focused', '00000000', light='{color.accent}', focus_fill=True),
    # a sunken / raised frame (`FRAME_SHAPES`): the halves of its edge over its fill
    Token('color.bevel.light', '40FFFFFF', light='B3FFFFFF'),  # the lit half: top-left of a raised frame, bottom-right of a sunken one
    Token('color.bevel.dark', '80000000', light='59303A44'),  # the dark half: bottom-right of a raised frame, top-left of a sunken one
    # the focus: a ring on the edge of the focused element (`texture.focus`), over its look in its focused state
    #: the focus ring (lighter than the accent, in the light variant darker: seen on the accent-tinted focused looks)
    Token('color.focus', 'lighter({color.accent}, 40%)', light='darker({color.accent}, 80%)'),
    Token('color.focus.editing', '{color.accent}'),  # the focus ring of an edited control (a slider, a spin box: OK started its editing)
    Token('color.bg.editing', 'alpha({color.accent}, 1A)'),  # the inside of the focus ring of an edited control: the accent barely tinting it
    # the menus, the colour picker (their own look)
    Token('color.bg.menu', 'FF1A2123', light='FFE6EBF0'),  # a menu item, the background of the colour picker
    Token('color.bg.menu.focused', 'FF0E597E', light='{color.accent}', focus_fill=True),  # the focused menu item, the title band of the colour picker
    Token('color.frame.cell', 'FF302F2F', light='FF9AA5B0'),  # the frame of the current cell of the colour picker
    Token('color.frame.sample', '{color.text.dim}'),  # the outline of a colour sample (seen whatever its colour: of the text of its field)
    # the spacing
    Token('space.xs', 6),  # the steps of the spacing (`space.density` multiplies them): the smallest
    Token('space.s', 10),  # also the text offset of a button
    Token('space.m', 14),  # a middle step
    Token('space.l', 20),  # also the text offset of a field, a tab
    Token('space.xl', 30),  # a large step (the padding of a dialog: `space.pad.dialog`)
    Token('space.xxl', 40),  # the largest step
    Token('space.density', 1.0, adjustable=True, kind='factor', label=lambda: L(30600, 'Density')),  # the factor of the spacing steps
    Token('space.indent', '{space.xxl}'),  # the indent of a level (the trees, the lists)
    # the automatic colours of the source providers (`oklch()`: one lightness and chroma, the hue of a provider): a bar and a name on a
    # row of the theme, the background of a row (its texture tints it, its text by its brightness) - a calmer one
    Token('palette.accent.lightness', .74, light=.52, kind='factor'),
    Token('palette.accent.chroma', .14, light=.15, kind='factor'),
    Token('palette.tint.lightness', .52, light=.84, kind='factor'),
    Token('palette.tint.chroma', .09, light=.07, kind='factor'),
    Token('space.pad.dialog', '{space.xl}'),  # the inner spacing of a dialog frame
    Token('space.pad.panel', '{space.l}'),  # the inner spacing of a panel
    Token('space.pad.card', '{space.m}'),  # the inner spacing of a card
    Token('space.pad.tag', 4),  # the inner spacing of a tag (its icons of 32 px in `metric.tag.height`)
    Token('space.gap.tag', '{space.xs}'),  # the gap between the tags of one place (along the edge), between a tag and the element over it
    Token('space.tag.corner', '{space.m}'),  # a tag in a corner (inside / up): from the corner along its edge, clear of the side of its host
    # the texts of the parts of a source row (the colour mode `.accent`: the bar of the provider, the separator of the parts): from its sides
    Token('space.pad.source.left.left', 6),  # the left part: from its left side
    Token('space.pad.source.left.right', 6),  # the left part: from its right side (the joint)
    Token('space.pad.source.right.left', 12),  # the right part: from its left side (the joint)
    Token('space.pad.source.right.right', 6),  # the right part: from its right side
    Token('space.pad.source.left.left.accent', '{space.pad.source.left.left}'),
    Token('space.pad.source.left.right.accent', '{space.pad.source.left.right}'),
    Token('space.pad.source.right.left.accent', '{space.pad.source.right.left}'),  # maybe 18?
    Token('space.pad.source.right.right.accent', '{space.pad.source.right.right}'),
    Token('factor.tag.out', .25),  # how far a tag sticks out of the edge of its card: a part of its size
    Token('factor.toggle.radius', .5),  # the corners of the track and the knob of a toggle switch: a part of their height (.5 a pill and a round knob)
    # the metrics
    Token('metric.row', 64),  # a row of one line: a tree, a check box, a page button, a tool
    Token('metric.row.details', 96),  # a row of two lines (and an icon)
    Token('metric.row.large', 120),  # a rich row: a source (badges), a service
    Token('metric.button.height', 70),  # a button of a dialog; the side of a square tool / symbol
    Token('metric.button.width', 250),  # a button in a row
    Token('metric.button.width.wide', 350),  # a button in a column of buttons
    Token('metric.field.height', 80),  # an edit field
    Token('metric.separator', 2),  # the width of a line
    Token('metric.separator.group', '{metric.separator}'),  # the width of the separator of a group of rows
    Token('metric.dialog.title', 80),  # the title band of a dialog: its title centred in it, the extras of its head under it
    Token('metric.button.border', 6, light=7),  # the nine-slice border of a button
    Token('metric.frame.box', '{metric.separator}'),  # the edge of a frame of the shape box, every level: a line around it (the bordersize of its fill)
    Token('metric.tag.height', 40),  # a tag
    Token('metric.tag.width', 160),  # a tag of a text of Python (its text unknown at the generation)
    Token('metric.mark.bar', 16),  # a bar along a side of its host (`edge_mark`): across it
    Token('metric.mark.line', 3),  # a line along a side of its host (`edge_mark`): its width
    Token('metric.mark.line.inset', '{space.gap.tag}'),  # a line along a side: its ends in from the ends of the side (a further slot: more)
    Token('metric.mark.split', 4),  # the joint of the parts of a source row (`split`): its width, of its vertical lines (the separator)
    Token('metric.mark.ribbon', 50),  # a ribbon in a corner of its host (`edge_mark`): its side
    Token('metric.mark.icon', 50),  # a sticker (a tag of no background, `tag` bg none): its height, the side of its icon
    Token('metric.tab.width', '{metric.button.width.wide}'),  # an elided tab (`text.elide` end): the most of its title, a longer one cut
    Token('metric.bevel', '{metric.separator}'),  # the width of the edge of a sunken / raised frame (its halves, `texture.bevel`)
    Token('metric.focus', 2),  # the width of the focus ring (`texture.focus`)
    Token('metric.slider.track', 6),  # the track of a slider across (`track_size` of a use)
    Token('metric.slider.knob', 24),  # the knob of a slider with the focus (without it: two thirds of it; edited: its halo twice the knob, in the band)
    Token('metric.toggle.height', 36),  # a toggle switch: its track (a line of text; the knob in it)
    Token('metric.toggle.width', 72),  # a two-state toggle switch: its track (the knob moves by the width less the height)
    Token('metric.toggle.width.tristate', 81),  # a tristate toggle switch: its track (the knob in three places)
    Token('metric.combo.height', 540),  # the most height of the drop-down list of a combo box (its rows: as many as fit)
    # the font roles
    Token('font.normal', 'font13', adjustable=True, label=lambda: L(30601, 'Text size')),  # the skin font of the normal role
    Token('font.small', (.85, False)),  # the size ratio to the normal font, bold
    Token('font.tiny', (.75, False)),  # the size ratio to the normal font, bold: the smallest text
    Token('font.heading', (1.33, True)),  # the size ratio to the normal font, bold: a title
    Token('font.group', '{font.tiny}'),  # the label of a group of rows over its separator (`row_separator`)
    # the textures (the media folder)
    # the decorations of the windows (a theme or the base theme, images of its media folder, of a variant its folder first): `<path>[@MM-DD..MM-DD]`, comma
    # separated, the days inclusive (a period: `gui.decor_images()`, a holiday); '' none; the template of a window says which it draws
    Token('decor.stamp', ''),  # a date stamp at the NE corner of every window, under its content
    Token('decor.corner', ''),  # at the NW corner of the sources, the configuration and the add-to windows
    Token('decor.band', ''),  # under the title of a dialog, its size fixed
    Token('metric.decor.stamp', 180),
    Token('metric.decor.corner', 150),
    Token('metric.decor.band.width', 400),
    Token('metric.decor.band.height', 18),
    Token('texture.dialog', 'dialogs/rounded.png', border='20'),  # the frame and the background of a dialog
    Token('texture.button', 'dialogs/button-nofocus.png', light='{texture.panel}', radius=12),  # a button without the focus
    Token('texture.button.focused', 'dialogs/button-focus.png', light='{texture.panel}', radius=12, focus_fill=True),  # a button / a tab with the focus
    Token('texture.row', 'dialogs/bg.r7.c222.oC.b7.png', light='{texture.panel}'),  # a row of a list (a card)
    Token('texture.row.focused', 'dialogs/bg.r7.c333.oF.b7.png', light='{texture.panel}', focus_fill=True),  # the focused row
    #: the selected row, the focus elsewhere (dark: the fill of the focused one - lighter than a row; its frame instead of the focus ring)
    Token('texture.row.selected', 'dialogs/bg.r7.c333.oF.b7.png', light='{texture.panel}'),
    Token('texture.row.tint', 'dialogs/bg.r7.cCCC.oC.b7.png'),  # a row tinted by the colour of the rules
    Token('texture.row.tint.focused', 'dialogs/bg.r7.cCCC.oF.b7.png'),  # a tinted row with the focus
    Token('texture.row.tint.secondary', 'dialogs/bg.r7.c666.oC.b7.png'),  # the second part of a tinted row
    Token('texture.row.tint.secondary.focused', 'dialogs/bg.r7.c999.oF.b7.png'),  # the second part of a tinted row with the focus
    # the backgrounds of the parts of a source row of a colour of its own (`item.background`: the colour of its provider, the setting
    # "Item background"): `.focused` - with the focus, `.accent` - the colour mode accent (by default the left one as the right one)
    Token('texture.row.source.left', '{texture.row.tint}'),
    Token('texture.row.source.left.focused', '{texture.row.tint.focused}'),
    Token('texture.row.source.right', '{texture.row.tint.secondary}'),
    Token('texture.row.source.right.focused', '{texture.row.tint.secondary.focused}'),
    Token('texture.row.source.left.accent', '{texture.row.source.right.accent}'),
    Token('texture.row.source.left.focused.accent', '{texture.row.source.right.focused.accent}'),
    Token('texture.row.source.right.accent', '{texture.row.source.right}'),
    Token('texture.row.source.right.focused.accent', '{texture.row.source.right.focused}'),
    Token('texture.frame.selected', 'dialogs/frame.r7.w1.o0.b7.png'),  # the frame of the selected row
    Token('texture.frame.focused', 'dialogs/frame.r7.w1.t3.png', border='7'),  # the frame of a focused tile
    Token('texture.progress', 'dialogs/list-overlay_rounded.b7.png'),  # the track and the fill of a progress bar
    Token('texture.progress.frame', 'dialogs/list-frame.png', border='8'),  # the frame of a progress bar
    Token('texture.knob', 'dialogs/knob.r32.oF.png'),  # the knob of a slider: a white disc (`color.box*`), scaled whole (no border)
    Token('texture.slider.track', 'dialogs/track.r3.oF.b3.png'),  # the track and the fill of a slider: a white bar of round ends (its border: a thin one)
    Token('texture.poster', 'diffuse/poster.png', border='6'),  # the mask of a poster
    Token('texture.poster.frame', 'diffuse/poster-border.png', border='6', inset=31),  # the frame of a poster
    Token('texture.box.check', 'dialogs/checkbox', radius=7),  # the look of a check box (`box_texture()`)
    Token('texture.box.radio', 'dialogs/radio', radius=7),  # the look of a radio button
    Token('texture.panel', 'dialogs/bg.r7.oF.b7.png'),  # a panel (white: the colour of its level)
    Token('texture.card', '{texture.row}'),  # a card (a row)
    Token('texture.card.focused', '{texture.row.focused}'),  # a focused card
    Token('texture.card.selected', '{texture.row.selected}'),  # the current card, the focus elsewhere (`texture.frame.selected` over it)
    Token('texture.tag', '{texture.panel}'),  # a tag (`gui.size_texture()`: the file of its family for its size)
    Token('texture.ribbon', 'badges/ribbon.ne.png'),  # a ribbon in a corner (`edge_mark`): the one of the corner NE, mirrored for the others
    Token('texture.tab', 'dialogs/tab'),  # the family of the tabs (`gui.tab_texture()`: the shape, the side, current or not, the size)
    Token('texture.bevel', 'dialogs/frame'),  # the family of the edges of a frame by its corners: a box (`gui.box_edge()`), the halves of a sunken / raised one
    Token('texture.focus', 'dialogs/focus'),  # the family of the focus rings (`gui.focus_texture()`: the radius of the element, `metric.focus`)
    Token('texture.fill', 'dialogs/fill'),  # the family of the white fills of a shape (`gui.shape_fill()`: the radius of the element), e.g. a tint over it
    Token('texture.popup', 'dialogs/popup'),  # the family of the outlines open on one side (`gui.popup_texture()`): a drop-down list, a tab of a line
    Token('texture.more', 'dialogs/more'),  # the family of the marks of more rows (`gui.more_texture()`: a triangle pointing E or S, mirrored W / N)
    # the named choices
    Token('tab.shape', 'arc', choices=tuple(TAB_SHAPES)),  # the shape of a tab, its joint with its panel (`TAB_SHAPES`)
    Token('tab.align', 'center', choices=GROUP_ALIGNS),  # the title in its tab: at the start, in the middle, at the end
    Token('tab.scroll', 'edge', choices=('edge', 'start')),  # a scrolled tab bar: the current tab at the edge of the view (edge) or at its start
    Token('frame.shape.dialog', 'box', choices=SURFACE_SHAPES),  # the shape of a frame of a level (`FRAME_SHAPES`): a dialog - its edge
    Token('frame.shape.panel', 'box', choices=SURFACE_SHAPES),  # a panel: its edge
    Token('frame.shape.card', 'none', choices=SURFACE_SHAPES),  # a card: its fill alone
    Token('frame.shape.tag', 'none', choices=SURFACE_SHAPES),  # a tag: its fill alone
    Token('text.elide', 'none', choices=('none', 'end')),  # a text too long (a tab): none - the full text, end - cut with an ellipsis
    Token('group.names', 'hidden', choices=('hidden', 'shown')),  # the names of the groups of rows: shown - a section (its label over its separator)
    Token('tag.out', 'up', choices=TAG_OUTS),  # how far a tag sticks out of its host (`TAG_OUTS`): out across its edge
    Token('tag.edge', 'horizontal', choices=TAG_EDGES),  # the edge of a tag in a corner (`TAG_EDGES`): its slots along it
    Token('group.align', 'left', choices=GROUP_ALIGNS),  # the name of a group in the line of its separator: at the start, in the middle, at the end
    Token('popup.shape', 'closed', choices=POPUP_SHAPES),  # the outline of an open popup card (a drop-down list): closed, joined to its field
    # the outline of the layout (a developer view, `const.dev.outline`, `outline.py`): its own colours, seen over any look (no theme changes them)
    Token('dev.outline.widget', 'FFFFD600', kind='color'),  # the frame of a widget (its outermost control), its path (`const.dev.outline.labels`)
    Token('dev.outline.control', 'B300E5FF', kind='color'),  # the frame of a control
    Token('dev.outline.margin', 'FFFF4081', kind='color'),  # the inner frame of a laid out container: its margins (`ff:margins`) outside it
    Token('dev.outline.spacing', '6600E676', kind='color'),  # the fill of the spacing between the children of a row / column (`ff:spacing`)
    Token('dev.outline.stretch', '66FF9100', kind='color'),  # the fill of the free space of a row / column (`<ff:stretch/>`), a stretched child
    Token('dev.outline.grouplist', 'FFE040FB', kind='color'),  # the frame of a grouplist and the mark of its direction at its end
    Token('dev.outline.cell', 'FF2979FF', kind='color'),  # the frame of a cell of a grid (its area, a hole too)
    Token('dev.outline.selected', 'FFFFFFFF', kind='color'),  # the frame of the widget selected in the inspector (a double pen) and its path
    Token('dev.outline.label', 'B3000000', kind='color'),  # the background of the path of the selected widget (as wide as its text, over the window)
)

#: The surfaces by their levels (the nesting of the frames): the dialog frame, a panel, a card (a row), a tag; the name of a level
#: in its tokens (`color.bg.<level>` ...).
SURFACES: tuple[str, ...] = ('dialog', 'panel', 'card', 'tag')

class _Str(str):
    """A str token value, the parent of the longer names (their attributes); pickled as a plain str."""

    def __reduce__(self) -> tuple[Any, ...]:
        """Pickle (copy) the plain value."""
        return str, (str(self),)


class _Int(int):
    """An int token value (see `_Str`)."""

    def __reduce__(self) -> tuple[Any, ...]:
        """Pickle (copy) the plain value."""
        return int, (int(self),)


class _Float(float):
    """A float token value (see `_Str`)."""

    def __reduce__(self) -> tuple[Any, ...]:
        """Pickle (copy) the plain value."""
        return float, (float(self),)


class _Tuple(tuple):
    """A tuple token value (see `_Str`)."""

    def __reduce__(self) -> tuple[Any, ...]:
        """Pickle (copy) the plain value."""
        return tuple, (tuple(self),)


#: The node of a token value by the type of the value.
_NODES: dict[type, type] = {str: _Str, int: _Int, float: _Float, tuple: _Tuple}


class Style:
    """
    The resolved style: the tokens by the parts of their names (`style.color.text.focused`), `values` by their names, `origins`
    (the layer of each value) by their names, the variant of the themes of its defaults.
    """

    def __init__(self, values: Mapping[str, TokenValue], origins: Mapping[str, Origin], variant: str = '') -> None:
        #: The token values by their names.
        self.values: dict[str, TokenValue] = dict(values)
        #: The origins of the values by the token names: the layer which gave the value (`Origin`).
        self.origins: dict[str, Origin] = dict(origins)
        #: The variant of the themes of the declared defaults (`Token.default_of()`).
        self.variant: str = variant
        #: The stamp of the values (the cache of the generated windows).
        self.stamp: str = hashlib.sha1(repr(sorted(self.values.items())).encode('utf-8')).hexdigest()[:12]
        for name in sorted(self.values, key=lambda name: name.count('.')):  # a parent before its children
            *path, last = name.split('.')
            parent: Any = self
            for part in path:
                if not hasattr(parent, part):
                    setattr(parent, part, SimpleNamespace())
                parent = getattr(parent, part)
            value = self.values[name]
            setattr(parent, last, _NODES[type(value)](value))

    if TYPE_CHECKING:
        def __getattr__(self, name: str) -> Any:
            """Return a token or a group of them (the kinds: `color`, `space` ...)."""


class StyleError(ValueError):
    """A wrong expression of a token value (logged, the declared default of the token used)."""


def _color(value: TokenValue) -> tuple[int, int, int, int]:
    """Return the channels (alpha, red, green, blue) of a colour argument."""
    if not isinstance(value, str) or not RX_COLOR.fullmatch(value):
        raise StyleError(f'not a colour: {value!r}')
    return tuple(int(value[i:i + 2], 16) for i in range(0, 8, 2))  # type: ignore[return-value]  # four channels


def _hex(opacity: float, red: float, green: float, blue: float) -> str:
    """Return the colour of the channels (`AARRGGBB`)."""
    return ''.join(f'{min(max(round(channel), 0), 255):02X}' for channel in (opacity, red, green, blue))


def _number(value: TokenValue, *, percent: bool | None = None) -> tuple[float, bool]:
    """Return a number argument and whether it is a percent (`percent`: required True / False, None: any)."""
    if not isinstance(value, str) or not (mch := RX_NUMBER.fullmatch(value)) or percent not in (None, bool(mch[2])):
        raise StyleError(f'not a {"percent" if percent else "number"}: {value!r}')
    return float(mch[1]), bool(mch[2])


def _lightness(color: TokenValue, amount: TokenValue, sign: int) -> str:
    """Return the colour with its HSL lightness moved (`sign` 1: lighter, -1: darker) by the points or the percent (relative)."""
    opacity, *rgb = _color(color)
    hue, light, saturation = colorsys.rgb_to_hls(*(channel / 255 for channel in rgb))
    number, percent = _number(amount)
    if not percent:
        light += sign * number / 100
    elif sign > 0:
        light += (1 - light) * number / 100  # a part of the way to white
    else:
        light *= 1 - number / 100  # a part of the way to black
    red, green, blue = colorsys.hls_to_rgb(hue, min(max(light, 0), 1), saturation)
    return _hex(opacity, red * 255, green * 255, blue * 255)


def lighter(color: TokenValue, amount: TokenValue) -> str:
    """Return the colour lighter: its HSL lightness + N points (`N`), or a part of the way to white (`N%`); 0–100."""
    return _lightness(color, amount, 1)


def darker(color: TokenValue, amount: TokenValue) -> str:
    """Return the colour darker: its HSL lightness - N points (`N`), or a part of the way to black (`N%`); 0–100."""
    return _lightness(color, amount, -1)


def alpha(color: TokenValue, value: TokenValue) -> str:
    """Return the colour with another alpha: hex (`AA`) or a percent of opaque (`N%`)."""
    _, *rgb = _color(color)
    if isinstance(value, str) and re.fullmatch('[0-9A-Fa-f]{2}', value):
        return _hex(int(value, 16), *rgb)
    return _hex(255 * min(_number(value, percent=True)[0], 100) / 100, *rgb)


def oklch(lightness: float, chroma: float, hue: float) -> str:
    """
    Return the opaque colour (`FFRRGGBB`) of OKLCH (Björn Ottosson's OKLab: the same lightness looks equally light in every hue; `hue` in
    degrees): its chroma lowered until sRGB holds it (a hue of less reach at that lightness: a bit greyer, never another hue).
    """
    from math import cos, radians, sin

    def rgb(chroma: float) -> tuple[float, float, float] | None:
        """Return the sRGB channels (0-1) of the chroma, None out of sRGB."""
        a, b = chroma * cos(radians(hue)), chroma * sin(radians(hue))
        l_, m_, s_ = (lightness + 0.3963377774 * a + 0.2158037573 * b) ** 3, (lightness - 0.1055613458 * a - 0.0638541728 * b) ** 3, \
            (lightness - 0.0894841775 * a - 1.2914855480 * b) ** 3
        linear = (4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_, -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_,
                  -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_)
        if not all(-1e-6 <= channel <= 1 + 1e-6 for channel in linear):
            return None
        return tuple(12.92 * c if c <= 0.0031308 else 1.055 * max(c, 0) ** (1 / 2.4) - 0.055 for c in linear)  # type: ignore[return-value]

    low, high = 0.0, chroma
    channels = rgb(high)
    if channels is None:  # the most chroma sRGB holds at that lightness and hue (a bisection)
        for _ in range(20):
            if rgb(middle := (low + high) / 2) is None:
                high = middle
            else:
                low = middle
        channels = rgb(low) or (lightness, lightness, lightness)
    return _hex(255, *(255 * channel for channel in channels))


def mix(first: TokenValue, second: TokenValue, part: TokenValue) -> str:
    """Return the first colour with the percent of the second one (every channel, the alpha too)."""
    weight = min(_number(part, percent=True)[0], 100) / 100
    return _hex(*(one + (other - one) * weight for one, other in zip(_color(first), _color(second))))


#: The colour functions of the expressions (`evaluate()`) by their names.
COLOR_FUNCTIONS: dict[str, Callable[..., str]] = {'lighter': lighter, 'darker': darker, 'alpha': alpha, 'mix': mix}


def _is_number(value: Any) -> bool:
    """Return True for an int or a float (not a bool)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _media_texture(name: str) -> bool:
    """
    Return True if the texture is a file of the FF media folder or the base of its files (`dialogs/checkbox`), else of the textures of
    the active themes (`theme.skin_textures()`, any variant: a theme may name its own file).
    """
    from .gui import MEDIA
    from ..ff.theme import skin_textures
    if not name or Path(name).is_absolute() or '..' in Path(name).parts:
        return False
    path = MEDIA / name
    if path.is_file() or any(path.parent.glob(f'{glob.escape(path.name)}.*')):
        return True
    names = skin_textures(None)
    return name in names or any(rel.startswith(f'{name}.') and '/' not in rel[len(name):] for rel in names)


def wrong_value(token: Token, value: TokenValue) -> str:
    """Return what the kind of the token wants if the (evaluated) value is not of it, '' if it is."""
    if token.kind == 'color':
        return '' if isinstance(value, str) and RX_COLOR.fullmatch(value) else 'a colour AARRGGBB'
    if token.kind in ('space', 'metric'):
        return '' if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else 'a whole number >= 0'
    if token.kind == 'factor':
        return '' if _is_number(value) else 'a number'
    if token.kind == 'font':
        role = isinstance(value, tuple) and len(value) == 2 and _is_number(value[0]) and isinstance(value[1], bool)
        return '' if role or (isinstance(value, str) and value) else 'a skin font name or [size ratio, bold]'
    if token.kind == 'texture':
        return '' if isinstance(value, str) and _media_texture(value) else 'a texture of the FF media folder or of an active theme'
    if token.kind == 'decor':
        return '' if isinstance(value, str) and all(RX_DECOR.fullmatch(part.strip()) for part in value.split(',') if part.strip()) else 'images <path>[@MM-DD..MM-DD], comma separated'
    return '' if value in token.choices else f'one of {", ".join(token.choices)}'


def evaluate(value: TokenValue, lookup: Callable[[str], TokenValue]) -> TokenValue:
    """
    Return the value of an expression: a reference `{name}` (`lookup(name)`), a colour function (`COLOR_FUNCTIONS`) of
    expressions and plain arguments (`lighter({color.accent}, 20%)`, nested: `alpha(lighter({color.accent}, 20), 50%)`); any
    other value is a literal (itself). A wrong expression raises `StyleError`.
    """
    if not isinstance(value, str) or not RX_EXPRESSION.match(value):
        return value
    parts = RX_PART.findall(value)

    def expression() -> TokenValue:
        """Return the value of the expression of the next parts."""
        part = parts.pop(0) if parts else ''
        if len(part) > 1 and part[0] == '{':  # a reference (a single character: a syntax error)
            return lookup(part[1:-1])
        if part.endswith('('):
            if (function := COLOR_FUNCTIONS.get(part[:-1])) is None:
                raise StyleError(f'unknown function {part[:-1]!r} (not one of {", ".join(COLOR_FUNCTIONS)})')
            args = [expression()]
            while (part := parts.pop(0) if parts else '') == ',':
                args.append(expression())
            if part != ')':
                raise StyleError(f'{part or "the end"!r} instead of ")"')
            try:
                return function(*args)
            except TypeError:
                raise StyleError(f'{len(args)} arguments of {function.__name__}()') from None
        if RX_ARG.fullmatch(part):
            return part
        raise StyleError(f'{part or "the end"!r} instead of a value')

    result = expression()
    if parts:
        raise StyleError(f'{parts[0]!r} after the end')
    return result


@frozen
class Layer:
    """A layer of the style with its origin (`resolve()`: the origins of the values)."""

    #: The origin of its values (a style file, `PREVIEW`).
    origin: Origin
    #: The token values by their names.
    values: Mapping[str, TokenValue]


def resolve(layers: Iterable[Mapping[str, TokenValue] | Layer] = (), variant: str = '') -> Style:
    """
    Return the style of the declared tokens (`TOKENS`, their defaults of the variant of the themes: `Token.default_of()`) overridden
    by the layers (each one by the next ones; an undeclared name logged and ignored; a `Layer` gives the origin of its values, a plain
    mapping `LAYER`): the expressions evaluated, a value not of the kind of its token (`wrong_value()`) or a wrong expression logged
    and the declared default of the variant used, the spacing steps multiplied by `space.density`.
    """
    declared: dict[str, Token] = {token.name: token for token in TOKENS}
    defaults: dict[str, TokenValue] = {token.name: token.default_of(variant) for token in TOKENS}
    values = dict(defaults)
    origins: dict[str, Origin] = dict.fromkeys(values, DECLARATION)
    for layer in layers:
        origin, layer_values = (layer.origin, layer.values) if isinstance(layer, Layer) else (LAYER, layer)
        for name, value in layer_values.items():
            if name in values:
                values[name], origins[name] = value, origin
            else:
                fflog(f'[STYLE] unknown token {name!r} = {value!r} in a layer, ignored')
    density = values['space.density']
    if not _is_number(density):  # it scales the literals before any evaluation
        fflog(f'[STYLE] space.density = {density!r}: not a number, {defaults["space.density"]!r} used')
        density = values['space.density'] = defaults['space.density']
        origins['space.density'] = DECLARATION
    for name in values:  # the literals: the references read them scaled
        if declared[name].kind == 'space':
            for scaled in (values, defaults):
                if isinstance(value := scaled[name], int) and not isinstance(value, bool):
                    scaled[name] = round(value * density)  # type: ignore[operator]  # a factor
    resolved: dict[str, TokenValue] = {}

    def value_of(name: str, chain: tuple[str, ...] = ()) -> TokenValue:
        """Return the value of a token, its expression evaluated (`chain`: the tokens evaluating it, a cycle)."""
        if name in resolved:
            return resolved[name]
        if name not in values:
            raise StyleError(f'unknown token {name!r}')
        if name in chain:
            raise StyleError(f'a cycle {" -> ".join((*chain, name))}')
        lookup = partial(value_of, chain=(*chain, name))
        try:
            result = evaluate(values[name], lookup)
            if values[name] != defaults[name] and (wanted := wrong_value(declared[name], result)):
                raise StyleError(f'{result!r} is not {wanted}')
        except StyleError as exc:
            if values[name] == defaults[name]:
                raise
            fflog(f'[STYLE] {name} = {values[name]!r}: {exc}, {defaults[name]!r} used')
            result = evaluate(defaults[name], lookup)
            origins[name] = DECLARATION
        resolved[name] = result
        return result

    for name in values:
        try:
            value_of(name)
        except StyleError as exc:  # a wrong declaration (`test_style`): the style never stops a window
            fflog(f'[STYLE] {name} = {values[name]!r}: {exc}')
            resolved[name] = values[name]
    return Style(resolved, origins, variant)


def style_files(chosen: str | None = None) -> tuple[Path, ...]:
    """
    Return the style files of the layers (existing or not): of every active theme from the least important one (the base theme)
    its style and the one of its variant (`ThemeFiles.own_variant()`), the local style and the one of the chosen variant (None: the
    chosen one now).
    """
    from ..ff.theme import STYLE_FILE, chosen_variant, theme_files, theme_folders, variant_file
    if chosen is None:
        chosen = chosen_variant()
    files: list[Path] = []
    for folder in reversed(theme_folders()):
        files.append(folder / STYLE_FILE)
        if variant := theme_files(folder).own_variant(chosen):
            files.append(variant_file(folder / STYLE_FILE, variant))
    return (*files, *local_style_files(chosen))


def local_style_files(variant: str | None = None) -> tuple[Path, ...]:
    """Return the local style files in effect: the common one and the one of the variant (None: the chosen one; '' none)."""
    if variant is None:
        from ..ff.theme import chosen_variant
        variant = chosen_variant()
    return (local_style_file(), *((local_style_file(variant),) if variant else ()))


def local_style_file(variant: str = '') -> Path:
    """Return the local style file (in the add-on profile): of the variant, '' the common one (`LOCAL_STYLE`)."""
    from ..ff.control import dataPath
    from ..ff.theme import variant_file
    local = Path(dataPath) / LOCAL_STYLE
    return variant_file(local, variant) if variant else local


@frozen
class StyleKey:
    """What the style of the windows changes with (`style_key()`, compared by `check_style()`)."""

    #: The chosen variant of the themes (the defaults of the tokens, `Token.default_of()`; its style files).
    variant: str
    #: The style files of the layers in their order with their stats.
    files: tuple[tuple[Path, FileStat], ...]
    #: The changes of the preview layer (`set_preview_token()`).
    preview: int
    #: The accent of the skin of its layer (`skin_accent()`, Kodi evaluates a skin setting in it), '' none.
    skin: str = ''


def style_key() -> StyleKey:
    """
    Return the chosen variant, the style files of the layers with their stats, the changes of the preview and the accent of the skin (the
    style changes with them).
    """
    from ..ff.theme import chosen_variant
    variant = chosen_variant()
    return StyleKey(variant=variant, files=tuple((path, file_stat(path)) for path in style_files(variant)), preview=_preview_changes,
                    skin=skin_accent())


def skin_accent() -> str:
    """Return the accent of the active skin (`skinfonts.active_skin_accent()`) if the user chose the colours of the skin, else ''."""
    from ..ff.theme import skin_colors_chosen
    if not skin_colors_chosen():
        return ''
    from .skinfonts import active_skin_accent
    return accent.value if (accent := active_skin_accent()) is not None else ''


def skin_layer(accent: str, variant: str) -> dict[str, TokenValue]:
    """
    Return the token values of the layer of the colours of the skin (`SKIN`): its accent; a variant other than the light one, the focus
    filled by the accent as the light one fills it (`Token.focus_fill`).
    """
    fills = {token.name: token.light for token in TOKENS if token.focus_fill and token.light is not None} if variant != LIGHT_VARIANT else {}
    return {**fills, 'color.accent': accent}


def layered_style(layers: Iterable[Layer], variant: str, skin: str = '') -> Style:
    """
    Return the style of the layers (`resolve()`) over the layer of the colours of the skin of its accent (`skin_layer()`, '' none): the
    accent as it is or made lighter / darker (`SKIN_STEPS`, the least change first) - the first one with no contrast problem the style
    has not without it (`render.contrast_problems()`: a problem of a theme is not of the skin); none such - the style without it (logged).
    """
    layers = tuple(layers)
    plain = resolve(layers, variant)
    if not skin:
        return plain
    from .render import contrast_problems

    def problems(style: Style) -> set[str]:
        """Return the pairs of too little contrast of the style (its ratios skipped)."""
        return {problem.partition(':')[0] for problem in contrast_problems(style)}

    known = problems(plain)
    for amount in SKIN_STEPS:
        for color in dict.fromkeys((lighter(skin, amount), darker(skin, amount)) if amount != SKIN_STEPS[0] else (skin,)):
            style = resolve((Layer(SKIN, skin_layer(color, variant)), *layers), variant)
            if problems(style) <= known:
                return style
    fflog(f'[STYLE] the accent of the skin {skin} not readable ({", ".join(sorted(problems(style) - known))}), not used')
    return plain


def read_layer(path: Path) -> dict[str, TokenValue]:
    """Return the tokens of a style file (the comments `//…` skipped, a list a tuple), none if it is broken (logged, told once in a Kodi session)."""
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('not an object')
    except FileNotFoundError:  # removed after its stat
        return {}
    except (OSError, ValueError) as exc:
        fflog.warning(f'[STYLE] broken {path} ({exc}), not used')
        from ..ff.control import show_style_error
        show_style_error(path, str(exc))
        return {}
    return {name: tuple(value) if isinstance(value, list) else value for name, value in data.items() if not name.startswith('//')}


#: The style files of the last `check_style()` and their style, None before the first one.
_checked: tuple[StyleKey, Style] | None = None
#: The preview layer (`set_preview_token()`): token values over the local style, in the memory of the interpreter.
_preview: dict[str, TokenValue] = {}
#: The changes of the preview layer (a part of `StyleKey`).
_preview_changes: int = 0
#: The style files are checked again at the next use of the style (`recheck_style()`: the start of a call).
_recheck: bool = False


def recheck_style() -> None:
    """
    Check the style files again at the next use of the style (`tokens()`): the start of a call - the data of a window (e.g. the colours
    of the sources) is made before the window checks them, a reused interpreter keeps the style of an earlier call (another variant).
    """
    global _recheck
    _recheck = True


def check_style() -> Style:
    """Return the style of the windows of the style files now (read again if they changed): the open of a window, the key of its cache."""
    global _checked, _recheck
    _recheck = False
    key = style_key()
    if _checked is not None:
        checked_key, style = _checked
        if checked_key == key:
            return style
    style = layered_style((*(Layer(path, read_layer(path)) for path, stat in key.files if stat is not None), Layer(PREVIEW, dict(_preview))), key.variant,
                          key.skin)
    _checked = key, style
    return style


def tokens() -> Style:
    """Return the style of the FF windows of the style files of the last `check_style()` (the first use of a call checks them: `recheck_style()`)."""
    if _checked is None or _recheck:
        return check_style()
    _, style = _checked
    return style


def checked_value(name: str, value: TokenValue | None) -> Token:
    """
    Return the declared token of the name if the value fits it (None: any): evaluated on the style of the windows now
    (`check_style()`), of the kind of the token (`wrong_value()`); else raise `StyleError` with the reason.
    """
    if (token := {token.name: token for token in TOKENS}.get(name)) is None:
        raise StyleError(f'unknown token {name!r}')
    if value is None:
        return token
    values = check_style().values

    def lookup(ref: str) -> TokenValue:
        """Return the value of a referenced token now."""
        if ref not in values:
            raise StyleError(f'unknown token {ref!r}')
        return values[ref]

    if wanted := wrong_value(token, evaluate(value, lookup)):
        raise StyleError(f'{name} = {value!r} is not {wanted}')
    return token


def set_local_token(name: str, value: TokenValue | None) -> Path:
    """
    Write the value of the token into the local style (None: remove it), the rest of the file kept (the other tokens, the comments,
    the order). The file by the kind of the token: a colour into the file of the chosen variant (a colour for a dark skin does not
    spoil a light one), the common file without a variant and for the other kinds. Return the file. A wrong token or value
    (`checked_value()`) or a broken file raise `StyleError` (the file untouched). The next `check_style()` reads it (its stat).
    """
    from ..ff.theme import chosen_variant
    token = checked_value(name, value)
    path = local_style_file(chosen_variant() if token.kind == 'color' else '')
    data = _read_local(path)
    if value is None:
        data.pop(name, None)
    else:
        data[name] = list(value) if isinstance(value, tuple) else value
    _write_local(path, data)
    return path


def remove_local_tokens(names: Iterable[str]) -> None:
    """
    Remove the tokens from every local style file in effect (`local_style_files()`: also a token written by hand into the file of
    another kind), the rest of a file kept; a file without them is not written. A broken file raises `StyleError` (untouched), the
    files before it are written already.
    """
    names = set(names)
    for path in local_style_files():
        if (data := _read_local(path)).keys() & names:
            _write_local(path, {name: value for name, value in data.items() if name not in names})


def _read_local(path: Path) -> dict[str, Any]:
    """Return the data of a local style file to change ({} none); a broken file raises `StyleError`."""
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        raise StyleError(f'broken {path} ({exc}), not written') from None
    if not isinstance(data, dict):
        raise StyleError(f'broken {path} (not an object), not written')
    return data


def _write_local(path: Path, data: dict[str, Any]) -> None:
    """Write the data of a local style file (atomic); a failure raises `StyleError`."""
    from ..ff.filecache import write_atomic
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        write_atomic(path, f'{json.dumps(data, indent=4, ensure_ascii=False)}\n'.encode('utf-8'))
    except OSError as exc:
        raise StyleError(f'{path} not written ({exc})') from None


def set_preview_token(name: str, value: TokenValue | None) -> None:
    """
    Set the value of the token in the preview layer (None: remove it), over the local style until `clear_preview()`; the next
    `check_style()` (the open of a window) resolves the style again. A wrong token or value raise `StyleError` (`checked_value()`).
    """
    global _preview_changes
    checked_value(name, value)
    if value is None:
        _preview.pop(name, None)
    else:
        _preview[name] = value
    _preview_changes += 1


def preview_tokens() -> dict[str, TokenValue]:
    """Return the token values of the preview layer (a copy)."""
    return dict(_preview)


def clear_preview() -> None:
    """Remove every value of the preview layer."""
    global _preview_changes
    _preview.clear()
    _preview_changes += 1


@frozen(kw_only=True)
class Surface:
    """The look of a level of the frames (`SURFACES`): the resolved values of its tokens."""

    #: The level (0: the dialog frame).
    level: int
    #: The name of the level (`SURFACES`), the part of its token names.
    name: str
    #: The background colour (`color.bg.<level>`).
    bg: str
    #: The edge colour (`color.frame.<level>`).
    edge: str
    #: The width of the edge (`metric.frame.box`: every level), drawn by a box (`edge_width`).
    inset: int
    #: The inner spacing (`space.pad.<level>`).
    pad: int
    #: The texture of the background and of the edge (`texture.<level>`).
    texture: str
    #: The shape (`frame.shape.<level>`, `FRAME_SHAPES`): its outline.
    shape: str

    @property
    def edge_width(self) -> int:
        """Return the width of the edge of a box (under the background: its bordersize; an outline over a translucent one), else 0."""
        return self.inset if FRAME_SHAPES[self.shape].box else 0

    def forced(self, **values: str | int) -> Surface:
        """Return the look with the values a use of a frame forces (its parameters of the same names: `bg`, `edge`, `pad`, `shape`), '' derived."""
        return evolve(self, **{name: type(getattr(self, name))(value) for name, value in values.items() if value != ''})


#: The art of the list item of a row for a focused row of another brightness than the other rows (`surface_art()`), none: its icon.
FOCUSED_ICON: str = 'icon.focused'


def image_variant(focused: bool = False) -> str:
    """
    Return the variant of the images of the FF windows (`theme.art(variant=…)`) on their surfaces (a dialog, a panel, a card; `focused`:
    a focused card - a row) by the brightness of the stressed text there (`color.text.strong`, `color.text.strong.focused`;
    `theme.text_variant()`): a text is in contrast with its surface (a card is a texture of its own colour in a tint, its colour is
    not known).
    """
    from ..ff.theme import text_variant
    style = tokens()
    return text_variant(str(style.color.text.strong.focused if focused else style.color.text.strong))


def other_variant_style() -> Style:
    """
    Return the style of the FF declaration of the other variant than the one of the surfaces of the windows (`image_variant()`: light
    <-> dark): the texts on a surface of the other brightness (a row in a colour of the user).
    """
    from ..ff.theme import DARK_VARIANT, LIGHT_VARIANT
    return resolve((), LIGHT_VARIANT if image_variant() == DARK_VARIANT else DARK_VARIANT)


def focused_image_variant() -> str:
    """Return the variant of the images on a focused card while it is another one than of the other surfaces (`image_variant()`), else ''."""
    return focused if (focused := image_variant(True)) != image_variant() else ''


def surface_art(image: str) -> dict[str, str]:
    """
    Return the art of the list item of a row of an FF window showing the image (its icon): an image of a theme (`theme.media_rel()`:
    also given in another variant) in the variant of the surface of the row (`image_variant()`) - `icon`, of a focused row of another
    brightness (`focused_image_variant()`) - `FOCUSED_ICON`, else ''; another image (a poster, a URL) as it is in both.
    """
    from ..ff.theme import art, media_rel
    focused = focused_image_variant()
    if not (rel := media_rel(image)):
        return {'icon': image, FOCUSED_ICON: image if focused else ''}
    return {'icon': art(rel, variant=image_variant()), FOCUSED_ICON: art(rel, variant=focused) if focused else ''}


def surface(level: int) -> Surface:
    """Return the look of the level of the frames (`SURFACES`) in the style of the windows (`tokens()`)."""
    name = SURFACES[level]
    values = tokens().values
    return Surface(level=level, name=name, bg=str(values[f'color.bg.{name}']), edge=str(values[f'color.frame.{name}']),
                   inset=int(values['metric.frame.box']), pad=int(values[f'space.pad.{name}']), texture=str(values[f'texture.{name}']),
                   shape=str(values[f'frame.shape.{name}']))
