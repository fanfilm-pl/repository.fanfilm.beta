"""
The folders of the configuration window (its page: `lib.windows.widgets.folders`): when a level of a menu of lists is a folder
(`When`: never, if many, always - one of them in a row; `lib.ff.lists_config.FOLDER_POINTS`), with a preview of the lists in
the main menu built by the menu builder itself (no network: the user lists of an account are a placeholder).
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from cdefs import When
from ..ff import lists_config as lc
from ..kolang import L
from .style import tokens
if TYPE_CHECKING:
    from ..ff.lists_config import FolderPoint
    from ..indexers.lists.menu import MenuScope

#: The values of a row in the order of the columns.
WHENS: tuple[When, ...] = (When.NEVER, When.IF_MANY, When.ALWAYS)
#: The depth of the preview (folders opened).
PREVIEW_DEPTH = 3
#: The lines of the preview at most.
PREVIEW_LINES = 40
#: The indent of a level of the preview (no-break spaces: kept by Kodi).
INDENT = '\u00a0' * 4
#: The left of the columns (the labels of the rows before them).
X0 = 470
#: The width of a column.
STEP = 120
#: The height of a row.
ROW_H = 29
#: The height of the head (the labels of the columns).
HEAD = 40


def when_label(when: When) -> str:
    """Return the label of a column."""
    return {When.NEVER: L(32829, 'Never'), When.IF_MANY: L(32970, 'If many'), When.ALWAYS: L(32831, 'Always')}[when]


def preview_lines(group: str = 'main') -> list[str]:
    """
    Return the lines of the preview of the menu of the group (`lc.FOLDER_GROUPS`): its context (`· …` - the other entries
    of the menu above), the folder of the group or its entries in place, their folders opened. The lists in the main menu
    are the main menu too (they are in it, in their folder or in place).
    """
    from ..indexers.lists.menu import MenuScope, build_menu

    def route(scope: MenuScope) -> MenuScope:
        """Return the scope itself (a folder of the preview is opened by it)."""
        return scope

    def level(menu_id: str, scope: MenuScope, depth: int, prefix: str) -> list[str]:
        """Return the lines of a level of the menu."""
        out: list[str] = []
        for node in build_menu(menu_id, scope, route=route):  # type: ignore[arg-type]  # a menu ID
            if node.inline is not None:
                line = f'[I]{L(30149, "My Lists")} …[/I]'
            elif isinstance(node.target, MenuScope):
                line = f'{node.label} ›'
            else:
                line = node.label + (f'  [COLOR {tokens().color.text.dim}]{node.role}[/COLOR]' if node.role else '')
            out.append(f'{prefix}· {line}')  # the fonts of the skins have no box-drawing characters
            if isinstance(node.target, MenuScope) and depth < PREVIEW_DEPTH:
                out.extend(level(menu_id, node.target, depth + 1, prefix + INDENT))
        return out

    def menu(menu_id: str, scope: MenuScope, *, label: str = '', when: str = '') -> list[str]:
        """Return the lines of a menu: its folder (`label`, by the folder point `when`; no point - always) or its entries in place."""
        count = len(build_menu(menu_id, scope, route=route))  # type: ignore[arg-type]  # a menu ID
        if not count:
            return []
        if label and (not when or lc.folder_when(when)(count)):
            return [f'· {label} ›', *level(menu_id, scope, 1, INDENT)]
        return level(menu_id, scope, 1, '')

    from ..ff.account_admin import menu_label
    from ..ff.menu_entries import entry_shown
    more = '· …'
    if group in ('main', 'lists'):
        lines = [more, *menu('lists', MenuScope(), label=lc.FOLDER_GROUPS['lists'](), when='main.lists'), more]
    elif group == 'my':
        lines = [more, *menu('movies', MenuScope(), label=menu_label('movies')), more]
    elif group == 'history':
        lines = [more, *menu('history', MenuScope())]
    elif group == 'own':
        lines = menu('lists', MenuScope(type='own'))
    elif group == 'persons':
        lines = [more, *(menu('persons', MenuScope(), label=menu_label('persons'), when='persons.my') if entry_shown('person.my') else ())]
    else:
        lines = []
    if len(lines) > PREVIEW_LINES:
        lines = [*lines[:PREVIEW_LINES - 1], '…']
    return lines


def preview_text(group: str) -> str:
    """Return the preview of the menu of the group (`preview_lines()`; an error shown in it: a preview must not break the window)."""
    try:
        return '\n'.join(preview_lines(group))
    except Exception as exc:
        from ..ff.logs import fflog_exc
        fflog_exc()
        return f'[COLOR {tokens().color.warning}]{exc}[/COLOR]'


def head_color(group: str, shown: str) -> str:
    """Return the color of the head of a group: the match color for the group of the preview (`shown`)."""
    return tokens().color.text.match if group == shown else tokens().color.text.dim


def switch_help(point: FolderPoint, when: When) -> str:
    """Return the help of a switch: a `When` of a level of a menu."""
    where = f'{lc.FOLDER_GROUPS[point.group]()}: {point.label()}'
    return L(32973, '{where} - {when}: a folder never, if there are more items, always (else the items in place).').format(
        where=where, when=when_label(when))
