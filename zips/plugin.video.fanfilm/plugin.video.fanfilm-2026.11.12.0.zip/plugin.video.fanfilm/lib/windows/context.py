from __future__ import annotations
from typing import Any, List, Sequence, TYPE_CHECKING
from ..windows.base import BaseDialog
from ..ff.menu import ContextMenuItem
from ..ff.control import execute

#: The height of the list of the menu for one item (more than the row: the list ends below its last row).
ITEM_HEIGHT = 75
#: The most items of the menu shown at once (the height of the list).
MAX_ITEM_VISIBLE = 5


def visible_items(menu: Sequence[ContextMenuItem]) -> List[ContextMenuItem]:
    """Return the items of the menu shown (not the hidden ones)."""
    return [item for item in menu if getattr(item, 'visible', True)]


class ContextMenuDialog(BaseDialog):
    """Custom context-menu for custom XML windows."""

    @classmethod
    def xml_vars(cls, *, menu: Sequence[ContextMenuItem] = (), **kwargs: Any) -> dict[str, Any]:
        """The height of the list (its items up to `MAX_ITEM_VISIBLE`), one item only (the list lower)."""
        count = len(visible_items(menu))
        return {'HEIGHT': ITEM_HEIGHT * max(1, min(MAX_ITEM_VISIBLE, count)), 'ONE_ITEM': count == 1}

    def __init__(self, *args: Any, menu: Sequence[ContextMenuItem], **kwargs: Any) -> None:
        """The menu (its shown items: the rows of the list)."""
        super().__init__(*args, **kwargs)
        self.items: List[ContextMenuItem] = visible_items(menu)
        self.find('items').rows = [label for label, _action in self.items]

    def on_init(self) -> None:
        """Focus the menu."""
        self.setFocusId(self.find('items').id)

    def on_items_activated(self, position: int) -> None:
        """An item chosen: run its action, the result is its index."""
        _label, action = self.items[position]
        if isinstance(action, str):
            execute(action)
        elif callable(action):
            if TYPE_CHECKING:
                from ..ff.routing import subobject
                assert not isinstance(action, subobject)
            action()

        self.close(position)
