
from __future__ import annotations
from typing import Any
from typing_extensions import Iterable
from ..ff.threads import Timer
from .base import BaseDialog
from .widgets.ratings import RatingBar
from ..ff.logs import fflog
from ..ff.item import FFItem
from ..ff.ratings import rating_services, MediaRating, RatingService, NORM_MIN, NORM_MAX
from ..kolang import L
from .. import FAKE
from const import const
from cdefs import RatingServiceName, RatingsStyle


class RatingsDialog(BaseDialog[int]):
    """
    Dialog for handling user ratings.

    Returns:
      - 1..10 - the selected rating (int) on close
      - None  - if cancelled
      - (-1)  - for rating removal
    """

    REMOVE_RATING = -1

    @classmethod
    def xml_vars(cls, *,
                 services: dict[str, RatingService] | None = None,
                 style: RatingsStyle | None = None,
                 **kwargs: Any,
                 ) -> dict[str, Any]:
        """
        The dialog structure depends on the rating services and the look (`style`, default: `const.dialog.ratings.style`
        of the request, a change needs no restart) only, ratings are shown by bindings.
        """
        return {
            'style': const.dialog.ratings.style if style is None else style,
            'services': dict(rating_services() if services is None else services),
            'MIN_RATING': NORM_MIN,
            'MAX_RATING': NORM_MAX,
            'RATING_RANGE': range(NORM_MIN, NORM_MAX + 1),
            'COLORS': const.dialog.ratings.colors,
        }

    def __init__(self,
                 *args,
                 ffitem: FFItem,
                 ratings: Iterable[MediaRating],
                 services: dict[str, RatingService] | None = None,
                 title: str = L(30542, 'Rate'),
                 **kwargs,
                 ):
        fflog(f'Initializing RatingsDialog {ffitem=}')
        super().__init__(*args, **kwargs)
        self.ffitem: FFItem = ffitem
        #: Current ratings of the media (shown by bindings).
        self.ratings: list[MediaRating] = list(ratings)
        #: Rating services (in the dialog order).
        self.services: dict[str, RatingService] = dict(rating_services() if services is None else services)
        if self.ratings:
            average = int(sum(r.rating for r in self.ratings) / len(self.ratings) + .5)
        else:
            average = int(NORM_MAX + NORM_MIN + .5) // 2 + NORM_MIN
        #: Rating button focused at start.
        self.average_rating: int = max(NORM_MIN, min(NORM_MAX, average))
        self.setProperty('title', title)
        self.setProperty('media.title', self.get_media_label())
        self._close_timer: Timer | None = None

    def rating_of(self, service: RatingService) -> MediaRating | None:
        """Return the current rating of the service (for bindings)."""
        return next((r for r in self.ratings if r.service.key == service.key), None)  # per account

    def star(self, level: int, index: int) -> MediaRating | None:
        """Return `index`-th rating on the rating `level` (in the services order), None if there is no such (for bindings)."""
        stars = [r for srv in self.services.values() if (r := self.rating_of(srv)) is not None and r.rating == level]
        return stars[index] if index < len(stars) else None

    def get_media_label(self) -> str:
        it = self.ffitem
        label = it.title
        if it.ref.is_season:
            label = f'{it.show_item.title} - Season {it.season}'
        elif it.ref.is_episode:
            label = f'{it.show_item.title} - {it.season}x{it.episode:02} - {it.title}'
        return label

    def _start_autoclose_timer(self):
        if const.dialog.ratings.autoclose_timeout > 0:
            self._cancel_autoclose_timer()  # Ensure any existing timer is cancelled
            self._close_timer = Timer(const.dialog.ratings.autoclose_timeout, self.close, args=[None])
            self._close_timer.start()

    def _cancel_autoclose_timer(self):
        if self._close_timer:
            self._close_timer.cancel()
            self._close_timer = None

    def on_init(self):
        self.setFocusId(self.find('rates', cls=RatingBar).button(self.average_rating).id)
        self._start_autoclose_timer()

    def on_closing(self) -> None:
        self._cancel_autoclose_timer()
        return super().on_closing()

    def on_rates_rated(self, rating: int) -> None:
        """A rating button: the rating."""
        self._cancel_autoclose_timer()
        self.close(rating)

    def on_cancel_clicked(self) -> None:
        """Close the dialog (no rating)."""
        self._cancel_autoclose_timer()
        self.close(None)

    def on_remove_clicked(self) -> None:
        """Remove the rating."""
        self._cancel_autoclose_timer()
        self.close(self.REMOVE_RATING)

    def on_number_button(self, button: int) -> bool:
        self._cancel_autoclose_timer()
        if button == 0 and NORM_MIN > 0:  # button 0 means rating 10
            button = 10
        if NORM_MIN <= button <= NORM_MAX:
            self.close(button)
            return True
        return False

    # Debug fake implementation (command-line testing).
    if FAKE:
        def do_modal(self) -> int | None:
            print('-----  Rating Dialog for item  -----')
            button = self.average_rating
            print(f'-- Ref:    {self.ffitem.ref:a}')
            print(f'-- Title:  {self.ffitem.title}')
            print(f'-- Button: {button}')
            for srv in self.services.values():
                if rat := self.rating_of(srv):
                    print(f'-- {srv.name:8}: {rat.rating} ({rat.raw_rating})')
                else:
                    print(f'-- {srv.name:8}: ---')
            # rating = input(f'Enter rating ({NORM_MIN}-{NORM_MAX}, R-remove) [{button}]: ')
            rating = input(f'Enter rating ({NORM_MIN}-{NORM_MAX}, R-remove): ')
            if rating.lower() == 'r':
                return self.REMOVE_RATING
            try:
                rating_int = int(rating)
                if NORM_MIN <= rating_int <= NORM_MAX:
                    return rating_int
            except ValueError:
                pass
            return None


if __name__ == '__main__':
    from ..ff.ratings import RatingService, MediaRating

    def test1():
        a = RatingService(name='trakt', min=1, max=10)
        # b = RatingService(name='tmdb', min=.5, max=20, step=.5, offset=.5)
        b = RatingService(name='tmdb', min=1, max=10, step=.5)
        c = RatingService(name='rev', min=5, max=1, step=-1)

        # trakt
        assert a.from_service_rating(1) == 1
        assert a.from_service_rating(7) == 7
        assert a.from_service_rating(10) == 10
        assert a.to_service_rating(1) == 1
        assert a.to_service_rating(7) == 7
        assert a.to_service_rating(10) == 10

        # tmdb
        assert b.from_service_rating(.5) == 1
        assert b.from_service_rating(1) == 1
        assert b.from_service_rating(7) == 7
        assert b.from_service_rating(10) == 10
        assert b.to_service_rating(1) == 1.0
        assert b.to_service_rating(7) == 7.0
        assert b.to_service_rating(10) == 10.0

        assert c.from_service_rating(5) == 1
        assert c.from_service_rating(1) == 10
        assert c.to_service_rating(1) == 5
        assert c.to_service_rating(10) == 1

    def test2():
        a = MediaRating(raw_rating=7, service=rating_services()['trakt'])
        b = MediaRating(raw_rating=7, service=rating_services()['tmdb'])
        c = MediaRating(raw_rating=7, service=rating_services()['mdblist'])
        assert a.service is rating_services()['trakt']
        win = RatingsDialog(ffitem=FFItem(), ratings=[a, b, c])

    test1()
    # test2()
