
from __future__ import annotations
from typing import cast, TYPE_CHECKING
from pathlib import PurePath
from xbmcgui import ACTION_MOVE_RIGHT, ACTION_MOVE_LEFT
from .base import BaseDialog, CANCEL_ACTIONS
from ..ff.item import FFItem
from ..ff.logs import fflog
if TYPE_CHECKING:
    from typing import Sequence, Iterator
    from pathlib import Path
    from xbmcgui import ListItem
    from .base import Action
    from ..ff.url import URL
    from .widgets.views import ListView


class GalleryDialog(BaseDialog[int]):
    """The gallery: the images in a grid (the widget `gallery`), one of them on the whole screen (Enter, Back: the grid again)."""

    @classmethod
    def image_items(cls, images: Sequence[str | Path | URL | FFItem]) -> list[FFItem]:
        """Override to provide images for XML template."""

        def ff_images(it: str | Path | URL | FFItem) -> Iterator[FFItem]:
            path = ''
            if isinstance(it, FFItem):
                art = it.getArt()
                for key in ('icon', 'landscape', 'poster', 'tvshow.poster', 'thumb'):
                    if path := art.get(key):
                        break
                else:
                    path = next(iter(art.values()), '')
            elif isinstance(it, PurePath):
                path = str(it)
                it = FFItem(label=it.stem, art={'icon': path}, info_type='pictures', mode=FFItem.Mode.Command)
            else:
                path = str(it)
                label = '' if '://' in path else PurePath(path).stem
                it = FFItem(label=label, art={'icon': path}, info_type='pictures', mode=FFItem.Mode.Command)
            art = it.getArt()
            art.setdefault('thumb', art.get('icon', path or ''))
            it.setArt(art)
            it.setProperty('image.url', path or '')
            yield it

        items = [im for it in images for im in ff_images(it)]
        for i, it in enumerate(items, 1):
            it.setProperty('index', str(i))
            if not it.label:
                it.label = f'Image {i:03d}'
        return items

    # @classmethod
    # def xml_vars(cls, *, images: Sequence[str | Path | FFItem], **kwargs) -> dict[str, Any] | None:
    #     """Override to provide images for XML template."""
    #     return {
    #         'columns': 4,
    #         'items': cls.image_items(images),
    #     }

    def __init__(self, *args, title: str, images: Sequence[str | Path | URL | FFItem], choose: bool = False, current: int = 0, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.title = title
        self.items = self.image_items(images)
        self._fullscreen_index: int | None = None
        self.choose = choose
        #: The image of the focus at the start (e.g. the chosen one before).
        self.current = current

    @property
    def gallery(self) -> ListView:
        """Return the grid of the images (its whole columns in the middle: the template)."""
        return cast('ListView', self.find('gallery'))

    def on_init(self):
        self.setProperty('window_title', self.title)
        self.gallery.rows = self.items
        self.gallery.current = self.current

    def on_action(self, action: Action) -> bool | None:
        action_id = action.getId()
        index = self.fullscreen_index
        # is gallery view (list)
        if index is None:
            ...
        # is fullscreen
        else:
            if action_id in CANCEL_ACTIONS:
                self.fullscreen_index = None
                return True
            if action_id == ACTION_MOVE_RIGHT:
                index = (index + 1) % len(self.items)
                self.fullscreen_index = index
            elif action_id == ACTION_MOVE_LEFT:
                index = (index - 1) % len(self.items)
                self.fullscreen_index = index

    def on_gallery_activated(self, index: int) -> None:
        """An image clicked: the result (`choose`), else on the whole screen."""
        if self.choose:
            self.close(index)
            return
        self.fullscreen_index = index

    @property
    def is_fullscreen(self) -> bool:
        return self._fullscreen_index is not None

    @property
    def fullscreen_index(self) -> int | None:
        return self._fullscreen_index

    @fullscreen_index.setter
    def fullscreen_index(self, index: int | None) -> None:
        if index is None:
            self.setProperty('fullsize.url', '')
            if self._fullscreen_index is not None:
                self.gallery.current = self._fullscreen_index  # the grid at the image (the arrows moved it too)
            self._fullscreen_index = None
        elif 0 <= index < len(self.items):
            item = self.items[index]
            self.setProperty('fullsize.url', item.getProperty('image.url') or '')
            self._fullscreen_index = index
        else:
            fflog.error(f'Invalid image index: {index}')

    def show_image(self, item: ListItem) -> None:
        if url := item.getProperty('image.url'):
            self.setProperty('fullsize.url', url)


def show_gallery(title: str, images: Sequence[str | Path | URL | FFItem], *, choose: bool = False, current: int = 0) -> int | None:
    """Show the images in the gallery; `choose`: return the index of the clicked one (None: closed), `current` has the focus first."""
    return GalleryDialog(title=title, images=images, choose=choose, current=current).do_modal()


if __name__ == '__main__':
    # DEBUG
    win = GalleryDialog(title='My Gallery', images=[f'({i:02d})' for i in range(5)])
    win.doModal()
