"""
The accounts of the configuration window (its page: `lib.windows.widgets.accounts`): the panel of an account, the rows of the
list of accounts, the structure of the page, the help of the switch cells and the operations of the view.

The view of the model `lib.ff.account_admin` (the folder `tools/accounts_folder` is the other one, for the CLI): the rows, the actions
(`account_actions()`), the switch cells; every change is written at once (the operations of the model) and the view shows
the new state. A grayed control keeps the focus, the footer tells why it can not be used (a click does nothing). The sync
runs in the service: the view shows its state (the Home window properties, `lib.ff.sync.sync_state()`) while open.
"""

from __future__ import annotations
from typing import Any, Callable
from typing_extensions import Protocol
from attrs import frozen, field
from .base import WindowRef
from .style import image_variant, tokens
from ..ff import account_admin as admin
from ..ff.accounts import Account, LIST_MENU_IDS, SERVICE_TYPES, get_account
from ..ff import theme
from ..ff.sync import SyncState, sync_state
from ..kolang import L

#: The actions of the tool buttons (in their order): add, remove, up, down, sync all.
TOOL_ACTIONS: tuple[admin.AccountAction, ...] = ('add', 'remove', 'up', 'down', 'sync_all')
#: The actions of the action buttons (in their order).
ACTIONS: tuple[admin.AccountAction, ...] = ('sign_in', 'revoke', 'refresh_profile', 'sync')


@frozen(kw_only=True)
class AccountPanel:
    """The panel of an account (the page shows it)."""

    #: The account (None: no account).
    account: Account | None = None
    #: The icon of the service.
    icon: str = ''
    #: The title: the label and the nick.
    title: str = ''
    #: The label of the account (the type label of a built-in account).
    label: str = ''
    #: The type, the ID and the state.
    info: str = ''
    #: The summary (plan, budget, waiting changes, last sync).
    summary: str = ''
    #: The state of the sync of the account in the service.
    sync: SyncState = ''
    #: The actions by name.
    actions: dict[admin.AccountAction, admin.ActionView] = field(factory=dict)
    #: The switch cells the type has (capabilities and menus) by the cell.
    cells: dict[str, admin.SwitchCellView] = field(factory=dict)

    @classmethod
    def of(cls, account: Account) -> AccountPanel:
        """Return the panel of the account."""
        state = admin.account_state(account)
        cells = (*admin.switch_cells(account), *admin.menu_cells(account))
        return AccountPanel(account=account, icon=service_icon(account), title=admin.account_title(account), label=account.label,
                            info=' · '.join((account.type.label, account.id, admin.state_label(state, account))),
                            summary=' · '.join(admin.account_summary(account)), sync=sync_state(account.id), actions=admin.account_actions(account),
                            cells={c.cell: c for c in cells})


def service_icon(account: Account, *, focused: bool = False) -> str:
    """Return the icon of the service of the account on a surface of the window (`focused`: on a focused card, `image_variant()`)."""
    return theme.art(f'services/{account.type.name}/main.png', variant=image_variant(focused))


@frozen(kw_only=True)
class AccountListRow:
    """A row of the list of accounts as shown: its texts, its icon (a grayed account: not signed in, suspended)."""

    #: The account ID.
    id: str
    #: The title: the label and the nick.
    title: str
    #: A grayed account (not signed in, suspended): its title in the background text.
    dim: bool
    #: The type and the state.
    info: str
    #: The icon of the service.
    icon: str
    #: The icon of the service on a focused card (`image_variant(True)`: the same as `icon` unless the card is of another brightness).
    icon_focused: str
    #: The diffuse color of the icon.
    icon_color: str

    @classmethod
    def of(cls, row: admin.AccountRow) -> AccountListRow:
        """Return the shown row of the account row."""
        acc = row.account
        dim = row.state in ('none', 'suspended')
        return AccountListRow(id=acc.id, title=row.title, dim=dim,
                              info=' · '.join((acc.type.label, admin.state_label(row.state, acc))), icon=service_icon(acc),
                              icon_focused=service_icon(acc, focused=True),
                              icon_color=tokens().color.image.dim if dim else tokens().color.image)


@frozen
class GridLine:
    """A line of the switches of the page: a capability, a direction or a menu of lists."""

    #: The position (from 0).
    index: int
    #: The name (`progress`, `read`, `movies`).
    name: str
    #: The label.
    label: str


@frozen(kw_only=True)
class AccountsLayout:
    """
    The structure of the page (the same for every account): the lines of the switches, the sizes. The sizes are derived:
    the panel after the list and the tools, the label column of the grid as wide as its longest text (the font of the skin),
    a column of the grid as wide as its head or its switch; the panel fills the rest.
    """

    #: The gap between the list, the tools, the panel and the columns of the grid.
    gap: int
    #: The width of the list.
    list_width: int
    #: The width (and the height) of a tool button.
    tool_width: int
    #: The height of a line of the grid.
    cell_h: int
    #: The width of the icon of a switch of the grid.
    cell_icon: int
    #: The height of a line of the menus of lists.
    menu_h: int
    #: The width of the icon of a switch of a menu.
    menu_icon: int
    #: The start of the first column of the switches (after the labels of the capabilities and a gap).
    cell_left: int
    #: The width of a column of the switches (a gap included).
    cell_step: int
    #: The head of the grid.
    sync_heading: str
    #: The capabilities (the lines of the grid).
    capabilities: tuple[GridLine, ...]
    #: The directions (the columns of the grid).
    directions: tuple[GridLine, ...]
    #: The menus of lists.
    menus: tuple[GridLine, ...]

    @property
    def panel_left(self) -> int:
        """Return the start of the panel (after the list and the tools)."""
        return self.list_width + self.gap + self.tool_width + self.gap

    @property
    def grid_width(self) -> int:
        """Return the width of the grid."""
        return self.cell_left + len(self.directions) * self.cell_step


def accounts_layout() -> AccountsLayout:
    """Return the structure of the page: the lines of the switches, the sizes (the fonts of the skin)."""
    from .gui import switch_icon_width
    from .skinfonts import text_metrics
    normal, _ = text_metrics('normal')
    small, _ = text_metrics('small')
    heading = L(32923, 'Synchronized data')
    capabilities = tuple(GridLine(i, c, admin.capability_label(c)) for i, c in enumerate(admin.CAPABILITIES))
    directions = tuple(GridLine(j, d, admin.direction_label(d)) for j, d in enumerate(admin.DIRECTIONS))
    gap, cell_h, menu_h = tokens().space.l, 62, 54
    icon = switch_icon_width(cell_h)
    return AccountsLayout(gap=gap, list_width=450, tool_width=tokens().metric.button.height, cell_h=cell_h, cell_icon=icon, menu_h=menu_h,
                          menu_icon=switch_icon_width(menu_h),
                          cell_left=round(max(normal(text) for text in (heading, *(line.label for line in capabilities)))) + gap,
                          # a margin: Kodi cuts a text of its exact width
                          cell_step=round(max(icon, *(small(line.label) + gap / 2 for line in directions))) + gap,
                          sync_heading=heading, capabilities=capabilities, directions=directions,
                          menus=tuple(GridLine(i, m, admin.menu_label(m)) for i, m in enumerate(LIST_MENU_IDS)))


def cell_help_text(cell: str, view: admin.SwitchCellView) -> str:
    """Return the help of a switch cell of the account (for a grayed one: why)."""
    if cell.startswith('menu.'):
        what = L(32913, 'Show the lists of the account in this menu.')
    elif cell.endswith('.read'):
        what = L(32914, 'FanFilm reads it from the account.')
    else:
        what = L(32915, 'FanFilm writes it to the account.')
    return ' '.join(t for t in (f'{admin.cell_label(cell)}: {what}', admin.cell_help(view)) if t)


def ask_add_account() -> Account | None:
    """Add an account (a free IMDb cookie of the browser is a choice too); return the new account, None if none."""
    from ..ff.ui import ui
    names = list(admin.types_to_add())
    labels = [SERVICE_TYPES[name].label for name in names]
    if free := admin.free_imdb_cookie():
        names.append('imdb')
        labels.append(L(32909, 'Add the IMDb account of {nick}').format(nick=free['profile']['username']))
    if (index := ui.select(L(32859, 'Add account…'), labels)) < 0:
        return None
    if (account := admin.ask_add(names[index])) is not None and free and index == len(names) - 1:
        admin.authorize(account, 'private')  # the received cookie is the first choice of the sign-in
    return account


def ask_rename(account: Account) -> bool:
    """Change the label of the account (a text dialog). Return True if changed."""
    from ..ff.ui import ui
    label = (ui.input(L(32869, 'Account label'), account.label) or '').strip()
    return bool(label) and label != account.label and admin.rename(account, label)


class AccountsView(Protocol):
    """A view of the accounts (the page of the configuration window): what the operations of the view use."""

    #: The panel of the account of the list.
    panel: AccountPanel

    #: The window, kept weakly (`WindowRef`).
    win: WindowRef[Any]

    def show_accounts(self, *, select: str | None = None) -> None:
        """Show the accounts again (after a change) with the account `select` (else the same place in the list)."""

    def show_panel(self) -> None:
        """Show the panel of the account selected in the list."""

    def focus_action(self, action: admin.AccountAction) -> None:
        """Move the focus to the button of the action of the panel."""


def run_action(view: AccountsView, action: admin.AccountAction) -> None:
    """A button: the action on the account of the panel (written at once, the view shows the new state); a grayed one does nothing."""
    if action == 'add':
        if (acc := ask_add_account()) is not None:
            view.show_accounts(select=acc.id)
            view.focus_action('sign_in')  # added not signed in: one click to sign in
        return
    if (acc := view.panel.account) is None or not view.panel.actions[action].available:
        return
    if action == 'remove':
        if admin.ask_remove(acc):
            view.show_accounts()
    elif action in ('up', 'down'):
        if admin.move(acc, -1 if action == 'up' else 1):
            view.show_accounts(select=acc.id)
    elif action == 'sign_in':
        admin.ask_authorize(acc)
        view.show_accounts(select=acc.id)
    elif action == 'revoke':
        if admin.ask_revoke(acc):
            view.show_accounts(select=acc.id)
    elif action == 'refresh_profile':
        if admin.ask_refresh_profile(acc):
            view.show_accounts(select=acc.id)
    elif action in ('sync', 'sync_all'):
        if admin.ask_sync(acc if action == 'sync' else None):
            view.show_panel()
    elif action == 'label':
        if ask_rename(acc):
            view.show_accounts(select=acc.id)


def run_switch(view: AccountsView, name: str, value: bool) -> None:
    """A switch clicked: "Active" (`active`) or a switch cell of the account of the panel (a grayed one keeps its state: shown again)."""
    if (acc := view.panel.account) is None:
        return
    if name == 'active':
        if view.panel.actions['active'].available:
            admin.set_active(acc, value)
    elif name in view.panel.cells:
        admin.ask_switch(acc, name)
    if (acc := get_account(acc.id)) is not None:
        view.show_accounts(select=acc.id)


def watch_sync_state(view: AccountsView, update: Callable[[], None]) -> None:
    """
    Show the panel again (`update()`) while the window is open (checked every second): the sync state of the account is not
    the shown one, or a pass of the service ended (the summary: synced, failed). A plain sleep: the monitor of `xsleep()` is
    destroyed at the end of the script (the window closed), a sleep there then waits for another script (K21: Kodi waits
    for the thread).
    """
    from time import sleep
    try:
        if not view.win.wait_ready():
            return
        running = sync_state()
        while view.win.wait_ready(0):
            now = sync_state()
            ended, running = bool(running) and not now, now
            if (acc := view.panel.account) is not None and (ended or sync_state(acc.id) != view.panel.sync):
                update()
            sleep(1)  # ponytail: a sync of the account between two checks is seen only by the end of its pass
    except ReferenceError:  # the window is gone (the view keeps it weakly, the sleep does not keep it)
        return
