"""
The window of a tree select: a list of FFItem in a tree, select one leaf or more (multiselect).

A node is an item with children (`FFItem.children_items` set, also empty), Enter (a click) expands / collapses it.
A leaf is selected (single: the result) or checked (multi). In the multiselect the check button of the selected row
(`const.dialog.tree.check`) or a node action (`const.dialog.tree.keys`, `toggle`: a digit, Info...) checks / unchecks all
leaves of a node (`select_nodes`), a leaf like Enter; the keys `up` / `down` (2 / 8) go to the previous / next node of
the level of the row (a leaf: of its parent), around. The state of a node (none / partial / all of its leaves)
is derived from its leaves, or it is its own (`TreeModel(own_nodes=True)`: an entry of a menu with its own entries).
The context menu of a row checks / unchecks / restores / sets the default / expands / collapses it (what applies).

A tree with a memory (`tree_vars(memory=<name>)`, in `config.json` beside the choice, the choice itself as before) keeps
the last partial state of every node (`TreeModel.memory`): a node action goes none -> the remembered -> all -> none
(without a memory: none / partial -> all -> none), its counter tells the remembered when the node is none or all
(`const.dialog.tree.count_remembered`). Its view (the expanded nodes, the selected row) is kept in the memory of Kodi
until its restart (`TREE_VIEW_PROPERTY`): the window opened again shows the tree as it was left.

The skin gets the state of a row by its properties (`tree.*`), the indent by the level:
the positions of a list item can not use `$INFO`, the content slides by conditional animations (one per level).

The tree in a list of a window (`TreeView`: the dialog of the tree select, a tab of a window) may have the buttons of the
selected row (`ROW_BUTTONS`: check, move up / down): a list item has no controls of its own, the buttons are a group over
the selected row (one conditional animation per visible row); up / down there move the list and the focus stays on the
button (OK, OK, OK moves a row on). The template is `resources/skins/widgets/tree.xml` (`TreeVars`); a window made of
widgets has the tree as its widget (`tree_view`, `lib/windows/widgets/views.py`): the buttons drawn by the selected row
(they scroll with it, the list scrolls) under transparent buttons over it (`TreeVars.buttons_in_rows`).

The list gets new `ListItem` rows (not the items of the tree) and Python keeps none of them: a list item shown in
a window has its layout, freed with the item; an item freed by Python after the window is gone crashes Kodi 21
(`CGUIControlLookup::RemoveLookup()` of the gone window). Only the list owns its rows, they go with the window.
"""

from __future__ import annotations
from typing import Any, Callable, Iterator, Sequence, cast, overload, TYPE_CHECKING
from functools import partial
from unicodedata import combining, normalize
from typing_extensions import Literal, TypeAlias, get_args
from attrs import evolve, field, frozen
from xbmcgui import (
    ACTION_MOVE_LEFT, ACTION_SHOW_INFO, ACTION_SHOW_SUBTITLES, ACTION_MOUSE_MIDDLE_CLICK,
    ACTION_CONTEXT_MENU, ACTION_TELETEXT_RED, ACTION_TELETEXT_GREEN, ACTION_TELETEXT_YELLOW, ACTION_TELETEXT_BLUE,
    ACTION_NONE, KEY_VKEY,
)
from .base import AbstractWindow, BaseDialog, MENU_ACTIONS, WindowRef, weak_callback
from .style import FOCUSED_ICON, focused_image_variant, surface_art, tokens
from .widgets.buttons import CHECK_STATES, next_checked
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from typing import Mapping
    from xbmcgui import Action, ControlEdit, ControlList, ListItem
    from cdefs import TreeKey
    from ..ff.item import FFItem
    from ..ff.menu import ContextMenuItem
    from .widgets import views

#: The state of a row: a leaf is none or all, a node by its leaves.
TreeCheck: TypeAlias = Literal['none', 'partial', 'all']
#: What a node action does with a branch: all checked, none, its remembered partial state back.
TreeStep: TypeAlias = Literal['all', 'none', 'restore']
#: The result of the tree select: the selected leaf (single) or the checked leaves (multi).
TreeResult: TypeAlias = 'FFItem | list[FFItem]'
#: A navigation target of a tree: a control ID or a reference to a widget (`@path`, a window made of widgets), 0 / '' - none.
NavTarget: TypeAlias = 'int | str'

#: The size of the window of the tree select.
WIDTH = 1300
HEIGHT = 940
#: The top of the tree in the window of the tree select (under its heading and its counter).
TREE_TOP = 124
#: The memories of the trees in the configuration (`/gui/tree/<name>/memory`, `tree_vars(memory=...)`).
TREE_CONFIG = '/gui/tree'
#: The view of a tree with a memory (its expanded nodes, its selected row, by their keys) in a property of the Kodi home
#: window: in the memory of Kodi until its restart, no file (`tree_vars(memory=...)`).
TREE_VIEW_PROPERTY = 'fanfilm.tree.{name}.view'
#: The remembered of a node after its counter (`3 / 7` + ` · 5`).
COUNT_MEMORY = ' · {count}'
#: The font style of the label of the marks of a row (`tree_vars(marks=True)`: the symbol font if Kodi has it), the
#: `ff:style` of its label in the template (read as it is, not a template field).
MARKS_STYLE = 'normal.symbol'
#: The gap between the text of a row and its marks (in the text font).
MARKS_GAP = '  '


@frozen(kw_only=True)
class MarkColors:
    """The colours of the marks in the text of a row (`TreeView.row_label()`, `TreeView.marks_text()`: `[COLOR]` of Python)."""

    #: The selection: a checked label, a raised mark.
    accent: str
    #: A partial selection: its label.
    partial: str
    #: A match of the filter.
    match: str


def mark_colors(focused: bool = False) -> MarkColors:
    """Return the colours of the marks in the text of a row (`focused`: of a focused row - a card, the tokens `*.row.focused`)."""
    color = tokens().color
    if focused:
        return MarkColors(accent=str(color.accent.row.focused), partial=str(color.accent.partial.row.focused), match=str(color.text.match.row.focused))
    return MarkColors(accent=str(color.accent), partial=str(color.accent.partial), match=str(color.text.match))


@frozen
class NodeAction:
    """A Kodi action of a key of a tree (an operation of `const.dialog.tree.keys`)."""

    #: The Kodi action ID.
    id: int
    #: The key in the hint under the heading.
    label: str
    #: The button code of a key with no action in the keymaps (the window gets `ACTION_NONE` with it), 0 - an action.
    button: int = 0


#: The values of a leaf of a tristate tree in the context menu of its row (`TreeModel.value()`).
TRISTATE_LABELS: dict[bool | None, str] = {True: L(30923, 'Required'), False: L(30924, 'Hidden'), None: L(30925, 'Any')}

#: The search key of a keyboard / a remote (`browser_search` in the keymaps, no action there): `XBMCVK_BROWSER_SEARCH` of
#: Kodi (`xbmc/input/keyboard/XBMC_vkeys.h`, K21 and K22), not in `xbmcgui`.
XBMCVK_BROWSER_SEARCH = 0xB4

#: All known actions of the keys of a tree by their Kodi names (`ActionTranslator`, as in the keymaps), `const.dialog.tree.keys`
#: picks the enabled ones. The digits `Number0`-`Number9` are not here, they come by `on_number_button()` (a remote and
#: the keyboard), labeled by the digit.
NODE_ACTIONS: dict[str, NodeAction] = {
    # Not on by default: the context menu opens the menu of the row (`row_menu()`), the user expects it there;
    # a long OK of a TV remote is no context menu either.
    'ContextMenu': NodeAction(ACTION_CONTEXT_MENU, L(30157, 'long OK')),
    'Info': NodeAction(ACTION_SHOW_INFO, 'Info'),
    'ShowSubtitles': NodeAction(ACTION_SHOW_SUBTITLES, L(30183, 'subtitles')),
    'Red': NodeAction(ACTION_TELETEXT_RED, L(30158, 'red')),
    'Green': NodeAction(ACTION_TELETEXT_GREEN, L(30159, 'green')),
    'Yellow': NodeAction(ACTION_TELETEXT_YELLOW, L(30160, 'yellow')),
    'Blue': NodeAction(ACTION_TELETEXT_BLUE, L(30161, 'blue')),
    'MiddleClick': NodeAction(ACTION_MOUSE_MIDDLE_CLICK, L(30165, 'middle click')),
    # not a Kodi action: the search key, unmapped in the keymaps of Kodi, comes as no action with its button code
    'Search': NodeAction(ACTION_NONE, L(30217, 'search'), button=KEY_VKEY + XBMCVK_BROWSER_SEARCH),
}


def key_labels(names: Sequence[str]) -> list[str]:
    """Return the labels of the keys (a known action, a digit) of the key names."""
    return [action.label if (action := NODE_ACTIONS.get(name)) else name[len('Number'):]
            for name in names if name in NODE_ACTIONS or name.startswith('Number')]


def tree_keys_hint(keys: Mapping[TreeKey, Sequence[str]], *, button: bool = False) -> str:
    """
    Return the hint of the keys of a tree ("Info / 0: the whole branch · 2 / 8: the previous / next node · 3: filter"),
    `button`: the check button checks the branch too ("right, OK").
    """
    hints: list[str] = []
    if toggle := [*key_labels(keys.get('toggle', ())), *((L(30348, 'right, OK'),) if button else ())]:
        hints.append(L(30164, '{keys}: the whole branch').format(keys=' / '.join(toggle)))
    if jump := key_labels([*keys.get('up', ()), *keys.get('down', ())]):
        hints.append(L(30770, '{keys}: the previous / next node').format(keys=' / '.join(jump)))
    if search := key_labels(keys.get('filter', ())):
        hints.append(L(30212, '{keys}: filter').format(keys=' / '.join(search)))
    return ' · '.join(hints)


@frozen
class RowMarks:
    """
    The marks of a row of a tree after its label (`TreeView(marks=...)`, `TreeView.marks_text()`): its own color, raised (its own priority),
    a symbol (e.g. the direction of a criterion of a sort).
    """

    #: The color (AARRGGBB), '' - none.
    color: str = ''
    #: Raised (an up mark).
    up: bool = False
    #: The name of a symbol (`skinfonts.symbol_variants()`) in the accent colour, '' - none.
    symbol: str = ''


@frozen
class TreeRow:
    """A visible row of the tree."""

    #: The item.
    item: FFItem
    #: The depth (0: a root).
    level: int
    #: The index of the row of the parent, -1 for a root.
    parent: int

    @property
    def node(self) -> bool:
        """True if the row is a node (it has children, maybe none)."""
        return self.item.children_items is not None


#: The letters without a decomposition in Unicode (NFKD) and their base letters (`fold()`).
FOLD_LETTERS = str.maketrans({'ł': 'l', 'Ł': 'L', 'ø': 'o', 'Ø': 'O', 'đ': 'd', 'Đ': 'D', 'ß': 'ss'})


def fold(text: str) -> tuple[str, list[int]]:
    """Return the text for a match (no case, no diacritics: "Źródła" -> "zrodla") and the index in `text` of every its character."""
    folded: list[str] = []
    index: list[int] = []
    for n, char in enumerate(text):
        for part in normalize('NFKD', char.translate(FOLD_LETTERS)).casefold():
            if not combining(part):
                folded.append(part)
                index.append(n)
    return ''.join(folded), index


def match_span(text: str, needle: str) -> tuple[int, int] | None:
    """Return the span (start, end) in `text` of the folded `needle` (`fold()`), None if it is not there."""
    folded, index = fold(text)
    if not needle or (start := folded.find(needle)) < 0:
        return None
    return index[start], index[start + len(needle) - 1] + 1


def children(item: FFItem) -> Sequence[FFItem]:
    """Return the children of the item (none for a leaf)."""
    return item.children_items or ()


class TreeModel:
    """
    The state of the tree: expanded nodes, selected items and the visible rows (no Kodi). A node is selected by its leaves
    (a choice of leaves), with `own_nodes` it has its own state (an entry of a menu with its own entries): its entries are
    dimmed when it is not selected, they keep their states. The default selection (`defaults`) and the memory of the
    partial states of the nodes (`memory`) are optional.
    """

    def __init__(self, roots: Sequence[FFItem], *, selected: Sequence[FFItem] = (), expanded: Sequence[FFItem] = (), own_nodes: bool = False,
                 defaults: Sequence[FFItem] | None = None, key: Callable[[FFItem], str] | None = None, tristate: bool = False,
                 rejected: Sequence[FFItem] = (), actions: Sequence[FFItem] = ()) -> None:
        """
        Make the model of the `roots`; only the `expanded` nodes are expanded (the counters and the check of a node tell
        where the selected leaves are); `defaults`: the items selected by default (None: no default selection); `key`:
        the key of an item among its siblings (None: its label), the key of an item is the path of them from its root;
        `tristate`: a leaf has a third value (`value()`: selected True, `rejected` False, else None - a filter: must, must not, any);
        `actions`: leaves of no state (no check, not counted), OK on one activates it - a choice of leaves too.
        """
        #: The roots of the tree.
        self.roots: list[FFItem] = list(roots)
        #: A node has its own state (else by its leaves).
        self.own_nodes: bool = own_nodes
        #: The selected items (by `id()`: an item may define its own equality).
        self.selected: set[int] = {id(it) for it in selected}
        #: A leaf has a third value: neither selected nor rejected (`value()`; its node keeps the state of its selected leaves).
        self.tristate: bool = tristate
        #: The rejected leaves of a tristate tree (by `id()`): their value False, never selected (`set_selected()`).
        self.rejected: set[int] = {id(it) for it in rejected} - self.selected
        #: The expanded nodes (by `id()`).
        self.expanded: set[int] = {id(it) for it in expanded}
        #: The leaves of no state, activated by OK (by `id()`).
        self.actions: set[int] = {id(it) for it in actions}
        #: The parent of every item (by `id()`), None for a root.
        self.parents: dict[int, FFItem | None] = {}
        #: The key of every item (by `id()`): the path of the keys from its root.
        self.keys: dict[int, str] = {}
        for item, parent in self._walk(self.roots, None):
            self.parents[id(item)] = parent
            name = key(item) if key is not None else item.getLabel()
            self.keys[id(item)] = name if parent is None else f'{self.keys[id(parent)]}/{name}'
        #: The items selected by default (by `id()`), None: no default selection.
        self.defaults: set[int] | None = None if defaults is None else {id(it) for it in defaults}
        #: The last partial state of every node (its key: the keys of its selected `checkables()`), None: no memory (`load_memory()`).
        self.memory: dict[str, list[str]] | None = None
        #: The filter (folded, `fold()`; '' - none): the rows of the matched items, of the items under them and of their ancestors.
        self.filter: str = ''
        #: The items in the filter (matched or under a matched one; a branch action changes only them) and the shown ones (by `id()`).
        self.in_filter: set[int] = set()
        self._shown: set[int] = set()
        #: The nodes expanded by the filter: the ancestors of the matched items and the matched nodes (by `id()`).
        self._filter_expanded: set[int] = set()
        #: The visible rows.
        self.rows: list[TreeRow] = self.flatten()

    def _walk(self, items: Sequence[FFItem], parent: FFItem | None) -> Iterator[tuple[FFItem, FFItem | None]]:
        """Iterate over all items (depth first) with their parents."""
        for item in items:
            yield item, parent
            yield from self._walk(children(item), item)

    def flatten(self) -> list[TreeRow]:
        """Return the visible rows: the roots and the children of the expanded nodes."""
        rows: list[TreeRow] = []

        def add(items: Sequence[FFItem], level: int, parent: int) -> None:
            for item in items:
                if self.filter and id(item) not in self._shown:
                    continue
                rows.append(TreeRow(item, level, parent))
                if self.is_expanded(item):
                    add(children(item), level + 1, len(rows) - 1)

        add(self.roots, 0, -1)
        return rows

    def items(self) -> list[FFItem]:
        """Return all items of the tree in its order."""
        return [item for item, _ in self._walk(self.roots, None)]

    def leaves(self, item: FFItem) -> Iterator[FFItem]:
        """Iterate over the leaves of the item (the item itself if it is a leaf)."""
        if item.children_items is None:
            yield item
        else:
            for child in item.children_items:
                yield from self.leaves(child)

    def checkables(self, item: FFItem) -> Iterator[FFItem]:
        """Iterate over the items of the branch of the item that have a state: its leaves, with `own_nodes` the whole branch (no action)."""
        if self.own_nodes:
            yield from (it for it, _ in self._walk((item,), None) if id(it) not in self.actions)
        else:
            yield from (it for it in self.leaves(item) if id(it) not in self.actions)

    def all_leaves(self) -> list[FFItem]:
        """Return all leaves of the tree in its order."""
        return [leaf for root in self.roots for leaf in self.leaves(root)]

    def count(self, item: FFItem, selected: set[int] | None = None) -> tuple[int, int]:
        """Return the number of the selected items of the branch of the item (`checkables()`) and of all of them; `selected`: of another selection."""
        chosen = self.selected if selected is None else selected
        items = list(self.checkables(item))
        return sum(id(it) in chosen for it in items), len(items)

    def visible_count(self, item: FFItem, selected: set[int] | None = None) -> tuple[int, int]:
        """
        Return the number of the entries of the branch of the node (`own_nodes`, the node itself not counted) that are
        really visible (they and every node between them and the node selected) and of all of them; `selected`: of
        another selection (else the current one).
        """
        chosen = self.selected if selected is None else selected

        def walk(items: Sequence[FFItem], shown: bool) -> Iterator[bool]:
            for it in items:
                visible = shown and id(it) in chosen
                yield visible
                yield from walk(children(it), visible)

        states = list(walk(children(item), True))
        return sum(states), len(states)

    def check(self, item: FFItem) -> TreeCheck:
        """Return the state of the item: its own (`own_nodes`, a leaf), else none, partial or all of its leaves selected."""
        if self.own_nodes:
            return 'all' if id(item) in self.selected else 'none'
        selected, total = self.count(item)
        return 'none' if not selected else 'all' if selected == total else 'partial'

    def value(self, item: FFItem) -> bool | None:
        """Return the value of the item itself (`CheckBox.checked`): selected True, else of a tristate tree rejected False, neither None."""
        if id(item) in self.selected:
            return True
        return False if not self.tristate or id(item) in self.rejected else None

    def dimmed(self, item: FFItem) -> bool:
        """Return True if an ancestor of the item is not selected (`own_nodes`: the entries of a hidden menu)."""
        return self.own_nodes and any(id(it) not in self.selected for it in self.ancestors(item))

    def selected_leaves(self) -> list[FFItem]:
        """Return the selected leaves in the order of the tree."""
        return [leaf for leaf in self.all_leaves() if id(leaf) in self.selected]

    def ancestors(self, item: FFItem) -> Iterator[FFItem]:
        """Iterate over the ancestors of the item (the parent first)."""
        while (item := self.parents.get(id(item))) is not None:  # type: ignore[assignment]
            yield item

    def is_expanded(self, item: FFItem) -> bool:
        """Return True if the node is expanded (by the user or by the filter)."""
        return id(item) in self.expanded or id(item) in self._filter_expanded

    def toggle_expanded(self, pos: int) -> None:
        """Expand or collapse the node of the row (also one expanded by the filter)."""
        key = id(self.rows[pos].item)
        if self.is_expanded(self.rows[pos].item):
            self.expanded.discard(key)
            self._filter_expanded.discard(key)
        else:
            self.expanded.add(key)
        self.rows = self.flatten()

    def set_filter(self, text: str) -> None:
        """
        Filter the rows by the text (`fold()`; shorter than `const.dialog.tree.filter.min_chars`: none): the matched items with
        the items under them (a matched node: all its branch), their ancestors expanded; none: the expanded nodes of the user.
        """
        needle, _ = fold(text.strip())
        self.filter = needle if len(needle) >= const.dialog.tree.filter.min_chars else ''
        self.in_filter, self._shown, self._filter_expanded = set(), set(), set()
        if self.filter:
            matched = [item for item in self.items() if match_span(item.getLabel(), self.filter) is not None]
            for item in matched:
                self.in_filter |= {id(it) for it, _ in self._walk((item,), None)}
                ancestors = {id(it) for it in self.ancestors(item)}
                self._shown |= ancestors
                self._filter_expanded |= ancestors | ({id(item)} if item.children_items else set())
            self._shown |= self.in_filter
        self.rows = self.flatten()

    def targets(self, item: FFItem) -> list[FFItem]:
        """Return the items a branch action of the item changes: its `checkables()`, with a filter only those in it."""
        return [it for it in self.checkables(item) if not self.filter or id(it) in self.in_filter]

    def branch_count(self, item: FFItem) -> tuple[int, int]:
        """Return the number of the selected items of the branch action of the item (`targets()`) and of all of them."""
        items = self.targets(item)
        return sum(id(it) in self.selected for it in items), len(items)

    def toggle_selected(self, pos: int) -> None:
        """Select or unselect the item of the row itself (a leaf, a node of `own_nodes`); a tristate leaf: its next value (`next_checked()`)."""
        item = self.rows[pos].item
        self.set_value(item, next_checked(self.value(item), self.tristate and item.children_items is None))

    def set_value(self, item: FFItem, value: bool | None) -> None:
        """Set the value of the item itself (`value()`: selected True, a tristate leaf rejected False, else None)."""
        if value is False:
            self.rejected.add(id(item))
        else:
            self.rejected.discard(id(item))
        self.set_selected(self.selected | {id(item)} if value else self.selected - {id(item)})

    def set_selected(self, selected: set[int]) -> None:
        """
        Set the selected items (by `id()`; a selected one is not rejected), remember the partial states of the nodes (every change of the
        selection comes here).
        """
        self.selected = set(selected)
        self.rejected -= self.selected
        self.remember()

    def set_branch(self, pos: int, selected: set[int]) -> None:
        """Set the selected items of the branch of the row (`targets()`) to those of `selected` (by `id()`)."""
        keys = {id(it) for it in self.targets(self.rows[pos].item)}
        self.set_selected((self.selected - keys) | (selected & keys))

    def select_node(self, pos: int, selected: bool) -> None:
        """Select or unselect the branch of the row (`targets()`; a leaf: itself)."""
        self.set_branch(pos, {id(it) for it in self.targets(self.rows[pos].item)} if selected else set())

    def next_step(self, item: FFItem) -> TreeStep:
        """Return what a node action does with the branch of the item: none -> the remembered -> all -> none (no memory: none / partial -> all)."""
        selected, total = self.branch_count(item)
        if not selected and self.restorable(item):
            return 'restore'
        return 'all' if selected < total else 'none'

    def toggle_node(self, pos: int) -> None:
        """Do the next step of the branch of the row (`next_step()`); a leaf toggles."""
        step = self.next_step(self.rows[pos].item)
        if step == 'restore':
            self.restore_node(pos)
        else:
            self.select_node(pos, step == 'all')

    # --- the default selection, the memory ---

    def decided(self, item: FFItem) -> bool:
        """Check if the branch of the item (`targets()`) has a decision: a selected item or a rejected one (a tristate tree)."""
        keys = {id(it) for it in self.targets(item)}
        return bool(keys & self.selected or keys & self.rejected)

    def is_default(self, item: FFItem) -> bool:
        """Return True if the branch of the item has its default selection, none rejected (also without a default selection)."""
        if self.defaults is None:
            return True
        keys = {id(it) for it in self.targets(item)}
        return self.selected & keys == self.defaults & keys and not self.rejected & keys

    def reset_node(self, pos: int) -> None:
        """Set the default selection of the branch of the row, none rejected (a tristate leaf: neither unless a default)."""
        if self.defaults is not None:
            self.rejected -= {id(it) for it in self.targets(self.rows[pos].item)}
            self.set_branch(pos, self.defaults)

    def remembered(self, item: FFItem) -> set[int]:
        """Return the remembered selection of the branch of the node (by `id()`; empty: none)."""
        if not self.memory or (keys := self.memory.get(self.keys[id(item)])) is None:
            return set()
        on = set(keys)
        return {id(it) for it in self.checkables(item) if self.keys[id(it)] in on}

    def restorable(self, item: FFItem) -> bool:
        """Return True if the node has a remembered state which is not the current one (of the branch action, `targets()`)."""
        keys = {id(it) for it in self.targets(item)}
        return bool(remembered := self.remembered(item)) and remembered & keys != self.selected & keys

    def restore_node(self, pos: int) -> None:
        """Set the remembered state of the branch of the row."""
        self.set_branch(pos, self.remembered(self.rows[pos].item))

    def remember(self) -> None:
        """Remember the current state of every partial node (none and all keep the memory)."""
        if self.memory is None:
            return
        for item in self.items():
            if item.children_items is not None:
                items = list(self.checkables(item))
                keys = [self.keys[id(it)] for it in items if id(it) in self.selected]
                if 0 < len(keys) < len(items):
                    self.memory[self.keys[id(item)]] = keys

    def load_memory(self, memory: dict[str, list[str]]) -> None:
        """
        Start the memory (from the configuration): a node of the tree keeps only its items which are there (none or all
        left: forgotten), a node not in the tree now keeps its memory; then the current partial states.
        """
        self.memory = {}
        nodes = {self.keys[id(it)]: it for it in self.items() if it.children_items is not None}
        for key, keys in memory.items():
            if (node := nodes.get(key)) is None:
                self.memory[key] = list(keys)
                continue
            known = {self.keys[id(it)] for it in self.checkables(node)}
            if 0 < len(kept := [k for k in keys if k in known]) < len(known):
                self.memory[key] = kept
        self.remember()

    def siblings(self, item: FFItem) -> list[FFItem]:
        """Return the items of the level of the item (the children of its parent, the roots)."""
        parent = self.parents.get(id(item))
        return self.roots if parent is None else cast('list[FFItem]', parent.children_items)

    def can_move(self, pos: int, delta: int) -> bool:
        """Return True if the item of the row can move by `delta` among its siblings."""
        item = self.rows[pos].item
        siblings = self.siblings(item)
        return 0 <= next(i for i, it in enumerate(siblings) if it is item) + delta < len(siblings)

    def move(self, pos: int, delta: int) -> int | None:
        """Move the item of the row by `delta` among its siblings (with its branch), return its new row; None if it can not."""
        if not self.can_move(pos, delta):
            return None
        item = self.rows[pos].item
        siblings = self.siblings(item)
        i = next(i for i, it in enumerate(siblings) if it is item)
        siblings[i], siblings[i + delta] = siblings[i + delta], siblings[i]
        self.rows = self.flatten()
        return next(n for n, row in enumerate(self.rows) if row.item is item)

    def remove(self, pos: int) -> FFItem:
        """Remove the item of the row with its branch (its states forgotten), return it."""
        item = self.rows[pos].item
        siblings = self.siblings(item)
        del siblings[next(i for i, it in enumerate(siblings) if it is item)]
        for it, _ in self._walk([item], None):
            for ids in (self.selected, self.rejected, self.expanded):
                ids.discard(id(it))
            self.parents.pop(id(it), None)
            self.keys.pop(id(it), None)
        self.rows = self.flatten()
        return item

    def sibling_node(self, pos: int, delta: int) -> int | None:
        """
        Return the row of the previous (`delta` -1) / next (1) node of the level of the row (a leaf: of its parent; a leaf of
        the roots: of the roots), around; None if there is no other node.
        """
        row = self.rows[pos]
        item = row.item if row.node or row.parent < 0 else self.rows[row.parent].item
        siblings = self.siblings(item)
        i = next(n for n, it in enumerate(siblings) if it is item)
        for step in range(1, len(siblings)):
            if (it := siblings[(i + delta * step) % len(siblings)]).children_items is not None:
                return next(n for n, r in enumerate(self.rows) if r.item is it)
        return None

    def left(self, pos: int) -> int | None:
        """
        Move left from the row, return the new row: an expanded node collapses (the same row), another row goes to its
        parent; None for a collapsed root (out of the list).
        """
        row = self.rows[pos]
        if row.node and self.is_expanded(row.item):
            self.toggle_expanded(pos)
            return pos
        return None if row.parent < 0 else row.parent


@frozen
class RowButton:
    """A button of the selected row of a tree (`ROW_BUTTONS`)."""

    #: The name (`TreeView(buttons=...)`, the row property `tree.button.<name>`: the button applies to the row).
    name: str
    #: The icon (a texture of the add-on); none: the check box of the state of the row.
    icon: str
    # the functions are out of the repr: the template vars hold the button, their repr is the key of the cached XML
    #: The label (the help, the context menu) of the button for the row.
    label: Callable[[TreeView, int], str] = field(repr=False)
    #: True if the button applies to the row (else grayed, nothing to do).
    applies: Callable[[TreeView, int], bool] = field(repr=False)
    #: The action of the button for the row.
    action: Callable[[TreeView, int], None] = field(repr=False)

    def __reduce__(self) -> tuple[Callable[[str], RowButton], tuple[str]]:
        """Pickle the button by its name (the cached template vars): the button of `ROW_BUTTONS` again."""
        return row_button, (self.name,)


def row_button(name: str) -> RowButton:
    """Return the button of a row by its name (`ROW_BUTTONS`)."""
    return ROW_BUTTONS[name]


#: The buttons of a row a tree can have, by their names (`TreeView(buttons=...)`).
ROW_BUTTONS: dict[str, RowButton] = {button.name: button for button in (
    RowButton('check', '', lambda view, pos: view.step_label(pos, view.check_step(pos)), lambda view, pos: view.can_check(pos), lambda view, pos: view.check(pos)),
    RowButton('up', 'icons/up.32.png', lambda view, pos: L(32863, 'Move up'),
              lambda view, pos: view.model.can_move(pos, -1), lambda view, pos: view.move(pos, -1)),
    RowButton('down', 'icons/down.32.png', lambda view, pos: L(32866, 'Move down'),
              lambda view, pos: view.model.can_move(pos, 1), lambda view, pos: view.move(pos, 1)),
    RowButton('remove', 'icons/cross.32.png', lambda view, pos: L(30512, 'Remove'), lambda view, pos: True, lambda view, pos: view.remove(pos)),
)}


#: The left of the expander of a node (+ / -) in the content of a row and the left of what is after it (the icon, the label).
EXPANDER_LEFT: int = 12
EXPANDER_END: int = 48

#: What the counter of a node of tristate leaves shows (`DecisionSlots.summary`).
TreeSummary: TypeAlias = Literal['counts', 'marks', 'changed']
#: The kinds of the counter of a node of tristate leaves.
SUMMARIES: tuple[TreeSummary, ...] = get_args(TreeSummary)


@frozen(kw_only=True)
class DecisionSlots:
    """
    The places of the counter of a node of tristate leaves (`TreeVars.decisions`): `✓ 1 · ✗ 1` - its leaves of each decision, the marks the
    icons of the toggle switch (`icons/check`, `icons/cross`; a font of Kodi 21 has no such glyphs), left to right in the counter.
    """

    #: The side of a mark (the mark of the toggle switch).
    icon: int
    #: The width of a count (two digits) and of the dot between the decisions.
    digits: int
    #: The gap after a mark.
    gap: int
    #: What it shows: the counts with their marks, the marks of the decisions taken (no counts), one mark of a change.
    summary: TreeSummary = 'counts'

    @property
    def yes_left(self) -> int:
        """Return the left of the count of the selected leaves (must), after the mark ✓ at 0."""
        return self.icon + self.gap

    @property
    def dot_left(self) -> int:
        """Return the left of the dot between the decisions."""
        return self.yes_left + self.digits

    @property
    def cross_left(self) -> int:
        """Return the left of the mark ✗."""
        return self.dot_left + self.digits

    @property
    def no_left(self) -> int:
        """Return the left of the count of the rejected leaves (must not)."""
        return self.cross_left + self.icon + self.gap

    @property
    def width(self) -> int:
        """Return the width of the counter (of the marks without the counts, of one mark)."""
        if self.summary == 'marks':
            return 2 * self.icon  # side by side: the marks have their margins in their images
        if self.summary == 'changed':
            return self.icon
        return self.no_left + self.digits


@frozen
class ButtonVars:
    """A button of the selected row in the template: its control ID and the button."""

    #: The control ID.
    id: int
    #: The button.
    button: RowButton


@frozen(kw_only=True)
class TreeVars:
    """The template vars of a tree (`resources/skins/widgets/tree.xml`): the list, its rows, the buttons of the selected row."""

    #: The list of rows.
    list_id: int
    #: The position and the size of the list.
    left: int
    top: int
    width: int
    height: int
    #: The height of a row.
    row_height: int
    #: The rows have the second lines (`ListItem.Label2` under the label, a row without one has its label in the middle).
    details: bool
    #: The levels indented at most.
    max_depth: int
    #: The indent of a level.
    indent: int
    #: The place of the icon of a row before its label (else the label right after the expander).
    icons: bool
    #: The expander of a node (+ / -) before the label (else none: the label at the left edge of the content).
    expanders: bool = True
    #: The multiselect (the counter of a node).
    multi: bool
    #: The rows have their own states (the menus): an unchecked row is dimmed; else (a choice of leaves) the label has the color of its state.
    own_nodes: bool
    #: The check column (multi without the check button).
    check_icon: bool
    #: The width of the counter of a node (multi; with a memory and `const.dialog.tree.count_remembered`: the remembered too).
    count_width: int
    #: The marks of a row in their own label right after its text (`tree_vars(marks=True)`, `TreeView.marks_properties()`):
    #: the width of the label and of the gap before it; 0 - the marks in the text of the row.
    marks_width: int
    marks_gap: int
    #: The name of the memory of the partial states of the nodes in the configuration ('' - none).
    memory: str
    #: The filter field above the list (its clear button: the next ID; 0 - no filter), its hint without a text.
    filter_id: int
    filter_hint: str
    #: The buttons of the selected row in their order, their size.
    buttons: tuple[ButtonVars, ...]
    button_width: int
    #: The group of the buttons.
    buttons_id: int
    #: The buttons drawn by the selected row (they scroll with it: the list scrolls), the ones over it transparent (the focus,
    #: the clicks); else drawn over the selected row (the list does not scroll: the rows would slide under them).
    buttons_in_rows: bool
    #: A move right from the list (the first button if any; 0: none), from the last button (0: nowhere), left from the list (0: Python).
    onright: NavTarget
    button_onright: NavTarget
    onleft: NavTarget
    #: A move up from the first row / down from the last row, of the list and of the buttons (0: none, the list wraps - a focus line
    #: through the tree may take the direction).
    onup: NavTarget
    ondown: NavTarget
    #: The separators of the groups of rows among siblings (`row_separator`, `views.group_separators()`; the items: their property `group`).
    separators: bool = False
    #: The names of the groups shown over their separators (sections).
    group_names: bool = False
    #: The band of the label of a group over the content of a row (a part of `row_height`; 0: none).
    group_head: int = 0
    #: Where the label of a group breaks the line of its separator (`GROUP_ALIGNS`).
    group_align: str = 'left'
    #: One level only (a list as a tree: the drop-down list of a combo box): no node keys, its line above the list only for its
    #: filter - the hint of its keys is the help of the tree (the footer of the window).
    flat: bool = False
    #: A leaf has a third value (`TreeModel.tristate`: the model of the tree takes it from here).
    tristate: bool = False
    #: The look of the state of a leaf in the check column (`check_look`: the toggle switch `TOGGLE` or a box texture family; the row
    #: property `tree.state`, a node shows none), '' the check box of a row of today (none / partial / all, also of a node).
    check_look: str = ''
    #: The counter of a node of tristate leaves: its leaves of each decision (the row properties `tree.count.yes`, `tree.count.no`), None
    #: of a two-state tree (`tree.count`: selected / all).
    decisions: DecisionSlots | None = None

    @property
    def row_body(self) -> TreeVars:
        """Return the vars of the content of a row: a row without the band of the label of a group over it (`group_head`)."""
        return evolve(self, row_height=self.row_height - self.group_head, group_head=0) if self.group_head else self

    @property
    def focused_marks(self) -> bool:
        """
        Return True while the marks in the text of a focused row have their own colours (`mark_colors()`): its label and its marks are
        the row properties `tree.label.focused`, `tree.marks.focused` (Kodi: one text of a list item for both layouts).
        """
        return mark_colors(True) != mark_colors()

    @property
    def focused_icon(self) -> str:
        """Return the art of the icon of a focused row (`FOCUSED_ICON`) while a focused card is of another brightness (`focused_image_variant()`), else ''."""
        return FOCUSED_ICON if focused_image_variant() else ''

    @property
    def scroll_time(self) -> int:
        """Return the scroll time of the list: none with the buttons over the selected row only (`buttons_in_rows`)."""
        return 0 if self.buttons and not self.buttons_in_rows else 200

    @property
    def visible_rows(self) -> int:
        """Return the rows the list shows at once (the positions of the buttons)."""
        return max(1, self.height // self.row_height)

    @property
    def check_width(self) -> int:
        """Return the width of the check column (a toggle switch: its width and a margin)."""
        if not self.check_icon:
            return 0
        from .gui import TOGGLE, toggle_vars
        return toggle_vars(self.tristate).width + 16 if self.check_look == TOGGLE else 80

    @property
    def right_width(self) -> int:
        """Return the width on the right of a row the content does not use (the check column, the counter, the buttons)."""
        return self.check_width + self.count_width + len(self.buttons) * self.button_width

    @property
    def label_left(self) -> int:
        """Return the left of the label of a row (after the expander and the icon), before the indent of its level."""
        return self.icon_left + (self.row_height if self.icons else 0)

    @property
    def expander_left(self) -> int:
        """Return the left of the expander of a node in the content of a row."""
        return EXPANDER_LEFT

    @property
    def icon_left(self) -> int:
        """Return the left of the icon of a row (of its label without icons): after the expander, without expanders at its place."""
        return EXPANDER_END if self.expanders else EXPANDER_LEFT

    @property
    def node_check_width(self) -> int:
        """Return the width of the check column in the row of a node: none with the look of the state of a leaf (a node shows none)."""
        return 0 if self.check_look else self.check_width

    def label_width(self, level: int, node: bool, selected: bool = True) -> int:
        """
        Return the width of the label of a row of the level (the row slides by its indent): a node up to its counter (the check column of its
        row: `node_check_width`), a leaf up to the check; up to the buttons of the selected row (`selected`), else up to the ones of every
        row (`row_buttons_width`).
        """
        check = self.node_check_width if node else self.check_width
        buttons = len(self.buttons) * self.button_width if selected else self.row_buttons_width
        return self.width - (check + buttons) - self.label_left - (level * self.indent + 8 + (self.count_width if node else 0))

    @property
    def row_buttons_width(self) -> int:
        """
        Return the width of the buttons drawn in every row (the state of the check button, from it to the right edge); the others only by
        the selected row.
        """
        names = [slot.button.name for slot in self.buttons]
        return (len(names) - names.index('check')) * self.button_width if 'check' in names else 0

    @property
    def selected_marks(self) -> bool:
        """Return True if the label of the selected row is narrower than the others (its buttons): the marks of its own slides."""
        return bool(self.marks_width) and len(self.buttons) * self.button_width != self.row_buttons_width

    @property
    def mark_bits(self) -> tuple[int, ...]:
        """Return the slides of the label of the marks (powers of two, their sum: any offset in the widest label), see `marks_width`."""
        return tuple(1 << n for n in range(self.label_width(0, False, False).bit_length())) if self.marks_width else ()


def tree_row_height(details: bool) -> int:
    """Return the height of a row of a tree (`details`: the rows with the second lines)."""
    return tokens().metric.row.details if details else tokens().metric.row


def row_art(item: ListItem) -> dict[str, str]:
    """
    Return the art of the list item of a row of the item: its icon (else its thumb) in the variant of the row, of a focused row
    (`FOCUSED_ICON`; `surface_art()`); '' none.
    """
    return surface_art(item.getArt('icon') or item.getArt('thumb') or '')


def tree_vars(*, list_id: int, left: int, top: int, width: int, height: int, multi: bool = False, own_nodes: bool = False,
              details: bool = False, buttons: Sequence[str] = (), button_id: int = 0, buttons_in_rows: bool = False,
              onright: NavTarget = 0, button_onright: NavTarget = 0, onleft: NavTarget = 0, onup: NavTarget = 0, ondown: NavTarget = 0,
              memory: str = '', filter_id: int = 0, marks: bool = False, separators: bool = False, group_names: str = '',
              group_align: str = '', flat: bool = False, tristate: bool = False, check_look: str = '', summary: str = 'counts',
              indent_scale: float = 1, icons: bool = True, expanders: bool = True) -> TreeVars:
    """
    Return the template vars of a tree (`const.dialog.tree`): the list cut to whole rows, `own_nodes` - the rows have
    their own states (else a choice of leaves: the check button first by `const.dialog.tree.check`), `details` - the rows
    with the second lines; `button_id`: the group of the buttons, the buttons after it (`buttons_in_rows`: drawn by the
    selected row, see `TreeVars.buttons_in_rows`); the navigation targets: control IDs or widget references (`NavTarget`); `onright`: right out of the tree
    (from the list, with the buttons from the last one; none: no move, the list stays), `button_onright` another one from the last button;
    `memory`: the name of the memory of the partial states of the nodes (multi, `TREE_CONFIG`), '' - none; `filter_id`:
    the filter field above the list (its clear button the next ID; `TreeView.filter`), 0 - none; `marks`: the marks of
    the rows (`TreeView(marks=...)`) in their own label after the text (the symbol font if Kodi has it); `separators`: the separators
    of the groups of the rows, `group_names` their names (shown, hidden; '' the style `group.names`: a band of their labels over a row),
    `group_align` where a label breaks the line of its separator (`GROUP_ALIGNS`; '' the style `group.align`);
    `flat`: one level only (a list as a tree: no indent, no nodes - the drop-down list of a combo box); `tristate`: a leaf has a third
    value (multi); `check_look`: the look of the state of a leaf (`TreeVars.check_look`: in the check column, no check button); `summary`:
    the counter of a node of tristate leaves (`DecisionSlots.summary`); `indent_scale`: the indent of a level, this part of `space.indent`;
    `icons`: the place of the icon of a row before its label (False: none); `expanders`: the expander of a node before it (False: none).
    """
    cfg = const.dialog.tree
    if tristate and not multi:
        raise ValueError('A tristate tree is a multiselect')
    if multi and not own_nodes and cfg.check == 'button' and 'check' not in buttons and not check_look:
        buttons = ('check', *buttons)
    if buttons and not button_id:
        raise ValueError('The buttons of a tree need the ID of their group (button_id)')
    from .gui import group_alignment, group_band
    group_head = group_band(separators, group_names)
    row_height = tree_row_height(details) + group_head
    count_width = 110 if multi else 0
    if multi and memory and cfg.count_remembered:
        from .skinfonts import text_metrics
        width_of, _ = text_metrics('small')
        count_width += round(width_of(COUNT_MEMORY.format(count=999)))
    decisions = None
    if tristate or (multi and summary not in ('counts', 'changed')):  # the counter of both decisions (two values: the marks of the selected ones)
        from math import ceil
        from .gui import toggle_vars
        from .skinfonts import text_metrics
        width_of, _ = text_metrics('small')
        if summary not in SUMMARIES:
            raise ValueError(f'Unknown summary of a node of a tree: {summary!r} ({", ".join(SUMMARIES)})')
        decisions = DecisionSlots(icon=toggle_vars(True).icon, digits=ceil(width_of('99')), gap=tokens().space.s, summary=cast(TreeSummary, summary))
        count_width = decisions.width if summary != 'counts' else max(count_width, decisions.width)
    marks_width = marks_gap = 0
    if marks:
        from math import ceil
        from .skinfonts import symbol, text_metrics
        text_width, _ = text_metrics('normal')
        symbol_width, _ = text_metrics(MARKS_STYLE)
        marks_width, marks_gap = ceil(symbol_width(f'{symbol("square", MARKS_STYLE)} {symbol("up", MARKS_STYLE)}')), round(text_width(MARKS_GAP))
    return TreeVars(list_id=list_id, left=left, top=top, width=width, height=max(row_height, height - height % row_height),
                    row_height=row_height, details=details, max_depth=1 if flat else max(1, cfg.max_depth), indent=round(tokens().space.indent * indent_scale),
                    multi=multi, icons=icons, expanders=expanders,
                    own_nodes=own_nodes, check_icon=multi and (cfg.check == 'icon' or bool(check_look)) and 'check' not in buttons,
                    count_width=count_width, memory=memory if multi else '',
                    marks_width=marks_width, marks_gap=marks_gap,
                    buttons=tuple(ButtonVars(button_id + 1 + n, ROW_BUTTONS[name]) for n, name in enumerate(buttons)), button_width=tokens().metric.row,
                    buttons_id=button_id, buttons_in_rows=buttons_in_rows,
                    onright=button_id + 1 if buttons else onright, button_onright=button_onright or onright,
                    onleft=onleft, onup=onup, ondown=ondown, filter_id=filter_id,
                    filter_hint=L(30213, 'Filter: a part of a name') if filter_id else '', separators=separators,
                    group_names=bool(group_head), group_head=group_head, group_align=group_alignment(group_align) if separators else 'left',
                    flat=flat, tristate=tristate, check_look=check_look, decisions=decisions)


def tree_memory(name: str) -> dict[str, list[str]]:
    """Return the memory of the partial states of the nodes of the tree `name` (`tree_vars(memory=...)`)."""
    from ..ff.config import config
    memory = config.get(f'{TREE_CONFIG}/{name}/memory')
    return memory if isinstance(memory, dict) else {}


def set_tree_memory(name: str, memory: dict[str, list[str]]) -> None:
    """Write the memory of the partial states of the nodes of the tree `name` (empty: removed)."""
    from ..ff.config import config
    config.set(f'{TREE_CONFIG}/{name}/memory', memory, default={})


@frozen
class TreeViewState:
    """The view of a tree (`TREE_VIEW_PROPERTY`): its expanded nodes and its selected row by their keys (`TreeModel.keys`)."""

    #: The keys of the expanded nodes.
    expanded: tuple[str, ...] = ()
    #: The key of the selected row ('' - none).
    selected: str = ''

    @classmethod
    def read(cls, name: str) -> TreeViewState | None:
        """Return the view of the tree `name`, None if none (not shown since the start of Kodi)."""
        import json
        from ..ff.control import get_window_property
        if not (text := get_window_property(TREE_VIEW_PROPERTY.format(name=name))):
            return None
        data = json.loads(text)
        return cls(expanded=tuple(data.get('expanded', ())), selected=data.get('selected', ''))

    def text(self) -> str:
        """Return the view as the text of its property."""
        import json
        return json.dumps({'expanded': list(self.expanded), 'selected': self.selected}, ensure_ascii=False)


class TreeView:
    """
    A tree in a list of a window (the window gives it the events of the list and of the buttons): expand / collapse, check
    (multi), the node actions, the context menu of a row, left to the parent, the buttons of the selected row
    (`ROW_BUTTONS`; up / down there move the list, the focus stays on the button).
    """

    #: The window of the tree, kept weakly (the window keeps the tree, see `AbstractWindow`).
    win: WindowRef[AbstractWindow] = WindowRef()

    def __init__(self, win: AbstractWindow, model: TreeModel, *, tree: TreeVars, multi: bool = False, select_nodes: bool = True,
                 left_to_parent: bool = False, out_left: int = 0,
                 on_change: Callable[[], None] | None = None,
                 on_current: Callable[[int], None] | None = None,
                 on_check: Callable[[Sequence[FFItem]], None] | None = None,
                 on_move: Callable[[FFItem], None] | None = None,
                 extra_menu: Callable[[int], list[ContextMenuItem]] | None = None,
                 dimmed: Callable[[FFItem], bool] | None = None,
                 marks: Callable[[FFItem], RowMarks] | None = None) -> None:
        """
        The tree of the window: `out_left` - a left from a collapsed root (`left_to_parent`), the callbacks (a bound method
        kept weakly, see `weak_callback()`): the states of the rows changed (`on_change`), another row selected (`on_current`,
        its position; the tree follows the list: `track()`), the items checked / unchecked
        (`on_check`), an item moved (`on_move`), more entries of the context menu of a row (`extra_menu`), an item dimmed
        too (`dimmed`, e.g. an add-on disabled in Kodi; else by the model), the marks of an item after its label (`marks`).
        """
        self.win = win
        self.tree: TreeVars = tree
        #: The memory as written last (`tree.memory`).
        self._memory: dict[str, list[str]] = {}
        #: The view as written last, the key of the selected row of the read one (`TREE_VIEW_PROPERTY`).
        self._view: str = ''
        self._view_selected: str = ''
        #: The selected row before the action Kodi handles first (a digit of a remote is `JumpSMS<n>`: the list jumps to a
        #: letter before the window gets it), -1: none yet (`track()`).
        self._pos: int = -1
        self.model = model
        self.multi: bool = multi
        self.left_to_parent: bool = left_to_parent
        self.out_left: int = out_left
        self.on_change: Callable[[], None] | None = weak_callback(on_change)
        self.on_current: Callable[[int], None] | None = weak_callback(on_current)
        self.on_check: Callable[[Sequence[FFItem]], None] | None = weak_callback(on_check)
        self.on_move: Callable[[FFItem], None] | None = weak_callback(on_move)
        self.extra_menu: Callable[[int], list[ContextMenuItem]] | None = weak_callback(extra_menu)
        self.dimmed: Callable[[FFItem], bool] | None = weak_callback(dimmed)
        self.marks: Callable[[FFItem], RowMarks] | None = weak_callback(marks)
        #: The symbols of the marks by their names (chosen once, `marks_text()`).
        self._symbols: dict[str, str] = {}
        #: The separators above the shown rows (`separators()`, set by `show_rows()`).
        self._separators: list[str | None] = []
        #: The width of the text of a row (the marks in their own label after it: the template has it and the font of the
        #: text is measured, `marks_properties()`), None - the marks in the text.
        self._text_width: Callable[[str], float] | None = None
        if marks is not None and tree.marks_width:
            from .skinfonts import style_font, text_metrics
            if style_font('normal') is not None:
                self._text_width = text_metrics('normal')[0]
        #: A whole node may be checked (the multiselect; not in a tristate tree: a node of tristate leaves has no state of its own yet).
        self.select_nodes: bool = multi and select_nodes and not tree.tristate
        nodes = (self.select_nodes or tree.tristate) and any(row.node for row in self.model.rows)
        #: The enabled keys (keymap names) by their operations: `toggle` in the multiselect with nodes to select (a tristate tree: its branch
        #: cleared), no node moves in a flat tree.
        self.keys: dict[TreeKey, tuple[str, ...]] = {key: tuple(names) for key, names in const.dialog.tree.keys.items()
                                                     if (key != 'toggle' or nodes) and (key != 'filter' or tree.filter_id)
                                                     and (key not in ('up', 'down') or not tree.flat)}
        #: The operations of the keys by the Kodi action IDs and by the digits.
        self._key_actions: dict[int, TreeKey] = {NODE_ACTIONS[name].id: key for key, names in self.keys.items()
                                                 for name in names if name in NODE_ACTIONS and not NODE_ACTIONS[name].button}
        self._key_buttons: dict[int, TreeKey] = {NODE_ACTIONS[name].button: key for key, names in self.keys.items()
                                                 for name in names if name in NODE_ACTIONS and NODE_ACTIONS[name].button}
        self._key_digits: dict[int, TreeKey] = {int(name[len('Number'):]): key for key, names in self.keys.items()
                                                for name in names if name.startswith('Number') and name[len('Number'):].isdigit()}
        #: The buttons by their IDs.
        self.buttons: dict[int, RowButton] = {slot.id: slot.button for slot in tree.buttons}
        #: The check button checks a whole node (the hint of the node actions tells it).
        self.branch_button: bool = nodes and any(button.name == 'check' for button in self.buttons.values())
        #: The last focused control (0: none yet).
        self._focused: int = 0
        #: The list has just got the focus from another control: Kodi moves the focus before the window gets the action.
        self._entered: bool = False

    @property
    def model(self) -> TreeModel:
        """Return the model of the tree."""
        return self._model

    @model.setter
    def model(self, model: TreeModel) -> None:
        """
        Set the model of the tree (also a new one, read again): its leaves of a third value as the tree has them (`tree.tristate`), with a
        memory (`tree.memory`) its memory from the configuration.
        """
        model.tristate = self.tree.tristate
        self._model: TreeModel = model
        if self.tree.memory:
            self._memory = tree_memory(self.tree.memory)
            model.load_memory(self._memory)
            self.save_memory()
            if (view := TreeViewState.read(self.tree.memory)) is not None:
                expanded = set(view.expanded)
                model.expanded = {key for key, path in model.keys.items() if path in expanded}
                model.rows = model.flatten()
                self._view_selected = view.selected

    def start_row(self) -> int:
        """
        Return the row to show first: a tree with a memory - the selected one of the kept view, else its nearest shown
        ancestor; a tree without one - the first selected row (a choice: its preselection); else the first one.
        """
        if not self.tree.memory:
            return next((n for n, row in enumerate(self.model.rows) if id(row.item) in self.model.selected), 0)
        rows = {self.model.keys[id(row.item)]: n for n, row in enumerate(self.model.rows)}
        key = self._view_selected
        while key:
            if (pos := rows.get(key)) is not None:
                return pos
            key = key.rpartition('/')[0]
        return 0

    def track(self, pos: int | None = None) -> None:
        """
        The row `pos` (None: the selected one) is selected now: remember it (the keys of the tree start from it) and keep the
        view of the tree with a memory (`TREE_VIEW_PROPERTY`): its expanded nodes, the row; another row: `on_current`.
        """
        if pos is None:
            pos = self.position()
        moved, self._pos = pos != self._pos, pos
        if moved and self.on_current:
            self.on_current(pos)
        if not self.tree.memory:
            return
        model = self.model
        selected = model.keys[id(model.rows[pos].item)] if 0 <= pos < len(model.rows) else ''
        text = TreeViewState(expanded=tuple(sorted(model.keys[key] for key in model.expanded if key in model.keys)), selected=selected).text()
        if text != self._view:
            from ..ff.control import window
            self._view = text
            window().setProperty(TREE_VIEW_PROPERTY.format(name=self.tree.memory), text)

    def save_memory(self) -> None:
        """Write the memory of the model if it changed (`tree.memory`)."""
        if self.tree.memory and self.model.memory is not None and self.model.memory != self._memory:
            self._memory = {key: list(keys) for key, keys in self.model.memory.items()}
            set_tree_memory(self.tree.memory, self._memory)

    def owns(self, control_id: int) -> bool:
        """Return True if the control is of the tree (the list, a button, the filter)."""
        return self.in_list(control_id) or (self.tree.filter_id > 0 and control_id in (self.tree.filter_id, self.tree.filter_id + 1))

    def in_list(self, control_id: int) -> bool:
        """Return True if the control is the list or a button of its row (the keys of the tree work there, not in the filter)."""
        return control_id == self.tree.list_id or control_id in self.buttons

    def list_control(self) -> ControlList:
        """Return the list of rows."""
        return cast('ControlList', self.win.getControl(self.tree.list_id))

    def position(self) -> int:
        """Return the selected row (-1: none)."""
        return self.list_control().getSelectedPosition()

    def show_rows(self, pos: int) -> None:
        """
        Show the rows again (after expand / collapse, the filter) with the row `pos` selected (new list items, see the module), the
        separators of the groups of the shown rows (`TreeVars.separators`).
        """
        from xbmcgui import ListItem
        self._separators = self.separators()
        items: list[ListItem] = []
        for n, row in enumerate(self.model.rows):
            item = ListItem(self.row_label(n), row.item.getLabel2())
            if art := {name: image for name, image in row_art(row.item).items() if image}:
                item.setArt(art)
            item.setProperties(self.row_properties(n))
            items.append(item)
        self.win.add_items(self.tree.list_id, items)
        del items
        if self.model.rows:
            self.list_control().selectItem(pos := max(0, min(pos, len(self.model.rows) - 1)))
            self.track(pos)
        if self.on_change:
            self.on_change()

    def separators(self) -> list[str | None]:
        """
        Return the separators above the shown rows (`views.group_separators()`, none without `TreeVars.separators`): the groups of
        the items among their siblings (their property `group`), an explicit one of an item (`separator.above`, `separator.label`).
        """
        from .widgets.views import SEPARATOR_LABEL, SEPARATOR_PROPERTY, GroupRow, group_separators
        if not self.tree.separators:
            return []
        rows = [GroupRow(group=row.item.getProperty('group'), level=row.level,
                         forced=row.item.getProperty(SEPARATOR_LABEL) if row.item.getProperty(SEPARATOR_PROPERTY) == 'true' else None)
                for row in self.model.rows]
        return group_separators(rows, named=self.tree.group_names)

    def separator_properties(self, pos: int) -> dict[str, str]:
        """Return the properties of the separator above the row (`views.separator_properties()`; none without separators)."""
        from .widgets.views import separator_properties
        if pos >= len(self._separators):
            return {}
        return separator_properties(self._separators[pos], width=self.tree.width, align=self.tree.group_align)

    def row_label(self, pos: int, focused: bool = False) -> str:
        """
        Return the label of the row in the color of its state (a choice of leaves: none - the text color, partial, all; tristate leaves:
        the accent with a decision - must or must not, a node: under it; own states: no color, an unchecked row is dimmed), its marks after it if they have no label of their own (`marks_properties()`);
        in the text: `$INFO` in the text color of an item fails without the focus. `focused`: of a focused row (`mark_colors()`).
        """
        colors = mark_colors(focused)
        row = self.model.rows[pos]
        label = row.item.getLabel()
        if span := match_span(label, self.model.filter):  # the matched text of the filter
            label = f'{label[:span[0]]}[COLOR {colors.match}]{label[span[0]:span[1]]}[/COLOR]{label[span[1]:]}'
        if self._text_width is None and (marks := self.marks_text(row.item, focused)):
            label += f'{MARKS_GAP}{marks}'
        if self.model.tristate or self.tree.decisions:  # a decision in it (must or must not, a node: under it) - the accent, else none
            return f'[COLOR {colors.accent}]{label}[/COLOR]' if self.model.decided(row.item) else label
        if self.model.own_nodes or (check := self.model.check(row.item)) == 'none':
            return label
        return f'[COLOR {colors.accent if check == "all" else colors.partial}]{label}[/COLOR]'

    def row_properties(self, pos: int) -> dict[str, str]:
        """Return the properties of the row (the skin shows them)."""
        row = self.model.rows[pos]
        count, partial = '', False
        decided: dict[str, str] = {}
        if row.node and self.multi:
            selected, total = self.counter(row.item)
            count, partial = f'{selected} / {total}', self.model.own_nodes and selected < total
            if self.tree.decisions:  # tristate leaves: the selected (must) and the rejected (must not), no text of the counter
                count, decided = '', {'tree.count.yes': str(selected), 'tree.count.no': str(self.counter(row.item, self.model.rejected)[0])}
            elif const.dialog.tree.count_remembered and self.model.restorable(row.item):
                remembered = COUNT_MEMORY.format(count=self.counter(row.item, self.model.remembered(row.item))[0])
                count += f'[COLOR {tokens().color.accent.partial}]{remembered}[/COLOR]'
        return {
            'tree.level': str(min(row.level, self.tree.max_depth - 1)),
            'tree.node': 'true' if row.node else '',
            'tree.expanded': 'true' if self.model.is_expanded(row.item) else '',
            'tree.check': self.model.check(row.item),
            **({'tree.state': CHECK_STATES[self.model.value(row.item)]} if self.tree.check_look and not row.node else {}),
            'tree.action': 'true' if id(row.item) in self.model.actions else '',
            'tree.dim': 'true' if self.model.dimmed(row.item) or (self.dimmed is not None and self.dimmed(row.item)) else '',
            'tree.count': count,
            'tree.count.partial': 'true' if partial else '',
            **decided,
            **{f'tree.button.{button.name}': 'true' if button.applies(self, pos) else '' for button in self.buttons.values()},
            **self.marks_properties(pos),
            **self.separator_properties(pos),
            **({'tree.label.focused': self.row_label(pos, True)} if self.tree.focused_marks else {}),
        }

    def marks_text(self, item: FFItem, focused: bool = False) -> str:
        """
        Return the marks of the row after its text (`RowMarks`): a square of its own color, up (its own priority), its symbol (bold; the
        last two in the accent colour; `focused`: of a focused row, `mark_colors()`), the symbols its font draws (`skinfonts.symbol()`,
        chosen once: of their label, else of the text), '' - none.
        """
        if self.marks is None or not ((marks := self.marks(item)).color or marks.up or marks.symbol):
            return ''
        accent = mark_colors(focused).accent
        return ' '.join(text for text in (marks.color and f'[COLOR {marks.color}]{self.symbol("square")}[/COLOR]',
                                          marks.up and f'[COLOR {accent}]{self.symbol("up")}[/COLOR]',
                                          marks.symbol and f'[COLOR {accent}][B]{self.symbol(marks.symbol)}[/B][/COLOR]') if text)

    def symbol(self, name: str) -> str:
        """Return a symbol of the marks (the one its font draws: of their label, else of the text; chosen once)."""
        if (text := self._symbols.get(name)) is None:
            from .skinfonts import symbol
            text = self._symbols[name] = symbol(name, 'normal' if self._text_width is None else MARKS_STYLE)
        return text

    def marks_properties(self, pos: int) -> dict[str, str]:
        """
        Return the properties of the label of the marks of the row (`TreeVars.marks_width`): its text (`tree.marks`) and its
        slides (`tree.marks.<bit>`, `TreeVars.mark_bits`): right after the text, a longer text up to the end of its label
        (narrower by the marks: it scrolls without them), the slides of the row selected (`tree.marks.selected.<bit>`: its label up
        to its buttons, `TreeVars.selected_marks`), its text of a focused row (`tree.marks.focused`, `TreeVars.focused_marks`); none if
        the marks are in the text.
        """
        if self._text_width is None:
            return {}
        row = self.model.rows[pos]
        marks = self.marks_text(row.item)

        def slides(prefix: str, selected: bool) -> dict[str, str]:
            """Return the slides of the marks in the label of the row (`selected`: of the selected row)."""
            offset = 0
            if marks:
                room = self.tree.label_width(min(row.level, self.tree.max_depth - 1), row.node, selected) - self.tree.marks_gap - self.tree.marks_width
                offset = round(min(self._text_width(row.item.getLabel()), room)) + self.tree.marks_gap
            return {f'{prefix}.{bit}': 'true' if offset & bit else '' for bit in self.tree.mark_bits}

        focused = {'tree.marks.focused': self.marks_text(row.item, True)} if self.tree.focused_marks else {}
        selected = slides('tree.marks.selected', True) if self.tree.selected_marks else {}
        return {'tree.marks': marks, **focused, **slides('tree.marks', not self.tree.selected_marks), **selected}

    def counter(self, item: FFItem, selected: set[int] | None = None) -> tuple[int, int]:
        """Return the counter of the node: the selected of all (own nodes: the visible entries); `selected`: of another selection."""
        return self.model.visible_count(item, selected) if self.model.own_nodes else self.model.count(item, selected)

    def step_label(self, pos: int, step: TreeStep) -> str:
        """Return the label of the step of the row: select, unselect, restore (the remembered of all, as the counter)."""
        if step == 'restore':
            item = self.model.rows[pos].item
            selected, total = self.counter(item, self.model.remembered(item))
            return L(30766, 'Restore ({selected} of {total})').format(selected=selected, total=total)
        return L(30184, 'Select') if step == 'all' else L(30185, 'Unselect')

    def check_step(self, pos: int) -> TreeStep:
        """Return what the check button does with the row: a node of a choice of leaves - its next step, else the row itself."""
        row = self.model.rows[pos]
        if row.node and not self.model.own_nodes:
            return self.model.next_step(row.item)
        return 'none' if self.model.check(row.item) == 'all' else 'all'

    def update_row(self, pos: int) -> None:
        """Set the label and the properties of the shown row again (its state changed)."""
        list_item = self.list_control().getListItem(pos)
        list_item.setLabel(self.row_label(pos))
        list_item.setProperties(self.row_properties(pos))

    def show_states(self) -> None:
        """Show the states of all rows (a node, its shown items and its ancestors changed)."""
        for i in range(len(self.model.rows)):
            self.update_row(i)
        if self.on_change:
            self.on_change()

    def _changed(self, before: set[int], rejected: set[int] | None = None) -> None:
        """
        The selection changed from `before` (the rejected leaves of a tristate tree from `rejected`, None: they changed with it): show
        the states, tell the items checked / unchecked (a tristate leaf: its value changed, `TreeModel.value()`), write the memory.
        """
        self.show_states()
        if self.on_check and (changed := before ^ self.model.selected | (set() if rejected is None else rejected ^ self.model.rejected)):
            self.on_check([it for it in self.model.items() if id(it) in changed])
        self.save_memory()

    def set_selected(self, selected: set[int]) -> None:
        """Set the selection as the owner of the tree has it (no `on_check`), show it, write the memory."""
        if selected != self.model.selected:
            self.model.set_selected(selected)
            self.show_states()
        self.save_memory()

    def restore(self, pos: int) -> None:
        """Set the remembered state of the branch of the row."""
        before = set(self.model.selected)
        self.model.restore_node(pos)
        self._changed(before)

    def reset(self, pos: int) -> None:
        """Set the default selection of the branch of the row (a tristate tree: none rejected)."""
        before, rejected = set(self.model.selected), set(self.model.rejected)
        self.model.reset_node(pos)
        self._changed(before, rejected)

    def set_value(self, pos: int, value: bool | None) -> None:
        """Set the value of the item of the row (a tristate leaf: must, must not, any)."""
        before, rejected = set(self.model.selected), set(self.model.rejected)
        self.model.set_value(self.model.rows[pos].item, value)
        self._changed(before, rejected)

    def toggle(self, pos: int) -> None:
        """Check / uncheck the branch of the row (a node action)."""
        before = set(self.model.selected)
        self.model.toggle_node(pos)
        self._changed(before)

    def select(self, pos: int, selected: bool) -> None:
        """Check or uncheck the branch of the row."""
        before = set(self.model.selected)
        self.model.select_node(pos, selected)
        self._changed(before)

    def can_check(self, pos: int) -> bool:
        """Return True if the row can be checked by its check button: a leaf (no action), a node of `own_nodes` or of `select_nodes`."""
        row = self.model.rows[pos]
        return id(row.item) not in self.model.actions and (not row.node or self.model.own_nodes or self.select_nodes)

    def check(self, pos: int) -> None:
        """Check / uncheck the row: itself (a leaf, a node of `own_nodes`), else the leaves of the node."""
        if self.model.rows[pos].node and not self.model.own_nodes:
            self.toggle(pos)
            return
        before, rejected = set(self.model.selected), set(self.model.rejected)
        self.model.toggle_selected(pos)
        self._changed(before, rejected)

    def toggle_expanded(self, pos: int) -> None:
        """Expand / collapse the node of the row."""
        self.model.toggle_expanded(pos)
        self.show_rows(pos)

    def move(self, pos: int, delta: int) -> None:
        """Move the item of the row among its siblings (the next row: two rows change in place), select it again."""
        item = self.model.rows[pos].item
        rows = len(self.model.rows)
        if (new := self.model.move(pos, delta)) is None:
            return
        if abs(new - pos) == 1 and len(self.model.rows) == rows and not any(self.model.is_expanded(self.model.rows[p].item) for p in (pos, new)):
            for p in (pos, new):
                row, list_item = self.model.rows[p], self.list_control().getListItem(p)
                list_item.setLabel(self.row_label(p))
                list_item.setArt(row_art(row.item))
            self.show_states()  # the buttons of the neighbors too
            self.list_control().selectItem(new)
            self.track(new)
        else:
            self.show_rows(new)
        if self.on_move:
            self.on_move(item)

    def remove(self, pos: int) -> None:
        """Remove the item of the row (the owner of the tree hears it from `row_button_clicked`), select the row in its place."""
        self.model.remove(pos)
        self.show_rows(min(pos, len(self.model.rows) - 1))

    def row_menu(self, pos: int) -> list[ContextMenuItem]:
        """
        Return the context menu of the row, only what changes it: check, uncheck, restore, default (multi; a tristate tree: the other values of a
        leaf, the reset of a node), more, the buttons, expand, collapse, filter.
        """
        row = self.model.rows[pos]
        menu: list[ContextMenuItem] = []
        if self.model.tristate:
            if not row.node:
                menu.extend((label, partial(self.set_value, pos, value)) for value, label in TRISTATE_LABELS.items() if value is not self.model.value(row.item))
            elif not self.model.is_default(row.item):
                menu.append((L(30926, 'Reset'), partial(self.reset, pos)))
        elif self.multi and (self.select_nodes or not row.node):
            selected, total = self.model.branch_count(row.item)
            if selected < total:
                menu.append((L(30184, 'Select'), partial(self.select, pos, True)))
            if selected:
                menu.append((L(30185, 'Unselect'), partial(self.select, pos, False)))
            if row.node and self.model.restorable(row.item):
                menu.append((self.step_label(pos, 'restore'), partial(self.restore, pos)))
            if not self.model.is_default(row.item):
                menu.append((L(30767, 'Default selection'), partial(self.reset, pos)))
        if self.extra_menu:  # what the owner of the tree sets on the row, right after the selection
            menu.extend(self.extra_menu(pos))
        menu.extend((button.label(self, pos), partial(button.action, self, pos))
                    for button in self.buttons.values() if button.name != 'check' and button.applies(self, pos))
        if children(row.item):
            if self.model.is_expanded(row.item):
                menu.append((L(30187, 'Collapse'), partial(self.toggle_expanded, pos)))
            else:
                menu.append((L(30188, 'Expand'), partial(self.toggle_expanded, pos)))
        if self.tree.filter_id:
            menu.append((L(30214, 'Filter'), self.focus_filter))
        return menu

    # --- the filter ---

    def focus_filter(self) -> None:
        """Show the filter field (it is shown while it has the focus or a text) and focus it."""
        self.win.setFocusId(self.tree.filter_id)

    def filter(self, text: str) -> None:
        """
        Filter the rows by the text (`TreeModel.set_filter()`), the selected item stays selected if it is shown (else the
        first matched row); the end of the filter shows the selected item (its ancestors expanded).
        """
        item = self.model.rows[pos].item if 0 <= (pos := self._pos) < len(self.model.rows) else None
        self.model.set_filter(text)
        if not self.model.filter and item is not None:
            self.model.expanded |= {id(it) for it in self.model.ancestors(item)}
            self.model.rows = self.model.flatten()
        rows = [row.item for row in self.model.rows]
        if item is not None and any(it is item for it in rows):
            new = next(n for n, it in enumerate(rows) if it is item)
        else:
            new = next((n for n, it in enumerate(rows) if match_span(it.getLabel(), self.model.filter)), 0)
        self.show_rows(new)

    def filter_help(self, control_id: int) -> str:
        """Return the help of the filter field or of its clear button ('' for another control)."""
        if not self.tree.filter_id or control_id not in (self.tree.filter_id, self.tree.filter_id + 1):
            return ''
        if control_id == self.tree.filter_id:
            return L(30215, 'Filter: a part of a name (from {n} characters, no diacritics), down: the list.').format(n=const.dialog.tree.filter.min_chars)
        return L(30216, 'Clear the filter.')

    def help_of(self, control_id: int) -> str:
        """Return the label of a button for the selected row ('' for the list)."""
        if (button := self.buttons.get(control_id)) is None or (pos := self.position()) < 0:
            return ''
        return button.label(self, pos)

    # --- events (of the controls of the tree) ---

    def on_key(self, key: TreeKey, pos: int) -> None:
        """Do the operation of a key on the row: check / uncheck its branch (a tristate tree: reset it), the previous / next node."""
        if key == 'toggle':
            if self.model.tristate:
                self.reset(pos)
            else:
                self.toggle(pos)
        elif key == 'filter':
            self.focus_filter()
        else:  # no other node: the row again (a remote digit may have moved the list to a letter)
            new = self.model.sibling_node(pos, -1 if key == 'up' else 1)
            self.list_control().selectItem(pos if new is None else new)
            self.track(pos if new is None else new)

    def on_number_button(self, button: int) -> bool:
        """
        A digit of the keys (`Number<n>`) on the list or a button: its operation on the row selected before (`track()`: a
        digit of a remote has moved the list to a letter already, the operation selects its row again).
        """
        if (key := self._key_digits.get(button)) is None or not self.in_list(self.win.focused_id()):
            return False
        if (pos := self._pos if 0 <= self._pos < len(self.model.rows) else self.position()) >= 0:
            self.on_key(key, pos)
        return True

    def on_focus(self, control_id: int) -> None:
        """A control got the focus: remember if the list got it from another control (by the action that comes next), its row."""
        self._entered = control_id == self.tree.list_id and self._focused not in (0, self.tree.list_id)
        self._focused = control_id
        if control_id == self.tree.list_id:
            self.track()

    def on_action(self, action: Action) -> bool | None:
        """
        The keys of the tree; the context menu of a row; left in the list (`left_to_parent`): collapse, the parent, out of the
        list. Kodi handles the action first: a left that has just moved the focus to the list (from a button) is not a left
        in the list.
        """
        entered, self._entered = self._entered, False
        focused = self.win.focused_id()
        if not self.in_list(focused):
            return None  # the filter: the edit control
        self.track()  # Kodi has moved the list already
        aid = action.getId()
        key = self._key_actions.get(aid) if aid != ACTION_NONE else self._key_buttons.get(action.getButtonCode())  # no action: a key by its code
        if key is not None:
            if (pos := self.position()) >= 0:
                self.on_key(key, pos)
            return True
        if action.getId() in MENU_ACTIONS:
            if (pos := self.position()) >= 0 and (menu := self.row_menu(pos)):
                from .context import ContextMenuDialog
                ContextMenuDialog(menu=menu).doModal()
            return True
        if self.left_to_parent and action.getId() == ACTION_MOVE_LEFT and focused == self.tree.list_id and not entered:
            if (pos := self.position()) < 0:
                return None
            new = self.model.left(pos) if const.dialog.tree.left_to_parent else None  # off: out of the tree at once
            if new is None:
                if self.out_left:
                    self.win.setFocusId(self.out_left)
            elif len(self.model.rows) != self.list_control().size():
                self.show_rows(new)  # collapsed
            else:
                self.list_control().selectItem(new)
                self.track(new)
            return True
        return None

    def on_click(self, control_id: int) -> FFItem | None:
        """
        A row: a node expands / collapses, a leaf toggles (multi) or is returned (single, an action); a button acts on the selected row;
        the filter field: its text changed (Kodi clicks it at every change), its clear button: no text.
        """
        if self.tree.filter_id and control_id in (self.tree.filter_id, self.tree.filter_id + 1):
            edit = cast('ControlEdit', self.win.getControl(self.tree.filter_id))
            if control_id == self.tree.filter_id:
                self.filter(edit.getText())
            else:  # cleared: `setText()` reaches Kodi later (a message), `getText()` has the old text still
                edit.setText('')
                self.win.setFocusId(self.tree.filter_id)
                self.filter('')
            return None
        if (pos := self.position()) < 0:
            return None
        if (button := self.buttons.get(control_id)) is not None:
            if button.applies(self, pos):
                button.action(self, pos)
            return None
        row = self.model.rows[pos]
        if row.node:
            self.toggle_expanded(pos)
        elif not self.multi or id(row.item) in self.model.actions:
            return row.item
        else:
            self.check(pos)
        return None


class TreeSelectDialog(BaseDialog[TreeResult]):
    """The window of a tree select (see `tree_select()`): the tree is its widget `tree` (`tree_view`), OK (multi), Cancel."""

    @classmethod
    def xml_vars(cls, *, multi: bool = False, left_to_parent: bool = False, details: bool = False, select_nodes: bool = True,
                 **kwargs: Any) -> dict[str, Any]:
        """The structure of the window: the mode, the tree (its rows by their height: whole rows under the header)."""
        return {'MULTI': multi, 'DETAILS': details, 'SELECT_NODES': select_nodes, 'LEFT_TO_PARENT': left_to_parent, 'WIDTH': WIDTH,
                'HEIGHT': HEIGHT, 'BUTTON_WIDTH': tokens().metric.button.width, 'TREE_TOP': TREE_TOP,
                'TREE_ROWS': (HEIGHT - TREE_TOP - 30) // tree_row_height(details)}

    def __init__(self, *args, heading: str, roots: Sequence[FFItem], multi: bool = False, preselect: Sequence[FFItem] = (),
                 left_to_parent: bool = False, select_nodes: bool = True, details: bool = False, **kwargs) -> None:
        """Instance initialization, there are no XML controls yet (see `on_init()`): the model of the tree."""
        super().__init__(*args)
        self.heading: str = heading
        self.multi: bool = multi
        self.tree.set_model(TreeModel(roots, selected=preselect))
        if multi:  # only the multiselect has OK (no slot by name: a single select has no widget for it)
            self.find('ok').clicked.connect(self.accept)

    @property
    def tree(self) -> views.TreeView:
        """Return the widget of the tree."""
        return cast('views.TreeView', self.find('tree'))

    @property
    def view(self) -> TreeView:
        """Return the tree of the model."""
        view = self.tree.view
        assert view is not None
        return view

    @property
    def model(self) -> TreeModel:
        """Return the model of the tree."""
        return self.view.model

    def on_init(self) -> None:
        """Show the heading (the tree is the default control: shown from its first selected row, `TreeView.start_row()`)."""
        self.setProperty('heading', self.heading)

    def show_counter(self) -> None:
        """Show the number of the selected leaves (multiselect) and the hint of the node actions."""
        if self.multi:
            counter = L(32940, '{selected} of {total} selected').format(selected=len(self.model.selected), total=len(self.model.all_leaves()))
            hint = tree_keys_hint(self.view.keys, button=self.view.branch_button)
            self.setProperty('counter', ' · '.join(text for text in (counter, hint) if text))

    # --- slots ---

    def on_tree_changed(self) -> None:
        """The rows or their states changed: the counter."""
        self.show_counter()

    def on_tree_activated(self, item: FFItem) -> None:
        """A leaf of the single select is the result."""
        self.close(item)

    def accept(self) -> None:
        """OK: the checked leaves (multi)."""
        self.close(self.model.selected_leaves())

    def on_cancel_clicked(self) -> None:
        """Nothing selected."""
        self.close(None)


@overload
def tree_select(heading: str, roots: Sequence[FFItem], *, multi: Literal[False] = False, preselect: Sequence[FFItem] = (),
                left_to_parent: bool = False, select_nodes: bool = True, details: bool | None = None) -> FFItem | None: ...


@overload
def tree_select(heading: str, roots: Sequence[FFItem], *, multi: Literal[True], preselect: Sequence[FFItem] = (),
                left_to_parent: bool = False, select_nodes: bool = True, details: bool | None = None) -> list[FFItem] | None: ...


@overload
def tree_select(heading: str, roots: Sequence[FFItem], *, multi: bool, preselect: Sequence[FFItem] = (),
                left_to_parent: bool = False, select_nodes: bool = True, details: bool | None = None) -> TreeResult | None: ...


def tree_select(heading: str, roots: Sequence[FFItem], *, multi: bool = False, preselect: Sequence[FFItem] = (),
                left_to_parent: bool = False, select_nodes: bool = True, details: bool | None = None) -> TreeResult | None:
    """
    Show the tree select: return the selected leaf (single) or the checked leaves in the order of the tree (`multi`),
    None if canceled; `select_nodes`: a node action checks a whole node (multi); `details`: the rows with the second
    lines (`label2`, as `Dialog.select(useDetails=True)`), None: if an item has one. Out of Kodi (CLI) the leaves are asked
    by a plain select / multiselect, labeled by their path.
    """
    from .. import FAKE
    if details is None:
        details = any(item.getLabel2() for item in TreeModel(roots).items())
    if FAKE:
        return _plain_select(heading, roots, multi=multi, preselect=preselect, details=details)
    return TreeSelectDialog(heading=heading, roots=roots, multi=multi, preselect=preselect, left_to_parent=left_to_parent,
                            select_nodes=select_nodes, details=details).do_modal()


def _plain_select(heading: str, roots: Sequence[FFItem], *, multi: bool, preselect: Sequence[FFItem], details: bool = False) -> TreeResult | None:
    """
    Ask the leaves of the tree by a plain Kodi select / multiselect: the label of a leaf is its path, its second line
    (`details`) the second lines of the path.
    """
    from xbmcgui import Dialog, ListItem
    model = TreeModel(roots, selected=preselect)
    leaves = model.all_leaves()
    labels: list[str | ListItem] = []
    for leaf in leaves:
        path = (*reversed(list(model.ancestors(leaf))), leaf)
        label = ' / '.join(it.getLabel() for it in path)
        labels.append(ListItem(label, ' · '.join(text for it in path if (text := it.getLabel2())), offscreen=True) if details else label)
    if not multi:
        index = Dialog().select(heading, labels, useDetails=details)
        return None if index < 0 else leaves[index]
    chosen = Dialog().multiselect(heading, labels, preselect=[i for i, leaf in enumerate(leaves) if id(leaf) in model.selected], useDetails=details)
    return None if chosen is None else [leaves[i] for i in chosen]
