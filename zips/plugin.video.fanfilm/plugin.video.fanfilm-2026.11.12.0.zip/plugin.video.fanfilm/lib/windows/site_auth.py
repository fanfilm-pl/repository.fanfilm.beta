from __future__ import annotations
from typing import TYPE_CHECKING
from pathlib import Path

# from xbmcvfs import translatePath

from .base import BaseDialog, CANCEL_ACTIONS
from .style import tokens
from ..kolang import L
from ..ff.logs import fflog
from const import const
if TYPE_CHECKING:
    from xbmcgui import Action


class SiteAuthWindow(BaseDialog):
    """The authorization window: the link and its QR code, the code to enter, the progress; Open link, Cancel."""

    def __init__(self, *args,
                 code: str,
                 url: str = '',
                 progress: int | bool = 0,
                 icon: Path | str | None = None,
                 title: str | None = None,
                 qrcode: str | None = None,
                 qrcode_scale: int | None = None,
                 **kwargs) -> None:
        super().__init__(self, *args, **kwargs)
        self.progress_enabled: bool = progress is not False
        self.progress: int = progress or 0
        self.icon: str = str(icon or '')
        self.code: str = code
        self._remove_icon: bool = False
        self.url: str = url or ''
        self._is_inited: bool = False
        self._is_canceled: bool = False

        if not code:
            code = ''
        if icon is None and qrcode:
            self.icon = self.generate_qrcode(qrcode, scale=qrcode_scale)
            self._remove_icon = True
        code = f'[COLOR {tokens().color.code}]{code}[/COLOR]'
        if link := self.url:
            link = f'[COLOR {tokens().color.link}]{self.url}[/COLOR]'
        if title is None:
            title = L(30396, '[B]Authorize[/B]')
        self.setProperty('title', title)
        self.find('code').text = f'[B]{code}[/B]'  # type: ignore[attr-defined]
        self.find('link').text = link  # type: ignore[attr-defined]
        self.setProperty('link.open', L(30397, 'Open link') if link else '')
        self.setProperty('icon.path', str(self.icon or ''))
        self.setProperty('progress.enabled', 'enabled' if self.progress_enabled else '')

    def on_init(self) -> None:
        """The window is shown: the focus on Open link, the progress."""
        fflog('SiteAuthWindow.onInit()')
        self.setFocusId(self.find('open').id)
        self._is_inited = True
        self.update(self.progress)

    def on_action(self, action: Action) -> None:
        """Back / Esc cancels the authorization."""
        action_id = action.getId()
        fflog(f'SiteAuthWindow.onAction({action!r}): {action_id=}')
        if action_id in CANCEL_ACTIONS:
            self._is_canceled = True
            self.close()

    def on_cancel_clicked(self) -> None:
        """Cancel the authorization."""
        fflog('SiteAuthWindow: cancel')
        self._is_canceled = True
        self.close()

    def on_open_clicked(self) -> None:
        """Open the link in a browser."""
        from ..ff.kotools import launch_browser
        fflog('SiteAuthWindow: open link')
        launch_browser(self.url)

    def generate_qrcode(self, code: str, *, scale: int | None = None) -> str:
        """Generate QR code image and return its path."""
        import segno
        from ..ff.control import dataPath as DATA_PATH
        code_hash = f'{hash(code):08x}'
        icon = Path(DATA_PATH) / f'tmp/gui-qrcode.{code_hash}.png'
        icon.parent.mkdir(parents=True, exist_ok=True)
        qrcode = segno.make(code)
        qrcode.save(str(icon), scale=scale or const.tmdb.auth.qrcode_size)
        return str(icon)

    def on_close(self) -> None:
        """Cleanup temp QR code image."""
        if self._remove_icon and self.icon:
            try:
                Path(self.icon).unlink(missing_ok=True)
            except Exception as exc:
                fflog.warning(f'Error removing QR code image {self.icon}: {exc}')
            self._remove_icon = False
            self.icon = ''

    def update(self, value: int) -> None:
        """Upate progress in percent (0..100)."""
        if not value or value < 0:
            value = 0
        elif value is True or value > 100:
            value = 100
        self.progress = value
        if self._is_inited:
            track = self.find('progress_track').control()
            bar = self.find('progress_bar').control()
            if track is not None and bar is not None:
                bar.setWidth(int(value * track.getWidth() / 100))

    def dialog_is_canceled(self) -> bool:
        """Return True if the user canceled the authorization."""
        return self._is_canceled
