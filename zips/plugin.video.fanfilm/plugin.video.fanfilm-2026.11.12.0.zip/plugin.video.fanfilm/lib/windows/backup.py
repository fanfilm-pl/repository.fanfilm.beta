"""
The backup window: a backup of the user data (the parts, the folder) or a restore of one (the backup of the folder, its parts).
It only chooses: the caller makes or restores the backup (`lib.ff.backup`). A restore: OK on a row of the list chooses its backup
(its radio mark; the moves only move the cursor), the parts, Delete and OK follow the chosen one; Delete removes it (confirmed).
"""

from __future__ import annotations
from typing import Any, Collection, cast, TYPE_CHECKING
from attrs import evolve, frozen
from .base import BaseDialog, weak_callback
from .widgets.buttons import CHECK_STATES
from ..ff.backup import PARTS, Backup, BackupPart, backup_parts, backups, delete_backup, profile_folder
from ..kolang import L
if TYPE_CHECKING:
    from .widgets.buttons import CheckBox
    from .widgets.views import ListView

#: `Dialog.browse()` type: a folder (Kodi `CGUIDialogFileBrowser::ShowAndGetDirectory`, not exported by `xbmcgui`).
BROWSE_FOLDER: int = 0
#: `Dialog.browse()` type: a writable folder (Kodi `ShowAndGetWriteableDirectory`, not exported by `xbmcgui`).
BROWSE_WRITABLE_FOLDER: int = 3


@frozen(kw_only=True)
class BackupRow:
    """A shown backup of the folder."""

    #: The backup.
    backup: Backup
    #: The label: the date of the backup.
    title: str
    #: The second label: the file name.
    info: str
    #: Shown grayed (`row_text`): never.
    dim: bool = False
    #: The state of its radio mark (`CHECK_STATES`): `on` the chosen backup.
    state: str = CHECK_STATES[False]

    @classmethod
    def of(cls, backup: Backup) -> BackupRow:
        """Return the row of the backup (the date from its file name, the old backups of the settings told)."""
        digits = ''.join(ch for ch in backup.name if ch.isdigit())
        date = f'{digits[:4]}-{digits[4:6]}-{digits[6:8]} {digits[8:10]}:{digits[10:12]}' if len(digits) >= 12 else backup.name
        if backup.legacy:
            info = f'{backup.name} · {L(30999, "Settings only")}'
        elif backup.undo:
            info = f'{backup.name} · {L(31008, "Before the last restore")}'
        else:
            info = backup.name
        return BackupRow(backup=backup, title=date, info=info)


@frozen(kw_only=True)
class BackupChoice:
    """The choice of the window: the folder (None: the profile), the backup to restore (None: a new one) and the parts."""

    #: The folder of the backups, None: the add-on profile.
    folder: str | None
    #: The backup to restore, None: make a new one.
    backup: Backup | None
    #: The names of the chosen parts.
    parts: Collection[str]


class BackupDialog(BaseDialog[BackupChoice]):
    """The choice of a backup (`restore` false: the parts and the folder of a new one) or of a restore (the backup of the folder, its parts)."""

    @classmethod
    def xml_vars(cls, restore: bool = False, **kwargs: Any) -> dict[str, Any]:
        """The mode (a restore lists the backups), the parts, the texts."""
        return {'RESTORE': restore, 'PARTS': PARTS, 'TITLE': L(30370, 'Restore a backup') if restore else L(30371, 'Make a backup'),
                'CHOOSE': L(31000, 'Choose folder…'), 'DELETE': L(31009, 'Delete…'), 'NO_BACKUPS': L(31001, 'No backups in this folder')}

    def __init__(self, *args: Any, restore: bool = False, **kwargs: Any) -> None:
        """The window: a restore (`restore`) or a new backup; no controls yet."""
        super().__init__(*args)
        #: A restore (else a new backup).
        self.restore: bool = restore
        #: The folder of the backups, None: the add-on profile.
        self.folder: str | None = None
        #: The chosen backup to restore (OK on its row), None: none yet.
        self.chosen: Backup | None = None
        if restore:  # the list of the backups and Delete only in a restore (no slots by their names: a backup has no such widgets)
            self.backups_view.activated.connect(weak_callback(self.backup_activated))
            self.find('delete').clicked.connect(weak_callback(self.delete_chosen))

    def box(self, part: BackupPart) -> CheckBox:
        """Return the check box of the part."""
        return cast('CheckBox', self.find(f'part_{part.name}'))

    @property
    def backups_view(self) -> ListView:
        """Return the list of the backups (a restore)."""
        return cast('ListView', self.find('backups'))

    def on_init(self) -> None:
        """Show the folder (the backups of a restore) and the parts, the focus on the first choice."""
        self.show_folder()
        self.find('choose').help = L(31002, 'The folder of the backups: the profile of FanFilm or any folder of Kodi (a USB stick, a network share).')
        for part in PARTS:
            self.box(part).help = part.help
        if self.restore:
            self.backups_view.help = L(31007, 'OK on a row chooses the backup to restore (the arrows only move).')
            self.find('delete').help = L(31010, 'Delete the chosen backup file.')
        if not self.restore:
            for part in PARTS:
                box = self.box(part)
                box.checked = part.always or part.checked
                box.enabled = not part.always
                box.reason = L(31003, 'Always in a backup') if part.always else ''
        self.setFocusId((self.backups_view if self.restore and self.backups_view.rows else self.find('choose')).id)

    def show_folder(self) -> None:
        """Show the folder and - a restore - its backups (none chosen, the newest current)."""
        self.find('folder').text = profile_folder() if self.folder is None else self.folder
        if self.restore:
            self.chosen = None
            view = self.backups_view
            view.rows = [BackupRow.of(backup) for backup in backups(self.folder)]
            view.current = 0 if view.rows else -1
            self.show_parts()

    def backup_activated(self, index: int) -> None:
        """OK on a row: its backup chosen (its radio mark), the parts of it."""
        view = self.backups_view
        if not 0 <= index < len(view.rows):
            return
        self.chosen = view.rows[index].backup
        view.rows = [evolve(row, state=CHECK_STATES[row.backup == self.chosen]) for row in view.rows]
        self.show_parts()

    def show_parts(self) -> None:
        """A restore: the parts of the chosen backup - the ones it has checked, the others gray with the reason; OK only with a chosen backup."""
        backup = self.chosen
        reasons = backup_parts(backup) if backup is not None else {part.name: L(31004, 'No backup chosen') for part in PARTS}
        for part in PARTS:
            box = self.box(part)
            reason = reasons.get(part.name, '')
            box.checked = not reason
            box.enabled = not reason and not part.always
            box.reason = reason or (L(31005, 'Always restored') if part.always else '')
        self.find('ok').enabled = backup is not None and 'config' not in reasons
        self.find('delete').enabled = backup is not None

    def on_choose_clicked(self) -> None:
        """Choose the folder of the backups (Kodi: writable for a backup)."""
        from xbmcgui import Dialog
        heading = L(31006, 'Folder of the backups')
        current = profile_folder() if self.folder is None else self.folder
        folder = Dialog().browse(BROWSE_FOLDER if self.restore else BROWSE_WRITABLE_FOLDER, heading, 'files', '', False, False, current)
        if isinstance(folder, str) and folder and folder != current:
            self.folder = folder
            self.show_folder()

    def delete_chosen(self) -> None:
        """Delete the chosen backup (confirmed), the backups of the folder again (none chosen)."""
        from xbmcgui import Dialog, NOTIFICATION_ERROR
        backup = self.chosen
        if backup is None or not Dialog().yesno(L(31011, 'Delete the backup'), L(31012, 'Delete the backup {backup}?').format(backup=backup.name)):
            return
        if not delete_backup(backup):
            Dialog().notification(L(31011, 'Delete the backup'), L(31013, 'Can not delete the backup.'), NOTIFICATION_ERROR)
        self.show_folder()
        self.setFocusId((self.backups_view if self.backups_view.rows else self.find('choose')).id)

    def on_ok_clicked(self) -> None:
        """The choice: the parts checked (a restore: of the current backup)."""
        backup = self.chosen if self.restore else None
        if self.restore and backup is None:
            return
        self.close(BackupChoice(folder=self.folder, backup=backup, parts=[part.name for part in PARTS if self.box(part).checked]))

    def on_cancel_clicked(self) -> None:
        """No choice."""
        self.close()

    def on_focus(self, control_id: int) -> None:
        """The help of the focused control in the foot (a disabled part: why)."""
        self.find('help').text = self._widget_tree.help_of(control_id) if self._widget_tree is not None else ''
