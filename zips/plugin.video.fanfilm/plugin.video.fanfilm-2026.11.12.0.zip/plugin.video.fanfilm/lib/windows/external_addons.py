"""
The source providers of the configuration window (its page: `lib.windows.widgets.source_providers`): the native providers of
FanFilm (FanFilm (built-in): its groups, sections, providers and their sub-sources) and the provider add-ons with the
add-ons they serve in a tree (provider add-on / add-on / group / scraper, `lib.sources.addons.external.addons_tree()`), a
scraper searched or not (the check of its row, a node: its branch; the first activation of an add-on: its scrapers searched
by default), the panel of the selected row (its info from `addon.xml`, its settings; a provider add-on: active or not,
enable it in Kodi; an add-on: enable it in Kodi; a native provider: the header of FanFilm, its settings in a list, the
add-on it needs). Every change is written at once (`ADDONS_CONFIG`, `XPROVIDERS_CONFIG`, the settings of the native
providers); the default selection of a branch (its button in the panel, the context menu of the row), the last partial state
of every node remembered beside the choice (`tree_vars(memory=...)`: a node action restores it); a provider add-on which
does not run (inactive, disabled in Kodi) and a native provider without the add-on it needs are dimmed.
"""

from __future__ import annotations
from typing import Any, Callable, ClassVar, Sequence, cast, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from pathlib import Path
from functools import partial
from attrs import evolve, frozen
from .tree import RowMarks, TreeModel, TreeView
from .widgets.setting_list import SettingRow
from ..ff.kotools import addon_enabled_in_kodi, addon_info
from ..ff.xproviders import XPROVIDERS_CONFIG, is_active, set_active
from ..kolang import L
from ..sources import addon_name_parts, safe_addon_name
from ..sources.addons.external import (ADDONS_CONFIG, NODE_DEFAULTS, NODES_CONFIG, ExternalAddon, FoundXProvider, NodeValue, TreeEntry, addon_scrapers_selected,
                                       addons_choice, addons_tree, clear_node, default_leaves, found_xproviders, node_has, node_value, node_values,
                                       set_node_value, tree_keys)
from ..sources.natives import CatalogSetting, NativeProvider, ProviderSetting, SettingOption, catalog_setting, provider_value, set_provider_value
from const import const
if TYPE_CHECKING:
    from ..ff.item import FFItem
    from ..ff.menu import ContextMenuItem

#: The width of the tree.
TREE_WIDTH = 685


#: The options of a priority of a node: inherited (no value of its own), its own number (0 too: it stops the inheritance).
PRIORITY_OPTIONS: tuple[SettingOption, ...] = (SettingOption(value=None, label=L(30979, 'Inherits')),
                                               *(SettingOption(value=n, label=str(n)) for n in range(11)))

#: The settings of every node of the tree (the first rows of the panel): the priorities and the highlight color of its sources
#: (`NODES_CONFIG`; the first one set from the source up, its branch).
NODE_SETTINGS: tuple[CatalogSetting, ...] = tuple(catalog_setting(setting) for setting in (
    ProviderSetting(key='priority', kind='select', label=L(30219, 'Priority'), default=NODE_DEFAULTS['priority'], options=PRIORITY_OPTIONS,
                    help=L(30221, 'The priority of the sources of the branch (bigger first): the first one set from the source up.')),
    ProviderSetting(key='episode_priority', kind='select', label=L(30980, 'Priority of episodes'), default=NODE_DEFAULTS['episode_priority'],
                    options=PRIORITY_OPTIONS,
                    help=L(30981, 'The priority of the sources of the branch for episodes (bigger first): '
                                  'the first one set from the source up, none on the branch: as the movies.')),
    # the color before the settings of a provider: its color of the account items right under it
    ProviderSetting(key='color', kind='color', label=L(32649, 'Highlight color'), default=NODE_DEFAULTS['color'],
                    help=L(30218, 'The highlight color of the sources of the branch: the first one set from the source up.')),
))


@frozen
class NodeOrigin:
    """Where an effective value of a node comes from (`ProvidersTabLogic.effective()`)."""

    #: The value.
    value: Any
    #: The text of the origin ('' - the node itself).
    origin: str = ''


def rule_default(addon: str, provider: str, name: NodeValue) -> Any:
    """
    Return the default value `name` of the rules (`SourceAttribute.default_*`, `const.sources.rules`) of the add-on / the
    provider of a node, only the rules without a condition of a source (as the sources apply them: the last one, up to a
    final one), None if none.
    """
    from ..sources import ProviderModule
    module = ProviderModule(name=provider, provider=cast(Any, None), addon=addon)
    value = None
    for pat, attr in const.sources.rules.items():
        if attr and attr is not True and not pat.has_source_condition() and module.match(pat):
            if (default := getattr(attr, f'default_{name}')) is not None:
                value = default
            if attr.final:
                break
    return value


def addons_path() -> Path:
    """Return the folder of the add-ons."""
    from xbmcvfs import translatePath
    return Path(translatePath('special://home/addons'))


def required_addon(requires: Sequence[str]) -> tuple[str, bool]:
    """Return the add-on of `requires` (one of them enabled; else an installed one, else the first) and True if it is enabled."""
    for addon_id in requires:
        if addon_enabled_in_kodi(addon_id):
            return addon_id, True
    return next((addon_id for addon_id in requires if (addons_path() / addon_id).is_dir()), requires[0] if requires else ''), False


def setting_shown(setting: CatalogSetting, name: str) -> bool:
    """Return True if the row of a setting of the provider `name` is shown (every key of its `when` has one of its values)."""
    return all(provider_value(name, key) in values for key, values in setting.get('when', {}).items())


def setting_usable(setting: CatalogSetting) -> bool:
    """Return True if the row of a setting can be used (an add-on of its `requires` enabled, not a read only state)."""
    return setting['kind'] != 'state' and (not (requires := setting.get('requires')) or required_addon(requires)[1])


def summary_height() -> int:
    """Return the height of the summary of the panel: two lines of its font and a gap."""
    from .skinfonts import text_metrics
    _, line_height = text_metrics('normal')
    return round(2 * line_height) + 10


@frozen(kw_only=True)
class AddonPanel:
    """The panel of the selected row: of a provider add-on or of an add-on (the bindings of the window read it)."""

    #: The provider add-on of the row.
    xprovider: FoundXProvider | None = None
    #: The add-on (None: the row of the provider add-on itself).
    addon: ExternalAddon | None = None
    #: The icon.
    icon: str = ''
    #: The category of the name (`Category: Name`, the line above the name), '' - none.
    category: str = ''
    #: The name without its category (a name reserved for FanFilm: from the ID, `safe_addon_name()`).
    title: str = ''
    #: The name in its `addon.xml` if it is reserved for FanFilm (else none).
    claimed: str = ''
    #: The ID; the version and the author.
    id: str = ''
    info: str = ''
    #: The state: a provider add-on: active or not, its add-ons; an add-on: disabled in Kodi, new, the searched scrapers.
    state: str = ''
    #: The summary and the description (`addon.xml`, the language of Kodi).
    summary: str = ''
    description: str = ''
    #: The settings can be opened (it has them, it is enabled in Kodi: Kodi opens only the settings of an enabled one).
    settings: bool = False
    #: The add-on to enable in Kodi (the add-on or the provider add-on of the row), '' - none.
    enable: str = ''
    #: The add-on of the button of the settings ('' - `id`): a native provider - the add-on it needs, else FanFilm.
    target: str = ''
    #: The row is of the native providers: the name of the row and the list of the settings instead of the description.
    native: bool = False
    #: The name of the row (a native one: a provider, a group, a section).
    heading: str = ''
    #: The native provider of the row (its settings in the list), '' - none.
    provider: str = ''

    @property
    def path(self) -> Path:
        """Return the folder of the add-on of the row."""
        return addons_path() / (self.addon.id if self.addon is not None else self.xprovider.id if self.xprovider is not None else '')

    @classmethod
    def of_native(cls, xp: FoundXProvider, *, heading: str, provider: NativeProvider | None, sub: str, selected: int, total: int) -> AddonPanel:
        """
        Return the panel of a row of the native providers: the header of FanFilm, the name of the row, the add-on it needs
        (a provider, a sub-source: its settings, enable it in Kodi), the settings of its provider (in the list).
        """
        from ..ff.control import plugin_id
        requires: Sequence[str] = ()
        if provider is not None:
            requires = next((item['requires'] for item in provider.get('subsources', ()) if item['id'] == sub), ()) if sub else provider.get('requires', ())
        state = [L(30754, '{selected} of {total} searched').format(selected=selected, total=total)]
        target, enabled = required_addon(requires) if requires else (plugin_id, True)
        if requires and not (addons_path() / target).is_dir():
            state.append(L(30755, 'needs the add-on {addon}: not installed').format(addon=target))
        elif requires and not enabled:
            state.append(L(30756, 'needs the add-on {addon}: disabled in Kodi').format(addon=target))
        elif requires:
            state.append(L(30757, 'needs the add-on {addon}').format(addon=target))
        panel = cls._of(plugin_id, enabled_in_kodi=True, icon=xp.icon, title=xp.name, state=state, xprovider=xp)
        installed = (addons_path() / target).is_dir()
        return evolve(panel, claimed='', target=target, native=True, heading=heading, provider=provider['id'] if provider is not None and not sub else '',
                      settings=installed and enabled and (addons_path() / target / 'resources/settings.xml').is_file(),
                      enable=target if installed and not enabled else '')

    @classmethod
    def _of(cls, addon_id: str, *, enabled_in_kodi: bool, icon: str | None, title: str, state: list[str], xprovider: FoundXProvider,
            addon: ExternalAddon | None = None) -> AddonPanel:
        """Return the panel of an installed add-on of the row (its `addon.xml`)."""
        path = addons_path() / addon_id
        xml = addon_info(path)
        claimed = xml.name and safe_addon_name(xml.name, addon_id) != xml.name
        category, title = addon_name_parts(title)
        return AddonPanel(xprovider=xprovider, addon=addon, icon=icon or '', category=category, title=title,
                          claimed=L(30356, 'Name in the add-on: {name}').format(name=xml.name) if claimed else '',
                          id=addon_id, info=' · '.join(text for text in (xml.version, xml.author) if text), state=' · '.join(state),
                          summary=xml.summary, description=xml.description,
                          settings=enabled_in_kodi and (path / 'resources/settings.xml').is_file(), enable='' if enabled_in_kodi else addon_id)

    @classmethod
    def of_xprovider(cls, xp: FoundXProvider) -> AddonPanel:
        """Return the panel of a provider add-on: disabled in Kodi, inactive (it does not run), starting, its add-ons."""
        if not xp.enabled_in_kodi:
            state = [L(32920, 'disabled in Kodi: no service, no updates')]
        elif not xp.active:
            state = [L(30713, 'inactive: it does not run, its add-ons are not searched')]
        elif xp.loading:
            state = [L(30714, 'active, starting: open the tab again')]
        else:
            state = [L(30715, 'active'), L(30716, '{n} add-on|||{n} add-ons', n=len(xp.addons))]
        return cls._of(xp.id, enabled_in_kodi=xp.enabled_in_kodi, icon=xp.icon, title=xp.name, state=state, xprovider=xp)

    @classmethod
    def of_addon(cls, addon: ExternalAddon, xp: FoundXProvider, *, new: bool, selected: int) -> AddonPanel:
        """Return the panel of an add-on: `new` - not in the configuration yet, `selected` - its searched scrapers."""
        state = [text for text, on in ((L(32920, 'disabled in Kodi: no service, no updates'), not addon.enabled_in_kodi), (L(32921, 'new'), new)) if on]
        state.append(L(30349, '{selected} of {total} scrapers searched').format(selected=selected, total=len(addon.scrapers)))
        return cls._of(addon.id, enabled_in_kodi=addon.enabled_in_kodi, icon=addon.icon, title=addon.name, state=state, xprovider=xp, addon=addon)


#: A button of the panel: the settings of the add-on, its state (a provider add-on: active / not, enable it in Kodi; an
#: add-on: enable it in Kodi), the default selection of the branch of the row.
PanelButton: TypeAlias = Literal['settings', 'enable', 'defaults']


class ProvidersTabLogic:
    """
    The state and the logic of the tab of the source providers, shown by the page of widgets (`lib.windows.widgets.source_providers`):
    the tree model and what its items are, the panel of the selected row, its settings, the changes (written at once); the class
    showing them gives the tree (`view`) and shows the panel (`show_panel()`) and its settings (`show_rows()`).
    """

    #: The configuration branches of the tab (its defaults restored = these removed): the choice, the colors and the
    #: priorities (not the values of the providers).
    DEFAULTS: ClassVar[tuple[str, ...]] = (XPROVIDERS_CONFIG, ADDONS_CONFIG, NODES_CONFIG)

    if TYPE_CHECKING:
        #: The tree.
        view: TreeView

    def init_logic(self) -> None:
        """Nothing read yet (`load()`), no panel."""
        #: The configuration of the add-ons (`ADDONS_CONFIG`, read by `load()`).
        self.chosen: dict[str, Any] = {}
        #: The provider add-ons with their add-ons (the order of the tree).
        self.xproviders: list[FoundXProvider] = []
        #: The add-ons by their IDs.
        self.found: dict[str, ExternalAddon] = {}
        #: What every item of the tree is (by `id()`).
        self.entries: dict[int, TreeEntry] = {}
        #: The row the panel shows (-1: none).
        self.pos: int = -1
        #: The panel of the selected row.
        self.panel: AddonPanel = AddonPanel()
        #: The shown settings of the panel (the rows of its list): of the node of the row, of its native provider.
        self.rows: list[SettingRow] = []

    def load(self) -> TreeModel:
        """Read the provider add-ons and their add-ons, the choice (after the migration of the native providers), return the model of the tree."""
        from ..ff.config import config
        self.xproviders = found_xproviders()
        self.chosen = config.get(ADDONS_CONFIG) or {}
        self.found = {addon.id: addon for xp in self.xproviders for addon in xp.addons}
        roots, self.entries, preselect = addons_tree(self.xproviders, self.chosen)
        return TreeModel(roots, selected=preselect, defaults=default_leaves(self.xproviders, roots, self.entries), key=tree_keys(self.entries))

    def show_panel(self, pos: int | None = None) -> None:
        """Show the panel of the row `pos` (None: the selected one)."""
        raise NotImplementedError

    def show_rows(self, pos: int = 0) -> None:
        """Show the settings of the panel (`panel_settings()`) with the row `pos` selected."""
        raise NotImplementedError

    # --- the view ---

    def entry_of(self, item: FFItem) -> TreeEntry | None:
        """Return what the item of the tree is."""
        return self.entries.get(id(item))

    def xprovider_of(self, entry: TreeEntry | None) -> FoundXProvider | None:
        """Return the provider add-on of the entry."""
        return None if entry is None else next((xp for xp in self.xproviders if xp.id == entry.xprovider), None)

    def native_of(self, entry: TreeEntry | None) -> NativeProvider | None:
        """Return the native provider of the entry (its row, a group which is the provider itself), None if none."""
        if entry is None or not entry.provider or (xp := self.xprovider_of(entry)) is None:
            return None
        return next((prov for prov in xp.natives if prov['id'] == entry.provider), None)

    def dimmed(self, item: FFItem) -> bool:
        """
        Return True if nothing of the item is searched: its provider add-on does not run (inactive, disabled in Kodi), its
        native provider (a sub-source) needs an add-on not enabled in Kodi.
        """
        entry = self.entry_of(item)
        if (xp := self.xprovider_of(entry)) is not None and not (xp.active and xp.enabled_in_kodi):
            return True
        if entry is None or not entry.key or (prov := self.native_of(entry)) is None:
            return False
        requires = next((sub['requires'] for sub in prov.get('subsources', ()) if sub['id'] == entry.sub), ()) if entry.sub else prov.get('requires', ())
        return bool(requires) and not required_addon(requires)[1]

    def usable(self, button: PanelButton) -> bool:
        """Return True if the button of the panel can be used (else grayed)."""
        if button == 'settings':
            return self.panel.settings
        if button == 'enable':
            return bool(self.panel.enable) or (self.panel.xprovider is not None and self.panel.addon is None and not self.panel.native)
        return 0 <= self.pos < len(self.view.model.rows) and not self.view.model.is_default(self.view.model.rows[self.pos].item)

    def button_text(self, button: PanelButton) -> str:
        """Return the label of a button of the panel (by the state of its add-on)."""
        if button == 'settings':
            return L(30358, 'Settings of the add-on')
        if button == 'defaults':
            return L(30767, 'Default selection')
        if self.panel.enable:
            return L(30360, 'Enable in Kodi')
        if self.panel.addon is None and not self.panel.native and (xp := self.panel.xprovider) is not None:
            return L(30717, 'Deactivate provider') if xp.active else L(30718, 'Activate provider')
        return L(30360, 'Enable in Kodi')

    def select_panel(self, pos: int | None = None) -> None:
        """Make the panel of the row `pos` (None: the selected one)."""
        self.pos = self.view.position() if pos is None else pos
        entry = self.entry_of(self.view.model.rows[self.pos].item) if 0 <= self.pos < len(self.view.model.rows) else None
        if (xp := self.xprovider_of(entry)) is None or entry is None:
            self.panel = AddonPanel()
        elif xp.natives:
            item = self.view.model.rows[self.pos].item
            leaves = [leaf for leaf in self.view.model.leaves(item)] if self.view.model.rows[self.pos].node else [item]
            selected = sum(id(leaf) in self.view.model.selected for leaf in leaves)
            self.panel = AddonPanel.of_native(xp, heading=item.getLabel(), provider=self.native_of(entry), sub=entry.sub, selected=selected,
                                              total=len(leaves))
        elif not entry.addon:
            self.panel = AddonPanel.of_xprovider(xp)
        elif (addon := self.found.get(entry.addon)) is not None:
            selected = sum((e := self.entry_of(leaf)) is not None and e.addon == addon.id for leaf in self.view.model.selected_leaves())
            self.panel = AddonPanel.of_addon(addon, xp, new=addon.id not in self.chosen, selected=selected)

    # --- the nodes: the color, the priority ---

    def branch(self, item: FFItem) -> list[FFItem]:
        """Return the item and its ancestors (the leaf first, as the branch of a source)."""
        return [item, *self.view.model.ancestors(item)]

    def marks(self, item: FFItem) -> RowMarks:
        """Return the marks of a row of the tree: its own color, its own priority (up)."""
        if (entry := self.entry_of(item)) is None:
            return RowMarks()
        color = node_value(entry.node_key, 'color')
        up = any(name != 'color' and (node_value(entry.node_key, name) or 0) > 0 and name in node_values() for name in NODE_DEFAULTS)  # asked last: a row of a tree
        return RowMarks(color=color if node_has(color) else '', up=up)

    def describe(self, item: FFItem) -> tuple[str, str]:
        """Return the add-on and the provider of a node for the rules (`rule_default()`): a native one of FanFilm (''), a scraper by its name."""
        from ..sources.natives import NATIVES_ID
        if (entry := self.entry_of(item)) is None:
            return '', ''
        if entry.xprovider == NATIVES_ID:  # FanFilm itself: its groups, sections, providers
            return '', entry.provider
        if not entry.addon:  # a provider add-on
            return entry.xprovider, ''
        if entry.key and (addon := self.found.get(entry.addon)) is not None:
            return entry.addon, next((prov.name for prov in addon.providers if prov.id == entry.key), '')
        return entry.addon, ''

    def effective(self, item: FFItem, name: NodeValue, *, inherited: bool = False, premium: bool = False) -> NodeOrigin:
        """
        Return the value `name` of the sources of the node: its own (`inherited`: not this one - what it gets without it), of an ancestor,
        of the rules, the default one (and where from) - the colour of the settings: of the premium sources first (`premium`), the
        automatic one of a native provider, the default one, as the colour of a source (`lib/ff/sources.py`). The priority of the episodes
        with none on the branch: the one of the movies.
        """
        for n, it in enumerate(self.branch(item)):
            if (n or not inherited) and (entry := self.entry_of(it)) is not None and node_has(value := node_value(entry.node_key, name)):
                return NodeOrigin(value, '' if not n else L(30222, 'from {name}').format(name=it.getLabel()))
        if name == 'episode_priority':
            return NodeOrigin(self.effective(item, 'priority').value, L(30982, 'as the movies'))
        if (value := rule_default(*self.describe(item), name)) is not None:
            return NodeOrigin(value, L(30223, 'rule'))
        if name != 'color':
            return NodeOrigin(0, L(30979, 'Inherits'))
        from ..sources.source_settings import source_setting
        from .sources import auto_color
        if premium and (color := source_setting('premium_color')):
            return NodeOrigin(color, L(30753, 'Default'))
        if color := auto_color(self.describe(item)[1]):  # a native provider: its automatic colour
            return NodeOrigin(color, L(30811, 'automatic'))
        return NodeOrigin(source_setting('default_color'), L(30753, 'Default'))

    def node_text(self, item: FFItem, name: NodeValue) -> str:
        """Return the text of the effective value of the node (the priority always) and where it is from (the color: its sample is `swatch()`)."""
        eff = self.effective(item, name)
        if name == 'color':
            return str(eff.origin or eff.value)
        return f'{eff.value} · {eff.origin}' if eff.origin else str(eff.value)

    def reset_node(self, item: FFItem) -> None:
        """The color and the priority of the node as of its parent (its own ones removed)."""
        if (entry := self.entry_of(item)) is not None:
            clear_node(entry.node_key)
            self.view.show_states()
            self.show_panel()

    def extra_menu(self, pos: int) -> list[ContextMenuItem]:
        """The context menu of a row: its color and priority as of its parent (if it has its own ones)."""
        item = self.view.model.rows[pos].item
        if (entry := self.entry_of(item)) is None or not any(node_has(node_value(entry.node_key, name)) for name in node_values()):
            return []
        root = self.view.model.rows[pos].parent < 0
        label = L(30224, 'Color and priority: default') if root else L(30225, 'Color and priority: as the parent')
        return [(label, lambda: self.reset_node(item))]

    def panel_settings(self) -> list[SettingRow]:
        """
        Make the settings of the panel (`rows`) and return them: the color and the priority of the node of the tree row (their effective
        values; the default of the picker: the color the node gets without its own), the shown settings of its native provider (the default
        of the picker: the color of the node of the provider without it).
        """
        name = self.panel.provider
        prov = next((p for xp in self.xproviders for p in xp.natives if p['id'] == name), None) if name else None
        item = self.view.model.rows[self.pos].item if 0 <= self.pos < len(self.view.model.rows) else None
        entry = self.entry_of(item) if item is not None else None
        rows: list[SettingRow] = []
        if entry is not None and item is not None:
            node = entry.node_key
            for setting in NODE_SETTINGS:
                if (key := cast('NodeValue', setting['key'])) not in node_values():
                    continue
                rows.append(SettingRow(setting=setting, get=partial(node_value, node, key), set=partial(set_node_value, node, key),
                                       shown=partial(self.node_shown, item, key),
                                       color_default=partial(lambda it: str(self.effective(it, 'color', inherited=True).value), item)))
        if name:
            rows.extend(self.provider_row(name, setting, item) for setting in (prov or {}).get('settings', ()) if setting_shown(setting, name))
        self.rows = rows
        return rows

    def provider_row(self, name: str, setting: CatalogSetting, item: FFItem | None) -> SettingRow:
        """
        Return the row of a setting of the native provider `name` (`item`: the tree row of the panel); the default of the colour picker: the
        colour of the node of the provider without it (of the premium sources first).
        """
        provider = next((it for it in self.branch(item) if (ent := self.entry_of(it)) is not None and ent.node_key == name), item) if item else None
        return SettingRow(setting=setting, get=partial(provider_value, name, setting['key']), set=partial(set_provider_value, name, setting['key']),
                          usable=setting_usable(setting), reason=self.setting_reason(setting),
                          color_default=None if provider is None else partial(lambda it: str(self.effective(it, 'color', premium=True).value), provider))

    def node_shown(self, item: FFItem, name: NodeValue) -> tuple[str, str]:
        """Return the shown text of a value of the node (`node_text()`) and the colour of its sample (the effective color)."""
        return self.node_text(item, name), str(self.effective(item, name).value) if name == 'color' else ''

    def defaults_note(self) -> str:
        """Return the note of restoring the defaults: the external add-ons are not searched then (their own settings stay)."""
        return L(30231, 'The external add-ons are switched off (as after a new installation), their own settings stay.')

    def reload(self) -> None:
        """Read the provider add-ons again (a state changed), show the tree from the same row."""
        pos = self.view.position()
        self.view.model = self.load()
        self.view.show_rows(max(0, min(pos, len(self.view.model.rows) - 1)))
        self.show_panel()

    # --- changes (written at once) ---

    def checked(self, items: Sequence[FFItem]) -> None:
        """Scrapers searched / not: write the configuration of all add-ons of the tree."""
        from ..ff.config import config
        keys: dict[str, set[str]] = {}
        for leaf in self.view.model.selected_leaves():
            if (entry := self.entry_of(leaf)) is not None and entry.key:
                keys.setdefault(entry.addon, set()).add(entry.key)
        self.chosen = addons_choice(self.found.values(), self.chosen, keys)
        config.set(ADDONS_CONFIG, self.chosen)
        self.show_choice()
        self.show_panel()

    def show_choice(self) -> None:
        """Show the choice as written (the first activation of a whole add-on: its scrapers searched by default)."""
        on = {addon.id: set(addon_scrapers_selected(addon, self.chosen)) for addon in self.found.values()}
        self.view.set_selected({item for item, entry in self.entries.items() if entry.key and entry.key in on.get(entry.addon, ())})

    def open_settings(self) -> None:
        """Open the settings of the add-on of the panel (its own window over this one)."""
        from xbmc import executebuiltin
        if self.panel.settings and (addon_id := self.panel.target or self.panel.id):
            executebuiltin(f'Addon.OpenSettings({addon_id})')

    def enable(self) -> None:
        """The state button of the panel: enable the add-on of the row in Kodi; a provider add-on: activate / deactivate it."""
        from ..ff.kotools import KodiRpc
        if self.panel.enable:
            KodiRpc().rpc('Addons.SetAddonEnabled', params={'addonid': self.panel.enable, 'enabled': True})
        elif self.panel.addon is None and not self.panel.native and (xp := self.panel.xprovider) is not None:
            set_active(xp.id, not is_active(xp.id))
        else:
            return
        self.reload()

    def default_selection(self) -> None:
        """The default selection of the branch of the row (its button)."""
        if self.usable('defaults'):
            self.view.reset(self.pos)

    # --- help ---

    @staticmethod
    def setting_reason(setting: CatalogSetting) -> str:
        """Return why the row of a setting is grayed ('' it is not): a read only state, an add-on it needs not enabled."""
        if setting['kind'] == 'state':
            return L(30759, 'Set by the provider (read only).')
        if not setting_usable(setting):
            return L(30760, 'Needs the add-on {addon} enabled in Kodi.').format(addon=required_addon(setting.get('requires', ()))[0])
        return ''

    def button_help(self, button: PanelButton) -> str:
        """Return the help of a button of the panel (for a grayed one: why)."""
        if button == 'defaults':
            if self.usable('defaults'):
                return L(30768, 'Select the scrapers of the branch searched by default (as the add-on suggests).')
            return L(30769, 'The branch has its default selection.')
        if self.panel.native and self.panel.target and not (addons_path() / self.panel.target).is_dir():
            return L(30764, 'The add-on {addon} is not installed.').format(addon=self.panel.target)
        if button == 'enable' and self.panel.native:
            if self.panel.enable:
                return L(30765, 'Enable the add-on {addon} in Kodi: the provider needs it.').format(addon=self.panel.enable)
            return L(30398, 'The add-on is enabled in Kodi.')
        if button == 'settings':
            if self.panel.settings:
                return L(30361, 'Open the settings of the add-on (its own window).')
            return L(30362, 'Enable the add-on in Kodi first.') if self.panel.enable else L(30363, 'The add-on has no settings.')
        if self.panel.enable and self.panel.addon is None:
            return L(30719, 'Enable the provider add-on in Kodi: it runs if it is active.')
        if self.panel.enable:
            return L(30720, 'Enable the add-on in Kodi (not needed: FanFilm searches it anyway; Kodi runs its service and updates it).')
        if self.panel.addon is None and (xp := self.panel.xprovider) is not None:
            if xp.active:
                return L(30721, 'Deactivate the provider add-on: it does not run, FanFilm does not search its add-ons.')
            return L(30722, 'Activate the provider add-on: it runs, FanFilm searches the add-ons it serves (chosen here).')
        return L(30398, 'The add-on is enabled in Kodi.')

    def tree_help(self, control_id: int) -> str:
        """Return the help of the tree or of a button of the selected row."""
        if text := self.view.filter_help(control_id):
            return text
        if (pos := self.view.position()) < 0:
            return ''
        row = self.view.model.rows[pos]
        path = ' / '.join(it.getLabel() for it in (*reversed(list(self.view.model.ancestors(row.item))), row.item))
        if text := self.view.help_of(control_id):
            return f'{path}: {text}'
        return L(30469, '{path}: OK - searched or not (an add-on, a group: expand / collapse), right - the check of the row.').format(path=path)
