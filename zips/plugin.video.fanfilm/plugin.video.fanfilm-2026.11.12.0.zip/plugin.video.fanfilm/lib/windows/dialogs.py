
from __future__ import annotations
from typing import Optional, Union, Any, List, Sequence, Iterable, Iterator, TYPE_CHECKING
from typing_extensions import Self, TypeAlias
from collections import UserList
from enum import Enum
from pathlib import Path
from attrs import define, field
from .base import BaseDialog
from .style import tokens
from ..ff.control import lang2
from ..ff.logs import fflog, fflog_exc
from const import const


class KnownButton(Enum):
    CANCEL = 222
    OK = 186
    NO = 106
    YES = 107
    CLOSE = 15067
    DONE = 20177
    SAVE = 190
    CLEAR = 192
    SEARCH = 137
    SCAN = 193
    NEXT = 209
    PREVIOUS = 210
    DISABLE = 24021
    ENABLE = 24022


@define
class Button:
    name: str
    value: Optional[int] = None
    width: int = field(default=0, kw_only=True)
    known: Optional[KnownButton] = field(default=None, kw_only=True)


ButtonBoxType: TypeAlias = Optional[Iterable[Union[Button, KnownButton]]]


class ButtonBox(UserList):
    OK = (KnownButton.OK,)
    OK_CANCEL = (KnownButton.OK, KnownButton.CANCEL)
    YES_NO = (KnownButton.YES, KnownButton.NO)

    def __init__(self,
                 initlist: ButtonBoxType = None,
                 *,
                 button_width: int = 0,  # 0: the button width of the style
                 button_space: int = 100,
                 ) -> None:
        super().__init__(initlist)
        self.button_width = button_width
        self.button_space = button_space


class FLayout(str):  # później się tym zajmę (rysson)
    pass


def dialog_labels(label: Union[None, str, Sequence[Optional[str]]]) -> List[str]:
    """Return the labels of the dialog (`label`: one, none or a sequence of them; None ones skipped)."""
    if label is None:
        return []
    if isinstance(label, str):
        return [label]
    return [lb for lb in label if lb is not None]


class SimpleDialog(BaseDialog):
    """Base dialog with some extenstions like image."""

    def __new__(cls, *args: Any, modal: bool = True, scriptPath: Optional[str] = None, **kwargs: Any) -> Self:
        """Create the dialog of its shape: `xml_vars()` of the arguments of the dialog class (positional ones too)."""
        from .gui import CustomXmlRequest
        fflog(f'SimpleDialog.__new__({cls=}, {args=}, {modal=}, {kwargs=})')
        request = CustomXmlRequest(vars=cls.xml_vars(*args, **kwargs))
        return super().__new__(cls, None, scriptPath, None, None, modal=modal, _call_init=False, xml_request=request)

    @classmethod
    def xml_vars(cls,
                 layout: Union[None, FLayout, str] = None,
                 *args: Any,
                 label: Union[None, str, Sequence[Optional[str]]] = None,
                 buttons: ButtonBoxType = ButtonBox.OK,
                 image: Optional[str] = None,
                 image_size: Optional[int] = None,
                 **kwargs: Any,
                 ) -> dict[str, Any]:
        """The shape of the dialog: its layout, the number of the labels, the image (its size), the widths of the buttons."""
        if buttons is None:
            buttons = ButtonBox.OK
        button_width = getattr(buttons, 'button_width', 0) or tokens().metric.button.width
        return {
            'LAYOUT': str(layout or ''),
            'LABELS': len(dialog_labels(label)),
            'IMAGE': bool(image),
            'IMAGE_SIZE': image_size or 0,
            'BUTTONS': tuple(getattr(btn, 'width', 0) or button_width for btn in buttons),
            'BUTTON_SPACE': getattr(buttons, 'button_space', 100),
        }

    def __init__(self,
                 layout: Union[None, FLayout, str] = None,
                 *args,
                 heading: Optional[str] = None,
                 label: Union[None, str, Sequence[Optional[str]]] = None,
                 text: Optional[str] = None,
                 # code: Optional[str] = None,
                 buttons: ButtonBoxType = ButtonBox.OK,
                 image: Optional[str] = None,
                 image_size: Optional[int] = None,
                 **kwargs) -> None:
        super().__init__(self, *args, **kwargs)
        if buttons is None:
            buttons = ButtonBox.OK
        self.layout: FLayout
        # self.code: str = code or ''
        self._is_canceled: bool = False
        #: The index of the cancel button (None: no one).
        self._cancel_index: Optional[int] = None
        self.buttons: List[Button] = [btn if isinstance(btn, Button) else Button('', known=btn) for btn in buttons]
        self.heading = heading
        self.labels = dialog_labels(label)
        self.text = text
        self.image = image
        self.image_size = image_size
        if layout is None:
            self.layout = FLayout()
        elif isinstance(layout, str):
            # self.layout = FLayout.from_str(layout)
            self.layout = self._create_layout(layout)
        else:
            self.layout = layout

        if self.heading:
            self.setProperty('heading.name', self.heading)

        for i, label in enumerate(self.labels, 1):
            self.setProperty(f'label.{i}.name', label)

        if self.text:
            self.setProperty('textbox.1.name', 'aaa')
            self.setProperty('textbox.1.text', self.text)

        if i_btn := next(iter((i, btn)
                              for close_button in (KnownButton.CANCEL, KnownButton.CLOSE, KnownButton.NO)
                              for i, btn in enumerate(self.buttons)
                              if btn.known is close_button and btn.value is None), None):
            i_btn[1].value = 0
            self._cancel_index = i_btn[0]
        for i, btn in enumerate(self.buttons, 1):
            if btn.known is not None and not btn.name:
                btn.name = lang2(btn.known.value)  # Kodi's own text
            if btn.value is None:
                btn.value = i
            self.find(f'button{i}').text = btn.name

        if self.image:
            # self.setProperty('image.1.name', 'Dupa')
            self.setProperty('image.1.url', self.image)

    def on_click(self, control_id: int) -> None:
        """A button clicked: its value is the result (the cancel one: the dialog is canceled), the dialog closes."""
        index = next((i for i in range(len(self.buttons)) if self.find(f'button{i + 1}').id == control_id), None)
        if index is None:
            return
        if index == self._cancel_index:
            self._is_canceled = True
        self.close(self.buttons[index].value)

    def dialog_is_canceled(self) -> bool:
        return self._is_canceled

    def _create_layout(self, layout: str) -> FLayout:
        return FLayout(layout)  # XXX return fake layput

    if TYPE_CHECKING:
        def doModal(self) -> Optional[int]: ...


class ImageDialog(SimpleDialog):

    @staticmethod
    def image_layout(layout: Optional[FLayout], *, label: Optional[str], text: Optional[str]) -> FLayout:
        """Return the layout of the image dialog: the given one, else the image beside the label, the text or alone."""
        if layout is None:
            if label is not None:
                layout = FLayout('image|label')
            elif text is not None:
                layout = FLayout('image|text')
            else:
                layout = FLayout('image')
        return layout

    @classmethod
    def xml_vars(cls,
                 heading: str = '',
                 image: Union[str, Path] = '',
                 *args: Any,
                 label: Optional[str] = None,
                 text: Optional[str] = None,
                 size: Optional[int] = None,
                 buttons: ButtonBoxType = ButtonBox.OK,
                 layout: Optional[FLayout] = None,
                 **kwargs: Any,
                 ) -> dict[str, Any]:
        """The shape of the dialog of the arguments of the image dialog."""
        return super().xml_vars(cls.image_layout(layout, label=label, text=text), label=label, buttons=buttons, image=str(image), image_size=size)

    def __init__(self,
                 heading: str,
                 image: Union[str, Path],
                 *,
                 label: Optional[str] = None,
                 text: Optional[str] = None,
                 size: Optional[int] = None,
                 buttons: ButtonBoxType = ButtonBox.OK,
                 layout: Optional[FLayout] = None,
                 ) -> None:
        layout = self.image_layout(layout, label=label, text=text)
        super().__init__(layout=layout, heading=heading, image=str(image), image_size=size,
                         label=label, text=text, buttons=buttons)


class QRCodeDialog(ImageDialog):

    def __init__(self,
                 heading: str,
                 qrcode: str,
                 *,
                 label: Optional[str] = None,
                 text: Optional[str] = None,
                 size: Optional[int] = None,
                 scale: Optional[int] = None,
                 buttons: ButtonBoxType = ButtonBox.OK,
                 layout: Optional[FLayout] = None,
                 ) -> None:
        from sys import version_info
        from tempfile import NamedTemporaryFile
        import segno
        from ..ff.control import dataPath as DATA_PATH

        if scale is None:
            scale = const.tune.misc.qrcode.size
        # if size is None:
        #     size = 400  # default for QR-Code
        image_dir = Path(DATA_PATH) / 'tmp'
        image_dir.mkdir(parents=True, exist_ok=True)
        if TYPE_CHECKING or version_info < (3, 12):
            tmp_kwargs = {}
        else:
            tmp_kwargs = {'delete_on_close': False}
        with NamedTemporaryFile('w+b', prefix='qrcode-', suffix='.png', dir=image_dir, delete=False, **tmp_kwargs) as f:
            qrcode_image = segno.make(qrcode)
            qrcode_image.save(f, scale=scale)
            self.image_path = Path(f.name)
        super().__init__(layout=layout, heading=heading, image=self.image_path, size=size,
                         label=label, text=text, buttons=buttons)

    def on_close(self):
        super().on_close()
        try:
            self.image_path.unlink()
        except IOError:
            fflog_exc()
