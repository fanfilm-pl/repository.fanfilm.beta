"""
The scale of a slider, a spin box, a toggle of a few positions or a range: the positions 0..`last` (a Kodi slider works on integers:
`setInt(position, 0, 1, last)`) and their values, texts, ticks. The middle of a scale is linear (the multiples of a step), logarithmic
(the nice values of every decade: 1-2-5, or n steps a decade) or fixed values (numbers or values with labels: an enum). A linear or
logarithmic middle always has its edges (`minimum`, `maximum`) and the regular values between them; a regular value closer to an edge
than half of its step (in the logarithm for a logarithmic one) is left out (1..51 by 5: 1, 5, 10 … 45, 51). The special values (off,
auto…, each with its value and label) are only at its ends (`low`, `high`), several at an end allowed, the same value at both ends too
(told apart by the positions: `position_of()` in the positions of a knob). Pure Python (no Kodi).
"""

from __future__ import annotations
import math
import re
from typing import Any, Callable, Literal
from typing_extensions import TypeAlias
from attrs import frozen
from ..kolang import L

#: The text of a number: a template with a place for it (`'{} GB'`, `'≥ {}'`, `'{:.0%}'`) or a function of it (`human_readable_size`).
NumberText: TypeAlias = 'str | Callable[[Any], str]'

#: The positions of a big step (Page up / down) of a scale without major ticks.
PAGE_STEPS: int = 10


@frozen
class ScaleValue:
    """A value with its own label: a special value at an end of a scale (`Scale.low`, `Scale.high`: off, auto…) or a fixed one (an enum)."""

    #: The value (stored: a number or any other one).
    value: Any
    #: The label (the text of the value, the label of its tick).
    label: str


@frozen
class Tick:
    """A tick of a scale (`Scale.ticks()`)."""

    #: The place on the length of the scale: 0 (the first position) .. 1 (the last one).
    at: float
    #: A major tick (with its label), else a minor one.
    major: bool
    #: The label ('' none: a minor tick).
    label: str = ''


@frozen(kw_only=True)
class Scale:
    """
    The scale (one declaration of the slider and the spin box): the positions of its low end, its middle, its high end. The kind of the
    middle comes from the data: `values` given - fixed values, `log` given - logarithmic, else linear.
    """

    #: The lowest value of a linear or a logarithmic middle (> 0 for logarithmic): its first position, on the grid or not.
    minimum: float = 0
    #: The highest value of a linear or a logarithmic middle: its last position, on the grid or not.
    maximum: float = 100
    #: The step of a linear middle: its regular values are the multiples of the step between `minimum` and `maximum`.
    step: float = 1
    #: A logarithmic middle: the nice mantissas of a decade (`(1, 2, 5)`) or the number of its equal steps in a decade (the values rounded
    #: to two digits); its regular values are the nice ones between `minimum` and `maximum`. Empty / 0: not logarithmic.
    log: tuple[float, ...] | int = ()
    #: The fixed values of the middle in their order: numbers or `ScaleValue` (an enum); empty: minimum..maximum.
    values: tuple[Any, ...] = ()
    #: The special values of the low end (left / bottom): the first one at position 0.
    low: tuple[ScaleValue, ...] = ()
    #: The special values of the high end (right / top): the last one at the last position.
    high: tuple[ScaleValue, ...] = ()
    #: A range: the highest value its minimum knob may take, None: no limit of its own (one axis, the knobs of different extents).
    knob_min_most: Any = None
    #: A range: the lowest value its maximum knob may take, None: no limit of its own.
    knob_max_least: Any = None
    #: The text of a number (the value of the slider, the field of the spin box); the values with labels show their labels.
    format: NumberText = '{}'
    #: The label of a number of a major tick (short: the unit once, in the text of the value or the title).
    tick_format: NumberText = '{}'
    #: Minor ticks every n positions of the middle (fixed: from the first one; the regular values of a linear one: from its value 0, of
    #: a logarithmic one: from its value 1, an edge off the grid does not shift them); 0: every fixed or logarithmic value, none of
    #: a linear one.
    minor: int = 0
    #: Major ticks (labelled) every n positions of the middle (as `minor`); 0: every fixed value, the decades of a logarithmic one, none of
    #: a linear one. The special values are always major ticks, the edges of a linear or logarithmic middle when it has ticks (logarithmic,
    #: `minor` or `major` given).
    major: int = 0

    def _mantissas(self) -> tuple[float, ...]:
        """Return the mantissas of a logarithmic middle: the given ones or the n equal steps of a decade rounded to two digits."""
        if isinstance(self.log, tuple):
            return self.log
        return tuple(float(f'{10 ** (i / self.log):.2g}') for i in range(self.log))

    def _regular(self, k: int) -> float:
        """Return the regular value k: k steps from the value 0 of a linear middle, from the value 1 of a logarithmic one."""
        if not self.log:
            return _clean(k * self.step)
        mantissas = self._mantissas()
        decade, index = divmod(k, len(mantissas))
        return _clean(mantissas[index] * 10 ** decade)

    def _above(self, number: float) -> int:
        """Return the first k of a regular value above the number."""
        if self.log:
            k = (math.floor(math.log10(number)) - 1) * len(self._mantissas())
        else:
            k = math.floor(number / self.step) - 1
        while self._regular(k) <= number:
            k += 1
        return k

    def _distance(self, one: float, other: float) -> float:
        """Return the distance of two numbers of a linear middle, the distance in the logarithm of a logarithmic one."""
        return abs(math.log10(one / other)) if self.log else abs(one - other)

    def _too_close(self, edge: float, k: int, outer: int) -> bool:
        """Return whether the regular value k is closer to the edge than half of its step to the regular value outer (beyond the edge)."""
        value = self._regular(k)
        return round(2 * self._distance(edge, value) - self._distance(value, self._regular(outer)), 9) < 0

    def _regulars(self) -> range:
        """Return the k of the regular values of a linear or logarithmic middle between its edges (none closer to an edge than half a step)."""
        if self.log and self.minimum <= 0:
            raise ValueError(f'the minimum of a logarithmic scale is not > 0: {self.minimum}')
        first, last = self._above(self.minimum), self._above(self.maximum) - 1
        if self._regular(last) == self.maximum:  # the maximum on the grid: the edge
            last -= 1
        if self._too_close(self.minimum, first, first - 1):
            first += 1
        if self._too_close(self.maximum, last, last + 1):
            last -= 1
        return range(first, last + 1)

    def _count(self) -> int:
        """Return the number of the positions of the middle."""
        if self.values:
            return len(self.values)
        if self.minimum > self.maximum:
            return 0
        return len(self._regulars()) + (2 if self.maximum > self.minimum else 1)

    def _middle(self, index: int) -> Any:
        """Return the item of the middle at its index: a fixed one, an edge or a regular value."""
        if self.values:
            return self.values[index]
        regulars = self._regulars()
        if index == 0:
            return _clean(self.minimum)
        if index > len(regulars):
            return _clean(self.maximum)
        return self._regular(regulars[index - 1])

    @property
    def numeric(self) -> bool:
        """Return True for a middle of numbers (linear, logarithmic, fixed numbers), False for fixed values of other kinds (an enum)."""
        return all(isinstance(_value(item), (int, float)) for item in self.values)

    @property
    def last(self) -> int:
        """Return the last position (the first one is 0)."""
        return len(self.low) + self._count() + len(self.high) - 1

    def _item(self, position: int) -> Any:
        """Return the item at the position: a `ScaleValue` (an end, an enum) or a number."""
        if not 0 <= position <= self.last:
            raise IndexError(f'no position {position} in the scale 0..{self.last}')
        index, count = position - len(self.low), self._count()
        if index < 0:
            return self.low[position]
        if index >= count:
            return self.high[index - count]
        return self._middle(index)

    def value_at(self, position: int) -> Any:
        """Return the value at the position (stored: the value of a special or fixed one, a number)."""
        return _value(self._item(position))

    def text(self, position: int) -> str:
        """Return the text of the value at the position: the label of a value with one, else the number by `format`."""
        return _label(self._item(position), self.format)

    def number_text(self, number: float) -> str:
        """Return the text of a number by `format` (also one of no position: e.g. a value off the steps of a linear middle)."""
        return _label(number, self.format)

    def position_of(self, value: Any, positions: range | None = None) -> int:
        """
        Return the position of the value in the positions (all by default; a knob of a range: `knob_positions()`): the first one of
        an equal special or fixed value, else the nearest number of the middle (a logarithmic one: the nearest in the logarithm), kept
        in the positions. A value of no position and no number raises ValueError.
        """
        if positions is None:
            positions = range(self.last + 1)
        start, count = len(self.low), self._count()
        exact = [*range(start), *range(start + count, self.last + 1), *(range(start, start + count) if self.values else ())]
        found = next((pos for pos in exact if pos in positions and self.value_at(pos) == value), None)
        if found is not None:
            return found
        if not isinstance(value, (int, float)):
            raise ValueError(f'not a value of the scale: {value!r}')
        return min(max(start + self._nearest(value), positions.start), positions.stop - 1)

    def _nearest(self, number: float) -> int:
        """Return the index of the middle of the nearest number (a logarithmic middle: the nearest in the logarithm)."""
        if self.values:
            values = [_value(item) for item in self.values]
            indexes = [index for index, value in enumerate(values) if isinstance(value, (int, float))]
            if not indexes:
                raise ValueError(f'no numbers in the scale for {number!r}')
            return min(indexes, key=lambda index: abs(values[index] - number))
        low, high = 0, self._count() - 1
        while low < high:  # the first index of a number not below it (the last one if none)
            middle = (low + high) // 2
            if self._middle(middle) < number:
                low = middle + 1
            else:
                high = middle
        if low > 0 and self._distance(self._middle(low - 1), number) <= self._distance(self._middle(low), number):
            return low - 1
        return low

    def knob_positions(self, knob: Literal['min', 'max'], other: int | None = None) -> range:
        """
        Return the positions of a knob of a range on the scale: the minimum one has none of the high end, the maximum one none of the
        low end, each none past its limit (`knob_min_most`, `knob_max_least`); with the position of the other knob, up to it (minimum) or from it
        (maximum) - the order of the positions, not of the values (the maximum off at the high end is above every number).
        """
        if knob == 'min':
            stop = self.last + 1 - len(self.high)
            if self.knob_min_most is not None:
                stop = min(stop, self.position_of(self.knob_min_most) + 1)
            return range(0, stop if other is None else min(stop, other + 1))
        start = len(self.low)
        if self.knob_max_least is not None:
            start = max(start, self.position_of(self.knob_max_least))
        return range(start if other is None else max(start, other), self.last + 1)

    def range_positions(self, low: Any, high: Any) -> tuple[int, int]:
        """
        Return the positions of the knobs of a range of the values (`position_of()`): the minimum one in its positions, the maximum one
        in its positions from there (`knob_positions()`).
        """
        first = self.position_of(low, self.knob_positions('min'))
        return first, self.position_of(high, self.knob_positions('max', first))

    def range_text(self, low: int, high: int) -> str:
        """
        Return the text of a range of the positions low..high (the knobs of a range): an end at its special value bounds nothing
        (`≥ 1 GB`: the maximum one, `≤ 50 GB`: the minimum one, `any`: both), one value once, else both (`1–50 GB`: their common unit
        - the text after the last digit - once).
        """
        free_low, free_high = low < len(self.low), high > self.last - len(self.high)
        if free_low and free_high:
            return L(30772, 'any')
        if free_high:
            return L(30773, '≥ {value}', value=self.text(low))
        if free_low:
            return L(30774, '≤ {value}', value=self.text(high))
        one, other = self.text(low), self.text(high)
        if one == other:
            return one
        if (unit := _unit(one)) and unit == _unit(other):
            one = one[:-len(unit)]
        return f'{one}–{other}'

    def _tick(self, position: int) -> Tick | None:
        """Return the tick at the position (None: none)."""
        item, index, count = self._item(position), position - len(self.low), self._count()
        at = position / self.last if self.last > 0 else 0.0
        if not 0 <= index < count:
            return Tick(at, True, item.label)
        if self.values:
            number = index
        elif 0 < index < count - 1:
            number = self._regulars()[index - 1]
        elif self.log or self.minor or self.major:  # an edge of a scale with ticks
            return Tick(at, True, _label(item, self.tick_format))
        else:  # an edge of a linear scale without ticks
            return None
        if self.major:
            major = number % self.major == 0
        else:
            major = bool(self.values) or (bool(self.log) and math.log10(item).is_integer())
        if major:
            return Tick(at, True, _label(item, self.tick_format))
        if (number % self.minor == 0) if self.minor else bool(self.values or self.log):
            return Tick(at, False)
        return None

    def ticks(self) -> tuple[Tick, ...]:
        """Return the ticks of the scale: minor ones, major ones with labels, the special values (major, with their labels)."""
        return tuple(tick for position in range(self.last + 1) if (tick := self._tick(position)))

    def page(self, position: int, direction: int) -> int:
        """
        Return the position of a big step (Page up / down) from the position in the direction (1 up, -1 down): the next major tick
        (the ends of the scale if none), a linear scale without `major`: `PAGE_STEPS` positions.
        """
        if not (self.major or self.values or self.log):
            return min(max(position + direction * PAGE_STEPS, 0), self.last)
        end = self.last if direction > 0 else 0
        return next((pos for pos in range(position + direction, end + direction, direction) if (tick := self._tick(pos)) and tick.major), end)


def _clean(number: float) -> float:
    """Return the number without the float noise (`0.3` not `0.30000000000000004`), an int if it is whole (`2` not `2.0`)."""
    number = round(number, 10)
    return int(number) if number == int(number) else number


def _unit(text: str) -> str:
    """Return the unit of the text of a number: the text after its last digit ('' none, no digit)."""
    return match.group(1) if (match := re.search(r'\d(\D+)$', text)) else ''


def _value(item: Any) -> Any:
    """Return the value of an item of a scale (a `ScaleValue` or a number)."""
    return item.value if isinstance(item, ScaleValue) else item


def _label(item: Any, number_text: NumberText) -> str:
    """Return the text of an item of a scale: the label of a `ScaleValue`, else the number by the template or the function."""
    if isinstance(item, ScaleValue):
        return item.label
    return number_text(item) if callable(number_text) else number_text.format(item)
