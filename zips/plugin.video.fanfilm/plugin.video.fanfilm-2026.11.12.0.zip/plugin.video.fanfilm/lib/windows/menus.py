"""
The menus of the configuration window (its page: `lib.windows.widgets.menus`): the fixed entries of the menus of folders in a
tree (`lib.ff.menu_entries`, collapsed), a row shown / hidden (its check), moved up / down in its menu (the buttons of the row),
the default order of a menu (the context menu of a row); every change is written at once. A hidden menu keeps the switches of
its entries (dimmed).
"""

from __future__ import annotations
from typing import Callable, ClassVar, Sequence, TYPE_CHECKING
from .tree import TreeModel, TreeView
from ..ff import menu_entries as me
from ..ff.config import config
from ..ff.item import FFItem
from ..kolang import L
if TYPE_CHECKING:
    from ..ff.menu import ContextMenuItem

#: The buttons of a row.
ROW_BUTTONS: tuple[str, ...] = ('check', 'up', 'down')
#: The width of the tree.
WIDTH = 1000


class MenusTabLogic:
    """
    The state and the logic of the menus, shown by the page of widgets (`lib.windows.widgets.menus`): the model of the tree,
    the changes (written at once), the help of the tree; the class showing them gives the tree (`view`).
    """

    #: The configuration branches of the page (its defaults restored = these removed).
    DEFAULTS: ClassVar[tuple[str, ...]] = (me.MENUS_CONFIG,)

    if TYPE_CHECKING:
        #: The tree.
        view: TreeView

    def init_logic(self) -> None:
        """No entries read yet (`load()`)."""
        #: The keys of the entries of the tree (by `id()` of their items).
        self.keys: dict[int, str] = {}

    def load(self) -> TreeModel:
        """Read the entries in the user order and their switches, return the model of the tree."""
        self.keys = {}
        roots = self.items(me.MAIN)
        items = self.all_items(roots)
        return TreeModel(roots, selected=[it for it in items if me.entry_shown(self.keys[id(it)])], own_nodes=True,
                         defaults=[it for it in items if me.MENU_ENTRY[self.keys[id(it)]].default], key=lambda it: self.keys[id(it)])

    def reload(self) -> None:
        """Read the entries again (the defaults restored), show the tree from the same row."""
        pos = self.view.position()
        self.view.model = self.load()
        self.view.show_rows(max(0, min(pos, len(self.view.model.rows) - 1)))

    def items(self, menu: str) -> list[FFItem]:
        """Return the items of the entries of the menu in the user order (a node with its entries)."""
        from ..ff.theme import art
        result: list[FFItem] = []
        for key in me.menu_order(menu):
            entry = me.MENU_ENTRY[key]
            item = FFItem(entry.label())
            if entry.thumb:
                item.setArt({'icon': art(entry.thumb)})  # in the variant of its row: the tree (`surface_art()`)
            if me.entries_of(key):
                item.children_items = self.items(key)
            self.keys[id(item)] = key
            result.append(item)
        return result

    def all_items(self, items: Sequence[FFItem]) -> list[FFItem]:
        """Return the items with all their entries (depth first)."""
        return [it for item in items for it in (item, *self.all_items(item.children_items or ()))]

    # --- changes (written at once) ---

    def checked(self, items: Sequence[FFItem]) -> None:
        """Entries shown / hidden (a branch: written once)."""
        with config.batch():
            for item in items:
                me.set_entry_shown(self.keys[id(item)], id(item) in self.view.model.selected)

    def moved(self, item: FFItem) -> None:
        """An entry moved: the order of its menu."""
        key = self.keys[id(item)]
        me.set_menu_order(me.MENU_ENTRY[key].parent, [self.keys[id(it)] for it in self.view.model.siblings(item)])

    def default_order(self, pos: int) -> None:
        """Set the default order of the menu of the row (its siblings), show it."""
        model = self.view.model
        item = model.rows[pos].item
        menu = me.MENU_ENTRY[self.keys[id(item)]].parent
        me.set_menu_order(menu, [entry.key for entry in me.entries_of(menu)])
        siblings = model.siblings(item)
        order = {key: n for n, key in enumerate(me.menu_order(menu))}
        siblings.sort(key=lambda it: order[self.keys[id(it)]])
        model.rows = model.flatten()
        self.view.show_rows(next(n for n, row in enumerate(model.rows) if row.item is item))

    def extra_menu(self, pos: int) -> list[ContextMenuItem]:
        """The context menu of a row: the default order of its menu (if it is not)."""
        item = self.view.model.rows[pos].item
        menu = me.MENU_ENTRY[self.keys[id(item)]].parent
        if me.menu_order(menu) == [entry.key for entry in me.entries_of(menu)]:
            return []
        return [(L(30195, 'Default order'), lambda: self.default_order(pos))]

    # --- help ---

    def tree_help(self, control_id: int) -> str:
        """Return the help of the tree or of a button of the selected row."""
        if text := self.view.filter_help(control_id):
            return text
        if (pos := self.view.position()) < 0:
            return ''
        row = self.view.model.rows[pos]
        path = ' / '.join(it.getLabel() for it in (*reversed(list(self.view.model.ancestors(row.item))), row.item))
        if text := self.view.help_of(control_id):
            return f'{path}: {text}'
        return L(30329, '{path}: OK - show / hide (a menu: expand / collapse), right - the buttons of the row.').format(path=path)
