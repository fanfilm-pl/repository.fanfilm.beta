"""
The absolute geometry of the controls of a generated window XML (the root of the output of `render_xml()`), by the rules
of Kodi (K21 = K22):

- a position of `left` / `right` / `centerleft` / `centerright` / `width` (and so for the height), a number, `N%` of the
  parent size or `Nr` (the parent size minus N); an empty tag is no tag (`CGUIControlFactory::ParsePosition()`,
  `GetDimensions()`);
- the parent of a control is its group (`group`, `grouplist`), else the window of 1920x1080 (the 1080i folder) at its
  `<coordinates>` (`left`, `top`), `CGUIWindow::LoadControl()`; only groups have child controls (`IsGroup()`): the
  item layouts of a list / panel are not controls of the window;
- a `grouplist` stacks its children in their order, `itemgap` (default 5) between them, by its `align` (`center`, `justify`,
  `right` / `bottom`) only when they are smaller than it; a child at 0, 0 unless `usecontrolcoords` (then its position
  is kept and is a part of its size in the stack), `CGUIControlGroupList::AddControl()`, `Process()`.

The state of the window (its skin conditions) is given by a `condition` evaluator; without it every control is shown (a
child of a grouplist with a `<visible>` condition takes its place in the stack) and no conditional slide animation is
applied. With it a control is hidden unless all its `<visible>` conditions hold (a hidden child of a grouplist takes no
place) and the conditional slide animations whose condition holds move the control (and its children). The scroll of a
grouplist is 0, `auto` sizes are their `max`, other animations (focus, visible…) are not applied.
"""

from __future__ import annotations
from typing import Callable, Iterator, TYPE_CHECKING
from itertools import combinations
import re
from xml.etree import ElementTree as ET
from attrs import evolve, frozen
from .geom import Point, Rect, Size
from .layout import CONTAINER_TYPES, DIRECTIONS, LIST_LAYOUTS
if TYPE_CHECKING:
    from typing_extensions import TypeAlias

#: The size of the window coordinates (`m_coordsRes` of the window: the 1080i folder of the skin).
WINDOW_SIZE: Size = Size(1920, 1080)
#: The most of the width of the window a popup card may take (a drop-down list wider than its field: `PopupWidget.popup_span()`), in the middle of
#: it - the rest the optical margins at both sides (`apply_overlays()` shifts a wider card into them).
POPUP_ROOM: float = 0.9
#: The default `itemgap` of a grouplist (`buttonGap` of `CGUIControlFactory::Create()`).
ITEM_GAP: float = 5.0
#: The leading number of a position (`strtod()`), its suffix (`r`, `%`) after it.
RX_NUMBER: re.Pattern[str] = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')

#: An evaluator of a skin condition (the state of the window): True if the condition holds.
Condition: TypeAlias = 'Callable[[str], bool]'


@frozen
class _Span:
    """A position and a size of a control on one axis (float, as Kodi has them)."""

    #: The position in the parent.
    start: float
    #: The size.
    size: float


@frozen
class _Box:
    """The absolute float rectangle of a control (rounded to a `Rect` at the end)."""

    #: The left edge.
    x: float
    #: The top edge.
    y: float
    #: The width.
    width: float
    #: The height.
    height: float

    def rect(self) -> Rect:
        """Return the rectangle in pixels."""
        return Rect(Point(round(self.x), round(self.y)), Size(round(self.width), round(self.height)))


@frozen(kw_only=True)
class OverlayPlace:
    """
    Where an overlay of a widget lies (`apply_overlays()`), for Python: the side of its card and the room of the card where it is surely
    shown (the window; in a grouplist the part Kodi surely shows after its scroll: `_sure_region()`) - Python sizes the card to it.
    """

    #: The side of the card: S under its field, N over it (a row: Python chooses it at the current row, `row_info`).
    side: str
    #: The room of the card by its sides (S, N) from the field: one side (the chosen one) of a control, both of a row at the first row of its list.
    room: dict[str, int]
    #: A row: the info of the list of the place of the current row on the vertical axis (`Container(<id>).<info>`: Position, Row), '' none.
    row_info: str = ''
    #: A row: the step of a row along the vertical axis (the room under the field shrinks by it each row down, the room over it grows).
    row_step: int = 0


def _number(text: str) -> float:
    """Return the leading number of the text (`strtod()`: 0 when there is none)."""
    found = RX_NUMBER.match(text)
    return float(found.group()) if found else 0.0


def parse_position(text: str, parent: float) -> float:
    """Return the position of the text in the parent of the size: `N`, `N%` of the parent, `Nr` = parent - N (`ParsePosition()`)."""
    text = text.strip()
    found = RX_NUMBER.match(text)
    value = float(found.group()) if found else 0.0
    suffix = text[found.end() if found else 0:][:1]
    if suffix == 'r':
        return parent - value
    if suffix == '%':
        return value * parent / 100
    return value


def _position(elem: ET.Element, tag: str, parent: float) -> float | None:
    """Return the position of the tag of the control, None if there is no tag (or it is empty)."""
    text = (elem.findtext(tag) or '').strip()
    return parse_position(text, parent) if text else None


def _dimension(elem: ET.Element, tag: str, parent: float) -> float | None:
    """Return the size of the tag of the control (`auto`: its `max`), None if there is no tag (`GetDimension()`)."""
    node = elem.find(tag)
    text = (node.text or '').strip() if node is not None else ''
    if not text:
        return None
    if text[:4].lower() == 'auto':
        return parse_position(node.get('max') or '', parent)  # type: ignore[union-attr]
    return parse_position(text, parent)


def _span(elem: ET.Element, parent: float, *, near: str, far: str, center: str, center_far: str, size: str) -> _Span:
    """Return the position and the size of the control on one axis in the parent (`GetDimensions()` + its fallback in `Create()`)."""
    start = _position(elem, near, parent)
    middle = _position(elem, center, parent)
    if middle is None and (middle := _position(elem, center_far, parent)) is not None:
        middle = parent - middle
    end = _position(elem, far, parent)
    if end is not None:
        end = parent - end
    length = _dimension(elem, size, parent)
    if start is None:
        if middle is not None:
            if length is not None:
                start = middle - length / 2
            elif end is not None:
                length = (end - middle) * 2
                start = end - length
        elif end is not None and length is not None:
            start = end - length
    if length is None:
        if end is not None:
            start = start or 0.0
            length = max(0.0, end - start)
        elif middle is not None:
            if start is not None:
                length = max(0.0, (middle - start) * 2)
            elif 0 < middle < parent:
                length = max(0.0, min(parent - middle, middle) * 2)
                start = middle - length / 2
        elif start is not None:
            length = max(0.0, parent - start)
    if start is None or length is None:  # no dimensions: from 0 (`posx` / `posy` not used by FF), the rest of the parent
        start = 0.0
        if not length:
            length = parent
    return _Span(start, length)


def _local(elem: ET.Element, parent: _Box) -> _Box:
    """Return the rectangle of the control in its parent (relative to it)."""
    x = _span(elem, parent.width, near='left', far='right', center='centerleft', center_far='centerright', size='width')
    y = _span(elem, parent.height, near='top', far='bottom', center='centertop', center_far='centerbottom', size='height')
    return _Box(x.start, y.start, x.size, y.size)


def _slid(elem: ET.Element, box: _Box, condition: Condition | None) -> _Box:
    """Return the box moved by the conditional slide animations of the control whose condition holds."""
    if condition is None:
        return box
    for anim in elem.findall('animation'):
        kind = anim.get('type') or (anim.text or '').strip()
        if anim.get('effect') == 'slide' and kind.lower() == 'conditional' and condition(anim.get('condition') or 'true'):
            end_x, _sep, end_y = (anim.get('end') or '').partition(',')
            box = evolve(box, x=box.x + _number(end_x.strip()), y=box.y + _number(end_y.strip()))
    return box


def _shown(elem: ET.Element, condition: Condition | None) -> bool:
    """Return True if the control is shown: all its `<visible>` conditions hold (every control without an evaluator)."""
    return condition is None or all(condition(text) for vis in elem.findall('visible') if (text := (vis.text or '').strip()))


def _controls(group: ET.Element, box: _Box, condition: Condition | None) -> Iterator[tuple[ET.Element, _Box]]:
    """Yield the controls of the group (or of the window) at the box, with their absolute boxes, in the document order."""
    children = [child for child in group if child.tag == 'control']
    local = [_local(child, box) for child in children]
    stacked = group.get('type') == 'grouplist'
    vertical = (group.findtext('orientation') or '').strip() != 'horizontal'
    gap_text = (group.findtext('itemgap') or '').strip()
    gap = _number(gap_text) if gap_text else ITEM_GAP
    if stacked and (group.findtext('usecontrolcoords') or '').strip().lower() != 'true':  # the children of a grouplist at 0, 0
        local = [evolve(rel, x=0.0, y=0.0) for rel in local]

    def extent(rel: _Box) -> float:
        """Return the size of the child in the stack of the grouplist (its position too: 0 unless `usecontrolcoords`)."""
        return rel.y + rel.height if vertical else rel.x + rel.width

    pos = 0.0
    if stacked:
        sizes = [extent(rel) for child, rel in zip(children, local) if _shown(child, condition)]
        total = sum(sizes) + gap * max(0, len(sizes) - 1)
        room = box.height if vertical else box.width
        align = (group.findtext('align') or '').strip()
        if total < room:
            if align in ('right', 'bottom'):
                pos = room - total
            elif align in ('center', 'justify'):
                pos = (room - total) / 2
    for child, rel in zip(children, local):
        left, top = box.x + rel.x, box.y + rel.y
        if stacked:
            if vertical:
                top += pos
            else:
                left += pos
            if _shown(child, condition):  # a hidden child takes no place (it is where the next one is)
                pos += extent(rel) + gap
        child_box = _slid(child, _Box(left, top, rel.width, rel.height), condition)
        yield child, child_box
        if child.get('type') in CONTAINER_TYPES:  # the controls with child controls (Kodi `IsGroup()`)
            yield from _controls(child, child_box, condition)


def element_rects(root: ET.Element, *, condition: Condition | None = None) -> dict[ET.Element, Rect]:
    """
    Return the absolute rectangles of all controls of the generated window (the root of the output XML) by their elements,
    in the document order (also the controls without an ID). The `condition` evaluates the skin conditions of the window
    state (`<visible>`, conditional slide animations): none = all controls shown, no slide.
    """
    controls = root.find('controls')
    return {elem: box.rect() for elem, box in _controls(root if controls is None else controls, _window_box(root), condition)}


def _window_box(root: ET.Element) -> _Box:
    """Return the box of the window of the generated XML: its size at its `<coordinates>`."""
    return _Box(_number((root.findtext('coordinates/left') or '').strip()), _number((root.findtext('coordinates/top') or '').strip()),
                WINDOW_SIZE.width, WINDOW_SIZE.height)


def control_rects(root: ET.Element, *, condition: Condition | None = None) -> dict[int, Rect]:
    """Return the absolute rectangles of the controls of the generated window by their IDs (the controls with an ID)."""
    return {int(cid): rect for elem, rect in element_rects(root, condition=condition).items() if (cid := elem.get('id') or '').isdecimal()}


def rect_of(root: ET.Element, cid: int, *, condition: Condition | None = None) -> Rect:
    """Return the absolute rectangle of the control of the ID in the generated window (KeyError if there is none)."""
    return control_rects(root, condition=condition)[cid]


def _row_boxes(layout: ET.Element, size: Size) -> dict[ET.Element, _Box]:
    """Return the boxes of the controls of a layout of a row of a list (in the row), the size of the list given (its own if the layout has none)."""
    return dict(_controls(layout, _Box(0, 0, float(layout.get('width') or size.width), float(layout.get('height') or size.height)), None))


def row_rects(layout: ET.Element, size: Size) -> dict[ET.Element, Rect]:
    """Return the rectangles of the controls of a layout of a row of a list in the row, the size of the list given (`_row_boxes()`)."""
    return {elem: box.rect() for elem, box in _row_boxes(layout, size).items()}


#: The alignments of the left label of a pair Kodi cuts (`overlapping_row_labels()`: `align & 3 == 0` - neither right nor centred).
LEFT_ALIGNS: frozenset[str] = frozenset({'', 'left', 'justify'})


def overlapping_row_labels(root: ET.Element) -> Iterator[tuple[ET.Element, ET.Element]]:
    """
    Yield the pairs of labels of one group of a row of a list - a left one and a right one (`<align>right</align>`) - overlapping in
    their places (every control shown, no slide): Kodi (K21 = K22: `CGUIListGroup::UpdateInfo()`, `CGUILabel::CheckAndCorrectOverlap()`)
    cuts both at the middle of their places - the left one ends far before the right one, the right one gets a negative width (drawn
    whole, but nothing while it scrolls: in a focused row). The layout of a row and its `group`s check their own labels (a grouplist
    none): a label in a group of its own is out of its reach.
    """
    for lst, rect in element_rects(root).items():
        for layout in lst:
            if layout.tag not in LIST_LAYOUTS:
                continue
            boxes = _row_boxes(layout, rect.size)
            for group in (layout, *(elem for elem in boxes if elem.get('type') == 'group')):
                labels = [child for child in group if child.tag == 'control' and child.get('type') == 'label']
                for pair in combinations(labels, 2):
                    left, right = sorted(pair, key=lambda elem: boxes[elem].x)
                    one, other = boxes[left], boxes[right]
                    if ((left.findtext('align') or '').strip() in LEFT_ALIGNS and (right.findtext('align') or '').strip() == 'right'
                            and one.x < other.x + other.width and other.x < one.x + one.width
                            and one.y < other.y + other.height and other.y < one.y + one.height):
                        yield left, right

#: The tags of the dimensions of a control on an axis (`GetDimensions()`: two of them place it, the other ones are dropped).
AXIS_TAGS: tuple[tuple[str, ...], ...] = (('left', 'centerleft', 'centerright', 'right', 'width'), ('top', 'centertop', 'centerbottom', 'bottom', 'height'))


def overconstrained_controls(root: ET.Element) -> Iterator[tuple[ET.Element, tuple[str, ...]]]:
    """
    Yield the controls with more than two dimensions on an axis (`AXIS_TAGS`, e.g. left, right and width) and those tags: Kodi takes
    two of them (`GetDimensions()`: the start and the size first) and drops the others silently - which numbers win is not seen in
    the window, and they rarely add up (an empty tag: none).
    """
    for ctl in root.iter('control'):
        for tags in AXIS_TAGS:
            if len(given := tuple(tag for tag in tags if (ctl.findtext(tag) or '').strip())) > 2:
                yield ctl, given


#: The list item of a row in a condition (`ListItem.Label`; not `Container(<id>).ListItem.Label`): an overlay of a row reads the current
#: item of its list (`_kept_conditions()`).
RX_ROW_ITEM: re.Pattern[str] = re.compile(r'(?<![\w.])ListItem\.')
#: The template attribute of an overlay (`apply_overlays()`): the ID of the control it belongs to, `row` - of the current row of its list.
OVERLAY_ATTR: str = '{ff}overlay'
#: The overlay of the current row of a list (`OVERLAY_ATTR`).
ROW_OVERLAY: str = 'row'
#: The template attribute of the `visible` of a look of the current row (the focused layout of a list drawn by the focus of the list:
#: `<ff:delegate focus="…">`): no condition of the place of an overlay of the row (`_kept_conditions()`), the overlay is not a look.
ROW_LOOK_ATTR: str = '{ff}row-look'
#: The attribute of a part of an overlay of a control drawn on one side of it only (S: the overlay under the control, N: over it; the
#: open edge of a drop-down list towards its field): `apply_overlays()` keeps the parts of the side it chose.
OVERLAY_SIDE_ATTR: str = '{ff}overlay-side'


#: The template attribute of the layer of a control among its siblings (`apply_layers()`).
LAYER_ATTR: str = '{ff}layer'
#: The layers of the controls of a group in their drawing order (Kodi draws the children of a group in their order: the later ones
#: over the earlier ones): `back` - the fill of the host (the states of a row, the surface of a frame), `under` - under the content
#: (a bar of an edge), '' - the content, `over` - over it (a tag inside, a ribbon), `front` - the frame of the host (the frame of a row,
#: a focus ring), `edge` - on its edge over its frame (a tag sticking out of it: the frame runs under it, Qt: the title of a QGroupBox).
LAYERS: tuple[str, ...] = ('back', 'under', '', 'over', 'front', 'edge')
#: The layers of the anchored elements (a tag, an edge mark): a group with one orders its children by their layers (`apply_layers()`).
ANCHORED_LAYERS: frozenset[str] = frozenset({'under', 'over', 'edge'})


def apply_layers(root: ET.Element) -> None:
    """
    Order the children of every group with a control of the layer `under`, `over` or `edge` (`LAYER_ATTR`: a tag, an edge mark) by their layers
    (`LAYERS`, the order of a layer kept): Kodi draws them in that order. A group without one keeps its order (the windows without tags
    the same bytes); a laid out group (`ff:layout`: its order is its layout) is no host of a tag.
    """
    for parent in [elem for elem in root.iter() if any(child.get(LAYER_ATTR) in ANCHORED_LAYERS for child in elem)]:
        units: list[list[ET.Element]] = []  # a control with the comments before it (its source), the other elements alone
        comments: list[ET.Element] = []
        for child in parent:
            if child.tag is ET.Comment:
                comments.append(child)
            else:
                units.append([*comments, child])
                comments = []
        controls = iter(sorted((unit for unit in units if unit[-1].tag == 'control'), key=lambda unit: LAYERS.index(unit[-1].get(LAYER_ATTR, ''))))
        parent[:] = [elem for unit in units for elem in (next(controls) if unit[-1].tag == 'control' else unit)] + comments  # the others in place


#: The tags of the position of a control (`CGUIControlFactory::GetDimensions()`, the old `posx` / `posy` too).
POSITION_TAGS: tuple[str, ...] = ('left', 'top', 'right', 'bottom', 'centerleft', 'centerright', 'centertop', 'centerbottom', 'posx', 'posy')


def keep_grouplist_positions(root: ET.Element) -> None:
    """
    Give `usecontrolcoords` to every grouplist with a child of its own position (`POSITION_TAGS`, not 0; an explicit `usecontrolcoords`
    kept): Kodi puts every child of a grouplist at 0, 0 without it (`CGUIControlGroupList::AddControl()`), the inset of a label (`left`
    / `right`) or the centring of an image across the grouplist (`top`) would be lost; with it the position is kept and is a part of
    the size of the child in the stack, as in the grouplists of the layout (`layout.py`).
    """
    for grouplist in root.iter('control'):
        if grouplist.get('type') == 'grouplist' and grouplist.find('usecontrolcoords') is None and any(
                (child.findtext(tag) or '').strip() not in ('', '0') for child in grouplist.findall('control') for tag in POSITION_TAGS):
            ET.SubElement(grouplist, 'usecontrolcoords').text = 'true'


#: The template attribute of an element on a middle anchor of its host (a tag: `AnchorPlace.slots`), its slots centred as a group.
SLOTS_ATTR: str = '{ff}slots'
#: The value of `SLOTS_ATTR`: the anchor, the position tag along its edge, the slot after slot.
RX_SLOTS: re.Pattern[str] = re.compile(r'(?P<anchor>\w+) (?P<axis>left|top) (?P<step>\d+)')


def centre_slots(root: ET.Element) -> None:
    """
    Centre the slots of every middle anchor (a side, the centre) of a host as a group (`SLOTS_ATTR`: `<anchor> <axis> <step>`): the
    elements of one anchor among the children of a group - their places in their anchor points (the first control in each) - moved back
    along their edge by half of the slots after the first one (`anchor_place()` puts them from the middle to the right / down).
    """
    for parent in root.iter():
        groups: dict[str, list[ET.Element]] = {}
        for child in parent:
            if key := child.get(SLOTS_ATTR):
                groups.setdefault(key, []).append(child)
        for key, elems in groups.items():
            if not (slots := RX_SLOTS.fullmatch(key)) or len(elems) < 2:
                continue
            shift = (len(elems) - 1) * int(slots['step']) / 2
            for elem in elems:
                place = elem.find('control')
                node = place.find(slots['axis']) if place is not None else None
                if node is not None and node.text:
                    node.text = str(round(int(node.text) - shift))


#: The template attribute of the `movement` of a fixed list held at the start of its view (`focusposition` 0), its value `view`: the rows
#: in its view less one - the current row may go down to the end of the view at the end of the list (no empty view there; Kodi takes a
#: larger one as the row after its view), `fill_list_ends()`.
FILL_ATTR: str = '{ff}fill'


def fill_list_ends(root: ET.Element) -> None:
    """
    Set the `movement` of every fixed list held at the start of its view (`FILL_ATTR`): the rows in its view (its size along it after the
    layout, the size of a row and of the focused one: Kodi `CGUIBaseContainer::CalculateLayout()`) less one.
    """
    rects: dict[ET.Element, Rect] | None = None
    for lst in root.iter('control'):
        if (node := lst.find('movement')) is None or node.get(FILL_ATTR) != 'view':
            continue
        rects = element_rects(root) if rects is None else rects
        along = 'height' if (lst.findtext('orientation') or 'vertical').strip() != 'horizontal' else 'width'
        item, focused = lst.find('itemlayout'), lst.find('focusedlayout')
        row = float(item.get(along, 0)) if item is not None else 0
        focus = float(focused.get(along, row)) if focused is not None else row
        size = rects[lst].size.height if along == 'height' else rects[lst].size.width
        node.text = str(max(int((size - focus) // row) if row else 0, 0))  # the rows in view (Kodi: that + 1) less one


def _set_place(elem: ET.Element, left: float, top: float) -> None:
    """Set the position of the control (its other position tags removed; its size stays)."""
    for tag in POSITION_TAGS:
        for node in elem.findall(tag):
            elem.remove(node)
    for n, (tag, value) in enumerate((('left', left), ('top', top))):
        node = ET.Element(tag)
        node.text = str(round(value))
        node.tail = elem.text
        elem.insert(n, node)


def _row_overlay(overlay: ET.Element, parents: dict[ET.Element, ET.Element], boxes: dict[ET.Element, _Box]) -> tuple[_Box, list[ET.Element]]:
    """
    Return the box of an overlay of the current row (in the item layout of a list) on the first row of the list and its slides to the
    current row: by `Container(<id>).Position` (a vertical list down, a horizontal one right), a panel by its `Row` and `Column`.
    """
    chain: list[ET.Element] = []
    node = overlay
    while node.tag not in LIST_LAYOUTS:
        chain.append(node)
        node = parents[node]
    layout, lst = node, parents[node]
    base = boxes[lst]
    width, height = float(layout.get('width') or base.width), float(layout.get('height') or base.height)
    box = _Box(base.x, base.y, width, height)
    for elem in reversed(chain):
        rel = _local(elem, box)
        box = _Box(box.x + rel.x, box.y + rel.y, rel.width, rel.height)
    cid, vertical = lst.get('id'), (lst.findtext('orientation') or 'vertical').strip() != 'horizontal'
    slides: list[ET.Element] = []

    def slide(info: str, steps: int, dx: float, dy: float) -> None:
        """Add the slides of one step each for the positions of the info (`Container(<id>).<info>` above each step)."""
        for n in range(max(0, steps - 1)):
            anim = ET.Element('animation', effect='slide', end=f'{round(dx)},{round(dy)}', time='0',
                              condition=f'Integer.IsGreater(Container({cid}).{info},{n})')
            anim.text = 'Conditional'
            slides.append(anim)

    if lst.get('type') == 'panel':
        slide('Column', int(base.width // width), width, 0)
        slide('Row', int(base.height // height), 0, height)
    elif vertical:
        slide('Position', int(base.height // height), 0, height)
    else:
        slide('Position', int(base.width // width), width, 0)
    return box, slides


def _ancestors(elem: ET.Element, parents: dict[ET.Element, ET.Element]) -> Iterator[ET.Element]:
    """Yield the ancestors of the element, the nearest first."""
    while (elem := parents.get(elem)) is not None:  # type: ignore[assignment]
        yield elem


def _kept_conditions(control: ET.Element, parents: dict[ET.Element, ET.Element], *, stop: ET.Element | None = None) -> list[ET.Element]:
    """
    Return copies of the conditional slides and the visible conditions of a control and of its ancestors (an overlay of it moved to the
    end of the window goes on moving with them, e.g. a list slid down by a state of its window, and is shown only with them, e.g. on the
    page of a tab widget; Kodi ANDs the `visible` tags of a control, `CGUIControlFactory::GetConditionalVisibility()`). The conditions
    of a row (in the item layout of a list) read the current item of its list (`RX_ROW_ITEM`); a copy hides no focus of the overlay
    (no `allowhiddenfocus`: that one of its own `visible`); the look of a row is no condition of its place (`ROW_LOOK_ATTR`). `stop`: the
    ancestor the overlay goes in (its conditions and the ones of its ancestors hold for the overlay already), None: the window.
    """
    chain = [control, *_ancestors(control, parents)]
    if stop is not None:
        chain = chain[:chain.index(stop)]
    layout = next((n for n, node in enumerate(chain) if node.tag in LIST_LAYOUTS), 0)  # the nodes of a row before it
    item = f'Container({chain[layout + 1].get("id")}).ListItem.' if layout else ''
    kept: list[ET.Element] = []
    for n, node in enumerate(chain):
        for cond in node:
            if cond.get(ROW_LOOK_ATTR):
                continue
            if cond.tag == 'visible' or (cond.tag == 'animation' and cond.get('effect') == 'slide' and (cond.text or '').strip() == 'Conditional'):
                copy = ET.fromstring(ET.tostring(cond))
                copy.attrib.pop('allowhiddenfocus', None)
                if n < layout and copy.tag == 'visible':
                    copy.text = RX_ROW_ITEM.sub(item, copy.text or '')
                elif n < layout:
                    copy.set('condition', RX_ROW_ITEM.sub(item, copy.get('condition', '')))
                kept.append(copy)
    return kept


def _sure_region(node: ET.Element, parents: dict[ET.Element, ET.Element], boxes: dict[ET.Element, _Box],
                 window: _Box) -> tuple[_Box, ET.Element | None]:
    """
    Return where an overlay of the control `node` is surely shown and the child of the grouplist the overlay goes in (the nearest one around
    the control; None: no grouplist - the window, the overlay over it). Kodi scrolls a grouplist to show its focused child whole: its first
    child at the start, its last one at the end (`CGUIControlGroupList::OnMessage()`, GUI_MSG_FOCUSED), so the region of a child is the view
    of the grouplist then; of a child between them (the scroll by the way the focus came) the child itself, of any child of a grouplist
    which does not scroll (its children fit) or of a horizontal one the view (the static boxes: the grouplist not scrolled).
    """
    for child in (node, *_ancestors(node, parents)):
        if (grouplist := parents.get(child)) is not None and grouplist.get('type') == 'grouplist':
            break
    else:
        return window, None
    view = boxes[grouplist]
    shown = [ctl for ctl in grouplist if ctl.tag == 'control' and ctl in boxes]
    if (grouplist.findtext('orientation') or '').strip() == 'horizontal' or not shown:
        return view, child
    total = boxes[shown[-1]].y + boxes[shown[-1]].height - boxes[shown[0]].y
    if total <= view.height or child is shown[0]:
        return view, child
    if child is shown[-1]:  # scrolled to the end
        return evolve(view, y=view.y + total - view.height), child
    return boxes[child], child


def apply_overlays(root: ET.Element) -> dict[int, OverlayPlace]:
    """
    Move the overlays of the generated window (`OVERLAY_ATTR`: a drop-down list of a combo box) to the end of its controls - Kodi draws
    them over all the others - at their absolute places (the window after its layout); an overlay of a control in a grouplist to the end
    of the child of the grouplist around it instead (it scrolls with the child; Kodi draws the focused child last, the card over the
    others; a grouplist clips its children): `_sure_region()`. An overlay of a control (its ID) under it, or over it when its region has
    no room under it (the window: `WINDOW_SIZE`), with room for neither: in the window as low as the window lets it, in a grouplist on
    the side of more room (Python shortens the card to it) - the parts of the other side gone (`OVERLAY_SIDE_ATTR`); at the left of the
    control, one wider than it shifted left to end in the window margins (`POPUP_ROOM`); an overlay of the current row of a list
    (`ROW_OVERLAY`, in its item layout) on the first row and slid with the current one (`_row_overlay()`), its side chosen by Python at the
    current row; its focus moves out of the list go to the list, the button of its field is the move right of a list without its own,
    else gone (`_drop_row_button()`). An overlay keeps the conditional slides and the visible conditions of its control / its row and their
    ancestors (`_kept_conditions()`; in a grouplist up to the child it goes in). Return the places of the overlays (`OverlayPlace`) by the
    IDs of their controls (a row: by the IDs of its controls).
    """
    places: dict[int, OverlayPlace] = {}
    overlays = [elem for elem in root.iter() if elem.get(OVERLAY_ATTR)]  # '': none
    if not overlays:
        return places
    controls = root.find('controls')
    assert controls is not None
    window = _window_box(root)
    boxes = dict(_controls(controls, window, None))
    by_id = {elem.get('id'): elem for elem in boxes if elem.get('id')}
    parents = {child: parent for parent in root.iter() for child in parent}
    for overlay in overlays:
        anchor = overlay.attrib.pop(OVERLAY_ATTR)
        kept: list[ET.Element] = []  # the conditions of its place
        if anchor == ROW_OVERLAY:
            box, kept = _row_overlay(overlay, parents, boxes)
            left, top = box.x, box.y
            lst = next(node for node in _ancestors(overlay, parents) if node.get('type') in ('list', 'fixedlist', 'wraplist', 'panel'))
            region, host = _sure_region(lst, parents, boxes, window)
            info = 'Row' if lst.get('type') == 'panel' else '' if (lst.findtext('orientation') or '').strip() == 'horizontal' else 'Position'
            place = OverlayPlace(side='S', room={'S': round(region.y + region.height - box.y - box.height), 'N': round(box.y - region.y)},
                                 row_info=info, row_step=round(box.height))
            places.update((int(cid), place) for node in overlay.iter('control') if (cid := node.get('id', '')).isdecimal())
            if (button := overlay.find('.//control[@type="button"]')) is not None:
                if lst.find('onright') is None:  # the list leads there
                    ET.SubElement(lst, 'onright').text = button.get('id')
                else:
                    _drop_row_button(overlay, button, lst, parents)
            kept += _kept_conditions(parents[overlay], parents, stop=host)
        else:
            region, host = _sure_region(by_id[anchor], parents, boxes, window)
            kept = _kept_conditions(by_id[anchor], parents, stop=host)
            field = boxes[by_id[anchor]]
            height = _dimension(overlay, 'height', window.height) or 0.0
            below = field.y + field.height
            room = {'S': region.y + region.height - below, 'N': field.y - region.y}
            if height <= room['S']:
                top = below
            elif height <= room['N']:
                top = field.y - height
            elif host is None:  # no room under it nor over it: the most of it under the field, in the window
                top = max(window.y, window.y + window.height - height)
            else:  # in a grouplist: on the side of more room (the card shortened to it)
                top = below if room['S'] >= room['N'] else field.y - height
            left = field.x
            width = _dimension(overlay, 'width', window.width) or 0.0
            margin = window.width * (1 - POPUP_ROOM) / 2
            if width > field.width and left + width > window.x + window.width - margin:  # wider than its field: into the window margins
                left = max(window.x + margin, window.x + window.width - margin - width)
            side = 'S' if top >= field.y else 'N'
            places[int(anchor)] = OverlayPlace(side=side, room={side: round(room[side])})
            for part in [part for part in overlay.iter() if part.get(OVERLAY_SIDE_ATTR, side) != side]:
                parents[part].remove(part)
        parents[overlay].remove(overlay)
        origin = window if host is None else boxes[host]
        _set_place(overlay, left - origin.x, top - origin.y)
        for cond in kept:
            overlay.append(cond)
        (controls if host is None else host).append(overlay)
    return places


def _drop_row_button(overlay: ET.Element, button: ET.Element, lst: ET.Element, parents: dict[ET.Element, ET.Element]) -> None:
    """
    Remove the button of the field of a row overlay of a list with its own move right (OK on a row opens the card): the keys never
    reach it, the mouse would focus the field instead of the row - its group (the button, its focus ring) gone, the moves of the
    overlay to it lead to the list.
    """
    group = parents[button]
    parents[group].remove(group)
    bid, list_id = button.get('id'), lst.get('id')
    for direction in DIRECTIONS:
        for node in overlay.iter(direction.tag):
            if (node.text or '').strip() == bid:
                node.text = list_id


def _main() -> None:
    """Print the controls of a window output XML: one line each (depth, type, ID, x, y, width, height), comparable before / after."""
    from argparse import ArgumentParser
    from pathlib import Path
    from .. import cmdline_argv  # the arguments of the command line (`sys.argv` is the one of the fake plugin call)
    parser = ArgumentParser(prog='python -m lib.windows.geometry', description='The absolute geometry of the controls of a window XML.')
    parser.add_argument('xml', type=Path, help='the output XML of a window (python -m lib.windows.render render <Class> -o <xml>)')
    args = parser.parse_args(cmdline_argv[1:])
    root = ET.parse(args.xml).getroot()
    rects = element_rects(root)
    depth = {elem: 0 for elem in rects}
    for elem in rects:
        for child in elem:
            if child in depth:
                depth[child] = depth[elem] + 1
    for elem, rect in rects.items():
        size = rect.size
        print(f'{"  " * depth[elem]}{elem.get("type") or "-":10s} {elem.get("id") or "-":>6s} {rect.left:5d} {rect.top:5d} {size.width:5d} {size.height:5d}')


if __name__ == '__main__':
    _main()
