"""
The focus lines of a generated window: many moves through a shared control instead of one edge a direction (Kodi has one
`<onright>` of a control; a line remembers the way the focus came).

A template declares a line anywhere in the window (or a widget) by the widget paths of its members, in the order of the
line, forward = right (a row) / down (a column):

- `<ff:focus_row path="@a @X @b"/>` - left <-> right, `<ff:focus_column path="…"/>` - up <-> down, `<ff:focus_line path="…"/>`
  - the axis from the geometry of the members (the dominant one of the moves between them; not one: an error);
- a member `@path` (a widget), `@path:name` (another control of the widget, `id_of(name)`), with a position of a list
  entered by the line (a suffix): `:first`, `:last`, `:edge` (the near one by the move: the first row moving forward, the last one
  moving back - rows of a form, one column of several lists), `:same` (the index of the selected row of the nearest list member before
  it on the way: `ListView` keeps it in every row of a list a line reads it of, `INDEX_PROPERTY`), or a position the widget
  keeps (`Widget.FOCUS_POSITIONS`: the window property `ffw.<id>.<name>`, `widgets.position_property()`); a position name wins
  over a control name;
- a member may be a group (a widget of a `group` / `grouplist` control): the line enters it as Kodi does (its last focused /
  default control), `@path:child` enters its child widget `path.child`; the moves of a group out of it are written on its
  controls on the edge of that side (`_edges()`: Kodi takes the moves of the focused control only, a group gives its own to
  no child; a grouplist gives its moves along its orientation to its end controls itself);
- the inner members are the nodes; a member repeated inside is an error, the same widget at both ends is a loop (its last move
  wraps); the lines go both ways (backward: the previous member).

The pass (after the layout: the control IDs and the geometry are known) gives every member the moves of its lines in their
directions. A move in a direction one line goes is plain Kodi navigation; more lines a direction (shared nodes): the line the
focus came by (the window property `ffw.<node>.line`, set by the move onto the node: Kodi runs the text actions of a move
before its target; the node clears it when it loses the focus - `onunfocus`, a thread message: after the move; a group node
when the focus leaves it - the window, `WidgetTree.focus()`: a move inside the group keeps the line), else (no line known: a
mouse, another control) the first line declared there, on an edge control of a group node the line nearest to that control
(as a move across). A move across the line the focus came by (up / down from a row node) takes the line across through the
node nearest to the side the focus came from (from the left: the leftmost column, from the top: the topmost row; by the mean
position of their members), the side in `ffw.<node>.from` only where the two sides take different lines; a group node: on
each of its edge controls the line across nearest to that control (as Kodi goes from the focused control; no side kept); no
line across that way: the navigation of the node. The own navigation of a control in a direction of its lines stays where
the lines are not taken:

- an own tag going to the member a line goes to, or to a group the member lies in, is that line's move under its own condition
  (the member chooses between its ways, e.g. a field above a list only while it is shown; a node shared by pages: its move to the
  page shown - a tag to the page takes the line of that page, a page with no line there keeps the tag: Kodi enters the page);
- a node with its own navigation in the direction goes by a line only when the focus came by it (its property), its own tags
  are the rest (under the negation of the lines: disjoint);
- else (no own tags, an end with no own way to its line) the lines own the direction: its own tags removed (the other
  directions stay as they are);
- an own tag going to the control itself is Kodi's own move inside it (a list / panel wraps at its end): the lines do not
  take that direction of the control (the back move of a loop through a panel which wraps its rows).

A line no move can ever take (in either direction, along it or across) is a warning.

The guide for the authors of windows (when to use which declaration, examples, the limits): `notes/gui-xgui-merge.md`,
the section "Linie fokusu — jak używać".
"""

from __future__ import annotations
from typing import Callable, Iterator, Sequence, TYPE_CHECKING
import re
from xml.etree import ElementTree as ET
from attrs import frozen
from ..ff.logs import fflog
from .layout import CONTAINER_TYPES, FOCUSABLE_TYPES
from .widgets import LINE_GROUP, line_property, position_property, widget_class
from .xgui import KODI_WINDOW_IDS, SRC_ATTR, TemplateError
if TYPE_CHECKING:
    from .geom import Rect
    from .xgui import WidgetEntry


#: A position past the end of every list: Kodi `SetFocus(<list>,<pos>,absolute)` takes the last item for it (`row_focus()`).
LAST_ROW = 1_000_000


def row_focus(list_id: int, *, last: bool) -> str:
    """Return the Kodi action focusing the list on its first / last row (a navigation target, e.g. `<onup>`)."""
    return f'SetFocus({list_id},{LAST_ROW if last else 0},absolute)'


@frozen
class Axis:
    """
    An axis of a line: its name, the navigation tags forward (right / down: the order of the members) and backward, the sides a
    move comes from (a move forward from the start one), the coordinate of the center along it (0: x, 1: y).
    """

    #: The name (the declaration `ff:focus_<name>`).
    name: str
    #: The navigation tag of a move forward.
    forward: str
    #: The navigation tag of a move backward.
    backward: str
    #: The side a move forward comes from.
    start: str
    #: The side a move backward comes from.
    end: str
    #: The coordinate of a center along the axis.
    coord: int


#: The axis of a row: left <-> right.
ROW: Axis = Axis('row', 'onright', 'onleft', 'left', 'right', 0)
#: The axis of a column: up <-> down.
COLUMN: Axis = Axis('column', 'ondown', 'onup', 'top', 'bottom', 1)
#: The declarations of the lines: their tags and axes (None: the axis from the geometry).
LINE_TAGS: dict[str, Axis | None] = {'{ff}focus_line': None, '{ff}focus_row': ROW, '{ff}focus_column': COLUMN}
#: The positions of a list member every list has (`:first`, `:last`, `:edge`, `:same`).
LIST_POSITIONS: frozenset[str] = frozenset({'first', 'last', 'edge', 'same'})
#: The Kodi types of the lists (a position of a member selects their item).
LIST_TYPES: frozenset[str] = frozenset({'list', 'panel', 'fixedlist', 'wraplist'})
#: A member of a line: `@path`, then `:name` (a control of the widget) and / or `:position`.
RX_MEMBER: re.Pattern[str] = re.compile(r'@([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)((?::[\w.]+){0,2})')
#: An operator of a Kodi condition (`+`, `|`: a compound one).
RX_OPERATOR: re.Pattern[str] = re.compile(r'[+|]')


@frozen(kw_only=True)
class Member:
    """A member of a line: its reference, its control, the position of a list the line enters ('' Kodi's current one)."""

    #: The reference in the declaration (`@tabs.list:last`).
    ref: str
    #: The control ID.
    id: int
    #: The position entered: `first`, `last`, `same`, a widget position, '' none.
    pos: str = ''
    #: The control entered inside a group member (its child widget, `@path:child`), 0: the member itself.
    entry: int = 0


@frozen(kw_only=True)
class FocusLine:
    """A line of a window: its key (the window property value of a node), its axis, its members (forward), its declaration."""

    #: The key: the number of the declaration in the window (from 1).
    key: str
    #: The axis.
    axis: Axis
    #: The members, forward.
    members: tuple[Member, ...]
    #: The position of the declaration (`path:line`).
    src: str = ''

    def is_node(self, index: int) -> bool:
        """Return True if the member of the index is a node: an inner member."""
        return 0 < index < len(self.members) - 1

    def across(self, coord: int, centers: dict[int, tuple[float, float]]) -> float:
        """Return the position of the line across its axis: the mean coordinate of the centers of its members (`coord` 0: x, 1: y)."""
        return sum(centers[member.id][coord] for member in self.members) / len(self.members)


@frozen(kw_only=True)
class Move:
    """A move of a line from a member to the next / previous one."""

    #: The line.
    line: FocusLine
    #: The control the move leaves.
    source: int
    #: The navigation tag.
    tag: str
    #: The member entered.
    target: Member
    #: The navigation action (a control ID, `SetFocus(…)` with a position).
    action: str
    #: The move leaves a node of the line (only its line takes it when more lines go that way).
    from_node: bool
    #: The move enters a node of the line.
    to_node: bool

    @property
    def side(self) -> str:
        """Return the side of its target the move comes from (`Axis.start` / `end`)."""
        return self.line.axis.start if self.tag == self.line.axis.forward else self.line.axis.end


@frozen
class Entry:
    """A way the focus came onto a node: by the line of the key, from the side ('' any)."""

    #: The key of the line.
    line: str
    #: The side the focus came from ('' any).
    side: str = ''


@frozen(kw_only=True)
class Keyed:
    """A move of a node taken only by the ways the focus came onto the node (its properties)."""

    #: The move.
    move: Move
    #: The ways onto the node which take it (any of them).
    entries: tuple[Entry, ...]


@frozen(kw_only=True)
class Way:
    """How the lines take a direction of a control: the moves by their line, the own tags of the control kept, the move of the rest."""

    #: The moves of a node taken only by the ways the focus came by (the properties of the node).
    keyed: tuple[Keyed, ...]
    #: The own navigation tags of the control kept (the rest of the keyed moves), each with the move going its way (None: the tag as it is).
    own: dict[ET.Element, Move | None]
    #: The move of the rest (None: the own tags).
    rest: Move | None

    def taken(self) -> list[Move]:
        """Return the moves taken without the property of a node: the rest, the moves of the own tags."""
        return [move for move in (self.rest, *self.own.values()) if move is not None]


def _way(moves: Sequence[Move], own: Sequence[ET.Element], cross: dict[Move, tuple[Entry, ...]], within: Callable[[str], frozenset[str]]) -> Way:
    """
    Return how the lines take a direction of a control (their `moves` in the order of the declarations) with its own navigation
    (`own`): an own tag going to the member of a move, or to a group the member lies in (`within`: the IDs inside a control), is
    the move (its condition kept); a node with own tags goes by the line it came by (the own tags the rest); else the first move
    takes the rest, the next ones of a node go by their line. A move a line across takes (`cross`: the lines across and the sides
    they came from) goes by them too.
    """
    taken: dict[ET.Element, Move | None] = {el: None for el in own}
    for move in moves:
        target = str(move.target.entry or move.target.id)
        free = [el for el, by in taken.items() if by is None]
        if (el := next((el for el in free if (el.text or '').strip() == target), None)) is None:  # the member itself first, then a group of it
            el = next((el for el in free if target in within((el.text or '').strip())), None)
        if el is not None:
            taken[el] = move
    others = [move for move in moves if all(move is not by for by in taken.values())]

    def entries(move: Move) -> tuple[Entry, ...]:
        """Return the ways onto the node which take the move: its line (a move of a node), the lines across."""
        return ((Entry(move.line.key),) if move.from_node else ()) + cross.get(move, ())

    if not own or any(not move.from_node for move in others):  # the lines own the direction
        return Way(keyed=tuple(Keyed(move=move, entries=found) for move in moves[1:] if (found := entries(move))), own={}, rest=moves[0])
    return Way(keyed=tuple(Keyed(move=move, entries=entries(move)) for move in others), own=taken, rest=None)


def _cross(lines: Sequence[FocusLine], candidates: dict[tuple[int, str], list[Move]], controls: dict[int, ET.Element],
           rects: dict[ET.Element, Rect], centers: dict[int, tuple[float, float]]) -> dict[ET.Element, dict[Move, tuple[Entry, ...]]]:
    """
    Return the moves across the lines (a move of a node perpendicular to the line the focus came by) by the controls leaving
    the node (`_edges()`) with the ways which take them; of the lines across through the node that way (2+: one is plain
    navigation, the first declared of equal ones): a control node takes the one nearest to the side the focus came from (from
    the left: the leftmost column, from the top: the topmost row), the side only where the two sides of the line take different
    moves; a group node takes on each edge control the one nearest to that control (as Kodi goes from it), any side.
    """
    found: dict[ET.Element, dict[Move, list[Entry]]] = {}
    for line in lines:
        across, coord = COLUMN if line.axis is ROW else ROW, line.axis.coord
        for index, member in enumerate(line.members):
            if not line.is_node(index):
                continue
            node = controls[member.id]
            for tag in (across.forward, across.backward):
                if len(moves := candidates.get((member.id, tag), ())) < 2:
                    continue
                place = {move: move.line.across(coord, centers) for move in moves}
                for edge in _edges(node, tag, rects):
                    taken = found.setdefault(edge, {})
                    if edge is node:
                        first, last = min(moves, key=lambda move: place[move]), max(moves, key=lambda move: place[move])
                        if first is last:
                            taken.setdefault(first, []).append(Entry(line.key))
                        else:
                            taken.setdefault(first, []).append(Entry(line.key, line.axis.start))
                            taken.setdefault(last, []).append(Entry(line.key, line.axis.end))
                    else:
                        taken.setdefault(_nearest(moves, edge, rects, centers), []).append(Entry(line.key))
    return {edge: {move: tuple(entries) for move, entries in taken.items()} for edge, taken in found.items()}


def _ordered(moves: Sequence[Move], edge: ET.Element, controls: dict[int, ET.Element], rects: dict[ET.Element, Rect],
             centers: dict[int, tuple[float, float]]) -> list[Move]:
    """
    Return the moves of a direction of the control in the order of the declarations (the first one takes the rest: no line
    known, e.g. the mouse); an edge control of a group node puts the line nearest to it first (as Kodi goes from the control).
    """
    found = sorted(moves, key=lambda move: int(move.line.key))
    if all(controls[move.source] is edge for move in found):
        return found
    nearest = _nearest(found, edge, rects, centers)
    return [nearest, *(move for move in found if move is not nearest)]


def _nearest(moves: Sequence[Move], control: ET.Element, rects: dict[ET.Element, Rect], centers: dict[int, tuple[float, float]]) -> Move:
    """Return the move (of one direction: its lines of one axis) whose line is nearest to the control across them (the first of equal ones)."""
    coord = ROW.coord if moves[0].line.axis is COLUMN else COLUMN.coord
    at = _center(rects[control])[coord]
    return min(moves, key=lambda move: abs(move.line.across(coord, centers) - at))


def side_property(cid: int) -> str:
    """Return the window property of a node: the side the focus came from (set only by the lines whose moves across it depend on it)."""
    return position_property(cid, 'from')


def _line_is(cid: int, key: str) -> str:
    """Return the Kodi condition: the focus came onto the node by the line."""
    return f'String.IsEqual(Window.Property({line_property(cid)}),{key})'


def _came(cid: int, keyed: Keyed) -> str:
    """Return the Kodi condition of the keyed move of the node: the focus came by one of its ways (a line, from a side)."""
    found = [_all_of(_line_is(cid, entry.line), f'String.IsEqual(Window.Property({side_property(cid)}),{entry.side})' if entry.side else '')
             for entry in keyed.entries]
    return found[0] if len(found) == 1 else ' | '.join(f'[{cond}]' if ' + ' in cond else cond for cond in found)


def _error(elem: ET.Element, message: str) -> TemplateError:
    """Return an error of the declaration."""
    return TemplateError(message, src=elem.get(SRC_ATTR, ''))


def _member(token: str, elem: ET.Element, entries: dict[str, WidgetEntry]) -> Member:
    """Return the member of the reference (a position name wins over a control name of the widget)."""
    if (found := RX_MEMBER.fullmatch(token)) is None:
        raise _error(elem, f'Not a member of a focus line: {token!r} (@path[:name][:position])')
    if (entry := entries.get(found[1])) is None:
        raise _error(elem, f'No widget {found[1]!r} for the member {token!r}')
    parts = found[2].split(':')[1:]
    pos = ''
    if parts and parts[-1] in _positions(entry):
        pos = parts.pop()
    if len(parts) > 1:
        raise _error(elem, f'Unknown position {parts[-1]!r} of the member {token!r}')
    name = parts[0] if parts else ''
    if (cid := entry.ids.get(name)) is not None:
        assert cid not in KODI_WINDOW_IDS, f'control ID {cid} of {token} is a Kodi window ID'
        return Member(ref=token, id=cid, pos=pos)
    if pos or (child := entries.get(f'{found[1]}.{name}')) is None:
        raise _error(elem, f'No control {name!r} of the widget {found[1]!r} (nor its child widget) for the member {token!r}')
    return Member(ref=token, id=entry.id, entry=child.id)


def _positions(entry: WidgetEntry) -> frozenset[str]:
    """Return the position names a member of the widget may have (of every list, of its class)."""
    return LIST_POSITIONS | widget_class(entry).FOCUS_POSITIONS


def _axis(declared: Axis | None, members: Sequence[Member], centers: dict[int, tuple[float, float]], elem: ET.Element) -> Axis:
    """Return the axis of the line (the declared one, else the dominant one of its moves); the members must go forward on it."""
    moves = list(zip(members, members[1:]))
    if members[0].id == members[-1].id:
        moves.pop()  # the wrap of a loop goes back
    deltas = []
    for first, second in moves:
        if (missing := next((m for m in (first, second) if m.id not in centers), None)) is not None:
            raise _error(elem, f'The member {missing.ref} is not a control of the window')
        (x1, y1), (x2, y2) = centers[first.id], centers[second.id]
        deltas.append((first, second, x2 - x1, y2 - y1))
    axis = declared
    if axis is None:
        found = {ROW if abs(dx) > abs(dy) else COLUMN if abs(dy) > abs(dx) else None for _a, _b, dx, dy in deltas}
        if len(found) != 1 or None in found:
            raise _error(elem, f'The axis of the focus line {" ".join(m.ref for m in members)} is ambiguous: declare ff:focus_row or ff:focus_column')
        axis = found.pop()
    assert axis is not None
    for first, second, dx, dy in deltas:
        if (dx if axis is ROW else dy) <= 0:
            raise _error(elem, f'The focus {axis.name} goes {"right" if axis is ROW else "down"} in the order of its members: '
                               f'{second.ref} is not {"right of" if axis is ROW else "below"} {first.ref}')
    return axis


def _members(elem: ET.Element, entries: dict[str, WidgetEntry]) -> tuple[Member, ...]:
    """Return the members of the declaration: two different ones at least, none repeated inside (a loop: the same one at both ends)."""
    members = tuple(_member(token, elem, entries) for token in (elem.get('path') or '').split())
    if len({member.id for member in members}) < 2:
        raise _error(elem, 'A focus line needs two different members at least')
    inner = [member.id for member in (members[:-1] if members[0].id == members[-1].id else members)]
    if len(set(inner)) != len(inner):
        again = next(member for i, member in enumerate(members) if member.id in inner[:i])
        raise _error(elem, f'The member {again.ref} repeated in the focus line (a loop: the same widget at both ends only)')
    return members


def _action(line: FocusLine, index: int, step: int, kinds: dict[int, str], indexed: set[int], elem: ET.Element) -> str:
    """
    Return the navigation action entering the member of the index by a move of the step (+1 forward, -1 backward); a list whose
    index of the selected row it reads goes to `indexed`.
    """
    member = line.members[index]
    if not member.pos:
        return str(member.entry or member.id)
    if member.pos in LIST_POSITIONS and kinds.get(member.id) not in LIST_TYPES:
        raise _error(elem, f'The position :{member.pos} of {member.ref}: not a list')
    if member.pos == 'same':
        from .widgets.views import INDEX_PROPERTY
        before = range(index - step, -1 if step > 0 else len(line.members), -step)
        if (source := next((line.members[i] for i in before if kinds.get(line.members[i].id) in LIST_TYPES), None)) is None:
            raise _error(elem, f'The position :same of {member.ref}: no list before it in the line')
        indexed.add(source.id)
        pos = f'$INFO[Container({source.id}).ListItem.Property({INDEX_PROPERTY})]'
    elif member.pos in LIST_POSITIONS:  # the edge: the first row moving forward, the last one moving back
        return row_focus(member.id, last=member.pos == 'last' or (member.pos == 'edge' and step < 0))
    else:
        pos = f'$INFO[Window.Property({position_property(member.id, member.pos)})]'  # a position the widget keeps
    return f'SetFocus({member.id},{pos},absolute)'


def _moves(line: FocusLine, kinds: dict[int, str], indexed: set[int], elem: ET.Element) -> Iterator[Move]:
    """Yield the moves of the line: from every member to the next one (forward) and back."""
    for i in range(len(line.members) - 1):
        for src, dst, tag, step in ((i, i + 1, line.axis.forward, 1), (i + 1, i, line.axis.backward, -1)):
            yield Move(line=line, source=line.members[src].id, tag=tag, target=line.members[dst], action=_action(line, dst, step, kinds, indexed, elem),
                       from_node=line.is_node(src), to_node=line.is_node(dst))


def _entered(move: Move, readers: set[int], sided: set[tuple[int, str]]) -> list[str]:
    """Return the actions setting the line of the node the move enters (none: the node reads no property), its side if a move across reads it."""
    node = move.target.id
    if not move.to_node or node not in readers:
        return []
    found = [f'SetProperty({line_property(node)},{move.line.key})']
    if (node, move.line.key) in sided:
        found.append(f'SetProperty({side_property(node)},{move.side})')
    return found


def _remove(elem: ET.Element, parents: dict[ET.Element, ET.Element]) -> None:
    """Remove the element from its parent, its tail kept."""
    parent = parents[elem]
    index = list(parent).index(elem)
    if elem.tail:
        if index:
            prev = parent[index - 1]
            prev.tail = (prev.tail or '') + elem.tail
        else:
            parent.text = (parent.text or '') + elem.tail
    parent.remove(elem)


def _append(control: ET.Element, tag: str, text: str, attrs: dict[str, str] | None = None) -> None:
    """Append a tag to the control on its own line (the indentation of its children)."""
    new = ET.SubElement(control, tag, attrs or {})
    new.text = text
    if len(control) > 1:
        last = control[-2]
        new.tail, last.tail = last.tail, control.text


def _insert(control: ET.Element, before: ET.Element, tag: str, text: str, attrs: dict[str, str]) -> None:
    """Insert a tag into the control before its child (the indentation of that child)."""
    index = list(control).index(before)
    new = ET.Element(tag, attrs)
    new.text, new.tail = text, control[index - 1].tail if index else control.text
    control.insert(index, new)


def _none_of(conditions: Sequence[str]) -> str:
    """Return the Kodi condition: none of the conditions holds (`!c`, `![a | b]`)."""
    return f'!{conditions[0]}' if len(conditions) == 1 and not RX_OPERATOR.search(conditions[0]) else f'![{" | ".join(conditions)}]'


def _grouped(condition: str) -> str:
    """Return the condition safe in a conjunction: in brackets if it has an alternative (`|`) outside of them (`+` goes before `|`)."""
    depth = 0
    for char in condition:
        depth += (char == '[') - (char == ']')
        if char == '|' and not depth:
            return f'[{condition}]'
    return condition


def _all_of(*conditions: str) -> str:
    """Return the Kodi condition: all the conditions hold ('' always: none given)."""
    given = [cond for cond in conditions if cond]
    return given[0] if len(given) == 1 else ' + '.join(map(_grouped, given))


def apply_focus_lines(root: ET.Element, entries: Sequence[WidgetEntry]) -> list[FocusLine]:
    """
    Apply the focus lines of the generated window (after the layout), remove their declarations; return the lines.
    A wrong line (a member, its axis, a position) is an error with the position of the declaration.
    """
    decls = [elem for elem in root.iter() if elem.tag in LINE_TAGS]
    if not decls:
        return []
    from .geometry import element_rects
    by_path = {entry.path: entry for entry in entries}
    parents = {child: parent for parent in root.iter() for child in parent}
    controls = {int(cid): elem for elem in root.iter('control') if (cid := elem.get('id') or '').isdecimal()}
    kinds = {cid: elem.get('type') or '' for cid, elem in controls.items()}
    rects = element_rects(root)  # no window state: every control shown (a hidden one passes a move on by its own actions, as Kodi does)
    for entry in entries:  # the editing controls: no key reaches them (Python focuses them), no edge of a group
        if name := widget_class(entry).EDIT_CONTROL:
            rects.pop(controls[entry.ids[name]], None)
    centers = {cid: _center(rects[elem]) for cid, elem in controls.items() if elem in rects}
    lines: list[FocusLine] = []
    candidates: dict[tuple[int, str], list[Move]] = {}  # the moves of a control a direction, in the order of the declarations
    indexed: set[int] = set()  # the lists whose rows carry their index (`:same` reads it)
    for n, elem in enumerate(decls, 1):
        members = _members(elem, by_path)
        line = FocusLine(key=str(n), axis=_axis(LINE_TAGS[elem.tag], members, centers, elem), members=members, src=elem.get(SRC_ATTR, ''))
        lines.append(line)
        for move in _moves(line, kinds, indexed, elem):
            candidates.setdefault((move.source, move.tag), []).append(move)
        _remove(elem, parents)
    from .widgets.views import INDEX_PROPERTY
    for entry in entries:
        if entry.id in indexed:
            entry.data[INDEX_PROPERTY] = True  # the manifest: `ListView` sets the index of every row
    edge_moves: dict[tuple[ET.Element, str], list[Move]] = {}  # the moves of a control leaving a member (a group: its edge controls)
    for (source, tag), moves in candidates.items():
        for edge in _edges(controls[source], tag, rects):
            edge_moves.setdefault((edge, tag), []).extend(moves)
    cross = _cross(lines, candidates, controls, rects, centers)
    inside: dict[str, frozenset[str]] = {}

    def within(text: str) -> frozenset[str]:
        """Return the IDs of the controls inside the control of the ID (none: not a group)."""
        if (found := inside.get(text)) is None:
            group = controls.get(int(text)) if text.isdecimal() else None
            found = inside[text] = frozenset() if group is None or group.get('type') not in CONTAINER_TYPES else frozenset(
                cid for ctl in group.iter('control') if ctl is not group and (cid := ctl.get('id') or '').isdecimal())
        return found

    ways = {(edge, tag): _way(_ordered(moves, edge, controls, rects, centers), edge.findall(tag), cross.get(edge, {}), within)
            for (edge, tag), moves in edge_moves.items()
            if all((el.text or '').strip() != edge.get('id') for el in edge.findall(tag))}  # an own move to itself: Kodi's own (a panel wraps)
    readers = {keyed.move.source for way in ways.values() for keyed in way.keyed}  # the nodes whose property a move reads
    sided = {(keyed.move.source, entry.line) for way in ways.values() for keyed in way.keyed for entry in keyed.entries if entry.side}

    def emit(control: ET.Element, move: Move, condition: str) -> None:
        """Append the actions of the move to the control (the properties of the node it enters first, if a move of the node reads them)."""
        attrs = {'condition': condition} if condition else {}
        for prop in _entered(move, readers, sided):
            _append(control, move.tag, prop, attrs)
        _append(control, move.tag, move.action, attrs)

    for (control, tag), way in ways.items():
        for old in control.findall(tag):
            if old not in way.own:  # the lines own the direction
                control.remove(old)
        conditions = [_came(keyed.move.source, keyed) for keyed in way.keyed]
        rest = _none_of(conditions) if conditions else ''
        for el, move in way.own.items():  # the rest: the own tags (the conditions of the shown page, of a field shown ...)
            if condition := _all_of(el.get('condition', ''), rest):
                el.set('condition', condition)
            if move is not None:
                for prop in _entered(move, readers, sided):
                    _insert(control, el, tag, prop, dict(el.attrib))
                el.text = move.action
        for keyed, condition in zip(way.keyed, conditions):
            emit(control, keyed.move, condition)
        if way.rest is not None:
            emit(control, way.rest, rest)
    by_id = {entry.id: entry for entry in entries}
    for source in sorted(readers):  # the line is forgotten when the focus leaves the node (its side needs no clearing: read with its line only)
        if controls[source].get('type') in CONTAINER_TYPES and (entry := by_id.get(source)) is not None:
            # a group has no onunfocus: the window clears it when the focus leaves it (`WidgetTree.focus()`), a move inside keeps it
            entry.data[LINE_GROUP] = sorted(int(cid) for ctl in _focusables(controls[source]) if (cid := ctl.get('id') or '').isdecimal())
            continue
        # ponytail: run the next frame (a thread message) - two moves in one frame (a list of one row) still see it; a Python focus watch if it matters
        for control in _focusables(controls[source]):  # a group of no widget: its controls (a move inside forgets the line)
            _append(control, 'onunfocus', f'ClearProperty({line_property(source)})')
    for line in _dead(lines, list(ways.values())):
        fflog.warning(f'Focus line: {" ".join(m.ref for m in line.members)} is never taken (other lines go its ways first) at {line.src}')
    return lines


def _center(rect: Rect) -> tuple[float, float]:
    """Return the center of the rectangle."""
    return rect.left + rect.size.width / 2, rect.top + rect.size.height / 2


def _inner(group: ET.Element) -> Iterator[ET.Element]:
    """
    Yield the focusable controls of the group (a grouplist as one: Kodi leads inside it; a plain group passed through; a control disabled
    for good - `<enable>false</enable>`, a meter - takes no focus).
    """
    for child in group.iterfind('control'):
        if child.get('type') in FOCUSABLE_TYPES:
            if (child.findtext('enable') or '').strip() != 'false':
                yield child
        elif child.get('type') == 'group':
            yield from _inner(child)


def _focusables(control: ET.Element) -> Iterator[ET.Element]:
    """Yield the controls which take the focus for the control: itself, the ones inside a group / grouplist."""
    if control.get('type') not in CONTAINER_TYPES:
        yield control
        return
    for child in control.iterfind('control'):
        if child.get('type') in FOCUSABLE_TYPES | CONTAINER_TYPES:
            yield from _focusables(child)


def _beyond(other: Rect, rect: Rect, tag: str) -> bool:
    """Return True if the other rectangle is further than the rectangle in the direction of the navigation tag, across from it (overlapping)."""
    (x1, y1), (x2, y2) = _center(rect), _center(other)
    if tag in (ROW.forward, ROW.backward):
        across, ahead = other.top < rect.top + rect.size.height and rect.top < other.top + other.size.height, x2 - x1
    else:
        across, ahead = other.left < rect.left + rect.size.width and rect.left < other.left + other.size.width, y2 - y1
    return across and (ahead > 0 if tag in (ROW.forward, COLUMN.forward) else ahead < 0)


def _edges(control: ET.Element, tag: str, rects: dict[ET.Element, Rect]) -> list[ET.Element]:
    """
    Return the controls a move of the navigation tag leaves the control by (Kodi takes the moves of the focused control only):
    itself; a group: its focusable controls with no other one of the group further that way across from them (by their
    rectangles, all shown: a hidden one passes the move on by its own actions, as Kodi does), each by its own edges; a grouplist
    along its orientation: itself (Kodi gives these moves of a grouplist to its end controls, over theirs), across it as a group.
    """
    kind = control.get('type')
    axis = COLUMN if (control.findtext('orientation') or 'vertical').strip() == 'vertical' else ROW  # of a grouplist (Kodi's default: vertical)
    if kind not in CONTAINER_TYPES or (kind == 'grouplist' and tag in (axis.forward, axis.backward)):
        return [control]
    inner = [ctl for ctl in _inner(control) if ctl in rects]
    edge = [ctl for ctl in inner if not any(_beyond(rects[other], rects[ctl], tag) for other in inner if other is not ctl)]
    return [found for ctl in edge for found in _edges(ctl, tag, rects)]


def _dead(lines: Sequence[FocusLine], ways: Sequence[Way]) -> list[FocusLine]:
    """
    Return the lines no move can take in either direction: a move is taken when it takes the rest of its direction or an own tag
    of its control, or it is a move of a node by the ways onto it (`Way.keyed`: its line, a line across from a side) and a taken
    move enters the node one of these ways.
    """
    taken = [move for way in ways for move in way.taken()]
    pending = [keyed for way in ways for keyed in way.keyed]
    while True:
        entered = {(move.line.key, move.target.id, side) for move in taken if move.to_node for side in ('', move.side)}
        if not (more := [keyed for keyed in pending if any((entry.line, keyed.move.source, entry.side) in entered for entry in keyed.entries)]):
            break
        taken.extend(keyed.move for keyed in more)
        pending = [keyed for keyed in pending if all(keyed is not other for other in more)]
    used = {move.line.key for move in taken}
    return [line for line in lines if line.key not in used]
