from __future__ import annotations
from typing import Any, Mapping, cast, TYPE_CHECKING
from functools import reduce
from operator import or_
from attrs import frozen
from .base import BaseDialog
from .style import tokens
from .widgets.accounts import FieldButton
from .widgets.buttons import ButtonGroup
from ..kolang import L
from cdefs import ListType
if TYPE_CHECKING:
    from ..defs import RefType
    from ..ff.lists import AddToListCreateOptions, ServiceDescr
    from .widgets.buttons import CheckBox


@frozen
class TypeControl:
    """Type control definition: its check box is the widget of its name (`movie` ...), a type without one has none."""

    inital: str  # single-letter type name initial
    name: RefType
    type: ListType


@frozen(kw_only=True)
class TypeChoice:
    """A choice of the types of a service declaring them (the template vars of its radio button)."""

    #: The label.
    label: str
    #: The types of the choice.
    types: ListType


@frozen(kw_only=True)
class NewListResult:
    """Result of the new list dialog."""

    name: str
    types: ListType
    public: bool = False  # public list by default?


class NewWindowDialog(BaseDialog):
    """Create new list for "add to" dialog."""

    TYPES: dict[RefType, TypeControl] = {tc.name: tc for tc in (
        TypeControl('C', 'collection', ListType.COLLECTION),
        TypeControl('M', 'movie',      ListType.MOVIE),
        TypeControl('T', 'show',       ListType.SHOW),
        TypeControl('S', 'season',     ListType.SEASON),
        TypeControl('E', 'episode',    ListType.EPISODE),
        TypeControl('P', 'person',     ListType.PERSON),
        TypeControl('L', 'list',       ListType.LIST),
    )}

    @classmethod
    def xml_vars(cls, *, type_choices: Mapping[str, ListType] | None = None, **kwargs: Any) -> dict[str, Any]:
        """
        The choices of the types of a service declaring them (radio buttons instead of the check boxes of the types), the types of the
        check boxes (their values in the button group of the types).
        """
        return {'CHOICES': tuple(TypeChoice(label=label, types=types) for label, types in (type_choices or {}).items()), 'TYPES': cls.TYPES}

    def __init__(self,
                 *args,
                 types: ListType = ListType.MEDIA,
                 enabled_types: ListType = ListType.MIXED,
                 visible_types: ListType = ListType.MIXED,
                 new_list_options: AddToListCreateOptions | None = None,
                 type_choices: Mapping[str, ListType] | None = None,
                 **kwargs,
                 ) -> None:
        """Instance initialization, there are no XML controls yet. See onInit()."""
        super().__init__(*args)
        #: The name of the list (its field, OK: the keyboard of Kodi).
        self.name: str = ''
        #: The choices of the types (a service declaring them: their labels and types, one chosen), none: a check box of every type.
        self.type_choices: tuple[ListType, ...] = tuple((type_choices or {}).values())
        self.types = types
        self.enabled_types = enabled_types
        self.visible_types = visible_types
        self.new_list_options: AddToListCreateOptions = new_list_options or {}
        for tc in self.TYPES.values():
            # self.setProperty(f'type.{tc.name}.enabled', 'true' if self.enabled_types & tc.type else 'false')
            self.setProperty(f'type.{tc.name}.visible', 'true' if self.visible_types & tc.type else 'false')
        self.setProperty('type.collection.checked', 'true')
        for typ, box in self.type_boxes().items():
            box.enabled = bool(self.enabled_types & typ)
        group = self.type_group()
        if group.exclusive:  # the choices: the first one of the default types (one checked)
            group.value = next((typ for typ in self.type_choices if typ & self.types), self.type_choices[0])
        else:
            group.value = frozenset(typ for typ in self.type_boxes() if self.types & typ)
        # new list options
        public = self.public_box()
        val = self.new_list_options.get('public')
        public.checked = bool(val)
        public.enabled = val is not None

    def type_boxes(self) -> dict[ListType, CheckBox]:
        """Return the check boxes of the types (a type without a box, e.g. a list, has none)."""
        boxes = self.widgets.children
        return {tc.type: cast('CheckBox', boxes[tc.name]) for tc in self.TYPES.values() if tc.name in boxes}

    @classmethod
    def of_service(cls, service: ServiceDescr) -> NewWindowDialog:
        """Return the dialog of a new list of the service: its default types, the ones it lets change, its options, its choices of the types."""
        return cls(types=service.new_list_types, enabled_types=service.edit_types & service.types, new_list_options=service.new_list_options or {},
                   type_choices=service.edit_type_choices)

    def type_group(self) -> ButtonGroup:
        """Return the button group of the types: the radio buttons of the choices (exclusive), else the check boxes of the types (a set)."""
        return self.find('types', ButtonGroup)

    def public_box(self) -> CheckBox:
        """Return the check box of a public list."""
        return cast('CheckBox', self.find('buttons.public'))

    def on_init(self) -> None:
        """Kodi call it on window initialization, access to XML controls is allowed from now."""
        self.show_name()
        # focus
        self.setFocusId(self.find('name').id)
        self._set_ok_enabled()

    def show_name(self) -> None:
        """Show the name in its field (none: the hint in `color.text.hint`)."""
        self.find('name', FieldButton).text = self.name or f'[COLOR {tokens().color.text.hint}]{L(30409, "Enter new list name")}[/COLOR]'

    def list_name(self) -> str:
        """Return the name of the new list."""
        return self.name.strip()

    def list_type(self) -> ListType:
        """Return the selected types of the new list (the chosen choice of a service declaring them, else the checked types)."""
        group = self.type_group()
        if group.exclusive:
            return group.value or ListType.NONE
        return reduce(or_, group.value, ListType.NONE)

    def on_buttons_cancel_clicked(self) -> None:
        """No new list."""
        self.close()

    def on_buttons_ok_clicked(self) -> None:
        """The new list (its name and types are needed)."""
        if (name := self.list_name()) and (types := self.list_type()):
            self.close(NewListResult(name=name, types=types, public=self.public_box().checked))

    def on_name_clicked(self) -> None:
        """The name: the keyboard of Kodi (canceled: no change)."""
        from ..ff.ui import ui
        if (name := ui.input(L(30395, 'New list name'), self.name)) is not None:
            self.name = name
            self.show_name()
            self._set_ok_enabled()

    def _set_ok_enabled(self) -> None:
        """Set OK button enabled state."""
        self.find('buttons.ok').enabled = bool(self.list_name().strip() and self.list_type() is not ListType.NONE)

    def on_types_changed(self, value: Any) -> None:
        """The types changed (a check box of a type, a choice): OK enabled by them."""
        self._set_ok_enabled()
