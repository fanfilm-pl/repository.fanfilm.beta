
from __future__ import annotations
from typing import TYPE_CHECKING
from typing_extensions import Literal
from attrs import frozen
from .base import BaseDialog, CANCEL_ACTIONS
from .scale import Scale
from .style import tokens
from .widgets.frames import TagData, set_tags
from .widgets.tabs import Page, TabBar
from .widgets.views import ListView
from .widgets.basic import Label, SpinBox
from ..ff.item import FFItem
from ..ff.lists import AddToServices, AddToServiceDefs, ServiceDescr, add_to_defs, add_to_services, list_pointer
from ..ff.types import flag_names
from ..ff.control import notification
from ..ff.logs import fflog, fflog_exc
from ..kolang import L
from cdefs import ListType, ListTarget, ListPointer
from const import const
if TYPE_CHECKING:
    from typing import Any, Iterable, Sequence, Collection, ClassVar
    from ..defs import RefType, FFRef
    from .new_list import NewListResult


#: ...
AddToDialogMediaBarMode = Literal['hide', 'icons', 'labels', 'initial', 'notoco']


@frozen
class HeaderControl:
    inital: str  # single-letter type name initial
    type: RefType
    icon: str  # the icon (`icons/<icon>.32.png`)
    title: str  # localized (translated)
    notoco: str  # trolling

    @property
    def list_type(self) -> ListType:
        return ListType.from_media_ref(self.type)


@frozen(kw_only=True)
class ListInfo:
    """Information about the list."""
    service: ServiceDescr
    name: str
    id: str
    type: ListType
    #: The target of the items, taken from the row in the dialog (the result keeps no row: a row shown in a window must not outlive it).
    target: ListTarget
    tab_label: str = ''  # label for the list, used in the dialog

    def add_items(self, items: Iterable[FFRef]) -> int | None:
        """Add items to the selected list."""
        return self.service.add_items(self.target, items)


class AddToDialog(BaseDialog):
    """General add media (and other refs) to anything, like lists or library."""

    HEADER_CONTROLS: dict[RefType, HeaderControl] = {h.type: h for h in (
        HeaderControl('C', 'collection', 'collection', L(30388, '{n} collection|||{n} collections'), '시리즈'),
        HeaderControl('M', 'movie',      'movie',      L(30888, '{n} movie|||{n} movies'), ' 영화'),
        HeaderControl('T', 'show',       'tv',         L(30389, '{n} show|||{n} shows'), '드라마'),  # '시리즈'
        HeaderControl('S', 'season',     'season',     L(30390, '{n} season|||{n} seasons'), '시즌'),
        HeaderControl('E', 'episode',    'episode',    L(30391, '{n} episode|||{n} episodes'), '에피소드'),  # '화와'
        HeaderControl('P', 'person',     'person',     L(30392, '{n} person|||{n} persons'), '인물'),
        HeaderControl('L', 'list',       'list',       L(30393, '{n} list|||{n} lists'), '글자'),
    )}

    @classmethod
    def row_types(cls) -> list[HeaderControl]:
        """Return the types a list holds (the icons of the tag of its row, their colours: `update_list()`)."""
        return [hc for hc in cls.HEADER_CONTROLS.values() if hc.list_type & ListType.MIXED]

    @classmethod
    def xml_vars(cls, **kwargs: Any) -> dict[str, Any]:
        """
        The header types of the template (an icon and a count of each type), the types of a list (its tag), the one page of the services
        (their lists), the text of a service without lists.
        """
        return {'TYPES': list(cls.HEADER_CONTROLS.values()), 'ROW_TYPES': cls.row_types(), 'PAGES': (Page(name='lists'),),
                'NO_LISTS': L(30504, 'No lists')}

    def __init__(self,
                 *args,
                 items: Iterable[FFRef],
                 services: AddToServices | AddToServiceDefs | None = None,
                 **kwargs,
                 ) -> None:
        """Instance initialization, there are no XML controls yet. See onInit()."""
        super().__init__(*args)
        #: The header types shown (the template shows their icons and counts).
        self.shown_types: set[RefType] = set()
        self.source_items: list[FFRef] = list(items)
        self.source_services: AddToServices | AddToServiceDefs | None = services
        self.items: list[FFRef] = []
        self.item_counts: dict[RefType, int] = {}
        self.existing_types = ListType.NONE
        self.services: AddToServices = {}
        self._reinit(len(self.source_items))

    def _reinit(self, max_length: int) -> None:
        self.items = self.source_items[:max_length]
        self.item_counts = {}
        for it in self.items:
            rtype = it.ref.real_type
            self.item_counts[rtype] = self.item_counts.get(rtype, 0) + 1
        for rtype in self.item_counts:
            self.existing_types |= ListType.from_media_ref(rtype)
        # build service tree
        services = self.source_services
        if services is None:
            services = add_to_defs()
        # the service tree: pointers of types for all accounts, enabled ones only
        self.services = add_to_services(services or add_to_defs())
        self.list_list: list[FFItem] = []
        self.find('type_label', cls=Label).text = ''
        for typ in self.HEADER_CONTROLS:
            self.find(f'type_bar.{typ}.count').text = str(sum(it.ref.real_type == typ for it in self.items))
        self.media_type_bar: AddToDialogMediaBarMode = const.dialog.add_to.media_type.bar_mode

    def on_init(self) -> None:
        """Kodi call it on window initialization, access to XML controls is allowed from now."""
        # the shown types are centred by the template (a grouplist of the visible ones)
        show_types = self.existing_types | const.dialog.add_to.media_type.absent_visible
        self.shown_types = {hc.type for hc in self.HEADER_CONTROLS.values() if hc.list_type & show_types}
        self.bindings.refresh()
        self.update_media_bar(self.no_list_types())  # before the lists: the current list shows its own types
        total = len(self.source_items)
        limit = self.find('buttons.limit', cls=SpinBox)
        limit.scale = Scale(minimum=1, maximum=max(1, total), format=L(30775, 'Limit: {}'))
        limit.value = len(self.items)
        limit.heading = L(30491, 'Enter number of items (1..{total})').format(total=total)
        services = self.find('services.bar')
        services.rows = list(self.services)  # its current tab fills the lists (`on_services_bar_current_changed()`)
        # services.rows = [chr(65 + i)*3 for i in range(26)]  # DEBUG
        self.setFocusId(services.id)  # a filled list (an empty one can not have the focus: no default control)

    def on_close(self) -> None:
        """Kodi call it on window close, no access to XML controls is allowed from now."""
        self.source_items.clear()  # Remove FFItems to prevent memory leaks.
        self.items.clear()  # Remove FFItems to prevent memory leaks.

    def item_count(self, allowed: ListType | None = None) -> int:
        """Return the number of the items of the allowed types (None: of the current list, `no_list_types()` without one)."""
        if allowed is None:
            allowed = lst.type if (lst := self.current_list()) is not None else self.no_list_types()
        return sum(self.item_counts.get(hc.type, 0) for hc in self.HEADER_CONTROLS.values() if hc.list_type & allowed)

    def update_media_bar(self, allowed: ListType) -> None:
        """Update colors based on destination allowed media types."""
        def color(typ: RefType) -> str:
            ltype = ListType.from_media_ref(typ)
            if not ltype & self.existing_types:
                return tokens().color.text.disabled
            if ltype & allowed:
                return tokens().color.icon.focused
            return tokens().color.error

        item_count = self.item_count(allowed)
        self.find('title').text = L(30401, 'Add {matched} / {n} item|||Add {matched} / {n} items', n=len(self.items), matched=item_count)
        type_label = self.find('type_label')
        if self.media_type_bar == 'icons':
            for typ in self.HEADER_CONTROLS:
                self.find(f'type_bar.{typ}.icon').color = color(typ)
        elif self.media_type_bar == 'labels':
            type_label.text = ', '.join(f'[COLOR {color(hc.type)}]{L.get_text(hc.title, n=self.item_counts.get(hc.type, 0))}[/COLOR]'
                                        for hc in self.HEADER_CONTROLS.values())
        elif self.media_type_bar == 'initial':
            type_label.text = ',     '.join(f'[COLOR {color(hc.type)}]{hc.inital}: {self.item_counts.get(hc.type, 0)}[/COLOR]'
                                            for hc in self.HEADER_CONTROLS.values())
        elif self.media_type_bar == 'notoco':
            type_label.text = ', '.join(f'[COLOR {color(typ)}]{self.item_counts.get(typ, 0)} {hc.notoco}[/COLOR]'
                                        for typ, hc in self.HEADER_CONTROLS.items())
        self.find('type_bar').visible = self.media_type_bar == 'icons'
        type_label.visible = self.media_type_bar in ('labels', 'initial', 'notoco')

    def update_list(self) -> None:
        """Update list of the lists for current selected service."""
        def proc_item_list(it: FFItem) -> Iterable[FFItem]:
            exist_color = tokens().color.icon.focused
            types = ListType.new(it.getProperty('list_type'))
            set_tags(it, types=TagData(icons={hc.icon: exist_color if hc.list_type & types else '' for hc in row_types}))  # absent: gray
            yield it

        row_types = self.row_types()
        _, services = self.current_service()
        self.list_list = [it for srv in services for lst in srv.lists() for it in proc_item_list(lst)]
        self.find('services.lists').rows = self.list_list  # the separators of the groups of the lists: the list
        self.list_changed()  # the same current row as before is no change of it: the media bar of the new list (none: as before the lists)

    def update_new_list_button(self) -> None:
        """Update the "New List" button state."""
        self.find('buttons.new_list').enabled = self.new_list_service() is not None

    def update_limit_items_button(self) -> None:
        """Update the "Limit Items" state: a limit of more than one item (the limit stays changeable)."""
        self.find('buttons.limit').enabled = len(self.source_items) > 1

    def current_service(self) -> tuple[str, Sequence[ServiceDescr]]:
        """Return currently selected service (none before the tabs: '', no services)."""
        index, services = self.find('services.bar', cls=TabBar).current, tuple(self.services.items())
        if not 0 <= index < len(services):
            return '', ()
        label, group = services[index]
        return label, tuple(group)

    def new_list_service(self) -> ServiceDescr | None:
        """Return the service of the current tab a new list is created in (its first one creating lists), None if it creates none."""
        _, services = self.current_service()
        return next((srv for srv in services if srv.create_enabled()), None)

    def no_list_types(self) -> ListType:
        """
        Return the types allowed with no current list (before the lists, a service without lists: the media bar, the buttons): the ones of a
        new list of the current service by default (its new list dialog starts with them; a service creating no list: its first one).
        """
        _, services = self.current_service()
        service = self.new_list_service() or next(iter(services), None)
        return service.new_list_types if service is not None else ServiceDescr.DEFAULT_NEW_TYPES

    def current_list(self) -> ListInfo | None:
        """Return currently selected list (from central widget), None if the service has no list."""
        if not self.list_list:
            return None
        service_label = tuple(self.services.keys())[self.find('services.bar', cls=TabBar).current]
        item = self.list_list[self.find('services.lists', cls=ListView).current]
        pointer: ListPointer = item.getProperty('pointer')
        service = list_pointer(pointer)
        assert service is not None  # the pointer comes from the services of the dialog
        list_id = item.getProperty('list_id')
        name = item.getLabel()
        return ListInfo(service=service, name=name, id=list_id or name, type=ListType.new(item.getProperty('list_type')),
                        target=ListTarget.from_ffitem(item), tab_label=service_label)

    # --- slots of the widgets ---

    def on_services_bar_current_changed(self, index: int) -> None:
        """Another service: its lists."""
        self.update_list()

    def on_services_lists_current_changed(self, index: int) -> None:
        """Another list: the media bar of its types, the buttons."""
        self.list_changed()

    def list_changed(self) -> None:
        """The current list changed: the media bar of its types, the buttons."""
        lst = self.current_list()
        self.update_media_bar(lst.type if lst is not None else self.no_list_types())
        self.update_new_list_button()
        self.update_limit_items_button()

    def on_services_lists_activated(self, index: int) -> None:
        """List selected, add items to it."""
        lst = self.current_list()
        # num = lst.service.add_items(lst.item, self.items)
        # notification(f'Add to {lst.service.name} list', f'Added {num} items to {lst.name}.', visible=True)
        self.close(lst)

    def on_buttons_cancel_clicked(self) -> None:
        """Close the dialog (no list)."""
        self.close()

    def on_buttons_new_list_clicked(self) -> None:
        """Create a new list of the current service."""
        from .new_list import NewWindowDialog
        label, _ = self.current_service()
        if service := self.new_list_service():
            new: NewListResult | None = NewWindowDialog.of_service(service).doModal()
            fflog(f'new list: {new=}')  # TODO: remove this log
            if new:
                if service.create(new.name, type=new.types, public=new.public):
                    notification(L(30484, 'Create {service} list').format(service=label),
                                 L(30485, 'List {name} has been created').format(name=new.name), visible=True)
                    self.update_list()
                else:
                    from xbmcgui import Dialog
                    fflog(f'Failed to create {label} list {new.name!r} with types {flag_names(new.types)}')
                    Dialog().ok(L(30394, 'Error'),
                                L(30486, 'Failed to {service} create list {name}.').format(service=label, name=new.name))

    def on_buttons_limit_committed(self, limit: int) -> None:
        """The items to add limited (their number, 1..all of them)."""
        self._reinit(limit)
        self.update_list()  # its media bar, its buttons

    # The debug button (commented in the template).
    # def on_buttons_debug_clicked(self) -> None:
    #     from xbmcgui import Dialog
    #     Dialog().ok('H', 'Mmm')
