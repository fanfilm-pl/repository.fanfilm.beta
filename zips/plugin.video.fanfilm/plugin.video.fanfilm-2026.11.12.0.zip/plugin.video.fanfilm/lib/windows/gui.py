"""Simple GUI helpers."""

from __future__ import annotations
from typing import Mapping, Protocol, TypeVar, TYPE_CHECKING
import hashlib
import os
import re
from pathlib import Path
from itertools import product
from functools import lru_cache
import pickle
from xml.etree import ElementTree as ET
from attrs import define, frozen, field
from ..ff.types import TRUE_VALUES
from ..ff.control import plugin_id
from ..ff.theme import ADDONS_URL, addon_url
from ..ff.logs import fflog, fflog_exc
from ..kolang import L
from .skinfonts import fonts_frozen, window_fonts
from .style import FRAME_SHAPES, GROUP_ALIGNS, TAB_SHAPES, TAG_EDGES, TAG_OUTS, TOKENS, image_variant, tokens
from const import const
if TYPE_CHECKING:
    from typing import Any, Callable, Iterable, Sequence, Iterator
    # from typing_extensions import LiteralString
    from .xgui import WidgetEntry, XmlManager
    from .bindings import Binding


#: All XML Kodi geometry (position and size) tags.
GEOM_TAGS = {'top', 'bottom', 'left', 'right', 'centerleft', 'centerright', 'centertop', 'centerbottom', 'width', 'height'}

#: The textures of the windows (the media folder of the add-on skin).
MEDIA: Path = Path(__file__).resolve().parents[2] / 'resources' / 'skins' / 'Default' / 'media'
#: The skin folder of the windows as Kodi's path (its media folder and the folders of its variants, `texture_url()`).
SKIN_URL: str = f'{ADDONS_URL}{plugin_id}/resources/skins/Default'
#: The media folder of the windows as Kodi's path in the generated windows (`window_texture()`): the same bytes on every system.
MEDIA_URL: str = f'{SKIN_URL}/{MEDIA.name}'
#: A texture name which is not a file of the media folder: a Kodi info, a field, a URL, an absolute path (also of Windows).
RX_NOT_A_FILE: re.Pattern[str] = re.compile(r'[$\[{]|://|^[/\\]|^[A-Za-z]:')
#: The texture tags of the controls (their text: a file of the media folder, a Kodi info, a path).
TEXTURE_TAGS: frozenset[str] = frozenset((
    'texture', 'texturefocus', 'texturenofocus', 'texturebg', 'textureleft', 'textureright', 'midtexture', 'lefttexture',
    'righttexture', 'alttexturefocus', 'alttexturenofocus', 'textureradioonfocus', 'textureradioonnofocus',
    'textureradiooffocus', 'textureradiooffnofocus', 'texturesliderbackground', 'texturesliderbar', 'texturesliderbarfocus',
    'texturesliderbardisabled', 'textureslidernib', 'textureslidernibfocus', 'textureslidernibdisabled', 'bordertexture',
))
#: The attributes of a texture tag naming a texture too (the image of an empty info, the mask of the texture).
TEXTURE_ATTRS: frozenset[str] = frozenset(('fallback', 'diffuse'))
#: The tags of an image a widget of a theme may write (`drop_remote_textures()`): the textures and the images of a multiimage, a static item.
THEME_IMAGE_TAGS: frozenset[str] = TEXTURE_TAGS | {'imagepath', 'icon', 'thumb'}
#: A texture of a theme naming no local file (`drop_remote_textures()`): a URL, any scheme but Kodi's local `special://` and `resource://`
#: (an installed resource add-on; `image://` wraps a URL).
RX_REMOTE_TEXTURE: re.Pattern[str] = re.compile(r'(?i)\b(?!special://|resource://)[a-z][\w+.-]*://')
#: The textures the widgets of the themes wrote in the last generated window, dropped (`drop_remote_textures()`): `<theme>: <value>`.
_remote_textures: list[str] = []
#: A texture of an info with a prefix and a postfix (`BoxTexture.info()`: `$INFO[Window.Property(p),dialogs/checkbox.,.f0.png]`).
RX_INFO_AFFIXES: re.Pattern[str] = re.compile(r'\$INFO\[([^,\]]+),([^,\]]+),([^,\]]+)\]')
#: A function cached until the textures of the themes change (`texture_cache()`).
_Cached = TypeVar('_Cached', bound='Callable[..., Any]')
#: A `<letter><value>` part of a texture name (`TextureName`): one value or four (`_` / `,` between), each digits (`~` the decimal
#: point) or upper hex digits (`off` is a word, `oF` a part).
RX_TEXTURE_PART: re.Pattern[str] = re.compile(r'([a-z])([\dA-F~]+(?:[_,][\dA-F~]+)*)')
#: The letters of the geometry parts of a texture name (the radius or the chamfer, the margin, the open sides, the flare, the half of
#: the pen, the pen width, the border, the height); the other parts are its look (colours, opacities, the focus) and the words.
TEXTURE_GEOMETRY: str = 'rkmnjswbh'
#: The letters of the corner part of a texture name, its kind (`TextureName.corner`): `r` rounded, `k` chamfered (cut on a diagonal).
TEXTURE_CORNERS: str = 'rk'

#: The folder (in `resources/skins`) of the widgets and the windows made of them (`render_xml()`).
WIDGETS_FOLDER: str = 'widgets'
#: The tags which may refer to a widget by its path (`@lists`): the navigation, the focus actions, the default control, the conditions,
#: the label (`Container(@sources).NumItems`).
WIDGET_REF_TAGS: frozenset[str] = frozenset({'onup', 'ondown', 'onleft', 'onright', 'onback', 'onfocus', 'onunfocus', 'defaultcontrol', 'visible', 'enable',
                                             'selected', 'label', 'animation'})
#: A reference to a widget by its path (not an e-mail-like `a@b`), `@path:name` another control of the widget (`id_of(name)`).
RX_WIDGET_REF: re.Pattern[str] = re.compile(r'(?<![\w@])@([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)(?::([\w.]+))?')


@define(kw_only=True)
class CustomXmlRequest:
    """Data for custom XML processing request."""
    #: Variables.
    vars: dict[str, Any] = field(factory=dict)


@frozen(kw_only=True)
class CustomXmlData:
    """Data from custom XML processing."""
    request: CustomXmlRequest = field(factory=CustomXmlRequest)
    #: Request variables the XML depends on (read by the template): name -> repr() of the value.
    deps: dict[str, str] = field(factory=dict)
    #: Global variables of the XML template (only values which can be pickled), for the window code.
    globals: dict[str, Any] = field(factory=dict)
    #: Bindings (`{=expr}` fields computed at runtime): window property -> binding.
    bindings: dict[str, Binding] = field(factory=dict)
    #: The widgets of a window made of them (the manifest) in the document order.
    widgets: tuple[WidgetEntry, ...] = ()
    #: The default control the window focuses after `on_init()` (`defer_default_control()`), 0: none (Kodi focuses its default control).
    default_focus: int = 0
    #: The sizes the layout gave the widgets reading their missing use sizes (`XmlManager.layout_sizes()`): path -> tag -> size; the seed
    #: of the next generation of the window (`render_xml(sizes=…)`: one pass when they hold).
    sizes: dict[str, dict[str, int]] = field(factory=dict)

    def widget_ids(self) -> dict[str, int]:
        """Return the control IDs of the widgets by their paths (the tests find the controls by them)."""
        return {entry.path: entry.id for entry in self.widgets}


def custom_xml(xml_source: Path, xml_path: Path, request: CustomXmlRequest | None = None) -> CustomXmlData:
    """Fix window/dialog source XML to handle what kodi can not, write it to `xml_path` (if changed)."""
    try:
        xml_bytes, data = render_xml(xml_source, request)
        try:
            old_out = xml_path.read_bytes()
        except IOError:
            old_out = b''
        if old_out != xml_bytes:
            xml_path.parent.mkdir(parents=True, exist_ok=True)
            xml_path.write_bytes(xml_bytes)
        return data
    except IOError:
        fflog_exc()
        return CustomXmlData(request=request or CustomXmlRequest())


def png_size(path: Path) -> tuple[int, int] | None:
    """Return the size of a PNG image (from its header), None if it is not one (or missing)."""
    import struct
    try:
        with open(path, 'rb') as f:
            head = f.read(24)
    except OSError:
        return None
    if len(head) < 24 or head[:8] != b'\x89PNG\r\n\x1a\n':
        return None
    return struct.unpack('>II', head[16:24])


#: The caches of the texture families (`texture_cache()`), cleared when the textures of the themes change (`check_textures()`).
_texture_caches: list[Any] = []
#: The textures of the variant of the windows of the last `check_textures()` (`variant_textures()`), None before the first one.
_theme_textures: dict[str, str] | None = None


def texture_cache(func: _Cached) -> _Cached:
    """Cache the function of the texture files by its arguments until the textures of the themes change (`check_textures()`)."""
    cached = lru_cache(maxsize=None)(func)
    _texture_caches.append(cached)
    return cached  # type: ignore[return-value]


@lru_cache(maxsize=None)
def media_variant_textures(variant: str) -> dict[str, str]:
    """
    Return the textures of the media folder of a variant of FF (`media.<variant>` beside `MEDIA`, the same relative paths: a file there
    wins over the one of `MEDIA` in that variant): relative path -> its file; none without the folder (read once per interpreter).
    """
    top = MEDIA.with_name(f'{MEDIA.name}.{variant}')
    return {Path(root, name).relative_to(top).as_posix(): str(Path(root, name)) for root, _, names in os.walk(top) for name in names}


def variant_textures(variant: str) -> dict[str, str]:
    """
    Return the textures of the FF windows of a variant (`image_variant()`, `focused_image_variant()`) which are not the files of `MEDIA`:
    relative path -> its file - of the media folder of the variant of FF (`media_variant_textures()`), the ones of the active themes over
    them (`theme.skin_textures()`, a theme wins over FF; none without an active theme, nothing read).
    """
    from ..ff.theme import skin_textures, theme_folders
    themes = skin_textures(variant) if len(theme_folders()) > 1 else {}
    return {**media_variant_textures(variant), **themes} if variant else themes


def check_textures() -> dict[str, str]:
    """
    Return the textures of the FF windows of the variant of the dialog surface now (`variant_textures()` of `image_variant()`): the
    generation of a window and the key of its cache. The caches of the texture families are cleared when they changed.
    """
    global _theme_textures
    textures = variant_textures(image_variant())
    if textures != _theme_textures:
        if _theme_textures is not None:
            for cached in _texture_caches:
                cached.cache_clear()
        _theme_textures = textures
    return textures


def theme_textures() -> dict[str, str]:
    """Return the textures of the variant of the windows of the last `check_textures()` (the first call checks them)."""
    return check_textures() if _theme_textures is None else _theme_textures


def texture_stamp() -> str:
    """Return the stamp of the textures of the active themes now (`check_textures()`, a part of the key of the generated windows), '' none."""
    textures = check_textures()
    return hashlib.sha1(repr(sorted(textures.items())).encode('utf-8')).hexdigest()[:12] if textures else ''


def texture_path(rel: str, media: Path | None = None, *, variant: str | None = None) -> Path:
    """
    Return the file of the texture (relative to the media folder `media`, None `MEDIA`): of the variant (`variant_textures()`; None the
    one of the windows, `theme_textures()`) - of the active theme which has it, of the media folder of the variant of FF -, else in `media`.
    """
    textures = theme_textures() if variant is None else variant_textures(variant)
    return Path(path) if (path := textures.get(rel)) is not None else (MEDIA if media is None else media) / rel


def texture_url(path: str) -> str:
    """Return the file of a texture as Kodi's path: of the skin folder of FF (`SKIN_URL`: `media`, `media.<variant>`), of an add-on."""
    try:
        return f'{SKIN_URL}/{Path(path).relative_to(MEDIA.parent).as_posix()}'
    except ValueError:
        return addon_url(path)


def window_texture(name: str, *, variant: str | None = None) -> str:
    """
    Return the texture a window shows (the generated XML: `apply_window_textures()`; Python: an image, an icon of a list item) as Kodi's
    full path: the file of the variant which has it (relative to the media folder, `texture_path()`: of an active theme, of the media of
    the variant of FF; `texture_url()`), else the file of FF (`MEDIA_URL`). Kodi looks a relative name up in the skin and among the
    textures loaded by name first: a file of the same name there would win. Not a file of the media folder (`RX_NOT_A_FILE`: an info, a full path, a URL) or '': as it is.
    """
    if (path := (theme_textures() if variant is None else variant_textures(variant)).get(name)) is not None:
        return texture_url(path)
    return f'{MEDIA_URL}/{name}' if name and not RX_NOT_A_FILE.search(name) else name


def texture_file(texture: str) -> Path | None:
    """
    Return the file of a texture of a window (`window_texture()`: of FF, of a theme; a relative name: of FF), None: not a file of an
    add-on (an info, a URL, another path).
    """
    from ..ff.theme import addons_path
    if texture.startswith(f'{SKIN_URL}/'):  # the media of FF, of its variant
        return MEDIA.parent / texture[len(SKIN_URL) + 1:]
    if texture.startswith(ADDONS_URL):
        return addons_path() / texture[len(ADDONS_URL):]
    return None if RX_NOT_A_FILE.search(texture) else MEDIA / texture


@texture_cache  # the files are known once (`media_textures()`)
def switch_icon_size() -> tuple[int, int]:
    """Return the size (width, height) of the texture of a `compact` check box (`box_texture()`; unreadable: 74 x 64, today's file)."""
    return png_size(texture_path(box_texture(tokens().texture.box.check, frame=False).name('off', 0))) or (74, 64)


def switch_icon_width(height: float) -> int:
    """Return the width of the icon of a check box of the height (its texture of a `compact` check box scaled, as it shows it; rounded down)."""
    width, tex_height = switch_icon_size()
    return int(width * min(height, tex_height) // tex_height)


def switch_icon_height(width: float) -> int:
    """Return the height of the icon of a check box of the width (`switch_icon_width()` the other way)."""
    tex_width, height = switch_icon_size()
    return int(height * min(width, tex_width) // tex_width)


@frozen
class TextureName:
    """
    A texture file name `<base>.<part>…`: a part is a word (a state: `on`, `checked`, `1`) or `<letter><value>` (`RX_TEXTURE_PART`).
    The frame generator (tools/kodeco.py, `frame_name()`) writes `r` the radius (one value or the corners
    top-left, top-right, bottom-right, bottom-left) or `k` the same of chamfered corners (cut on a diagonal), `m` the margin, `n` the
    open sides (1 open: left, top, right, bottom; a tab joined to its panel), `j` the flare of the open sides (the inverted corners
    where a tab meets its panel), `s` a half of the pen (1 top-left, 2 bottom-right: the edge of a sunken / raised frame), `w` the pen
    width, `l` the pen colour, `c` the fill colour, `o` the fill opacity (`o0` the pen only: an edge), `p` the pen opacity (`p0`
    the inside only: a fill), `b` the nine-slice border (left, top, right, bottom); added by hand: `f` focused (0 / 1), `h` the
    height (the one the texture is made for, `size_rank()`).
    """

    #: The name without its parts (with its folder).
    base: str
    #: The parts after the base (no `.png`), in order.
    parts: tuple[str, ...]

    @classmethod
    def parse(cls, name: str) -> TextureName:
        """Return the parts of the name (`dialogs/checkbox.on.f0.b64_0_8_0.h64.png`; `.png` optional)."""
        folder, _, file = name.rpartition('/')
        base, *parts = (file[:-4] if file.endswith('.png') else file).split('.')
        return cls(f'{folder}/{base}' if folder else base, tuple(parts))

    @property
    def name(self) -> str:
        """Return the file name."""
        return '.'.join((self.base, *self.parts)) + '.png'

    def value(self, letter: str) -> str | None:
        """Return the value of the `<letter><value>` part (None: no such part)."""
        return next((m[2] for p in self.parts if (m := RX_TEXTURE_PART.fullmatch(p)) and m[1] == letter), None)

    def numbers(self, letter: str) -> tuple[float, ...]:
        """Return the numbers of a part (`b64_0_8_0`: 64, 0, 8, 0; one number for a box: all its sides), () no such part."""
        if (value := self.value(letter)) is None:
            return ()
        return tuple(float(v.replace('~', '.')) for v in re.split('[_,]', value))

    @property
    def corner(self) -> str | None:
        """
        Return the corner part of the name (`TEXTURE_CORNERS`: its kind and its radius - `r7` rounded, `k7_0_0_7` chamfered), None no
        such part.
        """
        return next((p for p in self.parts if (m := RX_TEXTURE_PART.fullmatch(p)) and m[1] in TEXTURE_CORNERS), None)


def tinted_surface(color: str, texture: str = '', *, under: str, fade: int = 100) -> str:
    """
    Return the colour of a surface (opaque `AARRGGBB`): the texture tinted by the colour (`AARRGGBB`; its colour and opacity by its
    name, `TextureName`: the fill `c`, the opacity `o` - a white mask without `c`; '' a white one), of the opacity `fade` (percent), over
    `under` (its colour); '' a texture of an unknown colour (a picture: no part `o`).
    """
    def channels(value: str) -> list[int]:
        """Return the numbers of the hex digits by two (one digit a doubled one: `C` - `CC`)."""
        value = ''.join(d * 2 for d in value) if len(value) in (1, 3) else value
        return [int(value[i:i + 2], 16) for i in range(0, len(value), 2)]

    name = TextureName.parse(texture) if texture else None
    if (opacity := name.value('o') if name else 'F') is None:
        return ''
    fill, (alpha, *rgb), (_, *below) = channels((name.value('c') if name else None) or 'FFF'), channels(color), channels(under)
    share = alpha / 255 * channels(opacity)[0] / 255 * fade / 100
    return 'FF' + ''.join(f'{round(u * (1 - share) + c * f / 255 * share):02X}' for u, c, f in zip(below, rgb, fill))


def contrast_ratio(color: str, surface: str) -> float:
    """Return the contrast (WCAG 2) of the colour (`AARRGGBB`: over the surface) on the surface (opaque `AARRGGBB`)."""

    def luminance(color: str) -> float:
        """Return the relative luminance of the colour (`AARRGGBB`)."""
        linear = [(c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4) for c in (int(color[i:i + 2], 16) / 255 for i in (2, 4, 6))]
        return .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2]

    light, dark = sorted((luminance(tinted_surface(color, under=surface)), luminance(surface)), reverse=True)
    return (light + .05) / (dark + .05)


@frozen
class BoxTexture:
    """The texture files of a check box (`box_texture()`): one name of the parts with the state and the focus as fields."""

    #: The texture name with the fields `{state}` (the state word) and `{focused}` (0 / 1).
    pattern: str
    #: The nine-slice border of the frame under the text (Kodi `border`: left, top, right, bottom), '' none (the whole texture scaled).
    border: str

    def name(self, state: str, focused: int) -> str:
        """Return the texture of the state, focused or not."""
        return self.pattern.format(state=state, focused=focused)

    def info(self, prop: str, focused: int) -> str:
        """Return the texture of the state in the window property `prop` (`$INFO[…,prefix,postfix]`: empty while the property is)."""
        prefix, _, postfix = self.name('\0', focused).partition('\0')
        return f'$INFO[Window.Property({prop}),{prefix},{postfix}]'


@frozen(kw_only=True)
class TextureImage:
    """A texture file as an image draws it: mirrored (Kodi `flipx` / `flipy`: one file for two sides), its border mirrored with it."""

    #: The file (in the media folder).
    name: str
    #: The nine-slice border of the drawn image (Kodi `border`: left, top, right, bottom on the screen), '' none.
    border: str
    #: Mirrored left to right.
    flipx: bool = False
    #: Mirrored top to bottom.
    flipy: bool = False


@frozen
class TabSide:
    """
    The texture of a tab on a side of its frame (`TAB_SIDES`): its file open to the frame, mirrored or not; where its tab bar starts
    (`tab_offset()`).
    """

    #: The open side of the file (its `n` part: left, top, right, bottom).
    open: str
    #: Mirrored left to right.
    flipx: bool = False
    #: Mirrored top to bottom.
    flipy: bool = False
    #: The corner of the frame where the tab bar starts (in the corner radii of its texture: top-left 0, top-right 1, bottom-right 2,
    #: bottom-left 3).
    corner: int = field(kw_only=True)
    #: The margin of the file along the side (in its `m` part: left 0 - a horizontal tab, top 1 - a vertical one).
    along: int = field(kw_only=True)
    #: The corner of the frame where the tab bar ends (the other end of the side; as `corner`).
    end: int = field(kw_only=True)
    #: The edge of a tab widget its tab bar lies on (a Kodi geometry tag: left, top, right, bottom), its pages towards the other one.
    edge: str = field(kw_only=True)

    @property
    def closed(self) -> int:
        """Return the corners of its file between two closed sides (the mask of `texture_corners()`: top-left 8 … bottom-left 1)."""
        opened = [part != '0' for part in self.open.split('_')]  # left, top, right, bottom
        return sum(bit for bit, (a, b) in zip((8, 4, 2, 1), ((0, 1), (1, 2), (2, 3), (3, 0))) if not opened[a] and not opened[b])


#: The side of a tab to its frame (its tab bar on the side W, N, E, S of the frame) -> its texture: E is the file of W mirrored, S
#: the one of N (Kodi has no rotation: a vertical and a horizontal file); its tab bar from the top / left end of the side.
TAB_SIDES: dict[str, TabSide] = {
    'W': TabSide('0_0_1_0', corner=0, along=1, end=3, edge='left'),
    'E': TabSide('0_0_1_0', flipx=True, corner=1, along=1, end=2, edge='right'),
    'N': TabSide('0_0_0_1', corner=0, along=0, end=1, edge='top'),
    'S': TabSide('0_0_0_1', flipy=True, corner=3, along=0, end=2, edge='bottom'),
}

#: The masks of a shape of a texture family by their names: the edge (the pen alone, `o0`), the fill (the inside of the pen, `p0`).
TEXTURE_MASKS: dict[str, str] = {'edge': 'o0', 'fill': 'p0'}


def flipped_texture(name: str, *, flipx: bool = False, flipy: bool = False) -> TextureImage:
    """
    Return the image of a texture file mirrored: Kodi keeps the border on the screen and mirrors what it samples, so the border of
    a mirrored image is the border of its file mirrored too (left and right swapped for `flipx`, top and bottom for `flipy`).
    """
    border = texture_border(name)
    if len(sides := border.split(',')) == 4:  # one value: the same mirrored
        left, top, right, bottom = sides
        if flipx:
            left, right = right, left
        if flipy:
            top, bottom = bottom, top
        border = ','.join((left, top, right, bottom))
    return TextureImage(name=name, border=border, flipx=flipx, flipy=flipy)


def size_rank(tex: TextureName, width: float = 0, height: float = 0) -> tuple[float, ...]:
    """
    Return the order of a texture of a family for the size it is drawn at (0: any; the lowest first): the one made for a height (the
    `h` part) - the lowest `h` >= `height` (`height` 0: the highest), then the highest below; else the one whose nine-slice border fits
    the size (Kodi draws a texture at least as large as its border: a thinner element would grow) - the largest border that fits,
    then the smallest that does not.
    """
    if heights := tex.numbers('h'):
        h = heights[0]
        return (0, -h) if not height else (0, h) if h >= height else (1, -h)
    border = tex.numbers('b') or (0,)
    left, top, right, bottom = border * 4 if len(border) == 1 else border
    fits = (not width or left + right <= width) and (not height or top + bottom <= height)
    size = left + top + right + bottom
    return (2, -size) if fits else (3, size)


def fit_texture(textures: Iterable[TextureName], width: float = 0, height: float = 0) -> TextureName:
    """
    Return the texture of a family (one look in its sizes) for the size it is drawn at (`size_rank()`); none fitting: the nearest one
    and a warning (it is drawn larger). No texture: an error.
    """
    tex = min(textures, key=lambda tex: (size_rank(tex, width, height), tex.name), default=None)
    if tex is None:
        raise ValueError('No texture to fit')
    if size_rank(tex, width, height)[0] % 2:  # the groups of the ones which do not fit
        fflog.warning(f'Texture: no {tex.base} fits {width:g} x {height:g}, {tex.name} drawn larger')
    return tex


def tab_texture(side: str, *, current: bool, mask: str, width: float = 0, height: float = 0, shape: str = '') -> TextureImage:
    """
    Return the image of a tab on the side of its frame (`TAB_SIDES`: W, N, E, S), current (joined to its panel, overlapping its edge)
    or not (behind its panel), its mask (`TEXTURE_MASKS`: edge, fill), drawn at the size (the tab with its flare zones along the frame):
    a file of the family `texture.tab` of the shape (`TAB_SHAPES`, '' the one of the style `tab.shape`) - its corners, its flare
    when current - open to the frame, mirrored for E / S.
    """
    look, place = TAB_SHAPES[shape or tokens().tab.shape], TAB_SIDES[side]
    if not look.joined:
        raise ValueError(f'A tab of no panel ({shape or tokens().tab.shape}) has no tab texture')
    base, corner, flare = tokens().texture.tab, 'k' if look.chamfer else 'r', current and look.flare
    family = [tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and tex.value('n') == place.open
              and tex.value(corner) is not None and (tex.value('j') is not None) == flare and TEXTURE_MASKS[mask] in tex.parts]
    if not family:
        raise ValueError(f'No tab texture {base!r} of the side {side} ({shape or tokens().tab.shape}, {"current" if current else "not current"}, {mask})')
    return flipped_texture(fit_texture(family, width, height).name, flipx=place.flipx, flipy=place.flipy)


def tab_margin(side: str, *, width: float = 0, height: float = 0, shape: str = '') -> int:
    """
    Return the margin of a tab on the side of its panel (`TAB_SIDES`) along the side, at each end of its place: the `m` part of its
    texture of the shape ('' the one of the style; drawn at the size) - the place of the flare of a current tab, the same for a tab
    which is not current (their bodies match); a tab of no panel (flat, of a line: no texture of the family): 0.
    """
    if not TAB_SHAPES[shape or tokens().tab.shape].joined:
        return 0
    tex = TextureName.parse(tab_texture(side, current=True, mask='fill', width=width, height=height, shape=shape).name)
    return int(((tex.numbers('m') or (0,)) * 4)[TAB_SIDES[side].along])


def tab_offset(side: str, panel: str, *, width: float = 0, height: float = 0, shape: str = '', end: bool = False) -> int:
    """
    Return where the place of the first tab of a tab bar on the side of its panel (`TAB_SIDES`) starts, from the corner of the panel
    at the start of the side (`end`: where the place of the last one ends, from the corner at the end of the side - a bar cut to the
    side): its tabs clear the corner, rounded or chamfered (the radius of the panel texture `panel` there, `texture_radius()`) by the flare of a
    current tab (the `j` part of its texture of the shape, '' the one of the style; drawn at the size: its tip ends where the corner
    does), less the margin of the texture before the tab (`tab_margin()`: the place starts there); a tab of no panel (flat, of a line:
    no panel to join, `TAB_SHAPES`): at the corner, 0.
    """
    if not TAB_SHAPES[shape or tokens().tab.shape].joined:
        return 0
    place = TAB_SIDES[side]
    radii = tuple(float(r) for r in re.split('[_,]', texture_radius(panel)[1:]))  # its corner part: the kind, the radii
    tex = TextureName.parse(tab_texture(side, current=True, mask='fill', width=width, height=height, shape=shape).name)
    flare = tex.numbers('j') or (0,)
    offset = (radii * 4)[place.end if end else place.corner] + flare[0] - tab_margin(side, width=width, height=height, shape=shape)
    return max(0, int(offset))


@frozen(kw_only=True)
class BevelImage:
    """A half of the edge of a sunken / raised frame (`bevel_images()`): its image, its colour."""

    #: The image (the top-left half, or its file turned for the bottom-right one).
    image: TextureImage
    #: Its colour (`color.bevel.light` / `.dark`: `FRAME_SHAPES`).
    color: str


def bevel_images(texture: str, shape: str) -> tuple[BevelImage, ...]:
    """
    Return the halves of the edge of a frame of the texture for its shape (`FRAME_SHAPES`: their colours of a sunken / raised one,
    none of the others). The file: the top-left half of the family `texture.bevel` of the corners of the texture (its corner part:
    the same kind - rounded, chamfered - and radius) and the width `metric.bevel`, turned (mirrored both ways) for the bottom-right
    half; none such (a texture without the corner part: the dialog), none.
    """
    style, look = tokens(), FRAME_SHAPES[shape]
    corner, base = TextureName.parse(texture).corner, style.texture.bevel
    if not look.top_left or corner is None:
        return ()
    want = {corner, f'w{style.metric.bevel}', 's1', TEXTURE_MASKS['edge']}
    found = next((tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and want <= set(tex.parts)), None)
    if found is None:
        return ()
    return (BevelImage(image=flipped_texture(found.name), color=str(style.values[look.top_left])),
            BevelImage(image=flipped_texture(found.name, flipx=True, flipy=True), color=str(style.values[look.bottom_right])))


def box_edge(texture: str, width: int, fill: str) -> TextureImage | None:
    """
    Return the image of the edge of a box frame of the texture (`FRAME_SHAPES`: box) over its translucent fill (`AARRGGBB`): the outline
    of the family `texture.bevel` of the corners of the texture (its corner part: the same kind and radius) and the pen `width`
    (`metric.frame.box`), whole (no half `s`) and with no fill (`o0`) - the colour of the edge does not show through the fill. None: no
    edge (`width` 0), an opaque fill (it hides the edge under it: crisper in a scaled GUI, the windows of the base the same) or no such
    outline (a texture without the corner part - the dialog -, another pen): the edge is the texture under the fill (its bordersize).
    """
    if not width or fill[:2].upper() == 'FF':
        return None
    return bevel_outline(texture, width)


def bevel_outline(texture: str, width: int) -> TextureImage | None:
    """
    Return the image of the whole outline of an element of the texture (`box_edge()`, a closed popup card `popup_edge()`): the file of the
    family `texture.bevel` of the corners of the texture (its corner part: the same kind and radius), the pen `width`, no half (`s`), no
    fill (`o0`); None: a texture without the corner part (the dialog), no such file.
    """
    corner, base = TextureName.parse(texture).corner, tokens().texture.bevel
    if corner is None:
        return None
    want = {corner, f'w{width}', TEXTURE_MASKS['edge']}
    found = next((tex for tex in media_textures(base.rpartition('/')[0])
                  if tex.base == base and want <= set(tex.parts) and tex.value('s') is None), None)
    return None if found is None else flipped_texture(found.name)


def texture_radius(name: str) -> str:
    """
    Return the corners of a texture (the shape of the element it draws) as a corner part of a name: the one of its name
    (`TextureName.corner`: rounded `r` or chamfered `k`, one value or four), else the radius declared at the texture token of that file
    (`Token.radius`: a look prefix like `dialogs/checkbox` too; rounded), `r0` none (square). The families of the element (its focus
    ring, its bevel) have the member of the same part.
    """
    if (corner := TextureName.parse(name).corner) is not None:
        return corner
    return f'r{next((token.radius for token in TOKENS if token.default == name), 0)}'


def focus_texture(texture: str = '') -> TextureImage:
    """
    Return the image of the focus ring of an element drawn by the texture (its corners: `texture_radius()`; '' a square element): the
    file of the family `texture.focus` of that radius and the pen `metric.focus`, an outline with no fill (on the edge of its place).
    """
    style = tokens()
    return _focus_texture(texture_radius(texture), style.texture.focus, style.metric.focus)


@texture_cache  # the files are known once (`media_textures()`); the style values in the key (a new style: a new entry)
def _focus_texture(corner: str, base: str, pen: int) -> TextureImage:
    """Return the focus ring of `focus_texture()`: the corner part `corner`, the family `base`, the pen `pen`."""
    want = {corner, f'w{pen}', TEXTURE_MASKS['edge']}
    found = next((tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and want <= set(tex.parts)), None)
    if found is None:
        raise ValueError(f'No focus ring {base!r} of the corners {corner} ({", ".join(sorted(want))})')
    return flipped_texture(found.name)


def shape_fill(texture: str = '') -> TextureImage:
    """
    Return the image of the fill of the shape of an element drawn by the texture (its corners: `texture_radius()`; '' a square element):
    the file of the family `texture.fill` of that radius (white, opaque) - a tint over the element in a colour (the inside of its focus
    ring while it is edited, `focus_ring`).
    """
    return _shape_fill(texture_radius(texture), tokens().texture.fill)


@texture_cache  # the files are known once (`media_textures()`); the style values in the key (a new style: a new entry)
def _shape_fill(corner: str, base: str) -> TextureImage:
    """Return the fill of `shape_fill()`: the corner part `corner`, the family `base`."""
    found = next((tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and tex.corner == corner), None)
    if found is None:
        raise ValueError(f'No fill {base!r} of the corners {corner}')
    return flipped_texture(found.name)


#: The look of a check box drawn as a toggle switch (`check_box` param `look`: not a texture family; `toggle_look` in `buttons.xml`).
TOGGLE: str = 'toggle'
#: The time of a change of a toggle switch: the slide of its knob, the fades of its track and its mark (ms).
TOGGLE_TIME: int = 150


@frozen(kw_only=True)
class ToggleVars:
    """The template vars of a toggle switch (`toggle_vars()`, the define `toggle_look` in `buttons.xml`)."""

    #: The size of the track.
    width: int
    height: int
    #: The track: a file of the family `texture.slider.track` rounded by `factor.toggle.radius` of its height (`round_texture()`).
    track: str
    #: The side of the knob, its inset in the track, its move from a place to the next one.
    knob: int
    pad: int
    step: int
    #: The knob: a file of the same family rounded the same way (a part of its side: round at 0.5, a rounded square below).
    knob_texture: str
    #: The side of the image of the mark of the state (✓ / ✗: its glyph about two thirds of it).
    icon: int
    #: The gap between the track and its focus ring (around it, its corners: the radius of the track and the gap).
    gap: int
    #: The radius of the corners of the track.
    radius: int

    @property
    def ring(self) -> str:
        """Return the focus ring: its file (`focus_texture()` of it is itself); only a switch of its own ring needs it (a row has its frame)."""
        style = tokens()
        return _focus_texture(f'r{self.radius + self.gap}', style.texture.focus, style.metric.focus).name


def toggle_vars(tristate: bool = False) -> ToggleVars:
    """
    Return the template vars of a toggle switch (two-state or `tristate`: three places of its knob): its size (`metric.toggle.*`), its
    track and its knob rounded by one rule (`factor.toggle.radius` of their heights: 0.5 a pill and a round knob), its focus ring.
    """
    style = tokens()
    metric, factor = style.metric.toggle, style.factor.toggle.radius
    height, width = metric.height, metric.width.tristate if tristate else metric.width
    pad = height // 9
    knob, gap, radius = height - 2 * pad, 2 * style.metric.focus, round(factor * height)
    return ToggleVars(width=width, height=height, track=round_texture(style.texture.slider.track, radius), knob=knob, pad=pad,
                      step=(width - height) // (2 if tristate else 1), knob_texture=round_texture(style.texture.slider.track, round(factor * knob)),
                      icon=height * 3 // 4, gap=gap, radius=radius)


#: The steps of the zoom of the line beside the label of a separator of a group (`row_separator`): powers of two, their sum the steps
#: of a zoom (`separator_zoom()`: the zooms of the bits multiply) - any length of the line from its whole down to 1/256 of it.
SEPARATOR_BITS: tuple[int, ...] = tuple(1 << n for n in range(11))
#: The steps of the zoom of a separator line in one halving of its length (a step: 0.27 %, a pixel in a line of 370).
SEPARATOR_OCTAVE: int = 256


def separator_zoom(steps: int) -> str:
    """Return the zoom of the steps of a separator line (`SEPARATOR_OCTAVE`): its width in percent (the Kodi `end` of a zoom)."""
    return f'{100 * 2 ** (-steps / SEPARATOR_OCTAVE):.4f}'


def group_alignment(align: str = '') -> str:
    """Return where the label of a group breaks the line of its separator (`GROUP_ALIGNS`; '' the style `group.align`)."""
    align = align or tokens().group.align
    if align not in GROUP_ALIGNS:
        raise ValueError(f'Unknown alignment {align!r} of the label of a group (not one of {", ".join(GROUP_ALIGNS)})')
    return align


def line_height(style: str) -> int:
    """Return the height of a line of the font role (`ff:style`) of the skin, rounded up (as the layout sizes a text of `ff:lines`)."""
    from math import ceil
    from .skinfonts import text_metrics
    return ceil(text_metrics(style)[1])


def group_band(separators: bool, names: str = '') -> int:
    """
    Return the band of the label of a group over a row (`row_separator`): the line height of the font `group` while the separators are
    drawn (`separators`) with the names of the groups shown (`names`: shown, hidden; '' the style `group.names`), else 0.
    """
    from .skinfonts import text_metrics
    if not separators or (names or tokens().group.names) != 'shown':
        return 0
    return round(text_metrics('group')[1])


def popup_texture(side: str, width: int = 0) -> TextureImage:
    """
    Return the image of an outline open on one side: the edge of a drop-down list on a side of its field (S: under it, N: over it; Qt:
    the frame of the popup of a QComboBox), a tab of a line on a side of its pages (`TAB_SHAPES`: the line beside the bar) - a file of
    the family `texture.popup` open to the field / the pages, as a tab on that side of its panel (`TAB_SIDES`: the file open E or S,
    mirrored for E / S), its pen `width` (0: `metric.frame.box`), its corners those of the panel texture (`texture.panel`: the same
    kind and radius) at its closed side (`masked_corner()`).
    """
    style, place = tokens(), TAB_SIDES[side]
    base, pen = style.texture.popup, f'w{width or style.metric.frame.box}'
    want = {masked_corner(texture_radius(style.texture.panel), place.closed), pen}
    found = next((tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and tex.value('n') == place.open and want <= set(tex.parts)),
                 None)
    if found is None:
        raise ValueError(f'No outline open on one side {base!r} of the side {side} ({", ".join(sorted(want))})')
    return flipped_texture(found.name, flipx=place.flipx, flipy=place.flipy)


def popup_edge(side: str) -> TextureImage:
    """
    Return the image of the edge of an open popup card on a side of its field (S: under it, N: over it) by `popup.shape`
    (`POPUP_SHAPES`): closed - the whole outline of the panel texture (`bevel_outline()`: the line between the field and the card), joined -
    open to the field (`popup_texture()`); its pen `metric.frame.box`.
    """
    style = tokens()
    if tokens().popup.shape == 'joined':
        return popup_texture(side)
    if (found := bevel_outline(style.texture.panel, style.metric.frame.box)) is None:
        raise ValueError(f'No outline {style.texture.bevel!r} of the texture {style.texture.panel!r} (w{style.metric.frame.box})')
    return found


def popup_fill(side: str) -> TextureImage:
    """
    Return the image of the fill in the outline open on one side (`popup_texture()`: a focused tab of a line): the panel texture
    (`texture.panel`) rounded only at the corners of its closed side (`texture_corners()`), mirrored as the outline.
    """
    place = TAB_SIDES[side]
    return flipped_texture(texture_corners(tokens().texture.panel, place.closed), flipx=place.flipx, flipy=place.flipy)


def more_texture(side: str) -> TextureImage:
    """
    Return the image of a mark of more rows at the side of a list (W, N, E, S: the way it points; Qt: the scroll arrows of a tab bar):
    a triangle of the family `texture.more` - the file pointing E (its right corners chamfered) or S (its bottom ones) - mirrored for
    W / N (Kodi has no rotation), drawn whole (no border: scaled to its place).
    """
    base, down = tokens().texture.more, side in 'NS'
    found = next((tex for tex in media_textures(base.rpartition('/')[0]) if tex.base == base and ((tex.numbers('k') or (0,) * 4)[3] > 0) == down), None)
    if found is None:
        raise ValueError(f'No mark of more rows {base!r} of the side {side}')
    return TextureImage(name=found.name, border='', flipx=side == 'W', flipy=side == 'N')


#: The anchors of an element on its host (`anchor_place()`): its corners, the middles of its sides (N, E, S, W), its centre (C).
ANCHORS: tuple[str, ...] = ('NW', 'N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'C')


@frozen(kw_only=True)
class AnchorPlace:
    """
    The place of an element anchored to its host (a tag, an edge mark: `anchor_place()`): the anchor point - a group of no size at a
    corner, in the middle of a side or in the centre of the host (its place: Kodi has no "50 % + N", a group clips no children) - and the
    element from that point.
    """

    #: Where the point lies across the host: W - at its left side, E - at its right side, '' - in its middle.
    x: str
    #: Where the point lies down the host: N - at its top, S - at its bottom, '' - in its middle.
    y: str
    #: The left of the element from the point.
    left: int
    #: The top of the element from the point.
    top: int
    #: The width of the element.
    width: int
    #: The height of the element.
    height: int
    #: The slots of a middle anchor (a side, the centre) - its group of the slots of that anchor in its host, centred as one by
    #: `geometry.centre_slots()`: `<anchor> <axis> <step>` (the position tag along its edge, the slot after slot); '' a corner.
    slots: str = ''


def anchor_place(anchor: str, width: int, height: int, *, out: str = '', edge: str = '', slot: int = 1, gap: int | None = None,
                 clear: bool = False, factor: float | None = None) -> AnchorPlace:
    """
    Return the place of an element of the size anchored to its host (`ANCHORS`). It lies on an edge of the host: the side of a middle
    anchor, in a corner the side of its `edge` (`TAG_EDGES`, '' the style `tag.edge`), none in the centre. It sticks out by `out`
    (`TAG_OUTS`, '' the style `tag.out`) from that edge: up - out across it, side - past the corner along it (in a corner only), corner -
    both, inside - none; by `factor` (None the style `factor.tag.out`) of its size across the edge it crosses. The slot `slot` (1, 2 ...) of the anchor moves it
    along its edge by its size and `gap` (None the style `space.gap.tag`) for every slot before it: from the corner; a middle anchor and
    the centre - from the middle to the right / down, the slots of that anchor in the host then centred as a group (`slots`). `clear`:
    in a corner (not past it) the first slot lies `space.tag.corner` from it, clear of the side of the host (a tag).
    """
    if anchor not in ANCHORS:
        raise ValueError(f'Unknown anchor {anchor!r} (not one of {", ".join(ANCHORS)})')
    style = tokens()
    out, edge = out or style.tag.out, edge or style.tag.edge
    if out not in TAG_OUTS:
        raise ValueError(f'Unknown out {out!r} of an anchored element (not one of {", ".join(TAG_OUTS)})')
    if edge not in TAG_EDGES:
        raise ValueError(f'Unknown edge {edge!r} of an anchored element (not one of {", ".join(TAG_EDGES)})')
    gap = style.space.gap.tag if gap is None else gap
    x = 'W' if 'W' in anchor else 'E' if 'E' in anchor else ''
    y = 'N' if 'N' in anchor else 'S' if 'S' in anchor else ''
    vertical = bool(x) and (not y or edge == 'vertical')  # its edge: a side W / E (else N / S, or none in the centre)
    across, past = out in ('up', 'corner'), out in ('side', 'corner') and bool(x and y)
    factor = style.factor.tag.out if factor is None else factor
    out_x = round(width * factor) if (across if vertical else past and bool(y)) else 0
    out_y = round(height * factor) if (past if vertical else across and bool(y)) else 0
    corner = style.space.tag.corner if clear and x and y and not past else 0
    along_x, along_y = (0, corner + (slot - 1) * (height + gap)) if vertical else (corner + (slot - 1) * (width + gap), 0)

    def offset(side: str, low: str, size: int, out: int, along: int) -> int:
        """Return the offset of the element from the point on one axis (`side`: the side of the point, `low` the left / top one)."""
        if not side:
            return -(size // 2) + along
        return along - out if side == low else out - size - along

    slots = '' if x and y else f'{anchor} {"top" if vertical else "left"} {(height if vertical else width) + gap}'
    return AnchorPlace(x=x, y=y, left=offset(x, 'W', width, out_x, along_x), top=offset(y, 'N', height, out_y, along_y), width=width,
                       height=height, slots=slots)


def filter_shown(edit: int | str, clear: int | str) -> str:
    """
    Return the Kodi condition of the filter field of a tree shown (on demand, Kodi has no state of it): the field or its clear button
    (their control IDs, widget references) has the focus, or the field has a text.
    """
    return f'Control.HasFocus({edit}) | Control.HasFocus({clear}) | !String.IsEmpty(Control.GetLabel({edit}).index(1))'


def tag_room(height: int = 0) -> int:
    """
    Return the room a tag sticking out of the top of its host needs over it (a row of a list: Kodi clips the rows to the list) - its
    part out of the edge (`factor.tag.out` of its `height`, 0 `metric.tag.height`) and the gap to the element over it (`space.gap.tag`).
    """
    style = tokens()
    return round((height or style.metric.tag.height) * style.factor.tag.out) + style.space.gap.tag


@texture_cache  # the files are known once (`media_textures()`)
def size_texture(name: str, width: float = 0, height: float = 0) -> str:
    """
    Return the file of the look of the texture for the size it is drawn at (`fit_texture()`; a thin element - a tag, a bar - needs a
    smaller border): the files of its base with its other parts, its corners of the same kind (rounded, chamfered) given the same way
    (one radius or the four corners), any radius and border.
    """
    tex = TextureName.parse(name)

    def look(t: TextureName) -> tuple[frozenset[str], str, int]:
        """Return the parts of the look (not the corners, not the border), the kind of the corners and the number of their values."""
        corner = t.corner or ''
        return (frozenset(p for p in t.parts if not (p[0] in f'{TEXTURE_CORNERS}b' and RX_TEXTURE_PART.fullmatch(p))), corner[:1],
                len(re.split('[_,]', corner[1:])))

    want = look(tex)
    return fit_texture((t for t in media_textures(tex.base.rpartition('/')[0]) if t.base == tex.base and look(t) == want), width, height).name


@texture_cache  # the files are known once (`media_textures()`)
def round_texture(name: str, radius: int) -> str:
    """
    Return the file of the look of the texture (its base, its parts but the corners and the border, as `size_texture()`) rounded by the
    radius (`r<radius>`: a shape of its height rounded by a part of it, a toggle switch); none such: an error (`render check`).
    """
    tex = TextureName.parse(name)
    others = {p for p in tex.parts if not (p[0] in f'{TEXTURE_CORNERS}b' and RX_TEXTURE_PART.fullmatch(p))}
    found = next((t for t in media_textures(tex.base.rpartition('/')[0]) if t.base == tex.base and t.corner == f'r{radius}'
                  and {p for p in t.parts if not (p[0] in f'{TEXTURE_CORNERS}b' and RX_TEXTURE_PART.fullmatch(p))} == others), None)
    if found is None:
        raise ValueError(f'No texture {tex.base!r} rounded by r{radius} ({", ".join(sorted(others))})')
    return found.name


@frozen
class Decoration:
    """A decoration of a window (`decor_images()`)."""

    #: The file of its image.
    image: str
    #: The Kodi condition of its period, '' always.
    when: str = ''


def decor_images(value: str) -> tuple[Decoration, ...]:
    """
    Return the decorations of the value of a `decor.*` token (`style.RX_DECOR`): the images of the variant of the surface of a window
    (`theme.art()`), a period the condition `System.Date` - Kodi takes its end as exclusive, the token gives the last day.
    """
    from datetime import date, timedelta
    from ..ff.theme import art
    from .style import RX_DECOR, image_variant

    def day_after(month_day: str) -> str:
        """Return the day after `MM-DD` (a leap year: 02-29 is a day)."""
        month, day = map(int, month_day.split('-'))
        return f'{date(2024, month, day) + timedelta(days=1):%m-%d}'

    found: list[Decoration] = []
    for part in filter(None, map(str.strip, value.split(','))):
        if not (mch := RX_DECOR.fullmatch(part)):
            continue
        when = f'System.Date({mch["first"]},{day_after(mch["last"])})' if mch['first'] else ''
        found.append(Decoration(image=art(mch['image'], variant=image_variant()), when=when))
    return tuple(found)


def texture_border(name: str) -> str:
    """
    Return the nine-slice border of a texture (Kodi `border`: left, top, right, bottom): the `b` part of its name, else the one
    declared at the texture token of that file (`Token.border`), '' none.
    """
    if (border := TextureName.parse(name).value('b')) is not None:
        return border.replace('_', ',')
    return next((token.border for token in TOKENS if token.default == name), '')


def texture_inset(name: str) -> int:
    """Return the inset of the content in a frame texture (Kodi `bordersize`) declared at the texture token of that file, 0 none."""
    return next((token.inset for token in TOKENS if token.default == name), 0)


def masked_corner(corner: str, corners: int) -> str:
    """
    Return the corner part of a name (`texture_radius()`: `r7`, `k7_0_0_7`) kept only at the corners of the bit mask `corners` (top-left
    8, top-right 4, bottom-right 2, bottom-left 1), the others square; no corner - a square of either kind (`r0`).
    """
    if not corners:
        return 'r0'
    if corners == 0b1111:
        return corner
    kind, radii = corner[:1], re.split('[_,]', corner[1:])
    return kind + '_'.join((radii * 4)[i] if corners >> (3 - i) & 1 else '0' for i in range(4))


@texture_cache  # the files are known once (`media_textures()`)
def texture_corners(name: str, corners: int) -> str:
    """
    Return the texture of the name rounded (or chamfered) only at some corners: the bit mask `corners` (top-left 8, top-right 4,
    bottom-right 2, bottom-left 1) with the radius and the kind of its corner part (`TextureName.corner`; none: a square, `r0`), the
    file of the media folder with the other parts the same but `b` (its border).
    """
    tex = TextureName.parse(name)
    want = {masked_corner(tex.corner or 'r', corners), *(p for p in tex.parts if p[0] not in f'{TEXTURE_CORNERS}b' or not RX_TEXTURE_PART.fullmatch(p))}
    found = next((t for t in media_textures(tex.base.rpartition('/')[0])
                  if t.base == tex.base and {p for p in t.parts if p[0] != 'b' or not RX_TEXTURE_PART.fullmatch(p)} == want), None)
    if found is None:
        raise ValueError(f'No texture {name!r} with the corners {corners:04b}')
    return found.name


@texture_cache
def media_textures(folder: str) -> tuple[TextureName, ...]:
    """
    Return the parsed names of the PNG textures of a media folder (`dialogs`) by name: of FF and of the active themes (`theme_textures()`:
    a theme may add a member of a family; the same name is one texture, its file the one of the theme).
    """
    textures = {tex.name: tex for tex in (TextureName.parse(f'{folder}/{path.name}') for path in (MEDIA / folder).glob('*.png'))}
    textures.update((rel, TextureName.parse(rel)) for rel in theme_textures() if rel.endswith('.png') and rel.rpartition('/')[0] == folder)
    return tuple(textures[name] for name in sorted(textures))


@texture_cache  # the files are known once (`media_textures()`)
def box_texture(look: str, *, frame: bool, height: float = 0, states: tuple[str, ...] = ('off', 'on')) -> BoxTexture:
    """
    Return the texture files of a check box of the look (`dialogs/checkbox`; with look parts, e.g. `dialogs/checkbox.cCCC`, only the
    files with them) in the media folder: the set of a file for each state word (`states`: of a check box `off`, `on`; of a switch its
    positions `1`, `2` ...) and focus (`f0`, `f1`) with the same other parts.
    `frame`: the box and its frame stretched under the text (a `b` part with a left border, the text margin: its `border`), else
    a lone box (preferred a file without the `b` part; else the whole texture scaled as it is). The height: `size_rank()` (the lowest
    `h` >= `height`, `height` 0: the highest). Of the rest the one with the fewest look parts. A missing file of the chosen set is an error.
    """
    want = TextureName.parse(look)
    folder = want.base.rpartition('/')[0]
    sets: dict[tuple[str, ...], set[tuple[str, str]]] = {}
    for tex in media_textures(folder):
        state, focused = next((p for p in tex.parts if p in states), None), tex.value('f')
        if tex.base == want.base and state is not None and focused is not None and set(want.parts) <= set(tex.parts):
            key = tuple('{state}' if p == state else 'f{focused}' if p == f'f{focused}' else p for p in tex.parts)
            sets.setdefault(key, set()).add((state, focused))

    def rank(key: tuple[str, ...]) -> tuple[float, ...]:
        """Return the order of a set (the lowest first)."""
        tex = TextureName(want.base, key)
        looks = sum(1 for p in key if not p.startswith(('{', 'f{')) and not (p[0] in TEXTURE_GEOMETRY and RX_TEXTURE_PART.fullmatch(p)))
        return (0 if frame or tex.value('b') is None else 1, *size_rank(tex, height=height), looks)

    usable = [key for key in sets if not frame or (TextureName(want.base, key).numbers('b') or (0,))[0] > 0]
    if not usable:
        raise ValueError(f'No texture files of the look {look!r} ({"with" if frame else "of"} a frame) in {MEDIA / folder}')
    key = min(usable, key=lambda k: (rank(k), k))
    if missing := {(s, f) for s in states for f in '01'} - sets[key]:
        raise ValueError(f'Missing texture files of the look {look!r}: '
                         + ', '.join(TextureName(want.base, key).name.format(state=s, focused=f) for s, f in sorted(missing)))
    pattern = TextureName(want.base, key).name
    return BoxTexture(pattern=pattern, border=texture_border(pattern) if frame else '')


@fonts_frozen()  # the text measures of the generation take the fonts of one check (nested: nothing)
def render_xml(xml_source: Path, request: CustomXmlRequest | None = None, *,
               sizes: Mapping[str, Mapping[str, int]] | None = None) -> tuple[bytes, CustomXmlData]:
    """
    Generate a window of widgets (its source in `WIDGETS_FOLDER`), return the output XML and its data: a strict xgui template,
    its modules next to it. Every fault is an error with its position (`TemplateError`); the rows / columns laid out
    (`layout.apply_layout()`; before it the controls of a group in their layers, `geometry.apply_layers()`; a widget whose template reads
    a size of its use the layout gives it - `XmlManager.use_value()` - generated with `sizes`, the ones of an earlier generation of the
    window (`CustomXmlData.sizes`, the layout reads no content there: they hold), the window generated again when the layout gives other
    ones), the overlays moved over the window (`geometry.apply_overlays()`), then the focus lines
    (`focus_lines.apply_focus_lines()`), the moves of the groups in grouplists (`layout.apply_grouplist_moves()`), with `const.dev.outline` the
    outline of the layout (`outline.apply_outline()`), a default control Kodi cannot focus at the open left to Python
    (`defer_default_control()`); the output has comments of its sources and no template attributes.
    """
    # The owner's option of the old pipeline (an explicit window ID, off), kept as it was there (in the `<window>` tag
    # substitution, `RX_XML_WIN_ID = re.compile(r'\bid="([^"]*)"', flags=re.DOTALL)`, `RX_WIN_PROP = re.compile(r'\b(Window)\.(Property)\b')`,
    # `AUTO_WINDOW_ID = 5900`; after the substitution `RX_WIN_PROP.sub(fr'\1({win_id}).\2', xml_data)` if `win_id`):
    #     if False:
    #         # Nie wiem czemu podanie jawnie ID działa jeszcze gorzej. Do obadania. [rysson]
    #         if mid := RX_XML_WIN_ID.search(mch[1]):
    #             nonlocal orig_win_id
    #             orig_win_id = mid[1]
    #         else:
    #             global AUTO_WINDOW_ID
    #             nonlocal win_id
    #             win_id = AUTO_WINDOW_ID = AUTO_WINDOW_ID + 1
    #             win = f'{win} id="{win_id}"'
    from .xgui import XmlManager, TemplateError, TEMPLATE_NAMESPACES
    from ..ff.theme import skin_widgets
    if request is None:
        request = CustomXmlRequest()
    check_textures()  # the families of the textures of the themes now
    _fonts, font_styles = window_fonts()
    #: The widgets of the themes failing in this window (`<theme>:<name>` -> the error): generated again with the ones of FF.
    faulty: dict[str, str] = {}
    #: The sizes of the widgets reading their missing use sizes: the seed, then the ones the layout gave them (`XmlManager.layout_sizes()`).
    layout_sizes: dict[str, dict[str, int]] = {path: dict(tags) for path, tags in (sizes or {}).items()}
    resized = False  # the window generated again with the sizes of its layout (once: the layout reads no content there, they hold)
    while True:  # a broken theme never breaks a window of FF
        manager = XmlManager(vars=request.vars, font_styles=font_styles, folder=xml_source.parent, faulty=faulty, sizes=layout_sizes)
        try:
            root = layout_window(xml_source, manager, font_styles)
            given = manager.layout_sizes(root)
            if not resized and any(layout_sizes.get(path) != tags for path, tags in given.items()):
                layout_sizes, resized = given, True
                continue  # once more: the widgets of their sizes of the layout (the same layout: no hint of their content there)
            layout_sizes = given  # the ones read (a seed may have more)
            break
        except TemplateError as exc:
            # in a widget of a theme (its generation), or at a position in a file of a theme (the layout of its output): all its widgets
            if not (failed := ({exc.widget} if exc.widget else manager.theme_widgets(exc.src)) - faulty.keys()):
                raise
            faulty.update(dict.fromkeys(failed, str(exc)))  # the warning: `XmlManager.add_theme_widgets()`
    _remote_textures[:] = drop_remote_textures(root) if skin_widgets() else ()
    default_focus = defer_default_control(root)
    if const.dev.outline.enabled:
        from .outline import apply_outline
        apply_outline(root, manager.widget_entries)  # the marks of the layout over the window (a developer view), all of it placed
    from .skinfonts import active_skin_seeds
    block_skin_defaults(root, active_skin_seeds().blocked)  # after the layout and the outline (they read a missing tag as the parent one)
    apply_window_textures(root, theme_textures())  # the full paths, at the end (the layout reads the sizes by the relative names)
    template_attrs = tuple(f'{{{ns}}}' for ns in TEMPLATE_NAMESPACES)
    for elem in root.iter():
        for name in [name for name in elem.attrib if name.startswith(template_attrs) or (name == 'id' and not elem.attrib[name])]:
            del elem.attrib[name]  # the template attributes, an empty ID (a define giving its controls IDs only on demand)
    strip_whitespace(root)
    # written at once and encoded once (a write to a byte stream encodes every piece on its own), the declaration and errors of `ElementTree.write()`
    xml_text = "<?xml version='1.0' encoding='utf-8'?>\n" + ET.tostring(root, encoding='unicode')
    xml_bytes = xml_text.encode('utf-8', 'xmlcharrefreplace')
    xml_globals = {name: value for name, value in manager.globals.items() if not name.startswith('_') and _picklable(value)}
    return xml_bytes, CustomXmlData(request=request, deps=manager.deps, globals=xml_globals, bindings=manager.bindings,
                                    widgets=tuple(manager.widget_entries), default_focus=default_focus, sizes=layout_sizes)


def layout_window(xml_source: Path, manager: XmlManager, font_styles: dict[str, str]) -> ET.Element:
    """Generate the window of widgets by the manager (`render_xml()`), lay it out, return its output root."""
    from .xgui import parse_template
    root = manager.run(parse_template(xml_source, root=xml_source.parent.parent))
    assert root is not None
    resolve_widget_refs(root, {entry.path: entry.ids for entry in manager.widget_entries})
    from .widgets.buttons import check_button_groups
    check_button_groups(manager.widget_entries)  # every member names a group of its parent widgets
    from .geometry import apply_layers, centre_slots, keep_grouplist_positions
    apply_layers(root)  # the tags under / over the content of their hosts
    centre_slots(root)  # the tags of a middle anchor centred as a group
    from .layout import apply_layout
    apply_layout(root, media=xml_source.parent.parent / 'Default' / 'media', font_styles=font_styles)
    keep_grouplist_positions(root)  # the own positions of the children of the grouplists written by hand
    from .geometry import apply_overlays, fill_list_ends
    places = apply_overlays(root)  # the drop-down lists over the window, at their places after the layout
    for entry in manager.widget_entries:  # the place of its overlay for Python (its side, its room; a row: by the IDs of its controls)
        if (place := places.get(entry.id) or next((places[cid] for cid in entry.ids.values() if cid in places), None)) is not None:
            entry.data['overlay'] = place
    fill_list_ends(root)  # the movement of the lists held at the start of their views, by their sizes after the layout
    from .focus_lines import apply_focus_lines
    apply_focus_lines(root, manager.widget_entries)  # the IDs and the geometry known
    from .layout import apply_grouplist_moves
    apply_grouplist_moves(root)  # the moves Kodi gives the children of a grouplist, of the focus lines too
    return root


def drop_remote_textures(root: ET.Element) -> list[str]:
    """
    Drop the textures the widgets of the themes write (`xgui.THEME_ATTR`) which name no local file (`RX_REMOTE_TEXTURE`: a URL - a theme
    makes Kodi fetch nothing), a warning; return them (`<theme>: <value>`, `remote_textures()`). The texts of the texture tags and their
    texture attributes (`TEXTURE_ATTRS`); an info of a prefix too (`$INFO[…,http://…/,.png]`).
    """
    from .xgui import THEME_ATTR
    dropped: list[str] = []
    for elem in root.iter():
        if theme := elem.get(THEME_ATTR):
            for name, value in ((None, elem.text), *((name, elem.get(name)) for name in TEXTURE_ATTRS & elem.attrib.keys())):
                if value and RX_REMOTE_TEXTURE.search(value):
                    fflog.warning(f'Texture {value!r} of the theme {theme}: not a local file, dropped')
                    dropped.append(f'{theme}: {value}')
                    if name is None:
                        elem.text = ''
                    else:
                        elem.set(name, '')
    return dropped


def remote_textures() -> list[str]:
    """Return the textures the widgets of the themes wrote in the last generated window, dropped (`drop_remote_textures()`)."""
    return _remote_textures


def apply_window_textures(root: ET.Element, textures: dict[str, str]) -> None:
    """
    Replace the textures of the media folder in a generated window with their full paths (`window_texture()`: of the active theme which
    has it - `textures`: `theme_textures()`, else of FF; Kodi looks a relative name up in the skin and among the textures loaded by name
    first) - the texts of the texture tags (`TEXTURE_TAGS`), their texture attributes (`TEXTURE_ATTRS`), the relative prefix of an info
    with a prefix and a postfix (`BoxTexture.info()`: the files of its states of one theme or of FF; of a theme and FF mixed: the ones of
    FF, a warning).
    """

    #: The folders of the infos by their prefix and postfix (Kodi's paths), once in a window.
    folders: dict[tuple[str, str], str] = {}

    def affix_folder(prefix: str, postfix: str) -> str:
        """Return the folder of every file the prefix and the postfix may name: of a theme, of FF (also mixed: a warning)."""
        found = affix_folders(prefix, postfix, textures)
        if len(found) > 1:
            fflog.warning(f'Texture: the files {prefix}*{postfix} of a theme and of FF mixed, the ones of FF used')
            return f'{MEDIA_URL}/'
        return found.pop() if found else f'{MEDIA_URL}/'

    def affixes(mch: re.Match[str]) -> str:
        """Return the info with its relative prefix in the folder of every file it may name."""
        info, prefix, postfix = mch[1], mch[2], mch[3]
        if RX_NOT_A_FILE.search(prefix):
            return mch[0]
        if (folder := folders.get((prefix, postfix))) is None:
            folder = folders[prefix, postfix] = affix_folder(prefix, postfix)
        return f'$INFO[{info},{folder}{prefix},{postfix}]'

    def full(text: str) -> str:
        """Return the texture as its full path (a file, an info with the prefix of the files) or the text as it is."""
        if '$INFO[' in text:
            return RX_INFO_AFFIXES.sub(affixes, text)
        name = text.strip()
        return text if (path := window_texture(name)) == name else path

    for elem in root.iter():
        if elem.tag in TEXTURE_TAGS:
            if elem.text:
                elem.text = full(elem.text)
            for name in TEXTURE_ATTRS & elem.attrib.keys():
                elem.set(name, full(elem.attrib[name]))


def affix_folders(prefix: str, postfix: str, textures: dict[str, str]) -> set[str]:
    """
    Return the folders (Kodi's paths, `window_texture()`) of the files an info with the prefix and the postfix may name (`RX_INFO_AFFIXES`:
    the states of a check box) - of a theme which has it (`textures`: `theme_textures()`), else of FF; none while no theme has a file of
    the prefix (also an absolute one, of a theme already). More than one: a mixed set (`apply_window_textures()` takes the files of FF).
    """
    if not any(rel.startswith(prefix) for rel in textures):
        return set()
    names = [tex.name for tex in media_textures(prefix.rpartition('/')[0]) if tex.name.startswith(prefix) and tex.name.endswith(postfix)
             and len(tex.name) > len(prefix) + len(postfix) and '.' not in tex.name[len(prefix):-len(postfix)]]
    return {texture_url(path)[:-len(name)] if (path := textures.get(name)) else f'{MEDIA_URL}/' for name in names}


def block_skin_defaults(root: ET.Element, blocked: dict[str, tuple[str, ...]]) -> None:
    """
    Give every control without a tag FF blocks the defaults of the skin give its type (`blocked`: `SkinSeeds.blocked`) an empty one:
    Kodi reads it as missing (FF lays the windows out so, its textures untinted), but adds a default tag only to a control lacking it -
    e.g. Arctic Zephyr Martian makes a label or a button 66 high, a text of a tag 40 high centred 13 lower, under its fill; Mimic LR
    tints the textures of a button in the colour of its focus.
    """
    for control in root.iter('control'):
        for tag in blocked.get(control.get('type', ''), ()):
            if control.find(tag) is None:
                ET.SubElement(control, tag)


def strip_whitespace(root: ET.Element) -> None:
    """
    Drop the indents of the output: a text of line breaks and blanks only (a text of blanks alone, e.g. a label of one space, stays) and
    every tail (the text after an element: Kodi reads none). The templates leave them in the output (`XmlTemplate._new()` copies the texts
    and the tails of its sources), a quarter of the file of a window; the comments of the sources go with the developer mode
    (`xgui.source_comment()`).
    """
    for elem in root.iter():
        if elem.text and '\n' in elem.text and not elem.text.strip():
            elem.text = None
        elem.tail = None


def defer_default_control(root: ET.Element) -> int:
    """
    Remove the default control of the window (`<defaultcontrol>`) which Kodi cannot focus when it opens the window: a list with no
    items of the skin (`<content>`), its items come from Python later (`on_init()`) - `CGUIBaseContainer::CanFocus()` refuses an empty
    list and Kodi logs an error ("has been asked to focus, but it can't", `CGUIWindow::RestoreControlStates()` before `onInit()`).
    Return its ID: the window focuses it after `on_init()` (`AbstractWindow.onInit()`); 0: none removed.
    """
    from .focus_lines import LIST_TYPES
    default = root.find('defaultcontrol')
    if default is None or not (cid := (default.text or '').strip()).isdecimal():
        return 0
    control = next((elem for elem in root.iter('control') if elem.get('id') == cid), None)
    if control is None or control.get('type') not in LIST_TYPES or control.find('content') is not None:
        return 0
    root.remove(default)
    return int(cid)


def resolve_widget_refs(root: ET.Element, ids: dict[str, dict[str, int]]) -> None:
    """
    Replace the references to the widgets `@path` (`WIDGET_REF_TAGS`: the navigation, the default control, the conditions,
    the label: `<onleft>@lists</onleft>`, `Control.HasFocus(@lists)`, `<onup condition="…@tabs…">`) with their control IDs, known
    after the generation (a reference may point to a widget later in the window); `@path:name` is another control of the
    widget (`id_of(name)`: `@tabs:tab.accounts`); an unknown path or name is an error with the position of the element.
    """
    from .xgui import SRC_ATTR, TemplateError

    def control_id(mch: re.Match[str]) -> str:
        """Return the control ID of the widget of the reference (its longest path: `@tabs.tab` -> the ID of `tabs` + `.tab`)."""
        if mch[2] is not None:  # `@path:name`
            if (cid := ids.get(mch[1], {}).get(mch[2])) is None:
                raise TemplateError(f'No control {mch[2]!r} of the widget {mch[1]!r} for the reference {mch[0]!r}', src=src)
            return str(cid)
        parts = mch[1].split('.')
        for n in range(len(parts), 0, -1):
            if (wids := ids.get('.'.join(parts[:n]))) is not None:
                return '.'.join((str(wids['']), *parts[n:]))
        raise TemplateError(f'No widget {mch[1]!r} for the reference {mch[0]!r}', src=src)

    for elem in root.iter():
        if elem.tag in WIDGET_REF_TAGS:
            src = elem.get(SRC_ATTR, '')
            if elem.text and '@' in elem.text:
                elem.text = RX_WIDGET_REF.sub(control_id, elem.text)
            if '@' in (condition := elem.get('condition', '')):  # `<onup condition="…">`: a conditional navigation
                elem.set('condition', RX_WIDGET_REF.sub(control_id, condition))


def _picklable(value: Any) -> bool:
    """Return True if the value can be pickled (stored in the XML cache)."""
    try:
        pickle.dumps(value)
    except Exception:
        return False
    return True


if __name__ == '__main__':
    if 1:
        def parse_var(s: str) -> tuple[str, Any]:
            """Parse variable from command line."""
            from ast import literal_eval
            name, _, val = s.partition('=')
            name, _, typ = name.partition(':')
            if typ == 'bool':
                return name, val.lower() in TRUE_VALUES
            if typ in ('str', 'int', 'float', 'complex'):
                return name, eval(f'{typ}({val})')
            if val.lower() == 'true':
                return name, True
            if val.lower() == 'false':
                return name, False
            try:
                return name, literal_eval(val)
            except Exception:
                pass
            from simpleeval import simple_eval, DEFAULT_FUNCTIONS
            try:
                return name, simple_eval(val, functions={
                    **DEFAULT_FUNCTIONS,
                    'zip': zip,
                    'max': max,
                    'min': min,
                    'range': range,
                    'L': L,
                })
            except Exception:
                raise ValueError() from None

        from ..ff.cmdline import DebugArgumentParser
        p = DebugArgumentParser()
        p.add_argument('xml', nargs='?', default='/tmp/x.xml', help='XML source file (template)')
        p.add_argument('-v', '--var', action='append', default=[], type=parse_var, metavar='NAME[:TYPE]=VALUE', help='variable')
        p.add_argument('-o', '--output', metavar='PATH', default='/tmp/a.xml', help='path to output XML file')
        args = p.parse_args()
        path = Path(args.xml).expanduser().resolve()
        x = custom_xml(path, Path(args.output), CustomXmlRequest(vars=dict(args.var)))
        print('custom_xml[cli]:', x)
    elif 0:
        from ..ff.tricks import Formatter
        fmt = Formatter()
        params = {'top': 0, 'right': 20, 'n': 2}
        print(params)
        print(fmt.format('{right}', **params))
        print(fmt.format('{top or (10 + (n-1) * 80)}', **params))
        raise SystemExit(0)
    elif 0:
        from typing import Any
        def cart(seq2: Sequence[Sequence[Any]]) -> Iterator[Sequence[Any]]:
            """Print sequence."""
            end = [len(seq) for seq in seq2]
            index = [0] * len(seq2)
            while True:
                seq = [seq2[i][index[i]] for i in range(len(seq2))]
                yield seq
                for i in range(len(index) - 1, -1, -1):
                    index[i] += 1
                    if index[i] < end[i]:
                        break
                    if not i:
                        return
                    index[i] = 0
        print(list(cart(("AB", "C", "EFG"))))
        print(list(cart(((False, None), (True, None), (None,)))))
        print(list(product("AB", "C", "EFG")))
        print(list(product((False, None), (True, None), (None,))))
    elif 0:
        x = custom_xml(Path(__file__).parent.parent.parent / 'resources/skins/Default/1080i/NewList.xml', Path('/tmp/a.xml'))
        print(x)
    elif 0:
        def pp(cond):
            return ''.join(('-' if v is None else str(v) for v in cond))

        flags = list(iter_flags(ControlState))
        flags.reverse()
        print(f'{flags=}')
        # print(list(product(*((None, 0, 1),)*len(flags))))
        defaults = {}
        for cond in product(*((None, 0, 1),)*len(flags)):
            src = []
            for i in range(len(flags)):
                if cond[i] is not None:
                    par = list(cond)
                    par[i] = None
                    src.append(pp(par))
                    # print(f'{pp(cond)}: <- {pp(par)}')
            # print(f'{pp(cond)}: !!')
            print(f'{pp(cond)}: {", ".join(src)}')
            defaults[cond] = ...
        # print(defaults)
    elif 0:
        def pp(cond):
            return ''.join(('-' if v is None else str(v) for v in cond))
        # for key in ControlState.attr_default_seq():
        #     print(key)
        for key, depends in ControlState.attr_default_seq().items():
            print(f'{str(key):25s}: {depends}')
        # print('-----------------------')
        # values = {tuple(key.values()): tuple(tuple(s.values()) for s in seq)
        #           for key, seq in ControlState.attr_default_seq()}
        # for key, depends in values.items():
        #     print(key, depends)
