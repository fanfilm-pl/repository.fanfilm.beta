"""
Cache of generated (customized) window XML.

Every window source `X.xml` has variants of the output `tmp--<instance>--X.<hash>.xml`, one for each different template
data (request variables the template has read) and environment stamp (Kodi, skin, language, style, sources, code...), and one
manifest `tmp--<instance>--X.cache` with them. A variant is valid in its environment only; the manifest keeps the variants of several
environments (the most recently used ones, `limit` of them), so an open after a switch back (a skin, a variant of the themes, the
colours of the skin) finds the XML of the earlier one. The instance is a Kodi profile.
"""

from __future__ import annotations
from typing import Any, Mapping, Protocol, TYPE_CHECKING
from pathlib import Path
from time import time
import hashlib
import pickle
import re
from attrs import define, evolve, fields
from ..ff.filecache import write_atomic
from ..ff.logs import fflog, fflog_exc
if TYPE_CHECKING:
    from .gui import CustomXmlData, CustomXmlRequest

class Render(Protocol):
    """Render function (`gui.render_xml()`): source XML, request and the sizes of the last variant -> output XML and its data."""

    def __call__(self, source: Path, request: CustomXmlRequest, *, sizes: Mapping[str, Mapping[str, int]]) -> tuple[bytes, CustomXmlData]: ...


@define(kw_only=True)
class XmlVariant:
    """Single cached output XML."""

    #: Output file name (in the source folder).
    name: str
    #: Request variables the output depends on: name -> repr() of the value, an empty string if it must be absent.
    deps: dict[str, str]
    #: Data of the output (without the request).
    data: CustomXmlData
    #: Last use time (to remove the least recently used).
    used_at: float = 0
    #: The environment of the output (`env_digest()` of its stamp); the last field: a manifest of an older version has none.
    env: str = ''

    def matches(self, request_vars: dict[str, Any]) -> bool:
        """Return True if the request variables are the same as the output depends on."""
        return all((repr(request_vars[name]) if name in request_vars else '') == value for name, value in self.deps.items())


def env_digest(stamp: str) -> str:
    """Return the short digest of the environment stamp (the key of the variants of an environment, of the prepared windows)."""
    return hashlib.sha1(stamp.encode('utf-8')).hexdigest()[:12]


def customized_xml(source: Path, request: CustomXmlRequest, *, env: str, render: Render, limit: int,
                   instance: str, foreign_ttl: float, folder: Path | None = None) -> tuple[str, CustomXmlData]:
    """
    Return the output XML file name (in `folder`, the source one by default) and its data, generate it if there is no cached one.

    Every `instance` (Kodi profile) has its own files `tmp--<instance>--X.*`: Kodi instances (and profiles) share
    the add-on folder, but they can differ in Kodi version, skin, language. Files of other instances are removed
    after `foreign_ttl` seconds without use (old file names at once).
    An empty `env` means unknown dependencies: the XML is always generated to a shared `tmp--<instance>--X.0.xml` file.
    """
    if folder is None:
        folder = source.parent
    prefix = f'tmp--{instance}--{source.stem}'
    manifest_path = folder / f'{prefix}.cache'
    key = env_digest(env) if env else ''
    variants = _read(manifest_path) if env else []
    for variant in variants:
        if variant.env == key and variant.matches(request.vars) and (folder / variant.name).exists():
            if variant is not variants[0] or _stale(manifest_path, foreign_ttl):  # no write on every open (an SD card)
                _touch(manifest_path, variant.name)  # the LRU order; its mtime is the last use of the window (other instances)
            fflog(f'XML {source.name}: cached {variant.name}')
            return variant.name, evolve(variant.data, request=request)

    # the sizes of the layout of the variant used last (of any environment) seed the generation: one pass when they hold (they usually do)
    xml, data = render(source, request, sizes=max(variants, key=lambda v: v.used_at).data.sizes if variants else {})
    _remove_foreign(folder, instance, foreign_ttl)
    stored = evolve(data, request=type(request)())  # request may hold anything
    if not env:
        reason = 'no stamp'
    elif any(' at 0x' in value for value in data.deps.values()):
        reason = 'unstable template data'
    elif not _picklable(stored):
        reason = 'template data can not be stored'  # e.g. a function defined in the template (`<ff:vars>`)
    else:
        reason = ''
    if reason:
        name = f'{prefix}.0.xml'
        fflog(f'XML {source.name}: not cached ({reason}) {name}')
        _write_if_changed(folder / name, xml)
        return name, data
    digest = hashlib.sha1(repr((env, sorted(data.deps.items()))).encode('utf-8')).hexdigest()[:12]
    name = f'{prefix}.{digest}.xml'
    write_atomic(folder / name, xml)
    # The manifest again: another interpreter of the instance (plugin, service) could add a variant meanwhile, its file
    # is maybe being opened by its window. Only variants out of the limit (the least recently used ones, of any environment) are removed.
    variants = _read(manifest_path)
    dropped = {v.name for v in variants}
    variants = [v for v in variants if v.name != name]
    variants.insert(0, XmlVariant(name=name, deps=data.deps, data=stored, used_at=time(), env=key))  # the first on equal time
    variants.sort(key=lambda v: v.used_at, reverse=True)
    # a variant of an older version may hold an object without a field of this version (its environment never matches): it can not be pickled again
    variants = [v for v in variants[:max(1, limit)] if _picklable(v)]
    dropped -= {v.name for v in variants}
    _save(manifest_path, variants)
    for dropped_name in dropped:
        (folder / dropped_name).unlink(missing_ok=True)
    fflog(f'XML {source.name}: generated {name}')
    return name, data


def _picklable(data: Any) -> bool:
    """Return True if the data can be stored in the manifest (pickle)."""
    try:
        pickle.dumps(data)
        return True
    except Exception:
        return False


def _read(path: Path) -> list[XmlVariant]:
    """
    Read the variants of the manifest, empty if no manifest or it is broken. A manifest of an older version (one environment
    for all its variants: `{'env': <stamp>, 'variants': […]}`) gives its variants of that environment; a variant whose data lacks a field
    of this version (pickled by an older one, its environment never matches) is dropped.
    """
    try:
        with open(path, 'rb') as file:
            manifest = pickle.load(file)
        variants = [v for v in manifest['variants'] if all(hasattr(v.data, f.name) for f in fields(type(v.data)))]
        if 'env' in manifest:
            key = env_digest(manifest['env'])
            for variant in variants:
                variant.env = key
        return variants
    except Exception:
        return []  # no cache, broken cache etc.


def _stale(path: Path, foreign_ttl: float) -> bool:
    """Return True if the manifest was written longer ago than half of `foreign_ttl` (other instances keep it till `foreign_ttl`)."""
    try:
        return time() - path.stat().st_mtime > foreign_ttl / 2
    except OSError:
        return True


def _touch(path: Path, name: str) -> None:
    """Mark the variant used now in the manifest (read again, other interpreters write it too); no file is removed."""
    variants = _read(path)
    for variant in variants:
        if variant.name == name:
            variant.used_at = time()
    _save(path, variants)


def _save(path: Path, variants: list[XmlVariant]) -> None:
    """Save the manifest (the variants with their environments)."""
    try:
        write_atomic(path, pickle.dumps({'variants': variants}))
    except Exception:
        fflog_exc()


#: Output of an instance: `tmp--<instance>--<window>.<variant>.xml`, `….0.xml`, `….cache`.
_RX_INSTANCE_FILE = re.compile(r'tmp--([0-9a-f]{8})--(.+?)\.(?:[0-9a-f]{12}\.xml|0\.xml|cache)')
#: Variant output of an instance: `tmp--<instance>--<window>.<variant>.xml`.
_RX_VARIANT_FILE = re.compile(r'tmp--([0-9a-f]{8})--(.+?)\.[0-9a-f]{12}\.xml')
#: Old outputs (without an instance): `tmp--X.xml`, `tmp--X.xml.cache`, `tmp--X.<variant>.xml`, `tmp--X.0.xml`, `tmp--X.cache`.
_RX_OLD_FILE = re.compile(r'tmp--(?![0-9a-f]{8}--).+?\.(?:xml|xml\.cache|[0-9a-f]{12}\.xml|0\.xml|cache)')


def _remove_foreign(folder: Path, instance: str, ttl: float) -> None:
    """
    Remove outputs of other instances unused for `ttl` seconds (by their manifest), old outputs (at once) and own variants
    out of their manifest for `ttl` seconds (a variant lost by a race of two interpreters of the instance).
    """
    now = time()
    try:
        files = list(folder.iterdir())
    except OSError:
        return
    listed: dict[str, set[str]] = {}  # own manifest -> its variant names
    for file in files:
        try:
            if _RX_OLD_FILE.fullmatch(file.name):
                file.unlink(missing_ok=True)
            elif (mch := _RX_INSTANCE_FILE.fullmatch(file.name)) and mch[1] != instance:
                manifest = folder / f'tmp--{mch[1]}--{mch[2]}.cache'
                used = (manifest if manifest.exists() else file).stat().st_mtime
                if now - used > ttl:
                    file.unlink(missing_ok=True)
            elif (mch := _RX_VARIANT_FILE.fullmatch(file.name)) and now - file.stat().st_mtime > ttl:
                manifest = f'tmp--{mch[1]}--{mch[2]}.cache'
                if manifest not in listed:
                    listed[manifest] = {v.name for v in _read(folder / manifest)}
                if file.name not in listed[manifest]:
                    file.unlink(missing_ok=True)
        except OSError:
            pass  # removed by the other instance meanwhile etc.


def _write_if_changed(path: Path, data: bytes) -> None:
    """Write the file only if its content is different, otherwise only touch it (it is still used, see `_remove_foreign()`)."""
    try:
        if path.read_bytes() == data:
            path.touch()
            return
    except OSError:
        pass
    write_atomic(path, data)
