"""
The configuration window made of widgets: its tabs (`tab_widget`: the pages of `PAGES`, TabPage classes), the title of the
shown page, the help of the focused control in the footer, "Close". The last shown tab (since the start of Kodi) is shown
again.

The pages are split into cards (`CARDS`): a card is one Kodi window with the bar of all the tabs and the pages of the card only. A tab
of the same card shows its page, a tab of another card opens that card: the window opened first stays under the others (the chain:
`ConfigDialog.open_cards()`), what the cards share is in `ConfigSession`.
"""

from __future__ import annotations
from importlib import import_module
from typing import Any, Callable, ClassVar, Sequence, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from attrs import define, field, frozen
from .base import BaseDialog, request_windows
from ..kolang import L
if TYPE_CHECKING:
    from .widgets import Widget
    from .widgets.tabs import Page, TabPage, TabWidget

#: The global window property of the tab shown last (shown again when the window opens).
TAB_PROPERTY: str = 'fanfilm.config.tab'
#: The width of the window frame.
WIDTH: int = 1880
#: The height of the window frame.
HEIGHT: int = 1020
#: The top of the tabs in the frame (below the header).
TABS_TOP: int = 100
#: The space below the tabs in the frame (the footer).
TABS_BOTTOM: int = 120
#: The left and the right of the tabs in the frame.
TABS_LEFT: int = 20
TABS_RIGHT: int = 30
#: The tabs: of a line (the current one outlined, the line broken at it), a tab this wide, the gap between the tabs.
TABS_SHAPE: str = 'line'
TABS_DEPTH: int = 330
TABS_SPACING: int = 12
#: The height of a tab page (the pages cut their lists to whole rows of it).
PAGE_HEIGHT: int = HEIGHT - TABS_TOP - TABS_BOTTOM


@frozen(kw_only=True)
class PageRef:
    """A page of the window known without importing its module (its class: `page_class()`), the only declaration of its titles and of its parent."""

    #: The name of the page (of its tab).
    name: str
    #: The title of the page (the language of the call): the title of the window, of the tab with no `tab`.
    title: Callable[[], str]
    #: The label of its tab (None: `title`).
    tab: Callable[[], str] | None = None
    #: The module of its class in `lib/windows/widgets`.
    module: str
    #: The name of its class.
    cls: str
    #: The name of the page this one is under (`TabPage.PARENT`), '' a top page.
    parent: str = ''

    def page_class(self) -> type[TabPage]:
        """Return the class of the page (its module imported now)."""
        return getattr(import_module(f'.widgets.{self.module}', __package__), self.cls)

    def tab_of(self) -> Page:
        """Return the tab of the page in the template data (no page module imported)."""
        from .widgets.tabs import Page
        return Page(name=self.name, title=(self.tab or self.title)(), level=1 if self.parent else 0)


#: The pages of the window in the order of their tabs (`page_refs()`: the ones of this installation).
PAGE_REFS: tuple[PageRef, ...] = (
    PageRef(name='sources', title=lambda: L(30794, 'Source settings'), tab=lambda: L(30758, 'Sources'), module='source_settings', cls='SourceSettingsPage'),
    PageRef(name='addons', title=lambda: L(32917, 'Source providers'), tab=lambda: L(30795, 'Providers', ctx='tab of the source providers'),
            module='source_providers', cls='SourceProvidersPage', parent='sources'),
    PageRef(name='debrid', title=lambda: L(30739, 'Debrid services'), tab=lambda: L(30740, 'Debrid'), module='debrid', cls='DebridPage', parent='sources'),
    PageRef(name='accounts', title=lambda: L(32916, 'Accounts'), module='accounts', cls='AccountsPage'),
    PageRef(name='feeds', title=lambda: L(32974, 'Data providers'), tab=lambda: L(30152, 'Data providers', ctx='config menu'), module='feeds', cls='FeedsPage'),
    PageRef(name='general', title=lambda: L(30628, 'General lists'), module='general_lists', cls='GeneralListsPage'),
    PageRef(name='menus', title=lambda: L(30192, 'Menus'), module='menus', cls='MenusPage'),
    PageRef(name='folders', title=lambda: L(32971, 'Folders'), module='folders', cls='FoldersPage'),
    PageRef(name='appearance', title=lambda: L(30543, 'Appearance'), module='appearance', cls='AppearancePage'),
)

#: The cards of the window: the names of the pages of each one (a card is one Kodi window, its name: the first page).
CARDS: Sequence[Sequence[str]] = (tuple(ref.name for ref in PAGE_REFS),)
#: The name of a card (the variant of its window).
CardName: TypeAlias = Literal[tuple(card[0] for card in CARDS)]  # type: ignore[valid-type]


@define(kw_only=True)
class ConfigSession:
    """What the cards of one open of the window share: plain data only, never a window or a part of one (e.g. a list item)."""

    #: The changes made in the cards (a page shown again is refreshed after a change since its last refresh).
    changes: int = 0
    #: The state of the pages of the cards closed (`TabPage.reopen_state()`) by the names of the pages.
    pages: dict[str, dict[str, Any]] = field(factory=dict)


def page_width() -> int:
    """Return the width of a tab page: the tabs less their bar, its line and gaps (`TabWidget.template_tabs()`, the style of now)."""
    from .style import tokens
    from .widgets.tabs import Page, TabWidget
    pages = [Page(name='page')]
    style = tokens()
    tabs = TabWidget.template_tabs(pages, pages, 'W', TABS_SHAPE, '', style.metric.row, TABS_DEPTH, TABS_SPACING, style.space.s, level=1)
    return WIDTH - TABS_LEFT - TABS_RIGHT - (tabs.content.left or 0) - (tabs.content.right or 0)


def page_rows(row_height: int, top: int = 0) -> int:
    """Return the whole rows of the height a list of a page shows from its `top` down (`PAGE_HEIGHT`)."""
    return (PAGE_HEIGHT - top) // row_height


def page_refs() -> tuple[PageRef, ...]:
    """Return the pages (tabs) of the window in their order (the source providers: if the tools have them), no page module imported."""
    from const import const
    return tuple(ref for ref in PAGE_REFS if ref.name != 'addons' or const.indexer.tools.external_addons)


def page_ref(cls: str) -> PageRef | None:
    """Return the declaration of the page of the class name (None: no page of the window, e.g. of a test)."""
    return next((ref for ref in PAGE_REFS if ref.cls == cls), None)


def pages() -> Sequence[tuple[str, type[TabPage]]]:
    """Return the pages (tabs) of the window in their order: the names and the classes (their modules imported)."""
    return tuple((ref.name, ref.page_class()) for ref in page_refs())


class ConfigDialog(BaseDialog):
    """The configuration window (tabs)."""

    #: The page classes of the tabs, in their order (by their names; None: the pages of FanFilm, `pages()`).
    PAGES: ClassVar[Sequence[tuple[str, type[TabPage]]] | None] = None
    #: The cards of the window (the pages in `PAGES` count, `CARDS` by default).
    CARDS: ClassVar[Sequence[Sequence[str]]] = CARDS
    #: The card is opened over the first one: it closes with the tab of the next card, the first one opens it.
    over_first: bool = False
    #: The first card runs the chain of the cards over it (`open_cards()`).
    cards_open: bool = False

    @classmethod
    def page_classes(cls) -> Sequence[tuple[str, type[TabPage]]]:
        """Return the pages of the window: the names and the classes."""
        return pages() if cls.PAGES is None else cls.PAGES

    @classmethod
    def card_of(cls, page: str) -> Sequence[str]:
        """Return the card of the page: the names of its pages (no such page: the first card)."""
        return next((card for card in cls.CARDS if page in card), cls.CARDS[0])

    @classmethod
    def card_classes(cls, card: Sequence[str]) -> Sequence[tuple[str, type[TabPage]]]:
        """Return the pages of the card: the names and the classes (the modules of these pages only imported)."""
        if cls.PAGES is not None:
            return tuple((name, page) for name, page in cls.PAGES if name in card)
        return tuple((ref.name, ref.page_class()) for ref in page_refs() if ref.name in card)

    @classmethod
    def tab_records(cls) -> Sequence[Page]:
        """Return the tabs of the window (of every card): their names, labels, levels (no page module imported)."""
        return tuple(ref.tab_of() for ref in page_refs()) if cls.PAGES is None else tuple(page.page_of(name) for name, page in cls.PAGES)

    @classmethod
    def xml_vars(cls, card: CardName | None = None, tab: str = '', **kwargs: Any) -> dict[str, Any]:
        """
        The tabs of all the pages (`TABS`), the pages of the card (`PAGES`: their names, titles, widgets, ports), the frame (`WIDTH`, `HEIGHT`) and
        its tabs (`TABS_*`), the size of a page (`PAGE_WIDTH`, `PAGE_HEIGHT`) and the template vars of the pages of the card (unique names).
        `card`: the variant of the window; none - the card of the asked tab (`tab`, else the last shown one).
        """
        from ..ff.control import get_window_property
        shown = cls.card_classes(cls.card_of(card or tab or get_window_property(TAB_PROPERTY)))
        result: dict[str, Any] = {'PAGES': [page.page_of(name) for name, page in shown], 'TABS': cls.tab_records(), 'WIDTH': WIDTH, 'HEIGHT': HEIGHT,
                                  'TABS_TOP': TABS_TOP, 'TABS_BOTTOM': TABS_BOTTOM, 'TABS_LEFT': TABS_LEFT, 'TABS_RIGHT': TABS_RIGHT,
                                  'TABS_SHAPE': TABS_SHAPE, 'TABS_DEPTH': TABS_DEPTH, 'TABS_SPACING': TABS_SPACING,
                                  'PAGE_WIDTH': page_width(), 'PAGE_HEIGHT': PAGE_HEIGHT}
        for name, page in shown:
            page_vars = page.xml_vars()
            if same := page_vars.keys() & result.keys():
                raise ValueError(f'Template vars of the page {name!r} are taken: {sorted(same)}')
            result.update(page_vars)
        return result

    def __init__(self, *args: Any, tab: str = '', account: str | None = None, session: ConfigSession | None = None, **kwargs: Any) -> None:
        """
        The window, there are no Kodi controls yet; `tab`: the tab to show (none: the last shown one, else the first one),
        `account`: the account to select in the accounts page, `session`: the session of the cards of a card opened over the first one.
        """
        from ..ff.control import get_window_property
        super().__init__(*args)
        self.over_first = session is not None
        #: What the cards of this open of the window share.
        self.session: ConfigSession = ConfigSession() if session is None else session
        self.watch_help(self.widgets)  # first: a page is built by the current tab below
        tabs = self.tabs
        tabs.changes = self.session.changes
        names = tabs.names()
        tab = tab or get_window_property(TAB_PROPERTY)
        tabs.current = tab if tab in names else next(iter(names), '')
        if account is not None and (accounts := tabs.page('accounts')) is not None:
            accounts.select_id = account  # type: ignore[attr-defined]

    def watch_help(self, widget: Widget) -> None:
        """The help of the focused control follows the changes of the helps of the widget and of what is under it."""
        for each in widget.walk():
            each.help_changed.connect(self._help_changed)
            each.reason_changed.connect(self._help_changed)

    def on_tabs_child_built(self, page: Widget) -> None:
        """A page built the first time it is needed: its helps too, its state of the card closed before (before its first show)."""
        self.watch_help(page)
        if (state := self.session.pages.get(page.name)) is not None:
            page.restore(state)  # type: ignore[attr-defined]

    def do_modal(self) -> Any:
        """
        Execute the window (opened again too, `reopen()`); then the FF folder refreshed if the active themes changed (its images),
        wherever the window was opened from, and the windows prepared again if the configuration was written (a setting the template
        of a window reads - the colour mode of the sources... - makes a new variant of it in the same environment). A card over the first
        one only executes: the first one does the rest for all.
        """
        if self.over_first:
            return super().do_modal()
        from ..ff.config import config, file_stat
        from ..ff.theme import active_themes
        before = active_themes()
        written = file_stat(config.path())
        result = super().do_modal()
        if active_themes() != before:
            from ..ff.control import refresh
            refresh()
        if file_stat(config.path()) != written:
            request_windows(self.ff_xml_args.env, again=True)
        return result

    @property
    def tabs(self) -> TabWidget:
        """Return the tab widget."""
        return self.find('tabs')  # type: ignore[return-value]

    def on_init(self) -> None:
        """Focus the tabs (the current one: the shown page)."""
        self.setFocusId(self.tabs.bar.id)

    def reopen_state(self) -> dict[str, Any]:
        """
        Return the state of an open again: the shown tab too (an asked tab of the arguments would win over the last shown one), the
        state of its page (`TabPage.reopen_state()`) and the session of the cards.
        """
        page = self.tabs.page(self.tabs.current)
        return {**super().reopen_state(), 'tab': self.tabs.current, 'page': page.reopen_state() if page is not None else {}, 'session': self.session}

    def restore(self, state: dict[str, Any]) -> None:
        """Show the tab of the closed window with the state of its page (before the show: its page filled once), the session goes on."""
        self.session = state.get('session', self.session)
        self.tabs.changes = self.session.changes
        if (page := self.tabs.page(tab := state.get('tab', ''))) is not None:
            page.restore(state.get('page') or {})
            self.tabs.current = tab
        super().restore(state)

    def on_tabs_current_changed(self, name: str) -> None:
        """Another tab shown: the title of its page, the tab shown again next time."""
        from ..ff.control import window
        if (page := self.tabs.page(name)) is not None:
            self.find('title').text = page.TITLE()
            window().setProperty(TAB_PROPERTY, name)
            if self._ready:  # a move along the tabs keeps the focus on them: the help of the current tab
                self.on_focus(self.focused_id())

    def on_tabs_activated(self, tab: str) -> None:
        """A tab of another card is chosen: a card over the first one closes with it, the first one opens it (once: a late click in the chain)."""
        if self.over_first:
            self.close(tab)
        elif not self.cards_open:
            self.open_cards(tab)

    def open_cards(self, tab: str | None) -> None:
        """
        Run the chain of the cards over this one (the first card, seen under the others): open the card of the tab, then the next one its
        result asks (the tab of the next card; None: the window closed, the first card too), up to a tab of this card (its page shown again,
        refreshed after a change made in the other cards). In the gap between two cards this window shows the next tab lit, no page of it.
        """
        names = self.tabs.names()
        self.session.changes = self.tabs.changes
        self.cards_open = True
        try:
            while tab is not None and tab not in names:
                self.tabs.bar.current = self.tabs.tab_names().index(tab)
                card = type(self)(scriptPath=self.ff_xml_args.script_path, tab=tab, session=self.session, busy=False)
                tab = card.do_modal()
                del card  # no window of the chain kept
        finally:
            self.cards_open = False
        if tab is None:
            self.close()
            return
        self.tabs.changes = self.session.changes
        self.tabs.current = tab
        self.tabs.apply_property('current')  # also the tab it showed before the chain: the bar, the refresh
        self.on_tabs_current_changed(tab)
        self.setFocusId(self.tabs.bar.id)

    def on_closing(self) -> bool | None:
        """The first card stays under the others (a Back in the gap between two cards)."""
        return False if self.cards_open else None

    def on_close(self) -> None:
        """The window closed: the changes and the state of its shown pages for the other cards."""
        self.session.changes = self.tabs.changes
        for name in self.tabs.names():
            if (page := self.tabs.children.get(name)) is not None and page.refreshed is not None:  # type: ignore[attr-defined]
                self.session.pages[name] = page.reopen_state()  # type: ignore[attr-defined]

    def on_close_clicked(self) -> None:
        """Close the window (every change is saved at once)."""
        self.close()

    def on_click(self, control_id: int) -> None:
        """A click in a page is a change (the other pages are refreshed when shown again)."""
        widget = self._widget_tree.widget_of(control_id) if self._widget_tree is not None else None
        if widget is not None and widget.path.startswith('tabs.'):
            self.tabs.changes += 1

    def on_focus(self, control_id: int) -> None:
        """The help of the focused control in the footer."""
        self.find('help').text = self.help_of(control_id)  # type: ignore[attr-defined]

    def _help_changed(self, text: str) -> None:
        """A help or a reason of a widget changed: the help of the focused control again."""
        if self._ready:
            self.on_focus(self.focused_id())

    def help_of(self, control_id: int) -> str:
        """Return the help of the control: of its widget (why it is disabled first) or of a parent widget."""
        tabs = self.tabs
        if control_id == self.find('close').id:
            return L(32912, 'Close the window (every change is saved at once).')
        if (page := tabs.page_of_tab(control_id)) is not None:
            if page.DEFAULTS:
                return L(30230, 'Move right to the settings of the tab, the context menu: restore its defaults.')
            return L(32963, 'Move right to the settings of the tab.')
        return self._widget_tree.help_of(control_id) if self._widget_tree is not None else ''
