-- playback.db v5: rows of accounts. Built anew: the old rows (one per media, Trakt and local mixed) are
-- dropped, the sync cursors of accounts are reset (on_update), the next sync of every account is a full one.
DROP TABLE IF EXISTS scrobble_playback;
DROP TABLE IF EXISTS scrobble_service;
