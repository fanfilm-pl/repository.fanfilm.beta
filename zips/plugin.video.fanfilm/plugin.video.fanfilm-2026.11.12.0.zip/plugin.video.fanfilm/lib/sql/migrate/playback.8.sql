-- playback.db v8: the time of the first failed delivery of a waiting change (given up after `const.accounts.pending.max_retry`);
-- the rows and the sync cursors stay (on_update).
ALTER TABLE pending_change ADD COLUMN "failed_at" INTEGER DEFAULT NULL;
