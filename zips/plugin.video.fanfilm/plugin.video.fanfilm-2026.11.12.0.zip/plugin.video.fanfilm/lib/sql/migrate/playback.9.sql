-- playback.db v9: the time a waiting change was queued (its wait is limited by `const.accounts.pending.max_age`, not the age
-- of the change); the ones waiting now count from the migration; the rows and the sync cursors stay (on_update).
ALTER TABLE pending_change ADD COLUMN "queued_at" INTEGER NOT NULL DEFAULT 0;
UPDATE pending_change SET queued_at = CAST(strftime('%s', 'now') AS INTEGER);
