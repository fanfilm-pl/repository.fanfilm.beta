-- library.db v2: the state of a STRM file in Kodi video DB after the last library alignment (the snapshot): a change of
-- Kodi the FF service did not see (a shared MySQL library, the service stopped) is a difference from it, not an old state.
-- The rows stay, no snapshot yet (the next alignment writes it).
ALTER TABLE strm ADD COLUMN "kodi_watched" TEXT DEFAULT NULL;
ALTER TABLE strm ADD COLUMN "kodi_progress" REAL NOT NULL DEFAULT 0;
