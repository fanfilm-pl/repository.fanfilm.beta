"""
The shows in progress in the service: one computation at a time (a plugin call joins a running one, e.g. a widget asked
for `/tvshow/progress` at the Kodi start while the service warms it up), the list kept until the progress, Kodi video DB (the
rows of the local Kodi account, Kodi refreshes its widgets at its change before the service handles it), the FF media
playing now (watched or not, `LivePlay`: Kodi refreshes its widgets when the home screen is back, before it writes the end
of the play) or the day changes, the first pages warmed (their full details in the media cache). The aired episodes of
shows the list has not (`ffinfo.watched_shows(stale=...)`) are read in the warm-up, with no lock: a plugin call does not
wait for TMDB but for the shows of the pages it shows (`first`, the page gets their details anyway); a later page asked
reads those of its shows then (the earlier pages stay as they are).
"""

from __future__ import annotations
from datetime import date as dt_date
from threading import Lock
from typing_extensions import TypeAlias
from attrs import frozen

from ..defs import MediaRef
from ..ff.db.playback import live_play, progress_timestamp
from ..ff.kodidb import FileStamp, video_db
from ..ff.logs import fflog
from const import const

#: The key of a computed list: the last progress change, the state of Kodi video DB (None: MySQL), the FF media playing now
#: and if it is watched already (None: none plays) and the day (an episode aired since).
ShowsKey: TypeAlias = 'tuple[float, tuple[FileStamp, ...] | None, tuple[str, bool] | None, dt_date]'


@frozen(kw_only=True)
class KeptShows:
    """A computed list of the shows in progress."""

    #: The key the list was computed with.
    key: ShowsKey
    #: The shows in progress.
    shows: list[MediaRef]
    #: The number of the leading shows with their aired episodes read (`ffinfo.watched_shows(first=...)`).
    first: int
    #: The shows of the list with no current aired episodes (kept in progress until updated).
    stale: frozenset[MediaRef]


class ShowsInProgress:
    """The shows in progress (`ffinfo.watched_shows()`) computed only here, per account (None - all accounts)."""

    def __init__(self) -> None:
        self._lock: Lock = Lock()
        self._lists: dict[str | None, KeptShows] = {}
        self._warmed: ShowsKey | None = None

    def shows(self, account: str | None = None, *, first: int | None = None) -> list[MediaRef]:
        """
        Return the shows in progress (of the `account`), the aired episodes of the `first` shows read (the pages shown, the
        first one by default); a running computation or warm-up is joined (waited for). The list of all accounts warms its
        first pages too, before the answer: the caller asks for a page next, it is not fetched twice.
        """
        with self._lock:
            shows = self._get(account, first=first)
            if account is None:
                self._warm_pages()
            return list(shows)

    def _get(self, account: str | None, *, first: int | None = None) -> list[MediaRef]:
        """
        Return the kept list if its key is current and its `first` shows have their aired episodes (none of them stale), else
        compute it (the lock is held).
        """
        from ..ff.info import ffinfo
        if first is None:
            first = const.indexer.tvshows.progress.page_size
        live = None if (play := live_play()) is None else (play.ref, play.watched())
        key: ShowsKey = (progress_timestamp(), video_db.db_stamp(), live, dt_date.today())
        if (kept := self._lists.get(account)) is not None and kept.key == key and (first <= kept.first or kept.stale.isdisjoint(kept.shows[:first])):
            return kept.shows
        stale: list[MediaRef] = []
        shows = ffinfo.watched_shows(account=account, stale=stale, first=first)
        self._lists[account] = KeptShows(key=key, shows=shows, first=first, stale=frozenset(stale))
        return shows

    def warm(self) -> None:
        """
        Compute the list of all accounts and the details of its first `const.indexer.tvshows.progress.warm_pages` pages, once per key;
        then the aired episodes of the stale shows (`ffinfo.update_aired()`, with no lock), the lists are computed again.
        """
        from ..ff.info import ffinfo
        with self._lock:
            self._get(None)
            self._warm_pages()
            stale = list({ref for kept in self._lists.values() for ref in kept.stale})
        if stale:
            updated = ffinfo.update_aired(stale)
            fflog(f'[PROGRESS] aired episodes of {len(updated)} of {len(stale)} stale shows')
            with self._lock:
                self._lists.clear()
                self._warmed = None
                self._get(None)
                self._warm_pages()

    def _warm_pages(self) -> None:
        """Get the details of the first pages of the kept list of all accounts, once per its key (the lock is held)."""
        from ..ff.info import ffinfo
        if not (pages := const.indexer.tvshows.progress.warm_pages) or (kept := self._lists.get(None)) is None or kept.key == self._warmed:
            return
        if refs := kept.shows[:pages * const.indexer.tvshows.progress.page_size]:
            ffinfo.progress_shows_page(refs)  # the same data as the plugin page: the shows with their seasons, the next episodes
        self._warmed = kept.key
        fflog(f'[PROGRESS] warmed {len(refs)} of {len(kept.shows)} shows in progress')
