"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import sty  # XXX XXX XXX

from pathlib import Path
import shutil
# import re
import json
import math
from time import monotonic
import sys
from traceback import format_stack
# from enum import Enum
from itertools import chain
from urllib.parse import urlsplit
# from pprint import pformat  # DEV LOGS
from typing import Any, Tuple, List, Dict, Set, Callable, Sequence, Iterable, overload, TYPE_CHECKING
from typing_extensions import cast
from attrs import define, frozen, Factory, field, evolve

import xbmc
from xbmc import getInfoLabel, getCondVisibility, Player as XbmcPlayer
from xbmcgui import Dialog, ListItem

# Some consts.
from const import const, CONST_REF, MediaWatchedMode, PlayCancel

from ..defs import MediaRef, RefType, FFRef
from ..ff import cache, control
from ..ff.control import reset_all
from ..ff.threads import Thread, Timer, Event, Queue, ShutDown, CancelScope
from ..api.trakt import TraktApi, ScrobbleAction
from ..ff.accounts import enabled_clients
from ..ff.sync import send_change
from ..ff.settings import settings, advanced_settings
from ..ff.db import state
from ..ff.db.playback import LivePlay, MediaPlayInfo, live_play, progress_announced, progress_changed, progress_timestamp, set_live_play
from ..ff.item import FFItem, FFItemDict
from ..ff.info import ffinfo
from ..ff.tricks import str_removeprefix
from ..ff.kotools import xsleep, get_player_item, stop_playing, video_playing, KodiLibraryType, KodiRpc
from ..ff.kodidb import KodiVideoDB, KodiVideoInfo, video_db, load_strm_file
from ..ff.logs import fflog, fflog_exc
from ..ff.calendar import utc_timestamp
from ..indexers.defs import VideoIds
from .exc import ExitBaseException, KodiExit
from . import base
from .base import Work, service_threads, service_works, join_threads, cyclic_call, after_video
from .misc import VolatileFfid, PluginRequestInfo, FFState, update_playback_db_by_kodi_info, SkipUpdate, align_library, repair_placeholder_resumes
from .http_server import HttpProxy
from .web_server import WebServer
from .tracking.accounts import AccountSync
from .progress import ShowsInProgress
from ..kolang import L
if TYPE_CHECKING:
    from typing import ClassVar
    from .misc import LibraryAutoAddSource
    from .reload import ReloadMonitor
    from .library import Library
    from .providers import ServiceProviders
    from ..ff.libtools import LibraryRun
    from ..ff.types import JsonData
    from ..api.trakt import HistoryContentType, Ids as TraktIds

# start sync on addon start (default: True), False for dev/testing (CLI)
START_SYNC_ON_START = True
# hack, for state in service mode
state.SERVICE = True
# reset some stuff on script relaod
reset_all()
#: File names of the cancel placeholders (skip blank).
OMIT_FILES: tuple[str, ...] = tuple(path.rpartition('/')[2] for mode in PlayCancel if (path := mode.path))


# FF plugin path
plugin_id: str = control.plugin_id
plugin_url: str = control.plugin_url


@define
class MediaNotifInfo:
    #: Real media type (movie or episode).
    type: RefType
    #: Video FFID.
    ffid: int
    #: Movie or episode IDs for query old FF links in kodi db.
    item: FFItem
    #: Movie or episode Kodi DB video info.
    kodi_info: KodiVideoInfo
    #: Trakt playback (event if not trakt credentials, will be ignored in this case)
    playback: MediaPlayInfo
    #: Denormalized ref.
    de_ref: MediaRef

    @property
    def ref(self) -> MediaRef:
        """Movie or episode ref (normalized)."""
        return self.item.ref

    @property
    def denormalized_ref(self) -> MediaRef:
        """Movie or episode ref (denormalized)."""
        return MediaRef(self.type, self.ffid)

    @property
    def history_type(self) -> HistoryContentType:
        """Movie or episode ref (normalized)."""
        # hack: movie -> movies, episode -> episodes
        return cast(HistoryContentType, f'{self.type}s')

    @property
    def ids(self) -> TraktIds:
        """Returns item ids. Convert type only, data already are OK."""
        if TYPE_CHECKING:
            return cast(TraktIds, self.item.ids)
        return self.item.ids


@frozen(kw_only=True)
class SeekInfo:
    """Seek offset and time from xbmc.Player.OnSeek notification."""
    # Seek offset – the jump of the seek.
    offset: float
    # The position after the seek (time from the beginning).
    time: float
    # Playing speed factor (0: paused).
    speed: float = 1

    def progress_for_time(self, total: float) -> float:  # 0 .. 100
        """Return the position after the seek in percent of the `total` time."""
        return 100 * self.time / total if total > 0 else 0


@frozen(kw_only=True)
class AddToLibraryRequest:
    """Info for adding to library request."""
    items: Sequence[FFRef]
    name: str
    sync: bool | None = None
    quiet: bool = False
    reload_after: bool = True   # False for intermediate chunks — skip UpdateLibrary
    #: The run shared by every chunk of one add_to_library() call (see `LibTools.add(run=...)`).
    run: LibraryRun | None = None


@define
class Works:
    #: Jobs (DB requests).
    jobs: Work | None = None
    #: Trakt sync thread object.
    account_sync: AccountSync | None = None
    #: All events (shared with HTTP server).
    events: Dict[str, Event] = Factory(dict)
    #: Volatile FFID.
    volatile_ffid: VolatileFfid = Factory(VolatileFfid)
    #: Folder info and history.
    folder: PluginRequestInfo = Factory(PluginRequestInfo)
    #: HTTP proxy (service) server.
    http: HttpProxy | None = None
    #: WEB server.
    web: WebServer | None = None
    #: General state virtual DB.
    state: FFState = Factory(FFState)
    #: Library service (adding items in the background).
    library: Library | None = None
    #: Library service (adding items in the background).
    library_jobs: Queue[AddToLibraryRequest] = field(factory=Queue)
    #: Methods to library auto add.
    library_auto_add: dict[LibraryAutoAddSource, Callable[[], None]] = field(factory=dict)
    #: Any providers' works (e.g. NetMirror token refresh)
    providers: ServiceProviders | None = None
    #: The shows in progress (computed only in the service, the first pages warmed).
    shows_progress: ShowsInProgress = Factory(ShowsInProgress)

    def reset(self):
        """Destroy all cyclic workers."""
        if self.jobs:
            self.jobs.stop()
        if self.account_sync:
            self.account_sync.stop()
        if self.http:
            self.http.stop()
        if self.web:
            self.web.stop()
        if self.library:
            self.library.stop()
        self.jobs = None
        self.account_sync = None
        self.events.clear()
        self.volatile_ffid = VolatileFfid()
        self.folder = PluginRequestInfo()
        self.http = None
        self.web = None
        self.state = FFState()
        self.library = None
        self.library_jobs = Queue()
        self.library_auto_add.clear()
        self.shows_progress = ShowsInProgress()


# All cyclic workers.
works = Works()

#: Set after a video library scan: the new items of the library get the FF state (`library_align_check()`).
library_scanned: Event = Event()

# Base events.
works.events['folder'] = Event()
works.events['folder'].set()  # ready by default


def hash_bar(text: str | None = None, *, stack_depth: int = 1) -> None:
    """Log ##### bar with text in the center."""
    width = 63
    if text is None:
        fflog("#" * width, stack_depth=stack_depth+1)
    else:
        text = f" {text} "
        fflog(f"{text:#^{width}}", stack_depth=stack_depth+1)


def hash_box(lines: List[str], *, ff: bool = False, stack_depth: int = 1) -> None:
    """Log text in ##### box. If `ff` is True, log "FANFILM" in header. """
    hash_bar("FANFILM" if ff else None, stack_depth=stack_depth+1)
    for line in lines:
        hash_bar(line, stack_depth=stack_depth+1)
    hash_bar(None, stack_depth=stack_depth+1)


def hash_bar_next(settting_name: str, title: str = '', stack_depth: int = 1) -> None:
    """Log update info, plus next in H hours."""
    hours = settings.getInt(settting_name)
    hash_bar(f"{title or settting_name} UPDATE - NEXT ON {hours} HOURS", stack_depth=stack_depth+1)


class FFMonitor(xbmc.Monitor):
    """FF monitor."""

    VTYPES: ClassVar[dict[str, RefType]] = {
        'tvshow': 'show',
    }

    def __init__(self, *, selfcheck: bool = True) -> None:
        super().__init__()
        self.selfcheck: bool = bool(selfcheck)
        #: The sources watched by the autoreload (`const.debug.autoreload`), None: not watched.
        self.reload_monitor: ReloadMonitor | None = None
        #: The sources changed (the autoreload) or a restart asked (`service/restart`): the service ends, a fresh one starts (`restart_service()`).
        self.restart: bool = False
        self.kodidb: KodiVideoDB = video_db
        #: True if working, else exit from monitor loop.
        self.working: bool = True
        #: Player state dict.
        self.player_info: Dict[str, Any] = {}
        #: The skipped (canceled) play reached the video start, Kodi went to the full screen video.
        self.skip_av_started: bool = False
        #: Playing now media denormalized reference (FFID).
        self.playing_media_de_ref: MediaRef | None = None
        #: Full ff-item of playing media
        self.playing_ffitem: FFItem | None = None
        #: All items needed to support playing media progress.
        self.playing_items: FFItemDict | None = None
        #: What to skip and when.
        self.skip_updates: SkipUpdate = SkipUpdate()
        #: Current playing Kodi ListItem. Set on OnPlay, remove after OnStop.
        self.playing_item: ListItem | None = None
        #: True, if library is scanning.
        self.lib_scanning: bool = False
        #: The end of the handling of the last library notification (`VideoLibrary.OnUpdate`, monotonic seconds), `inf` while
        #: one is handled: Kodi announces a mark of a show as a series of them, the library alignment waits for its end.
        self.library_update_at: float = 0
        #: JsonRPC client for Kodi RPC calls.
        self.rpc = KodiRpc()
        #: Number of onNotification calls (for debug).
        self._notif_cnt = 0
        #: The one player object of the service, created in the thread of waitForAbort() and kept to the end. Kodi queues
        #: player events for every living xbmc.Player with a raw pointer; a temporary one freed before the queue runs
        #: leaves a call to freed memory (crash in waitForAbort).
        self.player: XbmcPlayer = XbmcPlayer()

    def run(self) -> None:
        while self.working and not self.abortRequested():
            # fflog(f'FFMonitor.run... ans={service.ans}')
            # state.add_job('plugin', 'dupa', ('blada', 'ciemna'), sender='service')
            interval = const.tune.service.check_interval
            if self.waitForAbort(interval):
                break
            try:
                self.mark_position()
            except Exception:
                fflog_exc()
            if self.restart:  # asked (`service/restart` of the server)
                Dialog().notification('FanFilm', 'The service restarts', sound=False)  # developer
                return
            if self.selfcheck and self.sources_settled():
                Dialog().notification('FanFilm', 'Changed sources, the service restarts', sound=False)  # developer
                self.restart = True
                return
        raise KodiExit()

    def sources_settled(self) -> bool:
        """
        Return True if the sources changed (`const.debug.autoreload`) and none changes for `const.debug.autoreload_quiet` s
        (a checkout: one restart); never while Kodi stops the service (an exit, an update: Kodi changes the files after the
        stop) nor after Kodi installed the add-on (Kodi starts its new service itself).
        """
        if (watch := self.reload_monitor) is None or not watch.changed():
            return False
        while not self.waitForAbort(const.debug.autoreload_quiet):
            if not watch.changed():
                return not watch.installed()
        return False

        # --- start from beginning (old code) ---
        # Info.OnChanged          None
        # Player.OnPlay           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange       {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                             'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                             'time': {'hours': 0, 'milliseconds': 470, 'minutes': 10, 'seconds': 5}}}
        # <FF enter>
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- resume (kodi) ---
        # <ff enter>             action=play&imdb=tt17024450&tmdb=926393
        # Playlist.OnAdd         {'item': {'id': 170244501, 'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # <ff exit>
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange      {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                            'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                            'time': {'hours': 0, 'milliseconds': 149, 'minutes': 32, 'seconds': 18}}}
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}
        # <ff enter>             action=movies&url=tmdb_popular

        # --- to the end (no user action at all)
        # ...
        # <ff enter>             action=movies&url=tmdb_popular
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}, 'playcount': 2}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop         {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- cancel sources ---
        # Player.OnStop          {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}

        # --- pure video file ---
        # Playlist.OnAdd'        {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # Player.OnPlay          {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange x2, Player.OnAVStart ...
        # VideoLibrary.OnUpdate  {'id': -1, 'type': ''}
        # Player.OnStop          {'end': True, 'item': {'title': 'smediaPL--Most nad Sundem S02E07 Lektor PL.[CDA:12827975cd].mp4', 'type': 'movie'}}

        # --- set as watched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 1}

        # --- set as unwatched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 0}

        # --- reset progress  ---
        # VideoLibrary.OnUpdate  ...

        # --- others ---
        # System_OnSleep         None
        # System_OnWake          None

        # --- widget ---
        # Player.OnPlay          {'item': {'type': 'unknown'}, 'player': {'playerid': -1, 'speed': 1}}

        # ---
        # Info.OnChanged    - called on CGUIInfoManager::SetCurrentItem, when ListItem info changed?

        # Logika
        # ------
        # przed  Trakt | 0 ½ | 0 e | 0 ½ | 0 e | 1 ½ | 1 e | 1 ½ | 1 e |
        #         Kodi | 0 ½ | 0 e | 1 ½ | 1 e | 0 ½ | 0 e | 1 ½ | 1 e |
        #       folder | 0         | 1         | 1         | 1         |
        # -------------+-----+-----+-----+-----+-----+-----+-----+-----+
        # po   db Kodi | 0 D | 1 _ | 0 D | 1 _ | 0 D | 1 _ | 2 D | 2 _ |
        #        Trakt | 0 D | 1 _ | 1 D | 1 _ | 1 _ | 1 _ | 1 D | 1 _ |

    def onScanStarted(self, library: str) -> None:
        """The video or music library scan has been started, called by Kodi."""
        lib = cast(KodiLibraryType, library)
        if lib == 'video':
            self.lib_scanning = True

    def onScanFinished(self, library: str) -> None:
        """The video or music library has been scanned, called by Kodi."""
        lib = cast(KodiLibraryType, library)
        if lib == 'video':
            self.lib_scanning = False
            library_scanned.set()  # new items of the library get the FF state (`library_align_check()`)

    # @suppress(Exception, log_traceback=True)
    def onNotification(self, sender: str, method: str, data: str) -> None:
        """Notification, called by Kodi."""
        self._notif_cnt += 1
        cnt = self._notif_cnt
        library_update = sender == 'xbmc' and method == 'VideoLibrary.OnUpdate'
        if library_update:
            self.library_update_at = math.inf  # the library alignment waits (`library_align_check()`)
        try:
            self._on_notification(cnt, sender, method, data)
        finally:
            if library_update:
                self.library_update_at = monotonic()

    def _on_notification(self, cnt: int, sender: str, method: str, data: str) -> None:
        """Handle the notification `cnt`."""
        if sender == 'xbmc' and method == 'VideoLibrary.OnUpdate' and data and json.loads(data).get('transaction') is True:
            fflog.debug(f'--- [{cnt:2d} / enter / exit : mass library update')
            return
        fflog.debug(f'--- [{cnt:2d} / enter]')
        self.player_info = state.get_all(module='player')
        if const.debug.service_notifications:
            from .dev import spy
            spy.onNotification(sender, method, data)

        # works.events['folder'].clear()
        # fflog('[FOLDER] hold')
        _PLR = '\n'.join(f'  {k!r}: {v!r}' for k, v in self.player_info.items())
        fflog.debug(f' >> player_info = {{\n{_PLR}\n  }}')

        try:
            if sender == plugin_id:
                self.handle_fanfilm(method, data)
            else:
                self.handle_notification(sender, method, data)
            fflog.debug(f'--- [{cnt:2d} / exit]')
        except Exception:
            fflog_exc()
        except BaseException:
            fflog_exc()
            raise
        finally:
            # self.folder_ready()
            try:
                fflog.debug(f'--- [{cnt:2d} / fin] folder_ready={works.events["folder"].is_set()}')
            except KeyError:
                fflog('works.events["folder"] MISSING !!!')

    def handle_fanfilm(self, method: str, data_str: str) -> None:
        """Handle FanFilm specific notifications."""
        method = str_removeprefix(method, 'Other.')
        data: JsonData = json.loads(data_str or '{}') or {}
        mid = data.get(KodiRpc.MESSAGE_ID_NAME, 0)

        if method == 'ServicePing':
            self.rpc.notify('ServicePong', data, id=mid, action='response')

    def handle_notification(self, sender: str, method: str, data_str: str) -> None:
        data: JsonData = json.loads(data_str or '{}') or {}
        # rx = re.compile(r'\W+')
        # notif: str = f'{rx.sub("_", sender)}__{rx.sub("_", method)}'
        notif = f'{sender}.{method}'

        def playing_empty() -> bool:
            """True if empty file is really playing."""
            return getInfoLabel('Player.FilenameAndPath').endswith(OMIT_FILES)

        # kodi playing ListItem.
        def dump_item(it: ListItem | None) -> None:
            if it is None:
                fflog(f'[SERVICE] {notif} playing_item: None')
                return
            v = it.getVideoInfoTag()
            imdb = v.getUniqueID('imdb')
            tmdb = v.getUniqueID('tmdb')
            resume = f'{v.getResumeTime()} / {v.getResumeTimeTotal()}'
            fflog(f'[SERVICE] {notif} playing_item: dbid={v.getDbId()}, {imdb=}, {tmdb=}, episode={v.getEpisode()}, {resume=}')
            fflog.debug(f'[SERVICE] {notif} playing_item: {v.getIMDBNumber()=}, {it.getLabel()=}, {it.getPath()=}')
        #
        player_item = get_player_item(self.player)
        if notif in ('xbmc.Player.OnPlay', 'xbmc.Player.OnResume', 'xbmc.Playlist.OnAdd'):
            self.playing_item = player_item
        dump_item(player_item)

        # guess, what happened
        should_playing: bool = self.player_info.get('playing.video', False)
        is_playing_now: bool = getCondVisibility('Player.Playing')
        try:
            if self.player_info.get('playing.empty') or playing_empty():
                self.handle_skip_playing(notif, data)
            elif self.player_info.get('playing.run') or (notif == 'xbmc.Player.OnStop' and self.player_info.get('playing.video')):
                # the end of an FF video (since Player.OnAVStart) also when the next item of a playlist has called the plugin
                # already (its play resets `playing.run` before Kodi announces this stop)
                self.handle_ff_play(notif, data)
            elif notif == 'xbmc.VideoLibrary.OnUpdate' and not data.get('added') and not is_playing_now and not should_playing:
                self.handle_library_watched(notif, data)
            elif (notif == 'xbmc.VideoLibrary.OnUpdate' and not self.player_info.get('state')
                  and isinstance((dbid := data.get('id')), int) and dbid > 0 and dbid not in VideoIds.KODI_DBID):
                self.handle_watched(notif, data)
            else:
                self.handle_other(notif, data)
        finally:
            # clear current playing item
            if notif == 'xbmc.Player.OnStop' or (notif == 'xbmc.Playlist.OnClear' and not is_playing_now):
                self.playing_item = None
            if notif == 'xbmc.Player.OnStop':
                set_live_play(None)  # the end of the play is written: Kodi video DB (before it announces the stop), the rows of the accounts

    def handle_skip_playing(self, notif: str, data: JsonData) -> None:
        """Handle skip FF play (close sources window)."""
        fflog(f'[SERVICE][FFSKIP] {notif}')
        if notif == 'xbmc.Player.OnPlay':
            self.skip_av_started = False
            control.close_busy_dialog()
            mode = self.player_info.get('cancel.mode')
            stop_playing(self.player, stop=not (mode and PlayCancel(mode).ends_itself))
            self.set_state('state', 'canceling')
        elif notif == 'xbmc.Player.OnAVStart':
            # Kodi went to the full screen video, it reloads the list itself on return (GUI_MSG_WINDOW_INIT)
            self.skip_av_started = True
        elif notif == 'xbmc.Player.OnStop':
            # Kodi has saved the placeholder play already (VideoPlayer: OnPlayerCloseFile before OnPlayBackStopped, K21, K22),
            # put back the play state of the item from before the cancel (resume point, last played, play count).
            # Kodi saves a placeholder play with a play time only (a resume, TT430, EMPTY; not DATA from the start). Both that
            # save and Files.SetFileDetails send the list a bare item from the DB, it replaces the info tag of the list item
            # (no plot, no art): only a changed state is put back, and then the list is refreshed.
            restored = False
            if restore := self.player_info.get('cancel.restore'):
                try:
                    restored = self.kodidb.file_details(restore['file']) != restore
                except Exception:
                    fflog_exc()
                    restored = True
                if restored:
                    fflog(f'[SERVICE][FFSKIP] restore the play state {restore}')
                    self.kodidb.set_file_details(restore)
            # The restored item is shown with the placeholder state and without its info, refresh the list once: after the play
            # script ends (a refresh started earlier gets a new interpreter) and only if Kodi does not reload it itself.
            refresh = restored and not self.skip_av_started
            self.clear_player_state('canceling')
            self.set_state('state', '')
            if refresh and (delay := const.player.refresh_on_cancel_resume):  # None (or 0) disables it
                if const.player.refresh_on_cancel_from_call and (calls := works.folder.history) and calls[0].exit_timestamp:
                    # the play script has ended already (DATA: ~1 s before the stop): the delay counts from its end
                    delay = max(0.0, calls[0].exit_timestamp + delay - utc_timestamp())
                # only the list of the play (Back to its parent or Home meanwhile: nothing to refresh there)
                Timer(delay, control.refresh, kwargs={'folder': getInfoLabel('Container.FolderPath')}).start()
        elif notif == 'xbmc.VideoLibrary.OnUpdate':
            # If video was playing... we need to finish previous video state.
            if self.player_info.get('playing.media.ref'):
                self.next_play(data=data)

    def handle_ff_play(self, notif: str, data: JsonData) -> None:
        """Handle FF3 playing (library too), all with plugin://plugin.videofanfilm[3]/..."""
        fflog(f'[SERVICE][FFPLAY] {notif}')
        if notif == 'xbmc.Player.OnPlay':
            # control.close_busy_dialog()  -- to early, the video could start a few seconds
            if info := self.item_info(data):
                self.set_state((
                    ('playing.progress', info.kodi_info.percent),
                    ('playing.play_count', info.kodi_info.play_count),
                ))
            else:
                self.set_state((
                    ('playing.progress', 0),
                    ('playing.play_count', 0),
                ))
        elif notif == 'xbmc.Player.OnAVStart':
            control.close_busy_dialog()
            info = self.item_info(data)
            self.send_playing_state(info=info)
            self.set_state((
                ('playing.video', True),
                ('playing.path', getInfoLabel('Player.FilenameAndPath')),
                ('playing.last', None),
                ('playing.next', None),
                *((f'playing.{k}', v) for k, v in self.player_info.items() if k.startswith('media.')),  # copy media.* to playing.media.*
                ('state', 'playing'),
            ))
            self.mark_position(data)
            if info and info.type == 'episode' and not getInfoLabel('Player.FilenameAndPath').lower().endswith('.strm') and (media_ref := self.player_info.get('media.ref')):
                from ..ff.upnext import signal_upnext
                signal_upnext(current_item=info.item, ref=media_ref, player=self.player)
        elif notif == 'xbmc.VideoLibrary.OnUpdate':
            # If video should be playing...
            if self.player_info.get('playing.video'):
                if self.player.isPlaying():
                    # Still playing buf video is changed (more items on playlist, upnext etc...).
                    if (old_path := self.player_info.get('playing.path')) and old_path != (new_path := getInfoLabel('Player.FilenameAndPath')):
                        self.next_play(data=data)
                else:
                    # FF video should be playing but player has stop. It's playing finish labeled as "state = played".
                    self.set_state('state', 'played')
        elif notif == 'xbmc.Player.OnStop':
            is_playing: bool = self.player_info.get('playing.video', False)
            if not is_playing:
                # if the video didn't start at all (there was no Player.OnAVStart)
                control.close_busy_dialog()
            # the item which played (`playing.media.*` from Player.OnAVStart), not `media.*`: the next item of a playlist
            # sets them in its play, before Kodi announces this stop; read before the state is cleared
            info = self.item_info(data, player_info_prefix='playing.media') if is_playing else None
            self.clear_player_state()
            if is_playing:
                # real successful playing (was on Player.OnAVStart)
                self.send_played_state(info=info)
            else:
                fflog('[SERVICE] playing failed (no Player.OnAVStart)')
            self.set_state('state', '')
            self.folder_ready()
        elif notif == 'xbmc.Player.OnSeek':
            info = self.item_info(data)
            seek = self.seek_info(data)
            fflog(f'[SERVICE] {info=}')
            self.mark_position(data)
            self.send_playing_state(info=info, seek=seek)
        elif notif in ('xbmc.Player.OnPause', 'xbmc.Player.OnResume'):
            # the service would count a paused play on (its clock) and close it as watched
            if self.player_info.get('playing.video'):
                self.mark_position(data)
                self.send_playing_state(info=self.item_info(data), paused=notif == 'xbmc.Player.OnPause')
        elif notif == 'xbmc.Player.OnSpeedChanged':
            if self.player_info.get('playing.video'):
                self.mark_position(data)
        else:
            fflog(f'[SERVICE] unsupported play event, {notif=}, {data=}')

    def next_play(self, *, data: JsonData) -> bool:
        """Handle next play. Still playing buf video is changed (more items on playlist, upnext etc...)."""
        item: Dict[str, Any] = data.get('item', data)
        vtype: str = item.get('type', '')
        dbid: int = item.get('id', 0)
        old_path = self.player_info.get('playing.path')
        new_path = getInfoLabel('Player.FilenameAndPath')
        if vtype in ('movie', 'episode') and old_path and old_path != new_path:
            playing_dbid: int = int(getInfoLabel('VideoPlayer.DBID') or 0)
            new_url: str = ''
            if new_path.lower().endswith('.strm'):
                try:
                    new_url = load_strm_file(new_path)
                except (OSError, RuntimeError):
                    pass
            fflog(f'[SERVICE][NEXT] Playing {vtype} video changed from {old_path!r} to {new_path!r} ({new_url!r}), dbid {dbid} → {playing_dbid}')
            self.set_state((
                ('playing.path', new_path),
                ('playing.last', {
                    'dbid': dbid,
                    'ref': self.player_info.get('playing.media.ref'),
                    'tmdb': self.player_info.get('playing.media.tmdb'),
                    'imdb': self.player_info.get('playing.media.imdb'),
                }),
                ('playing.next', {
                    'dbid': playing_dbid,
                    'ref': None,
                    'tmdb': getInfoLabel('VideoPlayer.UniqueID(tmdb)'),
                    'imdb': getInfoLabel('VideoPlayer.UniqueID(imdb)'),
                }),
                ('state', 'play next'),
            ))
            info = self.item_info(data, player_info_prefix='playing.media')
            fflog(f'[SERVICE][NEXT] {info=}')
            self.send_played_state(info=info)
        return False

    def handle_watched(self, notif: str, data: JsonData) -> None:
        fflog(f'[SERVICE][WATCHED] {notif}')
        if notif == 'xbmc.VideoLibrary.OnUpdate':
            old_state = self.player_info.get('state')
            try:
                self.set_state('state', 'watching')
                # direct FF item set (un)watched
                if (li := get_player_item(self.player)) and (ref := MediaRef.from_slash_string(li.getVideoInfoTag().getUniqueID('ffref'))):
                    pass
                # FFID is set as DBID (and it is not internal kodi DBID), we can recover what ref is used.
                elif (vtype := data.get('type')) and isinstance((dbid := data.get('id')), int) and dbid > 0 and dbid not in VideoIds.KODI_DBID:
                    # TODO: implement it?
                    # should not hit here, shound call handle_library_watched()
                    fflog(f'[SERVICE] set (un)watch from OnUpdate DBID {vtype=}, {dbid=}  [NOT IMPLEMENTED]')
                    ...
                    return
                else:
                    fflog('[SERVICE] unsupported xbmc.VideoLibrary.OnUpdate')
                    return
                if info := self.item_info(data, ref=ref):
                    kodi_playcount = data.get('playcount')
                    fflog(f'{sty.fg.green}[SERVICE]{sty.rs.all}: {ref=}, {kodi_playcount=}, {info.kodi_info.play_count=}  ~~~')
                    if kodi_playcount is None:
                        kodi_playcount = info.kodi_info.play_count
            finally:
                self.set_state('state', old_state)

    def handle_library_watched(self, notif: str, data: JsonData) -> None:
        """On set (un)watched on library item. Support ff-links and alien links. Also called for FF3 if FAKE_DBID."""
        fflog(f'[SERVICE][LIBRARY] {notif}')
        if notif == 'xbmc.VideoLibrary.OnUpdate':
            item: Dict[str, Any] = data.get('item', data)
            vtype: str = item.get('type', '')
            dbid: int = item.get('id', 0)
            fflog(f'[SERVICE] Look watched for {vtype=}, {dbid=}')
            playcount = data.get('playcount')  # announced if changed: the state at the change (the DB may be changed again)
            if self.skip_updates.skip((vtype, dbid), playcount=playcount):
                fflog(f'[SERVICE] own library change of {vtype} {dbid} (aligned with FF), skipped')
                return
            if dbid in VideoIds.KODI_DBID and vtype in ('movie', 'episode'):  # this is the library
                if kodi_vid_info := video_db.get_play_by_kodi_id(vtype, dbid):
                    if isinstance(playcount, int):
                        kodi_vid_info = evolve(kodi_vid_info, play_count=playcount)
                    if self.is_ff_link(kodi_vid_info.fname):
                        fflog(f'[SERVICE] Found watched {kodi_vid_info=}')
                        update_playback_db_by_kodi_info(kodi_vid_info)
                    elif self.is_alien_enabled(kodi_vid_info.fname):
                        if info := self.item_info(data, kodi_vid_info=kodi_vid_info):
                            # TODO: handle alien library videos
                            fflog(f'[SERVICE] library set (un)watch from OnUpdate DBID {vtype=}, {dbid=}  [NOT IMPLEMENTED]')
                            ...
            elif dbid > 0 and const.core.media_watched_mode is MediaWatchedMode.FAKE_DBID:
                # TODO: handle old (dbid) watch detector (is this necessary?)
                ...

    def handle_other(self, notif: str, data: JsonData) -> None:
        """Handle all other events (non-FF3)."""
        fflog(f'[SERVICE][OTHER] event {notif}: {data=}')
        if notif in ('xbmc.Player.OnAVStart', 'xbmc.Player.OnSeek', 'xbmc.Player.OnStop'):
            self.handle_alien(notif, data)
        elif notif == 'xbmc.System.OnQuit' and works.http is not None:
            works.http.kodi_exit()  # the plugin calls end (Kodi does not abort them, it waits for them)

    def handle_alien(self, notif: str, data: JsonData) -> None:
        """Handle alien events (kodi and other plugins video events)."""
        path = getInfoLabel('Player.FilenameAndPath') or getInfoLabel('ListItem.FilenameAndPath')
        if self.is_alien_enabled(path):
            imdb = getInfoLabel('VideoPlayer.IMDBNumber') or getInfoLabel('ListItem.IMDBNumber')
            dbid = getInfoLabel('VideoPlayer.DBID') or getInfoLabel('ListItem.DBID')
            progress = getInfoLabel('Player.Progress') or getInfoLabel('ListItem.PercentPlayed')
            info = self.item_info(data)
            url = urlsplit(path)
            if url.scheme == 'plugin':
                fflog(f'[SERVICE][ALIEN] found {notif} event for alien plugin {url.hostname!r}, {imdb=}, {dbid=}, {progress=}, {info=}')
            else:
                fflog(f'[SERVICE][ALIEN] found {notif} event for alien scheme {url.scheme!r}, {imdb=}, {dbid=}, {progress=}, {info=}')
            # --- handle alien notifications
            return  # TODO:  implement it

    def is_ff_link(self, path: str) -> bool:
        """Return True if FF link."""
        if '://' not in path and path.lower().endswith('.strm'):
            path = load_strm_file(path)
        return path.startswith(plugin_url)

    def is_alien_enabled(self, path: str) -> bool:
        """Return True if support path is enabled (local or alien plugins)."""
        url = urlsplit(path)
        sync = const.trakt.sync.alien.scheme.get(url.scheme or 'file', const.trakt.sync.alien.default)
        if url.scheme == 'plugin':
            if url.hostname == plugin_id:  # this is not an alient, this is the FF3
                return True
            sync = const.trakt.sync.alien.plugins.get(url.hostname or '', sync)
        return sync

    def item_info(self,
                  data: JsonData,
                  *,
                  player_info_prefix: str = 'media',
                  ref: MediaRef | None = None,
                  kodi_vid_info: KodiVideoInfo | None = None,
                  ) -> MediaNotifInfo | None:
        """Returns full video info, based on state[player], kodi db, trakt db, notification json."""
        ffitem: FFItem | None = None
        pb: MediaPlayInfo | None = None

        item: Dict[str, Any] = data.get('item', data)
        de_ref = MediaRef(item.get('type', ''), item.get('id', 0))
        log_msg = ''
        # if (itype := item.get('type')) and (iid := item.get('id')):
        #     de_ref = MediaRef(itype, iid)
        if ref is not None:
            log_msg = 'with given ref'
        elif ref := self.player_info.get(f'{player_info_prefix}.ref'):
            log_msg = 'from "media.ref"'
        elif (li := get_player_item(self.player)) and (ref := MediaRef.from_slash_string(li.getVideoInfoTag().getUniqueID('ffref'))):
            log_msg = 'from "ffref"'
        else:
            fflog(f'[SERVICE] the is no REF at all, {item=}')
            return None
        # find more info
        ffitem = ffinfo.find_item(ref, progress=ffinfo.Progress.NO)
        fflog(f'[SERVICE] item info {log_msg}: {ref=}, {ffitem=}')
        # info from kodi MyVideos DB for VideoLibrary (DBID)
        if kodi_vid_info is None and de_ref.type in ('movie', 'episode') and de_ref.ffid in VideoIds.KODI_DBID:
            kodi_vid_info = video_db.get_play_by_kodi_id(de_ref.type, de_ref.ffid)
        # info from kodi MyVideos DB
        if kodi_vid_info is None and (media_url := self.player_info.get(f'{player_info_prefix}.url')):
            kodi_vid_info = video_db.get_play_by_url(media_url)
            if ffitem is None and kodi_vid_info is not None and kodi_vid_info.ref:
                ffitem = ffinfo.find_item(kodi_vid_info.ref, progress=ffinfo.Progress.NO)
                if ffitem:
                    fflog(f'[SERVICE] recovered from kodi db: {ffitem=}')
        if kodi_vid_info is None:
            kodi_vid_info = KodiVideoInfo(ref=ref)  # empty video info (no progress)
        if ffitem is None:
            fflog(f'[SERVICE] no ffitem, {ref=}, {item=}')
            return None
        # the playback of the local Kodi account (Kodi video DB)
        pb = MediaPlayInfo.from_ffitem(ffitem)
        if not kodi_vid_info.fake:
            pb.play_count = kodi_vid_info.play_count
            pb.progress = kodi_vid_info.percent
        # super info object
        return MediaNotifInfo(type=item.get('type', ref.real_type), ffid=ref.ffid,
                              item=ffitem, kodi_info=kodi_vid_info, playback=pb, de_ref=de_ref)

    def seek_info(self, data: JsonData) -> SeekInfo | None:
        """Returns seek info (percent progress)."""
        def get_time(d: JsonData) -> float | None:
            try:
                h, m, s, x = d['hours'], d['minutes'], d['seconds'], d.get('milliseconds', 0)
            except KeyError:
                return None
            return h * 3600 + m * 60 + s + x / 1000

        if player_data := data.get('player', {}):
            offset = get_time(player_data.get('seekoffset', {}))
            time = get_time(player_data.get('time', {}))
            speed = player_data.get('speed', 1)
            if offset is not None and time is not None:
                return SeekInfo(offset=offset, time=time, speed=speed)
        return None

    def clear_player_state(self, state: str = 'stopping'):
        self.set_state((
            ('playing.empty', False),
            ('playing.run', False),
            ('playing.video', False),
            ('playing.path', ''),
            ('playing.last', None),
            ('playing.next', None),
            *((k, None) for k in self.player_info if k.startswith('playing.media.')),  # clear playing.media.*
            ('cancel.mode', None),
            ('cancel.restore', None),
            ('state', state),
        ))

    def send_playing_state(self, *, info: MediaNotifInfo | None, seek: SeekInfo | None = None, paused: bool | None = None) -> None:
        """
        Send current playing state (scrobble: start, pause in the player). `paused`: a pause / resume in the player
        (the progress from the player), None - a start or a seek (paused if the player does not move).
        """
        fflog(f'[SERVICE] playing state {info=}, {seek=}, {paused=}')
        if info is None:
            fflog.warning('[SERVICE] can NOT set playing state, there is no info')
            return
        action: ScrobbleAction = 'pause' if paused or (paused is None and seek and not seek.speed) else 'start'
        # Seek playing video, just update "play srobble" progress (from seek notification).
        if seek:
            # the total time of Kodi could be wrong: the longest known (not shorter than the position)
            time = max(info.item.duration or 0, info.playback.duration or 0, info.kodi_info.total_s, seek.time)
            self.scrobble(info, action, progress=seek.progress_for_time(time), playing=True)
        # Paused or resumed in the player: its position.
        elif paused is not None:
            self.scrobble(info, action, progress=self.player_progress(), playing=True)
        # Just playing (start or resume), update "play srobble" video progress (from trakt, db or kodi).
        else:
            self.scrobble(info, action, playing=True)

    def mark_position(self, data: JsonData | None = None) -> None:
        """
        Write the position of the FF media playing now (`LivePlay`: the lists read it until Kodi writes the end of the play):
        at a player event with its speed (`data`), else (the service loop) again while the player moves, the speed known
        before (the clock of the position does not see a stalled buffer).
        """
        if data is None:
            if (live := live_play()) is None or not getCondVisibility('Player.Playing'):
                return
            speed = live.speed
        else:
            speed = data.get('player', {}).get('speed', 1)
        if not (ref := self.player_info.get('playing.media.ref')):
            return
        try:
            position, total = self.player.getTime(), self.player.getTotalTime()
        except RuntimeError:  # not playing any more
            return
        if total > 0:
            set_live_play(LivePlay(ref=f'{ref:a}', position=position, at=utc_timestamp(), speed=speed, total=total))

    def player_progress(self) -> float | None:
        """Return the position of the player in percent (None if it does not play)."""
        try:
            total = self.player.getTotalTime()
            return 100 * self.player.getTime() / total if total > 0 else None
        except RuntimeError:  # not playing any more
            return None

    def send_played_state(self, *, info: MediaNotifInfo | None) -> None:
        """Send played state, current playing just stops (sroblle: pause, stop)."""
        fflog(f'[SERVICE] played state {info=}')
        if info is None:
            fflog.warning('[SERVICE] can NOT set played state, there is no info')
            return
        old_play_count = self.player_info.get('playing.play_count') or 0
        # Paused in the middle (has progress and is not at the end).
        if (info.kodi_info.has_progress and info.kodi_info.percent
                and info.kodi_info.percent < advanced_settings.watched_percent()):
            info.playback.progress = info.kodi_info.percent
            self.scrobble(info, 'pause')
        # Finish watching (no progress and play_count is incremented).
        elif info.kodi_info.play_count == old_play_count + 1:
            info.playback.play_count = info.kodi_info.play_count
            info.playback.clear_progress()
            self.scrobble(info, 'stop', 100)
            self.just_watched(info, first_time=not old_play_count)
        # WTF? I don't know what happens. Maybe stop at video beginning?
        else:
            self.scrobble(info, 'pause')

    @overload
    def set_state(self, key: str, value: Any) -> None: ...

    @overload
    def set_state(self, values: Iterable[Tuple[str, Any]], /) -> None: ...

    def set_state(self, key: Any, value: Any = None) -> None:
        """Set player state."""
        if isinstance(key, str):
            fflog(f'[SERVICE] set state {(key, value)}')
            self.player_info[key] = value
            state.set(key, value, module='player')
        else:
            values = tuple(key)  # multiset
            fflog(f'[SERVICE] set state {values}')
            self.player_info.update(values)
            state.multi_set(values, module='player')

    def folder_ready(self):
        """Mark folder as ready to show."""
        # if works.events['folder'].is_set():
        #     fflog('[FOLDER] already ready')
        works.events['folder'].set()

    def update_db(self, video: MediaNotifInfo, *, announced: bool = False) -> bool:
        """
        The playback is changed (Kodi stores it in its video DB, the local Kodi account): refresh the folder, mark it ready.
        `announced`: Kodi has announced the change (the end of a play), see `progress_changed()`.
        """
        fflog(f'{video.playback.progress}%, x{video.playback.play_count}, {video.playback=}')
        progress_changed(announced=announced)
        self.folder_ready()
        return True

    def scrobble(self, info: MediaNotifInfo, action: ScrobbleAction, progress: float | None = None, *, playing: bool = False) -> None:
        """
        Send the playback to the accounts: `playing` (`start` "watching", `pause` in the player) now; the end of the play:
        `pause` (the resume point) and `stop` (watched) as changes of the accounts (`send_change()`: the rows at once,
        delivered by the sync). video.playback.progress must be already set.
        """
        if progress is None:
            progress = info.kodi_info.percent
        progress = progress or 0
        # first, send to the accounts (the rows at once)
        if info:
            if playing:
                for client in enabled_clients('progress', 'write'):  # every active account
                    client.scrobble_ref(action, info.ref, progress)
            elif action == 'pause':
                send_change('pause', info.ref, progress=progress)
            else:  # stop at the end: watched (the resume point of the service ends too)
                send_change('watched', info.ref, progress=progress or 100)
        # next, the change after the rows: a list computed meanwhile is not kept as the new one (the end of a play: Kodi has announced it)
        self.update_db(info, announced=not playing)
        if const.debug.tty:
            fflog(f'[SERVICE] scrobble: {sty.fg.cyan} {action} {progress:.1f}% {sty.rs.all}')
        else:
            fflog(f'[SERVICE] scrobble: {action} {progress:.1f}%')
        self.folder_ready()

    def set_watched(self, video: MediaNotifInfo, play_count: int) -> None:
        """Set trakt watched plays. NOT USED ANYMORE."""
        fflog.error('[SERVICE] set_watched is DEPRECATED !!!')
        if video:
            if play_count:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = play_count
                self.update_db(video)
                # next, send to trakt
                for client in enabled_clients('watched', 'write'):
                    if video.playback.progress:
                        client.scrobble_ref('stop', video.ref, 100)  # DB is updated already
                    else:
                        client.add_history_ref(video.ref)  # DB is updated already
            else:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = 0
                self.update_db(video)
                # next, send to trakt
                for client in enabled_clients('watched', 'write'):
                    if video.playback.progress:
                        client.scrobble_ref('pause', video.ref, 0)  # DB is updated already
                    client.remove_history_ref(video.ref)  # DB is updated already
            if const.debug.tty:
                fflog(f'[SERVICE] plays: {sty.fg.cyan} set {play_count or 0} {sty.rs.all}')
            else:
                fflog(f'[SERVICE] plays:  set {play_count or 0}')
        # else:
        #     self.folder_ready()

    def onSettingsChanged(self):
        fflog('[SERVICE]')
        L.reset()
        settings.reset()  # force recreate settings proxy
        try:
            ffinfo.reset()
            library_enabled = settings.getBool('enable_library')
        except TypeError:  # Kodi failed to load the settings file being written (a burst of writes): the next change does it
            fflog('[SERVICE] the settings are being written, skipped')
            return
        # detect library settings change and start thread if needed
        if library_enabled and works.library is None:
            from .library import Library  # noqa: F811
            works.library = Library()
            works.library.start()
        elif not library_enabled and works.library is not None:
            library, works.library = works.library, None
            library.stop()
        # providers settings change
        if works.providers is not None:
            works.providers.on_settings_changed()

    def just_watched(self, video: MediaNotifInfo, *, first_time: bool) -> None:
        """Handle watch video finished."""
        fflog(f'[SERVICE] just watched: {video.ref}, first time: {first_time}')
        if const.ratings.every_watched or first_time:
            ffitem = video.item
            main_type = video.ref.type
            if main_type in ('movie', 'show') and settings.getBool(f'rate_after_watch.{main_type}'):
                from ..ff.ratings import rate_media
                if main_type == 'movie':
                    rate_media(video.item, action='watched_movie')
                else:
                    for mode in const.ratings.watched_show_mode:
                        if mode == 'show':
                            ref = ffitem.show_item or video.ref.show_ref
                        elif mode == 'season':
                            ref = ffitem.season_item or video.ref.season_ref
                        elif mode == 'episode':
                            ref = ffitem
                        elif mode == 'show_finished':
                            ref = ffitem.show_item or video.ref.show_ref
                            if ref is None or (it := ffinfo.find_item(ref, progress=ffinfo.Progress.BASIC)) is None:
                                continue
                            if it.progress is None or it.progress.play_count < 1:
                                continue
                            ref = it
                        elif mode == 'season_finished':
                            ref = ffitem.season_item or video.ref.season_ref
                            if ref is None or (it := ffinfo.find_item(ref, progress=ffinfo.Progress.BASIC)) is None:
                                continue
                            if it.progress is None or it.progress.play_count < 1:
                                continue
                            ref = it
                        else:
                            fflog(f'[SERVICE] unsupported watched show rating mode: {mode!r}')
                            continue
                        assert ref is not None
                        rate_media(ref, action='watched_episode', if_not_rated=not const.ratings.every_watched)


def correct_media_ids() -> None:
    """Correct the ID map by the changes of TMDB since the last run (`const.media.ids`)."""
    from datetime import date, timedelta
    from ..ff.info import ffinfo
    from ..ff.calendar import utc_timestamp
    if not const.media.ids.tmdb_changes:
        return
    now = int(utc_timestamp())
    last = state.get('media.ids.tmdb_changes', module='service')
    if isinstance(last, (int, float)) and now - last < const.media.ids.tmdb_changes_interval:
        return
    # since the last run (the first run: one day back), TMDB keeps 14 days of changes
    since = date.fromtimestamp(last) if isinstance(last, (int, float)) else date.today() - timedelta(days=1)
    since = max(since, date.today() - timedelta(days=13))
    if ffinfo.correct_ids(since) is not None:
        state.set('media.ids.tmdb_changes', now, module='service')


def cleanup_databases() -> None:
    """Remove expired rows from the DB caches, old subtitles of providers (and the folder of the removed netcache)."""
    from ..ff.db import media, sources, accounts, library
    from ..ff import listcache
    from ..ff.control import dataPath
    from ..ff.source_utils import cleanup_subtitles
    fflog(f'[SERVICE] DB cleanup: media {media.cleanup()} rows, sources {sources.cleanup()} rows, accounts {accounts.cleanup()} rows,'
          f' library {library.cleanup()} rows, lists {listcache.cleanup()}, subtitles {cleanup_subtitles()} files')
    if (netcache := Path(dataPath) / 'netcache').exists():
        shutil.rmtree(netcache, ignore_errors=True)
        fflog(f'[SERVICE] removed the old netcache folder {netcache}')


def service_jobs():
    if works.http is not None:
        works.http.reload_local()  # a changed local.py (the plugin calls run here too)
    for job in state.jobs('service'):
        if job.command == 'accounts.sync':  # args: the account IDs (none: all)
            if works.account_sync:
                works.account_sync.request(job.args or None)
            else:
                fflog('[WARNING] the sync of accounts is NOT running')
        elif job.command in ('refresh', 'update'):
            # push job to plugin
            state.add_job('plugin', job.command, args=job.args, sender=job.sender)


def process_library_batches():
    """Process library batches for adding to library."""
    fflog(f'Add to library worker ({"up" if works.library else "passive"})')
    while not monitor.abortRequested():
        try:
            req = works.library_jobs.get()
        except ExitBaseException:
            break
        except ShutDown:
            break
        fflog(f'Process add to library chunk: {req.name!r} ({len(req.items)})')
        if works.library is None:
            fflog(f'[LIBRARY] library is disabled, skip processing batch {req.name!r}')
        else:
            works.library.add(req.items, name=req.name, quiet=req.quiet, sync=req.sync, run=req.run)
        works.library_jobs.task_done()
        xsleep(const.library.service.chunk_sleep)


def add_to_library(name: str, items: Iterable[FFRef], *, quiet: bool = False) -> None:
    """Add library batch for processing. Split into chunks."""
    if works.library is None:
        return
    items = tuple(items)
    chunk_size = const.library.service.chunk_size
    if not chunk_size:
        chunk_size = len(items)
    fflog(f'Add to library request: {name!r} {len(items)} items in {(len(items) + chunk_size - 1) // chunk_size} chunks')
    from ..ff.libtools import LibraryRun
    run = LibraryRun()  # shared by every chunk below: an item written once, the scan after the run only if a file is written
    for offset in range(0, len(items), chunk_size):
        last = offset + chunk_size >= len(items)
        if last:
            req = AddToLibraryRequest(items=items[offset:], name=name, quiet=quiet, run=run)
        else:
            req = AddToLibraryRequest(items=items[offset : offset + chunk_size], name=f'{name} ({offset // chunk_size + 1})', quiet=True, sync=False, run=run)
        works.library_jobs.put_nowait(req)


def warm_shows_progress() -> None:
    """Warm the shows in progress up (`ShowsInProgress.warm()`), only after the first sync of the syncing accounts."""
    from ..ff.sync import syncing_accounts
    if works.account_sync is not None and works.account_sync.timestamp is None and syncing_accounts():
        return  # the first sync is not done yet
    try:
        works.shows_progress.warm()
    except Exception:
        fflog_exc()


def widgets_reload_check() -> Callable[[], None]:
    """
    Return the cyclic check reloading Kodi widgets after a progress change (`progress_changed()`, from the service or a plugin
    call): Kodi reloads them only on its own events. Changes between two checks reload once; the progress at the start does not.
    A change Kodi has announced itself (`progress_announced()`, the end of a play) does not reload them when FF lists read
    its state from Kodi video DB (a local Kodi account, the DB state known: not MySQL): Kodi reloads them at the event,
    before the service handles it, and the lists follow Kodi DB (`ShowsInProgress`, `KodiVideoDB.get_plays()`). Not while
    a video plays nor until the service has written the end of an FF play (`live_play()`, Kodi announces the stop seconds
    after the player has stopped): Kodi refreshes the widgets of the home screen when it is back, the last change counts
    then (the end of the play Kodi has announced does not reload them).
    """
    last = progress_timestamp()

    def check() -> None:
        """Reload the widgets if the progress changed since the last check."""
        nonlocal last
        if const.core.widgets_reload is None:  # switched off: the changes until it is on again do not count
            last = progress_timestamp()
            return
        if video_playing() or live_play() is not None:
            return
        if (timestamp := progress_timestamp()) != last:
            last = timestamp
            try:
                if timestamp == progress_announced() and kodi_progress_followed():
                    fflog('[SERVICE] widgets: Kodi has reloaded them at its event')
                    return
                control.reload_widgets()
            except Exception:
                fflog_exc()

    return check


def kodi_progress_followed() -> bool:
    """Return True if FF lists follow the state of Kodi video DB: a local Kodi account reads the progress, the DB state is known (not MySQL)."""
    _, local = ffinfo.progress_accounts()
    return bool(local) and video_db.db_stamp() is not None


def library_align_check() -> Callable[[], None]:
    """
    Return the cyclic alignment of the FF STRM files of Kodi library with the FF progress (`align_library()`): after a progress
    change (`progress_changed()`, from the service or a plugin call), after a library scan, once at the start; not while
    the library is scanned or a video plays (Kodi writes its state at the end), nor until the library notifications are
    handled and quiet for one interval (a native mark of a show is a series of them: the items not handled yet would look
    older than FF and be set back).
    """
    last = -1.0

    def check() -> None:
        """Align the library if the progress changed or the library was scanned since the last alignment."""
        nonlocal last
        if not const.library.service.align or monitor.lib_scanning or video_playing():
            return  # switched off: once again when it is on (as at the start)
        if monotonic() - monitor.library_update_at < const.tune.service.library_align_interval:
            return
        if (timestamp := progress_timestamp()) != last or library_scanned.is_set():
            last = timestamp
            library_scanned.clear()
            try:
                if count := align_library(monitor.skip_updates):
                    fflog(f'[LIBRARY] {count} item(s) aligned with FF')
            except Exception:
                fflog_exc()

    return check


def show_local_error_window() -> None:
    """Show the window about the ignored `local.py` when the home screen is up (at most 2 minutes of waiting)."""
    for _ in range(120):
        if xbmc.getCondVisibility('Window.IsVisible(home)'):
            break
        xsleep(1)
    control.show_local_error(again=False)


def windows_check(*, updated: bool) -> Callable[[], None]:
    """
    Return the cyclic check starting the worker of the windows (`lib.windows.base.WINDOWS_JOB`): at its first call (a change of the skin,
    the language, Kodi... before this Kodi start; the worker ends at once if the windows are prepared for the environment of now), unless
    FF is `updated` (the update worker prepares them), then at a change of what the service sees of the environment (`environment_hint()`:
    the skin, its colours, the language changed in this Kodi session), so the first open of a window - mostly the sources of a play - finds
    its XML. Not while a video plays (the next check).
    """
    last: tuple[str, ...] | None = None

    def check() -> None:
        """Start the worker of the windows at the first check or a change of the environment."""
        nonlocal last
        if video_playing():
            return
        from ..windows.base import environment_hint, start_windows_worker
        hint = environment_hint()
        if hint != last:
            if last is not None or not updated:
                fflog(f'[SERVICE] start the worker of the windows ({"start" if last is None else "environment changed"})')
                start_windows_worker()
            last = hint

    return check


def start_update_worker() -> None:
    """Start the worker script of a FanFilm update (`worker.py`: the native providers - catalog, settings migration -, the windows)."""
    fflog('[SERVICE] start the update worker')
    xbmc.executebuiltin(f'RunScript({control.plugin_id})')


def startup():
    """Initialize all startup and cyclic stuff."""
    from .providers import ServiceProviders
    from ..ff.control import pretty_log_info

    def start_cyclic_task(func: Callable, *, setting_interval: str, setting_on_start: str | None = None, title: str = '') -> None:
        hours = settings.getInt(setting_interval)
        startup = setting_on_start and settings.getBool(setting_on_start)

        if hours > 0 and startup:
            hash_box([
                f"STARTING {title} SCHEDULING",
                f"SCHEDULED TIME FRAME {hours} HOURS",
            ])

        timeout = 3600 * hours

        if startup:
            # timeout = (randint(60, 120), timeout)
            timeout = (10, timeout)  # XXX
        cyclic_call(timeout, func)

    ff_updated: bool = False  # a new FF version (an update or a new install) starts now
    try:
        AddonVersion = control.addon(control.plugin_id).getAddonInfo("version")
        AddonOldVersion = settings.getString("addon.version")
        if AddonOldVersion != AddonVersion:
            ff_updated = True
            cache.cache_clear_all()
            hash_bar("FANFILM NOWA INSTALACJA")
        settings.setString("addon.version", AddonVersion)
        pretty_log_info()
    except Exception:
        hash_box([
            "CURRENT FANFILM VERSIONS REPORT",
            "ERROR GETTING FANFILM VERSIONS - NO HELP WILL BE GIVEN AS THIS IS NOT AN OFFICIAL FANFILM INSTALL"
        ], ff=True)

    def sync_lists_lib() -> None:
        """Sync arbitrary user-picked lists (any account) to the library, then update the shows in the library (new episodes).

        Selection is picked via Tools > Library > "Select lists to sync" (see lib.ff.lists
        pickable_lists()/save_selected_list_tokens()) and read back via selected_list_tokens().
        Each token has the shape `account:section:list`, matching cdefs.ListTarget. The shows of the library
        (`LibTools.library_shows()`, setting `library.service.update`) are added again: only their missing episodes are written.
        """
        if not works.library:
            return
        from ..ff.lists import selected_list_tokens, list_target_items
        from ..ff.libtools import library
        tokens = selected_list_tokens()
        update_shows = settings.getBool('library.service.update')
        if not tokens and not update_shows:
            return
        if settings.getBool('library.service.notification'):
            # a manual "Update selected lists" click is otherwise a silent fire-and-forget
            # HTTP call - give some immediate confirmation that it actually started.
            from ..ff.control import infoDialog, addonName
            infoDialog(L(30652, 'Sync started...'), addonName())
        from cdefs import ListTarget
        from ..ff.accounts import account_enabled
        sources: list[Iterable[FFRef]] = []
        for tok in tokens:
            service, _, rest = tok.partition(':')
            section, _, list_id = rest.partition(':')
            if not account_enabled(service, 'lists', 'read'):
                # e.g. user picked 3 trakt lists, then revoked trakt auth - skip quietly instead
                # of hammering the API with calls that would just fail every sync cycle.
                fflog(f'[LIB] Service {service!r} is no longer authorized, skipping list {tok!r}.')
                continue
            target = ListTarget(service=service, section=section, list=list_id)  # type: ignore[arg-type]
            try:
                items = list_target_items(target)
            except Exception:
                # one bad/misconfigured source must not kill the whole sync (or, if triggered
                # from the cyclic scheduler, the background thread for the rest of the session)
                fflog_exc()
                fflog(f'[LIB] Failed to read list {target!r}, skipping.')
                continue
            if items is None:
                continue
            # materialize + log per-source count now (add_to_library() would materialize it
            # anyway) - with 5 services x several list types, knowing which one returned what
            # is far more useful for debugging than only the combined total at the end.
            items = list(items)
            fflog(f'[LIB] List {target!r} -> {len(items)} item(s).')
            if items:
                sources.append(items)
        if update_shows:
            try:
                shows = library.library_shows()
            except Exception:
                fflog_exc()
                shows = []
            listed = {it.ref for items in sources for it in items}  # a show of a list is not fetched twice
            shows = [ref for ref in shows if ref not in listed]
            fflog(f'[LIB] Shows in library -> {len(shows)} item(s) not in the lists.')
            if shows:
                sources.append(shows)
        if sources and settings.getBool('library.check'):
            # only the media missing in the library go to the run (no skeleton, no Kodi query, no scan for the others)
            try:
                sources = [found] if (found := library.missing(chain(*sources))) else []
            except Exception:
                fflog_exc()  # the full way for all of them, as before
        if sources:
            try:
                add_to_library('auto lists', chain(*sources))
            except Exception:
                # belt-and-suspenders: a lazily-evaluated source could still fail only once
                # consumed here, well past the per-source try/except above.
                fflog_exc()
                fflog('[LIB] add_to_library("auto lists") failed.')

    works.library_auto_add = {
        'lists': sync_lists_lib,
    }

    if START_SYNC_ON_START:
        # the maintenance works (CPU, disk, a Kodi library scan) wait for the end of a video (`after_video()`)
        start_cyclic_task(after_video(sync_lists_lib), setting_interval='schedListsTime', setting_on_start='autoListsOnStart', title='auto lists')

        # DB caches cleanup (expired rows)
        cyclic_call(CONST_REF.tune.db.cleanup_interval, after_video(cleanup_databases))

        # The ID map corrected by the changes of TMDB, checked hourly, run once per interval
        cyclic_call((5 * 60, 60 * 60), after_video(correct_media_ids))

        # The shows in progress warmed after the first sync of accounts and after every change of the progress
        cyclic_call((10, 60), after_video(warm_shows_progress))

        # Provider (sources) service-tasks manager
        works.providers = ServiceProviders()
        works.providers.start()

    if START_SYNC_ON_START:
        assert works.account_sync
        works.account_sync.start()
        service_threads.add(works.account_sync)
        service_works.add(works.account_sync)  # its intervals read again after a reload of const
        service_threads.add(th := Thread(target=process_library_batches, name='library-batches', daemon=True))
        th.start()

    works.jobs = cyclic_call(CONST_REF.tune.service.job_list_sleep, service_jobs)

    # Kodi widgets reloaded after a progress change known only to FF (a mark from the FF menu, an account sync)
    cyclic_call(CONST_REF.tune.service.widgets_reload_interval, widgets_reload_check())

    # the FF STRM files of Kodi library follow the FF progress (a mark in FF, an account sync)
    cyclic_call(CONST_REF.tune.service.library_align_interval, library_align_check())

    # the resume points Kodi wrote with the duration of the TT430 placeholder (old canceled plays) repaired once
    cyclic_call((30, 0), repair_placeholder_resumes, monitor.skip_updates)

    # the jobs of a FF update by a worker script at once (a Kodi start costs nothing): the catalog and the old settings of the
    # native providers before a search or the configuration waits for them, then the windows of widgets (a change of the skin,
    # the language...: `windows_check()` below); the service imports neither the providers nor a window
    if ff_updated:
        cyclic_call((1, 0), start_update_worker)

    # the windows of widgets prepared in the XML cache for the environment of now (by the worker): after the start of Kodi, then at a
    # change of the skin, its colours, the language (a window of FF shown requests them too, but the first one is mostly the sources)
    cyclic_call((CONST_REF.tune.gui.xml_prepare_delay, CONST_REF.tune.gui.xml_check_interval), windows_check(updated=ff_updated))

    # the ignored `local.py`: the window once the home screen is up (unless a FF folder showed it already)
    from cdefs import local_error
    if local_error is not None:
        cyclic_call((1, 0), show_local_error_window)

    # monitor started, notify all (FF plugin)
    monitor.rpc.notify('ServiceUp', id=KodiRpc.BROADCAST)


def run() -> None:
    """Run service module; changed sources (`const.debug.autoreload`) or a restart asked: a fresh service started at its end."""
    from ..info import script_aborted
    if script_aborted():  # Kodi exit before the service monitor existed: Kodi notifies the existing monitors only
        stop(join=False)  # nothing runs yet, but the end releases the Kodi objects (the monitor and its player)
        raise KodiExit()
    from ..ff.threads import inherit_thread_scopes, watch_sockets
    from ..sdk.net import share_tls_contexts
    # the stop mechanism of the plugin: pool workers share the scope of their work, a stopped scope cuts its sockets,
    # Kodi exit cuts all of them (abort_network() of KodiMonitor)
    inherit_thread_scopes()
    watch_sockets()
    share_tls_contexts()  # one TLS context of the interpreter, not one with the CA bundle loaded for every connection
    base.service_scope = CancelScope()
    if const.debug.autoreload:
        from .reload import ReloadMonitor  # noqa: F811
        monitor.reload_monitor = ReloadMonitor()

    try:
        # Trakt sync thread.
        works.account_sync = AccountSync()

        if START_SYNC_ON_START:
            # Library service (adding items in the background). Start only if enabled. Settings are monitored.
            if settings.getBool('enable_library') and works.library is None:
                from .library import Library  # noqa: F811
                works.library = Library()
                works.library.start()

        proxy.start()
        if works.web:
            works.web.start()
    except Exception:
        fflog_exc()
    try:
        fflog('[FF] ### Service start-up')
        startup()
        fflog('[FF] ### Service monitor run')
        monitor.run()
    finally:
        fflog('[FF] ### Service going to stop')
        try:
            stop(join=False)
        except Exception:
            fflog_exc()
    if monitor.restart:  # the works stopped: nothing asks for the disabled add-on
        from .reload import restart_service
        fflog('[FF] ### Service restart')
        restart_service()


def stop(*, join: bool = True) -> None:
    """Stop all services."""
    from ..ff.kotools import destroy_xmonitor
    base.service_scope.set()  # the cyclic works end now, not after their current call (Kodi waits for them on exit)
    monitor.working = False
    # fflog('[FF] stopping::1 (providers)')
    if works.providers is not None:
        works.providers.stop()
        works.providers = None
    # fflog('[FF] stopping::2 (account_sync)')
    if works.account_sync:
        works.account_sync.stop()
    # fflog('[FF] stopping::4 (library)')
    if works.library is not None:
        works.library.stop()
        works.library = None
    # works.library_jobs feeds the separate "library-batches" thread (process_library_batches) -
    # a different queue than Library's own, and library.stop() above doesn't touch it. Without
    # this, that thread blocks forever on works.library_jobs.get() and never stops.
    works.library_jobs.shutdown(immediate=True)
    # fflog('[FF] stopping::5 (web)')
    if works.web:
        works.web.stop()
        works.web = None
    # fflog('[FF] stopping::6 (http)')
    proxy.stop()
    # fflog('[FF] stopping::7 (join threads)')
    if join:
        join_threads()
    works.reset()
    # fflog('[FF] stopping::8 (monitor)')
    destroy_xmonitor()
    fflog('[FF] ### Service stopped')
    from threading import enumerate as thread_enumerate, current_thread
    fflog(f'Active service threads: {thread_enumerate()}')  # debug
    # a thread not a daemon keeps the interpreter (Kodi kills it after 5 s, a restart leaves it): where it stands
    frames = sys._current_frames()
    for thread in thread_enumerate():
        if thread is not current_thread() and not thread.daemon and (frame := frames.get(thread.ident or 0)) is not None:
            fflog(f'[FF] the thread {thread.name} still runs:\n{"".join(format_stack(frame))}')


if const.tune.service.startup_delay:
    fflog(f'[SERVICE] ----- start delay ({const.tune.service.startup_delay:.1f}s) -----')
    _start_monitor = xbmc.Monitor()
    _start_monitor.waitForAbort(const.tune.service.startup_delay)
    del _start_monitor

fflog('[SERVICE] ----- start service -----')

# Trakt.tv withou auto-auth, to avoid dialog popups on kodi start.
TraktApi.AUTO_AUTH = False  # no auth dialog in the service (clients of all accounts)

# Uruchamianie serwera HTTP
proxy = works.http = HttpProxy(works=works)
# Uruchamianie serwera web
works.web = WebServer(works=works)

# Główny monitor
monitor = FFMonitor()
works.state.monitor = monitor  # istniejący monitor, aby nie tworzyć go za każdym razem
