"""
FanFilm Add-on

Providers' jobs in the service. Any job of any provider should be added here.

MIT
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from .base import cyclic_call
from ..sources.natives import provider_searched, provider_value
from const import const, CONST_REF
if TYPE_CHECKING:
    from .base import Work


class ServiceProviders:
    """Providers' (sources) jobs in the service."""

    def __init__(self) -> None:
        #: Running providers' works by name.
        self.works: dict[str, Work] = {}
        #: Last seen netmirror.otp_code value - see on_settings_changed()
        self._last_otp_code: str = provider_value('netmirror', 'otp_code').strip()

    def start(self) -> None:
        """Start all providers' jobs."""
        # --- netmirror ---
        # Keep the netmirror usertoken warm in the background (a no-op unless it's
        # close to its ~20h TTL, or the provider is disabled) - first check 1s after
        # startup, so its worst-case ~35-38s ad-verification refresh (see ensure_usertoken_fresh)
        # is done within ~40s of the service coming up; then every `token_autorefresh_hours`.
        # Started regardless of `provider.netmirror`, so enabling the provider later works too.
        def netmirror_interval() -> float:
            """Return the interval of the token refresh (0: switched off for now)."""
            return (const.sources.netmirror.token_autorefresh_hours or 0) * 3600

        if work := cyclic_call((1, netmirror_interval), self.netmirror_refresh_user_token):
            self.works['netmirror'] = work
        # --- provider add-ons ---
        # The workers of the provider add-ons serving the chosen add-ons, started after a while (Kodi has its own start to
        # do, the first search then finds them warm) and started again when one ended (a change of its add-on: a clean reload).
        xp = CONST_REF.sources.xproviders
        if work := cyclic_call((xp.start_delay, xp.watch_interval), self.keep_provider_workers):
            self.works['xproviders'] = work

    def stop(self) -> None:
        """Stop all providers' jobs."""
        for work in self.works.values():
            work.stop()
        self.works.clear()

    def on_settings_changed(self) -> None:
        """React to settings changes that affect providers' jobs."""
        # --- netmirror ---
        # Also catch the code typed straight into Kodi's settings GUI, not just
        # the one pushed by the tampermonkey script through /cookies. Kodi fires
        # this AFTER the value is already saved, so there's no "before" to read
        # here - compare against what we remembered from last time instead.
        # Remembered even if the provider is disabled, so a code set meanwhile isn't redeemed (stale) later.
        new_otp_code = provider_value('netmirror', 'otp_code').strip()
        otp_code_changed = bool(new_otp_code) and new_otp_code != self._last_otp_code
        self._last_otp_code = new_otp_code
        if provider_searched('netmirror'):
            if otp_code_changed:
                from ..sources.en.netmirror import source as NetMirrorSource
                NetMirrorSource.prefetch_otp_token()
            # Don't make someone who just flipped the provider on wait for the next
            # cyclic tick (see netmirror_refresh_user_token) - kick the check right away.
            # Cheap and idempotent (a no-op unless the cached token is missing or near expiry),
            # so calling it on every settings change (not just this one) is fine.
            if const.sources.netmirror.token_autorefresh_hours:
                from ..sources.en.netmirror import source as NetMirrorSource
                NetMirrorSource.ensure_usertoken_fresh()

    def keep_provider_workers(self) -> None:
        """Start the workers of the provider add-ons which should run and do not."""
        from ..ff.xproviders import keep_workers
        keep_workers()

    def netmirror_refresh_user_token(self) -> None:
        """Check the netmirror usertoken's age and refresh it in the background if needed (no-op if provider is disabled)."""
        if not const.sources.netmirror.token_autorefresh_hours:  # switched off (its first check too)
            return
        from ..sources.en.netmirror import source as NetMirrorSource
        NetMirrorSource.ensure_usertoken_fresh()
