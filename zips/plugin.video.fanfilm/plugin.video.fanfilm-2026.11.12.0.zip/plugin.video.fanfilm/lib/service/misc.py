
from __future__ import annotations
from typing import Optional, Union, Any, List, Dict, Iterable, Iterator, Sequence, Mapping, TYPE_CHECKING
from typing_extensions import TypedDict, TypeAlias, Literal
import re
import json
from itertools import takewhile
from pathlib import Path
from time import monotonic
from datetime import datetime, date as dt_date, time as dt_time
from attrs import define, frozen, field, Factory, asdict, evolve
from xbmc import Monitor
from ..defs import MediaRef, VideoIds
from ..ff.calendar import utc_timestamp
from ..ff.url import URL
from ..ff.item import FFItem
from ..ff.threads import Thread
from ..ff.kotools import xsleep
from ..ff.kodidb import video_db
from ..ff.threads import Condition, MAX_TIMESTAMP
# from ..ff.control import plugin_url
from ..ff.kodidb import KodiVideoInfo, LibraryMedia
from ..ff.db.playback import MediaPlayInfo, PlayState, ChangeAction, progress_changed, apply_local
from ..ff.logs import fflog, fflog_exc
from const import const

if TYPE_CHECKING:
    from ..ff.types import JsonData


#: Name of service, source for auto library add.
LibraryAutoAddSource: TypeAlias = Literal['lists']


def _parse_url(value) -> URL:
    if isinstance(value, str):
        return URL(value)
    return value


def serialize(value, *, recurse: bool = True) -> JsonData | list[Any]:
    """Serialize value to JSON compatible format."""
    if isinstance(value, (str, URL, Path)):
        return str(value)
    if serializer := getattr(value, '__to_json__', None):
        return serializer()
    if getattr(type(value), '__attrs_attrs__', None) is not None:  # define / frozen
        value = asdict(value)
    if recurse:
        if isinstance(value, Mapping):
            return {k: serialize(v, recurse=True) for k, v in value.items()}
        if isinstance(value, Sequence):
            return [serialize(v, recurse=True) for v in value]
    return value


def _serialize(inst, field, value):
    if isinstance(value, (URL, Path)):
        return str(value)
    if serialize := getattr(value, '__to_json__', None):
        return serialize()
    if getattr(type(value), '__attrs_attrs__', None) is not None:  # define / frozen
        return asdict(value)
    return value


@define
class VolatileFfid:
    """Volatile FFID, defined for single kodi session only."""

    _refs: Dict[int, MediaRef] = Factory(dict)
    _ids: Dict[MediaRef, int] = Factory(dict)
    _generator: Iterator[int] = field(init=False, factory=VideoIds.VOLATILE.__iter__)

    def next_ffid(self) -> int:
        """Get next volatile ffid."""
        try:
            return next(self._generator)
        except StopIteration:
            self._generator = iter(VideoIds.VOLATILE)
        return next(self._generator)

    def register(self, ref: MediaRef) -> int:
        """Register new value."""
        if ffid := self._ids.get(ref):
            return ffid
        ffid = self.next_ffid()
        self._ids[ref] = ffid
        self._refs[ffid] = ref
        return ffid

    def get(self, ffid: int) -> Optional[MediaRef]:
        """Return ref by `ffid` or None if not exists."""
        return self._refs.get(ffid)


@frozen(kw_only=True)
class FolderEntry:
    #: Entry label.
    label: str
    #: Media Reference if any. If not MediaRef('', 0) is used.
    ref: MediaRef = field(factory=lambda: MediaRef('', 0))
    #: TMDB ID or zero.
    tmdb: int = 0
    #: IMDB ID or empty.
    imdb: str = ''
    #: Kodi playback data if any.
    kodi_data: Optional[KodiVideoInfo] = None


@define
class FolderHistoryItem:
    """One item if the folder history."""

    #: Folder URL.
    url: URL = field(converter=_parse_url)
    #: Folder enter UTC timestamp.
    enter_timestamp: float = 0
    #: Folder exit UTC timestamp.
    exit_timestamp: float = 0

    def __to_json__(self) -> JsonData:
        """Serialize object to JSON."""
        return asdict(self, value_serializer=_serialize)

    @classmethod
    def __from_json__(cls, data: 'JsonData') -> FolderHistoryItem:
        """Create object from JSON."""
        return FolderHistoryItem(**data)


@define(kw_only=True)
class TreeFolderInfo:
    """Folder info in plugin tree."""

    url: str
    label: str = ''
    parent: Optional[str] = None


@define(kw_only=True)
class PluginRequestInfo:
    """FF plugin URL enter info (folder, videos, scripts etc.)."""
    #: True, if refresh is detected (reloaded, stop playing, cancel playing, (un)watched set...).
    refresh: bool = False
    #: True, folder is locked (refresh is detected on stop playing).
    locked: bool = False
    #: True, if kodi folder is scaned (tree scan is detected).
    scan: bool = False
    #: True, if kodi folder tree scan is just detected.
    scan_started: bool = False
    #: True, if kodi folder tree scan is just stoped (enter to `scan_url`, folder before scan started)
    scan_finished: bool = False
    #: Keep URL, when scanning is detected (folder before scan started).
    scan_url: URL = field(default=URL(''), converter=_parse_url)
    #: Main media URL (e.g. tvshow).
    media_url: URL = field(default=URL(''), converter=_parse_url)
    #: Folder path of a show / season the FF menu lets Kodi (un)mark natively (`announce_mark()`): the next enter, if into it, is its scan.
    mark_path: str = ''
    #: Last folder info (not video or else).
    folder_url: URL = field(default=URL(''), converter=_parse_url)
    #: Folder history.
    history: List[FolderHistoryItem] = Factory(list)
    #: Current (last) folder content. Set on "exit".
    content: Optional[Sequence[FFItem]] = None
    #: Current (last) folder Kodi DB plays of its movies / episodes. Set on "exit".
    current_plays: Dict[MediaRef, KodiVideoInfo] = Factory(dict)
    #: Kodi DB plays of the folder tree before Kodi changes them (movies, episodes; the episodes of the shows / seasons):
    #: set on "exit" of a folder outside the tree, a listing inside it (Kodi lists the tree of an item to (un)mark it, see
    #: `_mark_run()`; its last listing may be read after the change, Kodi DB has no rows of unplayed episodes) keeps it.
    tree_plays: Dict[MediaRef, KodiVideoInfo] = Factory(dict)
    #: Path of the folder of `tree_plays` (the root of the tree it covers).
    plays_root: str = ''
    #: Folder info in plugin tree folders. [url] -> TreeFolderInfo.
    folder_tree: Dict[str, TreeFolderInfo] = field(factory=dict)
    #: Parent folder info, if any.
    parent_path: List[TreeFolderInfo] = field(factory=list)

    @property
    def url(self) -> URL:
        """Current folder URL (first item from the history)."""
        if not self.history:
            return URL('')
        return self.history[0].url

    def __to_json__(self) -> JsonData:
        """Serialize object to JSON."""
        data = asdict(self, recurse=True, value_serializer=_serialize,
                      # skip `content`, `current_plays` and all private attributes
                      # filter=lambda attr, value: attr.name not in ('current_plays', 'folder_tree'),
                      filter=lambda attr, value: attr.name not in ('content', 'current_plays', 'tree_plays', 'plays_root', 'folder_tree'),
                      )
        return data

    @classmethod
    def __from_json__(cls, data: 'JsonData') -> PluginRequestInfo:
        """Create object from JSON."""
        data = dict(data)
        data['history'] = [FolderHistoryItem.__from_json__(it) for it in data['history']]
        if (content := data.get('content')) is not None:
            data['content'] = [FFItem.__from_json__(it) for it in content]
        data['parent_path'] = [TreeFolderInfo(**parent) for parent in data.get('parent_path') or []]
        return PluginRequestInfo(**data)

    def enter(self, url: Union[URL, str], *, timestamp: Optional[float] = None) -> None:
        """Enter into folder, add new URL."""
        if isinstance(url, str):
            url = URL(url)
        if timestamp is None:
            timestamp = utc_timestamp()
        if self.history and not self.history[0].exit_timestamp:
            self.history[0].exit_timestamp = timestamp
        self.history.insert(0, FolderHistoryItem(url, enter_timestamp=timestamp))
        if len(self.history) > 10:
            self.history = self.history[:10]
        # simple refresh
        try:
            fflog(f'################## refresh? {self.history[0].url in (self.history[1].url, self.scan_url, self.folder_url)}: #{len(self.history)}, {self.history[0].url!r} in {(self.history[1].url, self.scan_url, self.folder_url)}')
        except IndexError:
            fflog(f'################## refresh? ?: #{len(self.history)}, {(self.scan_url, self.folder_url)}')
        self.locked = False
        marked = self._mark_run()  # the folder of an item Kodi has just (un)marked natively, listed again now
        self.refresh = len(self.history) >= 2 and self.history[0].url in (self.history[1].url, self.scan_url, self.folder_url) or marked is not None
        if self.refresh:
            from xbmc import getInfoLabel
            from ..ff.db import state
            ref = item = None

            # def find_item_by_path() -> Optional[FFItem]:
            #     if (path := getInfoLabel('ListItem.FilenameAndPath')).startswith(plugin_url):
            #         for it in self.content or ():
            #             if it.getPath() == path:
            #                 return it
            #     fflog(f'[SERVICE] CM PATH {path!r} in \n' + '\n'.join(f'    - {it.getPath()!r}' for it in self.content or ()))
            #     return None

            fflog(f"[SERVICE] STATE = {state.get('state', module='player')}")
            # playing is stopping?
            if (st := state.get('state', module='player')) in ('playing', 'played', 'stopping'):
                fflog(f'Refresh {self.history[0].url} in state {st}')
                self.locked = True
            # CM on FFITem, ex. set (un)watched
            # elif (ref := MediaRef.from_slash_string(getInfoLabel('ListItem.UniqueID(ffref)'))) and (item := find_item_by_path()):
            # (un)watched in Kodi (natively or by the FF menu): sent to the accounts with another row state
            elif (ref := MediaRef.from_slash_string(getInfoLabel('ListItem.UniqueID(ffref)'))) and ref.is_container:
                if marked is not None:
                    self._container_marked(ref, marked)
            elif ref:
                vi0 = self.current_plays.get(ref)
                vi1 = video_db.get_play(ref)
                fi0 = next(iter(item for item in self.content or () if item.ref == ref), None)
                pr0 = fi0 and fi0.progress
                fflog(f'Refresh {self.history[0].url} with ref {ref:a}\n   {pr0=}\n   {vi0=}\n   {vi1=}')
                if vi1 is not None:
                    if no_vi0 := vi0 is None:
                        vi0 = KodiVideoInfo(ref=ref)
                        fflog(f'Restore vi0 for ref {ref:a}\n ~ {vi0=}')
                    # if not current progress... all action (watched, unwatched, reset_progress) reset the progress
                    if not vi1.time_s:
                        cnt0, cnt1 = vi0.play_count or 0, vi1.play_count or 0
                        # increment by one – set as watched
                        if cnt0 + 1 == cnt1 or (no_vi0 and cnt1 > 0):
                            update_playback_db_by_kodi_info(vi1, action='watched')
                        # decrement to zero and now has no watched time – set as unwatched
                        elif (cnt0 > 0 or (pr0 and pr0.play_count > 0)) and not vi1.played_at and cnt1 == 0:
                            update_playback_db_by_kodi_info(vi1, action='unwatched')
                        # remove progress - reset resume point
                        elif (vi0.time_s or (pr0 and pr0.progress)) and cnt0 >= cnt1:
                            update_playback_db_by_kodi_info(vi1, action='reset_progress')
            fflog(f'[SERVICE] CM PATH {ref=}, {item=}')
            fflog(f'  --------->   {self.current_plays}')
                # self.locked = True
        # interval between folder exit and enter into next one
        interval = const.folder.max_scan_step_interval
        # scanning by kodi, detected when history is (from newwst):
        #   - [0] SHOW/2
        #   - [1] SHOW/1
        #   - [2] SHOW
        #   - [3] some list of shows
        if len(self.history) >= 4:
            hist = self.history
            path0 = self.history[0].url.path
            path1 = self.history[1].url.path
            path2 = self.history[2].url.path
            path3 = self.history[3].url.path
            if (not re.fullmatch(r'/show/\d+/?.*', path3)                                 # shows (no show / season view)
                    and re.fullmatch(r'/show/\d+', path2)                                 # show view
                    and path1 == f'{path2}/1'                                             # first season
                    and path0 == f'{path2}/2'                                             # second season
                    and hist[2].exit_timestamp - hist[1].enter_timestamp <= interval      # fast enter into first season
                    and hist[1].exit_timestamp - hist[0].enter_timestamp <= interval      # fast enter into second season
               ):
                self.scan_started = True
                self.scan = True
                self.scan_url = self.history[3].url  # folder before scan started
                self.media_url = self.history[2].url  # scanned folder
        # scan is stopped / aborted if more time to enter into current folder
        if self.scan and self.history[1].exit_timestamp - self.history[0].enter_timestamp > interval:
            self.scan = False
        if self.scan and self.refresh:
            self.scan = False
            self.scan_finished = True
        # the scan of a show / season announced by the FF menu: Kodi lists its folder first (all aired episodes at once, see
        # `bypass_scanning()`), then the current folder again; any other folder ends the announcement
        announced, self.mark_path = self.mark_path, ''
        if announced and url.path == announced:
            self.scan = self.scan_started = True
            self.scan_url = self.folder_url  # folder before scan started (the menu call is in the history too)
            self.media_url = url  # scanned folder
        # Update folder tree with current folder info.
        if self.content:
            parent_url = str(self.folder_url)
            for item in self.content:
                if item.url:
                    self.folder_tree[item.url] = TreeFolderInfo(url=item.url, label=item.label, parent=parent_url)
        self.parent_path = []
        parent_url = str(url)
        for _ in range(10):
            if not (parent := self.folder_tree.get(parent_url)):
                break
            self.parent_path.insert(0, parent)
            if not (parent_url := parent.parent):
                break

    def exit(self, *, folder: Optional[Sequence[FFItem]] = None, focus: int = -1, timestamp: Optional[float] = None) -> None:
        """Exit from folder."""
        try:
            is_folder = folder is not None
            if self.history:
                if timestamp is None:
                    timestamp = utc_timestamp()
                self.history[0].exit_timestamp = timestamp
                if is_folder:
                    self.folder_url = self.history[0].url
            self.content = folder
            self.scan_started = False
            self.scan_finished = False
            fflog(f'EXIT FOLDER {-1 if folder is None else len(folder)}')
            if folder is not None:
                fflog(f'EXIT FOLDER refs: { {item.ref for item in folder} }')
                plays = {pb.ref: pb for pb in video_db.get_plays_for(folder)}  # movies, episodes; the episodes of the shows / seasons
                fflog(f'EXIT FOLDER PLAY DB: {list(plays.values())}')
                refs = {item.ref for item in folder}
                self.current_plays = {ref: pb for ref, pb in plays.items() if ref in refs}
                path = self.history[0].url.path if self.history else ''
                if not (self.plays_root and path.startswith(f'{self.plays_root}/')):  # inside the tree: its plays before kept
                    self.tree_plays, self.plays_root = plays, path
            if focus >= 0:
                Thread(target=self.focus_item, kwargs={'index': focus}).start()
        except Exception:
            fflog_exc()

    def announce_mark(self, path: str) -> None:
        """The FF menu lets Kodi (un)mark the focused show / season natively, Kodi lists its folder `path` next (see `enter()`)."""
        self.mark_path = path

    def _mark_run(self) -> Optional[URL]:
        """
        Return the URL of the folder of an item Kodi has just (un)marked natively, None if not: Kodi lists the folder of the
        item and its subfolders (each step quickly, `const.folder.max_scan_step_interval`), changes the play counts and lists
        the current folder (`history[0]`) again; the scan of a show (`bypass_scanning()`) may be longer than the history.
        """
        hist = self.history
        if self.scan and len(hist) >= 2 and hist[0].url == self.scan_url:
            return self.media_url
        interval = const.folder.max_scan_step_interval
        for k in range(2, len(hist)):
            if hist[k].url != hist[0].url:
                continue
            run, root = hist[1:k], hist[k - 1].url.path
            if (root != hist[0].url.path and all(it.url.path == root or it.url.path.startswith(f'{root}/') for it in run)
                    and all(new.enter_timestamp - old.exit_timestamp <= interval for new, old in zip(run, run[1:]))):
                return hist[k - 1].url
            return None
        return None

    def _container_marked(self, ref: MediaRef, root: URL) -> None:
        """
        Send a show / season (un)marked natively in Kodi (Kodi listed its folder `root` and changed its episodes in Kodi
        video DB) to the accounts with another state: a change of its episodes against the plays before (`tree_plays`)
        and all its aired episodes in that state now (else it is not a mark, e.g. one episode played). A season of an
        episode group (`root` with `episode_group`, its ref is the real season of the same number) goes episode by episode.
        """
        from ..ff.info import ffinfo
        if root.path != f'/{ref:a}' or not (root.path == self.plays_root or root.path.startswith(f'{self.plays_root}/')):
            return  # not the folder of the item, or the plays before are not of it
        group = root.args.get('episode_group') or None
        if not (episodes := ffinfo.aired_episode_refs(ref, episode_group=group)):
            return
        after = {pb.ref: pb for pb in video_db.get_plays(episodes)}
        watched_before = {ep for ep in episodes if (pb := self.tree_plays.get(ep)) and pb.play_count}
        watched_after = {ep for ep in episodes if (pb := after.get(ep)) and pb.play_count}
        # unmarked by Kodi without a row before (watched on another account): a new row without a play (a playback has
        # its last play time, a stopped one its resume point too; its play URL breaks the run of `_mark_run()`)
        unmarked = {ep for ep in episodes if ep not in self.tree_plays and (pb := after.get(ep)) is not None
                    and not pb.play_count and not pb.played_at and not pb.time_s}
        if not (changed := (watched_before ^ watched_after) | unmarked):
            return  # no change in Kodi video DB (an unmark of rows unwatched in Kodi already is not seen)
        if len(watched_after) == len(episodes) and watched_after > watched_before:
            action: ChangeAction = 'watched'
        elif not watched_after:
            action = 'unwatched'
        else:
            return  # not all aired episodes in one state: not a mark of the container
        fflog(f'[SERVICE] {ref:a} {action} in Kodi ({len(changed)} of {len(episodes)} episodes changed, {group=})')
        if group:
            for ep in episodes:
                update_playback_db_by_kodi_info(after.get(ep) or KodiVideoInfo(ref=ep), action=action)
        else:
            update_playback_db_by_kodi_info(KodiVideoInfo(ref=ref), action=action, episodes=episodes)

    def focus_item(self, index: int) -> None:
        """Try to focus item on current list."""
        if index >= 0:
            xsleep(const.tune.service.focus_item_delay)
            import xbmcgui
            from ..ff.control import execute
            window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
            container_id = window.getFocusId()
            execute(f'SetFocus({container_id},{index},absolute)')


@frozen(kw_only=True)
class StateVar:
    module: str
    key: str
    value: Any
    type: str
    updated_at: float


class StateVarDict(TypedDict):
    module: str
    key: str
    value: Any
    type: str
    updated_at: float


@define(kw_only=True)
class FFState:
    """General FF state, virtual DB."""

    state: Dict[str, Dict[str, StateVar]] = field(factory=dict)
    updated: Condition = field(factory=Condition)
    monitor: Optional[Monitor] = None

    def module(self, *, module: str) -> Dict[str, StateVar]:
        with self.updated:
            return self.state.get(module, {})

    def get(self, *, module: str, key: str, default: Optional[StateVar] = None) -> Optional[StateVar]:
        with self.updated:
            return self.state.get(module, {}).get(key, default)

    def get_all(self, *, module: str) -> Sequence[StateVar]:
        with self.updated:
            return tuple(self.state.get(module, {}).values())

    def set_variable(self, *, module: str, key: str, value: Any, type: str, updated_at: float) -> None:
        with self.updated:
            mod = self.state.setdefault(module, {})
            mod[key] = StateVar(module=module, key=key, value=value, type=type, updated_at=updated_at)
            self._emit()

    def set(self, var: Union[StateVar, StateVarDict], /) -> None:
        with self.updated:
            if not isinstance(var, StateVar):
                var = StateVar(**var)
            mod = self.state.setdefault(var.module, {})
            mod[var.key] = var
            self._emit()

    def multi_set(self, variables: Iterable[Union[StateVar, StateVarDict]], /) -> None:
        with self.updated:
            for var in variables:
                if not isinstance(var, StateVar):
                    var = StateVar(**var)
                mod = self.state.setdefault(var.module, {})
                mod[var.key] = var
            self._emit()

    def delete(self, *, module: str, key: str) -> Optional[StateVar]:
        with self.updated:
            res = self.state.get(module, {}).pop(key, None)
            if res is not None:
                self._emit()

    def delete_like(self, *, module: str, key: str) -> bool:
        def repl(mch: re.Match) -> str:
            return '.*' if mch.group() == '%' else '%'
        rx = re.compile(re.sub(r'(?:\\\\)?%', repl, re.escape(key)))
        with self.updated:
            if mod := self.state.get(module):
                prev_len = len(mod)
                self.state[module] = mod = {k: v for k, v in mod.items() if not rx.fullmatch(k)}
                if prev_len != len(mod):
                    self._emit()
                    return True
            return False

    def delete_all(self, *, module: str) -> bool:
        with self.updated:
            res = self.state.pop(module, None)
            if res is not None:
                self._emit()
            return bool(res)

    def wait_for(self, *, module: str, key: str, value: Any, timeout: Optional[float] = None) -> bool:
        def hit():
            var = self.state.get(module, {}).get(key)
            return var.value == value if var else False

        if hit():
            return True
        monitor = Monitor() if self.monitor is None else self.monitor
        end = MAX_TIMESTAMP if timeout is None else monotonic() + timeout
        with self.updated:
            while True:
                if (delta := end - monotonic()) <= 0 or monitor.abortRequested():
                    return False
                if self.updated.wait_for(hit, min(delta, const.tune.event_step)):
                    return True

    def _emit(self):
        self.updated.notify_all()


@frozen
class SkipEntry:
    """An own change of a library item: until when it is expected, the play count written (None: not written)."""

    #: Deadline (monotonic seconds).
    deadline: float
    #: The play count written (Kodi announces it), None if the change did not write it.
    playcount: Optional[int] = None


@define
class SkipUpdate:
    """
    Own changes of Kodi library to skip in its notifications (`VideoLibrary.OnUpdate`): the library media, each until its deadline.
    A notification with another play count than the written one is a change of the user (it is not skipped).
    """

    #: Library media (Kodi type, DBID) -> own change.
    media: Dict[LibraryMedia, SkipEntry] = Factory(dict)

    def add(self, media: LibraryMedia, *, playcount: Optional[int] = None, ttl: float = 10) -> None:
        """
        Add an own change of `media` (Kodi announces it in a moment), the expired ones are dropped from the oldest (the dict keeps
        the order of the changes; one alignment adds thousands of them).
        """
        now = monotonic()
        for key in [key for key, _ in takewhile(lambda item: item[1].deadline <= now, self.media.items())]:
            del self.media[key]
        self.media.pop(media, None)  # a new change of the media is the latest one
        self.media[media] = SkipEntry(deadline=now + ttl, playcount=playcount)

    def skip(self, media: LibraryMedia, *, playcount: Optional[int] = None) -> bool:
        """Return True if a change of `media` (the announced `playcount`, None if not announced) is an own one."""
        entry = self.media.get(media)
        if entry is None or entry.deadline <= monotonic():
            return False
        return playcount is None or playcount == entry.playcount  # no play count: the resume point / other details


def _db_time(timestamp: int) -> str:
    """Return the local time of Kodi video DB (`lastplayed`) of the unix `timestamp`."""
    return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')


def library_changes(kodi: KodiVideoInfo, pb: MediaPlayInfo | None, *, watched: bool, progress: bool) -> JsonData:
    """
    Return the changes (`VideoLibrary.Set*Details` params) of the library item `kodi` to the merged FF state `pb` (None: not
    watched, not started): the play count (a watched item keeps its own count) and the last play if `watched`, the resume
    point if `progress` (a percent of the merged state placed in the duration of the item, none if it is unknown). A resume
    point of the TT430 placeholder is not the state of the item (FF does not read it): it is not removed, its duration is not
    used (`repair_placeholder_resumes()` repairs it).
    """
    params: JsonData = {}
    play_count = (pb.play_count or 0) if pb else 0
    if watched and bool(kodi.play_count) != bool(play_count):
        params['playcount'] = play_count
        if pb and play_count and pb.last_watched_at:
            params['lastplayed'] = _db_time(pb.last_watched_at)
    if progress:
        percent = (pb.progress or 0) if pb else 0  # the merged state has no resume point older than the watch
        if kodi.placeholder_resume:
            changed = bool(percent)  # kept unless FF has a resume point
        else:
            changed = abs(percent - ((kodi.percent or 0) if kodi.has_progress else 0)) > const.media.progress.tolerance.resume
        if changed:
            if not percent:
                params['resume'] = {'position': 0, 'total': 0}
            elif total := (0 if kodi.placeholder_resume else kodi.total_s) or (pb.duration if pb else 0):
                params['resume'] = {'position': round(total * percent / 100), 'total': total}
                if pb and pb.paused_at and 'lastplayed' not in params:
                    params['lastplayed'] = _db_time(pb.paused_at)
    return params


def kodi_state(kodi: KodiVideoInfo) -> PlayState:
    """Return the state of the library item `kodi` the alignment compares: watched and the resume point (a placeholder one is none)."""
    return PlayState(watched=bool(kodi.play_count), progress=0 if kodi.placeholder_resume else (kodi.percent or 0))


def _read_parts(state: PlayState, *, watched: bool, progress: bool) -> PlayState:
    """Return the `state` with only the parts the local Kodi account reads."""
    return PlayState(watched=watched and state.watched, progress=state.progress if progress else 0)


def _kodi_changes(new: PlayState, old: PlayState, known: PlayState) -> list[ChangeAction]:
    """
    Return the changes of the user from the `old` state of a library item to the `new` one (the read parts, `_read_parts()`)
    the accounts do not have yet (their merged state `known`): none if the same; a watch ends the resume point, an unwatch
    too (a new one is a pause after it).
    """
    actions: list[ChangeAction] = []
    if new.watched != old.watched and new.watched != known.watched:
        actions.append('watched' if new.watched else 'unwatched')
    if (not evolve(new, watched=old.watched).same(old) and not evolve(new, watched=known.watched).same(known)
            and actions != ['watched'] and (new.progress or not actions)):
        actions.append('pause' if new.progress else 'reset_progress')
    return actions


def align_library(skip: SkipUpdate) -> int:
    """
    Align the FF STRM files of Kodi library with the merged FF progress (a mark in FF, an account sync, a play from an FF
    folder): an item of another state gets the play count, the last play and the resume point (only the parts the local Kodi
    account reads; nothing if it reads none, its library is its own then). Kodi announces the changes, the service skips
    them (`skip`). An item changed in Kodi since the last alignment (its snapshot in the library DB) is a change of the user:
    Kodi keeps it (also against a change of FF meanwhile) and the accounts get what they do not have yet (a change the FF
    service did not see: a shared MySQL library changed by another device, the service stopped). Return the number of the
    changed items.
    """
    from ..ff.info import ffinfo
    from ..ff.db import library as library_db
    parts, local = ffinfo.progress_accounts()
    if not local or not (plays := video_db.library_plays()):
        return 0
    watched, progress = parts[local[0]]

    def read(state: PlayState) -> PlayState:
        """Return the parts of the `state` the local Kodi account reads."""
        return _read_parts(state, watched=watched, progress=progress)

    merged = ffinfo.playback_info({kodi.ref for kodi, _ in plays})  # only the media of the library, not the whole history of accounts
    snapshots = library_db.snapshots()
    states = {kodi.fname: kodi_state(kodi) for kodi, _ in plays}
    # changed in Kodi since the last alignment: what the other accounts know of them (a few media, read only for them)
    changed = {kodi.ref for kodi, _ in plays if (old := snapshots.get(kodi.fname)) is not None and not read(states[kodi.fname]).same(read(old))}
    known = ffinfo.playback_info(changed, kodi=False) if changed else {}
    written: list[KodiVideoInfo] = []
    for kodi, media in plays:
        if kodi.ref in changed:
            pb = known.get(kodi.ref)
            actions = _kodi_changes(read(states[kodi.fname]), read(snapshots[kodi.fname]), read(pb.play_state() if pb else PlayState()))
            if actions:
                fflog(f'[LIBRARY] {kodi.ref} changed in Kodi, not known to the accounts: {actions}')
            for action in actions:
                update_playback_db_by_kodi_info(kodi, action=action, at=kodi.played_at if action in ('watched', 'pause') else None)
        elif params := library_changes(kodi, merged.get(kodi.ref), watched=watched, progress=progress):
            kodi_type, dbid = media
            fflog(f'[LIBRARY] align {kodi.ref} ({kodi_type} {dbid}): {params}')
            skip.add(media, playcount=params.get('playcount'))
            try:
                video_db.rpc(f'VideoLibrary.Set{kodi_type.capitalize()}Details', params={f'{kodi_type}id': dbid, **params})
            except Exception:
                fflog_exc()
            else:
                written.append(kodi)  # its snapshot: what Kodi keeps, read below (a write Kodi ignored is no change of the user later)
    states.update((kodi.fname, kodi_state(kodi)) for kodi in video_db.reread_plays(written))
    if new := {path: state for path, state in states.items() if (old := snapshots.get(path)) is None or not state.same(old)}:
        library_db.store_snapshots(new)
    return len(written)


def repair_placeholder_resumes(skip: SkipUpdate) -> int:
    """
    Repair the resume points of FF plays (play URLs, STRM files of the library) Kodi wrote with the duration of the TT430
    placeholder (a play canceled with a resume point, before the play state was restored): the point is the real one (the
    placeholder started there), the duration is the one of the media (FF info); a point past the end is removed; a media
    without a known duration keeps it (FF skips it, `KodiVideoInfo.placeholder_resume`). Kodi announces the changes of the
    library, the service skips them (`skip`). Return the number of the repaired files.
    """
    from ..ff.info import ffinfo, Progress
    if not (plays := video_db.placeholder_plays()):
        return 0
    items = ffinfo.get_items([kodi.ref for kodi, _ in plays], progress=Progress.NO, keep_missing=True, user_ratings=False)
    count = 0
    for (kodi, media), item in zip(plays, items):
        if item is None or not (duration := item.duration):
            fflog(f'[KodiDB] placeholder resume point of {kodi.ref} ({kodi.fname}) kept: no duration of the media')
            continue
        resume = {'position': kodi.time_s, 'total': duration} if kodi.time_s < duration else {'position': 0, 'total': 0}
        fflog(f'[KodiDB] repair placeholder resume point of {kodi.ref} ({kodi.fname}): {kodi.time_s}/{kodi.total_s} -> {resume}')
        try:
            if media is None:
                video_db.rpc('Files.SetFileDetails', params={**video_db.file_details(kodi.fname), 'resume': resume})
            else:
                kodi_type, dbid = media
                skip.add(media)
                video_db.rpc(f'VideoLibrary.Set{kodi_type.capitalize()}Details', params={f'{kodi_type}id': dbid, 'resume': resume})
        except Exception:
            fflog_exc()
            continue
        count += 1
    if count:
        progress_changed()  # the lists and widgets show the repaired progress
    return count


def update_playback_db_by_kodi_info(kodi: KodiVideoInfo, *, action: Optional[ChangeAction] = None,
                                    episodes: Optional[Sequence[MediaRef]] = None, at: Optional[float] = None) -> bool:
    """
    Send a change detected in Kodi video DB (the local Kodi account) to accounts: (un)watched, a removed resume point, a pause
    (the resume point of `kodi`). Without `action` it is found by the merged state of the other accounts (what they know before
    the change). A show / season (with `action`): its `episodes` (default: its aired ones). `at`: the time of the change
    (default: now). Kodi announces a change of a library item itself (`VideoLibrary.OnUpdate`, see `progress_changed()`).
    """
    from ..ff.info import ffinfo
    if kodi.ref.is_container or (pb := ffinfo.playback_info([kodi.ref], kodi=False).get(kodi.ref)) is None:
        pb = MediaPlayInfo(ref=kodi.ref)  # a container: no merged progress of the show (it would go as the progress of the change)
    if action is None:
        old, new = pb.play_count or 0, kodi.play_count
        if old == new:
            action = 'reset_progress'
            pb.progress = 0
        elif new > old:
            action = 'watched'
            pb.play_count = old + 1
        elif new == 0:
            action = 'unwatched'
            pb.play_count = 0
    elif action == 'watched':
        pb.play_count = (pb.play_count or 0) + 1
    elif action == 'unwatched':
        pb.play_count = 0
    elif action == 'reset_progress':
        pb.progress = 0
    elif action == 'pause':
        pb.progress = kodi.play_info('kodi').progress
    # the removal time of the local Kodi account (its rows are Kodi video DB)
    apply_local(action, kodi.ref, account_id='kodi', at=at, episodes=episodes or ())
    return update_playback_db(pb, action=action, episodes=episodes, at=at, announced=bool(kodi.library))


def update_playback_db(playback: MediaPlayInfo, *, play_count: Optional[int] = None, action: Optional[ChangeAction] = None,
                       episodes: Optional[Sequence[MediaRef]] = None, at: Optional[float] = None, announced: bool = False) -> bool:
    """
    Send the playback change (the local Kodi account has it in Kodi video DB already) to accounts, refresh the folder.
    A show / season: its `episodes` (default: its aired ones). `at`: the time of the change (default: now). `announced`:
    Kodi has announced the change itself (see `progress_changed()`).
    """
    from ..ff.sync import send_change

    fflog(f'[playback] {playback=}, {play_count=}, {action=}')

    if action is None:
        if playback.play_count:
            action = 'watched'
        else:
            action = 'unwatched'
    # progress before clearing: a paused item marked as watched has to finish the remote playback too
    progress = playback.progress
    if action in ('watched', 'unwatched', 'reset_progress'):
        playback.clear_progress()
    if play_count is not None:
        playback.play_count = play_count
    progress_changed(announced=announced)

    # watched with the progress before: the paused playback of the service is removed too
    # a state of Kodi video DB (a native mark, the FF menu marked already), not an event: only the accounts with another row state
    send_change(action, playback.ref, at=at, progress=progress if action in ('watched', 'pause') else None, episodes=episodes, if_differs=True)
    return True
