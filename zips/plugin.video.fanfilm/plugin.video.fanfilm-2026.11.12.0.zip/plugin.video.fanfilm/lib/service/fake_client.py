"""
Fake FF Service client for test.
"""

from __future__ import annotations
from typing import Optional, Union, Any, Dict, Iterable, Sequence, ClassVar, TYPE_CHECKING

from ..ff.logs import fflog
from .misc import PluginRequestInfo, StateVar, FFState, VolatileFfid
from .client import ServiceClient
if TYPE_CHECKING:
    from .misc import LibraryAutoAddSource
    from ..ff.url import URL
    from ..defs import MediaRef
    from ..ff.item import FFItem
from const import const


class FakeServiceClient(ServiceClient):
    """Simple FF Service client."""

    LOG_EXCEPTION: ClassVar[bool] = False
    FAKE: ClassVar[bool] = True

    def __init__(self, *, port: Optional[int] = const.tune.service.http_server.port) -> None:
        super().__init__(port=port)
        self._plugin_info = PluginRequestInfo()
        self._state = FFState()
        self._volatile_ffid = VolatileFfid()
        self._mdeia_files: Dict[str, str] = {}

    @property
    def url(self) -> str:
        """Service HTTP server URL."""
        if self._url is None:
            self._url = 'http://127.0.0.1:8123/'
        return self._url

    def folder_ready(self, *, timeout: Optional[float] = None) -> bool:
        """Wait for folder ready (watching progress update)."""
        fflog.debug('[FAKE] folder_ready()')
        return True

    def plugin_request_info(self) -> PluginRequestInfo:
        """Get folder info."""
        fflog.debug('[FAKE] plugin_request_info()')
        return self._plugin_info

    def plugin_request_enter(self, url: Union[URL, str], *, timestamp: Optional[float] = None) -> PluginRequestInfo:
        """Notify server about FF plugin folder enter."""
        fflog.debug(f'[FAKE] plugin_request_enter(url={str(url)!r})')
        self._plugin_info.enter(url, timestamp=timestamp)
        return self._plugin_info

    def plugin_request_exit(self, *, folder: Optional[Sequence[FFItem]] = None, focus: int = -1, timestamp: Optional[float] = None) -> PluginRequestInfo:
        """Notify server about FF plugin generate folder exit."""
        fflog.debug(f'[FAKE] plugin_request_exit({"-" if folder is None else len(folder)} items)')
        self._plugin_info.exit(folder=folder, focus=focus, timestamp=timestamp)
        return self._plugin_info

    def announce_mark(self, path: str) -> None:
        """Tell the service Kodi lists the show folder `path` next to (un)mark it natively."""
        self._plugin_info.announce_mark(path)

    def get_ffid_ref(self, ffid: int, *, timeout: Optional[float] = None) -> Optional[MediaRef]:
        """Get ref by volatile ffid."""
        if self._volatile_ffid is None:
            return None
        return self._volatile_ffid.get(ffid)

    def get_ffid_ref_dict(self, ffid_list: Iterable[int], *, timeout: Optional[float] = None) -> Dict[int, MediaRef]:
        """Get refs by volatile ffid list, return dict[ffid] = ref."""
        return {ffid: ref for ffid in ffid_list if (ref := self._volatile_ffid.get(ffid)) is not None}

    def create_ffid(self, ref: MediaRef, *, timeout: Optional[float] = None) -> Optional[int]:
        """Create new volatile ffid for given ref."""
        if self._volatile_ffid is None:
            return None
        return self._volatile_ffid.register(ref)

    def create_ffid_dict(self, refs: Iterable[MediaRef], *, timeout: Optional[float] = None) -> Dict[MediaRef, int]:
        """Create new volatile ffid for given ref."""
        if self._volatile_ffid is None:
            return {}
        return {ref: self._volatile_ffid.register(ref) for ref in refs}

    def accounts_sync(self, account: Optional[str] = None, *, wait: bool = True) -> Optional[list[str]]:
        """Sync the account (None: all syncing ones) directly (no service), tell the failed ones. Return their IDs."""
        from ..ff.sync import sync_accounts
        from ..ff.accounts import accounts
        from ..ff.account_admin import tell_sync_failed
        fflog.debug(f'[FAKE] accounts_sync({account!r})')
        results = sync_accounts(None if account is None else [acc for acc in accounts() if acc.id == account])
        if failed := [account_id for account_id, result in results.items() if result is None]:
            tell_sync_failed(failed, len(results))
        return failed

    def sync_wake(self) -> None:
        """Deliver the waiting changes of accounts directly (no service): a sync of the accounts with them."""
        from ..ff.sync import sync_accounts
        from ..ff.accounts import accounts
        from ..ff.db.playback import pending_changes
        waiting = {change.account_id for change in pending_changes()}
        fflog.debug(f'[FAKE] sync_wake() {sorted(waiting)}')
        sync_accounts([acc for acc in accounts() if acc.id in waiting])

    def restart_service(self) -> None:
        """No service to restart."""
        fflog.debug('[FAKE] restart_service()')

    def account_refresh(self, account_id: str) -> Optional[bool]:
        """Refresh the access token of the account directly (no service)."""
        from ..ff.accounts import get_account, account_client
        fflog.debug(f'[FAKE] account_refresh({account_id!r})')
        if (account := get_account(account_id)) is None or not hasattr(client := account_client(account), '_refresh_token'):
            return False
        return client._refresh_token()  # local (HTTP) refresh, refresh_token() would call this client again

    def state_get(self, module: str, key: str = '') -> Sequence[StateVar]:
        """Return service state variable."""
        var = self._state.get(module=module, key=key)
        return () if var is None else (var,)

    def state_set(self, variables: Iterable[StateVar], *, connect: bool = True) -> Optional[bool]:
        """Set list of variables to service state."""
        return self._state.multi_set(variables)

    def state_delete(self, module: str, key: str = '', *, connect: bool = True) -> Optional[bool]:
        """Delete service state variable."""
        return bool(self._state.delete(module=module, key=key))

    def state_wait(self, module: str, key: str, value: Any, *, timeout: Optional[float] = None) -> Optional[bool]:
        """Wait for service state variable change."""
        return self._state.wait_for(module=module, key=key, value=value, timeout=timeout)

    def advanced_settings(self) -> Dict[str, Any]:
        """Return advancedsettings.xml as JSON structure."""
        from ..ff.settings import advanced_settings
        return advanced_settings.get()

    def library_auto_add(self, source: LibraryAutoAddSource, *, sync: bool | None = None, quiet: bool | None = None) -> None:
        """Add to library items by theirs ref."""
        fflog.debug(f'[FAKE] library_auto_add({source=}, {sync=}, {quiet=})')

    def progress_shows(self, *, account: str | None = None, first: int | None = None, timeout: float | None = None) -> list[MediaRef] | None:
        """No service: the caller computes the shows in progress itself."""
        return None

    def set_media_files(self, data: Dict[str, str]) -> None:
        """Set media list files (m3u8 proxy)."""
        self._media_files = data
