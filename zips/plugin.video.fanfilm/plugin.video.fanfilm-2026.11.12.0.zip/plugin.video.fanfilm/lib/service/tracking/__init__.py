"""Service tasks of accounts (`accounts`: the sync of their rows and the delivery of their changes, `lib.ff.sync`)."""
