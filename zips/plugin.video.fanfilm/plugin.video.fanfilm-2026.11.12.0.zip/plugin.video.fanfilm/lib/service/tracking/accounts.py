"""Service task of accounts: the sync of their rows and the delivery of their waiting changes (`AccountSync`, `lib.ff.sync`)."""

from __future__ import annotations
from typing import Collection, Iterable
from threading import Lock, Condition
from time import monotonic
from typing_extensions import Literal, TypeAlias

from ...ff.threads import Thread, Event
from ...ff.db.playback import pending_changes
from ...ff.sync import sync_accounts, syncing_accounts, set_sync_state, sync_due, kodi_idle
from ...ff.accounts import accounts
from ...ff.kotools import xsleep
from ...ff.calendar import utc_timestamp
from ...ff.control import notification
from ...ff.logs import fflog, fflog_exc
from ..exc import ExitBaseException
from ...kolang import L
from ...ff.settings import settings
from const import const, CONST_REF
from cdefs import const_value

#: Who asks for a sync: the user (a failure is told), the cyclic sync, the delivery of a waiting change (no notification).
SyncRequester: TypeAlias = Literal['user', 'cycle', 'delivery']


class AccountSync(Thread):
    """
    Sync of accounts service task (`lib.ff.sync`), the policy is `const.accounts.sync`.

    A request puts accounts in the queue (once, it does not pile up), a pass syncs them one by one. An account the pass
    has not got to yet is not queued again, the one syncing now is synced once more after the pass (its changes made
    meanwhile). A pass of deliveries only waits for the end of their series (`const.accounts.sync.delivery_quiet`): one
    pass delivers it. The states of the accounts are in the Home window properties (`sync_state()`).
    """

    def __init__(self) -> None:
        self.active: bool = False
        #: The interval of the cyclic pass [s] (`CONST_REF`: read at its sleep and at `recheck()`).
        self.interval: int = CONST_REF.accounts.sync.interval
        #: The wait before the first pass [s] (as `interval`).
        self.startup_interval: int = CONST_REF.accounts.sync.startup_interval
        #: Wakes the thread up: a request.
        self.need_sync: Event = Event()
        #: Wakes the wait before the first pass: `recheck()` (a request waits for it).
        self._recheck_event: Event = Event()
        #: Set by `recheck()`: the sleep reads its interval again.
        self._rechecking: bool = False
        self._lock: Lock = Lock()
        #: Notified after the sync of each account (`wait()`).
        self._done: Condition = Condition(self._lock)
        #: The accounts waiting for the next pass (IDs).
        self._queue: set[str] = set()
        #: The accounts of the pass not synced yet (IDs).
        self._pass: list[str] = []
        #: The account syncing now (ID).
        self._running: str = ''
        #: The accounts the user asked for (their failure is told).
        self._told: set[str] = set()
        #: The queue has a request of the user or the cycle (the pass does not wait for the end of a series of deliveries).
        self._urgent: bool = False
        #: Monotonic time of the first request of a delivery in the queue (0: none).
        self._delivery_first: float = 0
        #: Monotonic time of the last request of a delivery in the queue (0: none).
        self._delivery_last: float = 0
        #: The next pass shows its notification (not only deliveries).
        self._shown: bool = False
        #: The last result of each account (`sync_account()`) by its ID.
        self._results: dict[str, bool | None] = {}
        #: UTC timestamp of the end of the last pass (None: not synced yet).
        self._timestamp: float | None = None
        super().__init__()
        self.name = f'{self.name}: AccountSync'

    @property
    def timestamp(self) -> float | None:
        """UTC timestamp of the end of the last pass, None if not synced yet."""
        with self._lock:
            return self._timestamp

    def stop(self) -> None:
        """Stop the sync thread."""
        self.active = False
        self.need_sync.set()

    def recheck(self) -> None:
        """Read the intervals again now (`const` reloaded): a shorter one ends the sleep sooner."""
        self._rechecking = True
        self._recheck_event.set()
        self.need_sync.set()

    def _sleep(self, interval: float, event: Event) -> bool:
        """Sleep the interval (read again at a recheck, counted from the start of the sleep); True: it passed, False: a request."""
        start = monotonic()
        while (left := const_value(interval) - (monotonic() - start)) > 0:
            if xsleep(left, cancel_event=event):
                return True
            if event is self.need_sync:
                if not self._rechecking or self._queue or not self.active:
                    return False  # a request, the stop
                self._rechecking = False
            event.clear()
        return True

    def _cycle_wait(self) -> bool:
        """
        Sleep until the cyclic pass: the interval, then while Kodi is idle (`kodi_idle()`) until it is used again or the idle
        interval passed since the start (`const.accounts.sync.idle_interval`). True: the pass is due, False: a request.
        """
        start = monotonic()
        if not self._sleep(self.interval, self.need_sync):
            return False
        if not kodi_idle():
            return True
        fflog('[SERVICE][SYNC] Kodi idle: the cycle waits')
        while kodi_idle():
            if monotonic() - start >= const.accounts.sync.idle_interval:
                fflog('[SERVICE][SYNC] Kodi idle: the idle interval passed')
                return True
            if not self._sleep(CONST_REF.tune.service.wait_check_interval, self.need_sync):
                return False
        fflog('[SERVICE][SYNC] Kodi used again: the cycle runs')
        return True

    def run(self) -> None:
        """Main activity: a pass of the requests, the cyclic one after the interval (longer while Kodi is idle)."""
        self.active = True
        self._clear_states(acc.id for acc in accounts())  # left by a killed service
        try:
            self._sleep(self.startup_interval, self._recheck_event)
            self.request(by='cycle')
            while self.active:
                if not self._queue and self._cycle_wait():  # the interval passed (not a request)
                    self.request(by='cycle')
                self.need_sync.clear()
                self._wait_deliveries()
                self._sync()
        except (ExitBaseException, SystemExit):
            self.active = False
            raise
        finally:
            with self._lock:
                self._clear_states(self._queue | {*self._pass, self._running})

    def request(self, account_ids: Iterable[str] | None = None, *, by: SyncRequester = 'user') -> set[str]:
        """
        Ask for the sync of the accounts (None: all syncing ones; the cycle: the ones it is due for, `sync_due()`) now, the one
        syncing now once more after it. Return their IDs.
        """
        if account_ids is None:
            ids = {acc.id for acc in syncing_accounts() if by != 'cycle' or sync_due(acc)}
        else:
            ids = set(account_ids)
        with self._lock:
            new = ids - set(self._pass)  # the pass gets to the rest yet
            self._queue |= new
            if by == 'user':
                self._told |= ids
            if by != 'delivery':
                self._shown = self._urgent = True
            elif new:
                self._delivery_last = monotonic()
                self._delivery_first = self._delivery_first or self._delivery_last
            for account_id in new - {self._running}:  # the running one shows "running" until its end
                set_sync_state(account_id, 'queued')
        self.need_sync.set()
        return ids

    def deliver_start(self, account_ids: Iterable[str] | None = None) -> None:
        """
        Deliver the waiting changes (of the accounts, default: all with them): a sync of the accounts, quietly, after the end
        of a series of changes (a sync running: right after it).
        """
        self.request({change.account_id for change in pending_changes()} if account_ids is None else account_ids, by='delivery')

    def _wait_deliveries(self) -> None:
        """
        Wait for the end of a series of deliveries in the queue (`const.accounts.sync.delivery_quiet` after the last one, at
        most `delivery_max_wait` since the first one); a request of the user or the cycle does not wait.
        """
        while self.active:
            with self._lock:
                if self._urgent or not self._delivery_last:
                    return
                quiet = self._delivery_last + const.accounts.sync.delivery_quiet
                left = min(quiet, self._delivery_first + const.accounts.sync.delivery_max_wait) - monotonic()
            if left <= 0:
                return
            self.need_sync.clear()
            xsleep(left, cancel_event=self.need_sync)  # a new request: the time again

    def wait(self, account_ids: Collection[str], timeout: float | None = None) -> dict[str, bool | None] | None:
        """Wait for the sync of the accounts (requested), return their results (`sync_account()`), None if `timeout` expires."""
        ids = set(account_ids)
        with self._lock:
            if not self._done.wait_for(lambda: not ids & (self._queue | {*self._pass, self._running}), timeout):
                return None
            return {account_id: self._results.get(account_id) for account_id in ids if account_id in self._results}

    def _sync(self) -> None:
        """A pass: sync the queued accounts (in the order of the accounts), tell the failures the user asked for."""
        accs = {acc.id: acc for acc in syncing_accounts()}
        with self._lock:
            self._pass = [account_id for account_id in accs if account_id in self._queue]
            for account_id in self._queue - accs.keys():  # removed, inactive meanwhile
                set_sync_state(account_id, '')
            self._queue.clear()
            self._urgent, self._delivery_first, self._delivery_last = False, 0, 0
            shown, self._shown = self._shown, False
            if not self._pass:
                self._done.notify_all()
                return
        set_sync_state(None, 'running')
        results: dict[str, bool | None] = {}
        fflog(f'[SERVICE][SYNC] START {self._pass}')
        try:
            with notification(f'[FanFilm] {L(32916, "Accounts")}', L(30200, 'sync in progress'), delay=const.accounts.sync.notification_delay,
                              enabled=shown and settings.getBool('trakt.sync_notification')):
                while True:
                    with self._lock:
                        if not self._pass:
                            break
                        self._running = account_id = self._pass.pop(0)
                        set_sync_state(account_id, 'running')
                    try:
                        results.update(sync_accounts([accs[account_id]]))
                    except Exception:  # the thread serves the other accounts and the next passes
                        fflog_exc()
                        results[account_id] = None  # failed (told as the activities failed)
                    finally:
                        with self._lock:
                            self._running = ''
                            self._results.update(results)
                            set_sync_state(account_id, 'queued' if account_id in self._queue else '')
                            self._done.notify_all()
        finally:
            set_sync_state(None, '')
        fflog(f'[SERVICE][SYNC] DONE {results}')
        with self._lock:
            self._timestamp = utc_timestamp()
            told = [account_id for account_id in results if account_id in self._told]
            self._told -= {account_id for account_id in told if account_id not in self._queue}
        if failed := [account_id for account_id in told if results[account_id] is None]:
            from ...ff.account_admin import tell_sync_failed
            tell_sync_failed(failed, len(told))

    @staticmethod
    def _clear_states(account_ids: Iterable[str]) -> None:
        """Clear the sync states of the service and the accounts (the windows show no sync)."""
        set_sync_state(None, '')
        for account_id in account_ids:
            if account_id:
                set_sync_state(account_id, '')
