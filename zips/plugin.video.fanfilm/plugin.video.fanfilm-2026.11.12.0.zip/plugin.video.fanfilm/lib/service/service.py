

ans = 44

