"""Service / reload exception definitions."""

from typing import Sequence
from pathlib import Path


class ExitBaseException(BaseException):
    """Exit exceptions are based on BaseException to pass thru `except Exception`."""


class KodiExit(ExitBaseException):
    """Kodi is going to close."""


class ReloadExit(ExitBaseException):
    """A source of FanFilm changed (`const.debug.autoreload`): the plugin interpreter ends, the next call starts fresh."""

    def __init__(self, *args, changed: Sequence[Path] = ()) -> None:
        super().__init__(*args)
        #: The changed sources.
        self.changed: Sequence[Path] = changed
