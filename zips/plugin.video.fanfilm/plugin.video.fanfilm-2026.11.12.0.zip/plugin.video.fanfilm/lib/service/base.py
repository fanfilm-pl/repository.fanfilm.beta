
"""
FanFilm Add-on

Service base: cyclic works (background threads) shared by service modules.

MIT
"""

from __future__ import annotations
from functools import wraps
from time import monotonic
from typing import Sequence, Union, TYPE_CHECKING
from typing_extensions import Protocol
from typing_extensions import TypeAlias
from weakref import WeakSet
from attrs import define, Factory
from .exc import ExitBaseException
from ..ff.threads import Thread, Event, CancelScope
from ..ff.settings import settings
from ..ff.kotools import xsleep, video_playing
from ..ff.logs import fflog, fflog_exc
from const import const
if TYPE_CHECKING:
    from typing import Any, Callable

#: An interval of a cyclic work [s]: a number or a function of it read at every cycle and after a reload of `const`
#: (e.g. `CONST_REF.tune.db.cleanup_interval`); 0 or None of a function: the work waits (switched off for now).
Interval: TypeAlias = Union[float, 'Callable[[], float | None]']
#: The longest sleep of a work switched off for now [s] (a reload of `const` wakes it anyway).
OFF_SLEEP = 3600


class Rechecking(Protocol):
    """A sleeper of an interval of `const` (a member of `service_works`)."""

    def recheck(self) -> None:
        """Read the interval again now (`const` reloaded)."""


@define(eq=False)  # by identity: a member of `service_works`
class Work:
    """Cyclic work (function called periodically in its own thread)."""

    #: Work name (function qualname).
    name: str
    #: Function called cyclically.
    func: Callable[..., None]
    #: Interval between calls [s].
    interval: Interval = 0
    #: Thread running the work.
    thread: Thread | None = None
    #: Event to wake up the sleeping thread (force call or stop).
    break_event: Event = Factory(Event)
    #: Set by stop(), cyclic loop exits instead of calling `func`.
    stopped: bool = False
    #: Set by recheck(): the sleeping thread reads its interval again (no call unless the new one has passed).
    rechecking: bool = False

    def force_call(self) -> None:
        """Force re-call cyclic function now."""
        self.break_event.set()

    def recheck(self) -> None:
        """Read the interval again now (`const` reloaded): a shorter one ends the sleep sooner."""
        self.rechecking = True
        self.break_event.set()

    def stop(self) -> None:
        """Stop cyclic calling (wakes up the sleeping thread)."""
        self.stopped = True
        self.break_event.set()


def after_video(func: Callable[..., None]) -> Callable[..., None]:
    """
    Return the maintenance work `func` of a cyclic call waiting for the end of a video (`video_playing()`, checked every
    `const.tune.service.wait_check_interval`): its CPU and disk work could make the video stutter on a weak device. A direct
    call of `func` (e.g. asked by the user) does not wait.
    """
    @wraps(func)
    def call(*args: Any, **kwargs: Any) -> None:
        """Wait for the end of a video, then call the work."""
        if video_playing():
            fflog(f'[SERVICE] {func.__qualname__} waits for the end of the video')
            while video_playing():
                xsleep(const.tune.service.wait_check_interval)
            fflog(f'[SERVICE] {func.__qualname__} runs after the video')
        func(*args, **kwargs)

    return call


def seconds(interval: Interval) -> float | None:
    """Return the interval now [s] (a function: its value, None or 0: switched off for now)."""
    return interval() if callable(interval) else interval


def cyclic_call(interval: Interval | tuple[Interval, Interval], func: Callable[..., None], *args: Any, **kwargs: Any) -> Work | None:
    """
    Call function cyclically in a separate thread (an error of a call is logged, the next cycle calls it again).
    Interval is `(first, next)` or single value [s]; a number 0 of the next one: called once. A function is read at every
    cycle and after a reload of `const` (`recheck_works()`).
    """

    def sleep(interval: Interval) -> None:
        """Sleep the interval (read again at a recheck, from the start of the sleep); return at its end or a forced call."""
        start = monotonic()
        while True:
            if (length := seconds(interval)) is None or (length <= 0 and callable(interval)):
                left: float = OFF_SLEEP  # switched off for now: a recheck wakes it
            else:
                left = length - (monotonic() - start)
            if left > 0:
                xsleep(left, cancel_event=work.break_event)
            if work.stopped or not work.rechecking:
                return  # its end (also of a new interval passed already), a forced call, the stop
            work.rechecking = False
            work.break_event.clear()

    def calling() -> None:
        """Thread loop: sleep and call `func` until stop or exit."""
        interval = first_interval
        try:
            # Kodi abort is handled by xsleep() (raises ExitBaseException).
            # Do not check abortRequested() here, a Monitor created after abort never sees it.
            while True:
                sleep(interval)
                if work.stopped:
                    return
                work.break_event.clear()  # xsleep() doesn't clear it, force_call() would loop forever
                settings.delete()
                try:
                    func(*args, **kwargs)
                except ExitBaseException:
                    raise
                except Exception:  # an error of one call (e.g. Kodi could not read the settings): the next cycle calls it again
                    fflog_exc()
                interval = next_interval
                if not callable(interval) and not interval:
                    return
        except ExitBaseException:
            return
        except Exception:
            fflog_exc()
            raise

    if not interval:
        return None
    if isinstance(interval, Sequence):
        first_interval, next_interval = interval
    else:
        first_interval = next_interval = interval
    thread = Thread(target=calling, scope=service_scope)  # stopped with the service, also in the middle of `func`
    thread.name = f'{thread.name}: {func.__qualname__}'
    work = Work(thread=thread, func=func, name=func.__qualname__, interval=next_interval)
    thread.start()
    service_threads.add(thread)
    service_works.add(work)
    return work


def recheck_works() -> None:
    """Make the cyclic works read their intervals again (`const` reloaded)."""
    for work in list(service_works):
        work.recheck()


def join_threads() -> None:
    """Join all service threads."""
    for th in service_threads:
        th.join()
    service_threads.clear()


#: All service threads (joined on service stop).
service_threads: WeakSet[Thread] = WeakSet()
#: All cyclic works and other sleepers of an interval of `const` (`recheck_works()`).
service_works: WeakSet[Rechecking] = WeakSet()
#: Stop scope of the cyclic works of the current service run (new in `main.run()`, set by `main.stop()`): a work busy
#: in `func` ends at its next request (`ff.requests`) or cache read, its sockets are cut (see `lib.ff.threads.CancelScope`).
service_scope: CancelScope = CancelScope()
