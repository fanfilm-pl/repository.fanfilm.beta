"""
Simple HTTP Web server for FanFilm Kodi addon users.

Used to help users set up their Kodi addon by providing a web interface.
"""

if True:  # to avoid: module level import not at top of file (flake8 E402)
    def cli_define():
        from ..dev.main import predefine as tui_predefine, base_args_parser
        p = base_args_parser()
        p.add_argument('-p', '--port', type=int, default=8663, help='server port')
        p.add_argument('-t', '--threading', action='store_true', help='multithreading / concurrent requests')
        p.add_argument('-j', '--user-js', choices=['stable', 'beta'], help='cat fanfilm.user.js file (for stable or beta version)')
        p.add_argument('--help', action='help', help='show this help message and exit')
        args, _ = tui_predefine(args=p.parse_args())
        return args

    if __name__ == '__main__':
        cli_args = cli_define()
    else:
        cli_args = None

from typing import Any, Optional, Type, Mapping, TYPE_CHECKING
from pathlib import Path
from weakref import WeakSet
from fnmatch import fnmatch
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from .http_request import (
    RequestHandler, RoutedServer, Route, request, Address,
    HTTPBadRequest, HTTPNotFound, HTTPUnprocessableContent, ExpectedJsonObjectError,
)
from ..ff.threads import Thread, Event
# from ..ff.routing import Router
from ..ff.settings import settings
from ..ff.types import JsonData, JsonResult
from ..ff.logs import fflog, fflog_exc
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from .main import Works
    from socketserver import BaseRequestHandler
    import socket


def _setting_name(value: 'str | tuple[str, str]') -> str:
    """Unwrap a const.tune.service.web_server.cookies value - either a plain setting name, or an
    (setting_name, 'append') tuple (see update_cookies() append handling)."""
    return value[0] if isinstance(value, tuple) else value


def cookie_sites() -> 'dict[Any, dict[str, Any]]':
    """
    Return the sites of the cookies: `const.tune.service.web_server.cookies` (the accounts) and the sites of the native
    providers (their declarations in the stored catalog), a value of a provider as `provider:<name>:<key>`.
    """
    from ..sources.natives import catalog_providers, native_catalog
    sites: 'dict[Any, dict[str, Any]]' = {host: dict(conv) for host, conv in const.tune.service.web_server.cookies.items()}
    for prov in catalog_providers(native_catalog(build=False)):
        for host, values in prov.get('cookies', {}).items():
            sites.setdefault(host, {}).update({cookie: f'provider:{prov["id"]}:{key}' for cookie, key in values.items()})
    return sites


def target_value(target: str) -> 'str | None':
    """Return the value of a target of a cookie (`provider:<name>:<key>` or a setting), None if there is no such setting."""
    if target.startswith('provider:'):
        from ..sources.natives import provider_value
        _, name, key = target.split(':', 2)
        return str(provider_value(name, key))
    return settings.get(target, default=None)


def set_target_value(target: str, value: str) -> None:
    """Set the value of a target of a cookie (`provider:<name>:<key>` or a setting)."""
    if target.startswith('provider:'):
        from ..sources.natives import set_provider_value
        _, name, key = target.split(':', 2)
        set_provider_value(name, key, value)
    else:
        settings.setString(target, value)


if TYPE_CHECKING:
    class ServerBase(ThreadingHTTPServer):
        pass
elif __name__ == '__main__' and not cli_args.threading:  # DEBUG only !!!
    class ServerBase(HTTPServer):
        pass
else:
    class ServerBase(ThreadingHTTPServer):
        pass


class Server(RoutedServer, ServerBase):
    """FanFilm Web Server."""

    daemon_threads = True  # terminate worker threads when main thread terminates

    MIME_TYPES = {
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
    }

    @staticmethod
    def credentials() -> 'list[str]':
        """Return the names of the supported credentials (the targets of `cookie_sites()`, not the accounts)."""
        return [name for name in (_setting_name(value) for hc in cookie_sites().values() for value in hc.values()) if not name.startswith('account:')]

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler] = RequestHandler,
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        from ..ff.kotools import Notification
        super().__init__(server_address, RequestHandlerClass, works=works)
        self.path = Path(__file__).parent.parent.parent / 'web'
        self._active_requests: 'WeakSet[socket.socket]' = WeakSet()
        # The web server is driven from outside Kodi (a browser): its notifications are silent (e.g. a TV while watching).
        self._update_notif = Notification('FanFilm', L(30519, 'Received cookies'), sound=False)

    @staticmethod
    def modify_js_for_beta(file: bytes) -> bytes:
        """Modify JavaScript file content for beta version."""
        import re
        file = re.sub(rb'^(//\s*@name\s+FanFilm)$', rb'\1 Beta', file, flags=re.MULTILINE)
        file = re.sub(rb'^(// @(?:icon|downloadURL|updateURL)\b\s+ https://raw.githubusercontent.com/fanfilm-pl/)repository.fanfilm/',
                      rb'\1repository.fanfilm.beta/', file, flags=re.MULTILINE)
        return file

    def finish_request(self, request, client_address):
        """Finish one request by instantiating RequestHandlerClass."""
        fflog(f'New request {request} from {client_address}')
        self._active_requests.add(request)
        req = self.RequestHandlerClass(request, client_address, self)
        self._active_requests.discard(request)
        fflog(f'Finish request {request} from {client_address}')

    @Route.get(r'/(index.html)?')
    def root(self) -> str:
        try:
            return (self.path / 'index.html').read_text(encoding='utf-8')
        except OSError:
            fflog_exc()
            return '<!DOCTYPE html><html><head><title>FanFilm Web Server</title></head><body>Not supported</body></html>'

    @Route.post(r'/echo')
    def echo(self) -> JsonResult:
        data = request.json
        return data

    def file(self, path: Path) -> 'tuple[int, bytes, dict[str, str]]':
        """Read static file and return response tuple (status, content, headers)."""
        ext = path.suffix.lower()
        headers: 'dict[str, str]' = {}
        if ctype := self.MIME_TYPES.get(ext):
            headers['Content-Type'] = ctype
        try:
            return 200, path.read_bytes(), headers
        except FileNotFoundError:
            fflog.info(f'Missing static file: {path}')
        except OSError:
            fflog_exc()
        raise HTTPNotFound(f'File not found: {path}')

    @Route.get(r'/(?P<path>(?:static|mod)/.+)')
    def static(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(self.path / path)

    @Route.get(r'/beta/(?P<path>.+)')
    def static_beta(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        status, file, headers = self.file(self.path / 'mod' / path)
        if path.endswith('.js') and status == 200 and isinstance(file, bytes):
            file = self.modify_js_for_beta(file)
        return status, file, headers

    @Route.get(r'/addon/(?P<path>(?:fanart\.jpg|icon\.png))')
    def static_addon(self, path: str) -> 'tuple[int, bytes, dict[str, str]]':
        return self.file(Path(__file__).parent.parent.parent / path)

    def _list_credentials(self) -> JsonData:
        def label(js_name: str, setting_name: str) -> str:
            if js_name == ':user_agent':
                return L(30353, 'User agent')
            if js_name.startswith(':'):
                return js_name[1:].replace('_', ' ').title()
            if js_name == 'cf_clearance':
                return L(30526, 'Cloudflare cookie')
            return L(30527, 'Cookie ({name})').format(name=js_name)

        return {
            'settings': [
                {
                    'name': name,
                    'value': value,
                    'section': host,
                    'cookie': js_name,
                    'label': label(js_name, name),
                    # 'buttons': ['user_agent'] if js_name == ':user_agent' else [],
                } for host, hsets in cookie_sites().items()
                for js_name, raw_name in hsets.items()
                if (name := _setting_name(raw_name)) and not name.startswith('account:') and (value := target_value(name)) is not None
            ]
        }

    def _get_cookie_value(self, setting_name: str, cookie: str) -> str:
        from ..ff.source_utils import extract_cookie
        for cookies_defs in cookie_sites().values():
            for cookie_name, setting in cookies_defs.items():
                if _setting_name(setting) == setting_name:
                    return extract_cookie(cookie=cookie, cookie_name=cookie_name)
        return cookie

    @Route.get(r'/credentials/?')  # (?P<name>[^/]+)')
    def list_credentials(self) -> JsonData:
        return self._list_credentials()

    @Route.post(r'/credentials/?')
    def set_all_credentials(self) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if setting_list := data.get('settings'):
            fflog(f'Updating credentials: {setting_list}')
            for setting in setting_list:
                name, cookie = setting.get('name'), setting.get('value')
                if name in self.credentials():
                    cookie = self._get_cookie_value(name, cookie)
                    set_target_value(name, cookie)
        return self._list_credentials()

    @Route.get(r'/credentials/(?P<name>[^/]+)')
    def get_credentials(self, name: str) -> JsonData:
        value = target_value(name)
        return {
            'name': name,
            'value': value,
        }

    @Route.post(r'/credentials/(?P<name>[^/]+)')
    def set_credentials(self, name: str) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        value = data.get('value')
        set_target_value(name, '' if value is None else str(value))
        return {
            'name': name,
            'value': value,
        }

    @Route.post(r'/cookies')
    def update_cookies(self) -> JsonData:
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        cookie_name_list = ', '.join(f'{cookie.get("name")}' for cookie in data.get('cookies', []))
        fflog(f'Updating cookies: {data.get("host")} ({cookie_name_list})')
        settings_count = 0
        changed: 'set[str]' = set()
        account_values: 'dict[str, dict[str, str]]' = {}
        if host := data.get('host'):
            for host_def, conv in cookie_sites().items():
                if fnmatch(host, host_def) if isinstance(host_def, str) else host_def.fullmatch(host):
                    cookies = {name: value for cookie in data.get('cookies', []) if (name := cookie.get('name')) and (value := cookie.get('value'))}
                    for cookie_name, settings_name in conv.items():
                        if cookie_name == ':UA':  # user-agent
                            cookie_name = ':user_agent'
                        value = data.get(cookie_name[1:], '') if cookie_name.startswith(':') else cookies.get(cookie_name, '')
                        if isinstance(settings_name, str) and settings_name.startswith('account:'):  # to an account
                            _, type_name, key = settings_name.split(':', 2)
                            if value:
                                account_values.setdefault(type_name, {})[key] = value
                            continue
                        append = isinstance(settings_name, tuple)  # (settings_name, 'append')
                        if append:
                            settings_name = settings_name[0]
                            if not value:
                                continue  # nothing to append - leave the setting alone
                            current = [v for part in (target_value(settings_name) or '').split(',') if (v := part.strip())]
                            if value in current:
                                continue  # already there
                            value = ','.join([*current, value])
                        if value != (target_value(settings_name) or ''):
                            changed.add(settings_name)
                        set_target_value(settings_name, value)
                        settings_count += 1
                    otp_setting = conv.get('otp_code')
                    if otp_setting and otp_setting in changed and (target_value(otp_setting) or '').strip():
                        from ..sources.en.netmirror import source as NetMirrorSource
                        NetMirrorSource.prefetch_otp_token()
        for type_name, values in account_values.items():
            settings_count += len(values)
            changed.update(self._to_account(type_name, values))
        warning = ''
        if fnmatch(host or '', '*imdb.com') and not account_values.get('imdb', {}).get('at-main') and not data.get('imdb_user_id'):
            # no session cookie (not signed in, or the script can not read HttpOnly cookies): nothing for the accounts;
            # told to the sender (the script shows the warning), in Kodi only as the update notification (silent)
            warning = L(30692, 'IMDb: no at-main cookie - not signed in, or the script can not read HttpOnly cookies')
            (fflog if data.get('forced_by_user') else fflog.debug)('IMDb cookies without at-main (not signed in, or no HttpOnly access of the script)')
        if changed or data.get('forced_by_user'):
            fflog(f'Changed settings: {", ".join(sorted(changed))}')
            if const.tune.service.web_server.update_notification:
                if warning and data.get('forced_by_user'):
                    from ..ff.kotools import Notification
                    Notification('FanFilm', warning, sound=False).show()
                else:
                    self._update_notif.show()
        return {
            'success': True,
            'settings_count': settings_count,
            **({'warning': warning} if warning else {}),
        }


    @staticmethod
    def _to_account(type_name: str, values: 'dict[str, str]') -> 'set[str]':
        """Give the cookies to the accounts (IMDb: the account of the cookie user), return what changed (for the log)."""
        from ..ff import account_admin
        from ..ff.kotools import Notification
        changed: 'set[str]' = set()
        if type_name != 'imdb':
            return changed
        if user := values.get('public'):
            before = {acc.id for acc in account_admin.account_store.accounts()}
            if (acc := account_admin.add_public_imdb(user)) and acc.id not in before:  # an existing account of the user: no change
                changed.add(acc.id)
        if values.get('at-main'):
            free = account_admin.free_imdb_cookie()
            target, nick = account_admin.receive_imdb_cookie(values)
            if target:
                changed.add(target)
            elif nick and (not free or free.get('at-main') != values['at-main']):  # a new free cookie: tell once
                Notification('FanFilm', L(30693, 'IMDb cookie of {nick}: add the account in the accounts').format(nick=nick), sound=False).show()
        return changed


class WebServer:
    """The main function that starts the HTTP Web Server."""

    def __init__(self,
                 *,
                 works: Optional['Works'],
                 ) -> None:
        self._running: bool = False
        self._server: Optional[Server] = None
        self._httpd_thread: Optional[Thread] = None
        self.works: Optional['Works'] = works

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Start proxy server (in new therad)."""
        if self._running:
            return

        address = '0.0.0.0'  # any address
        try:
            # create HTTP server and start serve in new therad
            self._server = Server((address, const.tune.service.web_server.port), RequestHandler, works=self.works)
            self._server.allow_reuse_address = True
            self._httpd_thread = Thread(target=self._server.serve_forever, kwargs={'poll_interval': const.tune.service.server_poll_interval},
                                        name='Service WEB')
            self._httpd_thread.start()
            self._running = True

            # get port number and set server URL in the settings
            fflog(f'=== Web Server Started: {self._server.url} ===')

        except Exception:
            # creating HTTP server failed, clear URL in the settings
            self._running = False
            fflog_exc()
            raise

    def stop(self):
        """Stop proxy server."""
        if not self._running:
            return

        # shutdown and close the server
        try:
            if self._server is not None:
                self._server.shutdown()
                self._server.server_close()
                if self._server._active_requests:
                    fflog(f'Active requests: {self._server._active_requests}')
                for req in self._server._active_requests:
                    try:
                        req.shutdown(2)
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                    try:
                        req.close()
                    except Exception as exc:
                        fflog(f'Exception during closing request socket: {exc}')
                self._server._active_requests.clear()
                self._server.socket.close()
                self._server._update_notif.close()
                self._server = None
            if self._httpd_thread is not None:
                self._httpd_thread.join()
                self._httpd_thread = None
        except Exception as exc:
            fflog(f'Exception during stopping web server: {exc}')
            fflog_exc()
        self._running = False
        fflog('=== Web Server Stopped ===')


# DEBUG (command line tests)
def main(args):
    def _run_server():
        from .main import Works
        address = '0.0.0.0'
        works = Works(
            events={
                'folder': Event(),
            },
        )
        works.events['folder'].set()
        server = Server((address, args.port), RequestHandler, works=works)
        server.allow_reuse_address = True
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('   Interrupted, shutting down ...')
            server.shutdown()
            server.server_close()
            print('Server stopped.')
        finally:
            from .main import stop
            from ..ff.kotools import destroy_xmonitor
            stop()
            destroy_xmonitor()
        # from threading import enumerate as thread_enumerate
        # from .main import threads
        # print('Active threads:', thread_enumerate())
        # print('FanFilm threads:', threads)

    if args.user_js == 'stable':
        print((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_text(encoding='utf-8'))
    elif args.user_js == 'beta':
        print(Server.modify_js_for_beta((Path(__file__).parent.parent.parent / 'web' / 'mod' / 'fanfilm.user.js').read_bytes()).decode('utf-8'))
    else:
        _run_server()


if __name__ == '__main__' and cli_args is not None:
    main(cli_args)
