"""
Plugin calls in the service: the thin plugin (`lib.plugin_remote`) sends a call of a handle (a folder, a widget) here, it
runs warm in a thread of its own (`CallScope`, a child of the service scope). The switch: `const.tune.service.remote_plugin`.
A changed `local.py` is loaded again between the calls (`cdefs.const_reload()`).
"""

from __future__ import annotations
from threading import Condition
from time import monotonic
from typing import Callable, Dict, List, Optional
from weakref import WeakValueDictionary

from . import base
from ..ff.control import CallScope, reload_local
from ..ff.kotools import kodi_abort_event
from ..ff.logs import fflog, fflog_exc
from ..ff.threads import Thread
from ..ff.types import JsonResult
from ..ff.url import URL
from const import const

#: How often the server checks the end of a call which has not answered Kodi, seconds (the answer itself ends the wait at once).
CALL_END_STEP = .05


class RemoteCalls:
    """
    The plugin calls run in the service: `calls` at once, the next ones wait for a free one; they run in the plugin only
    if every running call runs longer than `call_timeout` (a dialog of the user, a hang), not because of a long queue.
    """

    def __init__(self, *, on_reload: Optional[Callable[[List[str]], None]] = None) -> None:
        #: The calls by their id (given by the thin plugin), for their abort.
        self._calls: Dict[str, CallScope] = {}
        #: The start (`monotonic()`) of the running calls by their id.
        self._running: Dict[str, float] = {}
        #: Guards `_calls` and `_running`, wakes the waiting calls (a call ended, an abort).
        self._cond = Condition()
        #: Called after `local.py` was loaded again (the changed keys), e.g. to publish the switch again.
        self._on_reload = on_reload

    def run(self, call_id: str, argv: List[str], *, folder: bool) -> Optional[JsonResult]:
        """
        Run the plugin call, return when it answered Kodi or ended without the answer (`answered`); `here`: run it in the
        plugin (a play, no free call in time, the switch off). At Kodi exit no call starts (`answered` false at once: Kodi
        stops only after the thin plugin ended, it does not abort it). None: the id is of a call still known (a wrong client).
        """
        from ..indexers.play import is_play_url
        if kodi_abort_event.is_set():
            return {'answered': False}
        if not const.tune.service.remote_plugin.enabled or is_play_url(URL(argv[0] + argv[2])):  # a play: the source search, the player
            return {'here': True}
        call = CallScope(argv, parent=base.service_scope)
        call.folder = folder
        call.items = WeakValueDictionary()
        with self._cond:
            if call_id in self._calls:
                return None  # another call: its abort and its end must stay its own
            self._calls[call_id] = call  # an abort while the call waits for a free one
        if not self._enter(call_id, call):
            self._leave(call_id)
            if call.is_set() or kodi_abort_event.is_set():  # aborted while it waited, Kodi exits
                return {'answered': False}
            fflog(f'[FF] remote call {call_id}: the running calls take over {const.tune.service.remote_plugin.call_timeout} s, run in the plugin')
            return {'here': True}
        thread = Thread(target=self._run, args=(call_id, call), scope=call, name=f'Plugin call {call_id}')
        try:
            thread.start()
        except BaseException:
            self._leave(call_id)
            raise
        while not call.answer.wait(CALL_END_STEP):
            if not thread.is_alive():
                break
        return {'answered': call.answered}

    def abort(self, call_id: str) -> bool:
        """Abort the call (Kodi aborted its thin plugin): its threads stop, its sockets are cut, it writes to Kodi no more."""
        with self._cond:
            if (call := self._calls.get(call_id)) is None:
                return False
            call.set()
            self._cond.notify_all()  # it may wait for a free call
        return True

    def _enter(self, call_id: str, call: CallScope) -> bool:
        """Wait for a free call and take it; False if every running call runs longer than `call_timeout`, aborted or Kodi exits."""
        with self._cond:
            while not call.is_set() and not kodi_abort_event.is_set() and len(self._running) >= const.tune.service.remote_plugin.calls:
                if (left := max(self._running.values()) + const.tune.service.remote_plugin.call_timeout - monotonic()) <= 0:
                    return False
                self._cond.wait(left)
            if call.is_set() or kodi_abort_event.is_set():
                return False
            if not self._running:
                self._reload_local()  # no call runs: a call sees one `const` from its start to its end
            self._running[call_id] = monotonic()
            return True

    def reload_local(self) -> None:
        """Load `local.py` again if it changed and no call runs (a cycle of the service; the next call does it too)."""
        from cdefs import local_changed
        if local_changed():
            with self._cond:
                if not self._running:
                    self._reload_local()

    def _reload_local(self) -> None:
        """Load a changed `local.py` again (under the lock, no call runs, `reload_local()`), the works and the server follow it."""
        if (changed := reload_local()) is None:
            return
        base.recheck_works()  # the cyclic works read their intervals again
        if self._on_reload is not None:
            try:
                self._on_reload(changed)
            except Exception:
                fflog_exc()

    def kodi_exit(self) -> None:
        """Kodi exits: the calls waiting for a free one end at once (no call starts any more, see `run()`)."""
        with self._cond:
            self._cond.notify_all()

    def _leave(self, call_id: str) -> None:
        """Free the call, wake the waiting ones."""
        with self._cond:
            self._calls.pop(call_id, None)
            self._running.pop(call_id, None)
            self._cond.notify_all()

    def _run(self, call_id: str, call: CallScope) -> None:
        """Run the call in its thread, destroy its FFItems (the Kodi GC can not see their cycles), free the call."""
        from ..launch import run_call
        from ..ff.item import FFItem
        from ..ff.kodidb import video_db
        start = monotonic()
        try:
            video_db.reset()  # the FF plays of Kodi DB: read again in every call (MySQL)
            if const.debug.enabled:
                fflog(f'[FF] remote enter {call_id}: {call.argv}, folder={call.folder}')
            run_call(call)
        finally:
            items = call.items or {}
            count = len(items)
            FFItem.destroy_ffitems(list(items.values()), own=items)  # not the linked items of the service
            self._leave(call_id)
            if const.debug.enabled:
                from ..ff.tricks import memory_stats
                fflog(f'[FF] remote exit {call_id} --- ({monotonic() - start:.3f}s), aborted={call.is_set()}, call items={count}, {memory_stats()}')
