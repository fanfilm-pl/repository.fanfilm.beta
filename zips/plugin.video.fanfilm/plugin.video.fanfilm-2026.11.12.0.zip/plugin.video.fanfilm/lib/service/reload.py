"""
The autoreload of the sources (`const.debug.autoreload`): a changed source of FanFilm ends the plugin interpreter (the
next call starts fresh, `lib.preenter.preinit()`) and restarts the service in a fresh interpreter (`restart_service()`),
the code as after a Kodi restart. A service is started again by Kodi only after its stop, so the add-on is disabled and
enabled (`CServiceAddonManager`: a service which ended by itself is "already started").
"""

from __future__ import annotations
import json
from pathlib import Path

from .exc import ReloadExit

#: The folder of the add-on (the path of Kodi, a link of a developer followed): its sources and its inode (a new folder: Kodi installed
#: the add-on, `ReloadMonitor.installed()`).
ADDON_DIR: Path = Path(__file__).parents[2]


def source_files() -> list[Path]:
    """Return the sources of FanFilm watched by the autoreload: its modules, not the bundled third party ones (`lib/3rd`)."""
    lib = ADDON_DIR / 'lib'
    third = lib / '3rd'
    return [*ADDON_DIR.glob('*.py'), *(path for path in lib.rglob('*.py') if third not in path.parents)]


def _mtime(path: Path) -> float:
    """Return the modification time of the file, -1 if it is gone."""
    try:
        return path.stat().st_mtime
    except OSError:
        return -1


class ReloadMonitor:
    """The modification times of the sources (`source_files()`) and the inode of the add-on folder."""

    def __init__(self) -> None:
        #: The inode of the add-on folder: Kodi installs an add-on into a new folder (renamed in place of the old one).
        self.inode: int = ADDON_DIR.stat().st_ino
        #: The sources and their modification times.
        self.files: dict[Path, float] = {path: _mtime(path) for path in source_files()}

    def changed(self) -> list[Path]:
        """Return the sources changed since the last check (their new times kept)."""
        changed = [path for path, mtime in self.files.items() if _mtime(path) != mtime]
        for path in changed:
            self.files[path] = _mtime(path)
        return changed

    def installed(self) -> bool:
        """Return True if Kodi installed the add-on meanwhile (an update: Kodi starts its new service itself)."""
        try:
            return ADDON_DIR.stat().st_ino != self.inode
        except OSError:
            return True

    def check(self) -> None:
        """Raise ReloadExit if a source changed (a plugin call: the next one runs in a fresh interpreter)."""
        if changed := self.changed():
            raise ReloadExit(changed=changed)


def restart_service() -> None:
    """Start the service again in a fresh interpreter: the add-on disabled and enabled (this one, stopped already, ends by the abort)."""
    import xbmc
    for enabled in (False, True):
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
                                        'params': {'addonid': ADDON_DIR.name, 'enabled': enabled}}))
