"""
Simple HTTP Proxy for FanFilm Kodi addon
This module starts a simple HTTP proxy server that listens for incoming
HTTP requests and forwards them to an external server, modifying the headers as necessary.
"""

from typing import Optional, Union, Any, Tuple, List, Dict, Set, Iterable, Mapping
from typing import ClassVar, Type, Callable, TYPE_CHECKING
from typing_extensions import TypeAlias, ParamSpec
import json
from pathlib import Path
import os
import sys
from enum import Enum
# from contextlib import closing
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from attrs import define, frozen, asdict
if sys.version_info >= (3, 9):
    from random import randbytes
else:
    from random import randint
    def randbytes(n: int) -> bytes:
        return b''.join(bytes((randint(0, 255),)) for _ in range(n))
if TYPE_CHECKING:
    from .tracking.accounts import AccountSync
    from .misc import VolatileFfid, LibraryAutoAddSource
    from .main import Works

import requests
import xbmcgui

from .http_request import (
    RequestHandler, RoutedServer, Route, request, Address, ANSWERED, Answered,
    HTTPStatusException, HTTPBadRequest, HTTPNotFound, HTTPUnprocessableContent, ExpectedJsonObjectError,
)
from .predefined import EMPTY_M3U, TT430
from .remote import RemoteCalls
from ..plugin_remote import REMOTE_PROPERTY, REMOTE_FILE, REMOTE_QUIT, RUN_PATH, ABORT_PATH, HOME_WINDOW, remote_address
from ..ff.control import plugin_id, busy_dialog, dataPath
from ..ff.settings import settings
from ..ff.logs import fflog, fflog_exc
# from ..ff.routing import Router
from ..ff.threads import Thread, Event, Lock
from ..ff.tricks import MISSING
from ..ff.types import JsonData, JsonResult
from ..ff.item import FFItem
from ..ff.db.db import Db, DbManager, DbMode, SqlConnection, SqlCursor
from ..ff.db import state
from ..ff.kotools import KodiRpc, kodi_abort_event
from ..defs import MediaRef
from const import const, StateMode

PS = ParamSpec('PS')
RouteResultValue: TypeAlias = Union[JsonResult, str]
RouteResult: TypeAlias = Union[Tuple[int, RouteResultValue], RouteResultValue]

DbClientId: TypeAlias = str


# DEBUG (command line tests)
if __name__ == '__main__':
    from ..ff.cmdline import DebugArgumentParser
    p = DebugArgumentParser()
    p.add_argument('-p', '--port', type=int, default=8123, help='server port')
    p.add_argument('-t', '--threading', action='store_true', help='multithreading / concurent requests')
    args = p.parse_args()


class SqlMethod(Enum):
    EXECUTE = 'execute'
    EXECUTE_MANY = 'executemany'
    EXECUTE_SCRIPT = 'executescript'
    COMMIT = 'commit'
    ROLLBACK = 'rollback'


@define
class DbClient:
    """Represents single client connection."""
    id: DbClientId
    db: Db
    cursor: SqlCursor


if TYPE_CHECKING:
    class ServerBase(ThreadingHTTPServer):
        pass
elif __name__ == '__main__' and not args.threading:  # DEBUG only !!!
    class ServerBase(HTTPServer):
        pass
else:
    class ServerBase(ThreadingHTTPServer):
        pass


class Server(RoutedServer, ServerBase):
    """FanFilm HTTP Server."""

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler] = RequestHandler,
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        super().__init__(server_address, RequestHandlerClass, works=works)
        self.db_lock = Lock()
        self.db_conns: Dict[DbClientId, Db] = {}
        self.db_clients: Dict[DbClientId, DbClient] = {}
        self.events: Dict[str, Event] = {} if works is None else works.events  # no copy - shared events
        self.account_sync: Optional['AccountSync'] = works and works.account_sync
        self.volatile_ffid: Optional['VolatileFfid'] = works and works.volatile_ffid
        self.media_files: Dict[str, bytes] = {}  # path -> content for scraper media proxied playlists
        self.link_folder: Dict[str, List[str]] = {}
        #: The plugin calls run in the service (`const.tune.service.remote_plugin`).
        self.remote_calls = RemoteCalls(on_reload=self.const_reloaded)

    def const_reloaded(self, changed: List[str]) -> None:
        """`local.py` was loaded again: publish the switch of the plugin calls again (on / off, the waits)."""
        publish_remote(str(self.url) if const.tune.service.remote_plugin.enabled else None)

    def _get_db_under_lock(self, name: str):
        """Get DB connection. MUST be under self.lock."""
        try:
            return self.db_conns[name]
        except KeyError:
            pass
        # DB manager is used only for create connection. Do NOT use manage methods here.
        manager = DbManager()
        path = manager.path_for_db(name)
        db = manager._create_connection(name, path, mode=DbMode.SEPARATED)
        self.db_conns[name] = db
        return db

    def _get_db(self, name: str):
        with self.db_lock:
            return self._get_db_under_lock(name)

    def _get_client(self, cid: Optional[DbClientId], name: str) -> DbClient:
        with self.db_lock:
            if cid:
                try:
                    return self.db_clients[cid]
                except KeyError:
                    pass
            while True:
                cid = randbytes(8).hex()
                if cid not in self.db_clients:
                    break
            db = self._get_db_under_lock(name)
            self.db_clients[cid] = client = DbClient(cid, db, db._conn.cursor())
            return client

    @Route.get(r'(?i).*\.avi')
    def avi_range(self) -> Answered:
        """Serve the range proxy of an OpenDML AVI (`<b64-of-cdn-url>.avi`), the answer written by the proxy."""
        from .avi_proxy import handle
        handle(request.handler)
        return ANSWERED

    @Route.get(r'/info?')
    def info(self) -> JsonResult:
        from ..ff.control import plugin_id
        return {
            'status': 'ok',
            'plugin': plugin_id,
        }

    # Off: any SQL on the FF databases, for manual tests only (any local program or web page could send it).
    # @Route.post(r'/db/(?P<name>\w+)/?')
    def db_query(self, name: str) -> JsonResult:
        """Handle SQL query POST."""
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        try:
            cid = data.get('cursor')
            method = SqlMethod(data.get('method', 'execute'))
            if method in (SqlMethod.COMMIT, ):
                query = ''
                params = ()
            else:
                query = data['query']
                if method == SqlMethod.EXECUTE_MANY:
                    params = data['params']
                else:
                    params = data.get('params', ())
        except (KeyError, ValueError):
            raise HTTPUnprocessableContent(message='innorect request')
        client = self._get_client(cid, name)
        with self.db_lock:
            if method is SqlMethod.EXECUTE:
                client.cursor.execute(query, params)
            elif method is SqlMethod.EXECUTE_MANY:
                client.cursor.executemany(query, params)
            elif method is SqlMethod.EXECUTE_SCRIPT:
                client.cursor.executescript(query)
            elif method is SqlMethod.COMMIT:
                client.cursor.connection.commit()
            elif method is SqlMethod.ROLLBACK:
                client.cursor.connection.rollback()
            return {
                'status': 'ok',
                'items': client.cursor.fetchall(),
                'lastrowid': client.cursor.lastrowid,
                'rowcount': client.cursor.rowcount,
            }

    @Route.post(r'/event/(?P<name>[a-zA-Z]\w*)(?:/(?P<action>\w+))?/?')
    def event_request(self, name: str, action: Optional[str] = None) -> JsonResult:
        """Remote service events support."""
        event = self.events.get(name)
        if event is None:
            raise HTTPNotFound(message=f'Event {name!s} not found')
        if not action:
            action = 'get'
        data = {'status': 'ok', 'event': name, 'action': action}
        if action == 'get':
            return data
        elif action == 'wait':
            result = event.wait()
            return {**data, 'state': result}
        elif action == 'set':
            event.set()
            return {**data, 'state': event.is_set()}
        elif action == 'clear':
            event.clear()
            return {**data, 'state': event.is_set()}
        else:
            raise HTTPUnprocessableContent(message=f'Unspotted event action {action!r}')

    @Route.post(r'/account/refresh/?')
    def account_refresh(self) -> JsonResult:
        """Refresh the access token of the account (the service is the only session owner, one lock per account)."""
        from ..ff.accounts import get_account, account_client
        account_id = request.json.get('id') if isinstance(request.json, Mapping) else None
        if not isinstance(account_id, str) or (account := get_account(account_id)) is None:
            raise HTTPNotFound(message=f'Account {account_id!r} not found')
        if not hasattr(client := account_client(account), '_refresh_token'):
            raise HTTPUnprocessableContent(message=f'Account {account_id!r} has no client with a token to refresh')
        return {'status': 'ok', 'action': 'refresh', 'id': account_id, 'refreshed': client._refresh_token()}

    @Route.post(r'/accounts/(?P<action>\w+)/?')
    def accounts_request(self, action: str) -> JsonResult:
        """
        The sync of accounts: `sync` of the `account` (none: all) - with a `timeout` it waits for their results (`changed`, the `failed`
        account IDs; null on timeout), `deliver` the waiting changes now (no waiting).
        """
        if self.account_sync is None:
            raise HTTPUnprocessableContent(message='The sync of accounts is not running')
        args = request.json if isinstance(request.json, Mapping) else {}
        data = {'status': 'ok', 'action': action}
        if action == 'sync':
            ids = self.account_sync.request(None if (account := args.get('account')) is None else [account])
            if not (timeout := args.get('timeout')):
                return data
            if (results := self.account_sync.wait(ids, timeout=timeout)) is None:
                return {**data, 'changed': None, 'failed': None}
            return {**data, 'changed': any(results.values()), 'failed': [account_id for account_id, result in results.items() if result is None]}
        elif action == 'deliver':
            self.account_sync.deliver_start()
            return data
        else:
            raise HTTPUnprocessableContent(message=f'Unspotted accounts action {action!r}')

    @Route.post(r'/service/restart/?')
    def service_restart(self) -> JsonResult:
        """Restart the service in a fresh interpreter: its loop ends (`FFMonitor.run()`), its end starts a new one (`restart_service()`)."""
        from .main import monitor
        monitor.restart = True
        return {'status': 'ok', 'action': 'restart'}

    @Route.get(r'/plugin/request/info/?')
    @Route.get(r'/folder/info/?')
    def get_plugin_request_info(self) -> JsonResult:
        """Get folder info."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    @Route.post(r'/plugin/request/enter/?')
    @Route.post(r'/folder/enter/?')
    def plugin_request_enter(self) -> JsonResult:
        """Enter into new plugin folder."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if not isinstance(request.json, Mapping):
            raise HTTPUnprocessableContent(message='innorect request, object requested')
        if not (url := request.json.get('url')):
            raise HTTPUnprocessableContent(message='"url" missing')
        enter_timestamp = request.json.get('timestamp')
        self.works.folder.enter(url, timestamp=enter_timestamp)
        if self.works.folder.locked:
            if event := self.events.get('folder'):
                fflog('[SERVICE] lock the folder')
                event.clear()  # folder is not ready if locked
        if const.tune.service.group_update_busy_dialog and self.works.folder.scan_started:
            busy_dialog(True)
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    @Route.post(rf'{RUN_PATH}/?')
    def plugin_run(self) -> JsonResult:
        """Run a plugin call of the thin plugin (`lib.plugin_remote`), answer when it answered Kodi."""
        data = request.json
        if not isinstance(data, Mapping) or not (call_id := data.get('call')) or not isinstance(argv := data.get('argv'), list) or len(argv) < 3:
            raise HTTPUnprocessableContent(message='"call" and "argv" expected')
        if (result := self.remote_calls.run(str(call_id), [str(arg) for arg in argv[:3]], folder=bool(data.get('folder')))) is None:
            raise HTTPStatusException(status_code=HTTPStatus.CONFLICT, data={'status': 'error', 'error': f'call {call_id!r} in use'})
        return result

    @Route.post(rf'{ABORT_PATH}/?')
    def plugin_abort(self) -> JsonResult:
        """Abort a plugin call: Kodi aborted its thin plugin."""
        data = request.json
        if not isinstance(data, Mapping) or not (call_id := data.get('call')):
            raise HTTPUnprocessableContent(message='"call" expected')
        return {'aborted': self.remote_calls.abort(str(call_id))}

    @Route.post(r'/plugin/request/mark/?')
    def plugin_request_mark(self) -> JsonResult:
        """Announce the scan of a show / season folder: Kodi (un)marks it natively (the FF menu)."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if not isinstance(request.json, Mapping) or not (path := request.json.get('path')):
            raise HTTPUnprocessableContent(message='"path" missing')
        self.works.folder.announce_mark(path)
        return {'status': 'ok'}

    @Route.post(r'/plugin/request/exit/?')
    @Route.post(r'/folder/exit/?')
    def plugin_request_exit(self) -> JsonResult:
        """Exit from list new plugin folder."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if const.tune.service.group_update_busy_dialog and self.works.folder.scan_finished:
            busy_dialog(False)
        if not isinstance(request.json, Mapping):
            raise HTTPUnprocessableContent(message='innorect request, object requested')
        if (folder_data := request.json.get('folder', MISSING)) is MISSING:
            raise HTTPUnprocessableContent(message='"folder" missing')
        if folder_data is None:
            folder = None
        else:
            folder = [FFItem.__from_json__(it) for it in folder_data]
        focus = request.json.get('focus', -1)
        exit_timestamp = request.json.get('timestamp')
        self.works.folder.exit(folder=folder, focus=focus, timestamp=exit_timestamp)
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    # DEBUG only (!!!)
    @Route.post(r'/plugin/request/ready/force/?')
    @Route.post(r'/folder/ready/force/?')
    def folder_force_ready(self, action: str = 'ready') -> JsonResult:
        """Handle folder ready event - force ready only."""
        if (event := self.events.get('folder')) is None:
            raise HTTPNotFound(message='Event folder not found')
        state = True
        if isinstance(request.json, Mapping):
            state = bool(request.json.get('set', True))
        if state:
            event.set()
        else:
            event.clear()
        # done = event.clear()
        return {
            'status': 'ok',
            'ready': event.is_set(),
        }

    @Route.route(('POST', 'GET'), r'/(?:plugin/request|folder)/(?P<action>ready)/?')
    def folder_ready(self, action: str = 'ready') -> JsonResult:
        """Handle folder ready event."""
        if (event := self.events.get('folder')) is None:
            raise HTTPNotFound(message='Event folder not found')
        timeout = request.json.get('timeout') if isinstance(request.json, Mapping) else None
        verbose = not event.is_set()
        if verbose:
            fflog('[FOLDER] wait')
        done = event.wait(timeout=timeout)
        if verbose:
            fflog(f'[FOLDER] {done = }')
        return {
            'status': 'ok',
            'ready': done,
        }

    @Route.post(r'/folder/content/?')
    def set_folder_content(self) -> JsonResult:
        """Handle set folder content (list of items)."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        self.works.folder.content = ...

    @Route.get(r'/progress/shows/?')
    def progress_shows(self) -> JsonResult:
        """
        The shows in progress (of the `account` if given; the aired episodes of the `first` shows read, the pages shown), computed
        here only (a running computation is joined).
        """
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        first = int(first) if (first := request.params.get('first')) else None
        shows = self.works.shows_progress.shows(account=request.params.get('account') or None, first=first)
        return {
            'status': 'ok',
            'shows': [ref.as_dict() for ref in shows],
        }

    @Route.get(r'/ffid/?')
    def list_ffid(self) -> JsonResult:
        """list all refs (filter by volatile ffid)."""
        if self.volatile_ffid is None:
            raise HTTPBadRequest(message='Volatile FFID is not supported')
        if 'ffid' in request.params:
            ffids = request.params.get('ffid', '')
            filters = {'ffid': ffids}
            refs = [{'ffid': ffid, 'ref': self.volatile_ffid.get(ffid)}
                    for ffid in map(int, ffids.split(','))]
        else:
            filters = {}
            refs = [{'ffid': ffid, 'ref': ref} for ffid, ref in self.volatile_ffid._refs.items()]
        return {
            'status': 'ok',
            'filters': filters,
            'refs': refs,
            }

    @Route.get(r'/ffid/(?P<ffid>\d+)/?')
    def get_ffid(self, ffid: int) -> JsonResult:
        """Get ref by volatile ffid."""
        if self.volatile_ffid is None:
            raise HTTPBadRequest(message='Volatile FFID is not supported')
        if ref := self.volatile_ffid.get(ffid):
            return {
                'status': 'ok',
                'ffid': ffid,
                'ref': ref.as_dict(),
            }
        raise HTTPNotFound(message=f'FFID {ffid} not found')

    @Route.post(r'/ffid/?')
    def create_ffid(self) -> JsonResult:
        """Create new volatile ffid for given ref."""
        if self.volatile_ffid is None:
            raise HTTPBadRequest(message='Volatile FFID is not supported')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if refs := data.get('refs'):
            try:
                return {
                    'status': 'ok',
                    'refs': [{'ffid': self.volatile_ffid.register(ref), 'ref': ref.as_dict()}
                             for ref_json in refs if (ref := MediaRef(**ref_json))],
                }
            except TypeError as exc:
                raise HTTPUnprocessableContent(message=f'incorrect `refs` format: {exc}`') from None
        raise HTTPUnprocessableContent(message='`refs` missing')

    @Route.get(r'/state/(?P<module>[^/]+)(?:/(?P<key>[^/]+))?/?')
    def state_get(self, module: str, key: str = '') -> JsonResult:
        """Get variables from virtual DB state."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if key:
            var = self.works.state.get(module=module, key=key)
            variables = [] if var is None else [var]
        else:
            variables = self.works.state.get_all(module=module)
        return {
            'status': 'ok',
            'variables': [asdict(var) for var in variables],
        }

    @Route.post(r'/state/?')
    def state_set(self) -> JsonResult:
        """Set variables in virtual DB state."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if (variables := data.get('variables')) and isinstance(variables, list):
            self.works.state.multi_set(variables)
        else:
            raise HTTPUnprocessableContent(message='"variables" missing')
        return {
            'status': 'ok',
        }

    @Route.delete(r'/state/(?P<module>[^/]+)(?:/(?P<key>[^/]+))?/?')
    def state_delete(self, module: str, key: str = '') -> JsonResult:
        """Delete variable or whole module from virtual DB state."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if key:
            var = self.works.state.delete(module=module, key=key)
            deleted = [] if var is None else [var]
        else:
            deleted = self.works.state.delete_all(module=module)
        return {
            'status': 'ok',
            'deleted': bool(deleted),
        }

    @Route.post(r'/state/wait/?')
    def state_wait(self) -> JsonResult:
        """Wait for variable value in virtual DB state."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        timeout: Optional[float] = data.get('timeout')
        if (var := data.get('wait_for')) and isinstance(var, Mapping) and (mod := var.get('module')) and (key := var.get('key')):
            res = self.works.state.wait_for(module=mod, key=key, value=var.get('value', True), timeout=timeout)
        else:
            raise HTTPUnprocessableContent(message='"wait_for" missing, or has no "module" and "key"')
        return {
            'status': 'ok',
            'result': res,
        }

    @Route.get(r'/media/tt430.mp4')
    def tt430(self) -> bytes:
        """Fake player (black) to avoid error on sources window cancel."""
        return TT430

    @Route.get(r'/media/(?:empty|stop).m3u8?')
    def stop_m3u(self) -> bytes:
        """Fake player (empty m38u playlist) to avoid error on sources window cancel."""
        return EMPTY_M3U

    @Route.get(r'/media(?P<key>/nm[^/]+\.m3u8)')
    def nm_playlist(self, key: str) -> bytes:
        """Serve NetMirror proxied HLS playlists (master + sub-playlists)."""
        try:
            return self.media_files[key]
        except KeyError:
            raise HTTPNotFound() from None

    @Route.post(r'/media(?P<key>/nm[^/]+\.m3u8)/?')
    def nm_playlist_set_one(self, key: str) -> JsonData:
        """Save NetMirror proxied HLS playlists (master + sub-playlists). Single file."""
        self.media_files[key] = request.content
        return {'status': 'ok'}

    @Route.post(r'/media/?')
    def nm_playlist_set_all(self) -> JsonData:
        """Save NetMirror proxied HLS playlists (master + sub-playlists). All files."""
        if not isinstance(request.json, Mapping):
            raise ExpectedJsonObjectError()
        self.media_files = {k: str(v).encode('utf-8') for k, v in request.json.items()}
        return {'status': 'ok'}

    @Route.delete(r'/media(?P<key>/nm[^/]+\.m3u8)/?')
    def nm_playlist_delete_one(self, key: str) -> None:
        """Clear NetMirror proxied HLS playlists (master + sub-playlists)."""
        del self.media_files[key]

    @Route.delete(r'/media/?')
    def nm_playlist_delete_all(self, key: str = '') -> None:
        """Clear NetMirror proxied HLS playlists (master + sub-playlists)."""
        self.media_files.clear()

    @Route.post(r'.*drm(?:cda)?=(?P<url>.*)')
    def drm(self, url: str) -> bytes:
        """DRM workaround."""
        #     if "@" in url:
        #         url, header_str = url.split('@')
        link = '?'.join((url, request.url.query))
        fflog(f'[SERVICE][DRM] {link=}')
        headers = {k: v for k, v in request.headers.items() if k not in ('Host', 'Content-Type')}
        post_data = request.content()
        fflog(f'[SERVICE][DRM] HTTP POST data {post_data!r}')
        resp = requests.post(url=url, headers=headers, data=post_data, params=request.params, verify=False)
        fflog(f'[SERVICE][DRM] HTTP Response {resp.status_code}, data {resp.content!r}')
        return resp.content

    @Route.get(r'/sleep/(?P<interval>\d+)')
    def sleep(self, interval: int) -> JsonData:
        """DEBUG. Sleep `interval` seconds."""
        from time import monotonic, sleep
        t = monotonic()
        if request.method != 'HEAD':
            sleep(interval)
        return {
            'slept': monotonic() - t,
        }

    @Route.get(r'/advanced_settings/?')
    def advanced_settings(self) -> JsonResult:
        from ..ff.settings import advanced_settings
        return advanced_settings.get()

    # @Route.get(r'/library/?')
    # def library_list(self) -> JsonResult:
    #     ...

    # @Route.get(r'/library/(?P<batch>\d+)/?')
    # def library_get(self, batch: int) -> JsonResult:
    #     ...

    @Route.post(r'/library/?')
    def library_add(self) -> JsonResult:
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if not self.works.library:
            raise HTTPUnprocessableContent(message='Library is not enabled')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        name = data.get('name')
        sync = data.get('sync')
        quiet = data.get('quiet', False)
        if (items := data.get('items')) and isinstance(items, list):
            batch_id = self.works.library.add([MediaRef.__from_json__(it) for it in items], name=name, sync=sync, quiet=quiet)
        else:
            raise HTTPUnprocessableContent(message='"items" missing')
        return {
            'status': 'ok',
            'batch': {
                'id': batch_id,
            },
        }

    @Route.post(r'/library/auto/?')
    def library_auto_add(self) -> JsonResult:
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if not self.works.library:
            raise HTTPUnprocessableContent(message='Library is not enabled')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        source: Optional[LibraryAutoAddSource] = data.get('source')
        # sync = data.get('sync')
        # quiet = data.get('quiet', False)
        if not source:
            raise HTTPUnprocessableContent(message='"source" missing')
        method = self.works.library_auto_add.get(source)
        if method is None:
            raise HTTPUnprocessableContent(message=f'{source!r} source handler missing')
        method()
        return {
            'status': 'ok',
        }

    @Route.get(r'virtual/folder/(?P<folder>\w+)/?')
    def virtual_folder_list(self, folder: str) -> JsonResult:
        """Get virtual folder links."""
        if folder not in self.link_folder:
            raise HTTPNotFound(message=f'Virtual folder {folder!r} not found')
        return {
            'status': 'ok',
            'folder': folder,
            'links': self.link_folder[folder],
        }


def publish_remote(url: 'str | None') -> None:
    """
    Tell the thin plugin (`lib.plugin_remote`) whether the service runs its calls of a handle (`url` of the server, None: not):
    the Home property ends its wait at Kodi start at once, the file tells the next Kodi start to wait for the service.
    """
    address = remote_address(url, abort_wait=const.tune.service.remote_plugin.abort_wait)
    path = Path(dataPath) / REMOTE_FILE
    try:
        if url:
            path.write_text(json.dumps({'startup_timeout': const.tune.service.startup_timeout}), encoding='utf-8')
        else:
            path.unlink(missing_ok=True)
    except OSError:
        fflog_exc()
    xbmcgui.Window(HOME_WINDOW).setProperty(REMOTE_PROPERTY, address)


class HttpProxy:
    """
    The main function that starts the HTTP Proxy server.
    """

    def __init__(self,
                 *,
                 works: Optional['Works'],
                 ) -> None:
        self._running: bool = False
        self._server: Optional[HTTPServer] = None
        self._httpd_thread: Optional[Thread] = None
        self.works: Optional['Works'] = works

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Start proxy server (in new therad)."""
        if self._running:
            return

        address = '127.0.0.1'  # Localhost
        try:
            # create HTTP server and start serve in new therad
            self._server = Server((address, RequestHandler.DEFAULT_PORT), RequestHandler, works=self.works)
            self._server.allow_reuse_address = True
            self._httpd_thread = Thread(target=self._server.serve_forever, kwargs={'poll_interval': const.tune.service.server_poll_interval},
                                        name='Service HTTP')
            self._httpd_thread.start()
            self._running = True
        except Exception:
            # creating HTTP server failed, clear URL in the settings
            state.set('url', None, module='service', mode=StateMode.DB)
            self._running = False
            fflog_exc()
            raise

        # the server runs: its URL for the plugin; a failed write (the state DB busy after all tries) does not stop it
        url = str(self._server.url)
        try:
            state.set('url', url, module='service', mode=StateMode.DB)
        except Exception:
            fflog_exc()
            fflog.error(f'Http Server URL {url} is not stored, the plugin finds the service only by its notification')
        fflog(f'=== Http Server Started: {url} ===')
        KodiRpc().notify('ServiceUpdate', {'url': url})
        publish_remote(url if const.tune.service.remote_plugin.enabled else None)

    def kodi_exit(self) -> None:
        """
        Kodi exits (`System.OnQuit`): the thin plugin ends its calls (waiting ones too) at once without an answer, the waiting
        calls of the service end (Kodi stops only after the plugin calls ended by themselves, it does not abort them).
        """
        xbmcgui.Window(HOME_WINDOW).setProperty(REMOTE_PROPERTY, REMOTE_QUIT)
        if isinstance(server := self._server, Server):
            server.remote_calls.kodi_exit()

    def reload_local(self) -> None:
        """Load `local.py` again if it changed and no plugin call runs (see `RemoteCalls.reload_local()`)."""
        if isinstance(server := self._server, Server):
            server.remote_calls.reload_local()

    def stop(self):
        """Stop proxy server."""
        if not self._running:
            return

        if kodi_abort_event.is_set():
            xbmcgui.Window(HOME_WINDOW).setProperty(REMOTE_PROPERTY, REMOTE_QUIT)  # Kodi exits: no call (not one waiting for the service)
        else:
            xbmcgui.Window(HOME_WINDOW).clearProperty(REMOTE_PROPERTY)  # the next plugin calls run in the plugin
        # shutdown and close the server
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server.socket.close()
            self._server = None
        if self._httpd_thread is not None:
            self._httpd_thread.join()
            self._httpd_thread = None
        self._running = False

        # Clear URL in the settings, the service stops while Kodi runs (e.g. add-on update).
        # Not on Kodi exit: the plug-in reads URL set after Kodi boot only and this synchronous DB write (fsync)
        # took 0.4-1.4 s of Kodi shutdown (the disk is busy with Kodi writes then).
        if not kodi_abort_event.is_set():
            state.set('url', None, module='service', mode=StateMode.DB)
        fflog('=== Http Server Stopped ===')


if __name__ == '__main__':
    from .misc import VolatileFfid
    from .main import Works
    address = '127.0.0.1'
    works = Works(
        events={
            'folder': Event(),
        },
        volatile_ffid=VolatileFfid()
    )
    works.events['folder'].set()
    server = Server((address, args.port), RequestHandler, works=works)
    server.allow_reuse_address = True
    server.serve_forever()
