# -*- coding: utf-8 -*-
"""
Debrid services: the universal resolvers of ResolveURL open the links of hostings and the magnets.

ResolveURL keeps the accounts (its settings: the keys, the tokens, which it refreshes itself, enabled, the priority);
FanFilm keeps nothing of them, it shows them and changes them through the resolvers (`debrid_accounts()`). A debrid
known to FanFilm is declared once (`DEBRIDS`): its short name, how to ask its account info and which torrents it has
cached (ready to play at once; Real-Debrid and AllDebrid do not tell any more).
"""

from __future__ import annotations
import re
from typing import Any, Callable, Iterator, Mapping, Sequence, TYPE_CHECKING
from attrs import frozen
from lib.ff import control
from lib.ff.logs import fflog, fflog_exc
if TYPE_CHECKING:
    from resolveurl.resolver import ResolveUrl
    from cdefs import PackKind
    from lib.defs import MediaRef


#: Global list of debrid resolvers (internal)
_debrid_resolvers: list[ResolveUrl] | None = None
#: Global list of debrid resolvers
debrid_resolvers: list[ResolveUrl]


@frozen(kw_only=True)
class DebridInfo:
    """The account info of a debrid service (its API)."""

    #: The user (a name or an e-mail).
    user: str = ''
    #: True if the account is premium (a free account opens nothing or little).
    premium: bool = False
    #: The end of premium (a UTC timestamp), None if not known.
    until: float | None = None


def _rd_info(data: Mapping[str, Any]) -> DebridInfo:
    """Return the info of a Real-Debrid account (`/rest/1.0/user`)."""
    from .calendar import utc_timestamp
    expiration = data.get('expiration')
    return DebridInfo(user=str(data.get('username') or ''), premium=data.get('type') == 'premium',
                      until=utc_timestamp(expiration) if expiration else None)


def _ad_info(data: Mapping[str, Any]) -> DebridInfo:
    """Return the info of an AllDebrid account (`/v4/user`)."""
    user = (data.get('data') or {}).get('user') or {}
    return DebridInfo(user=str(user.get('username') or ''), premium=bool(user.get('isPremium')), until=float(user.get('premiumUntil') or 0) or None)


def _pm_info(data: Mapping[str, Any]) -> DebridInfo:
    """Return the info of a Premiumize.me account (`/api/account/info`, `premium_until`: a timestamp or false)."""
    until = data.get('premium_until')
    return DebridInfo(user=str(data.get('customer_id') or ''), premium=bool(until), until=float(until) if until else None)


def _tb_info(data: Mapping[str, Any]) -> DebridInfo:
    """Return the info of a TorBox account (`/v1/api/user/me`, `plan`: 0 is the free one)."""
    from .calendar import utc_timestamp
    user = data.get('data') or {}
    expires = user.get('premium_expires_at')
    return DebridInfo(user=str(user.get('email') or ''), premium=bool(user.get('plan')), until=utc_timestamp(expires) if expires else None)


def _dl_info(data: Mapping[str, Any]) -> DebridInfo:
    """Return the info of a Debrid-Link account (`/api/v2/account/infos`, `premiumLeft`: seconds)."""
    from time import time
    user = data.get('value') or {}
    left = int(user.get('premiumLeft') or 0)
    return DebridInfo(user=str(user.get('pseudo') or ''), premium=left > 0, until=time() + left if left > 0 else None)


#: Hashes in one request of the cache check (the length of the address).
CACHE_CHUNK: int = 100


def _chunks(hashes: Sequence[str]) -> Iterator[Sequence[str]]:
    """Yield the hashes in the chunks of one request."""
    for i in range(0, len(hashes), CACHE_CHUNK):
        yield hashes[i:i + CACHE_CHUNK]


def _pm_cached(key: str, hashes: Sequence[str]) -> set[str]:
    """Return the cached ones of the hashes on Premiumize.me (`/api/cache/check`: a bool for each item, in order)."""
    from . import requests
    from const import const
    out: set[str] = set()
    for part in _chunks(hashes):
        resp = requests.get('https://www.premiumize.me/api/cache/check', params=[('items[]', h) for h in part],
                            headers={'Authorization': f'Bearer {key}'}, timeout=const.sources.resolve.cache_timeout)
        resp.raise_for_status()
        out.update(h for h, cached in zip(part, resp.json().get('response') or ()) if cached)
    return out


def _tb_cached(key: str, hashes: Sequence[str]) -> set[str]:
    """Return the cached ones of the hashes on TorBox (`/torrents/checkcached`: the cached torrents only)."""
    from . import requests
    from const import const
    out: set[str] = set()
    for part in _chunks(hashes):
        resp = requests.get('https://api.torbox.app/v1/api/torrents/checkcached', params={'hash': ','.join(part), 'format': 'list', 'list_files': 'false'},
                            headers={'Authorization': f'Bearer {key}'}, timeout=const.sources.resolve.cache_timeout)
        resp.raise_for_status()
        out.update(str(item.get('hash') or '').lower() for item in resp.json().get('data') or ())
    return out


@frozen(kw_only=True)
class DebridService:
    """A debrid service known to FanFilm (its ResolveURL resolver by the name)."""

    #: The name of its ResolveURL resolver (`ResolveUrl.name`).
    name: str
    #: The short name in the texts (the source list).
    short: str
    #: The setting of the resolver with the key or the token of the account (set: authorized).
    key: str = 'token'
    #: The address of the account info (the key as `Authorization: Bearer`), '' if none.
    info_url: str = ''
    #: The account info of the answer of `info_url`.
    info: Callable[[Mapping[str, Any]], DebridInfo] | None = None
    #: The cached ones of the torrent hashes (the key of the account, the hashes), None: the service does not tell.
    cached: Callable[[str, Sequence[str]], set[str]] | None = None


#: The debrid services known to FanFilm (the others are shown by their ResolveURL name).
DEBRIDS: tuple[DebridService, ...] = (
    DebridService(name='Real-Debrid', short='RD', info_url='https://api.real-debrid.com/rest/1.0/user', info=_rd_info),
    DebridService(name='AllDebrid', short='AD', info_url='https://api.alldebrid.com/v4/user?agent=fanfilm', info=_ad_info),
    DebridService(name='Premiumize.me', short='PM', info_url='https://www.premiumize.me/api/account/info', info=_pm_info, cached=_pm_cached),
    DebridService(name='TorBox', short='TB', key='apikey', info_url='https://api.torbox.app/v1/api/user/me?settings=false', info=_tb_info,
                  cached=_tb_cached),
    DebridService(name='Debrid-Link', short='DL', info_url='https://debrid-link.fr/api/v2/account/infos', info=_dl_info),
    DebridService(name='OffCloud', short='OC', key='apikey'),
    DebridService(name='Linksnappy', short='LS', key='username'),
    DebridService(name='MegaDebrid', short='MD', key='username'),
    DebridService(name='Simply-Debrid', short='SD', key='username'),
    DebridService(name='RPnet', short='RP', key='username'),
    DebridService(name='CocoLeech', short='CL', key='apikey'),
    DebridService(name='Boxbit', short='BB'),
)


#: The most letters of the initials made of the capitals of a resolver name (a debrid FanFilm does not know).
INITIALS: int = 2


def debrid_service(name: str) -> DebridService | None:
    """Return the debrid service of the resolver name (any case), None if FanFilm does not know it."""
    name = name.lower()
    return next((srv for srv in DEBRIDS if srv.name.lower() == name), None)


def debrid_short_name(name: str) -> str:
    """Return the short name of the debrid of the resolver name (`RD`), the name itself if FanFilm does not know it."""
    return srv.short if (srv := debrid_service(name)) else name


@frozen(kw_only=True)
class DebridAccount:
    """The account of a debrid service in ResolveURL (a view: ResolveURL keeps it)."""

    #: The ResolveURL resolver (its class: the settings are of the class).
    resolver: Any
    #: The service, None if FanFilm does not know it.
    service: DebridService | None
    #: True if the account has its key or token.
    authorized: bool
    #: True if the resolver is enabled in ResolveURL.
    enabled: bool
    #: Its priority in ResolveURL (lower first).
    priority: int

    @property
    def name(self) -> str:
        """Return the name of the service (of the resolver)."""
        return str(self.resolver.name)

    @property
    def short(self) -> str:
        """Return the short name (`RD`)."""
        return self.service.short if self.service else self.name

    @property
    def initials(self) -> str:
        """Return the initials (a badge): the short name of a known service (`RD`), else the capitals of the name (`NewDebrid`: `ND`, `Zapdl`: `Z`)."""
        if self.service:
            return self.service.short
        return ''.join(c for c in self.name if c.isupper())[:INITIALS] or self.name[:1].upper()

    @property
    def active(self) -> bool:
        """Return True if the debrid opens sources now: authorized and enabled."""
        return self.authorized and self.enabled

    @property
    def can_authorize(self) -> bool:
        """Return True if ResolveURL authorizes the account itself (a code, a PIN); else its settings."""
        return callable(getattr(self.resolver, 'authorize_resolver', None))

    @property
    def can_revoke(self) -> bool:
        """Return True if ResolveURL can forget the authorization."""
        return self.authorized and callable(getattr(self.resolver, 'reset_authorization', None))


def _resolver_classes() -> list[Any]:
    """Return the universal resolvers of ResolveURL (the disabled ones too) in their priority order, [] without ResolveURL."""
    try:
        import resolveurl
        classes = resolveurl.relevant_resolvers(include_universal=True, include_popups=True, include_disabled=True, order_matters=True)
    except Exception:
        fflog_exc()
        return []
    return [cls for cls in classes if cls.isUniversal()]


def _authorized(resolver: Any, service: DebridService | None) -> bool:
    """Return True if the account of the resolver has its key (an unknown service: enabled with its login, ResolveURL tells)."""
    if service is not None:
        return bool(resolver.get_setting(service.key))
    return bool(resolver._is_enabled())


def debrid_accounts() -> list[DebridAccount]:
    """
    Return the debrid accounts of ResolveURL in their priority order (the ones not authorized too): of the same priority
    the authorized ones first (ResolveURL uses only them; their own order stays).
    """
    out: list[DebridAccount] = []
    for cls in _resolver_classes():
        service = debrid_service(cls.name)
        out.append(DebridAccount(resolver=cls, service=service, authorized=_authorized(cls, service),
                                 enabled=cls.get_setting('enabled') == 'true', priority=cls._get_priority()))
    return sorted(out, key=lambda acc: (acc.priority, not acc.authorized))


def invalidate() -> None:
    """Forget the debrid resolvers of the process (a debrid account changed: the next search asks ResolveURL again)."""
    global _debrid_resolvers
    _debrid_resolvers = None


def debrids_allowed() -> bool:
    """Return True if ResolveURL uses the debrid services at all (its setting `allow_universal`)."""
    try:
        from resolveurl import common
        return common.get_setting('allow_universal') == 'true'
    except Exception:
        fflog_exc()
        return False


def set_debrids_allowed(allowed: bool) -> None:
    """Allow or forbid the debrid services in ResolveURL."""
    from resolveurl import common
    common.set_setting('allow_universal', 'true' if allowed else 'false')
    invalidate()


def authorize(account: DebridAccount) -> bool:
    """Authorize the account by ResolveURL (its dialog: a code or a PIN), enable it; return True if authorized."""
    try:
        account.resolver().authorize_resolver()
    except Exception:
        fflog_exc()
    if authorized := _authorized(account.resolver, account.service):
        account.resolver.set_setting('enabled', 'true')
    invalidate()
    return authorized


def revoke(account: DebridAccount) -> None:
    """Forget the authorization of the account in ResolveURL."""
    try:
        account.resolver().reset_authorization()
    finally:
        invalidate()


def set_enabled(account: DebridAccount, enabled: bool) -> None:
    """Enable or disable the debrid in ResolveURL (its account stays)."""
    account.resolver.set_setting('enabled', 'true' if enabled else 'false')
    invalidate()


def move(account: DebridAccount, delta: int) -> bool:
    """
    Move the debrid in the priority order (`delta`: -1 up, 1 down), return False if it can not move. The debrids get
    the priorities from the lowest of them on, one by one (ResolveURL sorts by the priority, the same ones by chance).
    """
    accounts = debrid_accounts()
    names = [acc.name for acc in accounts]
    if account.name not in names or not 0 <= (pos := names.index(account.name)) + delta < len(accounts):
        return False
    accounts.insert(pos + delta, accounts.pop(pos))
    start = min(acc.priority for acc in accounts)
    for n, acc in enumerate(accounts):
        if acc.priority != start + n:
            acc.resolver.set_setting('priority', str(start + n))
    invalidate()
    return True


def account_info(account: DebridAccount) -> DebridInfo | None:
    """
    Return the account info from the debrid service (its key or token of ResolveURL), None if not known (no API, not
    authorized, an error). A token not accepted is refreshed by ResolveURL (it keeps it), then asked once more.
    """
    from . import requests
    if not account.authorized or (service := account.service) is None or not service.info_url or service.info is None:
        return None
    for retry in (True, False):
        try:
            resp = requests.get(service.info_url, headers={'Authorization': f'Bearer {account.resolver.get_setting(service.key)}'}, timeout=10)
            if resp.status_code == 401 and retry and callable(refresh := getattr(account.resolver(), 'refresh_token', None)):
                refresh()
                continue
            if resp.status_code != 200:
                fflog(f'[DEBRID] {account.name} account info: {resp.status_code}')
                return None
            return service.info(resp.json())
        except Exception:
            fflog_exc()
            return None
    return None


def get_resolvers() -> list[ResolveUrl]:
    """Get a list of available debrid resolvers."""
    global _debrid_resolvers
    if _debrid_resolvers is None:
        try:
            import resolveurl

            _debrid_resolvers = [
                resolver()
                for resolver in resolveurl.relevant_resolvers(order_matters=True)
                if resolver.isUniversal()
            ]
            if len(_debrid_resolvers) == 0:
                # Support Rapidgator accounts! Unfortunately, `sources.py` assumes that rapidgator.net is only ever
                # accessed via a debrid service, so we add rapidgator as a debrid resolver and everything just works.
                # As a bonus(?), rapidgator links will be highlighted just like actual debrid links
                _debrid_resolvers = [
                    resolver()
                    for resolver in resolveurl.relevant_resolvers(
                        order_matters=True, include_universal=False
                    )
                    if "rapidgator.net" in resolver.domains
                ]
        except Exception:
            fflog_exc('[DEBRID] no resolvers of ResolveURL')  # not silent: no debrid in the search then
            _debrid_resolvers = []
    return _debrid_resolvers


def status() -> bool:
    """Check if any debrid resolvers are enabled."""
    return bool(_debrid_resolvers)


def tor_enabled() -> bool:
    enabled = control.setting('torrent.enabled')  # XXX missing setting 'torrent.enabled'
    return enabled == 'true'


def pack_file(names: Sequence[str], season: int, episode: int, *, kind: PackKind = 'season') -> int | None:
    """
    Return the index of the file of the episode in a torrent pack by its name (`S01E02`, `s1e2`, `S01.E02`, `1x02`; in a
    season pack also `E02` / `Episode 2` if only one file has it), samples skipped; None if no file matches.
    """
    names = [name if 'sample' not in name.lower() else '' for name in names]
    rx = re.compile(rf'(?<![a-z0-9])(?:s0*{season}[ ._-]?e0*{episode}|0*{season}x0*{episode})(?!\d)', re.IGNORECASE)
    if (found := next((i for i, name in enumerate(names) if rx.search(name)), None)) is not None or kind != 'season':
        return found
    rx = re.compile(rf'(?<![a-z0-9])(?:e|ep|episode)[ ._-]?0*{episode}(?!\d)', re.IGNORECASE)
    hits = [i for i, name in enumerate(names) if rx.search(name)]
    return hits[0] if len(hits) == 1 else None


def resolver(url, debrid, *, pack: PackKind | None = None, ref: MediaRef | None = None) -> str | None:
    """
    Resolve a URL using the specified debrid service. A torrent `pack` opens the file of the episode `ref` (found by its
    name, else chosen by the user), the debrid gives all files of the pack.
    """
    try:
        if debrid_resolver := next(iter(resolver for resolver in get_resolvers() if resolver.name == debrid), None):
            debrid_resolver.login()
            if host_and_id := debrid_resolver.get_host_and_id(url):
                host, media_id = host_and_id
                if pack and ref is not None and ref.season is not None and ref.episode is not None:
                    files = debrid_resolver.get_media_url(host, media_id, return_all=True) or []
                    names = [str(file.get('name') or '') for file in files]
                    if (index := pack_file(names, ref.season, ref.episode, kind=pack)) is None:
                        from lib.kolang import L
                        index = control.selectDialog(names, heading=L(30532, 'Choose the file of the episode'))
                        if index < 0:
                            return None
                    fflog(f'[DEBRID] {debrid} pack file {names[index]!r} for S{ref.season:02d}E{ref.episode:02d}')
                    if not (host_and_id := debrid_resolver.get_host_and_id(link := files[index]['link'])):
                        return link
                    host, media_id = host_and_id
                stream_url = debrid_resolver.get_media_url(host, media_id)
                return stream_url
    except Exception as e:
        fflog.warning(f'{debrid} Resolve Failure: {e}')
    return None


def __getattr__(name: str) -> list[type[ResolveUrl]]:
    """Lazy load debrid resolvers."""
    if name == 'debrid_resolvers':
        return get_resolvers()
    raise AttributeError(name)


def cached_hashes(resolver: Any, hashes: Sequence[str]) -> set[str] | None:
    """Return the cached ones of the torrent hashes on the debrid of the resolver, None if not known (no API, an error)."""
    if (service := debrid_service(resolver.name)) is None or service.cached is None or not (key := resolver.get_setting(service.key)):
        return None
    try:
        return service.cached(key, hashes)
    except Exception as exc:
        fflog(f'[DEBRID] {resolver.name} cache check failed: {exc}')
        return None
