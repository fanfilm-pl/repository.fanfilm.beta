"""
The keys of the user filters and the user sorting of the sources: one declaration of what a source is filtered and sorted
by (`SOURCE_KEYS`). The keys of the facts come from their types (`lib.sdk.facts.types`: a vocabulary is one value, a list
of it a set, a bool a flag, a number or a text values seen in the sources; a field of the audio or subtitle tracks is of
any track, `ROUTE_FIELDS` of the main audio track only), the others are declared here (the quality, the size, the provider,
the ways to open a source, the localization...). The values of a source at a key are texts, none is unknown.

A user state (`SelectionState`: JSON data, the filter and the sort) is compiled once (`Selection`), not read for every source:

- the filter: in a key the "must" values are OR-ed, a "must not" value cuts, the keys are AND-ed; a source with no value of
  a key (unknown) passes unless the unknown value (`UNKNOWN`) of the key is "must not"; a range cuts a value out of it;
- the sort: a criterion is a key with the order of its values (the unknown one in it, else at the end) or a direction (a
  number); the localization (`lang`) ranks every way of a source (its languages and the ways they are given) and picks its
  main audio track (the keys of the main track are of it).
"""

from __future__ import annotations
from enum import Enum
from typing import Any, Callable, Iterable, Iterator, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias, TypedDict
from attrs import frozen, evolve
from .types import get_type_hints, get_args, is_optional
from .source_facts import label as fact_label, audio_language
from ..sdk.facts import Term, VideoFacts, AudioTrack, SubtitleTrack, ReleaseFacts, VideoCodec, Hdr, ReleaseSource, SubtitleKind, TrackKind
from ..kolang import L
from cdefs import ResolveKind
from const import const
if TYPE_CHECKING:
    from ..sources import Source


#: The kind of a key: one value (`enum`), a set of values (`set`), a flag, a number in a range (`range`: filtered by its range,
#: sorted by its number), a number only to sort by (`number`), a pair of a language and the way it is given (`pair`).
KeyKind: TypeAlias = Literal['enum', 'set', 'flag', 'range', 'number', 'pair']

#: The value of an unknown fact (a source says nothing) in the states.
UNKNOWN: str = ''
#: The derived value of a dubbing from a cinema copy (the key of the recording of the audio).
CINEMA_DUBBING: str = 'cinema_dubbing'
#: The derived value of a source with subtitles and no Polish audio (the key of the kind of the subtitles).
NO_POLISH_AUDIO: str = 'no_polish_audio'

#: The text of a flag set.
TRUE: str = 'true'
#: The text of a flag not set.
FALSE: str = 'false'
#: The texts of a flag (the values of its leaves).
FLAG_VALUES: tuple[str, str] = (TRUE, FALSE)
#: The labels of a flag.
FLAG_LABELS: dict[str, str] = {TRUE: L(30698, 'yes'), FALSE: L(30699, 'no')}
#: The label of the unknown value of a key.
UNKNOWN_LABEL: str = L(30872, 'unknown')
#: The label of the unknown value of the localization: a source of no audio track and no subtitles known (not a way of an unknown language).
NO_LANG_LABEL: str = L(30893, 'no language data')

#: The language of a way of a source in no language of the user (`Selection.langs`).
OTHER_LANGUAGE: str = 'other'

#: The way of the subtitles of a language (`lang` pairs; the audio tracks give the kinds of their tracks).
SUBTITLES_WAY: str = 'subtitles'

#: The qualities of the sources, the lowest first (`Source['quality']`, the vocabulary of the protocol; CAM, SCR: the release kinds
#: the old providers give as a quality).
QUALITY_SCALE: tuple[str, ...] = ('CAM', 'SCR', 'SD', '720p', '1080p', '4K')

#: Bytes of a gigabyte (the unit of the size range).
GB: int = 1024 ** 3

#: The groups of the facts and their types (the tracks: a list of them).
FACT_TYPES: dict[str, type] = {'video': VideoFacts, 'audio': AudioTrack, 'subtitles': SubtitleTrack, 'release': ReleaseFacts}

#: The groups of the tracks (lists of tracks in the facts).
TRACK_GROUPS: frozenset[str] = frozenset({'audio', 'subtitles'})

#: The fields of the audio tracks of the main track only (what is heard: an AC3 track in English does not count with a Polish voice-over).
ROUTE_FIELDS: frozenset[str] = frozenset({'codec', 'channels', 'atmos'})

#: The fields of the tracks in the localization (`lang` pairs), not keys of their own.
PAIR_FIELDS: frozenset[str] = frozenset({'audio.lang', 'audio.kind', 'subtitles.lang'})

#: HDR formats a Dolby Vision video falls back to on a display without DV.
DV_FALLBACK: frozenset[Hdr] = frozenset((Hdr.HDR, Hdr.HDR10, Hdr.HDR10_PLUS, Hdr.HLG))

@frozen
class KeyLabel:
    """
    The label of a key, of a group: in full (a node, a criterion), as a leaf of its group (no word of the group again; '' the full one),
    what it is (the help of its criterion of the sort; '' the label says it).
    """

    #: The label.
    label: str
    #: The label as a leaf of its group in the tree of the filter.
    leaf: str = ''
    #: What the key is (a criterion of the sort in its help), '' the label says it.
    about: str = ''


#: The labels of the keys and of their groups (the fact keys are named by their paths).
KEY_LABELS: dict[str, KeyLabel] = {
    'video': KeyLabel(L(30823, 'Video')),
    'video.codec': KeyLabel(L(30824, 'Video codec')),
    'video.hdr': KeyLabel(L(30825, 'HDR')),
    'video.bit_depth': KeyLabel(L(30826, 'Color depth')),
    'video.three_d': KeyLabel(L(30827, '3D')),
    'video.height': KeyLabel(L(30828, 'Frame height')),
    'video.fps': KeyLabel(L(30829, 'Frame rate')),
    'video.sign_language': KeyLabel(L(30830, 'Sign language')),
    'video.colorized': KeyLabel(L(30831, 'Colorized')),
    'video.ai': KeyLabel(L(30832, 'AI video'), leaf=L(30878, 'AI')),
    'audio': KeyLabel(L(30833, 'Audio')),
    'audio.codec': KeyLabel(L(30834, 'Audio codec')),
    'audio.channels': KeyLabel(L(30835, 'Channels')),
    'audio.atmos': KeyLabel(L(30836, 'Dolby Atmos')),
    'audio.recording': KeyLabel(L(30837, 'Cinema recording')),
    'audio.ai': KeyLabel(L(30838, 'AI voice'), leaf=L(30878, 'AI')),
    'subtitles': KeyLabel(L(30839, 'Subtitles')),
    'subtitles.kind': KeyLabel(L(30840, 'Subtitles kind')),
    'subtitles.burned': KeyLabel(L(30841, 'Burned subtitles'), leaf=L(30879, 'Burned')),
    'subtitles.ai': KeyLabel(L(30842, 'AI subtitles'), leaf=L(30878, 'AI')),
    'release': KeyLabel(L(30843, 'Release')),
    'release.source': KeyLabel(L(30844, 'Release source')),
    'release.remux': KeyLabel(L(30845, 'Remux')),
    'release.edition': KeyLabel(L(30846, 'Edition')),
    'release.container': KeyLabel(L(30847, 'Container')),
    'release.proper': KeyLabel(L(30848, 'Proper')),
    'release.repack': KeyLabel(L(30849, 'Repack')),
    'release.drm': KeyLabel(L(30850, 'DRM')),
    'lang': KeyLabel(L(30851, 'Language'), about=L(30894, 'your languages first (the languages of the providers in the settings), then other ones,'
                                                  ' unknown; in each the ways: {ways}; a source by its best way')),
    'quality': KeyLabel(L(30852, 'Quality')),
    'size': KeyLabel(L(32645, 'Size')),
    'provider': KeyLabel(L(30854, 'Provider'), about=L(30904, 'the sources of a provider together, the providers by their names')),
    'hosting': KeyLabel(L(30855, 'Hosting'), about=L(30905, 'the sources of a hosting together, the hostings by their names')),
    'route': KeyLabel(L(30856, 'Opened by')),
    'cached': KeyLabel(L(30857, 'Cached torrent'), about=L(30906, 'a torrent in the cache of a debrid service, it opens at once')),
    'premium': KeyLabel(L(30301, 'Premium'), about=L(30907, 'a source of a paid provider, opened by its account')),
    'pack': KeyLabel(L(30470, 'Season pack'), about=L(30908, 'the whole season in one source')),
    'transfer_short': KeyLabel(L(30858, 'Not enough transfer'), about=L(30909, 'the transfer left on the account is less than the source')),
    'language': KeyLabel(L(30955, 'Audio language'),
                         about=L(30956, 'the language of the audio alone, whatever its way: the order of the add-on (Polish, MULTI, English...)')),
    'origin': KeyLabel(L(30859, 'Origin'), about=L(30910, 'downloaded, the library, Plex, Jellyfin, other add-ons; a source on your account higher')),
    'priority': KeyLabel(L(30860, 'Provider priority'),
                         about=L(30911, 'the setting “Priority” of the branch of the provider in the Configuration, Sources (bigger first)')),
}


class Route(TypedDict):
    """A way of a source to the user: a language and the way it is given (a pair `<lang>/<way>`), its audio track (None: subtitles)."""

    #: The pair (`<lang>/<way>`).
    value: str
    #: The audio track (None: a subtitle track).
    track: AudioTrack | None


@frozen(kw_only=True)
class SourceView:
    """A source as the keys see it: its ways (the localization), its main audio track (the first way of audio), its priority."""

    #: The source.
    source: Source
    #: The ways of the source (the best first by the localization order of the selection).
    routes: tuple[Route, ...]
    #: The main audio track (None: no audio track is known).
    audio: AudioTrack | None
    #: The priority of the provider (bigger first): its branch of the tree of the source providers, else the rules.
    priority: int


#: The values of a source at a key (none: unknown).
KeyGetter: TypeAlias = 'Callable[[SourceView], frozenset[str]]'
#: The number of a source at a key (None: unknown).
NumberGetter: TypeAlias = 'Callable[[SourceView], float | None]'


@frozen(kw_only=True)
class DerivedValue:
    """A value derived from more facts (a fact key gets it beside its own values): `test` of the facts of the source."""

    #: The key.
    path: str
    #: The value.
    value: str
    #: The label.
    label: str
    #: Check the facts of a source.
    test: Callable[[Mapping[str, Any]], bool]


def _dv_only(facts: Mapping[str, Any]) -> bool:
    """Check if a Dolby Vision video has no HDR fallback (profile 5: wrong colours without DV); a Blu-ray or a remux has it always."""
    video = facts.get('video', {})
    release = facts.get('release', {})
    hdr = set(video.get('hdr', ()))
    return Hdr.DOLBY_VISION in hdr and not hdr & DV_FALLBACK and not release.get('remux') and release.get('source') != ReleaseSource.BLURAY


def _hi10p(facts: Mapping[str, Any]) -> bool:
    """Check if a video is H.264 of 10 bits or more (Hi10P: no hardware decoding)."""
    video = facts.get('video', {})
    return video.get('codec') == VideoCodec.H264 and video.get('bit_depth', 8) >= 10


def _cinema_dubbing(facts: Mapping[str, Any]) -> bool:
    """Check if a dubbing comes from a cinema copy (a camera release: its sound recorded in a cinema)."""
    return facts.get('release', {}).get('source') == ReleaseSource.CAM and any(track.get('kind') == TrackKind.DUBBING for track in facts.get('audio', ()))


def _no_polish_audio(facts: Mapping[str, Any]) -> bool:
    """Check if a source with subtitles has no Polish audio (the language of the old setting of the subtitles: Polish, whatever the languages of the user)."""
    return bool(facts.get('subtitles')) and audio_language(facts.get('audio', ())) != 'pl'


#: The derived values of the fact keys.
DERIVED_VALUES: tuple[DerivedValue, ...] = (
    DerivedValue(path='video.hdr', value='dolby_vision_only', label=L(30861, 'DV without HDR'), test=_dv_only),
    DerivedValue(path='video.codec', value='hi10p', label='Hi10P', test=_hi10p),
    DerivedValue(path='audio.recording', value=CINEMA_DUBBING, label=L(30952, 'Cinema dubbing'), test=_cinema_dubbing),
    DerivedValue(path='subtitles.kind', value=NO_POLISH_AUDIO, label=L(30953, 'Subtitles, no Polish audio'), test=_no_polish_audio),
)


@frozen(kw_only=True)
class SourceKey:
    """A key of the filters and the sorting of the sources."""

    #: The path (`video.codec`, `quality`...): the key in the states.
    path: str
    #: The kind.
    kind: KeyKind
    #: The label.
    label: str
    #: The label as a leaf of its group (a flag in the tree of the filter; '' the label).
    leaf_label: str = ''
    #: The values in their order (the leaves of the filter tree, the default sort order), () - the values of the sources.
    values: tuple[str, ...] = ()
    #: The labels of the values (a value without one: its text).
    labels: Mapping[str, str] = {}
    #: The values of a source (texts, none: unknown).
    get: KeyGetter
    #: The number of a source (`range`, `number`: the filter range, the sort), None: no number.
    number: NumberGetter | None = None
    #: The group in the tree (a group of the facts, '' none).
    group: str = ''

    @property
    def filtered(self) -> bool:
        """Check if the key is a filter (not only a sort criterion)."""
        return self.kind != 'number'

    def value_label(self, value: str) -> str:
        """Return the label of a value of the key (the unknown one: its own label, else `UNKNOWN_LABEL`)."""
        if (label := self.labels.get(value)):
            return label
        return UNKNOWN_LABEL if value == UNKNOWN else value


def key_labels(path: str) -> dict[str, str]:
    """Return the labels of a key (`KEY_LABELS`, none: its path) as the fields of `SourceKey`: its label, its label as a leaf."""
    labels = KEY_LABELS.get(path) or KeyLabel(path)
    return {'label': labels.label, 'leaf_label': labels.leaf}


def value_text(value: Any) -> str:
    """Return the text of a fact value (a vocabulary value: its formal name, a flag: `true` / `false`)."""
    if isinstance(value, bool):
        return TRUE if value else FALSE
    if isinstance(value, Enum):
        return str(value.value)
    return str(value)


def _texts(value: Any) -> Iterator[str]:
    """Iterate over the texts of a fact value (a list: of every item, None: none)."""
    if value is None:
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            yield value_text(item)
    else:
        yield value_text(value)


@frozen(kw_only=True)
class FieldKind:
    """The kind of a fact key by the type of its field: the kind, the values, their labels."""

    #: The kind.
    kind: KeyKind
    #: The values (() - of the sources).
    values: tuple[str, ...] = ()
    #: The labels of the values.
    labels: Mapping[str, str] = {}


def _vocabulary(vocab: type[Term]) -> FieldKind:
    """Return the values of a vocabulary and their labels (`FACT_LABELS`)."""
    return FieldKind(kind='enum', values=tuple(str(term.value) for term in vocab), labels={str(term.value): fact_label(term) for term in vocab})


def _field_kind(tp: Any, *, track: bool, route: bool) -> FieldKind:
    """Return the kind of a fact key, its values and their labels by the type of its field (a field of any track is a set)."""
    if is_optional(tp):
        tp = next(arg for arg in get_args(tp) if arg is not type(None))
    if isinstance(tp, type) and issubclass(tp, bool):
        field = FieldKind(kind='flag', values=FLAG_VALUES, labels=FLAG_LABELS)
    elif isinstance(tp, type) and issubclass(tp, Term):
        field = _vocabulary(tp)
    elif (args := get_args(tp)) and isinstance(args[0], type) and issubclass(args[0], Term):  # a list of a vocabulary
        field = evolve(_vocabulary(args[0]), kind='set')
    else:  # a number, a text: the values of the sources
        field = FieldKind(kind='enum')
    if track and not route and field.kind == 'enum':
        field = evolve(field, kind='set')
    return field


def _fact_getter(group: str, field: str, derived: Sequence[DerivedValue]) -> KeyGetter:
    """Return the getter of a fact key: of the group (video, release), of any track or of the main audio track (`ROUTE_FIELDS`)."""
    if group in TRACK_GROUPS:
        if group == 'audio' and field in ROUTE_FIELDS:
            def get(view: SourceView) -> frozenset[str]:
                """Return the value of the main audio track."""
                return frozenset(_texts(view.audio.get(field))) if view.audio is not None else frozenset()
        else:
            def get(view: SourceView) -> frozenset[str]:
                """Return the values of all tracks (the derived values too)."""
                facts: Mapping[str, Any] = view.source.facts
                values = {text for track in facts.get(group, ()) for text in _texts(track.get(field))}
                values.update(der.value for der in derived if der.test(facts))
                return frozenset(values)
        return get

    def get_group(view: SourceView) -> frozenset[str]:
        """Return the value of the group (its derived values too)."""
        facts: Mapping[str, Any] = view.source.facts
        values = set(_texts(facts.get(group, {}).get(field)))
        values.update(der.value for der in derived if der.test(facts))
        return frozenset(values)
    return get_group


def fact_keys() -> Iterator[SourceKey]:
    """Iterate over the keys of the facts (`FACT_TYPES`), derived from their types; the skipped ones (`const`) and the pairs left out."""
    skip = set(const.sources.filters.skip_keys) | PAIR_FIELDS
    for group, td in FACT_TYPES.items():
        for field, tp in get_type_hints(td).items():
            path = f'{group}.{field}'
            if path in skip:
                continue
            derived = tuple(der for der in DERIVED_VALUES if der.path == path)
            kind = _field_kind(tp, track=group in TRACK_GROUPS, route=group == 'audio' and field in ROUTE_FIELDS)
            yield SourceKey(path=path, kind=kind.kind, **key_labels(path), values=(*kind.values, *(der.value for der in derived)),
                            labels={**kind.labels, **{der.value: der.label for der in derived}}, get=_fact_getter(group, field, derived), group=group)


def _quality(view: SourceView) -> float | None:
    """Return the rank of the quality of a source (`QUALITY_SCALE`), None if unknown."""
    quality = view.source.get('quality') or ''
    return float(QUALITY_SCALE.index(quality)) if quality in QUALITY_SCALE else None


def _size(view: SourceView) -> float | None:
    """Return the size of a source in GB, None if unknown."""
    return view.source.size / GB if view.source.size else None


#: The origins of the sources first in the default order (a rule may give its own order: `SourceAttribute.order`).
ORIGIN_PROVIDERS: tuple[str, ...] = ('download', 'library', 'plex', 'jellyfin', 'external')


def _language(view: SourceView) -> float | None:
    """Return the rank of the language of a source (of its audio, `source_language()`; `const.sources.language_order`), None if out of it."""
    order = tuple(const.sources.language_order)
    language = view.source.get('language', '')
    return float(order.index(language)) if language in order else None


def _origin(view: SourceView) -> float | None:
    """
    Return the origin of a source (bigger first): a rule order (`SourceAttribute.order`), else the downloaded, the library, Plex,
    Jellyfin, an external add-on (2005 ... 2001) and on the account (+1000).
    """
    src = view.source
    if (order := src.attr.order) is not None:
        return float(order)
    order = 0
    for i, name in enumerate(reversed(ORIGIN_PROVIDERS), 1):
        if src.provider.startswith(name):
            order += 2000 + i
    if src.get('on_account'):
        order += 1000
    return float(order)


def _flag(test: Callable[[Source], bool | None]) -> KeyGetter:
    """Return the getter of a flag of a source (None: unknown)."""
    def get(view: SourceView) -> frozenset[str]:
        """Return the flag of the source."""
        value = test(view.source)
        return frozenset() if value is None else frozenset((value_text(bool(value)),))
    return get


def _routes_kinds(view: SourceView) -> frozenset[str]:
    """Return the kinds of the ways which open a source now (none: not derived)."""
    resolvability = view.source.resolvability
    return frozenset(route.kind for route in resolvability.routes) if resolvability is not None else frozenset()


def _cached(src: Source) -> bool | None:
    """Return the cache state of the torrent of a source on the debrids (None: not known)."""
    return src.resolvability.cached if src.resolvability is not None else None


def _number(get: NumberGetter) -> KeyGetter:
    """Return the getter of the values of a number (its text)."""
    def values(view: SourceView) -> frozenset[str]:
        """Return the number of the source as a text."""
        return frozenset() if (number := get(view)) is None else frozenset((f'{number:g}',))
    return values


#: The labels of the kinds of the ways which open a source.
ROUTE_LABELS: dict[str, str] = {
    'account': L(30873, 'account of the provider'),
    'direct': L(30874, 'direct link'),
    'plugin': L(30875, 'add-on'),
    'debrid': L(30876, 'debrid service'),
    'ff': 'FanFilm',
    'resolveurl': 'ResolveURL',
    'provider': L(30877, 'provider'),
}


def other_keys() -> Iterator[SourceKey]:
    """Iterate over the keys out of the facts."""
    yield SourceKey(path='lang', kind='pair', **key_labels('lang'), labels={UNKNOWN: NO_LANG_LABEL},
                    get=lambda view: frozenset(route['value'] for route in view.routes))
    yield SourceKey(path='quality', kind='range', **key_labels('quality'), values=QUALITY_SCALE,
                    get=lambda view: frozenset((view.source['quality'],)) if view.source.get('quality') in QUALITY_SCALE else frozenset(),
                    number=_quality)
    yield SourceKey(path='size', kind='range', **key_labels('size'), get=_number(_size), number=_size)
    yield SourceKey(path='provider', kind='enum', **key_labels('provider'), get=lambda view: frozenset((view.source.provider,)))
    yield SourceKey(path='hosting', kind='enum', **key_labels('hosting'),
                    get=lambda view: frozenset((view.source.hosting.lower(),)) if view.source.hosting else frozenset())
    yield SourceKey(path='route', kind='set', **key_labels('route'), values=get_args(ResolveKind), labels=ROUTE_LABELS, get=_routes_kinds)
    yield SourceKey(path='cached', kind='flag', **key_labels('cached'), values=FLAG_VALUES, labels=FLAG_LABELS, get=_flag(_cached))
    yield SourceKey(path='premium', kind='flag', **key_labels('premium'), values=FLAG_VALUES, labels=FLAG_LABELS,
                    get=_flag(lambda src: bool(src.get('premium'))))
    yield SourceKey(path='pack', kind='flag', **key_labels('pack'), values=FLAG_VALUES, labels=FLAG_LABELS,
                    get=_flag(lambda src: bool(src.get('pack'))))
    yield SourceKey(path='transfer_short', kind='flag', **key_labels('transfer_short'), values=FLAG_VALUES, labels=FLAG_LABELS,
                    get=_flag(lambda src: src.transfer_short))
    yield SourceKey(path='language', kind='number', **key_labels('language'), get=_number(_language), number=_language)
    yield SourceKey(path='origin', kind='number', **key_labels('origin'), get=_number(_origin), number=_origin)
    yield SourceKey(path='priority', kind='number', **key_labels('priority'), get=_number(lambda view: float(view.priority)),
                    number=lambda view: float(view.priority))


#: The keys out of the facts first (the localization, the quality, the size) in the order of `SOURCE_KEYS`.
FIRST_KEYS: tuple[str, ...] = ('lang', 'quality', 'size')


def source_keys() -> dict[str, SourceKey]:
    """Return the keys by their paths: the first keys (`FIRST_KEYS`), the facts, the rest of the source."""
    others = {key.path: key for key in other_keys()}
    return {**{path: others.pop(path) for path in FIRST_KEYS}, **{key.path: key for key in fact_keys()}, **others}


#: The keys by their paths (`source_keys()`).
SOURCE_KEYS: dict[str, SourceKey] = source_keys()

#: The values of the subtitle kinds which are not a way of a language (forced subtitles: only the foreign parts).
NOT_A_WAY: frozenset[str] = frozenset({SubtitleKind.FORCED.value})


# ----- state -----

class FilterState(TypedDict, total=False):
    """The state of the filter (JSON): the values of the keys (`True` must, `False` must not; no value: any), the ranges."""

    #: The filter is on (off: every source shown).
    on: bool
    #: The values of the keys by their paths: `{<value>: True | False}` (`UNKNOWN`: the unknown value).
    keys: dict[str, dict[str, bool]]
    #: The ranges of the keys (`range`): `[low, high]` (None: open), the quality by its values, the size in GB.
    ranges: dict[str, list[Any]]


class SortCriterion(TypedDict, total=False):
    """
    A criterion of the sort (JSON), one place of the sort key: any of the features (`any`: a source with one of them first, the others
    after it, equal - the next criterion decides) or a key in its natural order (`key`: a number or a flag - 1 set, 0 not - by its
    direction, the localization by the default order of the ways, other values by the order of the key, else by their labels).
    """

    #: Any of the features: the values of the keys by their paths (OR, the unknown value `UNKNOWN` too; no number, no range).
    any: dict[str, list[str]]
    #: The path of the key in its natural order (no `any`).
    key: str
    #: A number (a flag) in the descending order: the biggest (set) first.
    desc: bool
    #: A number of an unknown value first (else at the end).
    unknown_first: bool


class SelectionState(TypedDict, total=False):
    """The state of the selection of the sources (JSON): the filter and the sort."""

    #: The filter.
    filter: FilterState
    #: The criteria of the sort (the first decides).
    sort: list[SortCriterion]


# ----- compiled -----

@frozen(kw_only=True)
class KeyTest:
    """A compiled filter of a key: the must values (OR-ed), the must not values, the unknown one."""

    #: The key.
    key: SourceKey
    #: The must values (the unknown one too).
    must: frozenset[str]
    #: The must not values (the unknown one too).
    must_not: frozenset[str]

    def passes(self, values: frozenset[str]) -> bool:
        """Check if the values of a source pass (none: unknown - it passes unless it must not)."""
        if not values:
            return UNKNOWN not in self.must_not
        if values & self.must_not:
            return False
        return not self.must or bool(values & self.must)

    def matches(self, values: frozenset[str]) -> bool:
        """Check if the values of a source have one of the must values (none: unknown - the unknown one)."""
        return bool(values & self.must) if values else UNKNOWN in self.must


@frozen(kw_only=True)
class RangeTest:
    """A compiled range of a key: the low and the high number (None: open), the unknown value cut."""

    #: The key.
    key: SourceKey
    #: The lowest number.
    low: float | None
    #: The highest number.
    high: float | None
    #: An unknown value is cut.
    cut_unknown: bool

    def passes_number(self, number: float | None) -> bool:
        """Check if a number of a source passes (None: unknown)."""
        if number is None:
            return not self.cut_unknown
        return (self.low is None or number >= self.low) and (self.high is None or number <= self.high)


def _range_number(key: SourceKey, value: Any) -> float | None:
    """Return the number of a range end of a state (the quality: its rank, the size: GB), None: open."""
    if value is None:
        return None
    if key.values:
        return float(key.values.index(value)) if value in key.values else None
    return float(value)


def compile_tests(state: FilterState) -> tuple[tuple[KeyTest, ...], tuple[RangeTest, ...]]:
    """Return the compiled tests of a filter state (unknown keys ignored)."""
    keys = state.get('keys', {})
    tests: list[KeyTest] = []
    for path, values in keys.items():
        if (key := SOURCE_KEYS.get(path)) is None or not key.filtered:
            continue
        if key.kind == 'range':  # its unknown value belongs to its range
            values = {value: on for value, on in values.items() if value != UNKNOWN}
        must = frozenset(value for value, on in values.items() if on is True)
        must_not = frozenset(value for value, on in values.items() if on is False)
        if must or must_not:
            tests.append(KeyTest(key=key, must=must, must_not=must_not))
    ranges: list[RangeTest] = []
    for key in SOURCE_KEYS.values():
        if key.kind != 'range' or key.number is None:
            continue
        low, high = state.get('ranges', {}).get(key.path) or (None, None)
        cut_unknown = keys.get(key.path, {}).get(UNKNOWN) is False
        if low is not None or high is not None or cut_unknown:
            ranges.append(RangeTest(key=key, low=_range_number(key, low), high=_range_number(key, high), cut_unknown=cut_unknown))
    return tuple(tests), tuple(ranges)


def default_lang_order(langs: Sequence[str]) -> list[str]:
    """
    Return the default order of the localization: the languages of the user (`providers_lang`), other ones, unknown, each in the ways
    of `const.sources.filters.ways`; an unknown source (no way known) after them.
    """
    return [*(f'{lang}/{way}' for lang in (*langs, OTHER_LANGUAGE, UNKNOWN) for way in const.sources.filters.ways), UNKNOWN]


@frozen(kw_only=True)
class Criterion:
    """A compiled criterion of a key in its natural order (`SortCriterion.key`)."""

    #: The key.
    key: SourceKey
    #: The ranks of the values (the order of the state or of the key), none: the values by their texts.
    ranks: Mapping[str, int]
    #: The rank of an unknown value.
    unknown: int
    #: A number in the descending order.
    desc: bool = False
    #: A number of an unknown value first.
    unknown_first: bool = False

    def sort_key(self, view: SourceView) -> Any:
        """Return the sort key of a source: the best rank of its values (`lang`: the ranks of all its ways), a number."""
        key = self.key
        if key.kind in ('range', 'number') and key.number is not None:
            number = key.number(view)
            if number is None:
                return (0 if self.unknown_first else 2, 0.0)
            return (1, -number if self.desc else number)
        values = key.get(view)
        if not values:
            return ((self.unknown,), '') if key.kind == 'pair' else (self.unknown, '')
        last = len(self.ranks)
        if key.kind == 'pair':
            return tuple(sorted(self.ranks.get(value, last) for value in values)), ''
        return min((self.ranks.get(value, last), value) for value in values)


@frozen(kw_only=True)
class AnyCriterion:
    """A compiled criterion of any of the features (`SortCriterion.any`): a source with one of them first (0), the others after it (1)."""

    #: The features as the must values of the tests of their keys (`KeyTest.matches()`: the semantics of the required values of the filter).
    tests: tuple[KeyTest, ...]

    def sort_key(self, view: SourceView) -> int:
        """Return the sort key of a source: 0 with one of the features, else 1."""
        return 0 if any(test.matches(test.key.get(view)) for test in self.tests) else 1

    def values(self, path: str) -> frozenset[str]:
        """Return the features of a key (none: not in the criterion)."""
        return next((test.must for test in self.tests if test.key.path == path), frozenset())


#: A compiled criterion of the sort.
CompiledCriterion: TypeAlias = 'Criterion | AnyCriterion'


def criterion_paths(item: SortCriterion) -> tuple[str, ...]:
    """Return the paths of the keys of a criterion of a state (its features, its key)."""
    return tuple(item['any']) if 'any' in item else (item.get('key', ''),)


def compile_criterion(item: SortCriterion, *, langs: Sequence[str]) -> CompiledCriterion | None:
    """Return the compiled criterion of a state, None for one of no known key (a feature of a number or a range: not a feature)."""
    if 'any' in item:
        tests = tuple(KeyTest(key=key, must=frozenset(values), must_not=frozenset()) for path, values in item['any'].items()
                      if values and (key := SOURCE_KEYS.get(path)) is not None and key.kind not in ('range', 'number'))
        return AnyCriterion(tests=tests) if tests else None
    if (key := SOURCE_KEYS.get(item.get('key', ''))) is None:
        return None
    if key.kind == 'pair':
        order = default_lang_order(langs)
    elif key.kind == 'flag':  # a number 1 / 0: set first descending, else not set first
        order = [TRUE, FALSE] if item.get('desc') else [FALSE, TRUE]
    else:
        order = list(key.values)
    ranks = {value: i for i, value in enumerate(order)}
    unknown = ranks.get(UNKNOWN, len(order) + 1)
    return Criterion(key=key, ranks=ranks, unknown=unknown, desc=bool(item.get('desc')), unknown_first=bool(item.get('unknown_first')))


def lang_bucket(lang: str | None, langs: Sequence[str]) -> str:
    """Return the language of a way: a language of the user, `OTHER_LANGUAGE` or `UNKNOWN`."""
    if not lang:
        return UNKNOWN
    lang = lang.lower()
    return lang if lang in langs else OTHER_LANGUAGE


def source_routes(src: Source, langs: Sequence[str]) -> Iterator[Route]:
    """Iterate over the ways of a source: its audio tracks (their kinds, unknown: `UNKNOWN`), its subtitles (not forced ones)."""
    facts = src.facts
    tracks = facts.get('audio', ())
    known = any(track.get('lang') for track in tracks)
    for track in tracks:
        if known and 'lang' not in track and 'kind' not in track:
            continue  # only a codec beside a track of a known language: not a way of its own (MULTI has `lang` None)
        yield Route(value=f'{lang_bucket(track.get("lang"), langs)}/{value_text(track["kind"]) if "kind" in track else UNKNOWN}', track=track)
    for sub in facts.get('subtitles', ()):
        if value_text(sub.get('kind', SubtitleKind.FULL)) not in NOT_A_WAY:
            yield Route(value=f'{lang_bucket(sub.get("lang"), langs)}/{SUBTITLES_WAY}', track=None)


@frozen(kw_only=True)
class Selection:
    """
    The compiled selection of the sources (`compile_selection()`): the filter (`passes()`), the sort (`sort_key()`), both at once
    (`select()`). The views of the sources (`view()`) are made once a call of `select()`.
    """

    #: The filter is on.
    filter_on: bool
    #: The tests of the keys.
    tests: tuple[KeyTest, ...]
    #: The ranges.
    ranges: tuple[RangeTest, ...]
    #: The criteria of the sort.
    criteria: tuple[CompiledCriterion, ...]
    #: The languages of the user (`providers_lang`).
    langs: tuple[str, ...]
    #: The ranks of the ways (the localization of the sort or the default one): the main audio track is the best one.
    lang_ranks: Mapping[str, int]
    #: The priority of a source (the tree of the source providers, the rules), bigger first.
    priority: Callable[[Source], int]

    def view(self, src: Source) -> SourceView:
        """Return the view of a source: its ways by the localization order, its main audio track."""
        last = len(self.lang_ranks)
        routes = tuple(sorted(source_routes(src, self.langs), key=lambda route: self.lang_ranks.get(route['value'], last)))
        audio = next((route['track'] for route in routes if route['track'] is not None), None)
        return SourceView(source=src, routes=routes, audio=audio, priority=self.priority(src))

    def passes_view(self, view: SourceView) -> bool:
        """Check if the view of a source passes the filter."""
        if not self.filter_on:
            return True
        return (all(test.passes(test.key.get(view)) for test in self.tests)
                and all(test.passes_number(test.key.number(view)) for test in self.ranges if test.key.number is not None))

    def passes(self, src: Source) -> bool:
        """Check if a source passes the filter."""
        return self.passes_view(self.view(src))

    def sort_key(self, view: SourceView) -> tuple[Any, ...]:
        """Return the sort key of the view of a source."""
        return tuple(criterion.sort_key(view) for criterion in self.criteria)

    def value_passes(self, path: str, value: str) -> bool:
        """Check if a value of a key passes the tests of the key (a range: its number), e.g. the qualities shown while searching."""
        if not self.filter_on or (key := SOURCE_KEYS.get(path)) is None:
            return True
        if any(test.key is key and not test.passes(frozenset((value,))) for test in self.tests):
            return False
        number = _range_number(key, value) if key.kind == 'range' else None
        return all(test.passes_number(number) for test in self.ranges if test.key is key)

    def select(self, sources: Iterable[Source], *, filtered: bool = True) -> list[Source]:
        """Return the sources which pass the filter (all of them without `filtered`) in the order of the sort (stable)."""
        views = [self.view(src) for src in sources]
        if filtered:
            views = [view for view in views if self.passes_view(view)]
        views.sort(key=self.sort_key)
        return [view.source for view in views]


def compile_selection(state: SelectionState, *, langs: Sequence[str], priority: Callable[[Source], int] = lambda src: 0) -> Selection:
    """Return the compiled selection of a state for the languages of the user."""
    filter_state = state.get('filter', {})
    tests, ranges = compile_tests(filter_state)
    criteria = tuple(crit for item in state.get('sort', ()) if (crit := compile_criterion(item, langs=langs)) is not None)
    return Selection(filter_on=filter_state.get('on', True), tests=tests, ranges=ranges, criteria=criteria, langs=tuple(langs),
                     lang_ranks=lang_ranks(criteria, langs), priority=priority)


def lang_ranks(criteria: Iterable[CompiledCriterion], langs: Sequence[str]) -> dict[str, int]:
    """
    Return the ranks of the ways of the criteria (the main way of a source is its best one): the localization features of the criteria in
    their order (of one criterion in the default order), up to the localization in its natural order; the default order after them.
    """
    default = default_lang_order(langs)
    place = {value: i for i, value in enumerate(default)}
    first: list[str] = []
    for crit in criteria:
        if isinstance(crit, Criterion):
            if crit.key.kind == 'pair':
                break
            continue
        first.extend(sorted(crit.values('lang') - set(first), key=lambda value: (place.get(value, len(place)), value)))
    return {value: i for i, value in enumerate(dict.fromkeys((*first, *default)))}
