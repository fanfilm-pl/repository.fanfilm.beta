"""Simple Kodi tools."""

from __future__ import annotations
from time import monotonic
from threading import Event, Thread, Lock, enumerate as threading_enumerate, main_thread, TIMEOUT_MAX
from queue import Queue
from contextlib import contextmanager
from pathlib import Path
import atexit
import json
from types import TracebackType
from typing import Mapping, Type, TypeVar, Callable, ClassVar, Generic, TYPE_CHECKING
from typing_extensions import TypedDict, Unpack, NotRequired, Self, Literal, Protocol, TypeAlias
from attrs import define, field, frozen, Attribute
from .tricks import make_mutable_metaclass
from .threads import WeakThread, xsleep, abort_network, cut_sockets
from .threads import xsleep_until_exit  # noqa: F401
from .logs import fflog, fflog_exc
from .. import info
from ..info import exec_id
from ..sdk import threads as sdk_threads
if TYPE_CHECKING:
    from datetime import datetime
    from typing import Any, List, Dict, Sequence, Iterator, Iterable
    from .types import JsonData, JsonResult, Params
    from .url import URL


from xbmc import Monitor as XmbcMonitor, Player as XbmcPlayer, PlayList as XbmcPlayList, PLAYLIST_VIDEO
from xbmc import executeJSONRPC, getCondVisibility, getGlobalIdleTime
import xbmcaddon
import xbmcgui

from const import const
from ..service.exc import KodiExit, ReloadExit, ExitBaseException


T = TypeVar('T')
KodiLibraryType = Literal['video', 'music']
KodiRpcAction = Literal['notify', 'request', 'response']

#: System platform.
_platform: str | None = None
#: Kodi startup timestemp
_startup: 'datetime | None' = None


#: Monitor.onNotification callback type.
OnNotification: TypeAlias = Callable[[str, str, str], None]


def is_kodi_quit(sender: str, method: str) -> bool:
    """Return True if the Kodi notification is the Kodi exit (`System.OnQuit` of `xbmc`)."""
    return sender == 'xbmc' and method == 'System.OnQuit'


class MonitorProtocol(Protocol):
    """Protocol for objects that can receive Kodi notifications."""

    def onNotification(self, sender: str, method: str, data: str) -> None:
        """Notification, called by Kodi."""


class Monitor:
    """Pseudo Kodi monitor base class. Used in KodiMonitor.add_monitor()."""

    def add(self) -> None:
        """Add monitor to KodiMonitor."""
        if xmonitor := KodiMonitor.instance():
            xmonitor.add_monitor(self)
        else:
            fflog.warning(f'[KOTOOLS]  KodiMonitor instance is not created [{exec_id()}]')

    def remove(self) -> None:
        """Remove monitor from KodiMonitor."""
        if xmonitor := KodiMonitor.instance():
            xmonitor.remove_monitor(self)

    def __enter__(self) -> Self:
        """Context manager to add monitor to KodiMonitor."""
        if xmonitor := KodiMonitor.instance():
            xmonitor.add_monitor(self)
        else:
            fflog.warning(f'[KOTOOLS]  KodiMonitor instance is not created [{exec_id()}]')
        return self

    def __exit__(self, exc_type: Type[BaseException], exc_inst: BaseException | None, exc_tb: TracebackType | None) -> None:
        """Context manager to remove monitor from KodiMonitor."""
        if xmonitor := KodiMonitor.instance():
            xmonitor.remove_monitor(self)

    def onNotification(self, sender: str, method: str, data: str) -> None:
        """Notification, called by Kodi."""


@define(kw_only=True, eq=False)
class XTimer:
    """Timer for Kodi. Use it to run code after some time."""

    #: monotonic() value when timer expires.
    expires: float
    #: interval in seconds.
    interval: float = 0
    #: Cancel event: set by the caller (cancel) or by the monitor on Kodi exit / reload, never on expiration.
    event: Event = field(factory=Event, repr=False)
    #: True if timer is expired, False is aborted.
    expired: bool = field(default=False, init=False, repr=False)


class KodiMonitor(XmbcMonitor, metaclass=make_mutable_metaclass(XmbcMonitor)):
    """Kodi monitor for safe sleep and exit."""

    #: Global Kodi monitor instance.
    _instance: ClassVar[KodiMonitor | None] = None
    #: Event for create singleton instance.
    _instance_lock: ClassVar[Lock] = Lock()

    def __init__(self) -> None:
        super().__init__()
        #: Active timers, only to wake their waiters on Kodi exit / reload (each waiter knows its deadline itself).
        self._timers: set[XTimer] = set()
        # System.OnQuit seen already by an ended monitor of this interpreter: Kodi does not announce it again to a new one
        self._exiting: bool = kodi_abort_event.is_set()
        self._aborting: bool = self._exiting
        self._monitor_thread: Thread | None = None
        self._monitors: list[MonitorProtocol] = []
        self._watchers: set[OnNotification] = set()
        self._lock = Lock()  # Lock for thread safety, if needed

    @classmethod
    def instance(cls: type[KodiMonitor], *, sleep_step: float | None = None) -> KodiMonitor:
        """Return the Kodi monitor of the interpreter, create it first.

        `sleep_step` - the step of its loop (the x-monitor) when this call creates it (the worker script); None: the one of the service
        or of a plugin call, read at every step (a reload of the configuration).
        """
        def new(caller: str):
            iid = exec_id()
            fflog(f'[KOTOOLS]  KodiMonitor  CREATE [{iid}] from [{caller}]')
            aborting = exiting = None
            instance: KodiMonitor | None = None
            from ..service import SERVICE
            try:
                instance = cls()
                created.put_nowait(instance)
                while not instance.aborting and not instance._aborting and not instance.abortRequested():
                    step = sleep_step or (const.tune.service.sleep_step if SERVICE else const.tune.sleep_step)  # read again: a reload
                    if instance.waitForAbort(step):
                        break
                aborting, exiting = instance._aborting, instance._exiting
            except Exception:
                fflog_exc()
            finally:
                cls._instance = None
                if instance is not None:
                    # Kodi exit seen by waitForAbort() only (no System.OnQuit) or destroy: wake all sleeping threads
                    instance._aborting = True
                    instance._clear_timers()
                    if instance.abortRequested():  # Kodi abort (not destroy): end the blocked network reads
                        abort_network()
                fflog(f'[KOTOOLS]  KodiMonitor  thread EXIT [{iid}] (instance {aborting=}, {exiting=})')

        with KodiMonitor._instance_lock:
            if cls._instance is None:
                created: Queue[KodiMonitor] = Queue()
                # The monitor of the interpreter, not of the caller: a scope of its own (a stopped scope of the caller, e.g. the stopping
                # service, would cancel it before `new()` runs and the get() below would wait forever under the lock).
                th = WeakThread(target=new, name='KodiMonitor.monitor', kwargs={'caller': exec_id()}, scope=sdk_threads.CancelScope())
                th.start()
                cls._instance = created.get()
                assert cls._instance is not None, 'KodiMonitor instance is not created!'
                cls._instance._monitor_thread = th
            return cls._instance

    @classmethod
    def destroy(cls) -> None:
        """Destroy Kodi monitor instance."""
        fflog(f'[KOTOOLS]  KodiMonitor  going to destroy  {cls._instance!r} [{exec_id()}]')
        with KodiMonitor._instance_lock:
            # destroy kolang and settings
            from .. import kolang
            from .settings import settings
            kolang.destroy()
            if settings is not None:
                settings.destroy()
            # close all monitors and watchers
            if cls._instance is not None:
                fflog('[KOTOOLS]  KodiMonitor  destroying')
                cls._instance.stop()
                # cls._instance = None
                fflog('[KOTOOLS]  KodiMonitor  DESTROYED')

    @property
    def aborting(self) -> bool:
        """Return True if Kodi is quiting (abort has been requested)."""
        return self._aborting

    def _clear_timers(self) -> None:
        """Clear all timers, wake their waiters (the timer cancel event is set)."""
        with self._lock:
            timers, self._timers = self._timers, set()
        for timer in timers:
            timer.event.set()

    def _on_quit(self) -> None:
        """Clean on Kodi exit, cancel all timers and set abort event."""
        from .threads import Queue
        act_threads = ', '.join(str(th) for th in threading_enumerate())  # LOG
        fflog(f'[KOTOOLS]  System.OnQuit: {act_threads}')
        self._aborting = True
        self._exiting = True
        self._clear_timers()
        kodi_abort_event.set()
        abort_network()
        for queue in Queue.WAITING_QUEUES:
            queue.shutdown(exception=KodiExit)

    def onNotification(self, sender: str, method: str, data: str) -> None:
        """Notification, called by Kodi."""
        fflog(f'[KOTOOLS]  Kodi x-monitor received notification: {sender=}, {method=}, {data=}  |M|={len(self._monitors)},'  # XXX
              f' |W|={len(self._watchers)}, |T|={len(self._timers)}, abort={self.abortRequested()} [{exec_id()}]')             # XXX
        from .control import plugin_id
        for monitor in self._monitors:
            try:
                monitor.onNotification(sender, method, data)
            except Exception as exc:
                fflog(f'[KOTOOLS]  Error in observer {monitor!r} on notification({sender=}, {method=}): {exc}')
                fflog_exc()
        for watcher in self._watchers:
            try:
                watcher(sender, method, data)
            except Exception as exc:
                fflog(f'[KOTOOLS]  Error in watcher {watcher!r} on notification({sender=}, {method=}): {exc}')
                fflog_exc()
        if is_kodi_quit(sender, method):
            # Kodi is exiting, cancel all timers and set abort event.
            self._on_quit()
        elif sender == plugin_id and method == 'ServiceUpdate':
            from ..service.client import service_client
            try:
                msg = json.loads(data)
            except Exception as exc:
                fflog.error(f'JSONRPC message failed: {exc}, {sender=}, {method=}\n  {data!r}')
            else:
                fflog(f'Service updated: {msg}')
                if isinstance(msg, dict) and (url := msg.get('url')):
                    service_client.set_url(url)

    def add_monitor(self, monitor: MonitorProtocol) -> None:
        """Add monitor for Kodi notifications."""
        fflog(f'[KOTOOLS]  Add monitor {monitor!r}')
        with self._lock:
            for m in self._monitors:
                if m is monitor:
                    return
            self._monitors.append(monitor)

    def remove_monitor(self, monitor: MonitorProtocol) -> None:
        """Remove monitor for Kodi notifications."""
        fflog(f'[KOTOOLS]  Remove monitor {monitor!r}')
        with self._lock:
            for i, m in enumerate(self._monitors):
                if m is monitor:
                    del self._monitors[i]
                    return

    @contextmanager
    def with_monitor(self, monitor: MonitorProtocol) -> Iterator[Self]:
        """Context manager to add monitor for Kodi notifications."""
        self.add_monitor(monitor)
        try:
            yield self
        finally:
            self.remove_monitor(monitor)

    def add_watcher(self, watcher: OnNotification) -> None:
        """Add notification watcher."""
        with self._lock:
            self._watchers.add(watcher)

    def remove_watcher(self, watcher: OnNotification) -> None:
        """Remove notification watcher."""
        with self._lock:
            self._watchers.discard(watcher)

    @contextmanager
    def with_watcher(self, watcher: OnNotification) -> Iterator[Self]:
        """Context manager to add watcher for Kodi notifications."""
        self.add_watcher(watcher)
        try:
            yield self
        finally:
            self.remove_watcher(watcher)

    @contextmanager
    def abort_context(self,
                      on_abort: Callable[[], Any] | None,
                      args: Sequence[Any] | None = None,
                      kwargs: Mapping[str, Any] | None = None,
                      *,
                      event: Event | None = None
                      ) -> Iterator[Event]:
        """
        Context manager to work with aborting.

        Example (3 in 1):
        >>> def on_abort_function():
        >>>     print("Kodi is aborting, do something here...")
        >>> with KodiMonitor.instance().abort_context(on_abort=on_abort_function) as event:
        >>>     if event.wait(timeout=10):
        >>>          print("Kodi is aborting, do something here...")
        >>>     if event.is_set():
        >>>          print("Kodi is aborting, do something here...")
        """

        def look_for_abort(sender: str, method: str, data: str) -> None:
            if is_kodi_quit(sender, method):
                assert event is not None
                event.set()
                if on_abort:
                    aa = () if args is None else args
                    kw = {} if kwargs is None else kwargs
                    on_abort(*aa, **kw)

        if event is None:
            event = Event()
        with self.with_watcher(look_for_abort):
            yield event

    def reload(self) -> None:
        """Set reload event and cancel all timers."""
        self._clear_timers()
        fflog('[KOTOOLS]  Kodi monitor received reload, exiting...')
        reload_event.set()

    def new_timer(self, interval: float, *, event: Event | None = None) -> XTimer:
        """Create new timer."""
        expires = monotonic() + interval
        timer = XTimer(expires=expires, interval=interval, event=event or Event())
        with self._lock:
            self._timers.add(timer)
        return timer

    def remove_timer(self, timer: XTimer) -> bool:
        """Remove timer."""
        with self._lock:
            if timer in self._timers:
                self._timers.discard(timer)
                return True
        return False

    def wait(self, timer: XTimer) -> bool:
        """
        Wait for timer to expire. Return True if timer expired, False if cancelled (or on Kodi exit / reload).

        The waiting thread knows the deadline itself, so nothing has to signal the expiration. The cancel event
        is set only by the caller (cancel) or by the monitor (Kodi exit, reload), the monitor never touches it
        on expiration (a set + clear pulse could be lost or could wipe out a cancel set by the caller meanwhile).
        """
        try:
            while not self._aborting:
                remaining = timer.expires - monotonic()
                if remaining <= 0:
                    timer.expired = True
                    break
                # base Event.wait(): ff.threads.Event polls (and checks Kodi exit itself), here the monitor wakes us
                if Event.wait(timer.event, min(remaining, TIMEOUT_MAX)):
                    break
        finally:
            self.remove_timer(timer)
        return timer.expired

    def stop(self) -> None:
        """Stop Kodi monitor."""
        fflog(f'[KOTOOLS]  KodiMonitor  STOP  monitor={self._monitor_thread}')
        self._aborting = True
        self._exiting = True
        self._clear_timers()
        if self._monitor_thread:
            self._monitor_thread, thread = None, self._monitor_thread
            thread.join()


def destroy_xmonitor() -> None:
    """Destroy the monitor."""
    try:
        cls = KodiMonitor
    except NameError:
        # KodiiMonitor class deleted on kodi exit
        return
    cls.destroy()


def active_threads() -> List[Thread]:
    """Get list of active threads."""
    try:
        from threading import _DummyThread  # type: ignore[reportAssignmentType]  # confict with fallback class
    except ImportError:
        class _DummyThread:
            pass
    return [th for th in threading_enumerate()
            if isinstance(th, Thread) and type(th) not in (_DummyThread, type(main_thread()), WeakThread)]


def xmonitor_script_finish() -> None:
    """Check the monitor on end of stript."""
    xmonitor = KodiMonitor._instance
    fflog(f'[KOTOOLS]  KodiMonitor  SCRIPT finishing [{exec_id()}], {xmonitor=}')
    threads = active_threads()
    if not threads:
        if xmonitor is not None:
            destroy_xmonitor()
        return
    # Kodi does not reuse (nor free) the interpreter until all script threads are finished and the monitor threads
    # never finish by themselves. Destroy the monitor when the last thread (e.g. a delayed notification) is done,
    # otherwise the interpreter stays forever and handles every Kodi notification.
    # The monitor sees Kodi exit then, the threads blocked in the network (e.g. providers) must end at once.
    if xmonitor is None:
        xmonitor = KodiMonitor.instance()
    fflog(f'[KOTOOLS]  KodiMonitor  SCRIPT FINISH [{exec_id()}], {len(threads)} threads: {threads}, aborting={xmonitor.aborting}')
    if info.script_aborted() or kodi_abort_event.is_set():  # the monitor can be created after the abort
        abort_network()

    def reap() -> None:
        try:
            while left := active_threads():
                # again, a socket connecting before is not cut
                if sdk_threads.network_aborted or xmonitor.abortRequested() or kodi_abort_event.is_set():  # not `aborting`, set on destroy too
                    abort_network()
                else:
                    cut_sockets()  # of the stopped threads (e.g. providers of a closed search)
                left[0].join(const.tune.event_step)
            destroy_xmonitor()
        except Exception:
            fflog_exc()

    WeakThread(target=reap, name='KodiMonitor.reaper').start()


#: Event for Kodi exit.
kodi_abort_event = Event()
#: Event for module reload.
reload_event = Event()

# Start Kodi monitor in a separate thread.
atexit.register(destroy_xmonitor)


FF_ICON: str = xbmcaddon.Addon().getAddonInfo('icon')

ICONS: Dict[str | None, str] = {
    None: FF_ICON,
    '': FF_ICON,
    'INFO': xbmcgui.NOTIFICATION_INFO,
    'WARNING': xbmcgui.NOTIFICATION_WARNING,
    'ERROR': xbmcgui.NOTIFICATION_ERROR,
}


class NotificationOpenArgs(TypedDict):
    interval: NotRequired[float | None]
    delay: NotRequired[float | None]


@define
class Notification:
    """
    Forced GUI notifications.

    Like xbmcgui.Dialog().notification() but keeps visible event another notification occur.
    Differences:
    - `interval` in SECONDS (not milliseconds)
    - it starts hidden, must be opened or shown, you can use `with` statement
    - `heading`, `message` and `icon` could be changed in any time
    - you could add startup `delay`

    `open()` and `show()` are very similar and don't differ on first usage at all.
    Opening rests all settings and shows, then delay works again.

    When `with` statement is used `interval` interval means visible time AFTER statement exit.

    >>> Notification('Header', 'My text').show()
    >>>
    >>> with Notification('Header', 'Progress: 0%', delay=1) as notif:
    >>>    for i, job in enumerate(jobs):
    >>>        notif.message = f'Progress: {100 * i / len(jobs)}%'
    """

    # Dialog heading (title).
    heading: str
    # heading: str = field()
    # Dialog message.
    message: str
    # message: str = field()
    # Icon to use. Default is FanFilm icon.
    icon: str | None = None
    # Time in SECONDS (sic!). Default 5, None or -1 means forever.
    interval: float | None = 5
    # Play notification sound, default True.
    sound: bool = True
    # True if the notification is visible, if not, you must use show().
    visible: bool = False
    # Startup show delay in seconds.
    delay: float = -1  # -1 means auto (zero or almost zero)
    # Show works if True otherwise hidden notification (show is not enabled).
    enabled: bool = True

    # -- private attributes --
    _visible: bool = field(default=False, init=False, repr=False)
    _sound: bool = field(default=False, init=False, repr=False)
    _delay: float = field(default=0, init=False, repr=False)
    _thread: Thread | None = field(default=None, init=False, repr=False)
    # _changed: Event = field(factory=Event, init=False, repr=False)
    _exit: Event = field(factory=Event, init=False, repr=False)
    _finished: Event = field(factory=Event, init=False, repr=False)
    _stack: ClassVar[List[Notification]] = []
    _end: float = field(default=0, init=False, repr=False)

    def __attrs_post_init__(self):
        self.icon = ICONS.get(self.icon, FF_ICON)
        self._delay = self.delay
        # self._changed.clear()
        if self.visible:
            if self.delay < 0:
                self.delay = 0.01
            self.show()
        elif self.delay < 0:
            self.delay = 0

    # @heading.validator
    # def _change_heading(self, attr: Attribute, value: str) -> None:
    #     self._changed.set()

    # @message.validator
    # def _change_message(self, attr: Attribute, value: str) -> None:
    #     self._changed.set()

    def _update_end_time(self, interval: float | None = None) -> None:
        if interval is None or interval < 0:
            self._end = 2**62  # a lot of seconds
        else:
            self._end = monotonic() + (interval or 5)

    def _show_loop(self, **kwargs: Unpack[NotificationOpenArgs]) -> None:
        assert self.icon is not None
        self._finished.clear()
        interval = kwargs.get('interval', self.interval)
        delay = kwargs.get('delay', self._delay)
        if delay and delay > 0:
            xsleep(delay, cancel_event=self._exit)
            # self._changed.clear()
            self._delay = 0
        self._update_end_time(interval)
        try:
            self._stack.append(self)
            fflog(f'Start {self.heading=}, {interval=}, {delay=}, {self._visible=}')
            while self._visible and (now := monotonic()) < self._end:
                if self._stack and self._stack[-1] is self:
                    sleep_interval = min(1, self._end - now)
                    sound, self._sound = self._sound, False
                    # self._changed.clear()
                    # fflog.debug(f'notif {self.heading=}, {interval=}, {delay=}, {sleep_interval=}')
                    xbmcgui.Dialog().notification(self.heading, self.message, self.icon, int(1000 * sleep_interval + 10), sound)
                    self._sound = False
                    xsleep(sleep_interval, cancel_event=self._exit)
                    self._exit.clear()
                else:  # not on top
                    fflog(f'hidden {self.heading=}, {interval=}, {delay=}')
                    xsleep(min(.2, self._end - now))
        finally:
            fflog(f'finish {self.heading=}, {interval=}, {delay=}')
            self._visible = False
            self._thread = None
            self._stack.remove(self)
            self._finished.set()

    def show(self, *, message: str | None = None, icon: str | None = None, **kwargs: Unpack[NotificationOpenArgs]) -> Self:
        """Shows notification. No delay again. If already visible, resets interval. Update message and icon if not None."""
        if self.enabled:
            if message is not None:
                self.message = message
            if icon is not None:
                self.icon = ICONS.get(icon, FF_ICON)
            self._finished.clear()
            self._exit.clear()
            if self._visible:
                assert self._thread is not None
                interval = kwargs.get('interval', self.interval)
                self._update_end_time(interval)
            else:
                self._visible = True
                self._sound = self.sound
                self._thread = Thread(target=self._show_loop, kwargs=kwargs)
                self._thread.start()
        return self

    def hide(self) -> Self:
        """Hide notification."""
        if self._visible:
            self._visible = False
            self._exit.set()
            # self._changed.set()
        return self

    def open(self, **kwargs: Unpack[NotificationOpenArgs]) -> Self:
        """Opens notification again: resets settings and shows. Do not use delay again if already visible."""
        if not self.visible:
            self._sound = self.sound
            self._delay = self.delay
            self.show(**kwargs)
        return self

    def close(self) -> Self:
        """Closes notification."""
        self.hide()
        return self

    # def __del__(self) -> None:
    #     self.hide()

    def __enter__(self) -> Notification:
        if self._visible:
            self.hide()
            xsleep(1.1, cancel_event=self._finished)
        self.open(interval=None)
        return self

    def __exit__(self, exc_type: Type[BaseException], exc_inst: BaseException | None, exc_tb: TracebackType | None) -> None:
        self.close()


def video_playing() -> bool:
    """Return True if a video plays (also paused): the service postpones its maintenance works, its reloads of Kodi."""
    return bool(getCondVisibility('Player.HasVideo'))


def idle_time() -> int:
    """
    Return the idle time of Kodi in seconds: since the last input of the user (remote, keyboard, mouse, JSON-RPC `Input.*`),
    0 while a media plays (Kodi does not count a play as an input; paused: idle).
    """
    if getCondVisibility('Player.Playing'):
        return 0
    return getGlobalIdleTime()


def get_player_item(player: XbmcPlayer | None = None) -> xbmcgui.ListItem | None:
    """Returns current playing Kodi ListItem or current ListItme from playlist. A long living `player` is used if given."""
    try:
        if player is None:
            player = XbmcPlayer()
        if player.isPlaying():
            return player.getPlayingItem()
    except Exception:
        fflog_exc()

    pls = XbmcPlayList(PLAYLIST_VIDEO)
    if (size := pls.size()) > 0 and 0 <= (index := pls.getposition()) < size:
        try:
            return pls[index]
        except Exception:
            fflog_exc()
    # if (size := pls.size()) > 0:
    #     index = pls.getposition()
    #     try:
    #         return pls[index if 0 <= index < size else 0]
    #     except Exception:
    #         fflog_exc()
    return None


def stop_playing(player: XbmcPlayer | None = None, *, stop: bool = True) -> None:
    """Stop playing anything. A long living `player` is used if given. Without `stop` only the playlist is cleared."""
    from .control import close_busy_dialog
    if stop:
        (XbmcPlayer() if player is None else player).stop()
    XbmcPlayList(PLAYLIST_VIDEO).clear()
    close_busy_dialog()


def get_platform() -> str:
    """Get current platform."""
    global _platform
    if _platform is None:
        import platform
        import sys
        _platform = platform.system().lower()
        if _platform == 'linux' and hasattr(sys, 'getandroidapilevel'):
            _platform = 'android'
    return _platform


@frozen(kw_only=True)
class AddonXmlInfo:
    """The info of an add-on in its `addon.xml` (read as a file: no `xbmcaddon.Addon`, also of a disabled add-on)."""

    #: The add-on ID (its folder).
    id: str
    #: The name (the ID if not read).
    name: str
    #: The version.
    version: str = ''
    #: The author (`provider-name`).
    author: str = ''
    #: The summary and the description in the language (`addon_info()`).
    summary: str = ''
    description: str = ''
    #: The icon path (`<assets><icon>` as Kodi, else `icon.png` of an add-on without it), '' - none.
    icon: str = ''


def addon_info(path: Path, lang: str = '') -> AddonXmlInfo:
    """
    Return the info of the add-on in the folder (`addon.xml`); the texts in the language `lang` (ISO 639-1, none: of Kodi),
    else English (also without `lang`, the Kodi default), else the first one; only the ID if not read.
    """
    import xml.etree.ElementTree as ET
    try:
        root = ET.parse(path / 'addon.xml').getroot()
    except (OSError, ET.ParseError):
        return AddonXmlInfo(id=path.name, name=path.name)
    if not lang:
        from xbmc import getLanguage, ISO_639_1
        lang = getLanguage(ISO_639_1)
    meta = next((ext for ext in root.iter('extension') if ext.get('point') == 'xbmc.addon.metadata'), None)

    def text(tag: str) -> str:
        texts: dict[str, str] = {}
        for elem in meta.findall(tag) if meta is not None else ():
            texts.setdefault((elem.get('lang') or 'en').partition('_')[0].lower(), (elem.text or '').strip())  # the first one of a language
        return texts.get(lang) or texts.get('en') or next(iter(texts.values()), '')

    icon = meta.findtext('assets/icon', '').strip() if meta is not None else ''
    if not icon and (path / 'icon.png').is_file():  # an old add-on without assets (Kodi shows none, FanFilm its icon.png)
        icon = 'icon.png'
    return AddonXmlInfo(id=path.name, name=root.get('name') or path.name, version=root.get('version') or '', author=root.get('provider-name') or '',
                        summary=text('summary'), description=text('description'), icon=str(path / icon) if icon else '')


def addon_name(path: Path) -> str:
    """Return the name of the add-on in the folder (`addon.xml`), its folder name (ID) if not read."""
    return addon_info(path, lang='en').name


def addon_icon(path: Path) -> str:
    """Return the icon path of the add-on in the folder (`addon.xml`, `AddonXmlInfo.icon`), '' if none."""
    return addon_info(path, lang='en').icon


def addon_enabled_in_kodi(addon_id: str) -> bool:
    """Return True if the add-on is enabled in Kodi (it asks Kodi: the main thread)."""
    return bool(getCondVisibility(f'System.AddonIsEnabled({addon_id})'))


@fflog_exc
def launch_browser(url: str) -> None:
    """Launch external browser."""
    if get_platform() == 'android':
        try:
            # Metoda 1: Użycie xbmc.executebuiltin (zalecana dla Kodi)
            import xbmc
            xbmc.executebuiltin(f'StartAndroidActivity("",android.intent.action.VIEW,"","{url}")')
        except Exception as e:
            fflog(f'Failed to open URL by StartAndroidActivity: {e}')

            # Metoda 2: Fallback - użycie os.system zamiast Popen
            from subprocess import Popen
            Popen(['am', 'start', '-a', 'android.intent.action.VIEW', '-d', url])
            # os.system(f'am start -a android.intent.action.VIEW -d "{self.url}"')
    else:
        import webbrowser
        THE_SAME, NEW_WINDOW, NEW_TAB = 0, 1, 2  # noqa: F841
        webbrowser.open(url, new=NEW_TAB, autoraise=True)


def kodi_startup_timestamp() -> 'datetime':
    """Return datetime timestamp of kodi launch (in UTC)."""
    import re
    from datetime import datetime, timezone, timedelta
    global _startup
    if _startup is None:
        from xbmcvfs import translatePath
        log_path = Path(translatePath('special://logpath')) / 'kodi.log'
        from xbmc import getInfoLabel
        if log_path.exists():
            from codecs import BOM_UTF8
            from .calendar import fromisoformat
            try:
                with open(log_path, 'rb') as f:
                    data = f.read(128)
                    if data.startswith(BOM_UTF8):
                        data = data[len(BOM_UTF8):]
                    if mch := re.match(rb'[-\d]+[ T][:.\d]+', data):
                        # parse first log timestamp and convert it to UTC.
                        _startup = fromisoformat(mch[0].decode('ascii')).astimezone(timezone.utc)
                        return _startup
            except (OSError, ValueError):
                fflog_exc()
                pass
        fflog(f'Missing kodi.log {log_path=}')
        # fallback to kodi api, it is fucked, can return "busy"
        from xbmc import getInfoLabel
        now = datetime.now(timezone.utc)
        up = getInfoLabel("System.Uptime")
        nums = list(map(int, re.findall(r'\d+', getInfoLabel("System.Uptime"))))
        if nums:
            # could be, in translations (sic!):
            # - "1 day 2 hours 3 minutes"
            # - "1 hour 2 minutes"
            # - "1 minute"  (not checked)
            d, h, m = [0, 0, *nums][-3:]
            _startup = now - timedelta(days=d, hours=h, minutes=m)
        else:
            fflog(f'Incorrect System.Uptime: {up!r}')
            # WTF???
            # Kodi can NOT return human readable time data, even if system is 4 hours up`.
            # It could return "Busy" (PL: "Zajęty")
            return datetime(1971, 1, 1, tzinfo=timezone.utc)
    return _startup


class KodiRpc:
    """Kodi JSONRPC client."""

    MESSAGE_ID_NAME: ClassVar[str] = '_id_'
    ACTION_NAME: ClassVar[str] = '_action_'
    BROADCAST: ClassVar[int] = 0

    def __init__(self) -> None:
        #: JSON-RPC message id.
        self._jsonrpc_id = 1
        #: Notification message id for match NotifyAll response.
        self._notify_message_id = int(monotonic() * 1000) % 1000 * 1000 + 1

    def rpc(self, method: str, *, params: Params | None = None, fields: Sequence[str] = ()) -> JsonResult:
        """Call remote procedure (JSONRPC)."""
        msg_id, self._jsonrpc_id = self._jsonrpc_id, self._jsonrpc_id + 1
        params = dict(params or {})
        req = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params,
            'id': msg_id,
        }
        # TODO: sort
        # TODO: filter
        # TODO: limits
        if fields:
            params['properties'] = tuple(fields)
        result = None
        try:
            fflog.debug(f'... JSON RPC () ...  {req}')
            result = executeJSONRPC(json.dumps(req, default=tuple, ensure_ascii=False))
            data = json.loads(result)
        except Exception as exc:
            fflog.error(f'JSONRPC call failed: {exc}, {req!r}\n  {result!r}')
            raise
        fflog.debug(f'... JSON RPC: ...  {data}')
        if isinstance(data, Mapping) and (error := data.get('error')):
            # the callers do not check the answer: a failed call (e.g. Files.SetFileDetails) is not silent at least
            fflog.warning(f'JSONRPC {method} failed: {error}, params={params!r}')
        return data

    def rpc_list(self, method: str, *, params: Params | None = None, fields: Sequence[str] = (), return_type: str | None = None) -> list[JsonData]:
        """Call remote procedure (JSONRPC)."""
        data = self.rpc(method=method, params=params, fields=fields)
        if isinstance(data, Mapping) and isinstance((result := data.get('result')), Mapping):
            if return_type is None:
                return_type = next(iter(result.keys() - {'limits'}), None)
                if return_type is None:
                    return []
            # if limits := result.get('limits'):
            #     end, start, total = limits['end'], limits['start'], limits['total']
            return result[return_type]
        return []

    def rpc_object(self, method: str, *, params: Params | None = None, fields: Sequence[str] = (), return_type: str | None = None) -> JsonData:
        """Call remote procedure (JSONRPC)."""
        data = self.rpc(method=method, params=params, fields=fields)
        if isinstance(data, Mapping) and isinstance((result := data.get('result')), Mapping):
            if return_type is None:
                return_type = next(iter(result.keys() - {'limits'}), None)
                if return_type is None:
                    return {}
            return result[return_type]
        return {}

    def notify(self, method: str, data: JsonData | None = None, *, id: int | None = None, action: KodiRpcAction = 'notify') -> int:
        """Emit JSON-RPC notification. Returns message id."""
        from .control import plugin_id
        data = dict(data or ())
        if isinstance(id, int):
            mid = id  # could be zero on service notification broadcast
        else:
            mid, self._notify_message_id = self._notify_message_id, self._notify_message_id + 1
        data[self.MESSAGE_ID_NAME] = mid
        data[self.ACTION_NAME] = action
        params = {
            'sender': plugin_id,
            'message': method,
            'data': data or {},
        }
        self.rpc(method='JSONRPC.NotifyAll', params=params)
        return mid

    def addon_signal(self, message: str, data: Mapping[str, Any] | None = None, *, sender: str | None = None) -> None:
        """Emit JSON-RPC notification like AddonSignals."""
        from base64 import b64encode
        from .control import plugin_id
        if sender is None:
            sender = f'{plugin_id}.SIGNAL'
        data = dict(data or ())
        encoded = b64encode(json.dumps(data).encode('utf-8')).decode('ascii')
        params = {
            'sender': sender,
            'message': message,
            'data': [encoded],
        }
        self.rpc(method='JSONRPC.NotifyAll', params=params)

    def service_call(self, method: str, data: JsonData | None = None, *, timeout: float | None = None) -> JsonData | None:
        """Call JSON-RPC using notifications and return response."""

        class ServiceWaiter(Monitor):

            def __init__(self) -> None:
                super().__init__()
                self.last_id: int | None = None
                self.last_msg: JsonData | None = None
                self.msg: JsonData | None = None

            def onNotification(self, sender: str, method: str, data: str) -> None:
                """Notification, called by Kodi."""
                # fflog(f'[KOTOOLS][RPC]  ServiceWaiter received notification: {sender=}, {method=}, {data=}')
                if sender == plugin_id and data and (msg := json.loads(data)) and msg.get(ACTION_NAME) == 'response':
                    self.last_msg = msg
                    self.last_id = msg.get(MESSAGE_ID_NAME)
                    if self.last_id == mid:
                        self.msg = msg
                        event.set()

        from .control import plugin_id
        MESSAGE_ID_NAME = self.MESSAGE_ID_NAME
        ACTION_NAME = self.ACTION_NAME
        if timeout is None:
            timeout = const.tune.service.rpc_call_timeout
        mid = 0
        event = Event()
        with ServiceWaiter() as waiter:
            mid = self.notify(method, data, action='request')
            if waiter.last_id == mid:
                # already received
                return waiter.last_msg
            xsleep(timeout, cancel_event=event)
            # waiter.waitForAbort(0.001)
            # waiter.waitForAbort(timeout)
            if not event.is_set():
                return None
            return waiter.msg

    def wait_for_service(self, *, timeout: float | None = None, ready: Callable[[], bool] | None = None) -> bool:
        """
        Wait for Kodi service to be ready. Returns True if service is ready, False on timeout.

        The service answers a ping (or broadcasts it is up), but Kodi can hold the notifications for seconds at its start.
        `ready` checks the service without them (e.g. its URL in the state DB), it is called often (it costs no broadcast).
        """

        def service_up(sender: str, method: str, data: str) -> None:
            """Notification, called by Kodi."""
            # fflog.debug(f'======================================================== {sender=}, {method=}, {data=}')
            if sender == plugin_id and method in ('Other.ServicePong', 'Other.ServiceUp'):
                fflog('Service is up, hurray')
                event.set()

        from .control import plugin_id
        xmonitor = KodiMonitor.instance()
        if xmonitor is None:
            return False
        if timeout is None:
            timeout = const.tune.service.startup_timeout
        event = Event()
        ping_interval: float = 1.5
        step: float = (const.tune.service.http_server.wait_for_url or .01) if ready is not None else ping_interval
        deadline: float = monotonic() + timeout
        next_ping: float = 0
        with xmonitor.with_watcher(service_up):
            while not event.is_set():
                if ready is not None and ready():
                    return True
                now = monotonic()
                if now >= deadline:
                    return False
                if now >= next_ping:
                    self.notify('ServicePing')
                    next_ping = now + ping_interval
                # wait for service pong (the event) or the next check
                xsleep(min(step, deadline - now), cancel_event=event)
            return True


_STREAM_SCHEMES = {
    'http', 'https',
    'tcp', 'udp',
    'rtp', 'sdp',
    'mms', 'mmst',
    'mmsh', 'rtsp',
    'rtmp', 'rtmpt',
    'rtmpe', 'rtmpte',
    'rtmps', 'shout',
    'rss', 'rsss',
}

_STREAMED_FILESYSTEM_SCHEMES = {
    'upnp',
    'ftp', 'ftps',
    'http', 'https',
    'sftp', 'ssh',
}

_LOCAL_SCHEMES = {
    '', 'file',
    'cdda', 'iso9660',
    'addons', 'sources', 'videodb', 'musicdb', 'library', 'plugin',
    'androidapp', 'win-lib',
}

_PARENT_HOSTNAME_SCHEMES = {
    'zip', 'apk', 'bluray', 'udf', 'iso9660', 'xbt', 'rar', 'archive',
}


def _get_first_stacked_file(url: str | URL) -> URL:
    """Get first file from stacked filename, separated by " , ". For stack:// scheme."""
    # format is: stack://file1 , file2 , file3 , file4
    # filenames with commas are double escaped (ie replaced with ,,), thus the " , " separator used.
    return URL(str(url).split(' , ', 1)[0].strip().replace(',,', ','))


def _get_all_multipath_files(url: str | URL) -> Iterable[URL]:
    """Get all file from multi filename, quoted and separated by "/". For multipath:// scheme."""
    # format is: multipath://file1/file2/file3
    # filenames are quoted, thus the "/" separator used.
    from urllib.parse import unquote
    url = URL(url)
    return (URL(url.scheme, unquote(part), '') for part in url.path.split('/'))


def is_streamed_filesystem(url: str | URL) -> bool:
    """Check if URL is streamed filesystem (based on Kodi C++ code)."""
    from .url import URL
    url = URL(url)
    if not url.scheme:
        return False
    if url.scheme == 'stack':
        return is_streamed_filesystem(_get_first_stacked_file(url))
    return url.scheme in _STREAMED_FILESYSTEM_SCHEMES


def is_internet_stream(url: str | URL, *, strict: bool = False) -> bool:
    """Check if URL is internet stream (based on Kodi C++ code)."""
    from .url import URL
    url = URL(url)
    if not url.scheme:
        return False
    if url.scheme == 'stack':
        return is_internet_stream(_get_first_stacked_file(url), strict=strict)
    if strict and is_streamed_filesystem(url):
        return True
    return url.scheme in _STREAM_SCHEMES


def is_remote(url: str | URL) -> bool:
    """Check if URL is remote (based on Kodi C++ code)."""
    from .url import URL
    url = URL(url)
    if url.scheme in _LOCAL_SCHEMES:
        return False
    if url.scheme == 'stack':
        return is_remote(_get_first_stacked_file(url))
    if url.scheme == 'special':
        from xbmcvfs import translatePath
        return is_remote(translatePath(str(url)))
    if url.scheme == 'multipath':
        for u in _get_all_multipath_files(url):
            if is_remote(u):
                return True
        return False
    if url.scheme in _PARENT_HOSTNAME_SCHEMES:
        # and (CServiceBroker::IsAddonInterfaceUp() && CServiceBroker::GetFileExtensionProvider().EncodedHostName(GetProtocol()));
        return is_remote(url.hostname or '')
    if url.hostname in ('localhost', '127.0.0.1', '::1'):
        return False
    return False
