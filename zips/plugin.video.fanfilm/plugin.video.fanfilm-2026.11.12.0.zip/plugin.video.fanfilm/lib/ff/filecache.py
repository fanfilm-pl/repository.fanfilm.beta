"""
Small file cache: a JSON file with data, valid while its stamp is the same.

The stamp describes everything the data depends on (versions, file modification times, ...),
so the data is computed again only when something of that changes.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from threading import get_ident
from typing import Any, Callable, Iterable, TypeVar

from .logs import fflog_exc

T = TypeVar('T')


def cached_json(path: Path, stamp: str, compute: Callable[[], T]) -> T:
    """
    Return data from the `path` file if it was stored with the same `stamp`, otherwise compute and store it.

    An empty `stamp` means unknown dependencies: the data is always computed and never stored.
    Cache problems (no file, a broken file, a failed write) are never raised, errors of `compute()` are.
    """
    if stamp:
        try:
            cached: Any = json.loads(path.read_text(encoding='utf-8'))
            if cached.get('stamp') == stamp:
                return cached['data']
        except (OSError, ValueError, KeyError, AttributeError):
            pass  # no cache yet, a broken or an old file
    data = compute()
    if stamp:
        try:
            write_atomic(path, json.dumps({'stamp': stamp, 'data': data}).encode('utf-8'))
        except OSError:
            fflog_exc()
    return data


def write_atomic(path: Path, data: bytes) -> None:
    """Write the file atomically (a reader never sees a partial file), raise OSError on failure."""
    tmp_path = path.with_name(f'{path.name}.{os.getpid()}.{get_ident()}')
    try:
        tmp_path.write_bytes(data)
        os.replace(tmp_path, path)
    except OSError:
        tmp_path.unlink(missing_ok=True)
        raise


def mtime_stamp(paths: Iterable[Path]) -> str:
    """Return a stamp of files, it changes when any file changes, appears or disappears. Empty if unknown."""
    try:
        return repr(sorted((str(path), path.stat().st_mtime_ns) for path in paths))
    except OSError:
        return ''
