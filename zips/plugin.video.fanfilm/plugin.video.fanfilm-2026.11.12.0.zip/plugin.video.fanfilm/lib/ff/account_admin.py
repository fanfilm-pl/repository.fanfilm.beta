"""
Account management: the view model and the operations, without a view.

The views (the window of accounts in Kodi, the folder `tools/accounts_folder` - also the CLI by its routes) render the rows of
`account_rows()` and the cells of `switch_cells()`, and call the operations. The operations ask the user only through
`lib.ff.ui` (Kodi dialogs or the terminal). A new account is written only after a successful sign-in.
"""

from __future__ import annotations
from typing import Any, Callable, Collection, Iterator, Sequence, cast
from typing_extensions import Literal, TypeAlias
import re
from attrs import frozen, evolve
from .accounts import (
    Account, Capability, Direction, SwitchCell, SERVICE_TYPES,
    account_store, account_client, limited_until, new_account_id, switch_value, LIST_MENU_IDS,
)
from .logs import fflog
from ..kolang import L

#: Account state in the view: the auth state, or `suspended` (inactive).
RowState: TypeAlias = Literal['authorized', 'public', 'none', 'suspended']
#: Why a switch cell is not available: the account is not authorized / is public.
CellReason: TypeAlias = Literal['', 'unauthorized', 'public']
#: How an account signs in (chosen at its first sign-in, then fixed): its user (`private`), a public user (`public`, read only,
#: the types with public users); an account is added not signed in (a private one until a public user is set).
SignInKind: TypeAlias = Literal['private', 'public']
#: The result of a sign-in: the account (maybe changed), None if canceled by the user, False if failed (the step told why).
SignInResult: TypeAlias = 'Account | None | Literal[False]'
#: An action on an account in the views (the window of accounts).
AccountAction: TypeAlias = Literal['add', 'remove', 'up', 'down', 'label', 'sign_in', 'revoke', 'refresh_profile', 'sync', 'sync_all', 'active']

#: Order of capabilities and directions in the views.
CAPABILITIES: tuple[Capability, ...] = ('progress', 'watched', 'ratings', 'lists')
#: Order of directions in the views.
DIRECTIONS: tuple[Direction, ...] = ('read', 'write')
#: Public IMDb user ID.
IMDB_USER_RX: re.Pattern[str] = re.compile(r'ur\d+')
#: How long an account waits for an IMDb cookie from the browser / a free cookie is kept (seconds).
COOKIE_WAIT: float = 600
#: Namespace (`accounts.db`) of the state of the accounts management (not an account).
ADMIN_SCOPE: str = ''
#: Key of the account waiting for an IMDb cookie from the browser.
IMDB_WAITING: str = 'imdb.cookie.waiting'
#: Key of a free IMDb cookie (no account of its user, none waiting).
IMDB_FREE: str = 'imdb.cookie.free'


@frozen
class AccountRow:
    """A row of the list of accounts."""

    #: The account.
    account: Account
    #: The title: the label and the user nick (`TMDB (klaudia-ff3)`).
    title: str
    #: The state of the account.
    state: RowState
    #: True if the account can be removed (types without users have one fixed account).
    removable: bool


@frozen
class SwitchCellView:
    """A switch cell of an account (capability x direction) in the view."""

    #: The cell (`progress.write`).
    cell: SwitchCell
    #: The own switch of the account.
    value: bool
    #: The switch with the cells it needs (what the account does).
    effective: bool
    #: Why the cell can not work now ('' - it can): the state of the account.
    reason: CellReason
    #: Cells switched on that need this one (e.g. `progress.write` needs `watched.write`).
    needed_by: tuple[SwitchCell, ...]

    @property
    def available(self) -> bool:
        """True if the cell can be switched: a public account never writes; an account not signed in can be prepared (it works after the sign-in)."""
        return self.reason != 'public'


@frozen
class ActionView:
    """An action on an account in the view: may it run now, its label and its help (what it does or why it can not)."""

    #: The action.
    action: AccountAction
    #: True if the action can run now.
    available: bool
    #: The label of the action (a button).
    label: str
    #: What the action does, or why it can not run now.
    help: str


# --- View model ---

def account_nick(account: Account) -> str:
    """Return the user nick of the account: the kept profile (no network), the public user, '' if unknown; "local" for the local Kodi."""
    from .db.accounts import account_data_store
    if account.type.name == 'kodi':
        return L(32857, 'local')  # no user: it tells the local Kodi from the services (the title "Kodi (local)")
    if not account.type.multi:
        return ''
    if nick := (account_data_store(account.id).get('profile') or {}).get('username'):
        return str(nick)
    return str(account.config.get('user') or '')


def account_tag(account: Account) -> str:
    """
    Return what tells the account from the other accounts of its type: the nick, the own label (not the type label) or the
    number of the account in its type (`#1`, `#2`...).
    """
    if nick := account_nick(account):
        return nick
    if account.label and account.label != account.type.label:
        return account.label
    ids = [acc.id for acc in account_store.accounts() if acc.type.name == account.type.name]
    return f'#{ids.index(account.id) + 1}' if account.id in ids else account.id


def account_title(account: Account) -> str:
    """Return the title of the account: the label and the nick (decision: always both, it is a list of accounts)."""
    nick = account_nick(account)
    return f'{account.label} ({nick})' if nick else account.label


def account_state(account: Account) -> RowState:
    """Return the state of the account in the view."""
    return account_store.auth_state(account) if account.active else 'suspended'


def account_rows() -> list[AccountRow]:
    """Return the rows of all accounts in order (the order is the priority)."""
    from .accounts import accounts
    return [AccountRow(account=acc, title=account_title(acc), state=account_state(acc), removable=acc.type.multi)
            for acc in accounts()]  # the types switched off in `const` are hidden


def switch_cells(account: Account) -> list[SwitchCellView]:
    """Return the switch cells of the capabilities of the account type (a cell the type has not is not there)."""
    typ = account.type
    state = account_store.auth_state(account)
    cells: list[SwitchCellView] = []
    for capability in CAPABILITIES:
        for direction in DIRECTIONS:
            if direction not in typ.capabilities.get(capability, ()):
                continue
            cell = f'{capability}.{direction}'
            if state == 'none':
                reason: CellReason = 'unauthorized'
            elif state == 'public' and direction not in typ.public.get(capability, ()):
                reason = 'public'
            else:
                reason = ''
            cells.append(SwitchCellView(cell=cell, value=switch_value(account, cell), reason=reason, needed_by=tuple(needed_cells(account, cell)),
                                        effective=account_store.switch(account, capability, direction)))
    return cells


def menu_cells(account: Account) -> list[SwitchCellView]:
    """Return the switch cells of the menus of lists the account is shown in (`menu.<id>`), for a type with entries there (`ServiceLists.entries()`)."""
    if not any('read' in account.type.capabilities.get(capability, ()) for capability in ('lists', 'ratings', 'watched')):
        return []
    return [SwitchCellView(cell=cell, value=(value := switch_value(account, cell)), effective=value, reason='', needed_by=())
            for cell in (f'menu.{menu}' for menu in LIST_MENU_IDS)]


def account_actions(account: Account) -> dict[AccountAction, ActionView]:
    """Return the actions on the account (the window of accounts): availability by its type, its state and its place in the list."""
    from .accounts import accounts
    from .sync import sync_block, syncing_accounts
    multi = account.type.multi
    signed = account_store.auth_state(account) != 'none'  # also of a suspended account
    public = account_kind(account) == 'public'
    ids = [acc.id for acc in accounts()]
    index = ids.index(account.id) if account.id in ids else -1
    builtin = L(32858, 'A built-in account (the service has no users).')
    local = account.type.name == 'kodi'

    def view(action: AccountAction, label: str, available: bool, help: str, reason: str = '') -> ActionView:
        """The action view (the reason is the help of an action that can not run)."""
        return ActionView(action=action, available=available, label=label, help=help if available or not reason else reason)

    block = sync_block(account)
    return {act.action: act for act in (
        view('add', L(32859, 'Add account…'), True, L(32860, 'Add an account: its service and its name, then sign it in.')),
        view('remove', L(32861, 'Remove account…'), multi, L(32862, 'Remove the account from FanFilm (its data in the service stay).'), builtin),
        view('up', L(32863, 'Move up'), index > 0, L(32864, 'Move the account up: the order is the priority, the first account of a service is its default one.'),
             L(32865, 'The account is the first one.')),
        view('down', L(32866, 'Move down'), 0 <= index < len(ids) - 1,
             L(32867, 'Move the account down: the order is the priority, the first account of a service is its default one.'), L(32868, 'The account is the last one.')),
        view('label', L(32869, 'Account label'), multi, L(32870, 'The name of the account in FanFilm (its ID stays).'), builtin),
        view('sign_in', L(32926, 'Change public user…') if public else L(32871, 'Sign in again…') if signed else L(32872, 'Sign in…'), multi,
             L(32927, 'Change the user of the public account (read only); another kind of account is another account.') if public
             else L(30232, 'Sign in to the service (a code or a page in the browser) or set a public user (read only).') if account.type.public and not signed
             else L(32873, 'Sign in to the service (a code or a page in the browser).'), builtin),
        view('revoke', L(32925, 'Revoke…'), multi and signed and not public,
             L(32874, 'Revoke the authorization of the account (in the service too) and forget it in FanFilm.'),
             builtin if not multi else L(32928, 'A public account has no authorization.') if public else L(32875, 'Not available: the account is not signed in')),
        view('refresh_profile', L(32876, 'Refresh profile'), multi and signed and hasattr(account_client(account), 'refresh_profile'),
             L(32877, 'Get the user of the account (its nick) from the service again.'),
             builtin if not multi else L(32875, 'Not available: the account is not signed in')),
        view('sync', L(32878, 'Synchronize'), not block,
             L(32982, 'Synchronize the account now (a sync in progress: once more after it).'),
             L(32879, 'The local Kodi needs no synchronization.') if local else sync_block_reason(account, block)),
        view('sync_all', L(32985, 'Synchronize all accounts'), bool(syncing_accounts()),
             L(32986, 'Synchronize all accounts now (the ones in progress: once more after them).'), L(32987, 'No account synchronizes anything.')),
        view('active', L(32881, 'Active'), True, L(32882, 'An inactive account keeps its data and affects nothing (no lists, progress, ratings).')),
    )}


# --- View texts (the folder of accounts and the window) ---

def sync_block_reason(account: Account, block: str) -> str:
    """Return why the account does not sync (`lib.ff.sync.sync_block()`), '' if it does."""
    if block == 'limited':
        from .calendar import from_timestamp
        until = limited_until(account.id) or limited_until(account.type.name) or 0
        return L(32996, 'Daily request limit reached, until {time}').format(time=from_timestamp(until).strftime('%H:%M'))
    return {
        'type': L(32983, 'The service has no synchronization: FanFilm reads its data when needed.'),
        'inactive': L(30153, 'The account is suspended: its waiting changes are kept until it is restored.'),
        'unauthorized': L(32875, 'Not available: the account is not signed in'),
        'public': L(30154, 'A public account: its data are read when needed (no synchronization).'),
        'nothing': L(32984, 'Nothing to synchronize: the account reads nothing from the service.'),
    }.get(block, '')


def capability_label(capability: str) -> str:
    """Return the label of the capability."""
    return {'progress': L(32883, 'Progress'), 'watched': L(32884, 'Watched'), 'ratings': L(30546, 'Ratings'),
            'lists': L(30471, 'Lists')}.get(capability, capability)


def direction_label(direction: str) -> str:
    """Return the label of the direction of a capability."""
    return L(32885, 'read') if direction == 'read' else L(32886, 'write')


def menu_label(menu: str) -> str:
    """Return the label of the menu of lists."""
    return {'lists': L(30471, 'Lists'), 'movies': L(32003, 'My Movies'), 'shows': L(32004, 'My TV Shows'),
            'persons': L(30328, 'My Persons'), 'history': L(32036, 'History')}.get(menu, menu)


def cell_label(cell: str) -> str:
    """Return the label of the switch cell, e.g. `Progress - write`, `Shown in: My Movies`."""
    capability, _, direction = cell.partition('.')
    if capability == 'menu':
        return f'{L(30197, "Shown in")}: {menu_label(direction)}'
    return f'{capability_label(capability)} – {direction_label(direction)}'


def state_label(state: RowState, account: Account) -> str:
    """Return the label of the account state (`none` of a type without users: off in `const`)."""
    if state == 'none' and not account.type.multi:
        return L(32887, 'off')
    return {'authorized': L(30654, 'authorized'), 'public': L(32888, 'public'), 'none': L(32889, 'not signed in'),
            'suspended': L(30653, 'suspended')}[state]


def reason_label(reason: CellReason) -> str:
    """Return the text of the reason a cell is not available."""
    return {'': '', 'unauthorized': L(32929, 'The account is not signed in: it works after the sign-in.'),
            'public': L(32890, 'Not available: a public account')}[reason]


def cell_help(view: SwitchCellView) -> str:
    """Return the help of the switch cell: an own switch not working, the cells that need it, or why it is not available."""
    if view.value and not view.effective:
        return L(32891, 'Off: needs another switch')
    if view.needed_by:
        return f'{L(30198, "Needed by")}: {", ".join(cell_label(c) for c in view.needed_by)}'
    return reason_label(view.reason)


# --- Operations ---

def _replace(account: Account, new: Account | None) -> bool:
    """Replace (None: remove) the account in the list and write it."""
    accounts = [new if acc.id == account.id else acc for acc in account_store.accounts()]
    return account_store.save([acc for acc in accounts if acc is not None])


def set_entry_field(account: Account, name: str, value: Any) -> Account | None:
    """Set a field of the entry of the account in `/accounts` (`Account.config`) and write it. Return the changed account, None if not written."""
    new = evolve(account, config={**account.config, name: value})
    return new if _replace(account, new) else None


def rename(account: Account, label: str) -> bool:
    """Change the label of the account (its ID stays)."""
    return bool(label.strip()) and _replace(account, evolve(account, label=label.strip()))


def set_active(account: Account, active: bool) -> bool:
    """
    Suspend (False) or restore the account: a suspended account keeps its data and its waiting changes and affects nothing;
    a restored one is synced soon (the kept changes are delivered).
    """
    if not _replace(account, new := evolve(account, active=active)):
        return False
    if active:
        _sync_soon(new)
    return True


def move(account: Account, delta: int) -> bool:
    """Move the account in the list (the order is the priority; the first account of a type is its alias)."""
    accounts = list(account_store.accounts())
    index = next(i for i, acc in enumerate(accounts) if acc.id == account.id)
    if not 0 <= (new := index + delta) < len(accounts):
        return False
    accounts.insert(new, accounts.pop(index))
    return account_store.save(accounts)


def set_switch(account: Account, cell: SwitchCell, value: bool) -> bool:
    """Set the own switch of the account cell (the view asks about the cells that need it)."""
    switches = dict(account.config.get('switches') or {})
    switches[cell] = value
    return _replace(account, evolve(account, config={**account.config, 'switches': switches}))


def sign_in_kinds(type_name: str) -> list[SignInKind]:
    """Return the ways an account of the type can sign in: its own user, a public user (types with public users)."""
    return ['private', *(['public'] if SERVICE_TYPES[type_name].public else [])]


def sign_in_kind_label(kind: SignInKind) -> str:
    """Return the label of the way an account signs in."""
    return {'private': L(32872, 'Sign in…'), 'public': L(32930, 'Public user…')}[kind]


def account_kind(account: Account) -> SignInKind:
    """Return the kind of the account: a public user (read only) or its own user (`private`, signed in or not)."""
    return 'public' if account.type.public and account.config.get('user') else 'private'


def add_account(type_name: str, label: str | None = None) -> Account | None:
    """
    Add an account of the type, not signed in (it signs in by `authorize()`, the views offer it at once): the label (asked if
    not given), the ID from it. Return the account or None (a canceled label, a type without users).
    """
    from .ui import ui
    typ = SERVICE_TYPES[type_name]
    if not typ.multi:
        return None
    if label is None:
        count = sum(acc.type.name == type_name for acc in account_store.accounts())
        if not (label := ui.input(L(32869, 'Account label'), f'{typ.label} {count + 1}' if count else typ.label)):
            return None
    account = Account(id=new_account_id(type_name, label), type=typ, label=label)
    accounts = list(account_store.accounts())
    pos = max((i + 1 for i, acc in enumerate(accounts) if acc.type.name == type_name), default=len(accounts))
    accounts.insert(pos, account)
    if not account_store.save(accounts):
        return None
    fflog(f'[ACCOUNTS] added {account.id!r}')
    return account


def authorize(account: Account, kind: SignInKind | None = None) -> bool:
    """
    Sign in the account by its kind (a public account: another public user); an account not signed in of a type with public
    users asks the kind first (unless given). Another user drops its data (the clients). A canceled / failed sign-in keeps the
    account as it is.
    """
    from .ui import ui
    if kind is None:
        kind = account_kind(account)
        if kind == 'private' and account.type.public and account_store.auth_state(account) == 'none':
            kinds = sign_in_kinds(account.type.name)
            if (index := ui.select(account.label, [sign_in_kind_label(k) for k in kinds])) < 0:
                return False
            kind = kinds[index]
    if not (new := _sign_in(account, kind, again=True)):
        fflog(f'[ACCOUNTS] sign-in of {account.id!r} ({kind}) {"canceled" if new is None else "failed"}')
        return False
    refresh_profile(new)  # the nick in the views (not every sign-in keeps the profile, e.g. TMDB), maybe another user
    _sync_soon(new)
    return new == account or _replace(account, new)


def _sync_soon(account: Account) -> None:
    """Ask the service to sync the new / signed in account (if it syncs anything)."""
    from .sync import sync_client
    if sync_client(account) is not None:
        from .db import state
        state.add_job('service', 'accounts.sync', args=(account.id,), sender='plugin')


def refresh_profile(account: Account) -> bool:
    """Get the user profile of the account again (the nick in the views), False if it can not."""
    client = account_client(account)
    return client is not None and hasattr(client, 'refresh_profile') and client.refresh_profile() is not None


def drop_old_keys() -> None:
    """
    Forget the API keys of the MDBList accounts of old versions (a key is used no more, an account signs in by a device
    code) and tell it once, quietly, for the accounts without a token (signed out).
    """
    from .ui import ui
    from .db.accounts import account_data_store
    labels: list[str] = []
    for account in account_store.accounts():
        if account.type.name == 'mdblist' and (store := account_data_store(account.id)).get('api_key') is not None:
            store.delete('api_key')
            if not (store.get('token') or {}).get('refresh_token'):  # signed in by a token already: nothing to tell
                labels.append(account.label)
    if labels:
        fflog(f'[ACCOUNTS] old MDBList keys forgotten: {", ".join(labels)}')
        ui.notify(', '.join(labels), L(30346, 'Signed out, sign in again'))


def revoke(account: Account) -> bool:
    """Revoke the authorization of the account (Trakt / TMDB: also in the service) and forget its secrets."""
    from .db.accounts import account_data_store
    client = account_client(account)
    if (unauth := getattr(client, 'unauth', None)) is not None:
        return bool(unauth())
    store = account_data_store(account.id)
    for key in SECRETS.get(account.type.name, ()):
        store.delete(key)
    store.delete('profile')
    return True


def remove(account: Account) -> bool:
    """
    Remove the account: revoke its authorization (Trakt / TMDB), its data (`accounts.db`), its lists (`lists.db`), its rows
    (`playback.db`), its lists picked for the library and its entry. Types without users have a fixed account (not removed).
    """
    from .db.accounts import remove_account_data
    from .db.lists import remove_scope
    from .db.playback import remove_account_rows
    from .lists import remove_account_tokens
    if not account.type.multi:
        return False
    if account_store.auth_state(account) == 'authorized' and hasattr(account_client(account), 'unauth'):
        revoke(account)
    if not _replace(account, None):
        return False
    remove_account_data(account.id)
    remove_scope(account.id)
    remove_account_rows(account.id)
    remove_account_tokens(account.id)
    fflog(f'[ACCOUNTS] removed {account.id!r}')
    return True


#: Secrets of the accounts of a type without the service revoke (`accounts.db` keys).
SECRETS: dict[str, tuple[str, ...]] = {'imdb': ('at-main', 'user_agent')}


def _sign_in(account: Account, kind: SignInKind, *, again: bool = False) -> SignInResult:
    """
    Sign in the account by its type and kind (the user asked through `ui`): the account (maybe changed), None if canceled,
    False if failed (told by the step).
    """
    from .ui import ui
    name = account.type.name
    client = account_client(account)
    if kind == 'public':
        if name == 'wetrakr':
            return _public_user(account, L(32894, 'WeTrakr username'), normalize=lambda user: user.strip(), valid=lambda user: bool(user) and '/' not in user)
        if name == 'imdb':
            return _public_user(account, L(32898, 'Public user (ur…)'), normalize=lambda user: f'ur{user}' if user.isdecimal() else user.strip().lower(),
                                valid=lambda user: bool(IMDB_USER_RX.fullmatch(user)), invalid=L(32900, 'Incorrect IMDb user'))
        return False
    if hasattr(client, 'auth'):  # device code / a page / e-mail: True, False (failed), None (canceled)
        result = client.auth() if name == 'trakt' else client.auth(force=again)
        if result is False and name in ('trakt', 'tmdb'):  # the others tell why
            ui.notify(account.label, L(30190, 'Authorization FAILED'), error=True)
        return account if result else result
    if name == 'imdb':
        free = free_imdb_cookie()
        kinds = [L(32896, 'Cookie at-main (paste)'), L(32897, 'Cookie from the browser (FanFilm script)…')]
        if free:
            kinds.insert(0, L(32899, 'Received cookie of {nick}').format(nick=free['profile']['username']))
        if (index := ui.select(account.label, kinds)) < 0:
            return None
        if free:
            if not index:
                return account if _assign_imdb_cookie(free, account.id) else False
            index -= 1
        if index == 1:
            return account if _wait_imdb_cookie(account) else None
        if not (cookie := ui.input(L(30621, 'IMDb at-main Cookie'))):
            return None
        target, nick = receive_imdb_cookie({'at-main': cookie.strip()}, waiting=account.id)
        if not target:
            ui.notify(account.label, L(32901, 'The cookie does not work'), error=True)
        elif target != account.id:  # the cookie of the user of another account: it got the cookie
            ui.notify(account.label, L(32902, 'The cookie of {nick} went to the account {label}').format(nick=nick, label=target))
        return account if target == account.id else False
    return False


def _public_user(account: Account, heading: str, *, normalize: Callable[[str], str], valid: Callable[[str], bool],
                 invalid: str = '') -> SignInResult:
    """Ask the user of a public account (read only, `config.user`): the account with it, None if canceled, False if not valid (told)."""
    from .ui import ui
    if not (user := normalize((ui.input(heading, str(account.config.get('user') or '')) or '').strip())):
        return None
    if not valid(user):
        ui.notify(account.label, invalid or L(32903, 'Incorrect user'), error=True)
        return False
    return evolve(account, config={**account.config, 'user': user})


# --- IMDb cookies from the browser (the FanFilm script -> the web server) ---

def receive_imdb_cookie(values: dict[str, str], *, waiting: str | None = None) -> tuple[str, str]:
    """
    Give an IMDb cookie (`at-main`, `user_agent`) to the account of its user (`whoami`): 1. the account of this user,
    2. the account waiting for a cookie (`waiting`, else the one the accounts folder waits for), 3. none: a free cookie
    kept `COOKIE_WAIT` seconds (the folder offers to add its user). Return (the account ID, '' if none; the user nick),
    ('', '') if the cookie does not work.
    """
    from .db.accounts import account_data_store, remove_account_data
    if not (cookie := values.get('at-main')):
        return '', ''
    probe = Account(id='imdb.~probe', type=SERVICE_TYPES['imdb'], label='IMDb')
    store = account_data_store(probe.id)
    store.set('at-main', cookie, ttl=COOKIE_WAIT)
    try:
        profile = account_client(probe).refresh_profile()
    finally:
        remove_account_data(probe.id)
    if not profile:
        return '', ''
    data = {'at-main': cookie, 'user_agent': values.get('user_agent', ''), 'profile': profile}
    nick = str(profile.get('username') or profile.get('id'))
    admin_store = account_data_store(ADMIN_SCOPE)
    owner = next((acc.id for acc in account_store.accounts() if acc.type.name == 'imdb' and _imdb_user(acc) == profile['id']), None)
    target = owner or waiting or admin_store.get(IMDB_WAITING)
    if not target:
        admin_store.set(IMDB_FREE, data, ttl=COOKIE_WAIT)
        fflog(f'[ACCOUNTS] a free IMDb cookie of {nick!r}')
        return '', nick
    _assign_imdb_cookie(data, target)
    if not owner:
        admin_store.delete(IMDB_WAITING)
    return target, nick


def _imdb_user(account: Account) -> str:
    """Return the IMDb user ID (`ur…`) of the account: its kept profile, got once if it has a cookie without it (e.g. an old account)."""
    from .db.accounts import account_data_store
    if not (profile := account_data_store(account.id).get('profile')) and account_data_store(account.id).get('at-main'):
        profile = account_client(account).refresh_profile()
    return str((profile or {}).get('id') or '')


def free_imdb_cookie() -> dict | None:
    """Return the free IMDb cookie (`at-main`, `user_agent`, `profile`), None if none."""
    from .db.accounts import account_data_store
    return account_data_store(ADMIN_SCOPE).get(IMDB_FREE)


def _assign_imdb_cookie(data: dict, account_id: str) -> bool:
    """Write the IMDb cookie (with its user profile) to the account (a free one is taken)."""
    from .db.accounts import account_data_store
    store = account_data_store(account_id)
    for key in ('at-main', 'user_agent', 'profile'):
        if data.get(key):
            store.set(key, data[key], ttl=None)
    if (free := free_imdb_cookie()) and free.get('at-main') == data.get('at-main'):
        account_data_store(ADMIN_SCOPE).delete(IMDB_FREE)
    fflog(f'[ACCOUNTS] IMDb cookie of {(data.get("profile") or {}).get("username")!r} -> {account_id!r}')
    return True


def _wait_imdb_cookie(account: Account) -> bool:
    """Wait (a dialog with the link, cancelable) for the cookie from the browser for the account; True if it came."""
    from time import monotonic
    from .ui import ui
    from .threads import xsleep
    from .db.accounts import account_data_store
    admin_store = account_data_store(ADMIN_SCOPE)
    admin_store.set(IMDB_WAITING, account.id, ttl=COOKIE_WAIT)
    start = monotonic()
    try:
        with ui.auth_session(title=f'{account.label}: {L(32897, "Cookie from the browser (FanFilm script)…")}', url='https://www.imdb.com/') as session:
            while (elapsed := monotonic() - start) < COOKIE_WAIT and not session.is_canceled():
                if account_data_store(account.id).get('at-main'):
                    return True
                session.update(elapsed / COOKIE_WAIT)
                xsleep(1)
        return False
    finally:
        if admin_store.get(IMDB_WAITING) == account.id:
            admin_store.delete(IMDB_WAITING)


def add_public_imdb(user: str) -> Account | None:
    """
    Add a public IMDb account of the user (`ur…`, the button of the FanFilm script), the existing account of the user if
    there is: a public one or one with the cookie of the user (it reads more, no duplicate).
    """
    from .db.accounts import account_data_store
    user = user.strip().lower()
    user = f'ur{user}' if user.isdecimal() else user
    if not IMDB_USER_RX.fullmatch(user):
        return None
    if (acc := next((acc for acc in account_store.accounts() if acc.type.name == 'imdb' and (
            acc.config.get('user') == user or (account_data_store(acc.id).get('profile') or {}).get('id') == user)), None)):
        fflog(f'[ACCOUNTS] IMDb user {user} has the account {acc.id!r}')
        return acc
    typ = SERVICE_TYPES['imdb']
    account = Account(id=new_account_id('imdb', f'{typ.label} {user}'), type=typ, label=f'{typ.label} {user}', config={'user': user})
    accounts = list(account_store.accounts())
    pos = max((i + 1 for i, acc in enumerate(accounts) if acc.type.name == 'imdb'), default=len(accounts))
    accounts.insert(pos, account)
    return account if account_store.save(accounts) else None


# --- Interactive operations of the views (they ask and tell through `lib.ff.ui`) ---

def ask_add(type_name: str | None = None) -> Account | None:
    """Add an account, not signed in: the type (asked if not given), the label (the views show the result and offer the sign-in)."""
    from .ui import ui
    if type_name is None:
        names = list(types_to_add())
        if (index := ui.select(L(32859, 'Add account…'), [SERVICE_TYPES[name].label for name in names])) < 0:
            return None
        type_name = names[index]
    return add_account(type_name)


def ask_authorize(account: Account) -> bool:
    """Sign in the account, also again (the views show the result; a failure is told by the sign-in, a cancel is not)."""
    return authorize(account)


def ask_refresh_profile(account: Account) -> bool:
    """Get the user profile of the account again (the nick), tell a failure."""
    from .ui import ui
    if refresh_profile(account):
        return True
    ui.notify(account.label, L(32904, 'Can not get the user of the account'), error=True)
    return False


def ask_sync(account: Account | None = None) -> bool:
    """Ask the service to sync the account (None: all), no waiting (the views show the state); tell no answer of the service."""
    from .ui import ui
    from ..service.client import service_client
    if service_client.accounts_sync(None if account is None else account.id, wait=False) is not None:
        return True
    ui.notify(f'[FanFilm] {L(32916, "Accounts")}', L(32988, 'Synchronization failed: no answer of the FanFilm service'), error=True)
    return False


def tell_sync_failed(failed: Collection[str], count: int) -> None:
    """Tell the failed sync of the accounts the user asked for (`count` of them), quietly (the views show which ones)."""
    from .accounts import get_account
    from .control import notification
    if len(failed) == 1:
        acc = get_account(next(iter(failed)))
        text = L(32989, 'Synchronization of the account {label} failed').format(label=acc.label if acc else next(iter(failed)))
    elif len(failed) == count:
        text = L(32990, 'Synchronization of all accounts failed')
    else:
        text = L(32991, 'Synchronization of {count} accounts failed').format(count=len(failed))
    notification(f'[FanFilm] {L(32916, "Accounts")}', text, icon='ERROR', sound=False).show()


def ask_revoke(account: Account) -> bool:
    """Revoke the authorization of the account (confirmed), tell a failure (the views show a success)."""
    from .ui import ui
    if not ui.confirm(L(32056, 'Are you sure?'), heading=f'{L(32777, "Revoke authorization")} – {account.label}'):
        return False
    if revoke(account):
        return True
    ui.notify(account.label, L(30193, 'Revoke authorization FAILED'), error=True)
    return False


def ask_remove(account: Account) -> bool:
    """Remove the account (confirmed: Trakt / TMDB authorization is revoked, its data in FanFilm are gone)."""
    from .ui import ui
    if not account.type.multi:
        return False
    message = L(32905, 'Remove the account {name}? Its lists, progress and watched will be gone from FanFilm (they stay in the service).'
                ).format(name=account_title(account))
    if hasattr(account_client(account), 'unauth'):
        message = f'{message} {L(30367, "Its authorization will be revoked in the service.")}'
    return ui.confirm(message, heading=L(32861, 'Remove account…')) and remove(account)


def ask_switch(account: Account, cell: SwitchCell) -> bool:
    """
    Toggle the switch cell of the account (a cell the kind of the account does not allow: nothing, the views tell why);
    switching off a cell needed by others asks to switch them off too. Return True if the switches changed.
    """
    from .ui import ui
    from .accounts import get_account
    view = next((c for c in (*switch_cells(account), *menu_cells(account)) if c.cell == cell), None)
    if view is None:
        return False
    if not view.available:
        return False
    set_switch(account, cell, not view.value)
    if view.value and view.needed_by:
        names = ', '.join(cell_label(c) for c in view.needed_by)
        if ui.confirm(f'{L(30510, "Switch off also")}: {names}?', heading=cell_label(cell)):
            for other in view.needed_by:
                if (acc := get_account(account.id)) is not None:
                    set_switch(acc, other, False)
    return True


def types_to_add() -> Iterator[str]:
    """Yield the names of the types an account can be added to (types with users, not switched off in `const`)."""
    from .accounts import type_enabled
    return (name for name, typ in SERVICE_TYPES.items() if typ.multi and type_enabled(name))


def cell_parts(cell: SwitchCell) -> tuple[Capability, Direction]:
    """Return the capability and the direction of the cell."""
    capability, _, direction = cell.partition('.')
    return cast(Capability, capability), cast(Direction, direction)


def needed_cells(account: Account, cell: SwitchCell) -> Sequence[SwitchCell]:
    """Return the cells switched on that need the cell (switching it off makes them not work)."""
    return [other for other, needs in account.type.requires.items() if cell in needs and switch_value(account, other)]


def account_summary(account: Account) -> list[str]:
    """
    Return the parts of the summary of the account from its kept state (no network): the server (a self-hosted service:
    `server` of the profile, its host), the plan (VIP), the request budget of the day, the changes waiting for the delivery,
    the last check of the sync; the list of accounts and the CLI show it.
    """
    from urllib.parse import urlsplit
    from .db.accounts import account_data_store
    from .db.playback import pending_count
    from .calendar import from_timestamp
    from .sync import CHECKED_KEY, FAILED_KEY, sync_block, sync_state
    store = account_data_store(account.id)
    profile = store.get('profile') or {}
    parts: list[str] = []
    if server := profile.get('server'):
        address = urlsplit(str(server))
        parts.append(f'{address.netloc}{address.path}' if address.scheme == 'https' else str(server))  # http told: not encrypted
    if profile.get('vip'):
        parts.append('VIP')
    elif plan := profile.get('plan'):
        parts.append(str(plan))
    if (budget := store.get('budget') or store.get('quota')) and (limit := budget.get('limit')) and (remaining := budget.get('remaining')) is not None:
        parts.append(L(32906, 'requests {used} / {limit}').format(used=max(0, limit - remaining), remaining=remaining, limit=limit))
    if until := limited_until(account.id) or limited_until(account.type.name):  # the account or its application
        parts.append(L(32997, 'request limit until {time}').format(time=from_timestamp(until).strftime('%H:%M')))
    if count := pending_count(account.id):
        parts.append(L(32907, '{n} change waiting|||{n} changes waiting', n=count))
    if isinstance(checked := store.get(CHECKED_KEY), int):
        parts.append(L(32908, 'synced {time}').format(time=from_timestamp(checked).strftime('%Y-%m-%d %H:%M')))
    if isinstance(failed := store.get(FAILED_KEY), int) and failed > (checked if isinstance(checked, int) else 0) and not sync_block(account):
        parts.append(L(32992, 'sync failed {time}').format(time=from_timestamp(failed).strftime('%Y-%m-%d %H:%M')))
    if state := sync_state(account.id):
        parts.append(L(32993, 'syncing now') if state == 'running' else L(32994, 'sync queued'))
    return parts


if __name__ == '__main__':
    # python3 -m lib.ff.account_admin: the accounts with their summary (the profile of `lib.fake`, see `-K` of the CLI)
    for row in account_rows():
        print(' · '.join((row.title, row.account.id, row.state, *account_summary(row.account))))
