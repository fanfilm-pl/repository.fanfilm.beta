from __future__ import annotations
from typing import Protocol, overload, TYPE_CHECKING
from functools import wraps
from concurrent.futures import ThreadPoolExecutor
from requests import *  # noqa: F401, F403  # type: ignore
import requests as _requests
from .threads import check_thread_cancel
from const import CONST_REF
from cdefs import const_value

if TYPE_CHECKING:
    from typing_extensions import Any, Literal, Unpack, ParamSpec, TypeVar, Callable, ClassVar
    from collections import Counter
    from requests import (adapters, api, auth, certs, check_compatibility, codes, compat, cookies, exceptions, hooks, models, packages,  # noqa: F401
                          sessions, status_codes, structures,)
    from ._requests_types import RequestFunctionArgs, RequestMethodArgs, RequestOrigArgsWithoutUrl, SomeRequestOrigArgs
    from ._requests_types import JsonResult, Data, Method
    P = ParamSpec('P')
    R = TypeVar('R')
    S = TypeVar('S', bound='Session')


# Disable warnings about insecure requests, it is global setting.
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class Session(_requests.Session):
    """requests.Session with ThreadCanceled support and default request arguments (`with_defaults()`)."""

    DEFAULTS: ClassVar[SomeRequestOrigArgs] = {}

    def __init__(self, defaults: SomeRequestOrigArgs | None = None) -> None:
        super().__init__()
        #: Default request arguments of this session (over the class `DEFAULTS`).
        self.defaults: SomeRequestOrigArgs = defaults or {}

    def request(self,  # type: ignore[override]
                method: Method,
                url: str,
                **kwargs: Unpack[RequestOrigArgsWithoutUrl],
                ) -> Response:
        """Send the request (`check_thread_cancel()` before and after)."""
        check_thread_cancel()
        if self.DEFAULTS or self.defaults:
            kwargs = {**{k: const_value(v) for k, v in {**self.DEFAULTS, **self.defaults}.items()}, **kwargs}  # a `CONST_REF` read now
        result = super().request(method=method, url=url, **kwargs)
        check_thread_cancel()
        return result


def request(method: Method, url: str, **kwargs: Unpack[RequestFunctionArgs]) -> Response:
    """Proxy to requests.request with ThreadCanceled suport."""
    with Session() as session:
        return session.request(method=method, url=url, **kwargs)


def get(url: str, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.get with ThreadCanceled suport."""
    return request('GET', url, params=params, **kwargs)


def options(url: str, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.options with ThreadCanceled suport."""
    return request('OPTIONS', url, params=params, **kwargs)


def head(url: str, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.head with ThreadCanceled suport."""
    kwargs.setdefault('allow_redirects', False)
    return request('HEAD', url, params=params, **kwargs)


def post(url: str, data: Data = None, json: JsonResult | None = None, *, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.post with ThreadCanceled suport."""
    return request('POST', url, params=params, data=data, json=json, **kwargs)


def put(url: str, data: Data = None, json: JsonResult | None = None, *, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.put with ThreadCanceled suport."""
    return request('PUT', url, params=params, data=data, json=json, **kwargs)


def patch(url: str, data: Data = None, json: JsonResult | None = None, *, params: Data = None, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.patch with ThreadCanceled suport."""
    return request('PATCH', url, params=params, data=data, json=json, **kwargs)


def delete(url: str, **kwargs: Unpack[RequestMethodArgs]) -> Response:
    """Proxy to requests.delete with ThreadCanceled suport."""
    return request('DELETE', url, **kwargs)


class RequestFuncProto(Protocol):
    """Protocol for request functions."""
    DEFAULTS: ClassVar[SomeRequestOrigArgs]
    @overload
    def __call__(self, func: type[S], /) -> type[S]: ...
    # def __call__(self, func: type[Session], /) -> type[Session]: ...
    @overload
    def __call__(self, func: Callable[P, R], /) -> Callable[P, R]: ...


@overload
def with_defaults(cls: type[S], name: str | None = None, /,
                  **defaults: Unpack[SomeRequestOrigArgs],
                  ) -> type[S]: ...


@overload
def with_defaults(func: Callable[P, R], /,
                  **defaults: Unpack[SomeRequestOrigArgs],
                  ) -> Callable[P, R]: ...


@overload
def with_defaults(_: Literal[None] = None, /,
                  **defaults: Unpack[SomeRequestOrigArgs],
                  ) -> RequestFuncProto: ...


def with_defaults(func: Callable[P, R] | None = None, name: str | None = None, /,
                  **defaults: Unpack[SomeRequestOrigArgs],
                  ) -> Any:
    """Decorator to set default arguments for requests session or functions.
    IMPORTANT: func must be Session class compatible or request function supporting the same arguments as requests.request (SomeRequestOrigArgs)."""

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        """Decorate."""
        @wraps(func)
        def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
            kwargs = {**{k: const_value(v) for k, v in defaults.items()}, **kwargs}  # type: ignore[reportAssignmentType]  (a `CONST_REF` read now)
            return func(*args, **kwargs)

        # -- check compatibility with Session class or requests.request function --
        # from inspect import signature
        # sig = signature(func)
        # if isinstance(func, type):
        #     assert 'defaults' in sig.parameters, (f'Class {func.__name__} does not have "defaults" parameter for with_defaults decorato'
        #                                           ' (it should be compatible with Session class)')
        # else:
        #     from typing_extensions import get_args as get_typing_args
        #     from _requests_types import SomeRequestOrigArgs
        #     def_names = set(get_typing_args(SomeRequestOrigArgs))
        #     assert (def_names & sig.parameters.keys() == def_names), (f'Function {func.__name__} does not have any of the parameters in SomeRequestOrigArgs'
        #                                                               ' for with_defaults decorator (it should be compatible with requests.request function)')

        # class decorator
        if isinstance(func, type):
            # cls = type(f'{func.__name__}WithDefaults', (func,), {'defaults': defaults})
            func.DEFAULTS = defaults
            return func

        return wrapped

    # define decorator (decorator called with arguments)
    if func is None:
        return decorator
    # -- direct decorator (decorator called without arguments) or direct definition (class/function with defaults) --
    # direct class definition with defaults (e.g. A = with_defaults(SEssion, ...)): create new class with defaults attribute
    if isinstance(func, type):
        from types import new_class
        cls = new_class(name or func.__name__, (func,),
                        exec_body=lambda ns: ns.update((('DEFAULTS', {**getattr(func, 'DEFAULTS', {}), **defaults}),)))
        cls_as_callable: Callable[P, R] = cls  # type: ignore[assignment]
        func = cls_as_callable
    return decorator(func)


#: Request session for providers, with default timeout for requests to avoid hanging.
ProviderSession = with_defaults(Session, timeout=CONST_REF.sources.request_timeout)


class RequestsPoolExecutor(ThreadPoolExecutor):
    """ThreadPoolExecutor for requests (threads named `requests-*`)."""

    def __init__(self,
                 max_workers: int | None = None,
                 thread_name_prefix: str = 'requests-',
                 initializer: Callable[[], object] | None = None,
                 initargs: tuple[()] = (),
                 ) -> None:
        super().__init__(max_workers=max_workers, thread_name_prefix=thread_name_prefix, initializer=initializer, initargs=initargs)


#: HTTP requests per host (`count_http()`), None until counting is installed.
_http_counter: Counter[str] | None = None


def count_http() -> Counter[str]:
    """Count HTTP requests sent to the network (per host) from now on, any session (cache hits are not sent)."""
    global _http_counter
    if _http_counter is None:
        from collections import Counter
        from urllib.parse import urlsplit
        from requests.adapters import HTTPAdapter
        counter: Counter[str] = Counter()
        send = HTTPAdapter.send

        def counting_send(self: HTTPAdapter, request: _requests.PreparedRequest, *args: Any, **kwargs: Any) -> _requests.Response:
            counter[urlsplit(request.url or '').netloc] += 1
            return send(self, request, *args, **kwargs)

        HTTPAdapter.send = counting_send  # type: ignore[method-assign]
        _http_counter = counter
    _http_counter.clear()  # the interpreter is reused by next plugin calls
    return _http_counter

if __name__ == '__main__':

    def test2():
        A = with_defaults(Session, timeout=5)

        @with_defaults(timeout=6)
        class B(Session):
            Z = 1

        @with_defaults
        class C(Session):
            pass

        def _t(**kwargs: Unpack[SomeRequestOrigArgs]) -> float | tuple[float, float] | None:
            return kwargs.get('timeout')

        f1 = with_defaults(timeout=7)(_t)
        f2 = with_defaults(_t, timeout=8)

        assert A.DEFAULTS.get('timeout') == 5
        assert B.DEFAULTS.get('timeout') == 6
        assert 'timeout' not in C.DEFAULTS
        assert f1() == 7
        assert f2() == 8

        a = A()
        assert a.DEFAULTS.get('timeout') == 5

    test2()
