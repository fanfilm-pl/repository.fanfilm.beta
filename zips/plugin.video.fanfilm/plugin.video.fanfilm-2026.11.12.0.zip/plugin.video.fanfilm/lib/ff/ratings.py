
from __future__ import annotations
from typing_extensions import Any, Literal, Mapping, Collection, Iterable, TypeVar, Generic, cast, TYPE_CHECKING
from typing_extensions import Union  # Union for py3.8
# from numbers import Number
from decimal import Decimal
from functools import lru_cache
from attrs import define, frozen, evolve
from .tricks import round_to_step
from .logs import fflog, fflog_exc
from ..kolang import L
from .accounts import SERVICE_TYPES
from const import const
if TYPE_CHECKING:
    from cdefs import RatingServiceName, RatingAction
    from ..defs import FFRef, RefType, MediaRef
    from .accounts import Account, Direction
# from typing_extensions import reveal_type  # TESTING


# N = TypeVar('N', bound=int | float | Decimal, contravariant=True)
N = TypeVar('N', bound=Union[int, float, Decimal], contravariant=True)  # Union for py3.8
# T = TypeVar('T', bound=Number, default=int)
# T = TypeVar('T', bound=int | float | Decimal, default=int)
# T = TypeVar('T', bound=int | float, default=int)
T = TypeVar('T', int, float, Decimal, default=int)

NORM_MIN = 1
NORM_MAX = 10
RatingType = Literal[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

NORM_LEN = NORM_MAX - NORM_MIN
NORM_RANGE = range(NORM_MIN, NORM_MAX + 1)


@define
class MediaRating(Generic[T]):
    """Media rating with normalization."""

    #: The raw service rating value before any normalization.
    raw_rating: T
    #: The rating service.
    service: RatingService[T]

    @property
    def rating(self) -> RatingType:
        """The normalized rating value (1-10 scale)."""
        return self.service.from_service_rating(self.raw_rating)

    @rating.setter
    def rating(self, value: int):
        self.raw_rating = self.service.to_service_rating(value)


def pick_ratings(ratings: Mapping[MediaRef, T], refs: Iterable[FFRef] | None) -> Mapping[MediaRef, T]:
    """Return the ratings of the media `refs` (all without `refs`), for `AccountClient.ratings()`."""
    if refs is None:
        return ratings
    return {ref.ref: rating for ref in refs if (rating := ratings.get(ref.ref)) is not None}


@frozen(kw_only=True)
class RatingScale(Generic[T]):
    """Rating scale of a service (`AccountClient.RATING`): the raw rating `type` from `min` to `max` by `step`, and the rated media."""

    type: type[T] = int  # type: ignore[reportAssignmentType]
    min: T = type(1)
    max: T = type(10)
    step: T = type(1)
    offset: T = type(0)
    #: Rated media.
    media: Collection[RefType] = ()

    def from_service_rating(self, rating: T) -> RatingType:
        """Normalize a rating (from service's scale to general)."""
        # Normalize to a 1-10 scale
        normalized = NORM_MIN + (rating - self.min - self.offset) * NORM_LEN / (self.max - self.min)
        norm = int(max(NORM_MIN, min(NORM_MAX, normalized)))
        return norm  # type: ignore[return-value]

    def to_service_rating(self, rating: int) -> T:
        """Denormalize a rating (from general scale to service's)."""
        # Normalize to the service's scale (from 1-10 scale)
        normalized = self.type(round_to_step(self.min + (rating - NORM_MIN) * (self.max - self.min) / NORM_LEN, self.step))
        if self.step < 0:
            return min(self.min, max(self.max, normalized))
        return max(self.min, min(self.max, normalized))


@frozen(kw_only=True)
class RatingService(Generic[T]):
    """Rating service: a type x an account, the scale and the ratings from its client (`AccountClient.RATING`, `ratings()`, `set_ratings()`)."""

    #: The type name.
    name: RatingServiceName
    title: str = ''
    color: str = ''
    #: The account of the service, None - the type alias (the first account).
    account: Account | None = None
    #: The scale if not the one of the client (tests of the dialog).
    rating_scale: RatingScale[T] | None = None

    def __attrs_post_init__(self):
        """Post-initialization adjustments."""
        if not self.title:
            object.__setattr__(self, 'title', self.name.capitalize())

    @property
    def key(self) -> str:
        """Return the key of the service: the account ID (the type name for the type alias)."""
        return self.name if self.account is None else self.account.id

    def _instance(self) -> Any:
        """Return the API client of the account."""
        from .accounts import account_client, alias_client
        return alias_client(self.name) if self.account is None else account_client(self.account)

    @property
    def scale(self) -> RatingScale[T]:
        """Return the rating scale (of the client)."""
        if self.rating_scale is not None:
            return self.rating_scale
        return type(self._instance()).RATING

    @property
    def real_types(self) -> Collection[RefType]:
        """Return the rated media."""
        return self.scale.media

    def from_service_rating(self, rating: T) -> RatingType:
        """Normalize a rating (from service's scale to general)."""
        return self.scale.from_service_rating(rating)

    def to_service_rating(self, rating: int) -> T:
        """Denormalize a rating (from general scale to service's)."""
        return self.scale.to_service_rating(rating)

    def get_rating(self, ref: FFRef, *, fresh: bool = False) -> MediaRating[T] | None:
        """
        Get normalized rating for the given media reference: from the rated lists of the account (the list cache), `fresh` -
        asked now (the ratings window): the rating of the media if the client has it (`rating()`), else the ratings bucket
        synced first (a changed one makes the rated lists stale).
        """
        if ref.ref.real_type not in self.real_types:
            return None
        client = self._instance()
        if fresh and (one := getattr(client, 'rating', None)) is not None:
            rating = one(ref)
        else:
            if fresh and self.account is not None and 'ratings' in getattr(client, 'SYNC_BUCKETS', ()):
                from .sync import sync_account
                sync_account(self.account, client, buckets=('ratings',))
            rating = client.ratings([ref]).get(ref.ref)
        if rating is None:
            return None
        return MediaRating(raw_rating=rating, service=self)

    def set_rating(self, ref: FFRef, rating: int | MediaRating[T]) -> bool:
        """Set normalized rating for the given media reference."""
        if ref.ref.real_type not in self.real_types:
            return False
        raw = rating.raw_rating if isinstance(rating, MediaRating) else self.to_service_rating(rating)
        return bool(self._instance().set_ratings([ref], raw))

    def remove_rating(self, ref: FFRef) -> bool:
        """Remove rating for the given media reference."""
        if ref.ref.real_type not in self.real_types:
            return False
        return bool(self._instance().set_ratings([ref], None))

    def list_ratings(self, refs: Iterable[FFRef]) -> Mapping[MediaRef, MediaRating[T]]:
        """List ratings for the given media references (from the rated lists of the account, not a request per media)."""
        refs = [ref for ref in refs if ref.ref.real_type in self.real_types]
        if not refs:
            return {}
        return {ref: MediaRating(raw_rating=rating, service=self) for ref, rating in self._instance().ratings(refs).items()}


# AnyRatingService = RatingService[int] | RatingService[float] | RatingService[Decimal]
AnyRatingService = Union[RatingService[int], RatingService[float], RatingService[Decimal]]  # Union for py3.8


#: Avaliable rating services: the account types with ratings (the type alias).
all_rating_services: dict[RatingServiceName, AnyRatingService] = {
    cast('RatingServiceName', name): RatingService(name=cast('RatingServiceName', name), title=typ.label)
    for name, typ in SERVICE_TYPES.items() if typ.client and 'ratings' in typ.capabilities
}

def rating_services() -> dict[RatingServiceName, AnyRatingService]:
    """Return the enabled rating services (`const.ratings.enabled`), each with its color for UI (`const.dialog.ratings.colors`)."""
    enabled = const.ratings.enabled
    return _rating_services(enabled if isinstance(enabled, bool) else tuple(enabled), tuple(const.dialog.ratings.colors))


@lru_cache(maxsize=1)  # by the values of const: the same services until a reload of const changes them
def _rating_services(enabled: bool | tuple[str, ...], colors: tuple[str, ...]) -> dict[RatingServiceName, AnyRatingService]:
    """Return the enabled rating services with their colors."""
    services: dict[RatingServiceName, AnyRatingService] = cast('dict[RatingServiceName, AnyRatingService]', (
        {} if not enabled else
        all_rating_services if enabled is True else
        {srv.name: srv for name in enabled if (srv := all_rating_services.get(cast('RatingServiceName', name)))}
    ))
    return colored_services(services, colors)


#: The key of a mapping of the rating services (a service name, a test name of the dev demo).
K = TypeVar('K', bound=str)


def colored_services(services: Mapping[K, AnyRatingService], colors: Collection[str] | None = None) -> dict[K, AnyRatingService]:
    """Return the services, each with its color for UI in their order (`colors`, default: `const.dialog.ratings.colors`, cycled)."""
    colors = tuple(const.dialog.ratings.colors if colors is None else colors)
    return {name: evolve(srv, color=colors[i % len(colors)]) if colors else srv for i, (name, srv) in enumerate(services.items())}  # type: ignore[misc]


def account_rating_services() -> dict[str, AnyRatingService]:
    """
    Return the rating services of all accounts (a type x an account, key = the account ID), in order of accounts:
    the label of an account outside the settings, a color per account.
    """
    from .accounts import accounts, only_account
    services: dict[str, AnyRatingService] = {}
    colors = const.dialog.ratings.colors
    for acc in accounts():
        if (srv := rating_services().get(cast('RatingServiceName', acc.type.name))) is not None:
            color = colors[len(services) % len(colors)] if colors else srv.color
            services[acc.id] = evolve(srv, account=acc, title=srv.title if only_account(acc) else acc.label, color=color)  # type: ignore[assignment]
    return services


def enabled_rating_services(*,
                            action: RatingAction | None,
                            setting: str | bool = True,
                            ref: FFRef | None = None,
                            media_type: RefType | None = None,
                            ) -> dict[str, AnyRatingService]:
    """
    Get enabled rating services of accounts (key = the account ID): the account is enabled for ratings (`get` reads, other
    actions write) and the media type fits.

    `setting` is the caller's switch: a boolean or a setting expression, could contain subname {service} (the type name).
    """
    from .settings import settings
    from .accounts import account_enabled

    direction: Direction = 'read' if action in (None, 'get') else 'write'

    def is_enabled(srv: AnyRatingService) -> bool:
        if not account_enabled(srv.account or srv.name, 'ratings', direction, action=action):
            return False
        if ref is not None and ref.ref.real_type not in srv.real_types:
            return False
        if media_type is not None and media_type not in srv.real_types:
            return False
        try:
            if not settings.eval(setting, {'service': srv.name}):
                return False
        except KeyError:
            if isinstance(setting, str):
                from simpleeval.format import safe_xformat
                fflog.info(f'No setting found for rating service enable check: {safe_xformat(setting, service=srv.name)}')
            # no kodi setting, assume enabled
        except Exception:
            fflog_exc()
        return True

    return {key: srv for key, srv in account_rating_services().items() if is_enabled(srv)}


def rate_media(item: FFRef,
               *,
               action: RatingAction | None,
               setting: str | bool = True,
               if_not_rated: bool = False,
               ) -> bool:
    """Show rating dialog and set or remove rating for the given media."""
    from concurrent.futures import ThreadPoolExecutor
    from .item import FFItem
    from ..windows.ratings import RatingsDialog
    # No rating services enabled.
    # services = enabled_rating_services(setting=f'{{service}}.rate_after_watch.{item.ref.real_type}')
    services = enabled_rating_services(action=action, setting=setting, ref=item)
    if not services:
        fflog('No rating services enabled')
        return False
    # Get FFItem for the given item (if not given).
    if not isinstance(item, FFItem):
        from .info import ffinfo
        if (found := ffinfo.find_item(item, progress=ffinfo.Progress.NO)) is None:
            return False
        item = found
    # Get existing ratings (concurrently).
    with ThreadPoolExecutor() as ex:
        futures = [ex.submit(srv.get_rating, item, fresh=True) for srv in services.values()]  # the window: asked now
    ratings = [fut.result() for fut in futures if fut.result() is not None]
    # Skip if already rated.
    if if_not_rated and ratings:
        fflog.debug(f'Media {item.ref:a} already rated, skipping rating dialog')
        return False
    # Show rating dialog.
    win = RatingsDialog(ffitem=item, ratings=ratings, services=services)
    rating = win.do_modal()
    # Cancelled.
    if rating is None:
        return False
    if rating == RatingsDialog.REMOVE_RATING:
        # Remove rating.
        with ThreadPoolExecutor() as ex:
            futures = [ex.submit(srv.remove_rating, item) for srv in services.values()]
        ok = any(fut.result() for fut in futures)
    else:
        # Set rating.
        with ThreadPoolExecutor() as ex:
            futures = [ex.submit(srv.set_rating, item, rating) for srv in services.values()]  # type: ignore[arg-type]
        ok = any(fut.result() for fut in futures)
    if const.dialog.ratings.notification:
        from .kotools import Notification
        if rating == RatingsDialog.REMOVE_RATING:
            msg = L(30341, 'Rating removed for {title}').format(title=item.title)
        else:
            msg = L(30342, 'Rating {rating} set for {title}').format(rating=rating, title=item.title)
        if ok:
            Notification(L(30343, 'Rating updated'), msg, sound=False).show()
        else:
            Notification(L(30344, 'Rating FAILED'), msg, icon='WARNING').show()
    return ok
