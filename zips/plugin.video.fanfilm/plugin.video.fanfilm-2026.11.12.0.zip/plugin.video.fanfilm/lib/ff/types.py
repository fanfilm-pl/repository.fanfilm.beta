"""
Common types of FanFilm: the types of the SDK (`lib.sdk.types`, no import of FanFilm) and the FanFilm argument types
(`URL` on a path, `SplitResult` annotation). The modules import the types from here: `from lib.ff.types import ...`.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from urllib.parse import SplitResult
from ..sdk.types import (  # noqa: F401  (the types of FanFilm)
    ANN_TYPES, AnnMeta, ArgDescr, Args, EllipsisType, EnumArg, EnumDumper, EnumEnum, EnumFullName, EnumName, EnumValue,
    FALSE_VALUES, Headers, JsonData, JsonResult, KwArgs, LiteralArg, PY38_TYPES, PagedItems, Params, Path, Positive,
    ReferenceType, SequenceProto, StrEnum, TRUE_VALUES, TypeForm, UPath, Unsigned, ann_type, eval_annotations,
    find_arg_descr, flag_names, get_args, get_type_hints, is_datetime_instance, is_literal, is_optional, is_union,
    mk_bool, mk_none, mk_path, mk_upath, none_arg, NoneType, pint, remove_optional, ufloat, uint,
)

if TYPE_CHECKING:
    from .url import URL


def mk_url(v: str) -> URL:
    """Make simple URL."""
    from .url import URL
    if not v.startswith('/'):
        v = f'/{v}'
    return URL(v)


ANN_TYPES[SplitResult] = ArgDescr(mk_url, r'.+')
