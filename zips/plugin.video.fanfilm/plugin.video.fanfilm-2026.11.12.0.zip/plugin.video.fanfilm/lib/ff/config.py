"""
User configuration of FanFilm: `config.json` in the add-on profile, the choices made in FF windows.

Values are addressed by JSON Pointer (`/sources/addons/<add-on ID>/active`, RFC 6901: `~1` is `/`, `~0` is `~`), so
keys with dots (add-on IDs) are plain keys. Not the internal policies (`const`) nor the Kodi settings (`settings.xml`).
"""

from __future__ import annotations
import json
import os
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from threading import RLock
from typing import Any, Callable, Generator, Mapping
from typing_extensions import TypeAlias
from attrs import define
from .logs import fflog, fflog_exc
from .tricks import MISSING

#: Version of the `config.json` data (a file of an older version is migrated, `MIGRATIONS`).
CONFIG_VERSION: int = 9

#: Stat of a file (mtime, size), None if it does not exist.
FileStat: TypeAlias = 'tuple[float, int] | None'


def file_stat(path: Path) -> FileStat:
    """Return the stat (mtime, size) of the file, None if it does not exist."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    return st.st_mtime, st.st_size


def write_json_atomic(path: Path, data: Any) -> FileStat:
    """Write JSON atomically (a temporary file renamed). Return its stat, None on error (logged)."""
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
        return file_stat(path)
    except OSError:
        fflog_exc(f'[CONFIG] can not write {path}')
        tmp.unlink(missing_ok=True)
        return None


def _migrate_2(data: dict[str, Any]) -> None:
    """Version 2: the switch of an entry is `active` (as of the accounts), not `enabled` (the external add-ons of sources)."""
    addons = data.get('sources', {}).get('addons') if isinstance(data.get('sources'), dict) else None
    for entry in (addons.values() if isinstance(addons, dict) else ()):
        if isinstance(entry, dict) and 'enabled' in entry:
            entry['active'] = entry.pop('enabled')


def _migrate_3(data: dict[str, Any]) -> None:
    """
    Version 3: the switches of the entries of the menus are in `/menus` (`lib.ff.menu_entries`): "My persons" from the folder
    points of the lists, the anime in the main menu from the settings (`anime_folder`, the setting removed).
    """
    folders = data.get('lists', {}).get('folders') if isinstance(data.get('lists'), dict) else None
    if isinstance(folders, dict) and isinstance(shown := folders.pop('persons.my.shown', None), bool) and not shown:
        data.setdefault('menus', {}).setdefault('person.my', {})['shown'] = False
    if isinstance(folders, dict) and not folders:
        del data['lists']['folders']
        if not data['lists']:
            del data['lists']
    from .settings import settings
    if anime := settings.moved_setting('anime_folder'):
        if anime.lower() == 'true':
            data.setdefault('menus', {}).setdefault('anime', {})['shown'] = True
        settings.clear_moved_settings(['anime_folder'])


def _migrate_4(data: dict[str, Any]) -> None:
    """
    Version 4: the highlight color and the list order of a native provider (`/sources/providers/<name>`) are the values of
    its node of the tree of the source providers (`/sources/nodes/<name>`: `color`, `priority` - bigger first).
    """
    from ..sources.natives import OLD_NODE_SETTINGS, node_from_old
    sources = data.get('sources')
    providers = sources.get('providers') if isinstance(sources, dict) else None
    for name, values in (providers.items() if isinstance(providers, dict) else ()):
        if isinstance(values, dict) and any(key in values for key in OLD_NODE_SETTINGS):
            if node := node_from_old(*(values.pop(key, None) for key in OLD_NODE_SETTINGS)):
                sources.setdefault('nodes', {}).setdefault(name, node)


def _migrate_5(data: dict[str, Any]) -> None:
    """Version 5: the active themes are a list (`/gui/themes`, the most important first), not the one chosen theme (`/gui/theme`)."""
    gui = data.get('gui')
    if not isinstance(gui, dict) or 'theme' not in gui:
        return
    if isinstance(theme := gui.pop('theme'), str) and theme:
        gui.setdefault('themes', [theme])
    if not gui:
        del data['gui']


def _migrate_6(data: dict[str, Any]) -> None:
    """
    Version 6: a color setting of Kodi with its old default changed since (`OLD_SETTING_COLORS`) is removed from the user settings once,
    the new default shown (Kodi keeps the old default of an add-on setting); that colour chosen by hand later is kept.
    """
    from ..sources.natives import OLD_SETTING_COLORS
    from .settings import settings
    values = settings.user_values()
    if old := [sid for sid, color in OLD_SETTING_COLORS.items() if values.get(sid, '').upper() == color]:
        settings.clear_moved_settings(old)


def _migrate_7(data: dict[str, Any]) -> None:
    """
    Version 7: the settings of the sources (the colours, the row, the search; `lib.sources.source_settings`) are in `/sources/settings`,
    moved out of the user settings of Kodi (their definitions removed: read as texts) by one write of the file.
    """
    from ..sources.source_settings import migrate_legacy
    from .settings import settings
    if moved := migrate_legacy(data, settings.user_values()):
        settings.clear_moved_settings(moved)


def _migrate_8(data: dict[str, Any]) -> None:
    """Version 8: the languages of the providers moved to the settings of the sources after version 7 (`migrate_legacy()`), removed from the user file."""
    from ..sources.source_settings import migrate_legacy
    from .settings import settings
    if (value := settings.user_values().get('providers.lang')) is not None:
        migrate_legacy(data, {'providers.lang': value})
        settings.clear_moved_settings(['providers.lang'])


def _migrate_9(data: dict[str, Any]) -> None:
    """
    Version 9: the server of a Floppy account is a field of its entry of `/accounts` (configuration: in a backup), copied from
    the account data (`accounts.db`, kept there: a file not written would lose it).
    """
    from .db.accounts import account_data_store
    for entry in (data.get('accounts') if isinstance(data.get('accounts'), list) else ()):
        if isinstance(entry, dict) and entry.get('type') == 'floppy' and isinstance(entry.get('id'), str) and not entry.get('server'):
            if server := account_data_store(entry['id']).get('server'):
                entry['server'] = server


#: Migrations of the data: the version -> the change of the data of the version before (in place).
MIGRATIONS: dict[int, Callable[[dict[str, Any]], None]] = {
    2: _migrate_2,
    3: _migrate_3,
    4: _migrate_4,
    5: _migrate_5,
    6: _migrate_6,
    7: _migrate_7,
    8: _migrate_8,
    9: _migrate_9,
}


def migrate_data(data: dict[str, Any], *, version: int, migrations: Mapping[int, Callable[[dict[str, Any]], None]], first: int = 1) -> bool:
    """
    Migrate the data (in place) to the `version` by the `migrations` of the versions after theirs (no version: `first`).
    Return True if they changed.
    """
    current = data.get('version', first)
    if not isinstance(current, int) or current >= version:
        return False
    for ver in range(current + 1, version + 1):
        if (step := migrations.get(ver)) is not None:
            step(data)
    data['version'] = version
    return True


def migrate(data: dict[str, Any]) -> bool:
    """Migrate the data of `config.json` (in place) to `CONFIG_VERSION` (no version: 1). Return True if they changed."""
    return migrate_data(data, version=CONFIG_VERSION, migrations=MIGRATIONS)


def escape_key(key: str) -> str:
    """Return the key escaped for a JSON Pointer (`~0`, `~1`)."""
    return key.replace('~', '~0').replace('/', '~1')


def pointer_keys(pointer: str) -> list[str]:
    """Return the keys of a JSON Pointer (`/a/b~1c` -> `['a', 'b/c']`; '' -> the whole document)."""
    if not pointer:
        return []
    if not pointer.startswith('/'):
        raise ValueError(f'JSON Pointer must start with "/": {pointer!r}')
    return [key.replace('~1', '/').replace('~0', '~') for key in pointer[1:].split('/')]


def _remove_keys(data: dict[str, Any], keys: list[str]) -> bool:
    """Remove the value at the keys (the objects left empty too) from the data in place. Return True if it was there."""
    nodes = [data]
    for key in keys[:-1]:
        if not isinstance(child := nodes[-1].get(key), dict):
            return False
        nodes.append(child)
    if keys[-1] not in nodes[-1]:
        return False
    del nodes[-1][keys[-1]]
    for node, key in zip(reversed(nodes[:-1]), reversed(keys[:-1])):
        if node[key]:
            break
        del node[key]
    return True


@define(kw_only=True)
class _Changes:
    """The changes of a block of `ConfigStore.batch()`: the fresh data of the file, changed in place."""

    #: The path of the file.
    path: Path
    #: The data of the file read at the start of the block (a copy, migrated), changed by the block.
    data: dict[str, Any]
    #: False if the file is broken (nothing is changed nor written).
    valid: bool
    #: True if the block changed the data.
    changed: bool = False
    #: The result of the block: the changes written (or none to write), in a nested block the changes taken (written by the outer one).
    ok: bool = True


class ConfigStore:
    """
    The configuration file: read again when it changes (another process, a hand edit), a change is written to the fresh
    file (a change of another process is kept). A broken file is never overwritten (a change fails, logged). The data of
    an older version are migrated (`migrate`: the migrations of `config.json` by default).
    """

    def __init__(self, path: Callable[[], Path], *, migrate: Callable[[dict[str, Any]], bool] = migrate) -> None:
        #: Returns the path of the file (at call time).
        self.path: Callable[[], Path] = path
        #: Migrates the data to the current version in place (True: changed).
        self.migrate: Callable[[dict[str, Any]], bool] = migrate
        #: The data read last (not changed in place: a change builds new data).
        self._data: dict[str, Any] = {}
        #: Stat of the file the data were read from.
        self._stat: FileStat = None
        #: True if the file was read.
        self._loaded: bool = False
        #: False if the file read last is broken (its data are empty then).
        self._valid: bool = True
        #: Guards reading and writing.
        self._lock: RLock = RLock()
        #: The changes of the running block (`batch()`, its thread holds the lock), None out of a block.
        self._changes: _Changes | None = None

    def _read(self, path: Path) -> tuple[dict[str, Any], FileStat, bool]:
        """Return the data of the file, its stat and False if it is broken (the data empty then)."""
        stat = file_stat(path)
        if stat is None:
            return {}, None, True
        try:
            with open(path, encoding='utf-8') as f:
                data = json.load(f)
        except (OSError, ValueError) as exc:
            fflog.warning(f'[CONFIG] broken {path} ({exc}), not used')
            return {}, stat, False
        if not isinstance(data, dict):
            fflog.warning(f'[CONFIG] broken {path} (not an object), not used')
            return {}, stat, False
        if self.migrate(data):
            fflog(f'[CONFIG] {path} migrated to version {data.get("version")}')
            stat = write_json_atomic(path, data) or stat  # not written (logged): migrated again next time
        return data, stat, True

    def data(self) -> dict[str, Any]:
        """Return the whole configuration (do not change it)."""
        path = self.path()
        if not self._loaded or file_stat(path) != self._stat:
            with self._lock:
                self._data, self._stat, self._valid = self._read(path)
                self._loaded = True
        return self._data

    @property
    def valid(self) -> bool:
        """Return False if the file is broken (nothing in it is used, it is never overwritten)."""
        self.data()
        return self._valid

    def get(self, pointer: str, default: Any = None) -> Any:
        """Return a copy of the value at the pointer, `default` if there is none."""
        node: Any = self.data()
        for key in pointer_keys(pointer):
            if not isinstance(node, dict) or key not in node:
                return default
            node = node[key]
        return deepcopy(node)

    def get_bool(self, pointer: str, default: bool) -> bool:
        """Return the switch at the pointer, `default` if there is none (or it is not a bool)."""
        value = self.get(pointer)
        return value if isinstance(value, bool) else default

    def set(self, pointer: str, value: Any, *, default: Any = MISSING) -> bool:
        """
        Set the value at the pointer (missing objects made) in the fresh file and write it, remove it if it is the `default`
        (only the changes are stored: a changed default reaches everyone who did not change it). Return True if written (in a
        block of `batch()`: taken, written at its end).
        """
        if default is not MISSING and value == default:
            return self.remove(pointer)
        keys = pointer_keys(pointer)
        if not keys:
            raise ValueError('The whole configuration can not be set')
        with self._batch() as changes:
            if changes.valid:
                node = changes.data
                for key in keys[:-1]:
                    if not isinstance(child := node.get(key), dict):
                        child = node[key] = {}
                    node = child
                node[keys[-1]] = deepcopy(value)
                changes.changed = True
        return changes.ok

    def remove(self, *pointers: str) -> bool:
        """
        Remove the values at the pointers (the objects left empty too) in the fresh file and write it once.
        Return True if written or none of them there (in a block of `batch()`: taken, written at its end).
        """
        paths = [pointer_keys(pointer) for pointer in pointers]
        if not all(paths):
            raise ValueError('The whole configuration can not be removed')
        with self._batch() as changes:
            if changes.valid and any([_remove_keys(changes.data, keys) for keys in paths]):  # a list: every pointer removed
                changes.changed = True
        return changes.ok

    @contextmanager
    def batch(self) -> Generator[None, None, None]:
        """
        Write the changes of the block (`set()`, `remove()`: one user action) once at its end, to the fresh file read at its start;
        an exception in the block writes nothing (the whole action or none of it), a nested block joins the outer one. The other
        threads wait for the end of the block; reads in it (`get()`, `data()`) see the file before it.
        """
        with self._batch():
            yield

    @contextmanager
    def _batch(self) -> Generator[_Changes, None, None]:
        """Return the changes of the block (a nested one: of the outer block), written at the end of the outermost one (`batch()`)."""
        with self._lock:
            if (outer := self._changes) is not None:
                yield outer
                return
            path = self.path()
            data, _, valid = self._read(path)
            data = deepcopy(data)
            # a new file: the migrations of the settings moved here run (no version: 1), written even if the block changes nothing (the old ones are gone)
            migrated = valid and self.migrate(data)
            changes = self._changes = _Changes(path=path, data=data, valid=valid, changed=migrated, ok=valid)
            try:
                yield changes
            finally:
                self._changes = None
            if changes.valid and changes.changed:
                changes.ok = self._write(path, changes.data)

    def _write(self, path: Path, data: dict[str, Any]) -> bool:
        """Write the changed data (under the lock) and keep them. Return True if written."""
        # ponytail: no lock between processes (read - change - write is short, changes are user actions), add a lock file if it races
        if (stat := write_json_atomic(path, data)) is None:
            return False
        self._data, self._stat, self._loaded, self._valid = data, stat, True, True
        return True


def _config_path() -> Path:
    """Return the path of `config.json` (the add-on profile)."""
    from .control import dataPath
    return Path(dataPath) / 'config.json'


#: The user configuration of FanFilm.
config: ConfigStore = ConfigStore(_config_path)
