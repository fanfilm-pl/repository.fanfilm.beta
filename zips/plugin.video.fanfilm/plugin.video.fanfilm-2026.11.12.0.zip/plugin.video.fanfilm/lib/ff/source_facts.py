"""
The source facts (`lib.sdk.facts`) for the user: the labels of the fact values (one table, a change is one line) and
the text of the facts in the row of a source.
"""

from __future__ import annotations
from typing import Iterable, TYPE_CHECKING
from ..sdk.facts import (Term, VideoCodec, Hdr, AudioCodec, TrackKind, AudioRecording, SubtitleKind, ReleaseSource, Edition, Container)
from ..kolang import L
if TYPE_CHECKING:
    from ..sdk.facts import Facts, AudioTrack


#: The labels of the fact values (the languages are shown by their codes).
FACT_LABELS: dict[Term, str] = {
    VideoCodec.H264: 'H264',
    VideoCodec.HEVC: 'HEVC',
    VideoCodec.AV1: 'AV1',
    VideoCodec.VP9: 'VP9',
    VideoCodec.MPEG4: 'XviD',
    VideoCodec.MPEG2: 'MPEG-2',
    VideoCodec.VC1: 'VC-1',
    Hdr.HDR: 'HDR',
    Hdr.HDR10: 'HDR10',
    Hdr.HDR10_PLUS: 'HDR10+',
    Hdr.DOLBY_VISION: 'DV',
    Hdr.HLG: 'HLG',
    AudioCodec.AAC: 'AAC',
    AudioCodec.AC3: 'AC3',
    AudioCodec.EAC3: 'DD+',
    AudioCodec.TRUEHD: 'TrueHD',
    AudioCodec.DTS: 'DTS',
    AudioCodec.DTS_ES: 'DTS-ES',
    AudioCodec.DTS_HD: 'DTS-HD',
    AudioCodec.DTS_HD_MA: 'DTS-HD MA',
    AudioCodec.DTS_X: 'DTS:X',
    AudioCodec.FLAC: 'FLAC',
    AudioCodec.LPCM: 'LPCM',
    AudioCodec.MP3: 'MP3',
    AudioCodec.OPUS: 'Opus',
    TrackKind.ORIGINAL: L(30544, 'original'),
    TrackKind.DUBBING: L(30545, 'dubbing'),
    TrackKind.LEKTOR: L(30592, 'voice-over'),
    TrackKind.AUDIO_DESCRIPTION: L(30630, 'audio description'),
    AudioRecording.MIC: 'MD',
    AudioRecording.LINE: 'LD',
    SubtitleKind.FULL: L(30183, 'subtitles'),
    SubtitleKind.FORCED: L(30635, 'forced subtitles'),
    SubtitleKind.SDH: L(30636, 'SDH subtitles'),
    ReleaseSource.CAM: 'CAM',
    ReleaseSource.TELESYNC: 'TS',
    ReleaseSource.TELECINE: 'TC',
    ReleaseSource.SCREENER: 'SCR',
    ReleaseSource.PPV: 'PPV',
    ReleaseSource.TV: 'TV',
    ReleaseSource.VHS: 'VHS',
    ReleaseSource.DVD: 'DVD',
    ReleaseSource.DVDRIP: 'DVDRip',
    ReleaseSource.HDRIP: 'HDRip',
    ReleaseSource.WEB: 'WEB',
    ReleaseSource.WEBDL: 'WEB-DL',
    ReleaseSource.WEBRIP: 'WEBRip',
    ReleaseSource.BDRIP: 'BDRip',
    ReleaseSource.BLURAY: 'BluRay',
    Edition.EXTENDED: 'Extended',
    Edition.DIRECTORS_CUT: "Director's Cut",
    Edition.THEATRICAL: 'Theatrical',
    Edition.UNCUT: 'Uncut',
    Edition.UNRATED: 'Unrated',
    Edition.REMASTERED: 'Remastered',
    Edition.RESTORED: L(30637, 'Digital restoration'),
    Edition.IMAX: 'IMAX',
    Edition.CRITERION: 'Criterion',
    Container.MKV: 'MKV',
    Container.MP4: 'MP4',
    Container.AVI: 'AVI',
    Container.TS: 'TS',
    Container.MPG: 'MPG',
    Container.WMV: 'WMV',
    Container.MOV: 'MOV',
    Container.WEBM: 'WebM',
    Container.FLV: 'FLV',
}

#: Containers shown in the row of a source: they often do not play well while streamed.
ROW_CONTAINERS: frozenset[Container] = frozenset({Container.AVI, Container.TS, Container.MPG, Container.WMV, Container.FLV})


def label(value: Term) -> str:
    """Return the label of a fact value."""
    return FACT_LABELS.get(value, str(value))


def is_multi(facts: Facts) -> bool:
    """Check if the audio has a track of unknown languages (MULTI, dual audio)."""
    return any('lang' in track and track['lang'] is None for track in facts.get('audio', ()))


def audio_language(tracks: Iterable[AudioTrack]) -> str:
    """
    Return the language of a source from its audio tracks: Polish if a track is, `multi` if a track has unknown languages,
    else the first language, '' if no language is known (subtitles do not give it).
    """
    langs = [track['lang'] for track in tracks if 'lang' in track]
    if 'pl' in langs:
        return 'pl'
    if None in langs:
        return 'multi'
    return langs[0] if langs else ''


#: The words of the track kinds in the language type of a source (`info` of the providers), the first found kind wins.
KIND_WORDS: dict[TrackKind, str] = {
    TrackKind.DUBBING: 'Dubbing',
    TrackKind.LEKTOR: 'Lektor',
}


def language_type(facts: Facts, tracks: Iterable[AudioTrack] | None = None) -> str:
    """
    Return the language type of a source in the words of the providers (`Lektor`, `Dubbing Kino`, `Lektor AI`, `Napisy`,
    `Multi`): the track kind (a cinema dubbing, AI), the subtitles, more audio languages. `tracks`: the audio tracks
    instead of the ones of the facts.
    """
    audio = list(facts.get('audio', ()) if tracks is None else tracks)
    parts: list[str] = []
    if track := next((track for kind in KIND_WORDS for track in audio if track.get('kind') == kind), None):
        cinema = track.get('kind') == TrackKind.DUBBING and (facts.get('release', {}).get('source') == ReleaseSource.CAM
                                                            or any('recording' in other for other in audio))
        parts.append(' '.join(word for word in (KIND_WORDS[track['kind']], 'Kino' if cinema else '', 'AI' if track.get('ai') else '') if word))
    if subtitles := facts.get('subtitles'):
        parts.append('Napisy AI' if any(sub.get('ai') for sub in subtitles) else 'Napisy')
    langs = [track['lang'] for track in audio if 'lang' in track]
    if None in langs or len(set(langs)) > 1:
        parts.append('Multi')
    return ' '.join(parts)


def facts_text(facts: Facts) -> str:
    """
    Return the text of the facts in the row of a source: the source, the video, the audio tracks, 3D, the editions, the
    container. Not the facts the providers give in their info (shown as it is): sign language, colorized, DRM.
    """
    video = facts.get('video', {})
    release = facts.get('release', {})
    source = ' '.join(text for text in (label(release['source']) if 'source' in release else '', 'REMUX' if release.get('remux') else '') if text)
    hdr = ' '.join(label(value) for value in video.get('hdr', ()))
    fps = f'{video["fps"]} fps' if 'fps' in video else ''
    audio = ' · '.join(text for track in facts.get('audio', ())
                       if (text := ' '.join(part for part in (label(track['codec']) if 'codec' in track else '', track.get('channels', ''),
                                                               'Atmos' if track.get('atmos') else '',
                                                               label(track['recording']) if 'recording' in track else '') if part)))
    container = release.get('container')
    parts = (source, label(video['codec']) if 'codec' in video else '', hdr, fps, audio, '3D' if video.get('three_d') else '',
             *(label(value) for value in release.get('edition', ())), label(container) if container in ROW_CONTAINERS else '')
    return ' | '.join(part for part in parts if part)
