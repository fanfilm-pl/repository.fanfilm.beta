"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
from typing import overload
import json
import xml.etree.ElementTree as ET
from functools import lru_cache

from xbmc import getCondVisibility, getInfoLabel
from xbmcvfs import translatePath
from xbmcgui import ListItem

from . import control
from .db import state
from .item import FFItem
from .types import JsonData
from ..indexers.defs import VideoIds
from .logs import fflog, fflog_exc
from .control import current_call, resources_file
from .kotools import stop_playing
from .kodidb import video_db
from .settings import settings
from ..sources import Source
from ..sdk.protocol import ResolveResult, resolve_result, headers_text
from const import const, PlayCancel, MediaWatchedMode


@lru_cache(maxsize=1)
def _external_player_exts() -> frozenset:
    try:
        tree = ET.parse(translatePath('special://userdata/playercorefactory.xml'))
    except Exception:
        return frozenset()
    ep = {p.get('name') for p in tree.findall('.//player') if p.get('type') == 'ExternalPlayer'}
    rules = [r for r in tree.findall('.//rule') if r.get('player') in ep]
    if any(r.get('video') == 'true' or r.get('internetstream') == 'true' for r in rules if not r.get('filetypes')):
        return frozenset({'*'})
    return frozenset(e.lstrip('*.') for r in rules if (ft := r.get('filetypes')) for e in ft.lower().split('|') if e and '!' not in e)


def server_file(fname: str) -> str:
    return resources_file(fname)  # HACK, use file from disk (resources/media/)
    # url = state.get('url', module='service', mode=state.StateMode.DB)
    # return f'{url}{fname}'


def fallback_path() -> str:
    """Falback for play movie/eposode FF3 URL."""
    from sys import argv
    if len(argv) >= 2:
        return argv[0] + argv[2]
    return ''


def cancel(ffitem: FFItem | None = None) -> None:  # TODO: remove ffitem?
    """Cancel starting a video play."""
    # fflog(f'[PLAYER] CANCEL, {ffitem=}')
    try:
        # pli = get_player_item()
        if getInfoLabel('ListItem.Label') and getInfoLabel('ListItem.PercentPlayed') == '0' and not getCondVisibility('ListItem.IsResumable'):
            # has info and play from beggining
            cancel_mode = const.player.cancel_start  # typically PlayCancel.DATA
        else:
            # resume or missing info (we don't know if resume or not, resume is more safty)
            cancel_mode = const.player.cancel_resume  # typically PlayCancel.DATA

        item = ListItem() if (path := cancel_mode.path) is None else ListItem(path=server_file(path))
        if mime := cancel_mode.mime:
            item.setMimeType(mime)
        item.setContentLookup(False)  # we don't need HEAD
        fflog(f'[PLAYER] CANCEL, mode={cancel_mode.name}, {ffitem=}, path={item.getPath()!r}')
        if ffitem:
            fflog(f'[PLAYER] CANCEL, {ffitem.getPath()=}')
        # PlayCancel.FALSE plays nothing, no player event comes: the service must not wait for one (it would stop
        # the next video played by anything else) and the player is not ours to stop (e.g. music goes on).
        no_play = cancel_mode is PlayCancel.FALSE
        # Kodi stores the placeholder play (last played, its resume point) under the played URL: the service puts back this one.
        restore: JsonData | None = None
        if not no_play:
            try:
                restore = video_db.file_details(fallback_path())
            except Exception:
                fflog_exc()
        state.multi_set(module='player', values=(
            ('playing.empty', not no_play),
            ('playing.run', False),
            ('cancel.mode', cancel_mode.value),
            ('cancel.restore', restore),
            ('state', '' if no_play else 'cancel'),
        ))
        control.resolved_url(current_call().handle, not no_play, item)
        if no_play:
            control.close_busy_dialog()
        else:
            stop_playing(stop=not cancel_mode.ends_itself)
        # PlayCancel.TT430: the service refreshes the list after the placeholder stops (const.player.refresh_on_cancel_resume)

    except Exception:
        fflog_exc()


@overload
def play(*, source: Source) -> None: ...

@overload
def play(*, ffitem: FFItem, url: str) -> None: ...

def play(*, source: Source | None = None, ffitem: FFItem | None = None, url: str | None = None) -> None:
    """Resolve and start a video play."""

    if source is None:
        if not url:
            return cancel(ffitem)
        if ffitem is None or url is None:
            raise ValueError(f'Use `source` or (`ffitem` and `url`): got nothing')
        source = Source(url=url, provider='', hosting='', ffitem=ffitem)
    elif ffitem is not None or url is not None:
        raise ValueError(f'Use `source` or (`ffitem` and `url`) not both')
    ffitem = source.ffitem
    main = ffitem.show_item or ffitem
    # the resolve result (a source not resolved by FanFilm, e.g. a URL to play, has the old text form)
    stream = source.stream if source.stream is not None else resolve_result(source.url)
    url = source.url if 'parts' in stream else stream.get('url', '')
    headers = stream.get('headers', {})

    # OpenDML AVI has its index chained through the file; ffmpeg seeks to every
    # piece to open it, blowing Kodi's 30 s demuxer-open timeout over a slow host.
    # Route *.avi through the service range proxy (parallel index prefetch).
    if url.split('?', 1)[0].lower().endswith('.avi') and '127.0.0.1' not in url:
        try:
            from ..service.avi_proxy import proxy_path
            if _svc := state.get('url', module='service', mode=state.StateMode.DB, from_boot=True):
                url = f'{_svc.rstrip("/")}/{proxy_path(url)}'
        except Exception:
            fflog_exc()

    fflog(f'[PLAYER] {url=}, ref={ffitem.ref:a}, {ffitem=}, ffid={ffitem.ffid}', stack_depth=2)
    if not url or url == 'empty':
        return cancel(ffitem)
    try:
        fflog(f'[PLAYER] {url=}')
        item = ffitem.clone()
        vtag = ffitem.vtag

        imdb = vtag.getIMDBNumber() or vtag.getUniqueID('imdb') or ''
        tmdb = int(vtag.getUniqueID('tmdb') or 0)
        ids = VideoIds(tmdb=tmdb, imdb=imdb).ids()

        if const.player.set_dbid and (kodi_dbid := video_db.get_kodi_dbid(ffitem.ref)):
            vtag.setDbId(kodi_dbid)  # Kodi DBID
        elif const.core.media_watched_mode is not MediaWatchedMode.FAKE_DBID and ffitem.ffid not in VideoIds.KODI:
            vtag.setDbId(0)  # Reset Kodi DBID, seems it does NOT work

        # --- play modes: the provider's hint (its stream needs ISA) wins, then the source attributes ---
        play_mode = stream.get('play') or 'auto'
        if play_mode == 'auto':
            play_mode = source.attr.play or 'auto'
        if play_mode == 'isa':
            ia = True
        elif play_mode == 'direct':
            ia = False
        else:  # auto
            ia = bool(settings.getBool('isa.enabled') and source.is_m3u8())

        fflog(f'Play mode {play_mode!r}: ISA = {ia}, DRM = {"drm" in stream}')
        if 'drm' in stream:
            item = get_drm_item(url, stream=stream, item=item)
            if not item:
                fflog('[DRM] could NOT resolve item')
        elif ia:
            import inputstreamhelper
            from .. import kodi

            isa = stream.get('isa', {})
            if '.mpd' in url:
                protocol = 'mpd'
                mimetype = 'application/dash+xml'
            else:
                protocol = 'hls'
                mimetype = 'application/x-mpegURL'
            protocol = isa.get('protocol') or protocol
            mimetype = isa.get('mimetype') or mimetype

            is_helper = inputstreamhelper.Helper(protocol)
            if not is_helper.check_inputstream():
                return cancel(ffitem)

            listitem = item
            listitem.setProperty('inputstream', is_helper.inputstream_addon)
            if kodi.version < 21:
                listitem.setProperty('inputstream.adaptive.manifest_type', protocol)
            listitem.setMimeType(mimetype)
            listitem.setContentLookup(False)
            if headers:
                listitem.setProperty('inputstream.adaptive.stream_headers', headers_text(headers))
            if kodi.version > 19 and (manifest_headers := isa.get('manifest_headers', headers)):
                listitem.setProperty('inputstream.adaptive.manifest_headers', headers_text(manifest_headers))
            if config := isa.get('config'):
                listitem.setProperty('inputstream.adaptive.config', config)
            listitem.setPath(url)
        else:
            if headers and not url.startswith(('plugin://', 'stack://')):
                from .settings import players_settings
                # For direct play we can only set headers via ListItem properties, so we use the same format as for ISA (key=value pairs separated by |)
                # Found by our girl, we don't now why. TODO: Figure out when and why it is working.
                for key, val in headers.items():
                    item.setProperty(key, val)
                # Determine if is external player.
                if players_settings.bar_headers_support(url):
                    url = f'{url}|{headers_text(headers)}'
                fflog(f'[PLAYER] Direct: headers via setProperty, strip={"|" not in url}')
            item.setPath(url)
            item.setContentLookup(const.player.head_lookup)
        if item is None:
            return cancel(ffitem)
        # Kodi keeps the IMDB number as the DEFAULT unique ID (setIMDBNumber() sets the default one), so the default has
        # to be "imdb": with "tmdb" the IMDb ID replaced the TMDB one and e.g. TMDb Helper could not find the video.
        unique_ids = main.vtag.getUniqueIDs()
        item.vtag.setUniqueIDs(unique_ids, 'imdb' if unique_ids.get('imdb') else 'tmdb')

        # external subtitles of the provider
        if subtitle_files := [url for sub in stream.get('subtitles', ()) if (url := sub.get('url'))]:
            item.setSubtitles(subtitle_files)
            fflog(f'[PLAYER] Added {len(subtitle_files)} subtitles to ListItem')

        # item.setInfo(type="video", infoLabels=control.metadataClean(meta))
        fflog(f'setResolvedUrl(url={url!r})')

        state.multi_set(module='player', values=(
            ('media.ref', ffitem.ref),
            ('media.imdb', imdb),
            ('media.tmdb', tmdb),
            ('media.season', ffitem.season),
            ('media.episode', ffitem.episode),
            ('media.ffid', ffitem.ffid),
            ('media.real_type', ffitem.ref.real_type),
            ('media.duration', ffitem.vtag.getDuration()),
            ('media.url', ffitem.getPath() or fallback_path()),
            ('playing.empty', False),
            ('playing.run', True),
            ('cancel.mode', None),
            ('cancel.restore', None),
            ('state', 'play'),
        ))
        control.window().setProperty("script.trakt.ids", json.dumps(ids))
        control.resolved_url(current_call().handle, True, item)
        # close_busy_dialog()

    except Exception:
        fflog_exc()


def get_drm_item(url: str, *, stream: ResolveResult, item: FFItem | None = None) -> FFItem | None:
    """
    DRM support by Lantash: the manifest `url` with the license of the resolve result `stream` (`isa`, `drm`).

    InputStream old properties – deprecated (Kodi 18-22).
    See: https://github.com/xbmc/inputstream.adaptive/wiki/Integration-DRM
    """
    import inputstreamhelper
    from .. import kodi
    isa = stream.get('isa', {})
    drm = stream.get('drm', {})
    protocol = isa.get('protocol', '')
    licence_header = headers_text(drm.get('licence_header', {}))

    # pass drm= so inputstreamhelper also installs/verifies the Widevine CDM, not just inputstream.adaptive
    is_helper = inputstreamhelper.Helper(protocol, drm=drm.get('type') or None)
    if not is_helper.check_inputstream():
        return None

    if item is None:
        item = FFItem(path=url, offscreen=True)
    else:
        item.setPath(url)
        item.vtag.setPath(url)
    item.setContentLookup(False)

    item.setProperty('inputstream', is_helper.inputstream_addon)
    item.setMimeType(isa.get('mimetype', ''))
    if kodi.version < 21:
        item.setProperty('inputstream.adaptive.manifest_type', protocol)
    if kodi.version <= 21:
        item.setProperty('inputstream.adaptive.license_type', drm.get('type', ''))
        if licence_url := drm.get('licence_url'):
            license_config = {'license_server_url': licence_url,
                              'headers': licence_header,
                              'post_data': drm.get('post_data', ''),
                              'response_data': drm.get('response_data', ''),
                              }
            item.setProperty('inputstream.adaptive.license_key', '|'.join(license_config.values()))
    if kodi.version >= 22:
        drm_configs = {
            "com.widevine.alpha": {
                "license": {
                    "server_url": drm.get('licence_url', ''),
                    "req_headers": licence_header,
                }
            }
        }
        item.setProperty('inputstream.adaptive.drm', json.dumps(drm_configs))
    item.setProperty('IsPlayable', 'true')
    return item
