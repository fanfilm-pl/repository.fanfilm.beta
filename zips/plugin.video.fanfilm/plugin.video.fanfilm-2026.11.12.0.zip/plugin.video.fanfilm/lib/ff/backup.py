"""
Backup of the user data of FanFilm: one ZIP file of the parts the user chose (`PARTS`), with a manifest (the parts, the versions
of the data). The Kodi settings (`settings.xml`) and the configuration (`config.json`) are always in it; the access data
(`/accounts` and the values tuning the log format: passwords, keys, logins - `log.format.tunes()`, `tuned_setting()`) can be
left out (a pattern of the settings for others). The state of the accounts (`accounts.db`: tokens, sync cursors) is never in it:
a refresh token rotates, the current state is always newer (a new installation signs in again).

A restore writes the settings first (the migrations of the configuration read the moved settings there), then the JSON files
(their data migrated as by their stores, read again by them), then the databases (the rows of a backup copy migrated as a
database of its own, then put into the tables of the open database: no file is replaced under the service). A part left out
(not chosen or not in the backup) keeps the current data; a part of a newer FanFilm is not restored.

Backups are made in the add-on profile (the old ones removed, `const.tune.settings.vacuum_files` kept) or in a folder chosen by
the user (any Kodi path: `xbmcvfs`). The old backups of the settings only (`settings-*.xml` in the profile) are restored too.
A restore first makes the undo backup of the current data (all the parts, in the profile, the last one only kept).
"""

from __future__ import annotations
import json
import os
import re
import sqlite3
import zipfile
from contextlib import closing, contextmanager
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
from typing import Any, Callable, Collection, Generator, Mapping, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from attrs import field, frozen
import xbmcvfs
from .logs import fflog, fflog_exc, log
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from .db.orm import DbCursor, OrmDatabase

#: The name of a part of a backup.
PartName: TypeAlias = Literal['config', 'access', 'filters', 'ownlists', 'search']

#: The file name of a backup (`datetime.strftime()`).
BACKUP_FORMAT: str = 'fanfilm-backup-%Y%m%d-%H%M.zip'
#: The file name of the undo backup made before a restore (`datetime.strftime()`).
UNDO_FORMAT: str = 'fanfilm-undo-%Y%m%d-%H%M.zip'
#: The file name prefix of the undo backup.
UNDO_PREFIX: str = 'fanfilm-undo-'
#: The file names of the backups and the undo backups (any suffix of a second one of the same minute).
BACKUP_RX: re.Pattern[str] = re.compile(r'fanfilm-(?:backup|undo)-\d{8}-\d{4}(?:\+\d{3})?\.zip')
#: The manifest of a backup in its ZIP file.
MANIFEST: str = 'manifest.json'
#: The version of the format of a backup (a newer one is not read).
BACKUP_VERSION: int = 1
#: The Kodi settings of the add-on in a backup.
SETTINGS_FILE: str = 'settings.xml'
#: The configuration in a backup.
CONFIG_FILE: str = 'config.json'
#: The selections of the sources in a backup.
FILTERS_FILE: str = 'source_filters.json'


def _own_lists_db() -> OrmDatabase:
    """Return the database of the own lists."""
    from .ownlists import own_db
    return own_db.db


def _search_db() -> OrmDatabase:
    """Return the database of the search history."""
    from .db.search import db
    return db


@frozen(kw_only=True)
class BackupPart:
    """A part of a backup (a check box of the backup window)."""

    #: The name (in the manifest).
    name: PartName
    #: The label.
    label: str
    #: The help (what the part is).
    help: str = ''
    #: Always in a backup and always restored (no choice).
    always: bool = False
    #: Chosen by default at a backup.
    checked: bool = True
    #: The data of the part whose version is in the manifest ('' the part itself, e.g. a database).
    data: str = ''
    #: The database of the part, None: not a database (no repr: a template variable of the backup window, the key of its cached XML).
    database: Callable[[], OrmDatabase] | None = field(default=None, repr=False)


#: The parts of a backup in their order.
PARTS: tuple[BackupPart, ...] = (
    BackupPart(name='config', label=L(30986, 'Settings and configuration'), always=True,
               help=L(30987, 'The settings of FanFilm and its configuration: menus, lists, source providers, appearance.')),
    BackupPart(name='access', label=L(30988, 'Accounts and access data'), data='config',
               help=L(30989, 'Accounts, logins, passwords, keys. Off: the settings for someone else; a restore keeps the current ones.')),
    BackupPart(name='filters', label=L(30990, 'Source filters and sorting'),
               help=L(30991, 'The sets of the filters and the sorting of the sources, the current choices.')),
    BackupPart(name='ownlists', label=L(30992, 'Own lists'), database=_own_lists_db,
               help=L(30993, 'The lists of FanFilm itself (not those of the accounts).')),
    BackupPart(name='search', label=L(30994, 'Search history'), checked=False, database=_search_db,
               help=L(30995, 'The searches made and the edited source searches.')),
)


@frozen(kw_only=True)
class Backup:
    """A backup file in a folder."""

    #: The path (a Kodi path: any folder).
    path: str
    #: The file name.
    name: str
    #: An old backup of the settings only (`settings-*.xml`).
    legacy: bool = False

    @property
    def undo(self) -> bool:
        """The undo backup made before a restore (by its file name)."""
        return self.name.startswith(UNDO_PREFIX)


# --- Paths ---


def profile_folder() -> str:
    """Return the add-on profile (the default folder of the backups)."""
    from .control import dataPath
    return str(dataPath)


def _local(path: str) -> Path | None:
    """Return the local path of a Kodi path, None if it is not a local one (a network share)."""
    local = xbmcvfs.translatePath(path)
    return None if '://' in local else Path(local)


def _join(folder: str, name: str) -> str:
    """Return the path of a file in a Kodi folder."""
    return f'{folder.rstrip("/")}/{name}' if '://' in folder else str(Path(folder) / name)


@contextmanager
def _local_copy(path: str) -> Generator[Path, None, None]:
    """Give a local path of the file: itself, else a temporary copy (removed after)."""
    if (local := _local(path)) is not None:
        yield local
        return
    tmp = Path(profile_folder()) / f'.backup-read-{os.getpid()}.zip'
    if not xbmcvfs.copy(path, str(tmp)):
        raise OSError(f'can not read {path}')
    try:
        yield tmp
    finally:
        tmp.unlink(missing_ok=True)


def backups(folder: str | None = None) -> list[Backup]:
    """Return the backups in the folder (None: the profile, with the old backups of the settings), the newest first."""
    profile = folder is None
    folder = profile_folder() if folder is None else folder
    if (local := _local(folder)) is not None:
        names = [path.name for path in local.iterdir() if path.is_file()] if local.is_dir() else []
    else:
        names = xbmcvfs.listdir(folder)[1]
    found = [Backup(path=_join(folder, name), name=name) for name in names if BACKUP_RX.fullmatch(name)]
    if profile:
        from .settings import settings
        found.extend(Backup(path=str(path), name=path.name, legacy=True) for path in settings.backup_files())
    return sorted(found, key=lambda backup: _created(backup.name), reverse=True)


def _created(name: str) -> str:
    """Return the date of a backup by its file name (to sort the new and the old ones together)."""
    return ''.join(re.findall(r'\d+', name))


# --- Access data ---


def _access_nodes(root: ET.Element) -> list[ET.Element]:
    """Return the Kodi settings with access data (keys, passwords) of the settings file."""
    return [node for node in root.iterfind('setting') if log.format.tunes(node.get('id') or '')]


def _settings_with_access(data: bytes, source: bytes | None) -> bytes:
    """Return the settings file with the access data of the `source` file (None: none)."""
    root = ET.fromstring(data)
    for node in _access_nodes(root):
        root.remove(node)
    if source is not None:
        root.extend(_access_nodes(ET.fromstring(source)))
    return ET.tostring(root)


def with_access(data: Mapping[str, Any], source: Mapping[str, Any]) -> dict[str, Any]:
    """
    Return the configuration with the access data of the configuration `source` ({}: none): the accounts (`/accounts`) and the
    values of the native providers which are access data (`tuned_setting()`).
    """
    from ..sources.natives import PROVIDERS_CONFIG, tuned_setting
    from .config import pointer_keys

    def providers(conf: dict[str, Any], *, create: bool = False) -> dict[str, Any]:
        """Return the values of the native providers in the configuration ({} if none; `create`: made in it)."""
        node: Any = conf
        for key in pointer_keys(PROVIDERS_CONFIG):
            if create:
                node = node.setdefault(key, {})
            elif not isinstance(node := node.get(key), dict):
                return {}
        return node

    def access_keys(values: dict[str, Any]) -> dict[str, list[str]]:
        """Return the keys of the access data of the providers by their names."""
        return {name: [key for key in entry if tuned_setting(name, key)] for name, entry in values.items() if isinstance(entry, dict)}

    result = deepcopy(dict(data))
    result.pop('accounts', None)
    if 'accounts' in source:
        result['accounts'] = deepcopy(source['accounts'])
    own = providers(result)
    for name, keys in access_keys(own).items():
        for key in keys:
            del own[name][key]
        if not own[name]:
            del own[name]
    other = providers(deepcopy(dict(source)))
    for name, keys in access_keys(other).items():
        if keys:
            providers(result, create=True).setdefault(name, {}).update({key: other[name][key] for key in keys})
    return result


# --- Backup ---


def _versions() -> dict[str, int]:
    """Return the versions of the data of this FanFilm (the configuration, the filters, the databases of the parts)."""
    from .config import CONFIG_VERSION
    from .source_filters import FILTERS_VERSION
    versions = {'backup': BACKUP_VERSION, 'config': CONFIG_VERSION, 'filters': FILTERS_VERSION}
    versions.update({part.name: part.database().version for part in PARTS if part.database is not None})  # the open ones: migrated
    return versions


def _free_name(folder: str, name_format: str = BACKUP_FORMAT) -> str:
    """Return a free file name of a new backup in the folder (`name_format`: of `datetime.strftime()`)."""
    name = datetime.now().strftime(name_format)
    taken = {backup.name for backup in backups(folder)}
    stem, _, suffix = name.rpartition('.')
    return next(new for new in (name, *(f'{stem}+{i:03d}.{suffix}' for i in range(1, 1000))) if new not in taken)


def make_backup(parts: Collection[str], folder: str | None = None) -> str:
    """Make a backup of the parts (the ones `always` too) in the folder (None: the profile). Return its path, '' on failure (logged)."""
    path = _write_backup(parts, folder)
    if path and folder is None:
        vacuum()
    return path


def make_undo() -> str:
    """Make the undo backup of the current data (all the parts, in the profile), the older ones removed. Return its path, '' on failure."""
    path = _write_backup([part.name for part in PARTS], None, UNDO_FORMAT)
    if path:
        for backup in backups(profile_folder()):
            if backup.undo and backup.path != path:
                delete_backup(backup)
    return path


def _write_backup(parts: Collection[str], folder: str | None, name_format: str = BACKUP_FORMAT) -> str:
    """Write a backup of the parts (the ones `always` too) in the folder (None: the profile). Return its path, '' on failure (logged)."""
    from .config import config
    from .control import addonInfo
    from .settings import settings
    from .source_filters import filters_data
    chosen = [part for part in PARTS if part.always or part.name in parts]
    names = {part.name for part in chosen}
    target = profile_folder() if folder is None else folder
    tmp = Path(profile_folder()) / f'.backup-new-{os.getpid()}.zip'
    try:
        with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zf:
            if settings.path.exists():
                data = settings.path.read_bytes()
                zf.writestr(SETTINGS_FILE, data if 'access' in names else _settings_with_access(data, None))
            conf = config.data()
            zf.writestr(CONFIG_FILE, json.dumps(conf if 'access' in names else with_access(conf, {}), indent=2, ensure_ascii=False))
            if 'filters' in names:
                zf.writestr(FILTERS_FILE, json.dumps(filters_data(), indent=2, ensure_ascii=False))
            for part in chosen:
                if part.database is not None:
                    db = part.database()
                    snapshot = tmp.with_name(f'.backup-{db.name}-{os.getpid()}.db')
                    try:
                        with db.cursor() as cur, closing(sqlite3.connect(str(snapshot))) as out:
                            cur.connection.backup(out)
                        zf.write(snapshot, f'{db.name}.db')
                    finally:
                        snapshot.unlink(missing_ok=True)
            manifest = {'parts': sorted(names), 'versions': _versions(), 'addon': addonInfo('version'), 'created': datetime.now().isoformat(timespec='seconds')}
            zf.writestr(MANIFEST, json.dumps(manifest, indent=2))
        path = _join(target, _free_name(target, name_format))
        if (local := _local(path)) is not None:
            local.parent.mkdir(parents=True, exist_ok=True)
            os.replace(tmp, local)
        elif not xbmcvfs.copy(str(tmp), path):
            raise OSError(f'can not write {path}')
    except Exception:
        fflog_exc(f'[BACKUP] can not make a backup in {target}')
        return ''
    finally:
        tmp.unlink(missing_ok=True)
    fflog(f'[BACKUP] {path}: {", ".join(sorted(names))}')
    return path


def vacuum(*, keep: int | None = None) -> None:
    """Remove the old backups of the profile, keep the newest `keep` (None: `const.tune.settings.vacuum_files`; the undo one apart)."""
    keep = const.tune.settings.vacuum_files if keep is None else keep
    for backup in [backup for backup in backups(profile_folder()) if not backup.legacy and not backup.undo][keep:]:
        delete_backup(backup)


def delete_backup(backup: Backup) -> bool:
    """Remove the backup file (any Kodi folder). Return False on a failure (logged)."""
    try:
        if (local := _local(backup.path)) is not None:
            local.unlink(missing_ok=True)
        elif not xbmcvfs.delete(backup.path):
            raise OSError('xbmcvfs.delete failed')
    except OSError as exc:
        fflog(f'[BACKUP] can not remove the backup {backup.path}: {exc}')
        return False
    fflog(f'[BACKUP] {backup.path} removed')
    return True


# --- Restore ---


def _manifest(zf: zipfile.ZipFile) -> dict[str, Any]:
    """Return the manifest of a backup ({} if none or broken)."""
    try:
        data = json.loads(zf.read(MANIFEST))
    except (KeyError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def part_reasons(manifest: Mapping[str, Any]) -> dict[str, str]:
    """Return the parts of a backup which can not be restored with the reason (not in the backup, of a newer FanFilm), by the manifest."""
    parts = manifest.get('parts') or ()
    versions = manifest.get('versions') or {}
    current = _versions()
    newer = L(30996, 'Made by a newer FanFilm')
    if not isinstance(versions, Mapping) or int(versions.get('backup') or 0) > BACKUP_VERSION:
        return {part.name: newer for part in PARTS}
    reasons: dict[str, str] = {}
    for part in PARTS:
        version_key = part.data or part.name
        if part.name not in parts:
            reasons[part.name] = L(30997, 'Not in this backup')
        elif int(versions.get(version_key) or 0) > current.get(version_key, 0):
            reasons[part.name] = newer
    return reasons


def backup_parts(backup: Backup) -> dict[str, str]:
    """Return the parts of a backup which can not be restored with the reason (`part_reasons()`); an old backup has the settings only."""
    if backup.legacy:
        return {part.name: L(30997, 'Not in this backup') for part in PARTS if part.name not in ('config', 'access')}
    try:
        with _local_copy(backup.path) as local, zipfile.ZipFile(local) as zf:
            return part_reasons(_manifest(zf))
    except (OSError, zipfile.BadZipFile):
        fflog_exc(f'[BACKUP] can not read {backup.path}')
        return {part.name: L(30998, 'Can not read the backup') for part in PARTS}


def _restore_settings(data: bytes, *, access: bool) -> bool:
    """Write the Kodi settings of a backup (the current access data kept unless `access`)."""
    from .settings import settings
    if not access:
        data = _settings_with_access(data, settings.path.read_bytes() if settings.path.exists() else None)
    return settings._override_setting(data=data)


def _restore_json(data: Any, *, path: Path, migrate: Callable[[dict[str, Any]], bool], access_of: Mapping[str, Any] | None = None) -> bool:
    """Write a JSON file of a backup: its data migrated (as by its store), with the access data of `access_of` if given."""
    from .config import write_json_atomic
    if not isinstance(data, dict):
        return False
    migrate(data)
    if access_of is not None:
        data = with_access(data, access_of)
    return write_json_atomic(path, data) is not None


def table_columns(cur: DbCursor, table: str) -> list[str]:
    """Return the column names of the table (its rows are mappings: the cursors of `OrmDatabase`)."""
    return [row['name'] for row in cur.execute(f'PRAGMA table_info("{table}")').fetchall()]


def quoted(columns: list[str]) -> str:
    """Return the column names quoted for SQL, separated by commas."""
    return ', '.join(f'"{col}"' for col in columns)


def _restore_db(zf: zipfile.ZipFile, db: OrmDatabase) -> None:
    """
    Put the rows of a database of a backup into the open database: the copy is opened as a database of its own (migrated to
    the current version), the tables replaced in one transaction (the columns of both).
    """
    from .db.db import db_manager
    from .db.orm import OrmDatabase
    name = f'{db.name}-restore'
    db_manager.remove_db(name)  # a copy left by a broken restore
    db_manager.path_for_db(name).write_bytes(zf.read(f'{db.name}.db'))
    try:
        copy = OrmDatabase(name, *db.classes, version=db.version, on_update=db.on_update)
        tables = [cls.__tablename__ for cls in db.classes]
        with db.cursor() as cur:
            columns = {table: table_columns(cur, table) for table in tables}
        rows: dict[str, list[dict[str, Any]]] = {}
        with copy.cursor() as cur:
            for table in tables:
                old = set(table_columns(cur, table))
                columns[table] = [col for col in columns[table] if col in old]
                rows[table] = cur.execute(f'SELECT {quoted(columns[table])} FROM "{table}"').fetchall()
        with db.cursor(write=True) as cur:
            for table in reversed(tables):
                cur.execute(f'DELETE FROM "{table}"')
            for table in tables:
                if rows[table]:
                    marks = ', '.join(f':{col}' for col in columns[table])
                    cur.executemany(f'INSERT INTO "{table}" ({quoted(columns[table])}) VALUES ({marks})', rows[table])
    finally:
        db_manager.remove_db(name)


def restore_backup(backup: Backup, parts: Collection[str]) -> bool:
    """
    Restore the chosen parts of the backup (the ones `always` too; those it can not restore skipped). Return False on a failure (logged).
    The undo backup of the current data is made first (none restoring the undo backup itself: it would be replaced), no restore without it.
    """
    from .config import config, migrate as config_migrate
    from .source_filters import filters_store, migrate as filters_migrate
    if not backup.undo and not make_undo():
        fflog(f'[BACKUP] {backup.path} not restored: no undo backup')
        return False
    if backup.legacy:
        with _local_copy(backup.path) as local:
            return _restore_settings(local.read_bytes(), access='access' in parts)
    try:
        with _local_copy(backup.path) as local, zipfile.ZipFile(local) as zf:
            reasons = part_reasons(_manifest(zf))
            if 'config' in reasons:
                fflog(f'[BACKUP] {backup.path} not restored: {reasons["config"]}')
                return False
            chosen = {part.name for part in PARTS if (part.always or part.name in parts) and part.name not in reasons}
            access = 'access' in chosen
            files = set(zf.namelist())
            ok = True
            if SETTINGS_FILE in files:
                ok = _restore_settings(zf.read(SETTINGS_FILE), access=access) and ok
            ok = _restore_json(json.loads(zf.read(CONFIG_FILE)), path=config.path(), migrate=config_migrate,
                               access_of=None if access else config.data()) and ok
            if 'filters' in chosen:
                ok = _restore_json(json.loads(zf.read(FILTERS_FILE)), path=filters_store.path(), migrate=filters_migrate) and ok
            for part in PARTS:
                if part.database is not None and part.name in chosen:
                    _restore_db(zf, part.database())
    except Exception:
        fflog_exc(f'[BACKUP] can not restore {backup.path}')
        return False
    fflog(f'[BACKUP] {backup.path} restored: {", ".join(sorted(chosen))}')
    return ok
