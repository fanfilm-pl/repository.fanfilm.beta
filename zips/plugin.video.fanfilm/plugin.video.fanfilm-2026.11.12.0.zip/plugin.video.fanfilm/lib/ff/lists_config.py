"""
The user settings of the menus of lists (`config.json`, `/lists`): where the general lists of the service types are shown,
when a level of a menu is a folder, who gives the data of the fixed entries (`/movie`, `/show`). The defaults are declared
here (and by the general lists themselves, `GeneralList.places`), only the changes are stored (a value set back to its
default is removed), so a changed default reaches everyone who did not change it.

The general lists are of a service type (`const.indexer.<type>.enabled` and the application client of the type cut them
completely, `general_available()`); the user switches a type (`active`), a list everywhere, a place (a menu, a column
of the window) and a list in a place. A switched off type, list or place keeps the switches below it.
"""

from __future__ import annotations
from typing import Callable, Iterable
from typing_extensions import Literal, TypeAlias
from attrs import frozen
from cdefs import When
from .config import config, escape_key
from ..kolang import L

#: The settings of the lists in `config.json`.
LISTS_CONFIG: str = '/lists'
#: The switches of the general lists of the service types (`/lists/services/<type>`).
SERVICES_CONFIG: str = f'{LISTS_CONFIG}/services'
#: The switches of the places of the general lists (`/lists/places/<place>`).
PLACES_CONFIG: str = f'{LISTS_CONFIG}/places'
#: The folder points (`/lists/folders/<key>`).
FOLDERS_CONFIG: str = f'{LISTS_CONFIG}/folders'
#: The data providers of the fixed entries (`/lists/feeds/<key>`).
FEEDS_CONFIG: str = f'{LISTS_CONFIG}/feeds'
#: The VOD services of the user.
SUBSCRIPTIONS_CONFIG: str = f'{LISTS_CONFIG}/subscriptions'

#: A menu a general list can be shown in (`lib.indexers.lists.menu.MENUS`, `ListMenuId`).
Place: TypeAlias = Literal['lists', 'movies', 'shows', 'persons', 'history']


# --- general lists ---

def _service(type_name: str) -> str:
    """Return the pointer of the settings of the general lists of the service type."""
    return f'{SERVICES_CONFIG}/{escape_key(type_name)}'


def service_active(type_name: str) -> bool:
    """Return True if the general lists of the service type are switched on by the user (default: on)."""
    return config.get_bool(f'{_service(type_name)}/active', True)


def set_service_active(type_name: str, active: bool) -> bool:
    """Switch the general lists of the service type (the switches of its lists are kept)."""
    return config.set(f'{_service(type_name)}/active', active, default=True)


def list_active(type_name: str, key: str) -> bool:
    """Return True if the general list (`GeneralList.key`) of the type is switched on everywhere (default: on)."""
    return config.get_bool(f'{_service(type_name)}/{escape_key(key)}/active', True)


def set_list_active(type_name: str, key: str, active: bool) -> bool:
    """Switch the general list of the type everywhere (its places are kept)."""
    return config.set(f'{_service(type_name)}/{escape_key(key)}/active', active, default=True)


def place_active(place: Place) -> bool:
    """Return True if the general lists are switched on in the place (a menu; default: on)."""
    return config.get_bool(f'{PLACES_CONFIG}/{place}/active', True)


def set_place_active(place: Place, active: bool) -> bool:
    """Switch all the general lists in the place (the switches of the lists there are kept)."""
    return config.set(f'{PLACES_CONFIG}/{place}/active', active, default=True)


def list_place(type_name: str, key: str, place: Place, default: bool) -> bool:
    """Return the own switch of the general list of the type in the place (without the switches above it)."""
    return config.get_bool(f'{_service(type_name)}/{escape_key(key)}/places/{place}', default)


def set_list_place(type_name: str, key: str, place: Place, value: bool, default: bool) -> bool:
    """Set the own switch of the general list of the type in the place."""
    return config.set(f'{_service(type_name)}/{escape_key(key)}/places/{place}', value, default=default)


def general_switched(type_name: str, key: str, place: Place, default: bool) -> bool:
    """Return True if the user switches of the type, the general list, the place and the list in the place are on."""
    return service_active(type_name) and list_active(type_name, key) and place_active(place) and list_place(type_name, key, place, default)


def general_shown(type_name: str, key: str, place: Place, default: bool) -> bool:
    """
    Return True if the general list of the type is shown in the place: the type has its general lists available
    (`general_available()`: `const`, the application client) and the user switches are on (`general_switched()`).
    """
    from .accounts import general_available
    return general_switched(type_name, key, place, default) and general_available(type_name)


# --- folders of the menus ---

#: A text of the window, in the language of the call (`L()` runs then).
Text: TypeAlias = Callable[[], str]


@frozen
class FolderPoint:
    """A level of a menu that can be a folder (`When`), with its default."""

    #: The key (`config.json` `/lists/folders/<key>`).
    key: str
    #: The group of the window (the menu, `FOLDER_GROUPS`).
    group: str
    #: The label.
    label: Text
    #: The default.
    default: When


#: The groups of the folder points (the menus) in the order of the window.
FOLDER_GROUPS: dict[str, Text] = {
    'main': lambda: L(32950, 'Main menu'),
    'lists': lambda: L(32951, 'Lists in the main menu'),
    'my': lambda: L(32952, 'My movies / My TV shows'),
    'history': lambda: L(32036, 'History'),
    'own': lambda: L(32953, 'FanFilm lists'),
    'persons': lambda: L(32954, 'My persons'),
}

#: The folder points in the order of the window.
FOLDER_POINTS: tuple[FolderPoint, ...] = (
    FolderPoint('main.lists', 'main', lambda: L(32951, 'Lists in the main menu'), When.NEVER),
    FolderPoint('lists.type', 'lists', lambda: L(32955, 'Services'), When.ALWAYS),
    FolderPoint('lists.account', 'lists', lambda: L(32956, 'Accounts of a service'), When.IF_MANY),
    FolderPoint('lists.kind', 'lists', lambda: L(32957, 'Kinds of lists'), When.NEVER),
    FolderPoint('lists.media', 'lists', lambda: L(32958, 'Media of a list (movies, TV shows)'), When.IF_MANY),
    FolderPoint('lists.mine', 'lists', lambda: L(32959, 'User lists of an account'), When.ALWAYS),
    FolderPoint('lists.general', 'lists', lambda: L(30628, 'General lists'), When.NEVER),
    FolderPoint('my.type', 'my', lambda: L(32955, 'Services'), When.IF_MANY),
    FolderPoint('my.account', 'my', lambda: L(32956, 'Accounts of a service'), When.IF_MANY),
    FolderPoint('my.kind', 'my', lambda: L(32957, 'Kinds of lists'), When.NEVER),
    FolderPoint('history.type', 'history', lambda: L(32955, 'Services'), When.NEVER),
    FolderPoint('history.account', 'history', lambda: L(32956, 'Accounts of a service'), When.IF_MANY),
    FolderPoint('history.kind', 'history', lambda: L(32957, 'Kinds of lists'), When.NEVER),
    FolderPoint('own.mine', 'own', lambda: L(32953, 'FanFilm lists'), When.NEVER),
    FolderPoint('own.sublists', 'own', lambda: L(32960, 'Lists in a list'), When.NEVER),
    FolderPoint('own.list_name', 'own', lambda: L(32961, 'The list name of an item'), When.IF_MANY),
    FolderPoint('persons.my', 'persons', lambda: L(32954, 'My persons'), When.NEVER),
)

#: The folder points by the key.
_FOLDER_POINTS: dict[str, FolderPoint] = {point.key: point for point in FOLDER_POINTS}


def folder_when(key: str, *, base: str | None = None) -> When:
    """
    Return when the level of the point is a folder (the user setting, else the default; KeyError: no such point).
    `base` - the point of a key that is not declared (e.g. `trakt.mine` -> `lists.mine`, `own.mine` has its own).
    """
    if base is not None and key not in _FOLDER_POINTS:
        key = base
    default = _FOLDER_POINTS[key].default
    try:
        return When(config.get(f'{FOLDERS_CONFIG}/{key}', default.value))
    except ValueError:
        return default


def set_folder(key: str, value: When) -> bool:
    """Set the folder point."""
    return config.set(f'{FOLDERS_CONFIG}/{key}', value.value, default=_FOLDER_POINTS[key].default.value)


# --- data providers of the fixed entries ---

@frozen
class Feed:
    """A fixed entry of a menu (`/movie`, `/show`) whose data can come from more service types."""

    #: The key (`config.json` `/lists/feeds/<key>`).
    key: str
    #: The label.
    label: Text
    #: The service types that can give the data (`MainIndexer.trending()`), the base (always available) last.
    services: tuple[str, ...]
    #: The default service type.
    default: str


#: The fixed entries with more possible data providers, in the order of the window.
FEEDS: tuple[Feed, ...] = (
    Feed('movies.trending', lambda: f"{L(32001, 'Movies')}: {L(32017, 'People Watching')}", ('trakt', 'wetrakr', 'tmdb'), 'trakt'),
    Feed('shows.trending', lambda: f"{L(32002, 'TV Shows')}: {L(32017, 'People Watching')}", ('trakt', 'wetrakr', 'tmdb'), 'trakt'),
)

#: The fixed entries by the key.
_FEEDS: dict[str, Feed] = {fd.key: fd for fd in FEEDS}


def feed(key: str) -> str:
    """Return the chosen data provider of the fixed entry (the user setting if it can give the data, else the default)."""
    fd = _FEEDS[key]
    value = config.get(f'{FEEDS_CONFIG}/{key}')
    return value if value in fd.services else fd.default


def feed_service(key: str, available: Callable[[str], bool]) -> str | None:
    """Return the data provider of the fixed entry: the chosen one if `available`, else the base (the last), None if none."""
    fd = _FEEDS[key]
    return next((srv for srv in (feed(key), fd.services[-1]) if available(srv)), None)


def set_feed(key: str, service: str) -> bool:
    """Set the data provider of the fixed entry."""
    fd = _FEEDS[key]
    if service not in fd.services:
        raise ValueError(f'{service!r} can not give {key!r}')
    return config.set(f'{FEEDS_CONFIG}/{key}', service, default=fd.default)


#: The VOD services (JustWatch short names) of the user by default: new VOD titles of them only.
DEFAULT_SUBSCRIPTIONS: frozenset[str] = frozenset(('nfx', 'mxx', 'prv', 'dnp', 'cda', 'plp', 'pbg', 'sst', 'vtp', 'cpr'))


def subscriptions() -> frozenset[str]:
    """Return the VOD services (JustWatch short names) the user has, new VOD titles are of them only."""
    value = config.get(SUBSCRIPTIONS_CONFIG)
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return frozenset(value)
    return DEFAULT_SUBSCRIPTIONS


def set_subscriptions(services: Iterable[str]) -> bool:
    """Set the VOD services of the user."""
    value = sorted(set(services))
    return config.set(SUBSCRIPTIONS_CONFIG, value, default=sorted(DEFAULT_SUBSCRIPTIONS))
