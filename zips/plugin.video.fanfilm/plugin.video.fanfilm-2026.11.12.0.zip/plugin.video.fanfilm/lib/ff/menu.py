"""Menu and Kodi list directory support."""

from typing import Optional, Any, Union, Tuple, List, Dict, Set, Sequence, Iterable, Iterator, Callable, ClassVar
from typing_extensions import Literal, Self, TypedDict, Unpack, NotRequired, TypeAlias
from contextlib import contextmanager
from itertools import chain
from pathlib import PurePosixPath
import os
import re
from attrs import define, field, Factory

from xbmc import getSkinDir

from .logs import fflog, fflog_exc
from .routing import URL, url_for, url_proxy, subobject, route, RouteObject, EndpointInfo, main_router, unwrap
from .item import FFItem, FMode, SortPosition, ArtLabel
from .kotools import xsleep
from .tricks import pairprev
from .theme import art
from .db.state import save_directory
from .info import ffinfo
from .views import view_manager
from . import control
from .types import PagedItems
from ..service.client import service_client
from ..service.misc import PluginRequestInfo
from ..kolang import L
from .control import addonFanart, update as folder_update, plugin_url, plugin_id
from .settings import settings
from .menu_entries import MENU_ENTRY, entry_shown, menu_order
from const import const, CONST_REF, MediaWatchedMode
from cdefs import ListTarget, When, const_value


Target: TypeAlias = Union[str, URL, Callable[..., None], RouteObject, subobject, EndpointInfo, None]
ContextMenuItem: TypeAlias = Tuple[str, Target]
ContextMenu: TypeAlias = Iterable[ContextMenuItem]

#: Folder content view type.
ContentView: TypeAlias = Literal[
    # - from xbmcplugin.setContent():
    #   albums, artists, episodes, files, games, images, movies, musicvideos, songs, tvshows, videos,
    'albums', 'artists', 'episodes', 'files', 'games', 'images', 'movies', 'musicvideos', 'songs', 'tvshows', 'videos',
    # - from Container.Content():
    #   actors, albums, artists, directors, episodes, files, genres, movies, musicvideos, playlists, plugins,
    #   seasons, sets, songs, studios, tags, tvshows, years,
    'actors', 'directors', 'genres', 'playlists', 'plugins', 'seasons', 'sets', 'studios', 'tags', 'years',
    # - extra well known types:
    'addons',
    # - strange types (not supported): unknown, events, mixed
]

Sort = Literal['label', 'title', 'year']



@route
def _no_operation() -> None:
    """No operation (separator)."""


class MenuCondition:
    def __call__(self) -> bool:
        return True


@define
class IfSetting(MenuCondition):
    #: Settings name
    name: str

    def __call__(self) -> bool:
        return settings.getBool(self.name)


@define
# class IfHasLibrary(MenuCondition):
class if_has_library(MenuCondition):
    #: Settings name
    val: int

    def __call__(self) -> bool:
        return self.val >= 5


class CMenu(ContextMenuItem):
    """Single context-menu item with some extra stuff."""

    _visible: Union[bool, str, MenuCondition]
    _order: int

    def __new__(cls, label: str, target: Target, *, visible: Union[bool, str, MenuCondition] = True, order: int = 0) -> Self:
        obj = super().__new__(cls, (label, target))
        obj._visible = visible
        obj._order = order
        return obj

    @property
    def visible(self) -> bool:
        """Check if item is visible in context menu."""
        if self._visible is True:
            return True
        if not self._visible:  # False, None, ''
            return False
        if isinstance(self._visible, str):
            return settings.eval(self._visible)
        return self._visible()

    @property
    def order(self) -> int:
        """Order of item in context menu."""
        return self._order


class AutoContextMenu:
    """Generator (creator) for context menu items."""

    def generate(self,
                 item: FFItem,
                 *,
                 target: Optional[Target] = None,
                 menu: Sequence[ContextMenuItem] = (),
                 kdir: 'Optional[KodiDirectory]' = None,
                 ) -> Iterator[ContextMenuItem]:
        if False:
            yield


ItemsSectionItems: TypeAlias = Sequence[Union[FFItem, ContextMenuItem]]
ItemsSectionInput: TypeAlias = Union[ItemsSectionItems, Callable[['KodiDirectory'], Optional[ItemsSectionItems]]]


def _items_section_converter_items(items: ItemsSectionInput,
                                   ) -> 'Union[List[Union[FFItem, ContextMenuItem]], Callable[[KodiDirectory], ItemsSectionItems | None]]':
    if callable(items):
        return items
    return list(items)


@define
class ItemsSection:
    items: 'Union[List[Union[FFItem, ContextMenuItem]], Callable[[KodiDirectory], Optional[ItemsSectionItems]]]' = field(converter=_items_section_converter_items)
    label: Optional[str] = field(kw_only=True, default=None)
    style: Optional[str] = field(kw_only=True, default=None)
    separator: Optional[bool] = field(kw_only=True, default=None)
    position: Optional[SortPosition] = field(kw_only=True, default=None)


@define(kw_only=True)
class DirectoryCatch:
    kdir: 'KodiDirectory | None' = None

    @property
    def items(self) -> Sequence[FFItem]:
        return self.kdir._items if self.kdir else ()


@define
class DirectoryState:
    """The folder state of one plugin call (see KodiDirectory.state())."""

    #: Current folder URL.
    url: Optional[URL] = None
    #: Current folder info (url, refreshing, history...).
    info: PluginRequestInfo = Factory(PluginRequestInfo)
    #: True if folder is refreshed (the same URL is used).
    refresh_done: bool = False
    #: True if folder is created (KodiDirectory is used).
    created: bool = False
    #: Index of focused item.
    focus_index: int = -1
    #: Last folder contnet (KodiDirectory is used).
    content: Sequence[FFItem] = ()
    #: Catch directory items instance for show error folder on exception in with statement. Used in catch() method.
    catch: Optional[DirectoryCatch] = None


class KodiDirectoryKwArgs(TypedDict):
    """Arguments for KodiDirectory() for better typing."""
    # Content view type.
    view: NotRequired[Optional[ContentView]]
    #: Update the listing (updateListing=True).
    update: NotRequired[bool]
    #: Art: thumb.
    thumb: NotRequired[Optional[str]]
    #: Art: icon.
    icon: NotRequired[Optional[str]]
    #: Art: poster.
    poster: NotRequired[Optional[str]]
    #: Art: landscape.
    landscape: NotRequired[Optional[str]]
    #: Art: banner.
    banner: NotRequired[Optional[str]]
    #: Art: fanart.
    fanart: NotRequired[Optional[str]]
    #: Auto-format (ex. unaired).
    autoformat: NotRequired[bool]
    #: Style format.
    style: NotRequired[Optional[str]]
    #: Context menu (append on top).
    menu_top: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    #: Context menu (append on bottom).
    menu_bottom: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    #: Auto context menu creators.
    auto_menu: NotRequired[Optional[Iterable[AutoContextMenu]]]
    #: Auto ceate "no content do display" if directory is empty. True or message to show.
    no_content_message: NotRequired[Union[str, bool, None]]
    #: Plugin category, to show as super-title.
    category: NotRequired[Union[str, int, None]]
    #: User list target (add to, remove from...).
    list_target: NotRequired[Optional[ListTarget]]
    #: Top items section.
    top: NotRequired[Union[ItemsSection, ItemsSectionInput, None]]
    #: Bottom items section.
    bottom: NotRequired[Union[ItemsSection, ItemsSectionInput, None]]
    #: Force next page as redirect page or disable at all if False.
    next_page: NotRequired[Union[Target, Literal[False]]]
    #: Force previous page as redirect page or disable at all if False.
    previous_page: NotRequired[Union[Target, Literal[False]]]


class KodiDirectoryAddArgs(TypedDict):
    """Arguments for KodiDirectory() create items functions."""
    thumb: NotRequired[Optional[str]]
    icon: NotRequired[Optional[str]]
    poster: NotRequired[Optional[str]]
    landscape: NotRequired[Optional[str]]
    banner: NotRequired[Optional[str]]
    fanart: NotRequired[Optional[str]]
    style: NotRequired[Optional[str]]
    descr: NotRequired[str]
    position: NotRequired[SortPosition]
    menu_top: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    menu: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    menu_bottom: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    role: NotRequired[Optional[str]]
    auto_menu: NotRequired[Union[bool, Iterable[AutoContextMenu]]]


class KodiDirectory:
    """Kodi list directory used in with statement."""

    #: Format for future item (unaired, non-premiered).
    FUTURE_FORMAT: ClassVar[Optional[str]] = CONST_REF.folder.style.future
    #: Format for item with role.
    ROLE_FORMAT: ClassVar[Optional[str]] = CONST_REF.folder.style.role
    #: Style of the list entry data (added, rank, note) at the top of the description.
    LIST_ENTRY_FORMAT: ClassVar[Optional[str]] = CONST_REF.folder.style.list_entry
    #: Format for broken items (eg. not found in TMDB). Eg. '{} [COLOR red]![/COLOR]'
    BROKEN_FORMAT: ClassVar[Optional[str]] = CONST_REF.folder.style.broken

    NEXT_PAGE_LABEL = L(32053, '[I]Next page[/I]')
    PREV_PAGE_LABEL = L(30239, '[I]Previous page[/I]')
    #: Names to exclude from folder path.
    FOLDER_PATH_EXCLUDE_NAMES = {NEXT_PAGE_LABEL, PREV_PAGE_LABEL}

    _DEBUG_PRINT_LIST: ClassVar[bool] = False

    _rx_menu_target = re.compile(r'[^(]*://')

    def __init__(self,
                 *,
                 view: Optional[ContentView] = 'addons',
                 # prefix: str = '',
                 update: bool = False,
                 thumb: Optional[str] = None,
                 icon: Optional[str] = None,
                 poster: Optional[str] = None,
                 landscape: Optional[str] = None,
                 banner: Optional[str] = None,
                 fanart: Optional[str] = None,
                 autoformat: bool = True,
                 style: Optional[str] = None,
                 menu_top: Optional[Iterable[ContextMenuItem]] = None,
                 menu_bottom: Optional[Iterable[ContextMenuItem]] = None,
                 auto_menu: Optional[Iterable[AutoContextMenu]] = None,
                 no_content_message: Union[str, bool, None] = None,
                 category: Union[str, int, None] = None,
                 list_target: Optional[ListTarget] = None,
                 top: Union[ItemsSection, ItemsSectionInput, None] = None,
                 bottom: Union[ItemsSection, ItemsSectionInput, None] = None,
                 next_page: Union[Target, Literal[False]] = None,      # ignored, used in directory()
                 previous_page: Union[Target, Literal[False]] = None,  # ignored, used in directory()
                 ) -> None:
        #: Directory view type.
        self.view: Optional[ContentView] = view
        ##: URL prefix for all added actions.
        #self.prefix: str = prefix
        #: Update the listing (updateListing=True).
        self.update: bool = update
        #: Plugin handle.
        self.handle: int = control.current_call().handle
        #: Main section (folder items).
        self._main_section = ItemsSection([])
        #: Added items.
        self._items: List[FFItem] = []
        #: Auto-format (ex. unaired).
        self.autoformat = bool(autoformat)
        #: Style format.
        self.style: Optional[str] = style
        #: Context menu (append on top).
        self.menu_top: List[ContextMenuItem] = list(menu_top or ())
        #: Context menu (append on bottom).
        self.menu_bottom: List[ContextMenuItem] = list(menu_bottom or ())
        #: Focused item.
        self._focused_item: Optional[FFItem] = None
        #: Menu of last item.
        self._last_item_menu: Optional[ContextMenu] = None
        #: Set of handled items to avoid format duplications, key: id(FFItem).
        self._handled_items: Set[int] = set()
        #: The keys of the fixed entries of the menu (`entry()`), key: id(FFItem) of its item(s).
        self._entry_keys: Dict[int, str] = {}
        #: Auto context menu creators.
        self.auto_menu: Iterable[AutoContextMenu] = () if auto_menu is None else tuple(auto_menu)
        #: Auto ceate "no content do display" if directory is empty. True or message to show.
        if no_content_message is None:
            no_content_message = const.indexer.empty_folder_message
        self.no_content_message: str = L(32834, 'No content to display') if no_content_message is True else no_content_message or ''
        #: Plugin category, to show as super-title.
        self.category: Union[str, int, None] = category
        #: User list target (add to, remove from...).
        self.list_target: Optional[ListTarget] = list_target
        # --- default settings ---
        if fanart is None:
            fanart = addonFanart()
        #: Art images.
        self.images: Dict[str, Optional[str]] = {
            'thumb': thumb,
            'icon': icon,
            'poster': poster,
            'landscape': landscape,
            'banner': banner,
            'fanart': fanart,
        }
        #: Items sections (without top and bottom).
        self.sections: List[ItemsSection] = []
        #: Stack of sections for with context.
        self._section_stack: List[ItemsSection] = []
        #: Top items section.
        self.top: 'ItemsSection | None' = top if top is None or isinstance(top, ItemsSection) else ItemsSection(top)
        #: Bottom items section.
        self.bottom: 'ItemsSection | None' = bottom if bottom is None or isinstance(bottom, ItemsSection) else ItemsSection(bottom)
        # tune...
        if self.top:
            if self.top.style is None:
                self.top.style = const.folder.style.top
            self.top.position = 'top'
        if self.bottom:
            if self.bottom.style is None:
                self.bottom.style = const.folder.style.bottom
            self.bottom.position = 'bottom'

    @staticmethod
    def state() -> DirectoryState:
        """Return the folder state of the current plugin call."""
        call = control.current_call()
        if call.directory is None:
            call.directory = DirectoryState()
        return call.directory

    @classmethod
    def ready_for_data(cls) -> bool:
        """
        Checks service if everyfing is ready.

        Only trakt sync on refreshing is supported now.
        """
        state = cls.state()
        if state.catch is not None:
            return True
        if state.refresh_done:
            return True
        fflog(f'[MENU] ready? {state.info.refresh=}, {state.info.locked=}')
        if state.info.locked:
            ok = service_client.folder_ready()
            fflog(f'[MENU] folder ready: {ok=}')
        state.refresh_done = True
        # if state.info.refresh and const.folder.refresh_delay:
        #     fflog('sleep before refresh')
        #     xsleep(const.folder.refresh_delay)
        # if state.info.refresh and not state.refresh_done:
        #     fflog('wait for refresh')
        #     ok = service_client.foler_ready()
        #     fflog(f'folder ready: {ok=}')
        #     state.refresh_done = True
        return True

    @classmethod
    def set_current_info(cls, url: Union[URL, str], info: 'PluginRequestInfo') -> None:
        control.current_call().directory = DirectoryState(url=URL(url), info=info)

    def close(self) -> None:
        """Close the directory (endDirectory)."""
        if control.current_call().is_set():
            return  # aborted: Kodi gets no folder, so no Kodi data, no state of the folder, no folder in the DB
        self._order_entries()
        sections = sorted((self.top, *self.sections, self.bottom),
                          key=lambda sect: -1 if (pos := sect and sect.position) == 'top' else 1 if pos == 'bottom' else 0)
        for previous_section, section in pairprev(sections):
            self._resolve_section(section, previous_section=previous_section)
        state = self.state()
        if state.catch is not None:
            state.catch.kdir = self
            return
        if self.no_content_message and not self._items:
            self.no_content(empty_message=self.no_content_message)
        if self.view:
            control.content(self.handle, self.view)
        category = self.category
        if category is None:
            skin_id = getSkinDir()
            category = const.folder.category_by_skin.get(skin_id, const.folder.category)
        if category and isinstance(category, int):
            parent_path = [p for p in state.info.parent_path if p.label not in KodiDirectory.FOLDER_PATH_EXCLUDE_NAMES]
            if parent_path:
                category = ' / '.join(parent.label for parent in parent_path[-category:])
            else:
                category = False
        if isinstance(category, str):
            control.category(self.handle, category)  # visible as Container.PluginCategory in a skin
        if self._items:
            if self._DEBUG_PRINT_LIST:
                print('\n'.join(f'  {it.url:50s} {it}' for it in self._items))
            for item in self._items:
                item.remove_non_bmp()  # emoji: Kodi cuts characters to 16 bits
            items = [(item.url or '', item, item.isFolder()) for item in self._items]
            if self._focused_item:
                try:
                    state.focus_index = self._items.index(self._focused_item) + 1  # +1 for ".."
                except ValueError:
                    state.focus_index = -1
            try:
                ffinfo.update_item_kodi_data(self._items)  # playback info, stream details (Kodi race workaround)
            except Exception:
                fflog_exc()  # e.g. an error of the Kodi DB (MySQL): the list is shown without the Kodi data
            control.addItems(self.handle, items, len(self._items))
        control.end_of_directory(self.handle, updateListing=self.update, cacheToDisc=const.folder.cache_to_disc)
        if 1:  # XXX
            from ..info import exec_id
            fflog(f'[MENU] endOfDirectory [{exec_id()}]: {self.handle=}, {self.update=}, {self._focused_item=}')
        view_manager.set_custom_view(self.view)
        state.content = tuple(self._items)
        state.created = True
        # save folder to DB
        if const.folder.db_save:
            save_directory(str(state.info.url), self._items)

    @property
    def items(self) -> List[FFItem]:
        """Return main section items."""
        assert self._main_section is not None
        assert isinstance(self._main_section.items, list)
        assert all(isinstance(it, FFItem) for it in self._main_section.items)
        return self._main_section.items  # type: ignore[return-value]

    def _resolve_section(self, section: 'ItemsSection | None', *, previous_section: 'ItemsSection | None' = None) -> None:
        """Resolve section items if needed and add them."""
        if section is None:
            return
        kwargs: KodiDirectoryAddArgs = {}
        if section.position:
            kwargs['position'] = section.position
        items: Iterable[Union[FFItem, ContextMenuItem]] = []
        if (section.separator or (previous_section and previous_section.separator)) and self._items:
            ffitem = FFItem(const.folder.separator_label, mode=FMode.Separator)
            kwargs['style'] = const.folder.style.separator
            self._set_item(ffitem, target=_no_operation, **kwargs)
            self._items.append(ffitem)
        if section.label is not None:
            ffitem = FFItem(section.label, mode=FMode.Separator)
            kwargs['style'] = const.folder.style.section_label
            self._set_item(ffitem, target=_no_operation, **kwargs)
            self._items.append(ffitem)
        if callable(section.items):
            main_sect, self._main_section = self._main_section, ItemsSection([])
            try:
                sect_res = section.items(self)
            finally:
                items.extend(self.items)
                self._main_section = main_sect
            if sect_res is not None:
                items.extend(sect_res)
        else:
            items.extend(section.items)
        # if section.separator:
        #     self.separator(section.label)
        kwargs['style'] = section.style
        for it in items:
            if isinstance(it, FFItem):
                ffitem, target = it, it.url
            elif isinstance(it, Sequence) and len(it) >= 2:
                label, target, *_ = it
                if isinstance(label, FFItem):
                    ffitem, target = label, label.url
                else:
                    ffitem = FFItem(label, mode=FMode.Folder)
                    self._set_item(ffitem, target=target, **kwargs)
            else:
                fflog.warning(f'Invalid section item: {it!r}')
                continue
            # self._set_item(ffitem, target=target, **kwargs)
            if section.position:
                ffitem.position = section.position
            self._items.append(ffitem)

    def add_section(self, section: 'ItemsSection | ItemsSectionInput') -> None:
        """Add items section."""
        if not isinstance(section, ItemsSection):
            section = ItemsSection(section)
        self.sections.append(section)

    @contextmanager
    def section(self,
                label: Optional[str] = None,
                *,
                style: Optional[str] = None,
                separator: Optional[bool] = None,
                position: Optional[SortPosition] = None,
                ) -> Iterator[ItemsSection]:
        """With context for items section."""
        section = ItemsSection([], label=label, style=style, separator=separator, position=position)
        self._main_section, main_section = section, self._main_section
        try:
            self._section_stack.append(section)
            yield section
            self.sections.append(section)
        finally:
            self._section_stack.pop()
            self._main_section = main_section

    def _make_url(self, target: Target) -> str:
        """Make URL string from URL or target method."""
        if target is not None:
            if isinstance(target, str):
                return target
            if isinstance(target, URL):
                if ',' in target.path:  # fix comma in url
                    target = target._replace(path=target.path.replace(',', '%2C'))
                return str(target)
            if isinstance(target, EndpointInfo):
                return str(target.url)
            # if isinstance(target, subobject) and self.prefix:
            #     target = url_for(self.prefix, target)
            target = url_for(target)
        if target is None:
            return self.no_op_url
        return str(target)

    def _menu_target(self, target: Target) -> str:
        url = self._make_url(target)
        if self._rx_menu_target.match(url):
            url = f'RunPlugin({url})'
        return url

    def _set_item(self,
                  ffitem: FFItem,
                  enable_art: bool = True,
                  enable_format: bool = True,
                  target: Optional[Target] = None,
                  **kwargs: Unpack[KodiDirectoryAddArgs],
                  ) -> None:
        """Fill item with extra arguments."""
        if target is None:
            target = ffitem.target
        if target is not None:
            ffitem.url = self._make_url(target)
        if enable_art:
            mn_art, it_art = {}, ffitem.getArt()
            if fallback := const.folder.fanart_fallback:
                if ffitem.ref.type == 'show' and 'tvshow.fanart' not in it_art:
                    for key in (f'tvshow.{fallback}', fallback):
                        if img := it_art.get(key):
                            it_art.setdefault('tvshow.fanart', img)
                            break
                if 'fanart' not in it_art:
                    for key in ('tvshow.fanart', f'tvshow.{fallback}', 'tvshow.landscape', fallback):
                        if img := it_art.get(key):
                            it_art.setdefault('fanart', img)
                            break
            for nm, img in self.images.items():
                if img := kwargs.get(nm, it_art.get(nm) or img):
                    if '://' not in img:
                        if os.path.exists(path := art(img)):
                            img = path
                    mn_art[nm] = img
            ffitem.setArt({**mn_art, **it_art})
        if role := kwargs.get('role'):
            ffitem.role = role
        if id(ffitem) not in self._handled_items:  # only first time
            entry = ffitem.list_entry
            if entry is not None and not ffitem.role:  # the added date of the list entry is the role, if it is free
                ffitem.role = entry.date_label()
            if enable_format and self.autoformat:
                if ffitem.unaired and (fmt := const_value(self.FUTURE_FORMAT)) and not ffitem.broken:  # a broken item has no date
                    ffitem.label = fmt.format(ffitem.label, item=ffitem)
                if ffitem.role and (fmt := const_value(self.ROLE_FORMAT)):
                    ffitem.label = fmt.format(ffitem.label, item=ffitem)
                if ffitem.broken and (fmt := const_value(self.BROKEN_FORMAT)):
                    ffitem.label = fmt.format(ffitem.label, item=ffitem)
            if style := kwargs.get('style', self.style):
                ffitem.label = style.format(ffitem.label, item=ffitem)
            if descr := kwargs.get('descr'):
                ffitem.vtag.setPlot(descr)
            if entry is not None and (entry_style := const_value(self.LIST_ENTRY_FORMAT)) and (info := entry.description()):
                ffitem.vtag.setPlot('\n'.join(text for text in (entry_style.format(info), ffitem.vtag.getPlot()) if text))
            if ffitem.descr_style:
                ffitem.vtag.setPlot(ffitem.descr_style.format(ffitem.vtag.getPlot(), item=ffitem))
        menu: Optional[ContextMenu] = kwargs.get('menu')
        menu = menu or ()
        if ffitem.cm_menu:
            menu = (*menu, *ffitem.cm_menu)
        top_menu = (*self.menu_top, *(kwargs.get('menu_top') or ()))
        if const.debug.crash_menu:
            from ..main import crash
            menu = (('CRASH', url_for(crash)), *menu)
        if const.debug.restart_menu:
            from ..main import restart
            menu = (('RESTART', url_for(restart)), *menu)
        # create context-menu
        auto_menu = kwargs.get('auto_menu', True)
        if auto_menu is False:
            pass
        else:
            if auto_menu is None or auto_menu is True:
                auto_menu = ()
            menu = tuple(menu)
            # list(self.auto_menu[0].generate(ffitem, target=target, menu=menu, kdir=self))
            menu = (*menu, *(new for am in chain(auto_menu, self.auto_menu)
                             for new in am.generate(ffitem, target=target, menu=menu, kdir=self)))
        bottom_menu = (*(kwargs.get('menu_bottom') or ()), *self.menu_bottom)
        menu = (*top_menu, *sorted(menu, key=lambda m: getattr(m, 'order', 0)), *bottom_menu)
        if menu:
            # filter out context-menu items with visible == False
            menu = tuple(m for m in menu if getattr(m, 'visible', True))
        if menu:
            self._last_item_menu = tuple(menu)
            ffitem.addContextMenuItems([(label, self._menu_target(target)) for label, target in menu])
        if const.core.media_watched_mode is MediaWatchedMode.FAKE_DBID and ffitem.ffid:
            ffitem.vtag.setDbId(ffitem.ffid)
        if ffitem.mode == FMode.Playable and ffitem.url and not ffitem.getPath():
            ffitem.setPath(ffitem.url)
        elif ffitem.mode in (FMode.Command, FMode.Separator):
            ffitem.setProperty('IsPlayable', 'false')  # no "Play from here" in the context menu
        if ffitem.ffid:
            ffitem.vtag.setUniqueID(str(ffitem.ffid), 'ffid')
        if (ref := ffitem.ref).ffid:
            ffitem.vtag.setUniqueID(f'{ref:a}', 'ffref')
        if pos := kwargs.get('position'):
            ffitem.position = pos
        self._handled_items.add(id(ffitem))

    def add(self, item: FFItem, *, url: Optional[Target] = None, **kwargs: Unpack[KodiDirectoryAddArgs]) -> None:
        """Add new item (folder / action)."""
        if not self._section_stack and self._main_section not in self.sections:
            self.sections.append(self._main_section)
        # if url is not None:
        #     item.url = self._make_url(url)
        self._set_item(item, target=url, **kwargs)
        self.items.append(item)

    def folder(self, label: str, target: Optional[Target], **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new folder menu."""
        item = FFItem(label, mode=FMode.Folder)
        self.add(item, url=target, **kwargs)
        return item

    def group(self, label: str, target: Optional[Target], *, when: When, add: Callable[['KodiDirectory'], None],
              **kwargs: Unpack[KodiDirectoryAddArgs]) -> None:
        """
        Add a group (`add` adds its items) by `when` and the number of its items: NEVER - the items in place (not counted),
        else a folder (`label`, `target`, `kwargs`) if `when(count)`, the items in place if not; nothing without items.
        """
        if when is When.NEVER:
            add(self)
            return
        group = KodiDirectory()
        add(group)
        if not group.items:
            return
        if when(len(group.items)):
            self.folder(label, target, **kwargs)
        else:
            self.items.extend(group.items)

    def entry(self, key: str, target: Optional[Target], *, when: Optional[When] = None, add: Optional[Callable[['KodiDirectory'], None]] = None,
              **kwargs: Unpack[KodiDirectoryAddArgs]) -> None:
        """
        Add a fixed entry of the menu (`lib.ff.menu_entries`, the label and the images of its declaration), nothing if the
        user hid it: a folder, or a group (`add`, `when`: see `group()`). The fixed entries go in the user order (`close()`).
        """
        if not entry_shown(key):
            return
        entry = MENU_ENTRY[key]
        images: KodiDirectoryAddArgs = {}
        if entry.thumb:
            images['thumb'] = entry.thumb
        if entry.icon:
            images['icon'] = entry.icon
        start = len(self.items)
        if add is None:
            self.folder(entry.label(), target, **{**images, **kwargs})
        else:
            self.group(entry.label(), target, when=When.ALWAYS if when is None else when, add=add, **{**images, **kwargs})
        for item in self.items[start:]:
            self._entry_keys[id(item)] = key

    def _order_entries(self) -> None:
        """Put the fixed entries (`entry()`, a group with its items) in the user order, in the places of the entries; other items stay."""
        if not self._entry_keys:
            return
        items = self.items
        blocks: List[List[FFItem]] = []  # the items of an entry together, another item alone
        for item in items:
            key = self._entry_keys.get(id(item))
            if key is not None and blocks and self._entry_keys.get(id(blocks[-1][0])) == key:
                blocks[-1].append(item)
            else:
                blocks.append([item])
        menus = {MENU_ENTRY[key].parent for key in self._entry_keys.values()}
        rank = {key: i for menu in menus for i, key in enumerate(menu_order(menu))}
        entries = iter(sorted((block for block in blocks if id(block[0]) in self._entry_keys), key=lambda block: rank[self._entry_keys[id(block[0])]]))
        items[:] = [item for block in blocks for item in (next(entries) if id(block[0]) in self._entry_keys else block)]

    def action(self, label: str, action: Target, **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new action menu."""
        item = FFItem(label, mode=FMode.Command, info_type=None)
        self.add(item, url=action, **kwargs)
        return item

    def play(self, label: str, target: Optional[Target], **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new folder menu."""
        item = FFItem(label, mode=FMode.Playable)
        self.add(item, url=target, **kwargs)
        return item

    def separator(self, label: str = CONST_REF.folder.separator_label, **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new seaparator / label menu. No any operation."""
        item = FFItem(const_value(label), mode=FMode.Separator)
        self.add(item, url=_no_operation, **kwargs)
        return item

    def gallery(self, label: Optional[str] = None, target: Optional[Target] = None, *, flat: bool = False, **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new photo gallery menu."""
        if label is None:
            label = L(30572, 'Photos')
        if flat:
            mode, route_method = FMode.Command, show_gallery
        else:
            mode, route_method = FMode.Folder, show_gallery_folder
        item = FFItem(label, mode=mode, info_type='pictures')
        url = self._make_url(target)
        if url.startswith(plugin_url):
            path = url[len(plugin_url):]
            self.add(item, url=url_for(route_method, path=path), **kwargs)
        else:
            self.add(item, url=url_for(route_method, url=url), **kwargs)
        return item

    def image(self, path: Union[URL, str], label: Optional[str] = None, action: Optional[Target] = None, **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new image menu."""
        item = FFItem(label, mode=FMode.Command, info_type='pictures')
        self.add(item, url=action, **kwargs)
        return item

    def focus_item(self, item: Optional[FFItem]) -> None:
        """Set item and try to focus it (by service)."""
        self._focused_item = item

    @contextmanager
    def item_mutate(self) -> Iterator['KodiDirectoryMutate']:
        """With context for mutate (modify) added items."""
        yield KodiDirectoryMutate(self, len(self.items))

    @classmethod
    @contextmanager
    def catch(cls) -> Iterator[DirectoryCatch]:
        """With context to catch exceptions and show them as error folder."""
        state = cls.state()
        previous_catch = state.catch
        try:
            catch = DirectoryCatch()
            state.catch = catch
            yield catch
        except Exception:
            fflog_exc('Error in caught directory')
        finally:
            state.catch = previous_catch

    def no_content(self, content_view: Optional[ContentView] = None, *, target: Target = None, empty_message: Optional[str] = None) -> None:
        """Empty folder."""
        if not empty_message:
            empty_message = L(32834, 'No content to display')
        if const.indexer.no_content.show_item:
            self.folder(empty_message, target, icon='common/error.png')
        if const.indexer.no_content.notification:
            control.infoDialog(empty_message)

    no_op = staticmethod(_no_operation)

    no_op_url = str(url_for(_no_operation))


@define
class KodiDirectoryMutate:
    """With context for mutate (modify) added items."""

    kdir: KodiDirectory
    index: int = 0

    @property
    def items(self) -> Sequence[FFItem]:
        """Return new added items."""
        return self.kdir.items[self.index:]

    @property
    def item(self) -> Optional[FFItem]:
        """Return last new added item."""
        assert self.index >= 0
        if len(self.kdir.items) > self.index:
            return self.kdir.items[-1]
        return None

    @property
    def menu(self) -> Optional[List[ContextMenuItem]]:
        """Menu of last new added item."""
        assert self.index >= 0
        if len(self.kdir.items) > self.index:
            return list(self.kdir._last_item_menu or ())
        return None

    @menu.setter
    def menu(self, menu: ContextMenu) -> None:
        if not (item := self.item):
            raise IndexError('No item to mutate')
        self.kdir._set_item(item, enable_art=False, enable_format=False, menu=menu)

    def isort(self, sort: Sort, *, reverse: bool = False) -> None:
        """Sort items by Sort object in place."""
        def key(item: FFItem):
            if sort == 'label':
                return item.label.lower()
            if sort == 'title':
                return item.vtag.getTitle().lower()
            if sort == 'year':
                return item.vtag.getYear() or 0
            raise ValueError(f'Unknown sort: {sort}')
        if self.index:
            self.kdir.items[self.index:] = sorted(self.kdir.items[self.index:], key=key, reverse=reverse)
        else:
            self.kdir.items.sort(key=key, reverse=reverse)


def no_content(content_view: Optional[ContentView] = 'addons', *, target: Target = None, empty_message: Optional[str] = None) -> None:
    """Show no content folder."""
    with directory(view=content_view) as kdir:
        kdir.no_content(content_view, target=target, empty_message=empty_message)


@contextmanager
def directory(items: Optional[PagedItems] = None,  # optional items get pagination
              *,
              # Extra arguments for "next page" routing, next page url_for().
              route_args: Optional[Dict[str, Any]] = None,
              # All KodiDirectoryKwArgs arguments.
              **kwargs: Unpack[KodiDirectoryKwArgs]) -> Iterator[KodiDirectory]:
    kdir = KodiDirectory(**kwargs)
    if kdir.state().catch is None and kdir.handle == -1 and const.folder.script_autorefresh:  # called as script
        import sys
        folder_update(str(url_for()))
        sys.exit()
    kdir.ready_for_data()
    # Force next page as redirect page.
    next_page: Union[Target, Literal[False]] = kwargs.pop('next_page', None)
    previous_page: Union[Target, Literal[False]] = kwargs.pop('previous_page', None)
    if route_args is None:
        route_args = {}
    try:
        def show_page_item(*, go_next: bool) -> None:
            from lib.ff.control import is_plugin_folder
            A_LOT_PAGES = 1_000_000_000
            if not items or not hasattr(items, 'page') or not (page := items.page):
                return  # no page api
            total_pages = min(getattr(items, 'total_pages', A_LOT_PAGES), const.folder.max_page_jump or A_LOT_PAGES)
            if go_next:
                if next_page is False or not (is_plugin_folder() or settings.getBool('widgets_nextpage')):
                    return  # no next page (a widget without `widgets_nextpage`), never a previous one instead
                another_page = items.next_page() if hasattr(items, 'next_page') else page + 1
                if another_page and another_page > total_pages:
                    fflog.debug(f'[MENU] Ignore next page {another_page}, because is greater then const.folder.max_page_jump={const.folder.max_page_jump}')
                    return
                icon = 'common/poster_next.jpg'
                landscape = 'common/landscape.jpg'
                label = KodiDirectory.NEXT_PAGE_LABEL
                # force next page as redirect
                if next_page is not None:
                    kdir.folder(label, next_page, icon=icon,
                                thumb=icon, banner=icon, poster=icon, landscape=landscape)
                    return
            else:
                if previous_page is False:
                    return
                if const.folder.previous_page == 'never':
                    return
                another_page = page - 1
                icon = 'common/poster_prev.jpg'
                landscape = 'common/landscape_prev.jpg'
                label = KodiDirectory.PREV_PAGE_LABEL
            if not another_page:  # out of range
                return
            if hasattr(items, 'total_pages'):
                descr = L(30125, 'Go to page {page} / {total_pages}').format(page=another_page, total_pages=total_pages)
                if go_next is False and const.folder.previous_page == 'on_last_page' and page  < total_pages:
                    return
            else:
                total_pages = 0
                descr = L(30240, 'Go to page {page}').format(page=another_page)
            kdir.folder(label, url_for(page=another_page, **route_args), icon=icon,
                        thumb=icon, banner=icon, poster=icon, landscape=landscape, descr=descr, menu=[
                            CMenu(L(30241, 'First page'), url_for(page=1, **route_args), visible=page > 1),
                            CMenu(L(30332, 'Previous page'), url_for(page=page-1, **route_args), visible=page > 2),
                            CMenu(L(30242, 'Jump to page...'), url_proxy(jump_to_page, page=page, total_pages=total_pages), visible=total_pages > 3),
                            CMenu(L(30243, 'Last page'), url_for(page=total_pages, **route_args), visible=page + 1 < total_pages),
                        ])

        show_page_item(go_next=False)
        yield kdir
        show_page_item(go_next=True)
    except Exception:
        fflog_exc()
    finally:
        kdir.close()


@contextmanager
def gallery_directory(items: Optional[PagedItems] = None,  # optional items get pagination
                      *,
                      # Extra arguments for "next page" routing, next page url_for().
                      route_args: Optional[Dict[str, Any]] = None,
                      # All KodiDirectoryKwArgs arguments.
                      **kwargs: Unpack[KodiDirectoryKwArgs]) -> Iterator[KodiDirectory]:
    kwargs.setdefault('view', 'images')
    with directory(items, route_args=route_args, **kwargs) as kdir:
        yield kdir


# @route('/jumping_to_page/{page}/{total_pages}/{url}')
@route('{url}/jumping_to_page/{page}/{total_pages}')
def jump_to_page(url: URL, page: int, total_pages: int, **kwargs) -> None:
    """Proxy to jump to page with page number dialog."""

    from xbmcgui import Dialog
    from ..main import find_inner_call
    ShowAndGetNumber = 0

    if call := find_inner_call(url.with_query(kwargs)):
        total_pages = min(total_pages, const.folder.max_page_jump or 9999)
        heading = L(30244, 'Enter page number (1..{total_pages})').format(page=page, total_pages=total_pages)
        if snum := Dialog().numeric(ShowAndGetNumber, heading):
            if snum.isdecimal():
                page = int(snum)
                if page < 1:
                    page = 1
                elif total_pages and page > total_pages:
                    page = total_pages
                meth = call.bind()
                target = url_for(meth, page=page, **{**call.kwargs, **kwargs})
                if target:
                    folder_update(str(target))


def _show_ff_gallery_folder(url: 'URL | str') -> None:
    """Show Kodi folder as gallery dialog, its category as the title."""
    from ..main import find_inner_call
    from ..windows import gallery
    with KodiDirectory.catch() as catch:
        if call := find_inner_call(url):
            main_router.call(call)
    images = [it for it in catch.items if it.info_type == 'pictures']
    if not images:
        if not catch.items:  # else the folder answered no content itself (its item and notification)
            no_content('images')
        return
    title = catch.kdir.category if catch.kdir and isinstance(catch.kdir.category, str) else ''
    gallery.show_gallery(title, images)


@route('/gallery/{__path}')
def show_gallery(*, art_type: Optional[ArtLabel] = None, path: Optional[PurePosixPath] = None, url: Optional[str] = None, flat: bool = True) -> None:
    from .control import execute, WINDOW_PICTURES
    if not art_type and not flat:
        return show_gallery_folder(path=path, url=url)
    if path is None and not url:
        no_content('images')
        return
    if path is not None:
        im_url = URL(plugin_url) / path
    else:
        assert url
        im_url = URL(url)
    if art_type:
        im_url = im_url % {'art_type': art_type}
    # this is a FanFilm gallery, just catch folder and show in the dialog
    if im_url.scheme == 'plugin' and im_url.hostname == plugin_id:
        _show_ff_gallery_folder(im_url)
    else:
        execute(f'ActivateWindow({WINDOW_PICTURES}, {im_url}, return)')


@route('/galleries/{__path}')
def show_gallery_folder(path: Optional[PurePosixPath] = None, url: Optional[str] = None) -> None:
    from .art import art_type_label
    from ..main import find_inner_call
    if path is None and not url:
        no_content('images')
        return
    if path is not None:
        im_url = URL(plugin_url) / path
    else:
        assert url
        im_url = URL(url)
    with KodiDirectory.catch() as catch:
        if call := find_inner_call(im_url):
            main_router.call(call)
        art_types: Set[ArtLabel] = {atype for it in catch.items for atype in it.getArt()}
        art_types.discard('thumb')
    with directory() as kdir:
        for atype in sorted(art_types):
            label = art_type_label(atype).many
            item = FFItem(label, mode=FMode.Command, info_type='pictures')
            kdir.add(item, url=url_for(show_gallery, path=path, url=url, art_type=atype))


if __name__ == '__main__':
    from ..defs import ItemList

    with directory(view='addons') as kdir:
        kdir.folder('ala ma kaca', '/')
        kdir.folder(12345, '/')  # test nieporawnego argumentu

    items = ItemList(page=1, total_pages=5, total_results=10)
    with directory(items, view='addons') as kdir:
        kdir.folder('ala ma kaca', '/')
        kdir.folder(12345, '/')  # test nieporawnego argumentu
