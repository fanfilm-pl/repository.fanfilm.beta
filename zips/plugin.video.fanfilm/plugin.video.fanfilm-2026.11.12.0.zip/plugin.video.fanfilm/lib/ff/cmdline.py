
from __future__ import annotations
import re
from typing import Any, Sequence, Iterator, TypeVar, Generator, TYPE_CHECKING
from typing_extensions import TypedDict, Unpack, NotRequired, Type, Literal, Self, Generic, get_args as get_typing_args
from contextlib import contextmanager
from argparse import ArgumentParser, Namespace, Action, ArgumentError
from wrapt import ObjectProxy
from ..defs import MediaRef, VideoIds, RefType
# from ..api.tmdb import MediaRequest
if TYPE_CHECKING:
    from argparse import _FormatterClass, _SubParsersAction
    from .ratings import RatingService
    from .types import SequenceProto


T = TypeVar('T')


class ParserKwArgs(TypedDict):
    prog: NotRequired[str | None]
    usage: NotRequired[str | None]
    description: NotRequired[str | None]
    epilog: NotRequired[str | None]
    parents: NotRequired[Sequence[ArgumentParser]]
    formatter_class: NotRequired[_FormatterClass]
    prefix_chars: NotRequired[str]
    fromfile_prefix_chars: NotRequired[str | None]
    argument_default: NotRequired[str | None]
    conflict_handler: NotRequired[Literal['error', 'resolve']]
    add_help: NotRequired[bool]
    allow_abbrev: NotRequired[bool]
    exit_on_error: NotRequired[bool]


class AddSubparsersKwArgs(TypedDict):
    title: NotRequired[str]
    description: NotRequired[str | None]
    prog: NotRequired[Any]
    parser_class: NotRequired[Type[ArgumentParser]]
    action: NotRequired[str]
    option_strings: NotRequired[str | None]
    dest: NotRequired[str | None]
    required: NotRequired[bool]
    help: NotRequired[str | None]
    metavar: NotRequired[str | None]


class AddParserKwArgs(TypedDict):
    help: NotRequired[str | None]
    aliases: NotRequired[Sequence[str]]
    prog: NotRequired[str | None]
    usage: NotRequired[str | None]
    description: NotRequired[str | None]
    epilog: NotRequired[str | None]
    parents: NotRequired[Sequence[ArgumentParser]]
    formatter_class: NotRequired[_FormatterClass]
    prefix_chars: NotRequired[str]
    fromfile_prefix_chars: NotRequired[str | None]
    argument_default: NotRequired[Any]
    conflict_handler: NotRequired[str]
    add_help: NotRequired[bool]
    allow_abbrev: NotRequired[bool]
    exit_on_error: NotRequired[bool]


class RatingAction(Action):
    def __call__(self, parser, namespace, values, option_string=None):
        from .ratings import NORM_MIN, NORM_MAX
        try:
            if isinstance(values, list) and len(values) > 1:
                val, *refs = values
                if '.' in val:
                    val = float(val)
                else:
                    val = int(val)
                if 1 or NORM_MIN <= val <= NORM_MAX:
                    setattr(namespace, self.dest, [val, *(parse_ref(ref) for ref in refs)])
                    return
        except Exception:
            pass
        raise ArgumentError(self, f'RATING REF ... ({NORM_MIN}..{NORM_MAX} movie/ID|show/ID[/SEASON[/EPISODE]]...)')


def rating_action(service: RatingService) -> Type[Action]:
    """Factory for RatingAction class."""

    class XRatingAction(Action):
        def __call__(self, parser, namespace, values, option_string=None):
            from .ratings import NORM_MIN, NORM_MAX
            try:
                if isinstance(values, list) and len(values) > 1:
                    val, *refs = values
                    val = service.scale.type(val)
                    if NORM_MIN <= val <= NORM_MAX:
                        setattr(namespace, self.dest, [val, *(parse_ref(ref) for ref in refs)])
                        return
            except Exception:
                pass
            raise ArgumentError(self, f'RATING REF ... ({NORM_MIN}..{NORM_MAX} movie/ID|show/ID[/SEASON[/EPISODE]]...)')

    return XRatingAction


class DebugArgumentParser(ArgumentParser):

    def __init__(self, *, dest: str | None = None, **kwargs: Unpack[ParserKwArgs]) -> None:
        super().__init__(**kwargs)
        self._ff_subparsers_dest: str | None = dest
        self._ff_subparsers: _SubParsersAction | None = None

    def parse_known_args(self,  # type: ignore
                         args: Sequence[str] | None = None,
                         namespace: Any = None,
                         ) -> tuple[Namespace, list[str]]:
        if args is None:
            from .. import cmdline_argv
            args = cmdline_argv[1:]
        return super().parse_known_args(args, namespace)

    @contextmanager
    def with_subparser(self, name: str, dest: str | None = None, **kwargs: Unpack[AddParserKwArgs]) -> Generator[Self, None, None]:
        if self._ff_subparsers is None:
            pp_kwargs = {}
            if self._ff_subparsers_dest is not None:
                pp_kwargs['dest'] = self._ff_subparsers_dest
            self._ff_subparsers = self.add_subparsers(**pp_kwargs)
        yield self._ff_subparsers.add_parser(name, dest=dest, **kwargs)


def parse_ref(v: str, *, type: str | None = None) -> MediaRef:
    ref_type_pat = '|'.join(t for t in get_typing_args(RefType) if t)
    if mch := re.fullmatch(r'movie/(\d+)', v):
        media, ids = 'movie', [int(mch[1])]
    elif mch := re.fullmatch(r'show/(\d+(?:/\d+(?:/\d+)?)?)', v):
        media, ids = 'show', list(map(int, mch[1].split('/')))
    elif mch := re.fullmatch(rf'({ref_type_pat})/(?:(\d+)|(?:))', v):
        media, ids = mch[1], [int(mch[2])]
        if TYPE_CHECKING:
            assert media in ('movie', 'show', 'season', 'episode', 'person', 'collection', 'company', 'keyword', 'network',
                             # extra types (has no tmdb details)
                             'genre', 'language', 'country', 'list')
    elif mch := re.fullmatch(r'person/(\d+)', v):
        media, ids = 'person', [int(mch[1])]
    elif mch := re.fullmatch(r'movie/((?:(?:tmdb|imdb|trakt|mdblist)[:.])?\w+)', v):
        media, ids = 'movie', [VideoIds.guess_id(mch[1].replace('.', ':')).ffid]
    elif mch := re.fullmatch(r'show/((?:(?:tmdb|imdb|trakt|mdblist)[:.])?\w+)(?:/(\d+(?:/\d+)?))?', v):
        media, ids = 'show', [VideoIds.guess_id(mch[1].replace('.', ':')).ffid, *(int(x) for x in (mch[2] or '').split('/') if x)]
    elif v[:1] in 'Mm':
        media, ids = 'movie', [int(v[1:])]
    elif v[:1] in 'Tts':
        media, ids = 'show', list(map(int, v[1:].split('/')))
    elif v[:1] in 'S':
        media, ids = 'season', [int(v[1:])]
    elif v[:1] in 'E':
        media, ids = 'episode', [int(v[1:])]
    elif v[:1] in 'Pp':
        media, ids = 'person', [int(v[1:])]
    elif type:
        return parse_ref(f'{type}/{v}')
    else:
        raise ValueError(f'Incorrect media ref {v!r}')
    if ids[0] < 0:
        ids[0] = -ids[0]
    elif ids[0] < VideoIds.TMDB.start:
        ids[0] += VideoIds.TMDB.start
    return MediaRef(media, *ids)


def parse_movie_ref(v: str) -> MediaRef:
    return parse_ref(f'movie/{v}')


def parse_show_ref(v: str) -> MediaRef:
    return parse_ref(f'show/{v}')


class ItemProxy(ObjectProxy, Generic[T]):
    def __init__(self, item: T, *, index: int, width: int = 0) -> None:
        super().__init__(item)
        self._self_index = index
        self._self_width = width

    @property
    def index(self) -> int:
        return self._self_index

    @property
    def num(self) -> str:
        return f'{self._self_index:{self._self_width}d}'


@contextmanager
def enumerate_items(items: SequenceProto[T], start: int = 1, *, offset: int = 0, page: int | None = None, page_size: int = 100) -> Generator[list[T], None, None]:
    from math import log10
    if not offset and page and page_size:
        offset = ((page or 1) - 1) * page_size
    w = int(1 + log10(offset + len(items) + start))
    items = [ItemProxy(it, index=i, width=w) for i, it in enumerate(items, offset + start)]
    yield items


if __name__ == '__main__':
    p = DebugArgumentParser(dest='x')
    with p.with_subparser('aa') as o:
        o.add_argument('-a')
    with p.with_subparser('bb') as o:
        o.add_argument('-b')
    print(p.parse_args())
