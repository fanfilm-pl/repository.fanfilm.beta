"""
Our wrapper for threading.Thread: the threads of the SDK (`lib.sdk.threads`: result value, on_finished callbacks
(ex. to clean DB connection), stop scopes) bound to FanFilm (its Kodi monitor, `const`), and the Kodi sleeps.
"""

from __future__ import annotations
from time import monotonic
from threading import Event as _Event
from typing import Optional, Callable, TypeVar, TYPE_CHECKING
from typing_extensions import Generic

from xbmc import Monitor
from ..sdk import threads as _sdk_threads
from ..sdk.threads import (  # noqa: F401  (the threads of FanFilm)
    Lock, RLock, Condition, current_thread, ShutDown, ThreadOnFinished, MAX_TIMESTAMP,
    ThreadCanceled, local, ThreadSingleLocal, Event, CancelScope, current_scope, PriorityQueue, Thread, WeakThread,
    check_thread_cancel, Queue, inherit_thread_scopes, watch_sockets, cut_sockets, abort_network,
)
from const import const

if TYPE_CHECKING:
    from typing_extensions import Type
    from .kotools import ExitBaseException

T = TypeVar('T')


def _wait_monitor() -> Monitor:
    """
    Return the monitor of a wait: the FF monitor sees Kodi exit (System.OnQuit) and exists anyway, a new Monitor() is
    a new Kodi object on every wait and one created after the exit never sees it. Do not start the FF monitor here.
    """
    from .kotools import KodiMonitor
    return KodiMonitor._instance or Monitor()


def _event_step() -> float:
    """Return the wait step (`const.tune.event_step`)."""
    return const.tune.event_step


def _log_exception() -> bool:
    """Return the exception log switch (`const.debug.log_exception`)."""
    return const.debug.log_exception


_sdk_threads.options.monitor = _wait_monitor
_sdk_threads.options.event_step = _event_step
_sdk_threads.options.log_exception = _log_exception


def xsleep(interval: float,
           *,
           cancel_event: _Event | None = None,
           ) -> bool:
    """
    Sleep in safe mode. Exit on Kodi exit. Return True if timer expired, False if cancelled.

    Without `cancel_event` the sleep ends when the thread is stopped (its CancelScope) and raises ThreadCanceled
    (like check_thread_cancel()), a stopped provider does not sleep on. Returning False would make a sleep-only
    loop spin. Kodi exit or the monitor destroy wakes the timer by its event, i.e. stops that scope too.
    """
    from .kotools import KodiMonitor, KodiExit
    from .logs import fflog  # here: logs imports this module
    scope = current_scope() if cancel_event is None else None
    if scope is not None and scope.is_set():
        raise ThreadCanceled()
    xmonitor = KodiMonitor.instance()
    # if xmonitor is None:
    #     return  # Monitor is destroying.
    if cancel_event is not None and cancel_event.is_set():
        # cancel_event.clear()  # clear event if set
        return False
    timer = xmonitor.new_timer(interval, event=cancel_event if cancel_event is not None else scope)
    T = monotonic()
    expired = xmonitor.wait(timer)
    if const.debug.log_xsleep_jitter and (jitter := abs((dt := monotonic() - T) - interval)) >= const.debug.log_xsleep_jitter:
        fflog(f'[KOTOOLS]  xsleep({interval}) {jitter:.3f} mismatch, finished after {dt:.3f} seconds, {timer=} (ev={timer.event.is_set()}),'
              f' {cancel_event=} / {cancel_event and cancel_event.is_set()=}', internal=True)
    # timer.event.clear()  # clear event after wait
    if xmonitor and (xmonitor.aborting or xmonitor.abortRequested()):
        raise KodiExit()
    if scope is not None and scope.is_set():
        raise ThreadCanceled()
    return expired


def xsleep_until_exit(interval: float) -> Optional[Type[ExitBaseException]]:
    """Sleep like `xsleep()`, return the exception class of its end (the Kodi exit...) instead of raising it, None if it expired."""
    from .kotools import ExitBaseException
    try:
        xsleep(interval)
    except ExitBaseException as exc:
        return type(exc)
    return None


class Timer(Thread, Generic[T]):
    """
    Call a function after a specified number of seconds:

    >>> t = Timer(30.0, f, args=None, kwargs=None)
    >>> t.start()
    >>> t.cancel()     # stop the timer's action if it's still waiting

    Modified Python's version. Keep function result.
    """

    def __init__(self, interval: float, function: Callable[..., T], args=None, kwargs=None) -> None:
        super().__init__()
        self.interval = interval
        self.function = function
        self.args = args if args is not None else []
        self.kwargs = kwargs if kwargs is not None else {}
        self.finished = Event()
        self.result: Optional[T] = None

    def cancel(self) -> None:
        """Stop the timer if it hasn't finished yet."""
        self.finished.set()

    def run(self) -> None:
        xsleep(self.interval, cancel_event=self.finished)
        if not self.finished.is_set():
            self.result = self.function(*self.args, **self.kwargs)
        self.finished.set()


if __name__ == '__main__':
    class MT(Thread):
        def run(self):
            loc.__dict__.setdefault('a', 42)
            print(42, id(loc), loc.__dict__)
            return 42

    class A:
        def print44(self, a=1, b=2):
            loc.__dict__.setdefault('a', 44)
            print(f'44: {a=}, {b=}', id(loc), loc.__dict__)
            return 44

    loc = _local()
    t1 = MT()
    t2 = Thread(target=A().print44, args=(1, 2))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print(t1.name, t2.name)
    print(t1.result, t2.result)
