"""
Accounts DB (the "dumb" side): ``accounts.db`` with the state of accounts.

``account_data`` (:class:`AccountDataRow`) -- key-value state of an account (tokens of accounts outside the
settings, profile, activities of a service, ...) in the account namespace (the account ID). It is the state written
by the code; the account configuration is ``/accounts`` of ``config.json`` (see ``lib.ff.accounts``). Not a cache: no cache
action clears it, only removing an account does.
"""

from __future__ import annotations
from .kvstore import KeyValueRow, KeyValueStore, cleanup_expired
from .db import sql_dump
from .orm import OrmDatabase, select, update_or_ignore, delete, best_effort

#: Accounts DB version.
DB_VERSION: int = 1


class AccountDataRow(KeyValueRow):
    """Key-value state of an account (the namespace is the account ID)."""

    __tablename__ = 'account_data'


def account_data_store(account_id: str) -> KeyValueStore:
    """Return the state store of the account."""
    return KeyValueStore(account_id, table=AccountDataRow, db=lambda: db)


def account_data_namespaces() -> set[str]:
    """Return the namespaces with state (the account IDs, also of the internal stores, e.g. the type aliases of the migration)."""
    with db.cursor() as cur:
        return {row.namespace for row in cur.exec(select(AccountDataRow)).iter()}


def remove_account_data(account_id: str) -> None:
    """Remove all state of the account (the account is removed)."""
    account_data_store(account_id).clear()


def rename_account_data(old: str, new: str) -> None:
    """
    Move all state of the account `old` to the account ID `new` (the migrated settings accounts). A key the account `new`
    already has is kept (a migration again: its state is newer), the one of `old` removed.
    """
    with db.cursor(write=True) as cur:
        cur.exec(update_or_ignore(AccountDataRow).set(namespace=new).where(AccountDataRow.namespace == old))
    remove_account_data(old)


def reset_sync(account_id: str | None = None) -> None:
    """
    Forget the sync cursors (`sync.*` keys) of the account or all accounts (`playback.db` is built anew): the next sync
    is a full one.
    """
    def remove() -> None:
        where = '"key" LIKE \'sync.%\''
        if account_id is not None:
            where = f'{where} AND "namespace" = {sql_dump(account_id)}'
        with db.cursor(write=True) as cur:
            cur.exec(delete(AccountDataRow).where(where))

    best_effort(lambda: None, db=lambda: db)(remove)()


def cleanup() -> int:
    """Remove expired state rows (run by the service, also for suspended accounts). Return the count."""
    return cleanup_expired(db, AccountDataRow)


#: Global accounts DB.
db: OrmDatabase = OrmDatabase('accounts', AccountDataRow, version=DB_VERSION)
