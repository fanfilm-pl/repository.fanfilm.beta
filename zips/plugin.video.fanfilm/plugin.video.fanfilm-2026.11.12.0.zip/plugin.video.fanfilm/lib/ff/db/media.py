"""Media cache DB (the "dumb" side): the ``media.db#info`` table and its row operations.

It stores/reads :class:`MediaInfoRow` rows keyed by ``(ref, lang)`` plus freshness (``expires_at``), no cache
policy (dependency direction ``db -> FFItem``: the merge of a stored row reads the FFItem declarations, the identity
fields). The "smart" ffinfo layer maps rows <-> ``FFItem`` and decides what/when to store; the freshness policy itself
lives in :mod:`lib.ff.db.freshness`.
"""

if __name__ == '__main__':
    # CLI for operate on media DB. Do NOT remove.
    from ..cmdline import DebugArgumentParser
    from ...dev.main import predefine as tui_predefine, parse_args as tui_parse_args
    cli_args, cli_argv = tui_predefine()
else:
    cli_args, cli_argv = None, []

from typing import Optional, Union, Tuple, Set, Sequence, Iterable, Iterator, Dict, Any, Callable, TypeVar, TYPE_CHECKING
from typing_extensions import TypeAlias, cast
from functools import wraps
import json as json_mod
from sqlite3 import IntegrityError as DbIntegrityError, Error as DbError, DatabaseError

from .db import db_manager, sql_dump, DbCursor, PrimaryKey, SQL
from .orm import OrmDatabase, DbTable, field as db_field, select, delete, insert_or_replace, OR, MISSING, best_effort, delete_expired
from ..calendar import utc_timestamp
from const import const
from ..logs import fflog
from ..tricks import MissingType, JsonEncoder, dict_update_r
from ..types import JsonData
from ...defs import MediaRef, XMediaRef, AllIdsDict, IdService

if TYPE_CHECKING:
    from datetime import datetime, date as dt_date


#: Media DB version. v2 = ORM ``info`` table keyed by ``(ref, lang)`` with freshness.
#: v3 = last / next aired episodes are rows, not JSON dumps in the show row (the cache is dropped).
#: v4 = the ``ids`` table of external IDs (the ``info`` rows are kept).
#: v5 = the ``aired`` table of aired episodes of shows (the other rows are kept).
DB_VERSION: int = 5


def to_xref(ref: MediaRef) -> XMediaRef:
    """Return the normalized reference (xref) for `ref`."""
    return ref.xref


def to_timestamp(dt: 'str | float | datetime | dt_date | None') -> Optional[int]:
    """Convert `dt` to a unix timestamp (seconds), or None if `dt` is None."""
    if dt is None:
        return None
    return int(utc_timestamp(dt))


def to_json(data: 'JsonData | str') -> str:
    """Convert `data` to a JSON string (if it's not already)."""
    if isinstance(data, str):
        return data
    return json_mod.dumps(data, cls=JsonEncoder)


class MediaInfoRow(DbTable):
    """Cached media-info row, keyed by ``(ref, lang)`` with freshness (``expires_at``).

    The static media data is the FFItem JSON dump kept in ``json_string`` (decoded lazily via the
    ``data`` property, same pattern as ``SourceEditEntry``). The denormalized columns (``tmdb``,
    ``imdb``, ``details``, ``children_count``, ``premiere``, ``updated_at``, ``expires_at``) let the
    hot paths (id lookup, freshness check) avoid decoding ``json_string`` at all.
    """

    __tablename__ = 'info'
    # Single (normalized) identity key; the denormalized `ffid` is intentionally NOT unique (seasons
    # may carry only a volatile/zero id -- the service rebuilds the ref from the show otherwise).
    __table_args__ = (
        'UNIQUE("xref::type", "xref::ffid", "xref::season", "xref::episode", "lang")',
    )
    # Secondary indexes for the denormalized id lookups (known_ids / by-id recovery).
    __table_indexes__ = ('tmdb', 'imdb')

    #: The primary DB key.
    id: PrimaryKey = None
    #: Media reference, normalized (-1 instead of None for season/episode).
    xref: XMediaRef = db_field(default=MISSING, converter=to_xref)
    #: Denormalized node FFID (e.g. an episode's own ffid); 0 if unknown.
    ffid: int = 0
    #: Row language (part of the key): the language of the main title.
    lang: str = ''
    #: Content-aspect fingerprint (``InfoDetails & ITEM_MASK``) the node was obtained with; 0 = NONE.
    details: int = 0
    #: Declared number of children (container completeness axis).
    children_count: int = 0
    #: Reference date (premiere / last air) as a unix timestamp; TTL-policy input.
    premiere: Optional[int] = db_field(default=None, converter=to_timestamp)
    #: Store time (unix seconds); auto-stamped on every write (== ``FFItem.meta_updated_at``).
    #: Computed in Python: SQLite before 3.42 (Kodi 21 on Windows, Android) shifts `strftime('%s', 'now', 'utc')` by the time zone.
    updated_at: Optional[int] = db_field(default=None, on_update=lambda _: _now(), auto_generated=True, init=False)
    #: Freshness deadline (unix seconds); DB-only, computed by ffinfo's freshness policy.
    expires_at: Optional[int] = db_field(default=None, converter=to_timestamp)
    #: The Movie Database ID (denormalized for ``known_ids``); 0 = unknown (no NULL).
    tmdb: int = 0
    #: Internet Movie Database ID (denormalized for ``known_ids``); '' = unknown (no NULL).
    imdb: str = ''
    #: FFItem JSON dump (static node data) as text.
    json_string: str = db_field(default='{}', converter=to_json)
    #: Title (debug / quick listing only).
    title: Optional[str] = None

    # cached views (not stored columns)
    _data: Optional[JsonData] = None

    @property
    def ref(self) -> MediaRef:
        """Return media reference (denormalizing -1 back to None)."""
        return MediaRef.from_sql_ref(self.xref)

    @ref.setter
    def ref(self, ref: MediaRef) -> None:
        self.xref = ref.sql_ref

    @property
    def denormalized_ref(self) -> Optional[MediaRef]:
        """Return the direct/denormalized ref (by the node's own ``ffid``), or None if unknown."""
        if not self.ffid:
            return None
        x = self.xref
        if x.episode >= 0:
            return MediaRef('episode', self.ffid)
        if x.season >= 0:
            return MediaRef('season', self.ffid)
        return MediaRef(x.type, self.ffid)

    @property
    def data(self) -> JsonData:
        """Return the decoded FFItem JSON (lazy; cached)."""
        if self._data is None:
            data: JsonData = json_mod.loads(self.json_string)
            self._data = data
        return self._data

    @data.setter
    def data(self, data: JsonData) -> None:
        self._data = data
        self.json_string = json_mod.dumps(data, cls=JsonEncoder)


MediaInfoRowDict: TypeAlias = Dict[MediaRef, MediaInfoRow]
#: Stored rows by their identity key ``(xref, lang)``.
MediaInfoRowByKey: TypeAlias = Dict[Tuple[XMediaRef, str], MediaInfoRow]


class MediaIdRow(DbTable):
    """External ID of media: a link ``(ref, service) -> value``, kept permanently (not a cache).

    The ref is the TMDB ref of the media (an episode: the series with season / episode); a link of an unresolved
    external ref (e.g. an IMDb ref without TMDB) has that ref and an empty value - a "nothing found" marker with
    a short deadline. ``expires_at`` NULL = no deadline. The policy (sources, deadlines, 1 : 1 services) is in ffinfo.
    """

    __tablename__ = 'ids'
    __table_args__ = ('UNIQUE("xref::type", "xref::ffid", "xref::season", "xref::episode", "service", "value")',)
    __table_indexes__ = (('service', 'value'),)

    #: The primary DB key.
    id: PrimaryKey = None
    #: Media reference (TMDB), normalized (-1 instead of None for season/episode).
    xref: XMediaRef = db_field(default=MISSING, converter=to_xref)
    #: ID service (``imdb``, ``trakt``, ``tvdb``, ``kitsu``, ...).
    service: str = ''
    #: The ID as text ('' = nothing found, a marker).
    value: str = ''
    #: Where the link comes from (``tmdb``, ``mdblist``, ``trakt``, ``fribb``, ...).
    source: str = ''
    #: Store time (unix seconds).
    updated_at: int = 0
    #: Deadline (unix seconds), None = no deadline.
    expires_at: Optional[int] = None

    @property
    def ref(self) -> MediaRef:
        """Return media reference (denormalizing -1 back to None)."""
        return MediaRef.from_sql_ref(self.xref)


class MediaAiredRow(DbTable):
    """The aired episodes of a show (the shows in progress tell the ones watched in 100 % with no media row), by its FFID.

    Valid until ``expires_at`` (the next air of an episode, or the freshness of its media row when no air date is known),
    a TMDB change of the show expires it at once; an expired one stays until the cleanup (the show waits for an update).
    The policy (what is aired, the deadline) is in ffinfo.
    """

    __tablename__ = 'aired'
    __table_args__ = ('UNIQUE("ffid")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: The show FFID.
    ffid: int = 0
    #: The aired episodes of the regular seasons as JSON ``[[season, first episode, last episode], ...]`` (ranges).
    episodes: str = '[]'
    #: The count of the aired episodes (also with no ranges: a show with no seasons in its metadata).
    count: int = 0
    #: Deadline (unix seconds), None = no deadline.
    expires_at: Optional[int] = None

    @property
    def ranges(self) -> Sequence[Tuple[int, int, int]]:
        """Return the aired episode ranges ``(season, first, last)``."""
        return [tuple(r) for r in json_mod.loads(self.episodes)]  # type: ignore[misc]  # JSON lists of 3

    def episode_refs(self, season: Optional[int] = None) -> 'list[MediaRef]':
        """Return the refs of the aired episodes (of the `season` only if given); empty without ranges (no seasons in the metadata)."""
        return [MediaRef.tvshow(self.ffid, sz, ep) for sz, first, last in self.ranges if season is None or sz == season for ep in range(first, last + 1)]


#: WHERE IN VALUES key (normalized): (type, ffid, season, episode).
MediaInfoKey = Tuple[str, int, int, int]


def _now() -> int:
    """Return current UTC unix timestamp (seconds)."""
    return int(utc_timestamp())


def _normalized_keys(refs: Iterable[Optional[MediaRef]]) -> Set[MediaInfoKey]:
    """Return the set of normalized identity keys for `refs`."""
    return {(x.type, x.ffid, x.season, x.episode) for ref in refs if ref for x in (ref.xref,)}


def _multikey_where(keys: Set[MediaInfoKey]) -> Optional[str]:
    """Return a ``(...) IN (VALUES ...)`` clause for the normalized `keys`, or None if empty."""
    if not keys:
        return None
    names = '("xref::type", "xref::ffid", "xref::season", "xref::episode")'
    values = ','.join(f'({",".join(sql_dump(x) for x in key)})' for key in keys)
    return f'{names} IN (VALUES {values})'


F = TypeVar('F', bound=Callable[..., Any])


def _best_effort(default: Callable[[], Any]) -> Callable[[F], F]:
    """Decorate a cache operation of the media DB, see `orm.best_effort()`."""
    return best_effort(default, db=lambda: db)


@_best_effort(dict)
def fetch(refs: Iterable[MediaRef], *, lang: Optional[str] = None, descendants: bool = False,
          episodes_of: Optional[Iterable[MediaRef]] = None) -> MediaInfoRowDict:
    """Return cached, *fresh* rows for `refs` keyed by ref.

    Repo does the cheap axes only: the row language (when `lang` is given) and freshness
    (``expires_at > now``). The fingerprint/completeness axes are evaluated by ffinfo.

    :param refs: media references to read.
    :param lang: row language (part of the key); None means "any language".
    :param descendants: also return the subtree rows reachable by ``(type=show, ffid)``.
    :param episodes_of: with `descendants`, the seasons whose episodes are returned (ffinfo tells which ones are needed),
                        the rest of the subtree is the show and season rows only (a list of shows must not load every
                        cached episode); None - all episodes.
    :return: mapping ``{ref: MediaInfoRow}`` (only fresh rows).
    """
    refs = list(refs)
    where = _multikey_where(_normalized_keys(refs))
    if descendants:
        show_ffids = {ref.xref.ffid for ref in refs if ref and ref.type == 'show'}
        if show_ffids:
            sub = (f'("xref::type" = \'show\' AND "xref::ffid" IN '
                   f'({",".join(sql_dump(f) for f in show_ffids)}))')
            if episodes_of is not None:
                seasons = {(x.ffid, x.season) for ref in episodes_of if ref and ref.type == 'show' for x in (ref.xref,) if x.season >= 0}
                wanted = '"xref::episode" = -1'
                if seasons:
                    values = ','.join(f'({sql_dump(ffid)},{sql_dump(season)})' for ffid, season in seasons)
                    wanted = f'{wanted} OR ("xref::ffid", "xref::season") IN (VALUES {values})'
                sub = f'({sub} AND ({wanted}))'
            where = f'(({where}) OR {sub})' if where else sub
    if where is None:
        return {}
    now = _now()
    with db.cursor() as cur:
        stmt = select(MediaInfoRow).where(where)
        if lang is not None:
            stmt = stmt.where(MediaInfoRow.lang == lang)
        # A row with no deadline (NULL) is treated as fresh; ffinfo always sets one in practice.
        stmt = stmt.where(OR(MediaInfoRow.expires_at == None, MediaInfoRow.expires_at > now))  # type: ignore  # SQL NULL/compare
        if descendants:
            stmt = stmt.order_by(SQL('"xref::season", "xref::episode"'))
        return {m.ref: m for m in cur.exec(stmt).iter()}


def _identity_keys() -> Tuple[Tuple[str, ...], Tuple[str, ...]]:
    """FFItem and its vtag JSON keys with the node identity and structure (`VarApi.identity`): they survive any overwrite (`_union_into`)."""
    from ..item import FFItem, FFVTag
    return (tuple(key for key, var in FFItem.VARS.items() if var.identity),
            tuple(key for key, var in FFVTag.VARS.items() if var.identity))


def _union_into(new: MediaInfoRow, stored: MediaInfoRow) -> None:
    """Union-on-store: fold `stored` into `new` so an upsert never drops cached content.

    Denormalized ids/metadata never shrink (prefer-non-empty). The JSON data and the content
    fingerprint are merged ONLY when `new` is not already a superset of `stored` and both are of the same
    parser (`parse_stamp`; otherwise `new` overwrites cleanly, which also lets a full refetch or a new parser
    un-set fields). The merge deep-updates the
    JSON (new wins per key, stored-only keys survive — safe because `__to_json__` omits defaults)
    and OR-s the fingerprints.
    """
    try:
        stored_data = stored.data
    except ValueError:
        fflog(f'[MEDIA] broken JSON of the stored {stored.ref}, overwritten')
        return
    new.tmdb = new.tmdb or stored.tmdb
    new.imdb = new.imdb or stored.imdb
    new.ffid = new.ffid or stored.ffid
    new.children_count = new.children_count or stored.children_count
    new.title = new.title or stored.title
    if new.premiere is None:
        new.premiere = stored.premiere
    same_parser = stored_data.get('parse_stamp') == new.data.get('parse_stamp')  # a node of an older parser is replaced
    if same_parser and (new.details | stored.details) != new.details:   # new would drop aspects -> keep stored ones
        new.details = new.details | stored.details
        # the JSON fingerprint is read back into FFItem, it must match the merged column (new would roll it back)
        new.data = {**dict_update_r(stored_data, new.data), 'details': new.details}
    else:
        # A clean overwrite must not lose the node identity and structure: a season built as a side effect of
        # an episode request has no own ids and no children count, but claims the full content fingerprint.
        data, old = new.data, stored_data
        identity, vtag_identity = _identity_keys()
        kept = {key: val for key in identity if not data.get(key) and (val := old.get(key))}
        vtag, old_vtag = data.get('vtag') or {}, old.get('vtag') or {}
        kept_vtag = {key: val for key in vtag_identity if not vtag.get(key) and (val := old_vtag.get(key))}
        if kept or kept_vtag:
            new.data = {**data, **kept, 'vtag': {**vtag, **kept_vtag}}


@_best_effort(lambda: None)
def store(rows: Iterable[MediaInfoRow]) -> None:
    """Persist already-built rows (one per ``(ref, lang)``), upserting by the normalized key.

    NONE rows (``details == 0``) are skipped. On a key conflict the row is merged into the stored
    one via :func:`_union_into` (monotonic: cached content never shrinks); a refetch that is a
    superset overwrites cleanly. ``expires_at`` is taken from the incoming row (freshest deadline).

    :param rows: rows to upsert.
    """
    rows = [row for row in rows if row is not None and row.details]
    if not rows:
        return
    # The write cursor takes the write lock up-front (BEGIN IMMEDIATE), so the whole batch's SELECT+INSERT/UPDATE
    # is atomic against other threads and processes (plugin + service + widgets store concurrently).
    # The cursor context commits/rolls back on exit.
    with db.cursor(write=True) as cur:
        stored = _find_existing(cur, rows)
        for row in rows:
            _upsert(cur, row, stored)


def _find_existing(cur: DbCursor, rows: Sequence[MediaInfoRow]) -> MediaInfoRowByKey:
    """Return the stored rows sharing the ``(xref, lang)`` keys of `rows` (one query for the whole batch)."""
    where = _multikey_where(_normalized_keys(row.ref for row in rows))
    if where is None:
        return {}
    langs = {row.lang for row in rows}
    return {(m.xref, m.lang): m for m in cur.exec(select(MediaInfoRow).where(where)).iter() if m.lang in langs}


def _upsert(cur: DbCursor, row: MediaInfoRow, stored: MediaInfoRowByKey) -> None:
    """Insert `row`, or merge it into the existing row sharing its ``(xref, lang)`` key (looked up in `stored`).

    Belt-and-suspenders (C) against a concurrent writer inserting the same key between our SELECT and
    INSERT: on a UNIQUE ``IntegrityError`` we re-read the now-present row and turn the insert into a
    merging UPDATE. ``store()``'s write cursor (``BEGIN IMMEDIATE``) already serializes writers; this
    covers the residual window / when no write lock is held (and a key repeated in one batch).
    """
    existing = stored.get((row.xref, row.lang))
    if existing is not None:
        row.id = existing.id            # turn the INSERT into an UPDATE of the existing row
        _union_into(row, existing)
        cur.add(row)
        return
    try:
        cur.add(row)                    # INSERT (no PK yet)
    except DbIntegrityError:
        existing = _find_existing(cur, [row]).get((row.xref, row.lang))   # a racing writer inserted the same key -> merge into it
        if existing is None:
            raise
        row.id = existing.id
        _union_into(row, existing)
        cur.add(row)


@_best_effort(dict)
def find_denormalized(refs: Iterable[MediaRef]) -> MediaInfoRowDict:
    """Return rows matching the denormalized direct ``ffid`` (e.g. an episode by its own id).

    Used to recover a non-normalized ref (such as one coming from the Kodi monitor) to its stored,
    normalized row. Keyed by the row's (normalized) ref.

    :param refs: denormalized references (their ``ffid`` is the node's own id).
    :return: mapping ``{ref: MediaInfoRow}`` (only fresh rows).
    """
    ffids = {ref.ffid for ref in refs if ref and ref.ffid}
    if not ffids:
        return {}
    now = _now()
    with db.cursor() as cur:
        where = f'"ffid" IN ({",".join(sql_dump(f) for f in ffids)})'
        stmt = select(MediaInfoRow).where(where).where(
            OR(MediaInfoRow.expires_at == None, MediaInfoRow.expires_at > now))  # type: ignore  # SQL NULL/compare
        return {m.ref: m for m in cur.exec(stmt).iter()}


@_best_effort(dict)
def known_ids(refs: Iterable[MediaRef], services: Iterable[IdService]) -> Dict[MediaRef, AllIdsDict]:
    """Return external IDs already cached (no network, no freshness filter).

    Step (a) of id resolution: a cheap local seed from the denormalized ``tmdb``/``imdb`` columns
    (``json_string`` is loaded but never decoded -- the ``data`` property stays untouched).

    :param refs: media references to look up.
    :param services: id services of interest (``tmdb``, ``imdb``, ...).
    :return: mapping ``{ref: AllIdsDict}`` for rows that carry at least one wanted id.
    """
    refs = [ref for ref in refs if ref]
    want = set(services)
    result: Dict[MediaRef, AllIdsDict] = {}
    # the ID map first: links of TMDB refs, and TMDB refs of external IDs (imdb / trakt / tvdb refs)
    for ref, links in ids_of([ref for ref in refs if ref.tmdb_id], want).items():
        if ids := cast(AllIdsDict, {srv: vals[0] for srv, vals in links.items() if len(vals) == 1 and vals[0]}):  # 1 : 1 services only
            result.setdefault(ref, {}).update(ids)  # type: ignore  # AllIdsDict value
    if 'tmdb' in want:
        for service in ('imdb', 'trakt', 'tvdb'):
            ext = {ref: str(val) for ref in refs if not ref.tmdb_id and (val := ref.video_ids.all_ids().get(service))}
            if ext and (found := refs_of(service, ext.values())):
                for ref, val in ext.items():
                    if (tref := found.get((ref.type, val))) is not None and (tmdb := tref.video_ids.tmdb):
                        result.setdefault(ref, {}).update({'tmdb': tmdb, service: val})  # type: ignore  # AllIdsDict value
    with db.cursor() as cur:
        if (where := _multikey_where(_normalized_keys(refs))) is not None:
            for m in cur.exec(select(MediaInfoRow).where(where)).iter():
                ids: AllIdsDict = {}
                if 'tmdb' in want and m.tmdb:
                    ids['tmdb'] = m.tmdb  # type: ignore  # AllIdsDict value
                if 'imdb' in want and m.imdb:
                    ids['imdb'] = m.imdb  # type: ignore  # AllIdsDict value
                if ids:
                    result[m.ref] = ids
        # A ref of IMDb (an IMDB-range ffid) finds the media row of its title by the `imdb` column; an episode ref
        # (the series with season / episode) by the series row
        by_imdb = {ref: imdb for ref in refs if 'tmdb' in want and not ref.tmdb_id and (imdb := ref.video_ids.imdb)}
        if by_imdb:
            values = ','.join(sql_dump(v) for v in set(by_imdb.values()))
            rows = cur.exec(select(MediaInfoRow).where(f'"imdb" IN ({values}) AND "xref::season" = -1')).iter()
            tmdb_of = {(m.xref.type, m.imdb): m.tmdb for m in rows if m.tmdb}
            for ref, imdb in by_imdb.items():
                if tmdb := tmdb_of.get((ref.type, imdb)):
                    result.setdefault(ref, {}).update({'tmdb': tmdb, 'imdb': imdb})  # type: ignore  # AllIdsDict value
    return result


#: An external ID link to store: (media ref, service, value) - an empty value is a "nothing found" marker.
MediaIdLink = Tuple[MediaRef, str, str]


def _ids_where(refs: Iterable[MediaRef]) -> Optional[str]:
    """Return the WHERE clause of the ID links of `refs` (normalized keys)."""
    keys = _normalized_keys(refs)
    if not keys:
        return None
    values = ','.join(f'({",".join(sql_dump(x) for x in key)})' for key in keys)
    return f'("xref::type", "xref::ffid", "xref::season", "xref::episode") IN (VALUES {values})'


@_best_effort(dict)
def ids_of(refs: Iterable[MediaRef], services: Optional[Iterable[str]] = None) -> Dict[MediaRef, Dict[str, Sequence[str]]]:
    """Return fresh ID links of `refs`: ``{ref: {service: [values]}}`` (a marker has the value '')."""
    if (where := _ids_where(refs)) is None:
        return {}
    now = _now()
    want = None if services is None else set(services)
    result: Dict[MediaRef, Dict[str, Sequence[str]]] = {}
    with db.cursor() as cur:
        stmt = select(MediaIdRow).where(where).where(OR(MediaIdRow.expires_at == None, MediaIdRow.expires_at > now))  # type: ignore  # SQL NULL
        for row in cur.exec(stmt.order_by(SQL('"id"'))).iter():  # in order of storing (e.g. anime entries)
            if want is None or row.service in want:
                result.setdefault(row.ref, {}).setdefault(row.service, []).append(row.value)  # type: ignore[union-attr]
    return result


@_best_effort(dict)
def refs_of(service: str, values: Iterable[str]) -> Dict[Tuple[str, str], MediaRef]:
    """Return media refs of the IDs of the service (fresh, not markers): ``{(type, value): ref}``."""
    values = {v for v in values if v}
    if not values:
        return {}
    now = _now()
    where = f'"service" = {sql_dump(service)} AND "value" IN ({",".join(sql_dump(v) for v in values)})'
    with db.cursor() as cur:
        rows = cur.exec(select(MediaIdRow).where(where).where(OR(MediaIdRow.expires_at == None, MediaIdRow.expires_at > now))).iter()  # type: ignore
        return {(row.xref.type, row.value): row.ref for row in rows}


@_best_effort(lambda: None)
def store_ids(links: Iterable[MediaIdLink], *, source: str, ttl: Optional[int] = None, replace: bool = False,
              unique: Iterable[str] = ()) -> None:
    """
    Store ID links of the source (valid `ttl` seconds, None = no deadline).

    `replace` replaces all values of the given (ref, service) - the source gives the whole set (authoritative,
    e.g. TMDB external IDs, a Fribb entry). For `unique` services (1 : 1, e.g. imdb) a value belongs to one ref of
    its type: the links of other refs with that value are removed (a corrected ID moves). A link of a non-replacing
    source is added only if the (ref, service) has no value yet (it never overrides an authoritative one).
    """
    links = [(ref, service, str(value)) for ref, service, value in links]
    if not links:
        return
    now = _now()
    unique = set(unique)
    expires = None if ttl is None else now + int(ttl)
    replaced: Set[Tuple[MediaInfoKey, str]] = set()
    with db.cursor(write=True) as cur:
        for ref, service, value in links:
            where = _ids_where([ref])
            key = f'{where} AND "service" = {sql_dump(service)}'
            existing = cur.exec(select(MediaIdRow).where(key)).all()
            if replace:
                if (rkey := (tuple(ref.xref), service)) not in replaced:  # the whole set of the call replaces the old one
                    replaced.add(rkey)  # type: ignore[arg-type]
                    cur.exec(delete(MediaIdRow).where(key))
            elif any(row.value for row in existing if row.value != value):
                continue  # the ref has another value already (maybe an authoritative one)
            else:
                cur.exec(delete(MediaIdRow).where(f'{key} AND "value" = \'\''))  # a found value replaces the marker
            if service in unique and value:
                cur.execute(f'DELETE FROM "ids" WHERE "service" = ? AND "value" = ? AND "xref::type" = ? AND NOT ({where})',
                            (service, value, ref.xref.type))
            cur.exec(insert_or_replace(MediaIdRow), MediaIdRow(xref=ref, service=service, value=value, source=source,
                                                                updated_at=now, expires_at=expires))


@_best_effort(lambda: None)
def delete_ids(refs: Iterable[MediaRef], services: Optional[Iterable[str]] = None) -> None:
    """Remove ID links of `refs` (all services or `services`), e.g. a TMDB entry removed."""
    if (where := _ids_where(refs)) is None:
        return
    if services is not None:
        where = f'{where} AND "service" IN ({",".join(sql_dump(s) for s in services)})'
    with db.cursor(write=True) as cur:
        cur.exec(delete(MediaIdRow).where(where))


@_best_effort(lambda: [])
def tmdb_refs_with_ids(ffids: Iterable[int]) -> Sequence[MediaRef]:
    """Return main refs (no season / episode) with ID links of the given TMDB-range FFIDs (the changes of TMDB)."""
    ffids = set(ffids)
    if not ffids:
        return []
    with db.cursor() as cur:
        rows = cur.exec(select(MediaIdRow).where(f'"xref::ffid" IN ({",".join(str(int(f)) for f in ffids)}) AND "xref::season" = -1')).iter()
        return list({row.ref for row in rows})


@_best_effort(dict)
def aired_of(ffids: Iterable[int]) -> Dict[int, MediaAiredRow]:
    """Return the aired episodes of the shows (by their FFIDs), expired ones too (the caller checks ``expires_at``)."""
    ffids = {int(f) for f in ffids if f}
    if not ffids:
        return {}
    with db.cursor() as cur:
        return {row.ffid: row for row in cur.exec(select(MediaAiredRow).where(f'"ffid" IN ({",".join(map(str, ffids))})')).iter()}


@_best_effort(lambda: None)
def store_aired(rows: Iterable[MediaAiredRow]) -> None:
    """Store the aired episodes of shows (a row replaces the one of its show)."""
    rows = list(rows)
    if rows:
        with db.cursor(write=True) as cur:
            for row in rows:
                cur.exec(insert_or_replace(MediaAiredRow), row)


@_best_effort(lambda: 0)
def expire(refs: Iterable[MediaRef]) -> int:
    """Mark media rows of `refs` and their subtrees (seasons, episodes), the aired episodes of shows too, expired (changed in TMDB). Return the count."""
    keys = {(ref.type, ref.ffid) for ref in refs if ref}
    if not keys:
        return 0
    values = ','.join(f'({sql_dump(t)},{int(f)})' for t, f in keys)
    with db.cursor(write=True) as cur:
        cur.execute(f'UPDATE "info" SET "expires_at" = ? WHERE ("xref::type", "xref::ffid") IN (VALUES {values})', (_now() - 1,))
        count = cur.rowcount
        if shows := {f for t, f in keys if t == 'show'}:
            cur.execute(f'UPDATE "aired" SET "expires_at" = ? WHERE "ffid" IN ({",".join(map(str, shows))})', (_now() - 1,))
        return count


@_best_effort(int)
def cleanup() -> int:
    """Remove rows expired more than ``const.media.cache.cleanup_grace`` ago (run by the service). Return the count.

    The grace keeps expired rows for a while: `known_ids()` reads them with no freshness filter (a cheap id seed).
    """
    grace = const.media.cache.cleanup_grace
    return delete_expired(db, MediaInfoRow, grace=grace) + delete_expired(db, MediaIdRow) + delete_expired(db, MediaAiredRow, grace=grace)


@_best_effort(lambda: None)
def clear() -> None:
    """Remove all cached media info, aired episodes and "nothing found" markers (the ID links stay: they are a mapping, not a cache)."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(MediaInfoRow))
        cur.exec(delete(MediaAiredRow))
        cur.exec(delete(MediaIdRow).where('"value" = \'\''))


@_best_effort(lambda: None)
def invalidate(refs: Optional[Iterable[MediaRef]] = None, *, older_than: Optional[int] = None) -> None:
    """Invalidate rows by `refs` and/or by age (`older_than`, a unix timestamp).

    :param refs: references to drop; None means "do not select by ref".
    :param older_than: drop rows whose ``updated_at`` is older than this timestamp.
    """
    with db.cursor(write=True) as cur:
        if refs is not None and (where := _multikey_where(_normalized_keys(refs))):
            cur.exec(delete(MediaInfoRow).where(where))
        if older_than is not None:
            cur.exec(delete(MediaInfoRow).where(MediaInfoRow.updated_at < older_than))  # type: ignore  # NULL excluded


# --- DB schema / migration ------------------------------------------------------------------------

def on_update(cur: DbCursor) -> None:
    """Migrate older DB. Before v3 the media cache is disposable, so the old ``info`` table is dropped and
    recreated with the new schema + indexes (it rebuilds itself from TMDB). The old ref-list tables
    (``ref_list``, ``ref_list_items``, never used) are dropped. v4 adds the ``ids`` table only, v5 the ``aired`` table
    only (created by ``create_tables``), the ``info`` rows stay."""
    if (db.old_version or 0) >= 3:
        return
    cur.execute('DROP TABLE IF EXISTS info')
    cur.execute('DROP TABLE IF EXISTS ref_list_items')
    cur.execute('DROP TABLE IF EXISTS ref_list')
    cur.create_tables(MediaInfoRow)   # recreates `info` and its __table_indexes__


#: Global media cache DB.
db = OrmDatabase('media', MediaInfoRow, MediaIdRow, MediaAiredRow, version=DB_VERSION, on_update=on_update)


if __name__ == '__main__':
    # CLI for operate on media DB. Do NOT remove.
    from ..cmdline import DebugArgumentParser

    p = DebugArgumentParser(dest='op', description='Media DB CLI')
    p.add_argument('--database', '-d', default=':memory:', help='Database file (default: in-memory)')
    args = p.parse_args()

    db = OrmDatabase(args.database, MediaInfoRow, version=DB_VERSION, on_update=on_update)
