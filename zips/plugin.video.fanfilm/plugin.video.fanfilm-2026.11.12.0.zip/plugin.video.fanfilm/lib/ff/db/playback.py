
# from contextlib import closing
from contextlib import contextmanager
from datetime import datetime, date as dt_date
from typing import Optional, Union, Tuple, Dict, Set, Sequence, Iterable, Iterator, TypeVar, Callable
from typing_extensions import Self, TypeAlias, Literal
from attrs import frozen

from .db import db_manager, Lock, sql_dump, update_db_version, DbCursor, PrimaryKey, SQL
from .orm import OrmDatabase, DbTable, Expr, field as db_field, select, update, update_or_ignore, delete, AND, OR, IS, MISSING
from ...defs import MediaType, MainMediaType, MediaRef, XMediaRef, MediaProgressItem, MediaProgress
from ..tricks import MissingType
from ..item import FFItem
from ..calendar import utc_timestamp, utc_from_timestamp, from_timestamp, datestamp as make_datestamp
from ..logs import fflog
from ..debug.timing import logtime  # DEBUG
# to avoid collision with "def set()"
# TODO: reanme function
from builtins import set as _set
from const import const


T = TypeVar('T')

#: Playback DB version (5: rows of accounts, built anew; 6: times of the removals; 7: the changes waiting for the delivery;
#: 8: their first failed delivery; 9: their time in the queue - see `lib/sql/migrate/playback.<n>.sql`).
DB_VERSION: int = 9

#: A change of the rows of an account sent to its service (`record_change()`; `pause` - a resume point with its progress).
ChangeAction: TypeAlias = Literal['watched', 'unwatched', 'reset_progress', 'pause']


@frozen(kw_only=True)
class PlayState:
    """
    The state of a playback row that is seen (folders, widgets, the library alignment, the merge of accounts): an account
    sync whose rows keep it (`same()`) changed nothing - e.g. the time of a watch rounded by the service, a resume point
    with the playback ID of the service; the IDs, slugs and the air dates are not in it.
    """

    #: Watched (any play count: FanFilm shows watched or not, the alignment sets Kodi watched or not).
    watched: bool = False
    #: The resume point in percent (0: none).
    progress: float = 0
    #: Media duration in seconds.
    duration: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) of the last watch.
    last_watched_at: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) of the pause.
    paused_at: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) of the unwatch (the merge of accounts: the newest event wins).
    unwatched_at: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) of the removal of the resume point.
    unpaused_at: Optional[int] = None

    def same(self, other: 'PlayState') -> bool:
        """Return True if the other state is the same (`const.media.progress.tolerance`: the resume point, the times)."""

        def same_time(a: Optional[int], b: Optional[int]) -> bool:
            if a is None or b is None:
                return a is b
            return abs(a - b) <= tolerance.time

        tolerance = const.media.progress.tolerance
        return (self.watched == other.watched and self.duration == other.duration
                and abs(self.progress - other.progress) <= tolerance.resume
                and same_time(self.last_watched_at, other.last_watched_at) and same_time(self.paused_at, other.paused_at)
                and same_time(self.unwatched_at, other.unwatched_at) and same_time(self.unpaused_at, other.unpaused_at))


class MediaPlayInfo(DbTable):
    """Playback row (progress, watched) of a movie or an episode of an account."""

    __tablename__ = 'scrobble_playback'
    # the account is the last: a query by the media uses the index
    __table_args__ = ('UNIQUE("xref::type", "xref::ffid", "xref::season", "xref::episode", "account_id")',)
    # the denormalized ref (e.g. an episode FFID)
    __table_indexes__ = ('ffid',)

    #: Playback database ID.
    id: PrimaryKey = None
    #: Media reference (with -1 in season and episode instead of None).
    xref: XMediaRef = MISSING
    #: Denormalized media FFID (e.g. episode FFID for show episodes).
    ffid: int = 0
    #: The Movie Database ID.
    tmdb: Optional[int] = None
    #: Internet Movie Database ID.
    imdb: Optional[str] = None
    #: Trakt.tv ID.
    trakt: Optional[int] = None
    #: TheTVDB ID.
    tvdb: Optional[int] = None
    #: Media Trakt.tv slug.
    slug: Optional[str] = None
    #: TV show Trakt.tv slug.
    tv_slug: Optional[str] = None
    #: Account ID (see `lib.ff.accounts`).
    account_id: str = ''
    #: Level of details stored in the playback info.
    details_level: int = 0
    #: Playback unique ID (from scrobble service).
    playback_id: Optional[int] = None
    #: Episode progress in percent. If media is watched, progress is None.
    progress: Optional[float] = None
    #: Timestamp (UTC unixtime seconds) where playback was paused.
    paused_at: Optional[int] = None
    #: Number of times the media was played (watched).
    play_count: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) when the media was last watched.
    last_watched_at: Optional[int] = None
    #: Media duration in seconds.
    duration: Optional[int] = None
    #: Date stamp (number of days from 1 Jan AD 1) when the media was aired (released).
    aired_at: Optional[int] = None
    #: Date stamp (number of days from 1 Jan AD 1) when the next episode will be aired.
    next_aired_at: Optional[int] = None  # use only in tv-show or season
    #: Metadata last updated timestamp (UTC unixtime seconds).
    meta_updated_at: Optional[int] = db_field(default=MISSING)  # no DDL default (the migration baseline), set by __init__
    #: Timestamp (UTC unixtime seconds) when the media was unwatched (gone from the watched list of the account, or sent).
    unwatched_at: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) when the resume point was removed (gone from the account, or sent).
    unpaused_at: Optional[int] = None

    # cache for MediaRef
    _ref: Optional[MediaRef] = None

    def __init__(self, *, id: PrimaryKey = None, ref: MediaRef = MISSING, xref: Union[XMediaRef, MissingType] = MISSING, ffid: int = 0,
                 tmdb: Optional[int] = None, imdb: Optional[str] = None, trakt: Optional[int] = None, tvdb: Optional[int] = None,
                 slug: Optional[str] = None, tv_slug: Optional[str] = None, account_id: str = '',
                 details_level: Optional[int] = None, playback_id: Optional[int] = None,
                 progress: Optional[float] = None, paused_at: Optional[int] = None,
                 play_count: Optional[int] = None, last_watched_at: Optional[int] = None, duration: Optional[int] = None,
                 aired_at: Optional[int] = None, next_aired_at: Optional[int] = None, meta_updated_at: Optional[int] = None,
                 unwatched_at: Optional[int] = None, unpaused_at: Optional[int] = None) -> None:

        def timestamp(val):
            if not val:
                return None
            if isinstance(val, str):
                val = utc_timestamp(val)
            return int(val)

        def datestamp(val):
            if not val:
                return None
            return make_datestamp(val)

        _xref, _ref = xref, ref
        if xref is MISSING:
            xref = ref  # type: ignore  (hack)
        elif ref is not MISSING:
            raise ValueError('cannot specify both `ref` and `xref`')
        if xref is MISSING:
            raise ValueError('have to specify one of `ref` or `xref`')

        if details_level is None:
            details_level = 1  # default details level (degraded)

        self.id               = id                               # noqa: E221
        self.xref             = xref.sql_ref                     # noqa: E221  # type: ignore  (hack, XMediaRef = MediaRef)
        self.ffid             = int(ffid or 0)                   # noqa: E221
        self.tmdb             = int(tmdb or 0) or None           # noqa: E221
        self.imdb             = imdb                             # noqa: E221
        self.trakt            = int(trakt or 0) or None          # noqa: E221
        self.tvdb             = tvdb                             # noqa: E221
        self.slug             = slug                             # noqa: E221
        self.tv_slug          = tv_slug                          # noqa: E221
        self.account_id       = account_id                       # noqa: E221
        self.details_level    = int(details_level or 0)          # noqa: E221
        self.playback_id      = int(playback_id or 0) or None    # noqa: E221
        self.progress         = None if progress is None else float(progress)  # noqa: E221
        self.paused_at        = timestamp(paused_at)             # noqa: E221
        self.play_count       = None if play_count is None else int(play_count)     # noqa: E221
        self.last_watched_at  = timestamp(last_watched_at)       # noqa: E221
        self.duration         = int(duration or 0) or None       # noqa: E221
        self.aired_at         = datestamp(aired_at)              # noqa: E221
        self.next_aired_at    = datestamp(next_aired_at)         # noqa: E221
        self.meta_updated_at  = timestamp(meta_updated_at)       # noqa: E221
        self.unwatched_at     = timestamp(unwatched_at)          # noqa: E221
        self.unpaused_at      = timestamp(unpaused_at)           # noqa: E221
        self._ref = None

        # if self.xref.type not in get_typing_args(MediaType):
        #     allowed = ', '.join(get_typing_args(MediaType))
        #     raise ValueError(f'MediaPlayInfo: incorrect type {type!r}, should be one of: {allowed}')

    @property
    def has_progress(self) -> bool:
        return self.progress is not None and 0 < self.progress < 100

    @property
    def has_play_count(self) -> bool:
        return self.play_count is not None

    @property
    def ref(self) -> MediaRef:
        """Return media reference."""
        if self._ref is None:
            self._ref = MediaRef.from_sql_ref(self.xref)
        return self._ref

    @ref.setter
    def ref(self, ref: MediaRef) -> None:
        self._ref = ref
        self.xref = ref.sql_ref  # type: ignore  (hack)

    @property
    def denormalized_ref(self) -> Optional[MediaRef]:
        """Return denormalized reference (eg. episode)."""
        # vid = VideoIds(tmdb=self.tmdb, imdb=self.imdb, tvdb=self.tvdb)
        if self.ffid:
            return MediaRef(self.ref.real_type, self.ffid)
        return None

    def refs(self) -> Iterator[MediaRef]:
        """Iterate over refs (normalized and denormalized)."""
        yield self.ref
        if self.ffid and (de_ref := MediaRef(self.ref.real_type, self.ffid)) and de_ref != self._ref:
            yield de_ref

    def as_item(self) -> FFItem:
        """Return pb as (simplified) FFItem."""
        item = FFItem(self.ref)
        if time := max(self.paused_at or 0, self.last_watched_at or 0):
            item.vtag.setLastPlayed(from_timestamp(time))  # Kodi keeps the local time
        return item

    def as_media_progress_item(self, *, no_progress: bool = False) -> MediaProgressItem:
        """Return MediaProgressItem."""
        if self.last_watched_at and (self.play_count or not no_progress):
            last_watched_at = utc_from_timestamp(self.last_watched_at)
        else:
            last_watched_at = datetime.min
        if no_progress:
            return MediaProgressItem(self.ref, progress=0, play_count=self.play_count or 0, last_watched_at=last_watched_at)
        return MediaProgressItem(self.ref, progress=self.progress or 0, play_count=self.play_count or 0, last_watched_at=last_watched_at)

    def as_media_progress(self) -> MediaProgress:
        """Return progress of the movie or episode (shows and seasons: `lib.ff.progress.show_progress()`)."""
        if self.last_watched_at:
            last_watched_at = utc_from_timestamp(self.last_watched_at)
        else:
            last_watched_at = datetime.min
        return MediaProgress(self.ref, progress=self.progress or 0, play_count=self.play_count or 0, last_watched_at=last_watched_at)

    def update_playback(self, pb: 'MediaPlayInfo') -> Self:
        """Update playback (progress) from another MediaPlayInfo."""
        if pb and pb is not self:
            self.progress = pb.progress
            self.playback_id = pb.playback_id
            self.paused_at = pb.paused_at
            self.unpaused_at = max(self.unpaused_at or 0, pb.unpaused_at or 0) or None
        return self

    def update_removals(self, pb: 'MediaPlayInfo') -> Self:
        """Take the newer removal times of another MediaPlayInfo (the times only grow)."""
        self.unwatched_at = max(self.unwatched_at or 0, pb.unwatched_at or 0) or None
        self.unpaused_at = max(self.unpaused_at or 0, pb.unpaused_at or 0) or None
        return self

    def update_by_ffitem(self, item: Optional[FFItem], *, now: Optional[Union[dt_date, str, int]] = None) -> None:

        def int_or_none(v):
            return int(v) if v else None

        def timestamp(val):
            if not val:
                return None
            return int(utc_timestamp(val))

        def datestamp(val):
            if not val:
                return None
            return make_datestamp(val)

        if item is None:
            return

        vtag = item.vtag
        ids = vtag.getUniqueIDs()

        if (tmdb := int_or_none(ids.get('tmdb'))):
            self.tmdb = tmdb
        if (imdb := ids.get('imdb')):
            self.imdb = imdb
        if (trakt := int_or_none(ids.get('trakt'))):
            self.trakt = trakt
        if (tvdb := int_or_none(ids.get('tvdb'))):
            self.tvdb = tvdb
        if (slug := ids.get('slug')):
            self.slug = slug
        if (duration := int_or_none(vtag.getDuration())):
            self.duration = duration
        if (aired_at := datestamp(item.date)):
            self.aired_at = aired_at
        if now:
            self.meta_updated_at = timestamp(now)

    def play_state(self) -> PlayState:
        """Return the state of the row that is seen (see `PlayState`)."""
        return PlayState(watched=bool(self.play_count), progress=self.progress or 0, duration=self.duration,
                         last_watched_at=self.last_watched_at, paused_at=self.paused_at,
                         unwatched_at=self.unwatched_at, unpaused_at=self.unpaused_at)

    def clear_progress(self, *, progress: Optional[float] = None) -> None:
        """Clears progress."""
        self.playback_id = None
        self.progress = progress
        self.paused_at = None

    @classmethod
    def from_ffitem(cls, item: FFItem, *, now: Optional[Union[dt_date, str, int]] = None) -> Self:

        def int_or_none(v):
            return int(v) if v else None

        def timestamp(val):
            if not val:
                return None
            return int(utc_timestamp(val))

        def datestamp(val):
            if not val:
                return None
            return make_datestamp(val)

        vtag = item.vtag
        ids = vtag.getUniqueIDs()

        return cls(ref=item.ref,
                   ffid=item.ffid or 0,
                   tmdb=int_or_none(ids.get('tmdb')),
                   imdb=ids.get('imdb'),
                   trakt=int_or_none(ids.get('trakt')),
                   tvdb=int_or_none(ids.get('tvdb')),
                   slug=ids.get('slug'),
                   duration=int_or_none(vtag.getDuration()),
                   aired_at=datestamp(item.date),
                   meta_updated_at=timestamp(now),
                   )


MediaPlayInfoDict: TypeAlias = Dict[MediaRef, MediaPlayInfo]


class PendingChange(DbTable):
    """A change of the account rows not delivered to its service yet: the last one of the media (`record_change()`)."""

    __tablename__ = 'pending_change'
    __table_args__ = ('UNIQUE("xref::type", "xref::ffid", "xref::season", "xref::episode", "account_id")',)

    #: Pending change ID.
    id: PrimaryKey = None
    #: Media reference (a movie, an episode; a show or a season - all its episodes).
    xref: XMediaRef = MISSING
    #: Account ID (see `lib.ff.accounts`).
    account_id: str = ''
    #: The change (`ChangeAction`).
    action: str = ''
    #: The resume point in percent: `pause` - the one it sets; `watched` / `unwatched` / `reset_progress` - the one it ends on
    #: the service (none: nothing to remove there).
    progress: Optional[float] = None
    #: Timestamp (UTC unixtime seconds) of the change (FF, Kodi, the player).
    at: int = 0
    #: Failed deliveries (no connection, a server error).
    tries: int = 0
    #: Timestamp (UTC unixtime seconds) of its first failed delivery, None if it has not failed (see `const.accounts.pending.max_retry`).
    failed_at: Optional[int] = None
    #: Timestamp (UTC unixtime seconds) it was queued: its wait is limited (`const.accounts.pending.max_age`), not the age of
    #: the change (`at`, e.g. a watch found in Kodi long after it).
    queued_at: int = 0

    @property
    def ref(self) -> MediaRef:
        """Get media reference."""
        return MediaRef.from_sql_ref(self.xref)

    def covers(self, ref: MediaRef) -> bool:
        """Return True if the change is of the media `ref` (itself, or an episode of the show / season of the change)."""
        return self.ref.covers(ref)

    @property
    def capability(self) -> str:
        """Return the capability of the change (`watched` or `progress`)."""
        return 'progress' if self.action in ('pause', 'reset_progress') else 'watched'

    @property
    def ends_playback(self) -> bool:
        """
        Return True if the delivery of the change removes the resume point on the service: a movie / an episode watched,
        unwatched or reset with a resume point to end (`progress`: the end of a play, Kodi, the row of the account).
        """
        return not self.ref.is_container and self.action != 'pause' and bool(self.progress)

    @property
    def bucket(self) -> str:
        """Return the sync bucket of the change (`lib.ff.sync`), its cursor is reset when the change is lost."""
        return f'{self.capability}.{"movie" if self.ref.is_movie else "episode"}'

    def delivery_refs(self) -> Sequence[MediaRef]:
        """
        Return the media the delivery of the change sends: the media of the change; a show / a season watched - the episodes
        it set watched (the rows of the account with its time, `record_change()`), itself if the account had no other
        watched episodes of it (the service knows the aired ones), none if it had them all (nothing to send).
        """
        ref = self.ref
        if self.action != 'watched' or not ref.is_container:
            return (ref,)
        watched = [pb for pb in get_playback_rows([ref], accounts=[self.account_id]) if pb.play_count]
        written = [pb.ref for pb in watched if pb.last_watched_at == self.at]
        return (ref,) if len(written) == len(watched) else written


def on_build(cur: DbCursor) -> None:
    """The DB is built anew (a new file, v5 rows of accounts): forget the sync cursors of accounts, the next sync is a full one."""
    from .accounts import reset_sync
    reset_sync()


def on_update(cur: DbCursor) -> None:
    """Migrate an older DB: before v7 the rows of accounts changed (a full sync, `on_build()`); v8, v9 add columns of the waiting changes only."""
    if (db.old_version or 0) < 7:
        on_build(cur)


#: Global playback DB.
db = OrmDatabase('playback', MediaPlayInfo, PendingChange, version=DB_VERSION, on_create=on_build, on_update=on_update)


#: WHERE IN VALUES (type, main_ffid, season, episode)
MediaInfoWhereValue = Union[Tuple[str, int, int, int], Tuple[str, int, int], Tuple[str, int]]


def get_playback_rows(refs: Optional[Iterable[MediaRef]], *, accounts: Iterable[str]) -> Sequence[MediaPlayInfo]:
    """
    Return rows of the accounts for the media: a movie or an episode - its rows, a show (or a season) - rows of all its
    episodes (of the season); `refs` None - all rows of the accounts.
    """
    def make_where(ref: MediaRef) -> MediaInfoWhereValue:
        if ref.type == 'show':
            if ref.season is None:
                return ref.type, ref.ffid
            if ref.episode is None:  # season 0 (specials) is a season too
                return ref.type, ref.ffid, ref.season
            return ref.type, ref.ffid, ref.season, ref.episode
        return ref.type, ref.ffid, -1, -1  # movies and anything else

    accounts = tuple(accounts)
    where = f'"account_id" IN ({",".join(sql_dump(acc) for acc in accounts)})'
    if refs is not None:
        keys: Set[MediaInfoWhereValue] = {make_where(ref) for ref in refs}
        if not keys:
            return ()
        names = ('"xref::type"', '"xref::ffid"', '"xref::season"', '"xref::episode"')
        wheres = (f'({",".join(names[:size])}) IN (VALUES {values})' for size in (4, 3, 2)
                  if (values := ','.join(f'({",".join(sql_dump(x) for x in key)})' for key in keys if len(key) == size)))
        where = f'({" OR ".join(wheres)}) AND {where}'
    if not accounts:
        return ()
    with db.cursor() as cur:
        return cur.exec(select(MediaPlayInfo).where(where)).all()


class PlayedEpisode:
    """
    A light row of a played episode (no ORM object: the list of all played shows reads thousands): the fields of
    `MediaPlayInfo` the merge of accounts reads (`lib.ff.progress`), the episode by its show FFID, season and number.
    """

    __slots__ = ('account_id', 'ffid', 'season', 'episode', 'play_count', 'last_watched_at', 'unwatched_at', 'progress', 'paused_at',
                 'unpaused_at')

    def __init__(self, account_id: str, ffid: int, season: int, episode: int, play_count: Optional[int] = None,
                 last_watched_at: Optional[int] = None, unwatched_at: Optional[int] = None, progress: Optional[float] = None,
                 paused_at: Optional[int] = None, unpaused_at: Optional[int] = None) -> None:
        self.account_id: str = account_id
        self.ffid: int = ffid
        self.season: int = season
        self.episode: int = episode
        self.play_count: Optional[int] = play_count
        self.last_watched_at: Optional[int] = last_watched_at
        self.unwatched_at: Optional[int] = unwatched_at
        self.progress: Optional[float] = progress
        self.paused_at: Optional[int] = paused_at
        self.unpaused_at: Optional[int] = unpaused_at

    @classmethod
    def from_row(cls, pb: MediaPlayInfo) -> 'PlayedEpisode':
        """The light row of an episode row."""
        ref = pb.ref
        return cls(pb.account_id, ref.ffid, ref.season or 0, ref.episode or 0, pb.play_count, pb.last_watched_at, pb.unwatched_at,
                   pb.progress, pb.paused_at, pb.unpaused_at)

    @property
    def key(self) -> Tuple[int, int, int]:
        """The episode: (show FFID, season, episode)."""
        return self.ffid, self.season, self.episode

    def clear_progress(self, *, progress: Optional[float] = None) -> None:
        """Clear the resume point (as `MediaPlayInfo.clear_progress()`)."""
        self.progress = progress
        self.paused_at = None

    def __repr__(self) -> str:
        return f'PlayedEpisode({", ".join(repr(getattr(self, name)) for name in self.__slots__)})'


def get_played_episodes(accounts: Iterable[str]) -> Sequence[PlayedEpisode]:
    """Return light rows of the watched, started or removed episodes of the accounts (no specials), without row objects."""
    accounts = tuple(accounts)
    if not accounts:
        return ()
    sql = ('SELECT "account_id", "xref::ffid", "xref::season", "xref::episode", "play_count", "last_watched_at", "unwatched_at",'
           ' "progress", "paused_at", "unpaused_at"'
           ' FROM "scrobble_playback" WHERE "xref::type" = \'show\' AND "xref::season" > 0 AND "xref::episode" > 0'
           ' AND ("play_count" > 0 OR "progress" > 0 OR "unwatched_at" > 0 OR "unpaused_at" > 0)'
           f' AND "account_id" IN ({",".join(sql_dump(acc) for acc in accounts)})')
    with db.cursor() as cur:
        cur.orm = False  # tuple rows
        return [PlayedEpisode(*row) for row in cur.execute(sql).fetchall()]


@logtime
def _get_playback(cur: DbCursor, type: Optional[MediaType] = None, *, account_id: Optional[str] = None, in_progress: Optional[bool] = None,
                  sort: bool = False, ffids: Optional[Iterable[int]] = None, resumes: bool = False) -> Sequence[MediaPlayInfo]:
    """
    Get playback rows (of the account, if given). If `ffids` is set, get only videos (and episodes of shows) with given ffid,
    with `resumes` also the rows with a resume point (a progress or a playback ID of the service).
    """
    query = select(MediaPlayInfo)
    if account_id is not None:
        query = query.where(MediaPlayInfo.account_id == account_id)
    if ffids is not None:
        # the FFIDs in the SQL text (numbers), not as parameters: SQLite before 3.32 takes at most 999 parameters
        where = f'"xref::ffid" IN ({",".join(str(int(ffid)) for ffid in ffids)})'
        query = query.where(OR(where, MediaPlayInfo.progress != 0, MediaPlayInfo.playback_id != 0) if resumes else where)
    if type == 'episode':
        query = query.where(AND(MediaPlayInfo.xref.type == 'show', MediaPlayInfo.xref.season != -1, MediaPlayInfo.xref.episode != -1))
    elif type:
        query = query.where(MediaPlayInfo.xref.type == type)
    if in_progress is True:
        # "where" could be used many times: select().where(A).where(B) means select.where(AND(A, B))
        query = query.where(AND(MediaPlayInfo.progress > 0, MediaPlayInfo.progress < 100))  # type: ignore  # SQL column with NULL could be compared to number
    elif in_progress is False:
        # MediaPlayInfo.progress == None is indeted to build SQL WHERE statment
        query = query.where(OR(MediaPlayInfo.progress == None, MediaPlayInfo.progress <= 0, MediaPlayInfo.progress >= 100))  # type: ignore  # SQL column with NULL could be compared to number
    if sort:
        query = query.order_by(SQL('MAX(IFNULL(paused_at,0), IFNULL(last_watched_at, 0)) DESC'))
    return cur.exec(query).all()


def get_playback(type: Optional[MediaType] = None, *, account_id: Optional[str] = None, in_progress: Optional[bool] = None,
                 sort: bool = False) -> Sequence[MediaPlayInfo]:
    """Get all playback rows (of the account, if given)."""
    with db.cursor() as cur:
        return _get_playback(cur, type, account_id=account_id, in_progress=in_progress, sort=sort)


def get_playback_item(ref: MediaRef, *, account_id: str) -> Optional[MediaPlayInfo]:
    """Get the playback row of the media of the account."""
    with db.cursor() as cur:
        if ref.is_normalized:
            query = select(MediaPlayInfo).where(MediaPlayInfo.xref == ref.sql_ref)
        elif ref.type == 'episode':
            query = select(MediaPlayInfo).where(AND(MediaPlayInfo.xref.type == 'show', MediaPlayInfo.xref.season != -1, MediaPlayInfo.xref.episode != -1, MediaPlayInfo.ffid == ref.ffid))
        else:
            raise ValueError(f'Unsupported denormalized ref {ref}')
        return cur.exec(query.where(MediaPlayInfo.account_id == account_id)).first()


def _store_row(cur: DbCursor, media: MediaPlayInfo, before: PlayState) -> bool:
    """Store the row of the account (as its service has it); return True if its seen state changed (`PlayState`)."""
    cur.add(media)
    return not media.play_state().same(before)


def _pending_guard(cur: DbCursor, account_id: str, new: Sequence[MediaPlayInfo], *, progress: bool) -> 'Callable[[MediaRef], bool]':
    """
    Resolve the waiting changes of the account against its full list of a bucket (`new`; the watched or, with `progress`,
    the resume points): a change older than an event of the service for its media is cancelled (the service wins, newest
    event wins); return the guard of the media of the changes still waiting - their rows stay local.
    """
    if progress:
        # the resume points: a waiting change which sets or removes it keeps the row (the service has it after the delivery)
        cancel = ('pause', 'reset_progress')
        keep: Callable[[PendingChange], bool] = lambda change: change.action == 'pause' or change.ends_playback  # noqa: E731
        when = lambda pb: pb.paused_at or 0  # noqa: E731
    else:
        cancel = ('unwatched', 'pause')
        keep = lambda change: change.action in ('watched', 'unwatched')  # noqa: E731
        when = lambda pb: pb.last_watched_at or 0  # noqa: E731
    waiting: list[PendingChange] = []
    for change in cur.exec(select(PendingChange).where(PendingChange.account_id == account_id)).all():
        if change.action in cancel and any(when(pb) > change.at for pb in new if change.covers(pb.ref)):
            fflog(f'[SYNC] {account_id}: {change.action} {change.ref:a} cancelled, the service has a newer event')
            cur.exec(delete(PendingChange).where(PendingChange.id == change.id))
        elif keep(change):
            waiting.append(change)
    return lambda ref: any(change.covers(ref) for change in waiting)


def update_track_playback(new: Iterable[MediaPlayInfo], *, account_id: str, media_type: Optional[MainMediaType] = None,
                          removed_at: Optional[int] = None) -> bool:
    """
    Update resume points of the account by its full playback list (of the media type, if given): missing ones are
    removed (at `removed_at`, default now). The media of a waiting change keep their rows (`_pending_guard()`). Return True
    on any change seen (`PlayState`).
    """
    new = list(new)
    changed = False
    with db.cursor(write=True) as cur:
        waiting = _pending_guard(cur, account_id, new, progress=True)
        # only the rows these lists can change: of the media of `new` and the ones with a resume point (not all watched ones)
        ffids = {pb.ref.ffid for pb in new}
        old = {m.ref: m for m in _get_playback(cur, media_type, account_id=account_id, ffids=ffids, resumes=True)}
        refs: Set[MediaRef] = _set()
        for pb in new:
            refs.add(pb.ref)
            if waiting(pb.ref):
                continue
            if (media := old.get(pb.ref)) is None:
                before = PlayState()
                media = pb
                media.account_id = account_id
            else:
                before = media.play_state()
                media.update_playback(pb)
            changed |= _store_row(cur, media, before)
        removed_at = removed_at or int(utc_timestamp())
        for ref in old.keys() - refs:
            media = old[ref]
            if (media.progress or media.playback_id) and not waiting(ref):
                before = media.play_state()
                media.clear_progress()
                media.unpaused_at = removed_at
                changed |= _store_row(cur, media, before)
    return changed


def _container_episodes(new: Sequence[MediaPlayInfo], *, account_id: str, episodes: Sequence[MediaRef] = ()) -> Sequence[MediaPlayInfo]:
    """
    Return rows of episodes of a show or season (single one, from the menu): its `episodes` (the aired ones, given by the
    caller, see `ffinfo.aired_episode_refs()`), unwatched - also its rows of the account (e.g. not aired any more). Watched
    sets the episodes not watched on the account (one play), the watched ones keep their plays and time (as Kodi and the
    services do). An unwatched episode of another account or Kodi gets the removal time too.
    """
    if len(new) > 1:
        fflog(f'WARNING, _update_track_watched() supports only single show or season not {len(new)}')
        return ()
    one = new[0]
    ref = one.ref
    rows_of: dict[MediaRef, MediaPlayInfo] = {ep: MediaPlayInfo(ref=ep) for ep in episodes}
    account_rows = {pb.ref: pb for pb in get_playback_rows([ref], accounts=[account_id])}
    if not one.play_count:
        for pb in account_rows.values():
            rows_of.setdefault(pb.ref, pb)
    rows = []
    for ep in rows_of.values():
        if one.play_count:
            if (pb := account_rows.get(ep.ref)) is not None and pb.play_count:
                continue
            ep.play_count = 1
        else:
            ep.play_count = 0
        ep.last_watched_at = one.last_watched_at
        ep.clear_progress()
        ep.update_removals(one)
        rows.append(ep)
    return rows


@logtime
def _update_track_watched(new: Sequence[MediaPlayInfo],
                          *,
                          media_type: Optional[MainMediaType],
                          account_id: str,
                          mark_missing: bool = True,
                          episodes: Sequence[MediaRef] = (),
                          removed_at: Optional[int] = None,
                          ) -> bool:
    """
    Update watched rows of the account (movies, episodes; a show or season - its episodes). With `mark_missing` the `new`
    is the full watched list of the account: missing rows are unwatched (at `removed_at`, default now; the resume points
    are kept), the media of a waiting change keep their rows (`_pending_guard()`). Return True on any change seen
    (`PlayState`).
    """
    if any(m.ref.is_container for m in new):
        if not (new := _container_episodes(new, account_id=account_id, episodes=episodes)):
            return False  # no episodes of the containers (e.g. no info), nothing is unwatched
    elif not new and not mark_missing:
        return False  # an empty full list unwatches all rows of the account (e.g. its last watched item is removed)

    changed = False
    with db.cursor(write=True) as cur:
        # a full list (the sync) leaves the media of the waiting changes, a single item is a local event itself
        waiting = _pending_guard(cur, account_id, new, progress=False) if mark_missing else (lambda ref: False)
        # a single media (a local event, e.g. one of a series of the library alignment) needs only its row by its key, the
        # episodes of a show / season the rows of the show, a full list the whole table
        if not mark_missing and len(new) == 1 and (ref := new[0].ref).is_normalized:
            rows = cur.exec(select(MediaPlayInfo).where(AND(MediaPlayInfo.xref == ref.sql_ref, MediaPlayInfo.account_id == account_id))).all()
        else:
            rows = _get_playback(cur, media_type, account_id=account_id, ffids=None if mark_missing else {pb.ref.ffid for pb in new})
        old = {m.ref: m for m in rows}
        for pb in new:
            if pb.ref.real_type not in ('movie', 'episode') or waiting(pb.ref):
                continue
            if (media := old.get(pb.ref)) is None:
                before = PlayState()
                media = pb
                media.account_id = account_id
            else:
                before = media.play_state()
                media.play_count = pb.play_count
                media.last_watched_at = pb.last_watched_at
                media.update_removals(pb)
                if not mark_missing:  # a single item (a local event) sets its resume point too, a watched list does not
                    media.update_playback(pb)
            changed |= _store_row(cur, media, before)

        # missing (removed, play_count set to zero, the time of the removal: the bucket cursor or now)
        if mark_missing:
            removed_at = removed_at or int(utc_timestamp())
            for ref in old.keys() - {m.ref for m in new}:
                media = old[ref]
                if media.play_count and not waiting(ref):
                    before = media.play_state()
                    media.play_count = 0
                    media.last_watched_at = None
                    media.unwatched_at = removed_at
                    changed |= _store_row(cur, media, before)

    return changed


def update_track_watched_movies(new: Sequence[MediaPlayInfo], *, account_id: str, removed_at: Optional[int] = None) -> bool:
    """Update watched movies of the account by its full watched list (the gone ones unwatched at `removed_at`)."""
    return _update_track_watched(new, media_type='movie', account_id=account_id, removed_at=removed_at)


def update_track_watched_episodes(new: Sequence[MediaPlayInfo], *, account_id: str, removed_at: Optional[int] = None) -> bool:
    """Update watched episodes of the account by its full watched list (the gone ones unwatched at `removed_at`)."""
    return _update_track_watched(new, media_type='show', account_id=account_id, removed_at=removed_at)


def update_track_watched_item(new: MediaPlayInfo, *, account_id: str, episodes: Sequence[MediaRef] = ()) -> bool:
    """Update single playback & watched row of the account by its data (a show / season: its `episodes`)."""
    ref = new.ref
    if ref.type in ('movie', 'show'):
        return _update_track_watched([new], media_type=ref.type, account_id=account_id, mark_missing=False, episodes=episodes)
    return False


def set_track_watched_item(ref: MediaRef, *, account_id: str, timestamp: Optional[Union[datetime, float]] = None,
                           episodes: Sequence[MediaRef] = ()) -> bool:
    """
    Set the media of the account as watched: one more play, as the services count a watch of a watched media (Trakt,
    WeTrakr; MDBList keeps its count, set back by the next sync); a show or a season: its `episodes` (the aired ones) not
    watched yet (`_container_episodes()`).
    """
    new = get_playback_item(ref, account_id=account_id) or MediaPlayInfo(ref=ref)
    new.clear_progress()
    new.play_count = (new.play_count or 0) + 1
    new.last_watched_at = int(utc_timestamp(timestamp))
    return update_track_watched_item(new, account_id=account_id, episodes=episodes)


def unset_track_watched_item(ref: MediaRef, *, account_id: str, timestamp: Optional[Union[datetime, float]] = None,
                             episodes: Sequence[MediaRef] = ()) -> bool:
    """Set the media of the account as unwatched (at `timestamp`, default now; a show or a season: its `episodes`)."""
    new = get_playback_item(ref, account_id=account_id) or MediaPlayInfo(ref=ref)
    new.clear_progress(progress=0)
    new.play_count = 0
    new.last_watched_at = None
    new.unwatched_at = new.unpaused_at = int(utc_timestamp(timestamp))
    return update_track_watched_item(new, account_id=account_id, episodes=episodes)


def apply_change(action: str, ref: MediaRef, *, account_id: str, at: Optional[float] = None, progress: Optional[float] = None,
                 episodes: Sequence[MediaRef] = ()) -> bool:
    """
    Apply a change (`ChangeAction`, at `at` - default now; `pause` with its `progress`) to the rows of the account: shown at
    once, sent by `record_change()`; a show / season: its `episodes` (the caller knows them, `ffinfo.aired_episode_refs()`).
    Return True on any change.
    """
    if action == 'watched':
        return set_track_watched_item(ref, account_id=account_id, timestamp=at, episodes=episodes)
    if action == 'unwatched':
        return unset_track_watched_item(ref, account_id=account_id, timestamp=at, episodes=episodes)
    if ref.is_container:  # a resume point is of a movie or an episode
        return False
    pb = get_playback_item(ref, account_id=account_id) or MediaPlayInfo(ref=ref)
    if action == 'reset_progress':
        pb.clear_progress()
        pb.unpaused_at = int(utc_timestamp(at))
    elif action == 'pause' and progress:
        pb.progress, pb.paused_at = float(progress), int(utc_timestamp(at))
    else:
        return False
    return update_track_watched_item(pb, account_id=account_id)


def apply_local(action: str, ref: MediaRef, *, account_id: str, at: Optional[float] = None, episodes: Sequence[MediaRef] = ()) -> bool:
    """
    Apply a change of a local account (its rows are read from Kodi video DB): only the removals ('unwatched',
    'reset_progress') are kept here - their times, for the merged progress. Return True on any change.
    """
    if action in ('unwatched', 'reset_progress'):
        return apply_change(action, ref, account_id=account_id, at=at, episodes=episodes)
    return False


def _in_state(action: ChangeAction, ref: MediaRef, *, account_id: str, episodes: Sequence[MediaRef] = ()) -> bool:
    """
    Return True if the row of the account is the target state of the change already: a show / season - the rows of its
    `episodes` (watched: all of them, unwatched: none; without `episodes` never); a pause never is.
    """
    if action == 'pause':
        return False
    if ref.is_container:
        if not episodes or action not in ('watched', 'unwatched'):
            return False
        watched = {pb.ref for pb in get_playback_rows([ref], accounts=[account_id]) if pb.play_count}
        if action == 'watched':
            return all(ep in watched for ep in episodes)
        return not any(ep in watched for ep in episodes)
    pb = get_playback_item(ref, account_id=account_id)
    if action == 'watched':
        return pb is not None and (pb.play_count or 0) > 0 and not pb.progress
    if action == 'unwatched':
        return pb is None or not pb.play_count
    return pb is None or not pb.progress  # reset_progress


def record_change(action: ChangeAction, ref: MediaRef, *, account_ids: Iterable[str], at: Optional[float] = None,
                  progress: Optional[float] = None, episodes: Sequence[MediaRef] = (), if_differs: bool = False) -> bool:
    """
    Record a change (FF, Kodi, the player) of the accounts to send to their services: the change waits for the delivery
    (`pending_change`, the last one of the media; the sync delivers it, see `lib.ff.sync`), the rows are changed at once
    (with the time of the change). The waiting change is first: a crash between leaves a delivery, never a lost change.
    With `if_differs` (a state of Kodi to align, not an event) an account with its row in the target state is skipped.
    A movie / an episode watched, unwatched or reset keeps the resume point it ends on the service: the given `progress`,
    the one of the row of the account (before the change) or of the replaced waiting change (not delivered yet).
    Return True if any account got it.
    """
    at = int(utc_timestamp(at))
    ends = action != 'pause' and not ref.is_container
    done = False
    for account_id in account_ids:
        if if_differs and _in_state(action, ref, account_id=account_id, episodes=episodes):
            fflog(f'[SYNC] {account_id}: {action} {ref:a} skipped, the row has it already')
            continue
        resume = progress
        if ends and not resume and (pb := get_playback_item(ref, account_id=account_id)) is not None:
            resume = pb.progress
        with db.cursor(write=True) as cur:
            # the waiting change of the media by its key (unique): a series of changes is not read again for each of them
            old = cur.exec(select(PendingChange).where(AND(PendingChange.xref == ref.xref, PendingChange.account_id == account_id))).first()
            if ends and not resume and old is not None:
                resume = old.progress
            cur.add(PendingChange(id=old and old.id, xref=ref.xref, account_id=account_id, action=action, progress=resume, at=at,
                                  queued_at=int(utc_timestamp())))
        apply_change(action, ref, account_id=account_id, at=at, progress=progress, episodes=episodes)
        done = True
    return done


def pending_changes(account_id: Optional[str] = None) -> Sequence[PendingChange]:
    """Return the changes waiting for the delivery (of the account, if given), the oldest first."""
    with db.cursor() as cur:
        query = select(PendingChange)
        if account_id is not None:
            query = query.where(PendingChange.account_id == account_id)
        return sorted(cur.exec(query).all(), key=lambda change: change.at)


def pending_count(account_id: str) -> int:
    """Return the number of the changes of the account waiting for the delivery."""
    return len(pending_changes(account_id))


def _same_change(change: PendingChange) -> Expr:
    """Return the condition of the row of the waiting change, if it is still this one (`record_change()` replaces it in its row)."""
    return AND(PendingChange.id == change.id, PendingChange.action == change.action, PendingChange.at == change.at,
               IS(PendingChange.progress, change.progress))


def revert_change(change: PendingChange) -> bool:
    """
    Undo a change not delivered (given up, rejected, its media unknown to the service) in the rows of its account: the parts
    it set (with its time) are cleared, the service state comes with the next full sync of its bucket. Kept, such a row
    would be a removal nobody made there (a watched row missing in the full list is unwatched at the cursor time), which
    the merge of accounts (the newest event wins) applies to the other accounts too. Return True if any row changed.
    """
    at = change.at
    changed = False

    def state(media: MediaPlayInfo) -> object:
        """Return the parts of the row a change sets."""
        return media.play_count, media.last_watched_at, media.unwatched_at, media.unpaused_at, media.progress, media.paused_at

    with db.cursor(write=True) as cur:
        for media in _get_playback(cur, account_id=change.account_id, ffids={change.ref.ffid}):
            if not change.covers(media.ref):
                continue
            old = state(media)
            if change.action == 'watched' and media.last_watched_at == at:
                media.play_count, media.last_watched_at = 0, None  # not a watched row: the full list does not unwatch it
            if change.action in ('unwatched', 'reset_progress'):
                if media.unwatched_at == at and change.action == 'unwatched':
                    media.unwatched_at = None
                if media.unpaused_at == at:
                    media.unpaused_at = None
            if change.action == 'pause' and media.paused_at == at:
                media.clear_progress()
            if state(media) != old:
                cur.add(media)
                changed = True
    return changed


def drop_pending(change: PendingChange) -> None:
    """Remove the waiting change (delivered, rejected or given up); one replaced meanwhile (a newer change of the media) stays."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(PendingChange).where(_same_change(change)))


def retry_pending(change: PendingChange) -> None:
    """The delivery of the change failed for now (no connection, a server error): one more try later (a replaced one: its own)."""
    with db.cursor(write=True) as cur:
        cur.exec(update(PendingChange).set(tries=change.tries + 1, failed_at=change.failed_at or int(utc_timestamp()))
                 .where(_same_change(change)))


def progress_changed(*, announced: bool = False) -> float:
    """
    Mark the progress as changed (rows of any account, a change in Kodi video DB): an open folder is refreshed. `announced`:
    Kodi has announced the change itself (the end of a play), it reloads its widgets (see `progress_announced()`). Return the time.
    """
    from . import state
    now = utc_timestamp()
    state.multi_set((('progress.timestamp', now), ('progress.announced', now if announced else 0)), module='playback')
    return now


def progress_timestamp() -> float:
    """Return the time of the last progress change (see `progress_changed()`), 0 if unknown."""
    from . import state
    return state.get('progress.timestamp', module='playback', default=0)


def progress_announced() -> float:
    """Return the time of the last progress change if Kodi has announced it itself (see `progress_changed()`), else 0."""
    from . import state
    return state.get('progress.announced', module='playback', default=0)


@frozen(kw_only=True)
class LivePlay:
    """
    The position of the FF media playing now, written by the service at the player events (`set_live_play()`): Kodi writes
    the end of a play to its video DB later and the service handles it later still, a list read meanwhile (the widgets
    Kodi refreshes when the home screen is back) sees the play ahead of Kodi video DB (`InfoProvider.kodi_rows()`).
    """

    #: The media (`MediaRef` path: `f'{ref:a}'`).
    ref: str
    #: The position (seconds) at `at`.
    position: float
    #: Timestamp (UTC unixtime seconds) of the position.
    at: float
    #: The playing speed (0: paused).
    speed: float
    #: The total time (seconds).
    total: float

    @property
    def media_ref(self) -> Optional[MediaRef]:
        """Return the playing media."""
        return MediaRef.from_slash_string(self.ref)

    def percent(self) -> float:
        """Return the position now in percent: the one at `at` moved on by the clock and the speed (the player does not announce a stalled buffer)."""
        if self.total <= 0:
            return 0
        position = self.position + max(0.0, utc_timestamp() - self.at) * self.speed
        return min(100.0, 100 * position / self.total)

    def watched(self) -> bool:
        """Return True if the position is past the one from which Kodi counts the play as watched."""
        from ..settings import advanced_settings
        return self.percent() >= advanced_settings.watched_percent()

    def row(self, account_id: str, before: Optional[MediaPlayInfo]) -> Optional[MediaPlayInfo]:
        """
        Return the row of the local Kodi account with this play ahead (watched past the Kodi percent, else its resume point),
        `before`: its row in Kodi video DB; None if Kodi has written this play already (its play time, seconds, not older).
        """
        if before is not None and max(before.last_watched_at or 0, before.paused_at or 0) >= int(self.at):
            return None
        if (ref := self.media_ref) is None:
            return None
        at = int(self.at)
        ffid = ref.ffid if ref.is_movie else 0  # as `KodiVideoInfo.play_info()`
        play_count = (before.play_count or 0) if before is not None else 0
        if self.watched():
            return MediaPlayInfo(ref=ref, account_id=account_id, ffid=ffid, play_count=play_count + 1, last_watched_at=at)
        last_watched_at = before.last_watched_at if before is not None else None
        return MediaPlayInfo(ref=ref, account_id=account_id, ffid=ffid, play_count=play_count, last_watched_at=last_watched_at,
                             progress=self.percent(), duration=int(self.total), paused_at=at)


def live_play() -> Optional[LivePlay]:
    """Return the position of the FF media playing now (see `LivePlay`), None if none plays."""
    from . import state
    live = state.get('playing.live', module='player')  # None after a play
    return None if live is None else LivePlay(**live)


def set_live_play(live: Optional[LivePlay]) -> None:
    """Set the position of the FF media playing now (see `LivePlay`), None: the end of the play is written."""
    from . import state
    state.set('playing.live', live, module='player')


def rename_account_rows(old: str, new: str) -> None:
    """
    Move all rows of the account `old` to the account ID `new` (the migrated settings accounts). A row of a media the
    account `new` already has is kept (a migration again: it is newer), the one of `old` removed.
    """
    with db.cursor(write=True) as cur:
        cur.exec(update_or_ignore(MediaPlayInfo).set(account_id=new).where(MediaPlayInfo.account_id == old))
        cur.exec(update_or_ignore(PendingChange).set(account_id=new).where(PendingChange.account_id == old))
    remove_account_rows(old)


def remove_account_rows(account_id: str) -> None:
    """Remove all rows of the account (e.g. a new user of the account) and its waiting changes."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(MediaPlayInfo).where(MediaPlayInfo.account_id == account_id))
        cur.exec(delete(PendingChange).where(PendingChange.account_id == account_id))


# def _history_merge(old: List[TraktHistoryItem], new: List[TraktHistoryItem]) -> List[TraktHistoryItem]:
#     """Merge old and new history. Take new with removeing support."""
#     oldd: Dict[int, TraktHistoryItem] = {m.ffbid: m for m in old}
#     newd: Dict[int, TraktHistoryItem] = {m.ffid: m for m in new}
#     keep = set(oldd.keys()) - set(newd.keys())
#     return tuple(chain((v._replace(history_id=None) for k, v in old.itms() if k in keep), newd.values()))


# def update_history(rows: List[TraktHistoryItem]) -> None:
#     """Replace trakt playback content."""
#     with db.cursor() as cur:
#         cur.execute('SELECT * FROM trakt_history')
#         old = [TraktHistoryItem(*row[1:]) for row in cur.fetchall()]
#         rows = _history_merge(old, rows)
#         cur.execute('DELETE FROM trakt_history')
#         cur.executemany('INSERT INTO trakt_history ('
#                         ' history_id, ffid, action, watched_at, trakt_id, imdb, tmdb, slug, type,'
#                         ' episode, season, tv_trakt_id, tv_imdb, tv_tmdb, tv_slug'
#                         ') VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', rows)


if __name__ == '__main__':
    from ...ff.cmdline import DebugArgumentParser
    p = DebugArgumentParser(dest='cmd')
    with p.with_subparser('x1'):
        pass
    with p.with_subparser('playback'):
        pass
    with p.with_subparser('shows') as pp:
        pp.add_argument('-e', '--episode', action='store_true', help='show episodes with ffid')
    with p.with_subparser('movies'):
        pass
    args = p.parse_args()

    if args.cmd == 'x1':
        m1 = get_playback_item(MediaRef('show', 100_127_235, 2, 5), account_id='trakt')
        m2 = get_playback_item(MediaRef('episode', 104_557_662), account_id='trakt')
        assert m1 == m2
        print(m1)
    elif args.cmd == 'playback':
        from cProfile import Profile
        from pstats import Stats
        with Profile(builtins=False) as pr:
            get_playback('show')
            st = Stats(pr).sort_stats('cumtime', 'ncalls')
            # st = Stats(pr).sort_stats('ncalls', 'tottime', 'cumtime')
            # pr.print_stats(('ncalls', 'tottime', 'cumtime'))
            st.print_stats()
    elif args.cmd in ('movies', 'shows'):
        for pb in get_playback(args.cmd[:-1]):
            if not args.episode or (pb.ref.is_episode and pb.ffid):
                print(pb)
