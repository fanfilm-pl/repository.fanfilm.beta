"""
Media cache freshness policy (ffinfo-owned, the "smart" side of the cache).

`compute_expires_at` turns a *live* ``FFItem`` node plus "now" into a cache deadline using the
declarative :data:`const.media.cache` table. The repository only stores the resulting
``expires_at`` as an opaque column and never computes it (it stays "dumb").

Two mechanisms cover the edge cases (one table, no per-type rules):

* **base TTL from node age** — ``age = now - reference_date(node)`` where the reference date is the
  last significant event: movie -> premiere; show -> last aired episode; season -> its air date;
  episode -> its date. Older, settled nodes change rarely, so they get a longer TTL.
* **proportional vigilance toward a future event** ``E`` (premiere-if-ahead or next air) — expire
  after a fraction of the way to ``E`` so we take a few looks *before* ``E`` and catch a schedule
  shift. A returning show with no known next air falls back to a weekly poll floor.

The policy is kept in this light module (rather than inside the heavy ``info`` module) so it stays
importable and unit-testable on its own; ffinfo simply calls :func:`compute_expires_at`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..calendar import timestamp as dt_timestamp
from ..settings import settings
from const import const

if TYPE_CHECKING:
    from datetime import date as dt_date
    from ..item import FFItem

#: Series statuses meaning "more emissions may still come" (used by the returning-status floor).
RETURNING_STATUSES: frozenset[str] = frozenset({'returning series', 'in production', 'planned', 'pilot'})


def _as_seconds(expr: str | int) -> int:
    """Evaluate a TTL value to int seconds; a string is a settings expression (e.g. ``'6 * HOUR'``)."""
    if isinstance(expr, str):
        return int(settings.eval(expr))
    return int(expr)


def date_ts(date: dt_date | None) -> int | None:
    """Convert a date to a unix timestamp, or ``None`` if there is no date / it is out of range."""
    if date is None:
        return None
    try:
        return int(dt_timestamp(date))
    except OSError:
        # On Windows the C time range can be restricted (see ff.calendar); treat as unknown.
        return None


def _reference_ts(item: FFItem) -> int | None:
    """Return the node's last significant event timestamp (drives ``age``), or ``None`` if unknown."""
    last = item.last_episode_to_air
    if last is not None:
        ts = date_ts(last.date)
        if ts is not None:
            return ts
    return date_ts(item.date)


def _future_ts(item: FFItem, now: int) -> int | None:
    """Return the nearest known future event timestamp (next air, or premiere if still ahead)."""
    candidates: list[int] = []
    nxt = item.next_episode_to_air
    if nxt is not None:
        ts = date_ts(nxt.date)
        if ts is not None and ts > now:
            candidates.append(ts)
    own = date_ts(item.date)
    if own is not None and own > now:
        candidates.append(own)
    return min(candidates) if candidates else None


def _base_ttl(age: int | None, table: 'Sequence[tuple[int | None, str | int]]') -> tuple[int, int | None]:
    """Return ``(base_ttl, ceiling)`` for `age`: greatest threshold ``<= age`` wins; ``None`` = ceiling.

    ``age is None`` means "no past activity" (e.g. an unreleased title) and is treated as the oldest
    bucket (matches every concrete threshold), so the proportional vigilance toward the future event
    governs the actual TTL.
    """
    ceiling: int | None = None
    best: tuple[int, int] | None = None  # (threshold, ttl)
    for threshold, ttl_expr in table:
        if threshold is None:
            ceiling = _as_seconds(ttl_expr)
        elif (age is None or age >= threshold) and (best is None or threshold >= best[0]):
            best = (threshold, _as_seconds(ttl_expr))
    ttl = best[1] if best is not None else (ceiling or 0)
    if ceiling is not None:
        ttl = min(ttl, ceiling)
    return ttl, ceiling


def compute_expires_at(item: FFItem, now: float) -> int:
    """Compute the cache deadline (unix timestamp) for a live ``FFItem`` node at `now`.

    :param item: live media node (its date / last / next aired episode objects are read).
    :param now: current unix time (the store time; also used as ``updated_at``).
    :return: ``expires_at`` unix timestamp (always ``> now``; never an infinite TTL).
    """
    cache = const.media.cache
    now = int(now)
    ref_ts = _reference_ts(item)
    # No past activity (unknown, or the reference event is still ahead) -> oldest bucket; the future
    # event (handled below) then governs the TTL via proportional vigilance.
    age = now - ref_ts if ref_ts is not None and ref_ts <= now else None
    base_ttl, ceiling = _base_ttl(age, cache.ttl)
    future = _future_ts(item, now)
    if future is not None:
        # Proportional vigilance: expire part-way to the event, clamped to [vigilance_min, base_ttl].
        reach = (future - now) * cache.vigilance_frac
        ttl = max(_as_seconds(cache.vigilance_min), min(int(reach), base_ttl))
    else:
        ttl = base_ttl
        # Returning show with no known next air: keep polling at the floor period.
        status = item.vtag.getSeriesStatus().strip().lower()
        if status in RETURNING_STATUSES:
            ttl = min(ttl, _as_seconds(cache.returning_poll))
    if ceiling is not None:
        ttl = min(ttl, ceiling)
    return now + int(ttl)


def aired_expires_at(item: FFItem, now: float) -> int:
    """
    Return the deadline (unix timestamp) of the aired episodes of a live show node at `now`: the next air of an episode (the premiere),
    else the freshness of the node (`compute_expires_at()`: a returning show is polled, an ended one rarely).
    """
    return _future_ts(item, int(now)) or compute_expires_at(item, now)
