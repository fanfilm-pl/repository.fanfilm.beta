"""
Sqlite3 DB manager and base utilities of FanFilm: the DB core of the SDK (`lib.sdk.db.db`, no import of FanFilm)
bound to FanFilm (its data folder, `const`, the migration files of `lib/sql/migrate`, `MediaRef` as a value type).
"""

from __future__ import annotations
from pathlib import Path
from ...sdk.db import db as _sdk_db
from ...sdk.db.db import (  # noqa: F401  (the DB core of FanFilm)
    Db, DbCursor, DbManager, DbMode, Lock, MISSING, PrimaryKey, SQL, SqlConnection, SqlCursor, TypeMode, Unique,
    _split_sql, db_connect, db_create_columns, db_list_columns, db_manager, dump_value_and_type, get_cursor,
    known_types_by_name, load_value, render_column_type, sql_dump, sqlite3_column_type, update_db_version,
)
from ...defs import MediaRef
from const import const

try:
    from ..control import dataPath as _dataPath
    #: The folder of the databases.
    DB_PATH: Path = Path(_dataPath)
except ImportError:
    from ...fake.fake_api import FF3_PATH
    DB_PATH: Path = FF3_PATH

#: The migration files (`<name>.<version>.sql`).
MIGRATE_PATH = Path(__file__).resolve().parent.parent.parent / 'sql' / 'migrate'


def _path() -> Path:
    """Return the folder of the databases."""
    return DB_PATH


def _connection_timeout() -> float:
    """Return the connection timeout (`const.tune.db`)."""
    return const.tune.db.connection_timeout


def _synchronous(name: str) -> str:
    """Return `PRAGMA synchronous` of the database (`const.tune.db`)."""
    return const.tune.db.db_synchronous.get(name, const.tune.db.synchronous)


def _migrate_path() -> Path:
    """Return the folder of the migration files."""
    return MIGRATE_PATH


def _backup() -> bool:
    """Return True if a database is backed up before its migration (`const.dev.db`)."""
    return const.dev.db.backup


def _echo() -> bool:
    """Return True if the queries are echoed (`const.dev.db`)."""
    return const.dev.db.echo


def _tty() -> bool:
    """Return True if the log is a terminal (`const.debug`)."""
    return const.debug.tty


_sdk_db.options.path = _path
_sdk_db.options.connection_timeout = _connection_timeout
_sdk_db.options.synchronous = _synchronous
_sdk_db.options.migrate_path = _migrate_path
_sdk_db.options.backup = _backup
_sdk_db.options.echo = _echo
_sdk_db.options.tty = _tty
_sdk_db.register_type(MediaRef)
