"""
Lists cache DB (the "dumb" side): ``lists.db`` with user lists of accounts and general lists of types.

Two tables, no policy here (what to cache and for how long is decided by ``lib.ff.listcache``):

- ``list`` (:class:`ListRow`) -- a list header keyed by ``(scope, name, params)``: the scope is the account ID (the
  type name for a general list), the name is hierarchical (``watchlist``, ``user/123``, ``rated/movies``; a change of
  ``user`` marks all ``user/...``), the params are the normalized query of the service (with the page of a general list). Total, completeness, freshness (``expires_at``, ``stale``) and
  the list meta data of the service (e.g. its sort) as JSON.
- ``list_item`` (:class:`ListItemRow`) -- items of a list in order: the media reference (for lookups, e.g. ratings
  of a folder) and the raw item of the service as JSON (the service parser makes FFItems of it).

Every operation is "best effort": a DB error never reaches the caller (an empty read, a skipped write).
"""

from __future__ import annotations
from typing import Any, Callable, Iterable, Mapping, Optional, Sequence, TypeVar, TYPE_CHECKING
from time import time
import json

from attrs import frozen
from .db import PrimaryKey
from .orm import OrmDatabase, DbTable, Expr, SQL, field as db_field, select, delete, update, update_or_ignore, insert_or_replace, AND, OR, NOT, IN, MISSING
from .orm import best_effort
from ..tricks import JsonEncoder
from ...defs import MediaRef, XMediaRef
if TYPE_CHECKING:
    from ..types import JsonData

#: Lists DB version.
DB_VERSION: int = 1

F = TypeVar('F', bound=Callable[..., Any])


def _now() -> int:
    """Return current unix timestamp (seconds)."""
    return int(time())


def _to_xref(ref: MediaRef | None) -> XMediaRef:
    """Return the normalized reference (xref), an empty one for an item without a reference."""
    return XMediaRef('', 0) if ref is None else ref.xref


class ListRow(DbTable):
    """Header of a cached list."""

    __tablename__ = 'list'
    __table_args__ = ('UNIQUE("scope", "name", "params")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: Scope: the account ID, the type name for a general list of the type.
    scope: str = ''
    #: Hierarchical list name (`watchlist`, `user/123`, `rated/movies`).
    name: str = ''
    #: Normalized query parameters of the service.
    params: str = ''
    #: Number of items of the whole list (the stored ones can be less, see `complete`).
    total: int = 0
    #: All items are stored (not cut by the limit).
    complete: int = 1
    #: Marked as changed in the service (by the account sync or an own change): fetched again on the next read.
    stale: int = 0
    #: Fetch time (unix seconds).
    fetched_at: int = 0
    #: Freshness deadline (unix seconds).
    expires_at: int = 0
    #: List meta data of the service as JSON (e.g. the list sort).
    meta_json: str = '{}'

    @property
    def meta(self) -> JsonData:
        """Return the decoded meta data."""
        return json.loads(self.meta_json)


class ListItemRow(DbTable):
    """Item of a cached list."""

    __tablename__ = 'list_item'
    __table_args__ = ('UNIQUE("list_id", "pos")',)
    __table_indexes__ = (('list_id', 'xref::ffid'),)

    #: The primary DB key.
    id: PrimaryKey = None
    #: The list (`ListRow.id`).
    list_id: int = 0
    #: Position in the list (from 0).
    pos: int = 0
    #: Media reference, normalized (-1 instead of None), empty for an item without a reference.
    xref: XMediaRef = db_field(default=MISSING, converter=_to_xref)
    #: The raw item of the service as JSON.
    json_string: str = 'null'

    @property
    def data(self) -> JsonData:
        """Return the decoded raw item."""
        return json.loads(self.json_string)


@frozen
class StoredList:
    """A cached list: the header and the raw items in order."""

    #: The list header.
    row: ListRow
    #: Raw items of the service in order (all stored ones or only the requested references).
    items: Sequence[JsonData]

    def fresh(self, now: int | None = None) -> bool:
        """Return True if the list is not stale and not expired."""
        return not self.row.stale and self.row.expires_at > (_now() if now is None else now)


def dump(data: Any) -> str:
    """Return JSON of `data` (items and meta data of the service)."""
    return json.dumps(data, cls=JsonEncoder)


def _best_effort(default: Callable[[], Any]) -> Callable[[F], F]:
    """Decorate an operation of the lists DB, see `orm.best_effort()`."""
    return best_effort(default, db=lambda: db)


def _name_match(name: str) -> Any:
    """Return the WHERE expression of the list name and its sub-lists (`user` -> `user`, `user/...`)."""
    like = f'{name.replace("%", "").replace("_", "")}/%'  # names have no LIKE wildcards
    return OR(ListRow.name == name, Expr('"list"."name" LIKE ?', [like]))


@_best_effort(lambda: None)
def load(scope: str, name: str, params: str = '', *, refs: Iterable[MediaRef] | None = None) -> Optional[StoredList]:
    """Return the stored list (also a stale or expired one), with all items or only the items of `refs`."""
    with db.cursor() as cur:
        row = cur.exec(select(ListRow).where(AND(ListRow.scope == scope, ListRow.name == name, ListRow.params == params))).first()
        if row is None:
            return None
        query = select(ListItemRow).where(ListItemRow.list_id == row.id)
        if refs is not None:
            xrefs = {ref.xref for ref in refs}
            ffids = sorted({xref.ffid for xref in xrefs})
            items = [it for it in cur.exec(query.where(IN(ListItemRow.xref.ffid, ffids)).order_by(SQL('"pos"'))).iter()
                     if it.xref in xrefs]
        else:
            items = cur.exec(query.order_by(SQL('"pos"'))).all()
        return StoredList(row=row, items=[it.data for it in items])


@_best_effort(lambda: None)
def store(scope: str, name: str, params: str, items: Sequence[tuple[MediaRef | None, JsonData]], *,
          ttl: float, total: int | None = None, complete: bool = True, meta: Mapping[str, Any] | None = None) -> None:
    """Store (replace) the list and its items (reference, raw item) in order, valid for `ttl` seconds."""
    now = _now()
    row = ListRow(scope=scope, name=name, params=params, total=len(items) if total is None else total, complete=int(complete),
                  stale=0, fetched_at=now, expires_at=now + int(ttl), meta_json=dump(meta or {}))
    with db.cursor(write=True) as cur:  # column expressions are ready in the cursor (the tables are resolved)
        where = AND(ListRow.scope == scope, ListRow.name == name, ListRow.params == params)
        if (old := cur.exec(select(ListRow).where(where)).first()) is not None:
            cur.exec(delete(ListItemRow).where(ListItemRow.list_id == old.id))
            cur.exec(delete(ListRow).where(ListRow.id == old.id))
        cur.exec(insert_or_replace(ListRow), row)
        list_id = cur.exec(select(ListRow).where(where)).one().id or 0
        if items:
            cur.exec(insert_or_replace(ListItemRow), [ListItemRow(list_id=list_id, pos=pos, xref=ref, json_string=dump(data))
                                           for pos, (ref, data) in enumerate(items)])


@_best_effort(lambda: 0)
def mark_stale(scope: str, name: str | None = None) -> int:
    """Mark the lists of the scope (all, or the list `name` with its sub-lists, any params) as stale. Return the count."""
    with db.cursor(write=True) as cur:
        where = ListRow.scope == scope
        if name is not None:
            where = AND(where, _name_match(name))
        cur.exec(update(ListRow).set(stale=1).where(where))
        return cur.rowcount


@_best_effort(lambda: None)
def rename_scope(old: str, new: str) -> None:
    """
    Move all lists of the scope `old` to the scope `new` (the migrated settings accounts). A list the scope `new` already
    has is kept (a migration again: it is newer), the one of `old` removed.
    """
    with db.cursor(write=True) as cur:
        cur.exec(update_or_ignore(ListRow).set(scope=new).where(ListRow.scope == old))
    remove_scope(old)


@_best_effort(lambda: 0)
def remove_scope(scope: str) -> int:
    """Remove all lists of the scope (e.g. the account user changed). Return the number of lists."""
    with db.cursor(write=True) as cur:
        ids = [row.id for row in cur.exec(select(ListRow).where(ListRow.scope == scope)).iter()]
        if not ids:
            return 0
        cur.exec(delete(ListItemRow).where(IN(ListItemRow.list_id, ids)))
        cur.exec(delete(ListRow).where(IN(ListRow.id, ids)))
        return len(ids)


@_best_effort(lambda: None)
def clear() -> None:
    """Remove all lists (the user clears the lists cache)."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(ListItemRow))
        cur.exec(delete(ListRow))


@_best_effort(lambda: [])
def scopes() -> list[str]:
    """Return all scopes of the stored lists."""
    with db.cursor() as cur:
        return [row['scope'] for row in cur.execute('SELECT DISTINCT "scope" FROM "list"').fetchall()]


@_best_effort(lambda: 0)
def remove_other_scopes(scopes: Iterable[str]) -> int:
    """Remove all lists outside the scopes (e.g. of removed accounts). Return the number of lists."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(ListRow).where(NOT(IN(ListRow.scope, list(scopes)))))
        count = cur.rowcount
    _remove_orphans()
    return count


@_best_effort(lambda: 0)
def cleanup(grace: int = 0, *, keep_scopes: Iterable[str] = ()) -> int:
    """Remove lists expired more than `grace` seconds ago with their items, except lists of `keep_scopes`. Return the count."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(ListRow).where(AND(ListRow.expires_at < _now() - grace, NOT(IN(ListRow.scope, list(keep_scopes))))))
        count = cur.rowcount
    _remove_orphans()
    return count


def _remove_orphans() -> None:
    """Remove items of removed lists."""
    with db.cursor(write=True) as cur:
        cur.execute('DELETE FROM "list_item" WHERE "list_id" NOT IN (SELECT "id" FROM "list")')


#: Global lists DB.
db: OrmDatabase = OrmDatabase('lists', ListRow, ListItemRow, version=DB_VERSION)
