"""
Library DB (the "dumb" side): ``library.db`` with the STRM files of Kodi library.

``strm`` (:class:`StrmRow`) -- the URL a STRM file of Kodi library plays (an FF play URL or an URL of another add-on),
keyed by its path as Kodi video DB keeps it (``path.strPath`` + ``files.strFilename``). A STRM file keeps its URL, so it
is read once. An unreadable file (removed until Kodi cleans the library, a path of another device on a shared MySQL,
an offline share) is kept with an empty URL until its deadline (``expires_at``, NULL = never), then it is read again;
the caller gives the lifetime. A file keeps also its state in Kodi video DB after the last library alignment (the
snapshot, ``kodi_watched`` / ``kodi_progress``): a change of Kodi the FF service did not see is a difference from it.

Every operation is "best effort": a DB error never reaches the caller (an empty read, a skipped write).
"""

from __future__ import annotations
from typing import Any, Callable, Collection, Mapping, Optional, TypeVar
from pathlib import Path
from time import time

from .db import PrimaryKey
from .orm import OrmDatabase, DbTable, DbCursor, select, update, delete, insert_or_replace, IN, best_effort, delete_expired
from .playback import PlayState
from ..control import dataPath

#: Library DB version (2: the snapshot of the Kodi state - see `lib/sql/migrate/library.2.sql`).
DB_VERSION: int = 2

#: The old file of the STRM URLs (before this DB), removed when the DB is created.
OLD_FILE: str = 'strm_urls.json'

#: Parameters of one SQL statement (the paths of a removal).
CHUNK: int = 500

F = TypeVar('F', bound=Callable[..., Any])


class StrmRow(DbTable):
    """The URL of a STRM file of Kodi library."""

    __tablename__ = 'strm'
    __table_args__ = ('UNIQUE("path")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: Path of the file as in Kodi video DB (`path.strPath` + `files.strFilename`).
    path: str = ''
    #: The URL of the file, empty if the file is unreadable.
    url: str = ''
    #: Deadline (unix seconds) of an unreadable file, None = never (a read URL).
    expires_at: Optional[int] = None
    #: The file watched in Kodi video DB after the last library alignment, None - no snapshot (not aligned yet).
    kodi_watched: Optional[bool] = None
    #: The resume point (percent) of the file in Kodi video DB after the last library alignment, 0 - none.
    kodi_progress: float = 0


def _best_effort(default: Callable[[], Any]) -> Callable[[F], F]:
    """Decorate an operation of the library DB, see `orm.best_effort()`."""
    return best_effort(default, db=lambda: db)


@_best_effort(dict)
def strm_urls() -> dict[str, str]:
    """Return the known STRM files: path -> URL (empty: unreadable, not expired)."""
    with db.cursor() as cur:
        # plain rows like `snapshots()`: the table objects are 2/3 of a full read of the Kodi plays (`get_plays()`)
        cur.execute('SELECT path, url FROM strm WHERE expires_at IS NULL OR expires_at > ?', (int(time()),))
        rows = cur.fetchall()
    return {row['path']: row['url'] for row in rows}


@_best_effort(lambda: None)
def store(urls: Mapping[str, str], *, unreadable_ttl: float) -> None:
    """Store (replace) the URLs of STRM files: path -> URL, an empty URL (unreadable file) expires after `unreadable_ttl` seconds."""
    deadline = int(time() + unreadable_ttl)
    with db.cursor(write=True) as cur:
        insert_or_replace(StrmRow).exec(cur, [StrmRow(path=path, url=url, expires_at=None if url else deadline) for path, url in urls.items()])


@_best_effort(dict)
def snapshots() -> dict[str, PlayState]:
    """Return the snapshots of the Kodi state (watched, resume point) of the files after the last alignment: path -> state (no snapshot: missing)."""
    with db.cursor() as cur:
        # plain rows: thousands of table objects cost ~10x more (0.4 s on a Pi 4, at every alignment)
        cur.execute('SELECT path, kodi_watched, kodi_progress FROM strm WHERE kodi_watched IS NOT NULL')
        rows = cur.fetchall()
    return {row['path']: PlayState(watched=row['kodi_watched'] == '1', progress=row['kodi_progress']) for row in rows}


@_best_effort(lambda: None)
def store_snapshots(states: Mapping[str, PlayState]) -> None:
    """Store the snapshots of the Kodi state of the files (path -> state, see `snapshots()`); a file not known is skipped."""
    with db.cursor(write=True) as cur:
        for path, state in states.items():
            cur.exec(update(StrmRow).set(kodi_watched=state.watched, kodi_progress=state.progress).where(StrmRow.path == path))


@_best_effort(int)
def prune(paths: Collection[str]) -> int:
    """Remove the files not in `paths` (all STRM files of Kodi library now). Return the count."""
    with db.cursor(write=True) as cur:
        cur.execute('SELECT path FROM strm')  # plain rows, see `strm_urls()`
        gone = [path for row in cur.fetchall() if (path := row['path']) not in paths]
        for i in range(0, len(gone), CHUNK):  # SQLite before 3.32 takes at most 999 parameters
            cur.exec(delete(StrmRow).where(IN(StrmRow.path, gone[i:i + CHUNK])))
    return len(gone)


@_best_effort(int)
def cleanup() -> int:
    """Remove the expired rows (unreadable files, read again later; run by the service). Return the count."""
    return delete_expired(db, StrmRow)


def remove_old_file(cur: DbCursor) -> None:
    """Fresh DB: remove the old file of the STRM URLs (`OLD_FILE`)."""
    try:
        (Path(dataPath) / OLD_FILE).unlink()
    except OSError:
        pass  # no such file


#: Global library DB.
db: OrmDatabase = OrmDatabase('library', StrmRow, version=DB_VERSION, on_create=remove_old_file)
