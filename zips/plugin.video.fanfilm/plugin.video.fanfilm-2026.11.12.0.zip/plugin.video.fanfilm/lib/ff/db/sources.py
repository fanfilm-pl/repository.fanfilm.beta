"""Sources cache DB (the "dumb" side): ``sources.db`` tables and their row operations.

Two tables, no policy here (what to cache and for how long is decided by the callers):

- ``source_cache`` (:class:`SourceCacheRow`) -- results of a provider search, keyed by
  ``(provider, xref, query)``: a source list of a movie / an episode, or a show token (a row with the show
  xref, season and episode -1). ``query`` is the fingerprint of the search query.
- ``provider_data`` (:class:`ProviderDataRow`) -- key-value data of providers (sessions, tokens) and their
  shared helpers, keyed by ``(namespace, key)``, with a hard deadline (``expires_at``, NULL = never) and the
  store time (``updated_at``) for a soft freshness check (``max_age``).

Values are JSON. Every operation is "best effort": a DB error never reaches the caller. A search result is stored
in the background (`store()` only queues it, see `flush()`), the provider data at once.
"""

from typing import Optional, Any, Callable, Collection, Deque, Dict, List, Tuple, TypeVar
from collections import deque
from threading import Lock, Thread
from time import time
import json as json_mod

from .db import db_manager, PrimaryKey
from .orm import OrmDatabase, DbTable, DbCursor, field as db_field, select, delete, insert_or_replace, AND, IN, MISSING
from .orm import best_effort, delete_expired
from .kvstore import KeyValueRow
from ...sdk.db.providers import ProviderDataRow, ProviderStore as SdkProviderStore  # noqa: F401  (the one provider data table)
from ..logs import fflog
from ..threads import Event
from ..tricks import JsonEncoder
from ..types import JsonData
from ...defs import MediaRef, XMediaRef

#: Sources DB version. v2: the old providers DB is removed (all provider data is here).
DB_VERSION: int = 2

#: Old DBs replaced by this one, removed when it is created or migrated: the sources cache (`rel_src`, `rel_url`)
#: and the provider data (`providers.14.db`, `cache` table).
OLD_DBS: Tuple[str, ...] = ('sources.1', 'providers.14')

F = TypeVar('F', bound=Callable[..., Any])


def to_xref(ref: MediaRef) -> XMediaRef:
    """Return the normalized reference (xref) for `ref`."""
    return ref.xref


def to_json(data: JsonData) -> str:
    """Convert `data` to a JSON string."""
    return json_mod.dumps(data, cls=JsonEncoder)


def _now() -> int:
    """Return current unix timestamp (seconds)."""
    return int(time())


class SourceCacheRow(DbTable):
    """Cached result of a provider search: a source list (movie, episode) or a show token (show)."""

    __tablename__ = 'source_cache'
    __table_args__ = ('UNIQUE("provider", "xref::type", "xref::ffid", "xref::season", "xref::episode", "query")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: Provider (module) name.
    provider: str = ''
    #: Media reference, normalized (-1 instead of None); a show token has the show ref.
    xref: XMediaRef = db_field(default=MISSING, converter=to_xref)
    #: Fingerprint of the search query.
    query: str = ''
    #: The result as JSON.
    json_string: str = 'null'
    #: Store time (unix seconds).
    updated_at: int = 0
    #: Freshness deadline (unix seconds).
    expires_at: int = 0

    @property
    def data(self) -> JsonData:
        """Return the decoded result."""
        return json_mod.loads(self.json_string)


def _best_effort(default: Callable[[], Any]) -> Callable[[F], F]:
    """Decorate an operation of the sources DB, see `orm.best_effort()`."""
    return best_effort(default, db=lambda: db)


# --- source_cache ---------------------------------------------------------------------------------

@_best_effort(dict)
def fetch_many(ref: MediaRef, query: str, providers: Optional[Collection[str]] = None) -> Dict[str, SourceCacheRow]:
    """Return the fresh cached results for `ref` and `query` by their providers (all, or of `providers`): one query for a search."""
    with db.cursor() as cur:  # the columns of the table exist after the DB init (the first cursor)
        where = AND(SourceCacheRow.xref == ref.xref, SourceCacheRow.query == query, SourceCacheRow.expires_at > _now())
        if providers is not None:
            where = AND(where, IN(SourceCacheRow.provider, list(providers)))
        return {row.provider: row for row in cur.exec(select(SourceCacheRow).where(where))}


def fetch(provider: str, ref: MediaRef, query: str) -> Optional[SourceCacheRow]:
    """Return the fresh cached result of `provider` for `ref` and `query`, or None."""
    return fetch_many(ref, query, (provider,)).get(provider)


def store(provider: str, ref: MediaRef, query: str, data: JsonData, *, ttl: float) -> None:
    """
    Store (replace) the result of `provider` for `ref` and `query`, valid for `ttl` seconds.

    The result is only queued, the background writer stores the queued results in batches (one transaction each,
    in order), so the provider does not wait for the DB (many providers store at once, see `flush()`).
    """
    global _writer
    now = _now()
    row = SourceCacheRow(provider=provider, xref=ref, query=query, json_string=to_json(data),
                         updated_at=now, expires_at=now + int(ttl))
    with _pending_lock:
        _pending.append(row)
        _idle.clear()
        if _writer is None:
            _writer = Thread(target=_write_pending, name='SourcesCacheWriter', daemon=True)
            _writer.start()


def flush(timeout: Optional[float] = None) -> bool:
    """Wait until the queued results are stored (at most `timeout` seconds, Kodi exit ends it), return True if they are."""
    return _idle.wait(timeout)


def _write_pending() -> None:
    """Background writer: store the queued results in batches until the queue is empty, then end."""
    global _writer
    while True:
        with _pending_lock:
            rows = list(_pending)
            _pending.clear()
            if not rows:
                _writer = None
                _idle.set()
                return
        _store_rows(rows)


@_best_effort(lambda: None)
def _store_rows(rows: List[SourceCacheRow]) -> None:
    """Store (replace) the result rows in one transaction."""
    with db.cursor(write=True) as cur:
        for row in rows:
            insert_or_replace(SourceCacheRow).exec(cur, row)


# --- provider_data --------------------------------------------------------------------------------

class ProviderStore(SdkProviderStore):
    """
    Data of a provider (sessions, tokens, ...) or of a shared helper, in its own namespace, in the sources DB.

    The lifetime is given on every write (`ttl`, None = never expires); expired data is removed by the service.
    `max_age` on read is a soft freshness: older data is skipped, but kept (e.g. a stale fallback).
    """

    def __init__(self, namespace: str) -> None:
        """Create the store of the namespace."""
        super().__init__(namespace, database=lambda: db)


def get_data_row(namespace: str, key: str, *, max_age: Optional[float] = None) -> Optional[KeyValueRow]:
    """Return the data row, if it has not expired and (with `max_age`) is younger than `max_age` seconds."""
    return ProviderStore(namespace).row(key, max_age=max_age)


def set_data(namespace: str, key: str, value: Any, *, ttl: Optional[float]) -> None:
    """Store (replace) the data value; it expires after `ttl` seconds, None = never."""
    ProviderStore(namespace).set(key, value, ttl=ttl)


def delete_data(namespace: str, key: str) -> None:
    """Remove the data value."""
    ProviderStore(namespace).delete(key)


#: Shared (not provider) namespaces of the provider data. A provider uses its own name.
SHARED_NAMESPACES: Tuple[str, ...] = (
    'ff/kitsu',    # anime ids index (Fribb lists)
    'ff/proxy',    # free proxies of the resolvers
    'ff/client',   # random User-Agent of the old client
    'ff/natives',  # the catalog of the native providers (lib.sources.natives)
)


def provider_store(namespace: str) -> ProviderStore:
    """Return the data store of a provider (by its name) or of a shared namespace."""
    return ProviderStore(namespace)


# --- maintenance ----------------------------------------------------------------------------------

@_best_effort(lambda: None)
def clear(*, provider_data: bool = False) -> None:
    """Remove all cached search results, with `provider_data` also all data of providers (logins, tokens)."""
    with _pending_lock:
        _pending.clear()            # the queued results are gone too
    with db.cursor(write=True) as cur:
        cur.exec(delete(SourceCacheRow))
        if provider_data:
            cur.exec(delete(ProviderDataRow))


@_best_effort(int)
def cleanup() -> int:
    """
    Remove expired rows of both tables (run by the service). Return the count.

    The old DBs left by the migration (another interpreter had them open then) are removed too.
    """
    for name in OLD_DBS:
        db_manager.remove_db(name)
    return delete_expired(db, SourceCacheRow) + delete_expired(db, ProviderDataRow)


# --- DB schema / migration ------------------------------------------------------------------------

def remove_old_dbs(cur: DbCursor) -> None:
    """Fresh or migrated DB: remove the old DBs it replaces (OLD_DBS)."""
    for name in OLD_DBS:
        db_manager.remove_db(name)


#: Search results queued for the background writer (FIFO), see `store()`.
_pending: Deque[SourceCacheRow] = deque()
#: Guards `_pending` and `_writer`.
_pending_lock: Lock = Lock()
#: The background writer thread, None if it is not running.
_writer: Optional[Thread] = None
#: Set if no result is queued or being stored.
_idle: Event = Event()
_idle.set()

#: Global sources DB.
db = OrmDatabase('sources', SourceCacheRow, ProviderDataRow, version=DB_VERSION, on_create=remove_old_dbs, on_update=remove_old_dbs)
