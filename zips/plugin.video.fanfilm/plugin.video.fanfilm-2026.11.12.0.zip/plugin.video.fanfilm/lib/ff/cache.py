# -*- coding: utf-8 -*-
"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os

from . import control
from .db_connection_manager import connection_manager
from .logs import fflog
from .threads import check_thread_cancel

# Przechowujemy często używane ścieżki i ustawienia w zmiennych
data_path = control.dataPath


# --- NIGDY NIE UŻYWANA, BO NADPISANA PRZEZ TO CO PONIŻEJ ---
# def _get_connection_cursor(db_path=None):
#     if db_path is None:
#         db_path = data_path  # Użycie zmiennej zamiast ponownego wywoływania funkcji
#     conn = connection_manager.get_connection("cache", db_path)
#     return conn.cursor()


def _get_connection_cursor(db_path=None, conn=None):
    check_thread_cancel()
    if conn is None:
        conn = _get_connection(db_path)
    return conn.cursor()


def create_cache_table(db_path=None, *, table="cache"):
    cursor = _get_connection_cursor(db_path)
    cursor.execute(
        f"CREATE TABLE IF NOT EXISTS {table} ("
        "key TEXT PRIMARY KEY, value TEXT, date INTEGER)"
    )


def cache_clear(flush_only=False, db_path=None, *, table="cache"):
    try:
        dbcur = _get_connection_cursor(db_path)
        if flush_only:
            dbcur.execute(f"""DELETE FROM {table}""")
            dbcur.connection.commit()
            dbcur.execute("""VACUUM""")
        else:
            dbcur.execute(f"""DROP TABLE IF EXISTS {table}""")
            dbcur.execute("""VACUUM""")
            dbcur.connection.commit()
    except Exception as e:
        fflog(f"Cache Clear Error: {e}")


def cache_clear_sources(*, provider_data: bool = False) -> None:
    """Clear the sources cache (search results); with `provider_data` also data of providers (logins, tokens), of the provider add-ons too."""
    from .db import sources as sources_db
    sources_db.clear(provider_data=provider_data)
    if provider_data:
        from .xproviders import clear_data
        clear_data()


def cache_clear_downloader():
    try:
        create_cache_table()
        cursor = _get_connection_cursor_downloader()
        cursor.execute("DELETE FROM download_manager")
        cursor.connection.commit()
    except Exception as e:
        fflog(f"Cannot delete cached sources from database, error: {e}")


def cache_clear_search():
    try:
        cursor = _get_connection_cursor_search()
        for t in ["tvshow", "movies"]:
            cursor.execute("DROP TABLE IF EXISTS %s" % t)
            cursor.execute("VACUUM")
            cursor.connection.commit()
    except Exception as e:
        fflog(f"Cache Clear Search Error: {e}")


def cache_clear_search_by_term(term_value):
    try:
        cursor = _get_connection_cursor_search()
        for t in ["tvshow", "movies"]:
            cursor.execute("DELETE FROM %s WHERE term = ?" % t, (term_value,))
            cursor.connection.commit()
    except Exception as e:
        fflog(f"Cache Clear Search By Term Error: {e}")


def cache_clear_view():
    try:
        cursor = _get_connection_cursor_views()
        for t in ["views"]:
            cursor.execute("DROP TABLE IF EXISTS %s" % t)
            cursor.execute("VACUUM")
            cursor.connection.commit()
    except Exception as e:
        fflog(f"Cache Clear View Error: {e}")


def cache_clear_bookmarks():
    try:
        cursor = _get_connection_cursor_bookmarks()
        for t in ["bookmarks"]:
            cursor.execute("DROP TABLE IF EXISTS %s" % t)
            cursor.execute("VACUUM")
            cursor.connection.commit()
    except Exception as e:
        fflog(f"Cache Clear Bookmarks Error: {e}")


def cache_clear_all():
    """Clear caches on an add-on update. Provider data (logins, tokens) is kept."""
    fflog('Clearing all caches')
    # cache_clear()
    cache_clear_sources()


def _get_connection(db_path=None):
    """Zwraca połączenie z bazą danych SQLite z ustawionym row_factory na słownik."""
    # Sprawdza, czy wątek został anulowany
    check_thread_cancel()
    # Używa domyślnej ścieżki, jeśli nie podano innej
    if db_path is None:
        db_path = control.cacheFile
    # Upewnia się, że katalog danych istnieje
    if not control.existsPath(control.dataPath):
        control.make_dir(control.dataPath)
    # Pobiera połączenie z menedżera połączeń, tworzy jak trzeba
    conn = connection_manager.get_connection(db_path, db_path)
    conn.row_factory = _dict_factory
    return conn


def _get_connection_cursor_search():
    conn = _get_connection(os.path.join(data_path, control.searchFile))
    return conn.cursor()


def _get_connection_cursor_views():
    conn = _get_connection(os.path.join(data_path, control.viewsFile))
    return conn.cursor()


def _get_connection_cursor_bookmarks():
    conn = _get_connection(os.path.join(data_path, control.bookmarksFile))
    return conn.cursor()

def _get_connection_cursor_downloader():
    conn = _get_connection(os.path.join(data_path, control.downloadsFile))
    return conn.cursor()

def _dict_factory(cursor, row):
    return {column[0]: value for column, value in zip(cursor.description, row)}


