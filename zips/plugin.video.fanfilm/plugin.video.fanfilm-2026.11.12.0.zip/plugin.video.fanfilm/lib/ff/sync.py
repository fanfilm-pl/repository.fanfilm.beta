"""
Sync of accounts: changes found by buckets, a cursor per (account, bucket), committed per bucket.

The type gives only `SYNC_BUCKETS` (its buckets), `sync_activities()` (cursors of its buckets), `SYNC_LISTS` (the cached
lists of its list buckets: a change only marks them stale) and `sync_bucket()` for the other buckets (gets the bucket data
and stores rows of its account, `playback.db`; the gone rows get the time of the cursor); the capability of a bucket is
the prefix of its name (`lists.watchlist` -> `lists`). A cursor is a time of the service (its last change of the bucket)
or a fingerprint of the bucket (e.g. the count and the newest item of a list: a service without activities), compared by
equality; the lists of a fingerprint bucket keep a deadline (`listcache`). The engine compares the cursors, calls the
changed buckets and stores their cursors (`accounts.db`, `sync.<bucket>` keys, reset when `playback.db` is built anew).
A failed bucket keeps its cursor (synced again next time), the other ones are committed. Then it delivers the changes
of the account waiting in `pending_change` (`record_change()`): a bucket write cancels a change older than the event of
the service (the newest event wins), the rest is sent - delivered and rejected ones leave, the ones not delivered (no
connection) wait for the next sync. The service runs it (`AccountSync`, its state
in the Home window properties - `sync_state()`), the policy is in `const.accounts.sync` and `const.accounts.pending`.
"""

from __future__ import annotations
from typing import Any, Callable, ClassVar, Collection, Iterable, Iterator, Mapping, Optional, Sequence, TYPE_CHECKING
from time import time
from typing_extensions import Literal, Protocol, TypeAlias, cast
from .accounts import Account, accounts, account_client, account_enabled, account_store, enabled_clients, delivery, limited_until, NotDelivered
from .calendar import HAS_ISO, utc_timestamp
from .db.accounts import account_data_store, reset_sync
from .db.playback import progress_changed, pending_changes, drop_pending, retry_pending, revert_change, record_change, PendingChange, ChangeAction
from .kotools import idle_time
from const import const
from cdefs import const_snapshot, const_value
from .logs import fflog, fflog_exc
from .tricks import batched
if TYPE_CHECKING:
    from .accounts import Capability
    from ..defs import MediaRef

#: Key of the time of the last check of changes (`accounts.db`; a `sync.` key: reset with the cursors).
CHECKED_KEY: str = 'sync.checked_at'
#: Key of the time of the last failed check of changes (`accounts.db`; a `sync.` key: reset with the cursors).
FAILED_KEY: str = 'sync.failed_at'
#: Home window property: the service syncs accounts now ('running'); `<prefix>.<account ID>`: the sync of the account.
SYNC_PROPERTY: str = 'fanfilm.sync'
#: Key of the one full sync on Python < 3.11 (`accounts.db`, not a `sync.` key): service times parsed before could lack
#: their zone (a UTC time kept as a local one), the full sync writes them again.
ZONE_RESYNC_KEY: str = 'fix.zone_resync'

#: Why an account does not sync (`sync_block()`, '' - it syncs): its type has no sync, it is suspended, not signed in,
#: a public one (read when needed), its daily request limit (or the one of its application) is reached, nothing to read
#: and no waiting change.
SyncBlock: TypeAlias = Literal['', 'type', 'inactive', 'unauthorized', 'public', 'limited', 'nothing']
#: State of the sync of an account in the service: none, waiting for it, syncing now.
SyncState: TypeAlias = Literal['', 'queued', 'running']
#: Bucket of changes: `<capability>[.<part>]` (see notes/accounts.md § 7).
SyncBucket: TypeAlias = Literal['progress.movie', 'progress.episode', 'watched.movie', 'watched.episode',
                                'lists.watchlist', 'lists.favorites', 'lists.collection', 'lists.user', 'lists.seen', 'ratings']


class SyncClient(Protocol):
    """API client of an account with the sync of its rows."""

    #: Buckets of the client.
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]]
    #: Interval of the sync in the service (seconds), `CONST_REF` (read at its use: `const` may be loaded again).
    SYNC_INTERVAL: ClassVar[int]
    #: Cached lists (`lib.ff.listcache` names, with their sub-lists) of the list buckets: a change only marks them stale.
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]]

    def sync_activities(self) -> Optional[Mapping[SyncBucket, str]]:
        """Return cursors of the buckets (their last change times or fingerprints), None on failure."""

    def sync_bucket(self, bucket: SyncBucket, cursor: Optional[str] = None) -> Optional[bool]:
        """
        Get the data of a bucket out of `SYNC_LISTS` and store rows of the account (the gone ones at `cursor_time(cursor)`).
        Return True if changed, None on failure. A client with list buckets only does not need it.
        """


def cursor_time(cursor: Optional[str]) -> Optional[int]:
    """Return the time of the bucket cursor (the last change of the bucket on the service, unix seconds), None if not a time."""
    if not cursor:
        return None
    try:
        return int(utc_timestamp(cursor))
    except (ValueError, TypeError, OverflowError):
        return None


def bucket_capability(bucket: SyncBucket) -> Capability:
    """Return the capability of the bucket (the prefix of its name)."""
    return cast('Capability', bucket.partition('.')[0])


def sync_block(account: Account) -> SyncBlock:
    """
    Return why the account does not sync now, '' if it does: a signed in, active account of a type with the sync, not over
    a daily request limit, with a bucket to read or a change to deliver. A suspended / signed out account keeps its waiting
    changes (delivered after it is restored / signed in), a public one is read when needed (its lists, no activities).
    """
    client = account_client(account)
    if not hasattr(client, 'sync_activities'):
        return 'type'
    if not account.active:
        return 'inactive'
    if (state := account_store.auth_state(account)) != 'authorized':
        return 'public' if state == 'public' else 'unauthorized'
    if limited_until(account.id) or limited_until(account.type.name):  # the account or its application
        return 'limited'
    capabilities: set[Capability] = {bucket_capability(bucket) for bucket in client.SYNC_BUCKETS}
    if not any(account_enabled(account, capability, 'read') for capability in capabilities) and not pending_changes(account.id):
        return 'nothing'
    return ''


def bucket_cursor(account_id: str, bucket: SyncBucket) -> Optional[str]:
    """Return the stored cursor of the bucket of the account (the last synced one), None if none."""
    cursor = account_data_store(account_id).get(f'sync.{bucket}')
    return cursor if isinstance(cursor, str) else None


def sync_client(account: Account) -> SyncClient | None:
    """Return the client of the account if the account syncs now (`sync_block()`)."""
    return None if sync_block(account) else account_client(account)


def sync_account(account: Account, client: SyncClient | None = None, *, buckets: Collection[SyncBucket] | None = None) -> bool | None:
    """Sync changed buckets of the account (only `buckets` if given). Return True if any rows changed, None if the activities failed."""
    if client is None and (client := sync_client(account)) is None:
        return False
    try:
        cursors = client.sync_activities()
    except Exception:
        fflog_exc()
        cursors = None
    store = account_data_store(account.id)
    if cursors is None:
        fflog(f'[SYNC] {account.id}: activities failed')
        store.set(FAILED_KEY, int(time()), ttl=None)
        return None
    if not HAS_ISO and not store.get(ZONE_RESYNC_KEY):
        reset_sync(account.id)  # once: the times of the service rows are written again
        store.set(ZONE_RESYNC_KEY, 1, ttl=None)
    store.set(CHECKED_KEY, int(time()), ttl=None)  # the sync is alive (see `sync_alive()`)
    changed = False

    def sync_buckets(only: Collection[SyncBucket] | None = buckets) -> None:
        """Sync the changed buckets (their cursor differs from the stored one), only the given ones if any."""
        nonlocal changed
        for bucket, cursor in cursors.items():
            key = f'sync.{bucket}'
            if (only is not None and bucket not in only) or not account_enabled(account, bucket_capability(bucket), 'read') \
                    or store.get(key) == cursor:
                continue
            try:
                if (name := client.SYNC_LISTS.get(bucket)) is not None:
                    from .listcache import mark_stale
                    mark_stale(account.id, name)  # fetched on the next read
                    result = False                # no rows changed
                else:
                    result = client.sync_bucket(bucket, cursor)
            except Exception:
                fflog_exc()
                result = None
            fflog(f'[SYNC] {account.id}: {bucket} {cursor} -> {result}')
            if result is None:
                continue  # the cursor is kept: synced again next time
            store.set(key, cursor, ttl=None)
            changed |= result

    sync_buckets()
    if buckets is None:  # a full sync (the service), not a bucket read of the plugin (the ratings window)
        synced = {bucket for bucket, cursor in cursors.items() if store.get(f'sync.{bucket}') == cursor}
        deliver_pending(account, client)
        # the buckets of the changes the service has not got (their cursors removed): the service state of their rows now
        # (the same requests as the next sync, the cursors of the activities above; a failed bucket waits for it)
        if again := {bucket for bucket in synced if store.get(f'sync.{bucket}') is None}:
            sync_buckets(again)
    if changed:
        progress_changed()
    return changed


def _remove_playback(client: Any, ref: MediaRef) -> None:
    """
    Remove the resume point of the media on the service of the client (in `delivery()`). One the service has not (404:
    ended or removed elsewhere, nothing playing) is removed: the rest of the change goes on (e.g. the history of 'unwatched').
    """
    try:
        client.remove_playback_ref(ref)
    except NotDelivered as exc:
        if exc.status != 404:
            raise


#: Actions of waiting changes sent in batches (one write of many media) - the services take many in one history write.
BATCH_ACTIONS: frozenset[ChangeAction] = frozenset(('watched', 'unwatched'))


def _batch_action(client: Any, action: str) -> bool:
    """Return True if the changes of the action go to the client in batches (a history write, the resume points of WeTrakr)."""
    return action in BATCH_ACTIONS or (action == 'pause' and hasattr(client, 'set_playback_refs'))


def _batches(client: Any, changes: Sequence[PendingChange]) -> Iterator[Sequence[PendingChange]]:
    """
    Yield the changes (the oldest first) in batches: neighbouring changes of the same action (the order of the changes
    stays: a show watched, then its episode unwatched), up to `BATCH_LIMIT` of the client; one change for other actions.
    """
    limit: int = getattr(client, 'BATCH_LIMIT', 1)
    batch: list[PendingChange] = []
    for change in changes:
        if batch and (change.action != batch[0].action or len(batch) >= limit or not _batch_action(client, change.action)):
            yield batch
            batch = []
        batch.append(change)
    if batch:
        yield batch


def _send_batch(client: SyncClient, changes: Sequence[PendingChange]) -> bool:
    """
    Send changes of one action to the service of the client (in `delivery()`: a failed request raises `NotDelivered`).
    Return True if the service found every media (False: some unknown there, their buckets are synced again).
    """
    cl, action = cast(Any, client), changes[0].action
    if action == 'watched':
        # a season / a show may send its episodes (`delivery_refs()`), more than a batch of changes, or nothing
        items = [(ref, change.at) for change in changes for ref in change.delivery_refs()]
        found = all([cl.add_history_refs(part) for part in batched(items, getattr(cl, 'BATCH_LIMIT', 1))])
        if not getattr(cl, 'HISTORY_ENDS_PLAYBACK', False):  # else the service ended them with the history
            for change in changes:
                if change.ends_playback:  # watched a paused media: its resume point on the service ends
                    _remove_playback(cl, change.ref)
        return found
    if action == 'unwatched':
        for change in changes:
            if change.ends_playback:
                _remove_playback(cl, change.ref)
        return cl.remove_history_refs([change.ref for change in changes])
    if action == 'pause':
        if hasattr(cl, 'set_playback_refs'):  # resume points with their own time
            return cl.set_playback_refs([(change.ref, change.progress or 0, change.at) for change in changes])
        for change in changes:
            cl.scrobble_ref('pause', change.ref, change.progress or 0)
        return True
    for change in changes:  # reset_progress
        if change.ends_playback:
            _remove_playback(cl, change.ref)
    return True


def deliver_pending(account: Account, client: SyncClient) -> int:
    """
    Send the changes of the account waiting for the delivery (after its buckets: a change older than an event of the
    service is cancelled there), in batches (`_batches()`), in order: a batch not delivered (no connection, a server error,
    an error of the client) stops the delivery, it and the next ones are left for the next sync. Delivered, rejected (its
    bucket synced again), older than `const.accounts.pending.max_age`, failing longer than `const.accounts.pending.max_retry`
    or of a capability the account does not write any more (given up, its bucket synced again) - removed; a batch with
    media unknown to the service - delivered, its buckets synced again. A change the service has not got (given up,
    rejected, unknown there) is undone in the rows of the account (`revert_change()`). Return the number of the changes left.
    """
    now = utc_timestamp()
    store = account_data_store(account.id)
    reverted = False

    def not_delivered(change: PendingChange) -> None:
        """The service has not got the change: undo it in the rows, sync its bucket again, remove it."""
        nonlocal reverted
        reverted |= revert_change(change)
        store.delete(f'sync.{change.bucket}')
        drop_pending(change)

    try:
        return _deliver_ready(account, client, now=now, not_delivered=not_delivered)
    finally:
        if reverted:
            progress_changed()


def _deliver_ready(account: Account, client: SyncClient, *, now: float, not_delivered: Callable[[PendingChange], None]) -> int:
    """Send the waiting changes of the account (`deliver_pending()`), the ones the service has not got go to `not_delivered`."""
    ready: list[PendingChange] = []
    for change in pending_changes(account.id):
        if not account_enabled(account, cast('Capability', change.capability), 'write'):
            reason = 'no write'
        elif now - (change.queued_at or change.at) > const.accounts.pending.max_age:
            reason = 'too old'
        elif change.failed_at and now - change.failed_at > const.accounts.pending.max_retry:
            reason = f'not delivered for {int(now - change.failed_at)} s'
        else:
            ready.append(change)
            continue
        fflog(f'[SYNC] {account.id}: {change.action} {change.ref:a} given up: {reason}, its bucket {change.bucket} is synced again')
        not_delivered(change)
    done = 0
    for batch in _batches(client, ready):
        what = f'{batch[0].action} {batch[0].ref:a}' + (f' (+{len(batch) - 1})' if len(batch) > 1 else '')
        failure = ''
        try:
            with delivery():
                found = _send_batch(client, batch)
        except NotDelivered as exc:
            if exc.transient:
                failure = str(exc.status)
            else:
                fflog(f'[SYNC] {account.id}: {what} given up: rejected ({exc.status}), its buckets are synced again')
                found = False
        except Exception as exc:  # an error of the client (e.g. a broken answer): sent again as a transient one
            fflog_exc()
            failure = type(exc).__name__
        else:
            fflog(f'[SYNC] {account.id}: {what} delivered' + ('' if found else ', some media unknown there: its buckets are synced again'))
        if failure:  # the next changes wait for it (their order: a show watched, then its episode unwatched)
            fflog(f'[SYNC] {account.id}: {what} not delivered ({failure}), try {batch[0].tries + 1}, the next changes wait')
            for change in batch:
                retry_pending(change)
            return len(ready) - done
        for change in batch:
            if found:
                drop_pending(change)
            else:
                not_delivered(change)
        done += len(batch)
    return 0


def sync_due(account: Account, client: SyncClient | None = None) -> bool:
    """
    Return True if the cyclic sync of the service should check the account now: its interval (`SYNC_INTERVAL`) passed since
    its last check, within half of the cycle (`const.accounts.sync.interval`), or it was never checked.
    """
    if client is None and (client := account_client(account)) is None:
        return False
    checked = account_data_store(account.id).get(CHECKED_KEY)
    snap = const_snapshot()  # both intervals of one const
    return not isinstance(checked, int) or checked <= time() - const_value(client.SYNC_INTERVAL, snap) + snap.accounts.sync.interval / 2


def kodi_idle() -> bool:
    """
    Return True if nobody uses Kodi (`idle_time()`: no input for the cyclic interval, nothing plays) and the cyclic sync waits
    then (`const.accounts.sync.idle_interval`).
    """
    return bool(const.accounts.sync.idle_interval) and idle_time() >= const.accounts.sync.interval


def sync_interval(client: SyncClient) -> int:
    """Return the current interval of the sync of the account type: its own one, while Kodi is idle at least the idle one."""
    interval = const_value(client.SYNC_INTERVAL)
    if kodi_idle():
        return max(interval, const.accounts.sync.idle_interval)
    return interval


def sync_alive(account: Account, client: SyncClient) -> bool:
    """Return True if the sync of the account checked its changes within two current intervals (the service syncs it)."""
    checked = account_data_store(account.id).get(CHECKED_KEY)
    return isinstance(checked, int) and checked > time() - 2 * sync_interval(client)


def sync_accounts(accs: Iterable[Account] | None = None) -> dict[str, bool | None]:
    """Sync all accounts syncing now (or the given ones). Return the result of each synced one (`sync_account()`) by its ID."""
    return {acc.id: sync_account(acc, client) for acc in (accounts() if accs is None else accs) if (client := sync_client(acc)) is not None}


def sync_state(account_id: str | None = None) -> SyncState:
    """Return the state of the sync of the account in the service (None: of the service, 'running' or '')."""
    from xbmcgui import Window
    from .control import HOME_WINDOW
    return cast('SyncState', Window(HOME_WINDOW).getProperty(SYNC_PROPERTY if account_id is None else f'{SYNC_PROPERTY}.{account_id}'))


def set_sync_state(account_id: str | None, state: SyncState) -> None:
    """Set the state of the sync of the account (None: of the service) - the service does it, the windows show it."""
    from xbmcgui import Window
    from .control import HOME_WINDOW
    key = SYNC_PROPERTY if account_id is None else f'{SYNC_PROPERTY}.{account_id}'
    if state:
        Window(HOME_WINDOW).setProperty(key, state)
    else:
        Window(HOME_WINDOW).clearProperty(key)


def send_change(action: ChangeAction, ref: MediaRef, *, at: Optional[float] = None, progress: Optional[float] = None,
                episodes: Optional[Sequence[MediaRef]] = None, if_differs: bool = False) -> bool:
    """
    Send a change (FF, Kodi, the player) to the accounts writing it: recorded at once (their rows, the waiting change -
    `record_change()`), delivered by the sync woken now (the service, or directly without it - CLI). A show / season changes
    its `episodes` (default: its aired ones, `ffinfo.aired_episode_refs()`). With `if_differs` (a state of Kodi video DB
    to align) only the accounts with another row state get it. Return True if any account got it.
    """
    capability = 'progress' if action in ('pause', 'reset_progress') else 'watched'
    account_ids = [client.account.id for client in enabled_clients(capability, 'write') if hasattr(client, 'sync_bucket')]
    if episodes is None and account_ids and ref.is_container:
        from .info import ffinfo
        episodes = ffinfo.aired_episode_refs(ref)
    if not record_change(action, ref, account_ids=account_ids, at=at, progress=progress, episodes=episodes or (), if_differs=if_differs):
        return False
    from ..service import SERVICE
    if SERVICE:
        from ..service.main import works
        if works.account_sync is not None:
            works.account_sync.deliver_start(account_ids)
            return True
    from ..service.client import service_client
    service_client.sync_wake()  # the service, or the fake client in CLI without it: directly
    return True


def syncing_accounts() -> list[Account]:
    """Return accounts syncing now."""
    return [acc for acc in accounts() if sync_client(acc) is not None]
