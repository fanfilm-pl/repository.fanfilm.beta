
from __future__ import annotations
from enum import Enum, IntEnum
from typing import Sequence, Iterator, NamedTuple, TYPE_CHECKING, cast
from typing import List, Dict  # py3.8, class bases
from attrs import frozen, field
from .types import JsonData
from .item import ArtLabel
from ..defs import MediaRef
from .settings import settings
from ..kolang import L
from const import const

if TYPE_CHECKING:
    from .item import ArtValues
    from ..defs import FFRef


class ArtLang(Enum):
    NO = 0
    YES = 1
    FANART = 2
    EMPTY = 3


class ArtSortByKey(NamedTuple):
    """Sort images by key SettingsEnum. Must match to setting `image.sort_by`."""

    vote_average: Sequence[str]
    vote_count: Sequence[str]


class ArtQuality(IntEnum):
    """Image quality SettingsEnum. Must match to setting `image.quality`."""
    LOW = 0
    HIGH = 1
    BEST = 2

    THUMB = LOW


class ArtQualityParam(NamedTuple):
    """An image quality SettingsEnum. Must match to ArtQuality and setting `image.quality`."""

    low: str
    high: str
    best: str


@frozen
class ArtName:
    key: str
    quality: ArtQualityParam
    # thumb: str = field(default='w500', kw_only=True)


@frozen
class ArtDef:
    lang_type: ArtLang
    sources: Sequence[ArtName]

    def langs(self, *, yes: Sequence[str | None], no: Sequence[str | None] = (None,), skip_fanart: bool = False) -> Sequence[str | None]:
        """Get list of languages for this art definition."""
        if self.lang_type is ArtLang.NO:
            return no
        if self.lang_type is ArtLang.YES:
            return yes
        if self.lang_type is ArtLang.FANART:
            return [] if skip_fanart else no
        # ArtLang.EMPTY
        return []


@frozen(kw_only=True)
class ArtSettings:
    """Cache for settings for TMDB."""
    lang: str
    quality: ArtQuality
    sort_by: int


@frozen(kw_only=True)
class ImageInfo:
    """Information about an image."""

    url: str
    lang: str = ''
    width: int = 0
    height: int = 0
    vote_average: float = 0.0
    vote_count: int = 0
    _thumb: str = ''

    def __bool__(self) -> bool:
        return bool(self.url)

    @property
    def thumb(self) -> str:
        """Get thumbnail URL."""
        return self._thumb or self.url

    @property
    def is_landscape(self) -> bool:
        """Return True if image is landscape."""
        return self.width >= self.height

    @property
    def is_portrait(self) -> bool:
        """Return True if image is portrait."""
        return self.height > self.width

    @property
    def aspect_ratio(self) -> float:
        """Get aspect ratio (width / height)."""
        return self.width / self.height if self.height != 0 else 0.0

    def art(self, art_type: ArtLabel, ref: FFRef | None = None, *, thumb: str | None = None) -> ArtValues:
        """Return art dict for Kodi."""
        art: dict[ArtLabel, str] = {art_type: self.url}
        if thumb is not None:
            art['thumb'] = thumb
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            is_episode = bool(ref and ref.ref.is_episode)
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        return art


class ArtInfo(Dict[ArtLabel, List[ImageInfo]]):
    """Information about images. Result of ArtService.parse_arts()."""

    def art(self, ref: FFRef | None = None, *, thumb: str | None = None) -> ArtValues:
        """Return art dict for Kodi."""
        art: dict[ArtLabel, str] = {key: images[0].url for key, images in self.items() if images}
        if thumb is not None:
            art['thumb'] = thumb
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            is_episode = bool(ref and ref.ref.is_episode)
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        return art

    def all_images(self) -> Iterator[ImageInfo]:
        """Iterate over all images."""
        for images in self.values():
            for img in images:
                yield img

    def all_urls(self) -> Iterator[str]:
        """Iterate over all image URLs."""
        for images in self.values():
            for img in images:
                yield img.url


class Art:

    def __init__(self) -> None:
        #: Setting cache.
        self._settings: ArtSettings | None = None

    def reset(self) -> None:
        """Reset settings."""
        self._settings = None

    @property
    def settings(self, lang: str | None = None) -> ArtSettings:
        """Get settings."""
        if self._settings is None:
            from .control import apiLanguage
            self._settings = ArtSettings(
                lang=apiLanguage().get('tmdb', 'pl-PL'),
                quality=ArtQuality(settings.getInt('image.quality')),
                sort_by=settings.getInt('image.sort_by'),
            )
        return self._settings

    @settings.deleter
    def settings(self) -> None:
        self._settings = None

    def parse_art(self, *,
                  images: JsonData | None = None,
                  item: JsonData | None = None,
                  translation_order: Sequence[str] | None,
                  ref: MediaRef | None = None,
                  quality: ArtQuality | None = None
                  ) -> dict[str, str]:
        """Parse TMDB images and retrun kodi art dict."""

        def img_sort_key(im: JsonData):
            return tuple(-float(im[key]) for key in sort_by)

        if quality is None:
            art_settings = self.settings
        else:
            from .control import apiLanguage
            art_settings = ArtSettings(
                lang=apiLanguage().get('tmdb', 'pl-PL'),
                quality=quality,
                sort_by=settings.getInt('image.sort_by'),
            )

        is_episode = bool(ref and ref.is_episode)
        if images is None:
            if item is None:
                return {}
            images = item.get('images') or {}
        if translation_order is None:
            translation_order = (art_settings.lang, 'en-US', 'en-GB', 'en', 'xx-XX', 'xx', 'null')
        art_langs = (*dict.fromkeys(loc.partition('-')[0] for loc in translation_order), *(None,))
        no_langs = TmbdArtService.no_langs
        sort_by = TmbdArtService.sort_by[art_settings.sort_by]
        quality = art_settings.quality
        art: dict[str, str] = {}
        image_url = 'https://image.tmdb.org/t/p/{width}{path}'
        lang_key = TmbdArtService.lang_key
        for aname, artdef in TmbdArtService.art_names.items():
            for src in artdef.sources:
                width = src.quality[quality]
                ilist = images.get(src.key)
                if ilist:
                    ilist = [item for item in ilist if not item['file_path'].endswith('.svg')]
                    # Przeglądając **po kolei** języki sortujemy po głosowaniu i wielkości (o ile klucze podane).
                    # reversed() daje nam ostatni z pasujących obrazów (oczywiście wśród `sort_by`), bo liczymy, że ten będzie lepszy.
                    best = [img for lang in artdef.langs(yes=art_langs, no=no_langs, skip_fanart=is_episode)
                            for img in sorted((im for im in reversed(ilist) if im.get(lang_key) == lang), key=img_sort_key)]
                    if best:
                        im = best[0]
                        art[aname] = image_url.format(width=width, path=im['file_path'])
                        break
        # see issue #132 (fake thumb)
        if const.indexer.art.fake_thumb and 'thumb' not in art:
            if img := art.get('landscape' if is_episode else 'poster'):
                art['thumb'] = img
        if item and (poster := item.get('poster_path')):
            art.setdefault('poster', image_url.format(width='w780', path=poster))
        if item and (landscape := item.get('still_path')):
            art.setdefault('landscape', image_url.format(width='w1280', path=landscape))
        if item and (backdrop := item.get('backdrop_path')):
            backdrop = image_url.format(width='w1280', path=backdrop)
            art.setdefault('fanart', backdrop)
            art.setdefault('landscape', backdrop)
        if item and (logo := item.get('logo_path')):
            art.setdefault('clearlogo', image_url.format(width='original', path=logo))
            art.setdefault('thumb', image_url.format(width='w500', path=logo))
        return art

    def parse_arts(self, *,
                   images: JsonData | None = None,
                   item: JsonData | None = None,
                   translation_order: Sequence[str] | None,
                   ref: MediaRef | None = None,
                   quality: ArtQuality | None = None
                   ) -> ArtInfo:
        """Parse TMDB images and retrun kodi art dict."""

        def img_sort_key(im: JsonData):
            return tuple(-float(im[key]) for key in sort_by)

        if quality is None:
            art_settings = self.settings
        else:
            from .control import apiLanguage
            art_settings = ArtSettings(
                lang=apiLanguage().get('tmdb', 'pl-PL'),
                quality=quality,
                sort_by=settings.getInt('image.sort_by'),
            )

        is_episode = bool(ref and ref.is_episode)
        if images is None:
            if item is None:
                return {}
            images = item.get('images') or {}
        if translation_order is None:
            translation_order = (art_settings.lang, 'en-US', 'en-GB', 'en', 'xx-XX', 'xx', 'null')
        art_langs = (*dict.fromkeys(loc.partition('-')[0] for loc in translation_order), *(None,))
        no_langs = TmbdArtService.no_langs
        sort_by = TmbdArtService.sort_by[art_settings.sort_by]
        quality = art_settings.quality
        art = ArtInfo()
        image_url = 'https://image.tmdb.org/t/p/{width}{path}'
        lang_key = TmbdArtService.lang_key
        for aname, artdef in TmbdArtService.art_names.items():
            for src in artdef.sources:
                width = src.quality[quality]
                thumb = src.quality[ArtQuality.THUMB]
                ilist = images.get(src.key)
                if ilist:
                    ilist = [item for item in ilist if not item['file_path'].endswith('.svg')]
                    # Przeglądając **po kolei** języki sortujemy po głosowaniu i wielkości (o ile klucze podane).
                    # reversed() daje nam ostatni z pasujących obrazów (oczywiście wśród `sort_by`), bo liczymy, że ten będzie lepszy.
                    best = [img for lang in artdef.langs(yes=art_langs, no=no_langs, skip_fanart=is_episode)
                            for img in sorted((im for im in reversed(ilist) if im[lang_key] == lang), key=img_sort_key)]
                    if best:
                        art[aname] = [ImageInfo(url=image_url.format(width=width, path=im['file_path']),
                                                thumb=image_url.format(width=thumb, path=im['file_path']),
                                                lang=im.get(lang_key) or '',
                                                width=im.get('width') or 0,
                                                height=im.get('height') or 0,
                                                vote_average=float(im.get('vote_average') or 0.0),
                                                vote_count=int(im.get('vote_count') or 0)
                                                )
                                      for im in best]
        return art


class ArtService:
    pass


class TmbdArtService(ArtService):
    """The Movie Database service."""

    # Opisy zmiennych są w ArtService

    movies_url = "https://api.themoviedb.org/3/movie/{media_id}/images?api_key={tm_user}"
    tvshows_url = "https://api.themoviedb.org/3/tv/{media_id}/images?api_key={tm_user}"
    image_url: str = "https://image.tmdb.org/t/p/{quality}{path}"

    lang_key = 'iso_639_1'
    no_langs = ('00', 'xx', None)
    sort_by = ArtSortByKey(['vote_average'], ['vote_count'])
    art_names: dict[ArtLabel, ArtDef] = {
        'fanart':    ArtDef(ArtLang.FANART, (  # no-lang
            ArtName('backdrops', ArtQualityParam('w780', 'w1280', 'w1280')),
            ArtName('stills', ArtQualityParam('w780', 'w1280', 'w1280')),
        )),
        'landscape': ArtDef(ArtLang.YES, (
            ArtName('backdrops', ArtQualityParam('w780', 'w1280', 'original')),
            ArtName('stills', ArtQualityParam('w780', 'w1280', 'original')),
        )),
        'poster':    ArtDef(ArtLang.YES, (
            ArtName('posters', ArtQualityParam('w500', 'w780', 'w780')),
        )),
        'clearlogo': ArtDef(ArtLang.YES, (
            ArtName('logos', ArtQualityParam('w500', 'w780', 'original')),
        )),
        'actor':    ArtDef(ArtLang.NO, (
            ArtName('profiles', ArtQualityParam('w500', 'w780', 'original')),
        )),
    }

    # TMDB image sizes (see https://api.themoviedb.org/3/configuration)
    # "images": {
    #   "base_url": "http://image.tmdb.org/t/p/",
    #   "secure_base_url": "https://image.tmdb.org/t/p/",
    #   "backdrop_sizes": [ "w300", "w780", "w1280", "original" ],
    #   "logo_sizes":     [ "w45", "w92", "w154", "w185", "w300", "w500", "original" ],
    #   "poster_sizes":   [ "w92", "w154", "w185", "w342", "w500", "w780", "original" ],
    #   "profile_sizes":  [ "w45", "w185", "h632", "original" ],
    #   "still_sizes":    [ "w92", "w185", "w300", "original" ]
    # }


@frozen
class ArtTypeLabel:
    """The labels of an art type: one image (a gallery item, a folder) and the images (a gallery title)."""

    #: One image, e.g. "Poster" (a gallery item "Poster 3").
    one: str
    #: The images, e.g. "Posters" (a gallery title "Matrix – Posters").
    many: str


#: The labels of the art types (the actor art type is the photo of a person).
art_type_translations: dict[ArtLabel, ArtTypeLabel] = {
    'thumb': ArtTypeLabel(one=L(30703, 'Picture'), many=L(30374, 'Pictures')),
    'fanart': ArtTypeLabel(one=L(30704, 'Fanart'), many=L(30487, 'Fanarts')),
    'landscape': ArtTypeLabel(one=L(30705, 'Landscape'), many=L(30488, 'Landscapes')),
    'poster': ArtTypeLabel(one=L(30706, 'Poster'), many=L(30494, 'Posters')),
    'clearlogo': ArtTypeLabel(one=L(30707, 'Logo'), many=L(30496, 'Logos')),
    'actor': ArtTypeLabel(one=L(30538, 'Photo'), many=L(30572, 'Photos')),
}


def art_type_label(art_type: ArtLabel) -> ArtTypeLabel:
    """Return the labels of the art type, its name if it has none."""
    return art_type_translations.get(art_type) or ArtTypeLabel(one=art_type, many=art_type)


def list_art(art: ArtValues) -> ArtValues:
    """Return the art of a list of a service (its own image or the images of its first item): a poster is the thumb too (`const.indexer.art.fake_thumb`)."""
    if const.indexer.art.fake_thumb and (poster := art.get('poster')):
        return {'thumb': poster, **art}
    return art


def tmdb_list_art(item: JsonData) -> ArtValues:
    """Return the art of a list of a service from the TMDB paths of its first item (`poster_path`, `backdrop_path`)."""
    return list_art(cast('ArtValues', Art().parse_art(item=item, translation_order=None)))
