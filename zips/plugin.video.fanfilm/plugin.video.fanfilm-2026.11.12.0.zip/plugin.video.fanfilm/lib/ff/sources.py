# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import hashlib
import json
import random
import re
import sys
from time import monotonic
from contextlib import suppress, contextmanager
from threading import Lock, Event
from enum import IntEnum
from html import unescape
from itertools import chain
from collections import Counter
from typing import Any, Collection, Sequence, Iterable, Iterator, Mapping, Callable, ClassVar, cast, TYPE_CHECKING
from typing_extensions import NotRequired, Unpack, Protocol, Literal, TypeAlias
from urllib.parse import unquote
from attrs import define, field, fields, frozen
import xbmc
from ..ff import (
    # apis,
    # cache,
    cleantitle,
    client,
    control,
    debrid,
)
from ..windows.sources import SourceDialog, RescanSources, EditDialog, auto_color
from ..sources.source_settings import search_limits, source_setting
from .info import ffinfo
from .item import FFItem
from .tricks import evolve, MISSING
from .types import EllipsisType
from ..defs import MediaRef, MediaType
from . import player
from .db import state
from .db.search import sources_edit_db
from .db import sources as sources_db
from .threads import ThreadCanceled, CancelScope, check_thread_cancel, current_scope
from ..info import script_aborted
from ..sources import SourceItem, SourceMeta, Source, SourceSearchOverride, scan_providers, clear_source_modules, title_aliases, search_query
from ..sources import Resolvability, ResolveRoute, IncompleteResult, SearchCache, search_cache
from ..sdk.protocol import ResolveResult, ResolveSubtitle, resolve_result
from ..sources import addon_prefixes
from ..sources.natives import module_searched, native_catalog, provider_value
from ..sdk.protocol.item import DYNAMIC_KEYS, magnet_hash
from ..sources import is_provider_addon_protocol, is_provider_new_protocol, has_apply_dynamic, unwrap_provider, provider_supports, bind_provider
from .logs import fflog, fflog_exc, log, LOGINFO, LOGDEBUG
from .source_facts import facts_text, is_multi, audio_language
from .source_filters import CurrentSelection, current_selection, current_state, user_languages, item_media, selected_sources, simple_view
from .source_keys import SelectionState, compile_selection
from .workers import Thread
from .kotools import xsleep
from .. import FAKE
from ..kolang import L
from cdefs import SourceAttribute, SourceSearchProgressStyle
from const import const
if TYPE_CHECKING:
    from typing_extensions import Generator
    from datetime import date as dt_date
    from .item import FFEpisodeGroup
    from ..sources import ProviderModule, SourceResolveKwargs, ProviderProtocol, SourceTitleAlias
    from ..defs import MediaCategory
    from cdefs import ResolveKind, PackKind
    from .db.sources import SourceCacheRow
    from ..sources.addons.external import NodeValue

#: Lazy imported resolveurl module (False = not tried yet, None = not available).
_resolveurl: Any = False


def get_resolveurl() -> Any:
    """Return resolveurl module or None. It is imported on demand, the import takes 0.3-1 s and blocks the play start."""
    global _resolveurl
    if _resolveurl is False:
        try:
            import resolveurl
            _resolveurl = resolveurl
        except Exception as exc:
            print(exc)
            _resolveurl = None
    return _resolveurl


#: Premium hosts (debrid only), the old API providers get them (`hostprDict`).
PREMIUM_HOSTS: tuple[str, ...] = ('1fichier.com', 'rapidgator.net', 'rg.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net')


def resolve_order() -> dict[ResolveKind, int]:
    """Return the preference of the kinds of ways (`const.sources.resolve.order`): a kind by its place."""
    return {kind: i for i, kind in enumerate(const.sources.resolve.order)}


#: The rank of a debrid way by its cache state (`ResolveRoute.cached`): cached first, not known, not cached last.
CACHED_RANK: dict[bool | None, int] = {True: 0, None: 1, False: 2}


def source_language(src: Source) -> str:
    """
    Return the language of a source: the one of its audio in the facts (a lektor, 'ENG', a Polish release group..., else the
    provider language; a torrent provider says always 'en'), subtitles do not give it ('napisy PL' of a Polish provider:
    unknown, ''); a provider language the facts do not know (no audio, no subtitles) is kept.
    """
    if (lang := audio_language(src.facts.get('audio', ()))) or src.facts.get('subtitles'):
        return lang
    return src.get('language', '').lower()


def torrent_hash(src: Source) -> str | None:
    """Return the info hash of a torrent source (the provider gave it or its magnet has it), None if it is not a torrent."""
    return src.meta.get('hash') or magnet_hash(src.url)


def needs_debrid(url: str, src: Source) -> bool:
    """Check if only a debrid opens a link of the source: `debridonly`, a magnet, a premium hosting."""
    host = src.hosting.lower()
    if host.startswith('www.'):
        host = host[4:]
    return bool(src.meta.get('debridonly')) or url.lower().startswith('magnet:') or host in PREMIUM_HOSTS


def played_as_is(url: str, src: Source) -> bool:
    """
    Check if a link of the source no resolver knows may be played as it is (the provider gave the stream): not one only
    a debrid opens (`needs_debrid()`), not a plugin (its own way), not premium (only the account of the provider opens it).
    """
    return not (needs_debrid(url, src) or src.meta.get('premium') or url.lower().startswith('plugin://'))

#: Supported hosts of a plugin call: (`lib.info.run_count`, hosts), see `supported_hosts()`.
_supported_hosts: tuple[int, list[str]] = (-1, [])


def supported_hosts() -> list[str]:
    """
    Return the hosts the resolvers support (resolveurl, and the own resolvers if `const.sources.local_resolvers`), the old
    API providers get them (`hostDict`). Made once per plugin call: the first call is in the main thread (the search
    start), it asks Kodi (the resolveurl version).
    """
    global _supported_hosts
    from .. import info
    run, hosts = _supported_hosts
    if run == info.run_count:
        return hosts
    hosts = []
    try:
        hosts = resolveurl_hosts()
    except Exception:
        fflog_exc()
    # hosts of the own resolvers: scrapers see them even if resolveurl drops or renames its plugin
    if const.sources.local_resolvers:
        try:
            from ..resolvers import get_local_domains
            hosts = list(dict.fromkeys(chain(hosts, get_local_domains())))
        except Exception:
            fflog_exc()
    _supported_hosts = (info.run_count, hosts)
    return hosts


def _resolveurl_cached(name: str, compute: Callable[[], list[str]]) -> list[str]:
    """
    Return the `compute()` result kept in the FF data file `name`: it is valid until resolveurl (its version or its
    settings) changes, so resolveurl does not have to be imported before the search.
    """
    from pathlib import Path
    from xbmc import getInfoLabel
    from xbmcvfs import translatePath
    from .filecache import cached_json, mtime_stamp

    # no xbmcaddon.Addon() here (Kodi keeps leftover Addon objects), an empty version: resolveurl is not installed
    version = getInfoLabel('System.AddonVersion(script.module.resolveurl)')
    settings_path = Path(translatePath('special://profile/addon_data/script.module.resolveurl/settings.xml'))
    stamp = f'{version}:{mtime_stamp([settings_path])}' if version else ''
    return cached_json(Path(control.dataPath) / name, stamp, compute)


def resolveurl_hosts() -> list[str]:
    """Return all domains (hosts) of all enabled resolveurl resolvers (no generic '*', no duplicates), see `_resolveurl_cached()`."""

    def hosts() -> list[str]:
        if (resolveurl := get_resolveurl()) is None:
            return []
        # wszyskie demeny (hosty) z wszystkich klas resolvera (z pominięciem generycznego '*'), bez duplikatów
        host_list: list[ResolverClass] = resolveurl.relevant_resolvers(order_matters=True)
        return list(dict.fromkeys(domain.lower() for cls in host_list for domain in cls.domains if domain != '*'))

    return _resolveurl_cached('resolveurl_hosts.json', hosts)


def debrid_names() -> list[str]:
    """Return the names of the enabled debrid resolvers (resolveurl universal ones), see `_resolveurl_cached()`."""
    return _resolveurl_cached('debrid_names.json', lambda: [resolver.name for resolver in debrid.get_resolvers()])


@define
class ResolveMap:
    """
    The ways to open the sources of one search (`Resolvability`): every resolver, debrid and add-on is asked once.

    The hosts of the FanFilm and resolveurl resolvers come from their file caches; the debrids (they need resolveurl)
    are asked only if one is enabled. On the list it is an estimate by the hosting: `provider.resolve()` may change the URL.
    """

    #: Domains of the FanFilm resolvers (`const.sources.local_resolvers`).
    ff_domains: tuple[str, ...] = ()
    #: Domains of the resolveurl host resolvers (no universal ones).
    resolveurl_domains: tuple[str, ...] = ()
    #: Names of the enabled debrids (resolveurl universal resolvers).
    debrid_names: tuple[str, ...] = ()
    #: Preference of the kinds of ways (`const.sources.resolve.order`), a kind not listed is not used.
    order: dict[ResolveKind, int] = field(factory=resolve_order)
    #: The debrid resolvers (created on the first need).
    _debrids: list[Any] | None = None
    #: Debrid answers by (the debrid name, the host or `magnet:`).
    _debrid_valid: dict[tuple[str, str], bool] = field(factory=dict)
    #: The cached torrent hashes by the debrid name (`check_cache()`; a debrid not asked or not telling is not here).
    _cached: dict[str, set[str]] = field(factory=dict)
    #: The hashes the debrids were asked about (`check_cache()`).
    _asked: set[str] = field(factory=set)
    #: Matches of the hostings by (the kind of the resolvers, the host).
    _hosts: dict[tuple[ResolveKind, str], bool] = field(factory=dict)
    #: Enabled state of the add-ons of `plugin://` sources by ID.
    _plugins: dict[str, bool] = field(factory=dict)

    @classmethod
    def create(cls) -> ResolveMap:
        """Return the map of the current resolvers (cheap: file caches, resolveurl imported only for a debrid)."""
        ff_domains: tuple[str, ...] = ()
        if const.sources.local_resolvers:
            try:
                from ..resolvers import get_local_domains
                ff_domains = tuple(domain.lower() for domain in get_local_domains())
            except Exception:
                fflog_exc()
        names: tuple[str, ...] = ()
        try:
            names = tuple(debrid_names())
        except Exception:
            fflog_exc()
        return cls(ff_domains=ff_domains, resolveurl_domains=tuple(resolveurl_hosts()), debrid_names=names)

    def _host_in(self, kind: ResolveKind, domains: tuple[str, ...], host: str) -> bool:
        """Return True if the hosting is one of the domains of the resolvers (the match of `source_utils.is_host_valid()`)."""
        if (found := self._hosts.get((kind, host))) is None:
            found = self._hosts[kind, host] = bool(host) and any(host in domain for domain in domains)
        return found

    def _debrid_resolvers(self) -> list[Any]:
        """Return the enabled debrid resolvers (created on the first need, none if no debrid is enabled)."""
        if not self.debrid_names:
            return []
        if self._debrids is None:
            try:
                self._debrids = list(debrid.get_resolvers())
            except Exception:
                fflog_exc()
                self._debrids = []
        return self._debrids

    def check_cache(self, sources: Sequence[Source]) -> None:
        """
        Ask the debrids which tell it which torrents of the sources they have cached: one question a debrid for all
        hashes not asked about yet, the debrids at once (in threads), each in its time limit (`const.sources.resolve.cache_timeout`).
        """
        if not (hashes := sorted({btih for src in sources if (btih := torrent_hash(src)) and btih not in self._asked})):
            return
        self._asked.update(hashes)
        resolvers = [res for res in self._debrid_resolvers() if (srv := debrid.debrid_service(res.name)) is not None and srv.cached is not None]

        def ask(resolver: Any) -> None:
            if (found := debrid.cached_hashes(resolver, hashes)) is not None:
                self._cached.setdefault(resolver.name, set()).update(found)

        threads = [Thread(target=ask, args=(res,), name=f'debrid-cache-{res.name}') for res in resolvers]
        for th in threads:
            th.start()
        for th in threads:
            th.join()
        if self._cached:
            fflog(f'[SOURCES] debrid cache of {len(hashes)} torrents: {", ".join(f"{name} {len(found)}" for name, found in self._cached.items())}')

    def tells_cache(self) -> bool:
        """Return True if a debrid tells which torrents it has cached."""
        return any((srv := debrid.debrid_service(res.name)) is not None and srv.cached is not None for res in self._debrid_resolvers())

    def asked(self, btih: str) -> bool:
        """Return True if the debrids were asked about the torrent."""
        return btih in self._asked

    def _debrid_routes(self, url: str, host: str, btih: str | None = None) -> Iterator[ResolveRoute]:
        """Yield the debrids which open the URL (a magnet) or the hosting; a torrent (`btih`) cached by a debrid that tells it is marked."""
        magnet = url.lower().startswith('magnet:')
        for resolver in self._debrid_resolvers():
            key = (resolver.name, 'magnet:' if magnet else host)
            if (valid := self._debrid_valid.get(key)) is None:
                try:
                    valid = bool(resolver.valid_url(url, '') if magnet else host and resolver.valid_url('', host))
                except Exception:
                    fflog_exc()
                    valid = False
                self._debrid_valid[key] = valid
            if valid:
                cached = None if not btih or (found := self._cached.get(resolver.name)) is None else btih in found
                yield ResolveRoute(kind='debrid', name=resolver.name, cached=cached)

    def _plugin_enabled(self, url: str) -> str:
        """Return the add-on ID of a `plugin://` URL if it is enabled in Kodi, empty otherwise."""
        addon_id = url[len('plugin://'):].partition('/')[0].partition('?')[0]
        if (enabled := self._plugins.get(addon_id)) is None:
            from .kotools import addon_enabled_in_kodi
            enabled = self._plugins[addon_id] = bool(addon_id) and addon_enabled_in_kodi(addon_id)
        return addon_id if enabled else ''

    def resolvability(self, src: Source) -> Resolvability:
        """Return the ways FanFilm can open the source now, the best first (`const.sources.resolve.order`)."""
        meta = src.meta
        url = src.url
        host = src.hosting.lower()
        if host.startswith('www.'):
            host = host[4:]
        routes: list[ResolveRoute] = []
        debrids = list(self._debrid_routes(url, host, torrent_hash(src)))
        if meta.get('debridonly'):  # the provider says: only a debrid opens it
            routes = debrids
        else:
            if meta.get('premium') and not (meta.get('no_transfer') and not meta.get('on_account')):
                routes.append(ResolveRoute(kind='account', name=src.provider))
            if meta.get('direct') or meta.get('local'):
                routes.append(ResolveRoute(kind='direct', name=src.provider))
            if url.startswith('plugin://') and (addon_id := self._plugin_enabled(url)):
                routes.append(ResolveRoute(kind='plugin', name=addon_id))
            routes.extend(debrids)
            if self._host_in('ff', self.ff_domains, host):
                routes.append(ResolveRoute(kind='ff', name=host))
            if self._host_in('resolveurl', self.resolveurl_domains, host):
                routes.append(ResolveRoute(kind='resolveurl', name=host))
            # no resolver knows the link: the provider's `resolve()` gives it (also from its own scheme, e.g. "fourkhdhub:…"),
            # played as it is (`played_as_is()`)
            if not routes and played_as_is(url, src):
                routes.append(ResolveRoute(kind='provider', name=src.provider))
        return self.ordered(routes)

    def ordered(self, routes: Iterable[ResolveRoute]) -> Resolvability:
        """
        Return the resolvability of the ways in the preference order (`order`, a kind not listed dropped): of the debrids the one with
        the torrent cached first, the one known without it last (their priority order kept).
        """
        order = self.order
        return Resolvability(routes=tuple(sorted((route for route in routes if route.kind in order),
                                                 key=lambda route: (order[route.kind], CACHED_RANK[route.cached]))))


class DeadLink(ValueError):
    """Exception raised when a source link is dead or invalid."""


def no_way(url: str, src: Source) -> DeadLink:
    """Return the error of a source no way opens: one only a debrid opens tells where to add a debrid."""
    if needs_debrid(url, src):
        return DeadLink(L(30746, 'Only a debrid opens this source: add one in Tools » Configuration » Debrid'))
    return DeadLink(L(30347, 'No way to open this source'))


Item = SourceMeta


#: Type of resolver object.
class ResolverClass(Protocol):
    name: str
    domains: Sequence[str]
    pattern: str | None = None


# 1 GiB
GB = 1024**3


SourceSearchQueryKey: TypeAlias = Literal['local_title', 'english_title', 'original_title', 'year', 'premiered',
                                          'season', 'episode', 'episode_group', 'ffitem']


class SourceSearchQuery(SourceSearchOverride):
    episode_group: str | None
    episode_offset: dict[str | None, dict[int, int]]  # mapping [group name][group season] = episode number offset
    ffitem: FFItem


class Quality(IntEnum):
    """Quality (video resolution)."""
    SD = 0
    HD = 1
    FHD = 2
    UHD = 3

    H_480 = SD
    H_720 = HD
    H_1080 = FHD
    H_2160 = UHD


#: The pause between two lists of the sources found so far: this many times what the last one cost (a slow device rebuilds less often).
LIVE_LIST_COST: float = 3


class ProgressDialogProtocol(Protocol):
    """Protocol for dialogs that can show search progress."""
    def update(self, percent: int, message: str = '', *, providers: Sequence[str] | None = None) -> None: ...
    def iscanceled(self) -> bool: ...


class SourceDialogProtocol(Protocol):
    """Protocol for dialogs that can search sources."""
    # def __init__(self,
    query: SourceSearchQuery
    def __new__(cls,
                *args,
                sources: SourceManager,
                item: FFItem,
                items: Sequence[Source] = (),
                query: SourceSearchQuery,
                default_query: SourceSearchQuery | None = None,
                edit_search: bool = False,
                selection: CurrentSelection | None = None,
                ) -> SourceDialogProtocol: ...
    def start_search(self) -> None: ...
    def wait_ready(self, timeout: float | None = None) -> bool: ...
    def finish_search(self, sources: Sequence[Source]) -> None: ...  # the prepared sources (the window selects)
    def do_modal(self) -> Source | None: ...
    def destroy(self) -> None: ...
    def update(self, percent: int, message: str = '', *, providers: Sequence[str] | None = None) -> None: ...
    def iscanceled(self) -> bool: ...


class GetSourcesKwargs(SourceSearchOverride):
    """Keyword arguments for `sources.get_sources()` method. SourceSearchQuery matches."""
    episode_group: NotRequired[str | None]
    quality: NotRequired[str]
    timeout: NotRequired[int | None]
    ffitem: FFItem
    progress_dialog: NotRequired[ProgressDialogProtocol | None]


class FindProviderSourcesKwargs(SourceSearchOverride):
    """Keyword arguments for `sources.get_provider_sources()` method. SourceSearchQuery matches, with additional data."""
    ffitem: FFItem
    # -- from SourceSearchQuery (could overritten by user in edit dialog) --
    # ... all from SourceSearchOverride
    # -- additional data --
    localtvshowtitle: str
    src_mod: ProviderModule


class ProvidersSetting(dict):
    """
    Simple setting cache, for mass providers query.

    >>> colors = ProvidersSetting('library.color.identify2', default=None, source_mods=mods)
    >>> colors['tb7']  # the setting 'library.color.identify2' of the provider 'tb7'
    """

    def __init__(self, name: str, *, default: Any, source_mods: list[ProviderModule]) -> None:
        var_name: str = f'has_{name.replace(".", "_")}'
        super().__init__()
        #: Settings name (suffix).
        self.name: str = name
        #: Default valur if settings is not found.
        self.default: Any = default
        #: Providers with settings enabled.
        self._enabled: set[str] = {srcmod.name for srcmod in source_mods if getattr(srcmod.provider, var_name, False)}

    def __missing__(self, key: str) -> Any:
        key = key.lower()
        if key in self._enabled:
            value = provider_value(key, self.name)
        else:
            value = self.default  # default no-order
        self[key] = value
        return value


class NodeStyles:
    """
    The highlight colors and the priorities of the sources from the nodes of the tree of the source providers (`NODES_CONFIG`,
    read once): the first node of the branch of a source (its leaf first, `native_chain()`, `scraper_chain()`) with its own value.
    """

    def __init__(self, *, source_mods: Iterable[ProviderModule]) -> None:
        """Read the nodes; `source_mods`: the providers of the search (the branch of a scraper of an add-on, the group of a native one)."""
        from ..ff.config import config
        from ..sources.addons.external import NODES_CONFIG, node_values
        #: The values of the nodes by their keys.
        self.nodes: dict[str, dict[str, Any]] = config.get(NODES_CONFIG) or {}
        #: The priority of the episodes is in use (read once: asked for every source).
        self.episodes: bool = 'episode_priority' in node_values()
        #: The providers by their names (`Source.provider`).
        self._mods: dict[str, ProviderModule] = {srcmod.name: srcmod for srcmod in source_mods}
        #: The branches by the provider and the sub-source of a source.
        self._chains: dict[tuple[str, str], tuple[str, ...]] = {}

    def chain(self, src: Source) -> tuple[str, ...]:
        """Return the branch of the source in the tree from its leaf: a scraper of an add-on (its proxy knows it), a native provider."""
        from ..sources.addons.external import native_chain
        key = (src.provider, src.meta.get('sub') or '')
        if (chain := self._chains.get(key)) is None:
            srcmod = self._mods.get(src.provider)
            if not (chain := tuple(getattr(srcmod.provider, 'nodes', ()) if srcmod is not None else ())):
                chain = native_chain(src.provider, srcmod.group if srcmod is not None else '', key[1])
            self._chains[key] = chain
        return chain

    def value(self, src: Source, name: NodeValue) -> Any:
        """Return the first own value `name` of the branch of the source (`node_has()`), None if no node has one."""
        from ..sources.addons.external import node_has
        for key in self.chain(src):
            if node_has(value := self.nodes.get(key, {}).get(name)):
                return value
        return None

    def priority(self, src: Source) -> int:
        """
        Return the priority of the source (bigger first). An episode: the first priority of the episodes of its branch; none on the
        whole branch (or a movie): the first priority of the branch, else the rules (`default_priority`), else 0.
        """
        if self.episodes and src.ffitem.ref.is_episode and (value := self.value(src, 'episode_priority')) is not None:
            return value
        if (value := self.value(src, 'priority')) is not None:
            return value
        return src.attr.default_priority or 0


class LibraryColorSettings(ProvidersSetting):
    """Simple setting cache, for mass query (sorting in filters)."""

    def __init__(self, *, source_mods: list[ProviderModule]) -> None:
        super().__init__(name='library.color.identify2', default=None, source_mods=source_mods)


def source_color(src: Source, styles: NodeStyles, libcolors: LibraryColorSettings) -> str:
    """
    Return the colour of the source: forced (the rules), of an account item (the leaf), of the branch in the tree, of the rules,
    of the settings (the premium one), the automatic one of its provider (`auto_color()`), the default one.
    """
    return (src.attr.color
            or (libcolors[src.provider] if src.get('on_account') else None)
            or styles.value(src, 'color') or src.attr.default_color
            or (source_setting('premium_color') if src.get('premium') else '')
            or auto_color(src.provider)
            or source_setting('default_color'))


class ProviderFilterLogger:
    """Helper class for logging filtered-out providers in one place, instead of logging in each filter separately."""

    def __init__(self, source_mods: Iterable[ProviderModule]) -> None:
        self.old_mods: Sequence[ProviderModule] = tuple(source_mods)
        self.new_mods: list[ProviderModule] = []

    def __call__(self, mods: Iterable[ProviderModule]) -> list[ProviderModule]:
        self.new_mods = mods if isinstance(mods, list) else list(mods)
        return self.new_mods

    def __iter__(self) -> Iterator[ProviderModule]:
        return iter(self.old_mods)


@contextmanager
def log_providers(source_mods: Iterable[ProviderModule], *, by: str = '') -> Iterator[ProviderFilterLogger]:
    """Context manager for logging disabled providers after filtering."""
    flt = ProviderFilterLogger(source_mods)
    try:
        yield flt
    except Exception as exc:
        fflog.warning(f'Providers filter{by} EXCEPTION: {exc}')
        raise
    else:
        if by:
            by = f' by {by}'
        if len(flt.new_mods) < len(flt.old_mods):
            fflog(f'Providers disabled{by}: {", ".join(sorted(srcmod.name for srcmod in flt.old_mods if srcmod not in flt.new_mods))}')
        fflog.debug(f'Providers filtered{by}, {len(flt.new_mods)} active: {", ".join(sorted(srcmod.name for srcmod in flt.new_mods))}')


class ProviderThreadProtocol(Protocol):
    """Protocol for provider threads (searching sources in background)."""

    def start(self) -> None: ...
    def stop(self) -> None: ...
    def is_alive(self) -> bool: ...


class ProviderTaskProxy:
    """Proxy to one of provider threads called in separated task (process)."""


class ProviderCallState:
    """State of provider calls, see `_with_calling_provider()`."""

    def __init__(self) -> None:
        #: Any provider call raised an exception (the result is not complete).
        self.failed: bool = False


@define
class ProviderTimes:
    """The times of the phases of one provider search (seconds; None: the phase did not run or did not end)."""

    #: From the search start to its thread running.
    wait: float | None = None
    #: The read of the cached result.
    cache: float | None = None
    #: The show token (an episode).
    show: float | None = None
    #: The search of the provider.
    find: float | None = None
    #: The account state.
    dynamic: float | None = None


@frozen
class SearchRows:
    """The fresh cached rows of a search (`search_rows()`) by the provider names, read once before the provider threads."""

    #: The cached results.
    sources: Mapping[str, SourceCacheRow] = field(factory=dict)
    #: The cached show tokens (an episode search).
    shows: Mapping[str, SourceCacheRow] = field(factory=dict)


def search_rows(ffitem: FFItem, override: SourceSearchOverride, names: Collection[str] | None = None) -> SearchRows:
    """
    Return the fresh cached rows of the search (of the providers `names`, all if None): the results and, of an episode,
    the show tokens; one query each (a provider thread reads no DB before its search).
    """
    sources = sources_db.fetch_many(ffitem.ref, query_fingerprint(override), names)
    show_ref = ffitem.ref.show_ref if ffitem.ref.is_episode else None
    shows = sources_db.fetch_many(show_ref, query_fingerprint(override, show=True), names) if show_ref is not None else {}
    return SearchRows(sources=sources, shows=shows)


def provider_times_text(times: Mapping[str, ProviderTimes]) -> str:
    """Return the summary of the provider times: of every phase the median and the maximum (its provider), the not ended searches."""
    parts = []
    for phase in (f.name for f in fields(ProviderTimes)):
        if values := sorted((getattr(pt, phase), name) for name, pt in times.items() if getattr(pt, phase) is not None):
            parts.append(f'{phase} {values[len(values) // 2][0]:.2f} / {values[-1][0]:.2f} ({values[-1][1]})')
    if running := sum(1 for pt in times.values() if pt.dynamic is None):  # the last phase: a search (or a cache hit) ended
        parts.append(f'not ended {running}')
    return ', '.join(parts)


@contextmanager
def _with_calling_provider(call: ProviderProtocol, state: ProviderCallState | None = None) -> Generator[None, None, None]:
    """Context manager to log exceptions in provider calls (marked in the `state`, if given)."""
    try:
        yield
    except Exception as exc:
        if state is not None:
            state.failed = True
        from .logs import traceback_string
        call = unwrap_provider(call)
        mod_name = call.__class__.__module__
        if mod := sys.modules.get(mod_name):
            stack = traceback_string(exc.__traceback__, from_file=mod.__file__, ffonly=True)
        else:
            stack = traceback_string(exc.__traceback__, stack_limit=-1, ffonly=True)
        provider = getattr(call, 'PROVIDER', mod_name)
        fflog(f'Exception in provider {provider}: {mod_name}.{call.__class__.__name__}: {exc!r}\n{stack}', stack_depth=3)


def find_provider_sources(*,
                          ffitem: FFItem,
                          override: SourceSearchOverride,
                          src_mod: ProviderModule,
                          show: Any = MISSING,
                          state: ProviderCallState | None = None,
                          ) -> list[Source]:
    """Get sources from a single provider directly, without DB caching and with exception logging.

    `show` is the show token (`find_show()` result) for an episode search, MISSING if the provider has no show level.
    The result is not complete (`state.failed`) if the provider failed (an exception, logged: no sources) or its search
    did not end (`IncompleteResult`: the sources found so far).
    """

    def make_item(src: SourceItem | str | None) -> SourceItem | None:
        """Make source item from provider result, or return None if invalid."""
        if not src:
            return None
        if isinstance(src, str):
            return {'url': src}
        if not isinstance(src, dict):
            fflog.warning(f'Provider {src_mod.name!r} returned invalid source item: {src!r}')
            return None
        return src

    call = src_mod.provider
    if state is None:
        state = ProviderCallState()
    sources: list[Source] = []
    with _with_calling_provider(call, state):
        if not is_provider_new_protocol(call):
            fflog.error(f'Provider {src_mod.name!r} has no find() method')
            return []
        try:
            if show is MISSING:
                found = call.find(ffitem=ffitem, override=override)
            else:
                found = call.find(ffitem=ffitem, override=override, show=show)
        except IncompleteResult as exc:
            fflog(f'[SOURCES] {src_mod.name!r}: incomplete result, {len(exc.items)} items ({exc})')
            state.failed = True
            found = exc.items
        # remove duplicates while preserving order
        source_items = list({json.dumps(src, sort_keys=True): it for src in found or () if (it := make_item(src))}.values())
        sources = [Source.from_provider_dict(addon=src_mod.addon, provider=src_mod.name, ffitem=ffitem, item=it) for it in source_items]
    return sources


def unique_sources(sources: Sequence[Source], *, priority: Mapping[str, int]) -> list[Source]:
    """
    Return the sources without the duplicates of a link (the torrent hash, else the URL), the order kept: the best one
    stays - of the provider of the higher priority (lower `priority`), then with more data (the size, the seeders).
    """
    def rank(src: Source) -> tuple[int, bool, int]:
        """Return the order of a duplicate, the best first."""
        return priority.get(src.provider, 1), not src.size, -(src.meta.get('seeders') or 0)

    best: dict[str, Source] = {}
    for src in sources:
        key = src.meta.get('hash') or src.url
        if (other := best.get(key)) is None or rank(src) < rank(other):
            best[key] = src
    kept = {id(src) for src in best.values()}
    return [src for src in sources if id(src) in kept]


#: The window property of the external subtitles a provider gives in `resolve()` (the old way: a JSON list of files).
SUBTITLES_PROPERTY = 'source.subtitles'


def provider_subtitles() -> list[ResolveSubtitle]:
    """Return the external subtitles a provider put in the window property (`SUBTITLES_PROPERTY`) and clear it."""
    window = control.window()
    if not (text := window.getProperty(SUBTITLES_PROPERTY)):
        return []
    window.clearProperty(SUBTITLES_PROPERTY)
    try:
        files = json.loads(text)
    except ValueError:
        fflog(f'[SOURCES] provider subtitles: not a JSON list {text!r}')
        return []
    return [{'url': file} for file in files if isinstance(file, str) and file] if isinstance(files, list) else []


def apply_dynamic_sources(*,
                          ffitem: FFItem,
                          override: SourceSearchOverride,
                          src_mod: ProviderModule,
                          sources: list[Source],
                          ) -> list[Source]:
    """Apply the provider's DYNAMIC data (account state) to the static sources, see `apply_dynamic()` capability.

    On a provider error the static sources are returned (like an account check that did not make it in time).
    """
    call = src_mod.provider
    if not has_apply_dynamic(call):
        return sources
    result: list[Source] = sources
    with _with_calling_provider(call):
        result = [src if isinstance(src, Source) else Source.from_provider_dict(provider=src_mod.name, ffitem=ffitem, item=src)
                  for src in call.apply_dynamic(ffitem=ffitem, override=override, sources=list(sources))]
    return result


#: Search query keys of the source cache fingerprint (not the protocol `query`: it is made of the others and the item).
QUERY_KEYS: tuple[str, ...] = tuple(key for key in SourceSearchOverride.__annotations__ if key != 'query')
#: Query keys a stored search edit ("Edit search") may set.
EDIT_QUERY_KEYS: frozenset[str] = frozenset(SourceSearchQuery.__annotations__) - {'ffitem', 'query'}
#: Query keys skipped in the show token fingerprint: a show token is shared by the episodes (the show itself is
#: in the cache key, show ref).
SHOW_QUERY_SKIP_KEYS: frozenset[str] = frozenset({'season', 'episode', 'premiered'})


def query_fingerprint(override: SourceSearchOverride, *, show: bool = False) -> str:
    """Return the fingerprint of the search query (of its show part with `show`), a part of the sources cache key."""
    data = {key: override.get(key) for key in QUERY_KEYS if not (show and key in SHOW_QUERY_SKIP_KEYS)}
    return hashlib.sha1(json.dumps(data, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:20]


def provider_cache_ttl(src_mod: ProviderModule, option: str, default: int) -> int:
    """Return the lifetime of a cached provider result: the provider class `option` or `default` (zero: not cached)."""
    if not source_setting('source_cache'):
        return 0
    ttl = src_mod.class_get(option, default=None)
    return int(default if ttl is None else ttl)


def _json_safe(data: Any) -> bool:
    """Check if `data` survives JSON unchanged (e.g. a tuple does not: it comes back as a list)."""
    try:
        return json.loads(json.dumps(data)) == data
    except (TypeError, ValueError):
        return False


def _search_canceled() -> bool:
    """Return True if the search is canceled (the window closed, a new search, Kodi abort)."""
    scope = current_scope()
    return (scope is not None and scope.is_set()) or script_aborted()


def get_show_token(*,
                   ffitem: FFItem,
                   override: SourceSearchOverride,
                   src_mod: ProviderModule,
                   rows: SearchRows,
                   use_cache: bool = True,
                   refresh: bool = False,
                   ) -> tuple[Any, bool]:
    """
    Return the show token of the provider for an episode search (`find_show()`, cached) and False on a provider error.

    The token is MISSING if the provider has no show level (or it is not an episode search). It is shared by the
    episodes (the show ref and the show part of the query are the cache key). A token which does not survive JSON
    (e.g. a tuple) is not cached, the provider gets it as it made it.
    """
    find_show = getattr(src_mod.provider, 'find_show', None)
    if not callable(find_show) or not ffitem.ref.is_episode or (show_ref := ffitem.ref.show_ref) is None:
        return MISSING, True
    ttl = provider_cache_ttl(src_mod, 'SHOW_TTL', const.sources.cache.show_ttl) if use_cache else 0
    query = query_fingerprint(override, show=True) if ttl > 0 else ''
    if ttl > 0 and not refresh and (row := rows.shows.get(src_mod.name)) is not None:
        fflog(f'[SOURCES] show cache hit {src_mod.name!r}')
        return row.data, True
    state = ProviderCallState()
    token: Any = None
    with _with_calling_provider(src_mod.provider, state):
        token = find_show(ffitem=ffitem, override=override)
    if state.failed:
        return None, False
    if ttl > 0 and not _search_canceled() and _json_safe(token):
        sources_db.store(src_mod.name, show_ref, query, token, ttl=ttl if token is not None else min(ttl, const.sources.cache.empty_ttl))
    return token, True


def get_provider_sources(*,
                         ffitem: FFItem,
                         override: SourceSearchOverride,
                         src_mod: ProviderModule,
                         use_cache: bool = True,
                         refresh: bool = False,
                         times: ProviderTimes | None = None,
                         rows: SearchRows | None = None,
                         ) -> list[Source]:
    """
    Get sources from a single provider, with DB caching and exception logging; the times of its phases into `times`;
    its cached rows of `rows` (read once by the search, `search_rows()`; else read for it).

    The static result of the provider search is cached (`const.sources.cache`, the provider's `SOURCES_TTL`), so is
    the show token (`find_show()`, `SHOW_TTL`); the DYNAMIC data (account state) is applied on every search and never
    cached. A failed, incomplete or canceled search is not cached. `refresh` skips the cache read (a rescan), the fresh result
    replaces the cached one. `use_cache` is False for a debug search (live results).
    """
    fflog.debug(f'get_provider_sources {src_mod.name!r}')
    if times is None:
        times = ProviderTimes()
    if rows is None:
        rows = search_rows(ffitem, override, (src_mod.name,)) if use_cache and not refresh else SearchRows()
    ttl = provider_cache_ttl(src_mod, 'SOURCES_TTL', const.sources.cache.ttl) if use_cache else 0
    query = query_fingerprint(override) if ttl > 0 else ''
    sources: list[Source] | None = None
    start = monotonic()
    if ttl > 0 and not refresh and (row := rows.sources.get(src_mod.name)) is not None:
        try:
            sources = [Source.from_json(it, ffitem=ffitem) for it in row.data]
            fflog(f'[SOURCES] cache hit {src_mod.name!r}: {len(sources)} sources')
        except Exception:
            fflog_exc()
            sources = None  # a broken / old format row, search again
    times.cache = monotonic() - start
    if sources is None:
        cache = SearchCache(refresh=refresh, show_ttl=provider_cache_ttl(src_mod, 'SHOW_TTL', const.sources.cache.show_ttl) if use_cache else 0,
                            empty_ttl=const.sources.cache.empty_ttl)
        with search_cache(cache):  # for the caches of the provider itself (a provider add-on: the context `cache`)
            start = monotonic()
            show, ok = get_show_token(ffitem=ffitem, override=override, src_mod=src_mod, rows=rows, use_cache=use_cache, refresh=refresh)
            times.show = monotonic() - start
            state = ProviderCallState()
            start = monotonic()
            sources = find_provider_sources(ffitem=ffitem, override=override, src_mod=src_mod, show=show, state=state) if ok else []
            times.find = monotonic() - start
        if use_cache:  # the lifetime again: the provider can know it from its result (`done` of a provider add-on)
            ttl = provider_cache_ttl(src_mod, 'SOURCES_TTL', const.sources.cache.ttl)
        if not ok or state.failed:  # a provider error (logged) or an incomplete result: nothing to cache
            pass
        elif not has_apply_dynamic(src_mod.provider) and any(DYNAMIC_KEYS & src.meta.keys() for src in sources):
            # the account state is in the result (no `apply_dynamic()`, e.g. an old add-on scraper): a cached copy lost it
            fflog(f'[SOURCES] {src_mod.name!r}: account state in the result, not cached')
        elif ttl > 0 and not _search_canceled():
            query = query or query_fingerprint(override)
            sources_db.store(src_mod.name, ffitem.ref, query, [src.as_json(dynamic=False) for src in sources],
                             ttl=ttl if sources else min(ttl, const.sources.cache.empty_ttl))
    # account state (DYNAMIC) on every search, never cached
    start = monotonic()
    sources = apply_dynamic_sources(ffitem=ffitem, override=override, src_mod=src_mod, sources=sources)
    times.dynamic = monotonic() - start
    return sources


class SourceManager:
    """Main class for searching and playing sources."""

    #: The qualities of the sources (`Source` has the quality of the protocol vocabulary).
    QUALITIES = {
        Quality.UHD: {'4K'},
        Quality.FHD: {'1080p'},
        Quality.HD: {'720p'},
        Quality.SD: {'SD'},
    }
    QUALITY_NAMES = {0: 'SD', 1: '720', 2: '1080', 3: '4K'}
    # TOTAL_FORMAT = "[COLOR {color}][B]{count}[/B][/COLOR]"  # not used

    # Debug. Run single source provider without threads.
    DEBUG_SINGLE_PROVIDER: ClassVar[str | None] = None
    # Debug. Do not wait for user selection, cancel dialog after sources search.
    SKIP_SOURCE_SELECTION: ClassVar[bool] = False

    # Dialog window factory (class).
    SOURCE_DIALOG: ClassVar[type[SourceDialogProtocol]] = SourceDialog

    def __init__(self):
        self.lock = Lock()
        self.selectedSource = None
        self.itemProperty = None
        self.metaProperty = None
        self.source_mods: list[ProviderModule] = []
        #: Providers of the last search (add-ons expanded to their providers, filtered), see `provider_module()`.
        self.search_mods: list[ProviderModule] = []
        self.hq_host_list: list[str] = []
        self.all_sources: list[Source] = []
        #: The sources of the last search the user selects from (`prepare_sources()`): all of them in the window.
        self.prepared_sources: list[Source] = []
        #: The ways to open the sources during a search (the debrids asked once a hash), None: out of a search.
        self.search_resolve: ResolveMap | None = None
        #: The priority of the provider of a source in the sort of the user (the tree of the source providers of the last search).
        self.source_priority: Callable[[Source], int] = lambda src: 0
        self.sources: list[Source] = []
        self.test = {}
        #: The next search skips the sources cache read (a rescan with the same query), its results replace the cache.
        self.refresh_sources: bool = False
        self.lang = control.apiLanguage()['tmdb'] or 'en'

    def play(self,
             media_type: MediaType,
             ffid: int,
             season: int | None = None,
             episode: int | None = None,
             *,
             #: If true, show edit search dialog instead of source selection.
             edit_search: bool = False,
             #: Override season and episode numbers (play as episode group).
             override_episode: tuple[int, int] | None = None,
             #: Episode group to use (used if season/episode if not set).
             episode_group: str | None | EllipsisType = ...,
             ) -> None:
        try:
            # state.delete_all(module='player')
            return self._play(media_type=media_type, ffid=ffid, season=season, episode=episode,
                              edit_search=edit_search, override_episode=override_episode,
                              episode_group=episode_group)
        except Exception:
            fflog_exc()
            raise
        finally:
            clear_source_modules()

    def _play(self,
              media_type: MediaType,
              ffid: int,
              season: int | None = None,
              episode: int | None = None,
              *,
              edit_search: bool = False,
              override_episode: tuple[int, int] | None = None,
              episode_group: str | None | EllipsisType = ...,
              ) -> None:
        # mark playing state
        state.multi_set(module='player', values=(
            ('playing.run', False),
        ))
        # pause the playing video (e.g. the previous episode) for the source search, Kodi resumed it before it ran the plugin
        if xbmc.getCondVisibility('Player.HasVideo + !Player.Paused'):
            xbmc.Player().pause()

        # TODO:  -----------------------------------------------------------------
        # TODO:  ---  refaktor, bez sensu odzyskuje pewne dane, zanim użyć ffinfo
        # TODO:  -----------------------------------------------------------------

        self.sources = []  # create new list to avoid add sources after cancel
        self.all_sources = []  # create new list to avoid add sources after cancel
        ref: MediaRef = MediaRef(media_type, ffid, season, episode)
        # the default details: the episode with its season node (the season sizes for the absolute numbers), no progress
        ffitem: FFItem | None = ffinfo.find_item(ref, progress=ffinfo.Progress.NO)
        if ffitem is None:  # nothing to search sources for: the same answer as a cancel (no "Playback failed", no next playlist item)
            fflog(f'[SOURCES] no info for {ref:a}, play canceled')
            control.infoDialog(L(32981, 'No data in TMDB'), icon='WARNING')
            player.cancel()
            return
        ffinfo.number_episodes([ffitem])  # its place in its season (the absolute number) if the metadata does not tell it

        # override season/episode if requested (play as episode group)
        if ref.is_episode and override_episode:
            ffitem.season, ffitem.episode = override_episode
        # elif ref.is_episode and (episode_group is None or isinstance(episode_group, str)):
        #     ffinfo.switch_episode_group(ffitem, episode_group)

        if ref.type == 'show' and (sh_item := ffitem.show_item):
            vtag = sh_item.getVideoInfoTag()
            premiered = sh_item.date
            # show_title = vtag.getEnglishTvShowTitle() or sh_item.title
        else:
            vtag = ffitem.getVideoInfoTag()
            premiered = ffitem.date
            # show_title = ''
        # `title` and `show_title` should be in English.
        title = vtag.getTitle()
        en_title = vtag.getEnglishTitle() or vtag.getOriginalTitle() or title
        query: SourceSearchQuery = {
            'english_title': en_title,    # title is in English
            'local_title': title,         # title is in api locale
            'original_title': vtag.getOriginalTitle(),
            'year': vtag.getYear(),
            'season': ffitem.season,
            'episode': ffitem.episode,
            'premiered': premiered,
            'episode_group': None,
            'episode_offset': {},
            'ffitem': ffitem,
        }
        default_query = query.copy()
        if const.sources_dialog.edit_search.cache and (se := sources_edit_db.get(ffitem)):
            # only the query keys: an older edit may have other ones (e.g. imdb / tmdb, ids are taken from the item now)
            query.update({key: val for key, val in se.data.items() if key in EDIT_QUERY_KEYS})  # type: ignore[reportArgumentType]

        # Switch episode group if needed
        eg_id: str | None = None
        if ref.is_episode:
            if episode_group is not ...:
                if TYPE_CHECKING:
                    assert not isinstance(episode_group, EllipsisType)
                query['episode_group'] = episode_group
            ffinfo.switch_episode_group(ffitem, query.get('episode_group'))
            if ffitem.episode_group.current is not None:
                default_query['season'] = ffitem.season
                default_query['episode'] = ffitem.episode
                if const.sources_dialog.edit_search.show_granularity == 'show':
                    query['season'] = ffitem.season
                    query['episode'] = ffitem.episode
                elif const.sources_dialog.edit_search.show_granularity == 'season':
                    query['episode'] = ffitem.episode
            if const.sources_dialog.edit_search.cache is not None and 'episode_offset' in const.sources_dialog.edit_search.cache and ffitem.season:
                eg_id = ffitem.episode_group.tmdb_id or None
                if offset := query['episode_offset'].get(eg_id, {}).get(ffitem.season):
                    query['episode'] = (ffitem.episode or 0) + offset
        initial_query = query.copy()  # for detect changes after rescan

        # Kodi does not wait for the result any more (e.g. Back on its busy dialog): no window, no search, no cancel.
        if script_aborted():
            fflog(f'[SOURCES] play aborted by Kodi, {ref:a}')
            return

        # Create window ASAP, before scan_source_modules() and other slow operations.
        # Show empty window as placebo - progress bar will be enabled later in background thread.
        win: SourceDialogProtocol | None = None
        selection: CurrentSelection | None = None  # of the window before a rescan (not stored): the next one goes on with it
        if not edit_search:
            win = self.SOURCE_DIALOG(sources=self, item=ffitem, query=query,
                                     default_query=default_query, edit_search=edit_search)

        def start(target: Callable[..., None], *args: Any, name: str) -> Thread:
            """Start the thread of a step; the CLI debug of one provider runs it in this thread (breakpoints, no time limit)."""
            th = Thread(target=target, args=args, name=name)
            if self.DEBUG_SINGLE_PROVIDER:
                target(*args)
            else:
                th.start()
            return th

        # Initialize aliases and providers in background thread
        init_complete = Event()

        def init_background():
            # It can be stopped (`init_thread.stop()`) between the steps and the provider modules, if the window
            # is closed early: Kodi waits for all script threads (see the end of the window loop).
            try:
                try:
                    ffitem.copy_from(ffitem.season_item, ffitem.show_item)
                except Exception:
                    fflog_exc()
                check_thread_cancel()
                try:
                    # the resume point of the accounts (the window found it without the progress: Kodi video DB, playback.db) -
                    # the window ends the video from it ("End at", `show_end_time()`)
                    ffinfo.update_item_progress(ffitem)
                except Exception:
                    fflog_exc()
                check_thread_cancel()
                try:
                    if show_ffitem := ffitem.show_item:
                        ffinfo.get_title_aliases(show_ffitem)
                    else:
                        ffinfo.get_title_aliases(ffitem)
                except Exception:
                    fflog_exc()
                check_thread_cancel()
                try:
                    # retrive category data (like anime info)
                    ffinfo.retreive_category_data(ffitem)
                except Exception:
                    fflog_exc()
                check_thread_cancel()
                try:
                    self.scan_source_modules(ffitem=ffitem)
                except Exception:
                    fflog_exc()
            except ThreadCanceled:
                fflog('Sources init canceled')
            finally:
                init_complete.set()

        # Start background initialization thread (aliases + provider loading)
        init_thread = start(init_background, name='SourcesInit')

        log_s = f', S{ffitem.season or 0:0>2}E{ffitem.episode or 0:0>2}/group={ffitem.episode_group or ""}' if ref.is_episode else ''
        fflog(f'play(ffid={ffid!r}) ref={ref!a}{log_s}')

        # Source searching  int loop (allows rescanning)
        source_to_play: Source | None = None
        while not script_aborted():
            # Ensure window exists if needed (e.g., after rescan from EditDialog when edit_search changes to False)
            if not edit_search and win is None:
                # no items: the window starts in the search mode, like on the first open (before it is shown)
                win = self.SOURCE_DIALOG(sources=self, item=ffitem, query=query,
                                         default_query=default_query, edit_search=edit_search, selection=selection)

            source_to_play = None

            try:
                if win:
                    # Search in background thread while window is shown
                    def search_thread(win: SourceDialogProtocol) -> None:
                        try:
                            # Wait for the window controls (Kodi loads the XML in do_modal()), e.g. after a rescan
                            # the init is already done and a fast search could finish before the window is shown.
                            if not win.wait_ready():
                                return  # closed before shown (or Kodi exit)
                            # "Preparing sources" while the init runs (aliases, category data, providers).
                            self.initial_progress_update(win)
                            # Wait for initialization to complete
                            init_complete.wait()
                            # The window is in the search mode since it was created. Do not start it again,
                            # it would reset a cancel pressed before the search started.
                            if win.iscanceled() or script_aborted():
                                win.finish_search([])
                                return
                            # Search for sources
                            self.get_sources(**query, progress_dialog=win)
                            # the found sources to the window: all of them prepared, the window shows the selection of the user
                            win.finish_search(self.prepared_sources)
                        except ThreadCanceled:
                            fflog('Sources search canceled')
                        except (KeyboardInterrupt, SystemExit):
                            win.finish_search(None)  # type: ignore[reportArgumentType]  # only debug
                            return
                        except Exception:
                            fflog_exc()

                    thread = start(search_thread, win, name='SourcesSearch')

                    # Show window (blocks until user closes or selects source)
                    # Search thread updates window in background
                    try:
                        source_to_play = win.do_modal()
                        if thread.is_alive():
                            thread.join(timeout=1)  # wait for thread to finish (should be done already)
                    finally:
                        query = win.query  # get possibly updated query from window before closing (event on cancel, to keep user edit changes)
                        with suppress(Exception):
                            win.destroy()
                        win = None  # remove reference to closed window
                    break  # source selected or canceled, exit while loop
                else:
                    # make sure to finish changing sources object if there was no window
                    init_complete.wait()
                if edit_search:
                    # edit search without source-dialog in background
                    edit_win = EditDialog(query=query, default_query=default_query)
                    edit_win.do_modal()
                    del edit_win
                    break
            except RescanSources as rescan:
                # Rescan requested (as exception), continue loop with new query
                if rescan.query:
                    query_changed = query != rescan.query
                    selection = rescan.selection
                    fflog(f'[SOURCES] rescan request (edit={query_changed})')
                    # Close current window before rescanning
                    if win is not None:
                        with suppress(Exception):
                            win.destroy()
                        win = None
                    # The same query: the user wants fresh results (skip the cache read, replace the cache).
                    # A changed query has another cache key (fingerprint), its results may be cached already.
                    self.refresh_sources = not query_changed
                    self.sources.clear()
                    self.all_sources.clear()
                    query = rescan.query
                    if initial_query['episode_group'] != query['episode_group']:
                        # reset season and episode to current if episode group changed, to avoid wrong offsets
                        # fflog(f'>>>>>>>>>> EG {default_query["episode_group"]!r} -> {query.get("episode_group")!r}: {default_query["season"]}x{default_query["episode"]} -> {ffitem.season}x{ffitem.episode}, eg={ffitem.episode_group}')
                        default_query['season'] = ffitem.season or 0
                        default_query['episode'] = ffitem.episode or 0
                    query['ffitem'] = ffitem
                    # Window will be recreated at the start of next loop iteration
            except Exception:
                fflog_exc()
                break
            edit_search = False  # skip only first sources scan
        # A rescan search waits for the init itself. On exit, the init is not needed any more (if the window was closed
        # before it finished): stop it. The script must end soon: when Kodi stops a play script (Back on its busy dialog)
        # it processes other messages meanwhile and a queued plugin call can deadlock Kodi (K21, K22: CPythonInvoker::stop).
        if not init_complete.is_set():
            init_thread.stop()
        init_complete.wait()
        fflog(f'source to play {source_to_play!r}')
        if allowed := const.sources_dialog.edit_search.cache:
            if 'episode_offset' in const.sources_dialog.edit_search.cache and ffitem.season:
                def es(q: SourceSearchQuery) -> str:
                    if q['season'] is None or q['episode'] is None:
                        return 'movie'
                    if q['episode_group']:
                        return f'S{q["season"]}E{q["episode"]}({q["episode_group"]})'
                    return f'S{q["season"]}E{q["episode"]}'
                d_offset = default_query['episode'] or 0
                q_offset = query['episode'] or 0
                i_season = initial_query['season'] or 0
                i_episode_group = initial_query['episode_group']
                fflog(f'{ffitem.ref!a}, S{ffitem.season or 0:02d}E{ffitem.episode or 0:02d}:'
                      f' save episode offset: d={es(default_query)}, i={es(initial_query)}, q={es(query)}, {i_episode_group=}')
                if d_offset and q_offset and d_offset != q_offset:
                    query['episode_offset'].setdefault(query['episode_group'], {})[ffitem.season] = q_offset - d_offset
                elif episode_offset := query['episode_offset'].get(i_episode_group):
                    episode_offset.pop(i_season, 0)
                    if not episode_offset:
                        del query['episode_offset'][eg_id]
            if query == default_query and not query.get('episode_group'):
                fflog(f'{ffitem!a}: remove saved edit')
                sources_edit_db.delete(ffitem)
            else:
                save_query = {k: v for k, v in query.items() if k in allowed}
                fflog(f'{ffitem!a}: save edit: {save_query}')
                sources_edit_db.set(ffitem, save_query)
        if script_aborted():
            fflog(f'[SOURCES] play aborted by Kodi, {ref:a}')
            return
        # the search results are stored in the background, mostly while the user chooses a source
        if not sources_db.flush(const.sources.cache.flush_timeout):
            fflog(f'[SOURCES] cache store not finished in {const.sources.cache.flush_timeout} s')
        if source_to_play:
            player.play(source=source_to_play)
        else:
            player.cancel(ffitem)

    def get_sources(self, **kwargs: Unpack[GetSourcesKwargs]) -> list[Source]:
        return self._get_sources(**kwargs)

    def initial_progress_update(self, progress_dialog: ProgressDialogProtocol | None) -> None:
        """Initial progress dialog update."""
        if progress_dialog is None:
            return
        line = L(30536, "Preparing sources...")
        progress_dialog.update(0, line)

    def _get_sources(self, *,
                     ffitem: FFItem,
                     english_title: str,
                     local_title: str,
                     year: int,
                     season: int | None,
                     episode: int | None,
                     premiered: dt_date | None,
                     original_title: str = "",
                     episode_group: str | None = None,              # used in query, not used directly
                     episode_offset: dict[int, int] | None = None,  # used in query, not used directly
                     quality: str = "HD",
                     timeout: int | None = None,
                     progress_dialog: ProgressDialogProtocol | None = None,
                     ) -> list[Source]:
        # fflog("get_sources")
        fflog(f'\033[91mget_sources\033[0m({english_title=}, {local_title=}, {year=}, ids={ffitem.ids},'
              f' {season=}, {episode=}, {premiered=}, {original_title=} ---------')

        # --- DEBUG ---
        # if 0:
        #     self.all_sources = [
        #         Source(url='/a/b/c', provider='test', hosting='host', ffitem=ffitem, meta={'size': '1 KB', 'quality': '720p'}),
        #     ]
        #     self.sources = self.filter_sources(self.all_sources, ffitem=ffitem)
        #     return self.sources
        # return []

        if timeout is None:
            timeout = search_limits().end
        self.prepared_sources = []  # nothing found yet (a search without providers ends before it)

        # progress_dialog is now always created in _play() before calling get_sources()
        # If None, progress updates will be skipped (used for testing or external calls)
        refresh, self.refresh_sources = self.refresh_sources, False

        # -------------------------------------------------------------------------------------------------------- XXX XXX XXX
        def log_source_mods(title='source_mods', *, mods: Sequence[ProviderModule] | None = None, level: int = LOGDEBUG):
            # from pprint import pformat
            if mods is None:
                nonlocal source_mods
                if not hasattr(source_mods, '__len__'):
                    source_mods = tuple(source_mods)  # support for generators
                mods = source_mods
            plural = '' if len(mods) == 1 else 's'
            title = title.format(N=len(mods), plural=plural, label_provider=f'provider{plural}')
            fflog(f'{title}: {", ".join(sorted(smod.name for smod in mods))}', stack_depth=2, level=level)
            # fflog.debug(f'{title}\n{pformat(mods, indent=2, width=240, compact=False)}', stack_depth=2)

        content = ffitem.ref.type
        source_mods: Sequence[ProviderModule] = self.source_mods
        srcmod: ProviderModule
        log_source_mods('start')
        for srcmod in source_mods:
            srcmod.provider.canceled = False

        def filter_source_modules(source_mods: Iterable[ProviderModule], *, allow_addon_providers: bool = False) -> list[ProviderModule]:
            # Filter-out provider modules with provider-level pattern (provider, platform, kodi version).
            # no source-level conditions means the provider could be skipped entirely here.
            # For CLI debug with --single-provider force given provider enabled.
            with log_providers(source_mods, by='rules') as flt:
                source_mods = flt([srcmod for srcmod in flt if self.DEBUG_SINGLE_PROVIDER == srcmod.name or srcmod.is_enabled_by_rules()])

            # the user / category / language filters skipped: all sources forced, or the one provider of the CLI debug
            forced = const.dev.sources.force_all_sources or bool(self.DEBUG_SINGLE_PROVIDER)
            # filtrowanie po dozowlonych providerach, tzn. takich, które włączył użytkownik w ustawieniach
            if forced:
                fflog('[DEV] force_all_sources / single provider: skipping provider user-settings filter')
            else:
                with log_providers(source_mods, by='user') as flt:
                    source_mods = flt([srcmod for srcmod in flt if module_searched(srcmod)])

            # filter providers searching the media type (by MEDIA, the old API: by its methods)
            if content not in ('movie', 'show'):
                fflog.error(f'Unknown content type: {content!r}')
                return []
            with log_providers(source_mods, by='missing methods') as flt:
                source_mods = flt(srcmod for srcmod in flt
                                  if provider_supports(srcmod.provider, content)
                                  or (allow_addon_providers and is_provider_addon_protocol(srcmod.provider)))

            if not forced:
                # filter by categories (if provider has categories defined, it must include our content type)
                categories: set[MediaCategory] = {'general', ffitem.category}
                with log_providers(source_mods, by='categories') as flt:
                    source_mods = flt(srcmod for srcmod in flt
                                      if not (cats := srcmod.class_get('CATEGORIES', default=())) or set(cats) & categories)
                # filter by provider's LANGUAGES class attribute (if exists), if it has any language in common with our accepted languages
                # no LANGUAGES means no language restrictions, provider is always accepted, otherwise it must have at least one language in common with accepted
                langs: set[str] = set(self.get_langs())
                with log_providers(source_mods, by='languages') as flt:
                    source_mods = flt(srcmod for srcmod in flt
                                      if not (lng := srcmod.class_get('LANGUAGES', 'language', default=())) or set(lng) & langs)
            return source_mods

        # dane (aliasy i inne)
        aliases: list[SourceTitleAlias] = title_aliases(ffitem, original_title)

        # override query for providers (e.g. by source dialog edit)
        search_source_query: FindProviderSourcesKwargs = {
            'ffitem': ffitem,
            'local_title': local_title,
            'english_title': english_title,
            'original_title': original_title,
            'premiered': premiered,
            'year': year,
            'season': season,
            'episode': episode,
            'aliases': aliases,
            'src_mod': None,  # type: ignore[assignment], will be set in loop
        }
        # the protocol query, once for all providers
        search_source_query['query'] = search_query(ffitem, search_source_query, lang=self.lang)

        # loading and filtering providers (with logging)
        source_mods = filter_source_modules(source_mods, allow_addon_providers=True)

        # expand addons and they providers (they run in threads like the native ones, see lib/sdk/addons/namespace.py)
        if addons_mods := [smod for smod in source_mods if is_provider_addon_protocol(smod.provider)]:
            log_source_mods('{N} addon {label_provider}', level=LOGINFO, mods=addons_mods)
            new_srcmods = []
            addons = [(amod.provider, ainfo) for amod in addons_mods if is_provider_addon_protocol(amod.provider)
                      for ainfo in amod.provider.scan_addons()]
            prefixes = addon_prefixes(ainfo for _, ainfo in addons)
            for aprov, ainfo in addons:
                mod = aprov.get_addon(ainfo, ffitem=ffitem)
                if (prefix := prefixes[mod.addon]) != mod.name:
                    fflog(f'[SOURCES] add-on {mod.addon!r}: short name {mod.name!r} is not unique, its providers are {prefix}:*')
                for srcmod in mod.provider.get_providers(ffitem=ffitem, override=search_source_query):
                    # add provider from addon as new source module, with reference to addon info
                    srcmod = evolve(srcmod, name=f'{prefix}:{srcmod.name}', addon=mod.addon)
                    new_srcmods.append(bind_provider(srcmod, ffitem=ffitem))
            # remove pure addon modules (modules that only serve as container for their providers, but don't have providers themselves)
            with log_providers(source_mods, by='remove addons') as flt:
                source_mods = flt(srcmod for srcmod in flt if provider_supports(srcmod.provider, content))
            # loading and filtering external addon providers (with logging)
            new_srcmods = filter_source_modules(new_srcmods)
            fflog.debug(f'Expanded {len(addons_mods)} addon modules into {len(new_srcmods)} provider modules:'
                        f' {", ".join(sorted(srcmod.name for srcmod in new_srcmods))}')
            source_mods.extend(new_srcmods)

        # mieszanie providerów (randomize), NIE UŻYWANE
        if False:
            source_mods = list(source_mods)  # generator → list, for random.shuffle()
            random.shuffle(source_mods)
        # sort providers by provider-level priority (if exists, default is 1)
        source_mods = sorted(source_mods, key=lambda srcmod: srcmod.class_get('PRIORITY', 'priority', default=1))
        # since now `source_mods` is a list, not a generator, it can be iterated multiple times
        log_source_mods('sorted')
        self.search_mods = list(source_mods)

        # pozyskiwanie źródeł (linków) od providerów (w wątkach)
        threads: dict[ProviderThreadProtocol, ProviderModule] = {}
        #: Stop scope of all provider threads (their pools and sockets too), stopped at the scan end; its deadline: the end of the search.
        search_start = monotonic()
        search_scope = CancelScope(parent=current_scope(), deadline=search_start + timeout if const.sources.stop_providers_at_max else None)
        #: The cached rows of the providers, read once (a provider thread reads no DB before its search; a rescan: none).
        start = monotonic()
        rows = SearchRows() if refresh or not source_mods else search_rows(ffitem, search_source_query, [srcmod.name for srcmod in source_mods])
        fflog(f'[SOURCES] cached rows: {len(rows.sources)} results, {len(rows.shows)} show tokens in {monotonic() - start:.2f} s')
        #: The times of the phases of the providers (by their names), see `ProviderTimes`.
        times: dict[str, ProviderTimes] = {srcmod.name: ProviderTimes() for srcmod in source_mods}
        # no source modules at all, nothing to find
        log_source_mods('{N} active {label_provider}', level=LOGINFO)
        if self.DEBUG_SINGLE_PROVIDER:
            debug_srcmod = next((s for s in source_mods if s.name == self.DEBUG_SINGLE_PROVIDER), None)
            fflog(f'  --> DEBUG single {self.DEBUG_SINGLE_PROVIDER} ({debug_srcmod})')
        if not source_mods:
            return []

        # single provider for CLI debug
        if self.DEBUG_SINGLE_PROVIDER:
            if debug_srcmod := next((s for s in source_mods if s.name == self.DEBUG_SINGLE_PROVIDER), None):
                # fake thread, to use the same progress monitoring loop (but without waiting, because it's not a real thread)
                class DummyThread:
                    def is_alive(self) -> bool: return False
                    def start(self) -> None: pass
                    def stop(self) -> None: pass
                fflog(f'DEBUG SINGLE PROVIDER: {debug_srcmod.name}')
                threads[DummyThread()] = debug_srcmod  # type: ignore[assignment]
                # get sources without threads, to debug single provider in CLI
                self.sources = get_provider_sources(ffitem=ffitem, override=search_source_query, src_mod=debug_srcmod, use_cache=False)
            else:
                fflog.warning(f'DEBUG SINGLE PROVIDER: {self.DEBUG_SINGLE_PROVIDER} not found')
        # all providers in threads
        else:
            def call_provider_sources(srcmod: ProviderModule) -> None:
                provider_times = times[srcmod.name]
                provider_times.wait = monotonic() - search_start
                try:
                    sources = get_provider_sources(ffitem=ffitem, override=search_source_query, src_mod=srcmod, refresh=refresh,
                                                   times=provider_times, rows=rows)
                    with self.lock:
                        self.sources.extend(sources)
                except Exception:
                    fflog_exc()
            for srcmod in source_mods:
                th = Thread(
                    target=call_provider_sources,
                    args=(srcmod,),
                    name=f'{srcmod.name} {ffitem.ref.real_type} sources',
                    scope=search_scope,
                )
                threads[th] = srcmod

        # Start threads z timeout tracking
        fflog(f'[SOURCES] Starting {len(threads)} providers (max {timeout:.1f}s): {", ".join(sorted(srcmod.name for srcmod in threads.values()))}')
        for th in threads:
            th.start()

        self.search_resolve = ResolveMap.create()
        sources = self._scanning_sources(threads=threads, scope=search_scope, progress_dialog=progress_dialog, timeout=timeout, ffitem=ffitem,
                                         list_after=None if simple_view(item_media(ffitem)) else min(search_limits().list_after, timeout))
        fflog(f'[SOURCES] provider times (median / max): {provider_times_text(times)}')
        self.all_sources = sources
        self.prepared_sources = self.prepare_sources(sources, ffitem=ffitem)
        self.search_resolve = None
        sources = self.select_sources(self.prepared_sources, ffitem=ffitem)
        self.sources = sources
        return sources

    def _scanning_sources(self, *,
                          threads: dict[ProviderThreadProtocol, ProviderModule],
                          scope: CancelScope,
                          progress_dialog: ProgressDialogProtocol | None,
                          timeout: int,
                          ffitem: FFItem,
                          list_after: float | None = 0,
                          ) -> list[Source]:
        """
        Monitor provider threads, update progress dialog with found sources count and other info, until all threads finish or timeout occurs
        (the counts by the selection of the sources of the item); from `list_after` seconds (None: never, the progress only) the window of the
        sources shows what is found so far (`show_found()`, no other dialog has it), prepared without the torrents the debrids were not asked about, not more often than
        the cost of the last one allows (`LIVE_LIST_COST`). The providers go on after the timeout (`const.sources.stop_providers_at_max`):
        the debrids asked once at it, the rest at the end of the search.
        """
        start_time: float = monotonic()
        end_time: float = start_time + timeout if scope.deadline is None else scope.deadline
        stop_at_end: bool = const.sources.stop_providers_at_max
        show_found: Callable[[Sequence[Source]], None] | None = None if list_after is None else getattr(progress_dialog, 'show_found', None)
        next_found: float = start_time + (list_after or 0)
        found_shown: int = -1  # the number of the sources shown; none yet: the list shown at once, also empty
        asked_at_end: bool = False

        string_total = L(32601, 'Total')
        string_premium = L(32606, 'Prem')
        string_normal = L(32607, 'Normal')
        string_languages = L(32014, 'Languages')

        # the qualities shown: the ones the filter of the user lets through, the sources counted by the language: the ones it lets through
        selection = current_selection(item_media(ffitem), langs=self.get_langs())
        qrange = [q for q in Quality if any(selection.value_passes('quality', name) for name in self.QUALITIES[q])]

        line1 = line2 = line3 = ""

        TOTAL = len(self.QUALITIES)
        source_qq = [0] * (TOTAL + 1)    # +1 for [TOTAL] - normal sources
        prem_source_qq = [0] * (TOTAL + 1)  # +1 for [TOTAL] - premium sources (premium=True)

        # Event-driven monitoring zamiast busy wait
        update_interval = .5  # Update co sekundę
        next_update_time = monotonic() + update_interval
        total_threads = len(threads)

        # Helper functions for progress dialog formatting
        def format_quality_count(count, color=None, width=2):
            """Format single quality count with color and fixed width"""
            if color is None:
                color = "lime" if count > 0 else "red"
            return f"[COLOR {color}][B]{count:>{width}}[/B][/COLOR]"

        def build_progress_line(*lines):
            """Combine lines with optional remaining line"""
            return '\n'.join(str(line) for line in lines if line)

        def build_quality_line(labels_list, quality_names, qrange, prefix=''):
            """Build quality line with proper alignment"""
            parts = [f"{quality_names[i]}: {labels_list[i]}" for i in reversed(qrange)]
            line = " | ".join(parts)
            return f"{prefix}{line}" if prefix else line

        def build_inline_quality_parts(source_qq, prem_source_qq, quality_names, qrange, has_premium):
            """Build quality parts for inline mode with premium in parentheses"""
            parts = []
            for i in reversed(qrange):
                normal_count = source_qq[i]
                premium_count = prem_source_qq[i]
                total_count = normal_count + premium_count

                if has_premium and premium_count > 0:
                    # Show as: "4K: 12 (1)" where 12 is total, (1) is premium in gold
                    part = f"{quality_names[i]}: {format_quality_count(total_count)} [COLOR gold]({premium_count})[/COLOR]"
                else:
                    # Show as: "4K: 12" (no premium sources, or total is 0)
                    part = f"{quality_names[i]}: {format_quality_count(total_count)}"

                parts.append(part)
            return parts

        try:
            # Main loop, wait for provider (source-module) threads to complete or timeout
            while (threads := {th: srcmod for th, srcmod in threads.items() if th.is_alive()}) and ((now := monotonic()) < end_time or not stop_at_end):
                if script_aborted():  # like a cancel: stop the providers (finally), Kodi does not wait for the result
                    break

                with suppress(AttributeError):
                    if progress_dialog.iscanceled():
                        break

                try:
                    if not stop_at_end and not asked_at_end and now >= end_time and self.search_resolve is not None:
                        asked_at_end = True
                        with self.lock:
                            found = list(self.sources)
                        self.search_resolve.check_cache(found)
                        found_shown = -1
                    if show_found is not None and now >= next_found:
                        with self.lock:
                            found = list(self.sources)
                        if len(found) != found_shown:
                            found_shown = len(found)
                            show_found(self.prepare_sources(found, ffitem=ffitem, final=False))
                            next_found = monotonic() + LIVE_LIST_COST * (monotonic() - now)

                    # Update progress only periodically to reduce CPU usage
                    if next_update_time <= now:
                        next_update_time = now + update_interval

                        if progress_dialog is not None:
                            with suppress():
                                progress_dialog.update_time((now - start_time), (end_time - start_time))

                        for q in qrange:
                            qq = self.QUALITIES[Quality(q)]
                            # Normal sources: not premium and not debridonly
                            source_qq[q] = sum(1 for e in self.sources if e["quality"] in qq and not e.get("premium") and not e.get("debridonly"))
                        source_qq[TOTAL] = sum(source_qq[0:TOTAL])

                        # Premium sources: premium=True (the resolvability, a debrid too, is known only after the search)
                        for q in qrange:
                            qq = self.QUALITIES[Quality(q)]
                            prem_source_qq[q] = sum(1 for e in self.sources if e["quality"] in qq and e.get("premium"))
                        prem_source_qq[TOTAL] = sum(prem_source_qq[0:TOTAL])

                        try:
                            info = [srcmod.name.upper() for srcmod in threads.values()]

                            # Common calculations
                            total_all = source_qq[TOTAL] + prem_source_qq[TOTAL]
                            quality_names = self.QUALITY_NAMES

                            # Count the sources the filter of the user lets through (the ways to open them not known yet) by the language of their audio
                            lang_counts = {}
                            for e in self.sources:
                                lang = source_language(e)

                                if selection.passes(e):
                                    lang_upper = lang.upper() if lang else 'EN'  # empty is EN
                                    lang_counts[lang_upper] = lang_counts.get(lang_upper, 0) + 1

                            # Format language display: "EN: 10 | PL: 20 | MULTI: 100"
                            if lang_counts:
                                lang_parts = []
                                for lang, count in sorted(lang_counts.items(), key=lambda x: x[1], reverse=True):
                                    color = "lime" if count > 0 else "red"
                                    lang_parts.append(f"{lang}: [COLOR {color}][B]{count}[/B][/COLOR]")
                                language_display = " | ".join(lang_parts)
                            else:
                                language_display = ""

                            has_premium = prem_source_qq[TOTAL] > 0

                            # Progress based on completed threads, not time
                            percent = min(99, 100 * (total_threads - len(threads)) // total_threads)

                            # Display mode from const
                            display_mode = SourceSearchProgressStyle(const.sources_dialog.searching.progress_style)

                            if display_mode == SourceSearchProgressStyle.FULL:
                                # Full mode: premium/normal separation with headers
                                prem_source_labels = [format_quality_count(sq, color="gold" if sq > 0 else "red") for sq in prem_source_qq]
                                source_labels = [format_quality_count(sq) for sq in source_qq]

                                if has_premium:
                                    # With premium: show headers and totals
                                    # Line 0: "Premium" header with total count
                                    line0 = f"[B]{string_premium}:[/B] {format_quality_count(prem_source_qq[TOTAL], color='gold')}"
                                    # Line 1: Premium qualities
                                    line1 = build_quality_line(prem_source_labels, quality_names, qrange)
                                    # Line 2: "Normal/Free" header with total count
                                    line2 = f"[B]{string_normal}:[/B] {format_quality_count(source_qq[TOTAL])}"
                                    # Line 3: Normal qualities
                                    line3 = build_quality_line(source_labels, quality_names, qrange)
                                    # Line 4: Total (all sources)
                                    line4 = f"[B]{string_total}:[/B] {format_quality_count(total_all)}"
                                    # Line 5: Languages
                                    line5 = f"[B]{string_languages}:[/B] {language_display}" if language_display else None
                                    progress_line = build_progress_line(line0, line1, line2, line3, line4, line5)
                                else:
                                    # Without premium: no headers, just totals
                                    # Line 0: Normal qualities
                                    line0 = build_quality_line(source_labels, quality_names, qrange)
                                    # Line 1: Total
                                    line1 = f"[B]{string_total}:[/B] {format_quality_count(total_all)}"
                                    # Line 2: Languages
                                    line2 = f"[B]{string_languages}:[/B] {language_display}" if language_display else None
                                    progress_line = build_progress_line(line0, line1, line2)

                            elif display_mode == SourceSearchProgressStyle.EXTENDED:
                                # Extended mode: premium in gold parentheses on same line
                                # Line 1: Combined qualities with premium in parentheses
                                combined_parts = build_inline_quality_parts(source_qq, prem_source_qq, quality_names, qrange, has_premium)
                                line1 = ' | '.join(combined_parts)
                                # Line 2: Total with premium shown separately
                                # Format: "Total: 38 (Premium: 4)" or "Total: 38" if no premium
                                if has_premium:
                                    line2 = f"{string_total}: {format_quality_count(total_all)} ([COLOR gold]{string_premium}: {prem_source_qq[TOTAL]}[/COLOR])"
                                else:
                                    line2 = f"{string_total}: {format_quality_count(total_all)}"
                                progress_line = build_progress_line(line1, line2)

                            else:  # display_mode == SourceSearchProgressStyle.SIMPLE
                                # Normal mode: all sources in one line, no distinction
                                all_sources_qq = [source_qq[i] + prem_source_qq[i] for i in range(len(source_qq))]
                                all_source_labels = [format_quality_count(sq) for sq in all_sources_qq]
                                # Line 1: All sources (normal + premium combined)
                                line1 = build_quality_line(all_source_labels, quality_names, qrange)
                                # Line 2: Total
                                line2 = f"{string_total}: {format_quality_count(total_all)}"
                                progress_line = build_progress_line(line1, line2)

                            if progress_dialog is not None:
                                progress_dialog.update(max(1, percent), progress_line, providers=info)
                        except Exception:
                            fflog_exc()

                    # Sleep less when we have sources, more when waiting
                    # sleep_time = 0.2 if len(self.sources) > 0 else 0.5
                    # xsleep(sleep_time)
                    xsleep(0.25)

                except Exception:
                    fflog_exc()
                    break

            # Final progress update
            try:
                final_message = L(30534, 'Finalizing sources...')
                if progress_dialog is not None:
                    progress_dialog.update(100, final_message)
            except Exception:
                pass
        finally:
            # Cleanup: stop remaining threads (a canceled search, a timeout, Kodi exit or the script abort)
            if threads := {th: srcmod for th, srcmod in threads.items() if th.is_alive()}:
                fflog(f'[SOURCES] Stopping {len(threads)} remaining providers: {", ".join(sorted(srcmod.name for srcmod in threads.values()))}')
            scope.set()  # the results are not used any more, stop the providers, their pools and network

        elapsed = timeout - (end_time - monotonic())
        fflog(f'[SOURCES] Completed: found {len(self.sources)} sources ({total_threads - len(threads)} / {total_threads} providers) in {elapsed:.1f}s')
        return self.sources

    def filter_sources(self, sources: Sequence[Source], *, ffitem: FFItem) -> list[Source]:
        """Return the sources of a search to show: prepared (`prepare_sources()`) and selected by the user (`select_sources()`)."""
        return self.select_sources(self.prepare_sources(sources, ffitem=ffitem), ffitem=ffitem)

    def prepare_sources(self, sources: Sequence[Source], *, ffitem: FFItem, final: bool = True) -> list[Source]:
        """
        Return the sources of a search the user selects from (all of them in the window): the ways to open them, the rules (`const`, a
        disabled one dropped), one of the same link, no disabled host, no excluded keyword, no unresolvable one (`hide`), their
        languages, colours and texts; the priority of their providers kept for the sort (`source_priority()`). Not `final` (the list while
        searching): no question to the debrids, the torrents they were not asked about left out (the list only grows). Prepared again: the
        rules from the start (the attributes of a rule stay only while it matches).
        """
        fflog('prepare_sources')

        sources = list(sources)  # make mutable copy

        # the ways to open each source now (DYNAMIC: accounts, debrids, add-ons of the user)
        resolve_map = self.search_resolve or ResolveMap.create()
        if final:
            resolve_map.check_cache(sources)
        elif resolve_map.tells_cache():
            sources = [src for src in sources if not (btih := torrent_hash(src)) or resolve_map.asked(btih)]
        for src in sources:
            src.resolvability = resolve_map.resolvability(src)
        fflog(f'[SOURCES] resolvability: {Counter(best.kind if (best := src.resolvability.best) else "-" for src in sources if src.resolvability)}')

        # the rules (`const.sources.rules`): every source as it is now (its ways to open it too), a disabled one dropped below
        for src in sources:
            src.attr = SourceAttribute()  # ponytail: the meta a rule merged stays, a rule of `resolvability` with meta would need a copy of it
            src.apply_rules()

        # Check if any items has unexpected keys and log them for debugging
        for src in sources:
            if unexpected := src.meta.keys() - SourceMeta.__annotations__.keys():
                fflog.warning(f'Source from provider {src.provider or "UNKNOWN"} has unexpected source keys: {", ".join(unexpected)}')

        # the language of the source: of its audio in the facts
        for src in sources:
            src['language'] = source_language(src)

        # Sort by provider+url to get deterministic order after multithreaded collection
        sources.sort(key=lambda src: (src.provider, src.url))

        # cache na odczyt ustawień PROVIDER.sort.order
        # providers of the search (with add-on providers), the scanned ones if there was no search
        search_mods = self.search_mods or self.source_mods
        # the same link from more providers (the torrent hash, else the URL): the best one stays
        sources = unique_sources(sources, priority={srcmod.name: srcmod.class_get('PRIORITY', 'priority', default=1) for srcmod in search_mods})
        # the colors and the priorities of the sources (the tree of the source providers)
        styles = NodeStyles(source_mods=search_mods)
        # cache na odczyt ustawień PROVIDER.library.color.identify2
        libcolors = LibraryColorSettings(source_mods=search_mods)

        # random.shuffle(sources)

        # filtrowanie po zabronionym host (source)
        sources = [src for src in sources if src.hosting.lower() not in const.sources_dialog.disabled_hosts]

        # filtrowanie po regułach (False wyłącza)
        # def is_enabled_by_rule(src: Source) -> bool:
        #     src.attr_update()
        #     enabled = True
        #     for pat, attr in const.sources.rules.items():
        #         if src.match(pat):
        #             enabled = attr is not False
        #             if attr and attr.meta:
        #                 src.meta.update(attr.meta)  # type: ignore[union-attr]  -- attr.meta has not required keys, but if they exist they match SourceMeta
        #             if attr and attr.badge:
        #                 src.badge_update(attr.badge)
        #             if attr and attr.final:
        #                 break
        #     return enabled
        # sources = [src for src in sources if src.is_enabled_by_applied_rules()]
        sources = [src for src in sources if src.enabled]

        # Filtrowanie po słowach kluczowych w opisie lub linku
        if const.sources.exclude_keywords:
            fflog(f"Filtering sources by keywords: {const.sources.exclude_keywords}")
            keywords_lower = [k.lower() for k in const.sources.exclude_keywords]
            sources = [
                src for src in sources
                if not any(
                    keyword in src.get("info", "").lower() or
                    keyword in src.get("url", "").lower() or
                    keyword in src.get("filename", "").lower() or
                    keyword in src.get("info2", "").lower()
                    for keyword in keywords_lower
                )
            ]

        # wywalanie zepsutych url (jesli nie są to pliki lokalne)
        # sources = sources_with_links(sources)

        # NOTE: the `checkquality` is used nowhere in the code !!!
        # for src in sources:
        #     if src.get('checkquality') and src['hosting'].lower() not in self.hq_host_list and src['quality'] not in ['SD', 'SCR', 'CAM']:
        #         src['quality'] = 'SD'

        # a local source (downloaded, the library) is of the first language of the user
        for src in sources:
            if src.get('local'):
                src.update({"language": self.get_primary_lang() or "en"})

        filtered: list[Source] = []
        # for d in debrid.debrid_resolvers:
        #     valid_hoster = {src.hosting for src in sources}
        #     valid_hoster = {hosting.lower() for hosting in valid_hoster if d.valid_url('', hosting)}
        #     filtered = [src for src in sources if src.hosting.lower() in valid_hoster]
        #     for src in filtered:
        #         src.meta['debrid'] = d.name
        # a source no way opens (resolvability): greyed out at the list end (below), hidden or shown as others
        if const.sources.resolve.unresolvable == 'hide':
            filtered.extend(src for src in sources if not src.unresolvable)
        else:
            filtered.extend(sources)
        sources = filtered

        # filter_out = {
        #     id(i)
        #     for i in sources
        #     if i["source"].lower() in self.hostblockDict and "debrid" not in i
        # }
        # sources = [i for i in sources if id(i) not in filter_out]

        # the priority of the provider in the sort of the user (`select_sources()`)
        self.source_priority = styles.priority

        extra_info = source_setting('extra_info')

        for src in sources:
            facts = src.facts
            # MULTI (audio of unknown languages): the language of the source (a Polish one keeps it, MULTI goes to the facts text)
            multi = is_multi(facts)
            if multi and src['language'] != 'pl':
                # and 'PL' not in src['language'].upper()  # założenie, że jak wykryto język PL, to nie ma potrzeby o dodatkowym ozaczeniu
                src['language'] = 'multi'  # wymiana języka
                src['info'] = re.sub(r'[/| ]*multi\b', '', src['info'], flags=re.I)  # wywalenie z opisu, aby nie było dubli
            if extra_info:
                t = facts_text(facts)
                if multi and src['language'] == 'pl' and 'multi' not in src['info'].lower():
                    src['info'] = ' | '.join(x for x in ('MULTI', src['info']) if x)  # right after the language: PL | MULTI | …
                """
                # pozbycie się tych samych oznaczeń ze zmiennej info
                if t:
                    src['info'] = re.sub(fr'(\b|[ ._|/]+)({'|'.join(t.split(' | '))})\b', '', src['info'], flags=re.I)
                """
                src.meta['info2'] = ' | '.join(x for x in [src.meta.get('info2'), t] if x.strip())

            src['color_identify'] = source_color(src, styles, libcolors)
            if text := src.meta['info2']:
                src.meta['info2'] = unescape(unquote(text))  # mam nadzieję, kolejność odkodowywania nie ma znaczenia

        return sources

    def select_sources(self, sources: Sequence[Source], *, ffitem: FFItem, state: SelectionState | None = None, filtered: bool = True) -> list[Source]:
        """
        Return the prepared sources (`prepare_sources()`) the selection of the user lets through (`state`, None: the current one of the media
        of the item; all of them without `filtered` or with `force_all_sources`) in its order.
        """
        if state is None:
            state = current_state(item_media(ffitem))
        selection = compile_selection(state, langs=self.get_langs(), priority=self.source_priority)
        return selected_sources(sources, selection, filtered=filtered and not const.dev.sources.force_all_sources)

    def provider_module(self, name: str) -> ProviderModule | None:
        """Return the provider module by name: of the last search (also add-on providers) or of the scan."""
        return next((sm for mods in (self.search_mods, self.source_mods) for sm in mods if sm.name == name), None)

    def _resolve_part(self, url: str, *, routes: Sequence[ResolveRoute], direct: bool, as_is: bool, pack: PackKind | None = None,
                      ref: MediaRef | None = None) -> str:
        """
        Return the playable URL of a link the provider gave: the ways of the source (its resolvability) in order, the next
        one if a way fails; at last the general way (a source tried without a way, or the estimate by the hosting missed),
        a link no resolver knows played as it is only if `as_is` (`played_as_is()`: not a magnet, a premium link...).
        Empty if a resolver took the link and failed (as before: "no stream") or nothing opened it. A debrid opens the file
        of the episode `ref` of a torrent `pack`.
        """
        from ..resolvers import resolve_local
        # kinds of the resolvers which took the link (not asked again by the general way)
        taken: set[ResolveKind] = set()
        for route in routes:
            try:
                if route.kind == 'debrid':
                    if resolved := debrid.resolver(url, route.name, pack=pack, ref=ref):
                        return resolved
                elif route.kind == 'ff':
                    taken.add('ff')
                    if const.sources.local_resolvers and (resolved := resolve_local(url)):
                        return resolved
                elif route.kind == 'resolveurl':
                    if (resolveurl := get_resolveurl()) is not None:
                        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
                        if hmf.valid_url():
                            taken.add('resolveurl')
                            if resolved := hmf.resolve():
                                return resolved
                else:  # account, direct, plugin, provider: the provider's link is played as it is
                    return url
            except Exception:
                fflog_exc()
            fflog(f'[SOURCES] {route.kind} {route.name!r} did not open {url!r}, the next way')
        if direct:
            return url
        # FanFilm's custom resolvers take precedence over upstream resolveurl for hosts we maintain ourselves
        # (see lib/resolvers/). Toggle: const.sources.local_resolvers.
        if 'ff' not in taken and const.sources.local_resolvers and (resolved := resolve_local(url)):
            return resolved
        if 'resolveurl' in taken:
            return ''
        if (resolveurl := get_resolveurl()) is None:
            fflog.warning('resolveurl module not available')
            return url if as_is else ''
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=True, include_universal=False)
        if hmf.valid_url():
            return hmf.resolve() or ''
        if not as_is:
            fflog(f'[SOURCES] no way opened {url!r}, not played as it is')
        return url if as_is else ''

    def resolve_source(self, item: Source, /, info: bool = False, for_resolve: SourceResolveKwargs | None = None, **kwargs) -> Source | None:
        """
        Return the source resolved, its `stream` the result of the provider `resolve()` (the old text forms parsed): its
        link opened by the ways of the source (debrid, resolvers) unless it is the stream itself; None if it does not open.
        """
        fflog("sourcesResolve")
        if for_resolve is None:
            for_resolve = {}
        try:
            if item is None:
                raise ValueError('No source item')
            if item.get('fake'):
                if resolve_to := item.get('resolve_to'):
                    return item.with_stream(resolve_result(str(resolve_to)))
                raise ValueError('Fake source item')

            url = item["url"]

            direct = item.get("direct", False)
            local = item.get("local", False)
            if item.unresolvable and not const.sources.resolve.try_unresolvable:
                raise no_way(url, item)

            provider = item["provider"]
            if (src_mod := self.provider_module(provider)) is None:
                raise ValueError(f'No provider {provider!r} to resolve the source')
            fflog(f'Go to {item.provider!r} to resolve {url!r}')
            control.window().clearProperty(SUBTITLES_PROPERTY)  # not the subtitles of an earlier source
            if 'data' in item.meta:  # the private data of the item back to its provider
                for_resolve = {**for_resolve, 'data': item.meta['data']}
            stream = resolve_result(src_mod.provider.resolve(url, **for_resolve))

            if error := stream.get('error'):
                fflog.warning(f'Dead link in provider {provider!r} ({item.get("hosting", "unknown")}): {url!r}, {error}')
                raise DeadLink(error.get('message') or L(30337, 'Selected link is not working'))
            if subtitles := provider_subtitles():
                stream.setdefault('subtitles', subtitles)

            target = stream.get('url', '')
            if 'parts' not in stream and "://" not in target and not local and not target.startswith('magnet:'):  # a magnet: only a debrid way opens it
                # if provider in ('netflix', 'external'):
                #    return url
                raise ValueError(f'Invlaid URL {target!r} in provider {provider!r}')

            if not local and not stream.get('final'):
                parts = stream.get('parts') or [target]
                opened = []
                for part in parts:
                    # Plugin URLs are internal Kodi paths and should not be passed to external resolvers.
                    if not part.startswith("plugin://"):
                        part = self._resolve_part(part, routes=item.resolvability.routes if item.resolvability else (), direct=direct,
                                                  as_is=played_as_is(part, item), pack=item.get('pack'), ref=item.ffitem.ref)
                    opened.append(part)
                if len(opened) > 1:
                    stream['parts'] = opened
                else:
                    # a resolver gives a text too (`url|headers`, `isa+url`), its headers after the provider's ones
                    found = resolve_result(opened[0])
                    stream = cast(ResolveResult, {**stream, **found, 'headers': {**stream.get('headers', {}), **found.get('headers', {})}})
                    if not stream.get('headers'):
                        stream.pop('headers', None)

            targets = stream.get('parts') or [stream.get('url', '')]
            if not all(targets):  # the ways of the source did not open it (a debrid failed, the transfer canceled...)
                fflog.warning(f'No way opened the source of provider {provider!r}: {url!r}')
                if ways := (item.resolvability.labels() if item.resolvability else []):
                    raise DeadLink(L(30712, 'The source did not open ({ways})').format(ways=', '.join(ways)))
                raise no_way(url, item)

            if any(part.split("?")[0].split("&")[0].split("|")[0].rsplit(".")[-1].replace("/", "").lower() == "rar" for part in targets):
                raise ValueError(f'RAR in URL in provider {provider!r}')

            target = stream.get('url', '')
            if 'parts' not in stream and target.startswith("http") and ".m3u8" in target:
                # a copy: the client adds its own headers (User-Agent...) to the dict, not to the stream
                result = client.request(target, headers=dict(stream.get('headers', {})), output="geturl", timeout=20)
                if result is None:
                    raise DeadLink(f'Resolve m3u8 failed in provider {provider!r}')
            # elif url.startswith("http"):
            #     return url

            resolved = item.with_stream(stream)
            fflog(f'[SOURCES] resolve to {resolved.url!r} in provider {provider!r}')
            return resolved

        except DeadLink as e:
            # Przewidywane błędy (martwe źródło, invalid URL, itd.) - logujemy jako warning
            error_msg = str(e)
            fflog.warning(f'Failed to resolve source: {error_msg}')
            if info:
                control.infoDialog(f'{error_msg}', sound=False, icon='INFO')
            return

        except Exception as e:
            # Nieprzewidziane błędy - logujemy jako exception
            fflog_exc()
            error_info = L(32401, 'No stream available')
            if info:  # the caller tells the user only by this
                # player.cancel()
                control.infoDialog(f'{error_info}: {e}' if str(e) else error_info, sound=False, icon='INFO')
            elif str(e):
                import xbmcgui
                xbmcgui.Dialog().notification('FanFilm', f'{error_info}: {e}')
            return

    # def sourcesDirect(self, items):
    #     fflog("sourcesDirect")

    #     filter = [
    #         i
    #         for i in items
    #         if i["source"].lower() in self.hostblockDict and i["debrid"] == ""
    #     ]
    #     items = [i for i in items if i not in filter]

    #     items = [
    #         i
    #         for i in items
    #         if ("autoplay" in i and i["autoplay"]) or "autoplay" not in i
    #     ]

    #     if settings.getBool("autoplay.sd"):
    #         items = [
    #             i
    #             for i in items
    #             if i["quality"] not in ["4K", "1440p", "1080p", "1080i", "HD"]
    #         ]

    #     u = None

    #     header = control.addonInfo("name")
    #     header2 = header.upper()

    #     try:
    #         control.sleep(1000)

    #         progress_dialog_mode = ProgressDialogMode(settings.getInt("progress.dialog"))
    #         if progress_dialog_mode is ProgressDialogMode.BACKGROUND:
    #             progressDialog = control.progressDialogBG()
    #         else:
    #             progressDialog = control.progressDialog()
    #         progressDialog.create(header, "")
    #         progressDialog.update(0)
    #     except Exception:
    #         pass

    #     for i in range(len(items)):
    #         try:
    #             if progressDialog.iscanceled():
    #                 break
    #             progressDialog.update(
    #                 int((100 / float(len(items))) * i),
    #                 str(items[i]["label"]) + "\n" + str(" "),
    #             )
    #         except Exception:
    #             progressDialog.update(
    #                 int((100 / float(len(items))) * i),
    #                 str(header2) + "\n" + str(items[i]["label"]),
    #             )

    #         try:
    #             if xbmc.Monitor().abortRequested():
    #                 return sys.exit()

    #             url = self.sourcesResolve(items[i])
    #             if u is None:
    #                 u = url
    #             else:
    #                 break
    #         except Exception:
    #             pass

    #     try:
    #         progressDialog.close()
    #     except Exception:
    #         pass

    #     return u

    def get_langs(self, *, default='pl') -> list[str]:
        """Accepted providers' language codes from settings (codes joined by ",")."""
        return user_languages(default=default)

    def get_primary_lang(self, *, default='') -> str:
        langs = self.get_langs(default=default)
        return langs[0] if langs else default

    def getTitle(self, title):
        fflog("getTitle")
        title = cleantitle.normalize(title)
        return title

    def scan_source_modules(self, *, ffitem: FFItem) -> None:
        self.itemProperty = f'{control.plugin_id}.container.items'
        self.metaProperty = f'{control.plugin_id}.container.meta'
        self.source_mods = scan_providers(ffitem=ffitem)
        try:
            native_catalog(mods=self.source_mods)  # the modules are imported now: the catalog of the native providers costs only its stamp
        except Exception:
            fflog_exc()
        if self.DEBUG_SINGLE_PROVIDER:
            allowed = {self.DEBUG_SINGLE_PROVIDER, self.DEBUG_SINGLE_PROVIDER.partition(':')[0]}
            self.source_mods = [sm for sm in self.source_mods if sm.name in allowed or is_provider_addon_protocol(sm.provider)]
        if not const.dev.sources.force_all_sources:
            self.source_mods = [sm for sm in self.source_mods if module_searched(sm)]
        fflog(f'scan {len(self.source_mods)} source module(s)')

        supported_hosts()  # here (the main thread, before providers), the old API providers get them
        self.hq_host_list = [
            "gvideo",
            "google.com",
        ]
