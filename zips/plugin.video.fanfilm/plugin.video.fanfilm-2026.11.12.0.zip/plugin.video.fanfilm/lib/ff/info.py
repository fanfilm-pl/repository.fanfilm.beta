"""Tiny TheMovieDB.org API getter."""

from __future__ import annotations
from typing import Optional, Union, Any, Sequence, Mapping, Iterable, Iterator, Callable, ClassVar, NamedTuple
from typing import overload, TYPE_CHECKING
from typing_extensions import get_args as get_typing_args, Literal, TypedDict, NotRequired, cast
import re
from enum import Enum
from time import time as cur_time
from datetime import datetime, date as dt_date, timedelta
from functools import lru_cache
from itertools import chain
from operator import attrgetter
import json
from concurrent.futures import ThreadPoolExecutor
from attrs import evolve
from ..api.tmdb import TmdbApi, TmdbCredentials, TmdbItemJson, ExternalIdType, DetailsAllowed, SkelOptions, seasons_iter, episodes_iter
from ..api.tmdb import MediaRequest, LOCALE_EN, LOCALE_ORIG
from ..api.trakt import TraktApi
from ..defs import MediaRef, MediaProgress, MediaProgressItem, NextWatchPolicy, VideoIds, Pagina, ItemList, RefType, FFRef
from . import apis
from .types import JsonData, SequenceProto
from .settings import settings
from .locales import country_translations
from .calendar import fromisoformat
from .item import FFItem, FFItemDict, FFActor, FFTitleAlias, FFEpisodeGroup, FFEpisodeGroupType
from .db.playback import get_playback_rows, get_played_episodes, live_play, MediaPlayInfo, MediaPlayInfoDict, PlayedEpisode
from .progress import merge_playback, merge_state, group_rows, show_progress, bar_progress
from .accounts import accounts, account_enabled
from .db import media
from .db.media import MediaInfoRow, MediaAiredRow
from .db.freshness import compute_expires_at, aired_expires_at
from ..api.tmdb import tmdb_app as tmdb_provider
from .art import Art
from ..kolang import L
from ..api.trakt import trakt as trakt_provider
from ..api.mdblist import mdblist_app as mdblist_provider, MdbList
from .tricks import pairwise, AlwaysFalse, JsonEncoder
from .kodidb import video_db
from ..service.client import service_client
from ..kolang import KodiLabels
from .logs import fflog, fflog_exc
from .debug import logtime
from ..ff.control import apiLanguage
from cdefs import InfoDetails, const_value
from const import const, CONST_REF, MediaWatchedMode
if TYPE_CHECKING:
    from concurrent.futures import Future
    from argparse import ArgumentParser
    from .art import ArtInfo
    from ..defs import MainMediaType, IdService, AllIdsDict
    from ..indexers.defs import CodeId


#: Supported media types and their supported directly ID in services.
#: ID services of a link stored from a resolution (MDBList, TMDB find, Trakt).
ID_LINK_SERVICES: frozenset[str] = frozenset({'imdb', 'trakt', 'tvdb', 'mdblist', 'mal'})
#: ID services TMDB gives for its media (external IDs) - the authority of these links.
TMDB_ID_SERVICES: frozenset[str] = frozenset({'imdb', 'tvdb'})
#: ID services 1 : 1 with a title (a value belongs to one title of its type); anime IDs (kitsu, mal, anilist) are 1 : N.
UNIQUE_ID_SERVICES: frozenset[str] = frozenset({'imdb', 'trakt', 'tvdb', 'mdblist'})

SERVICE_MEDIA_ID: dict[RefType, set[IdService]] = {
    'movie': {'tmdb', 'imdb', 'tvdb'},
    'show': {'tmdb', 'imdb', 'tvdb'},
    'season': {'tvdb'},
    'episode': {'imdb', 'tvdb'},
    'person': {'tmdb', 'imdb'},
    'collection': {'tmdb'},
}


def tmdb_locale() -> str:
    """Get user locale (language)."""
    return apiLanguage().get('tmdb', 'pl-PL')


@lru_cache(maxsize=1)  # by the value of const: a reload of const gives a new one
def language_aliases(aliases: Sequence[Sequence[str]]) -> dict[str, Sequence[str]]:
    """Return all aliases of a language by each of them (`const.tmdb.language_aliases`)."""
    return {lng: alias for alias in aliases for lng in alias}


def _node_details(details: InfoDetails, ref: MediaRef, *, primary: bool) -> InfoDetails:
    """Per-node content fingerprint (InfoDetails & ITEM_MASK) derived from a request's `details`.

    The directly-requested node ("primary") carries the item-level flags; a show/season/episode
    obtained as a sub-fetch carries its own level's flag group, shifted down to INFO_* via
    `.show()`/`.season()`/`.episode()`. Stored on `FFItem.details` (which masks to ITEM_MASK) at
    parse, and used later for cache sufficiency.
    """
    if primary:
        return details & InfoDetails.ITEM_MASK
    if ref.is_episode:
        return details.episode()        # already masked to ITEM_MASK
    if ref.is_season:
        return details.season()         # already masked to ITEM_MASK
    if ref.is_show:
        return details.show()           # already masked to ITEM_MASK
    return details & InfoDetails.ITEM_MASK


class Credits(NamedTuple):
    actors: list[FFActor]
    directors: list[str]
    writers: list[str]
    crew: tuple[FFActor, ...] = ()


class MyTmdb(TmdbApi):
    """API for themoviedb.org."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    def credentials(self) -> TmdbCredentials:
        """Return current credencials."""
        api_key: str = const.dev.tmdb.api_key or settings.getString("tmdb.api_key") or apis.tmdb_API
        return TmdbCredentials(api_key=api_key)


class Progress(Enum):
    """FFItem progress mode."""
    NO = 'no'
    BASIC = 'basic'
    FULL = 'full'


class ProgressBarMode(Enum):
    """FFItem progress bar mode."""
    #: Do not show progressbar at all.
    NONE = 'none'
    #: Show video percent progress (PERCENT) if video progress >0% and < 100% else show nothing.
    WATCHING = 'watching'
    #: Show only watched videos (movies and episodes progresses are skiped).
    WATCHED = 'watched'
    #: Show video percent progress.
    PERCENT = 'percent'
    #: Show video percent progress and watched in background (use const.indexer.progressbar.watched.*).
    PERCENT_AND_WATCHED = 'percent_and_watched'


"""Object to mark already watched progress in progreassbar."""
AREADY_WATCHED = AlwaysFalse()


class ItemInfoKwargs(TypedDict):
    """ffinfo.get_items() args."""
    #: FFinfo data limit, now only cast/crew limit, None - default, 0 - no cast, N – max N actors.
    crew_limit: NotRequired[int | None]
    #: Obtain progress details.
    progress: NotRequired[Progress]
    #: Scan details, what exaclty to obtain.
    details: NotRequired[InfoDetails]


class GetItemKwargs(ItemInfoKwargs):
    """ffinfo.get_items() args."""
    #: If true, return None in ref is not obtained (useful for zip()) else skip missing item.
    keep_missing: NotRequired[bool]
    #: Get more info about shows (and its seasons) to obtain episodes.
    duplicate: NotRequired[bool]
    #: Convert to episode groups. If ID (str) is used extra data will be collected.
    episode_group: NotRequired[str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None]


#: Version of the parsed item (`parse_tmdb_item()` and its helpers): bump it on every change of the parsed result,
#: then cached nodes are parsed again when they are used (`DB_VERSION` of the media DB is for its schema only).
PARSE_VERSION: int = 2


def _episodes_by_show(playback_info: MediaPlayInfoDict) -> dict[int, list[MediaPlayInfo]]:
    """Return rows of episodes by show FFID."""
    episodes: dict[int, list[MediaPlayInfo]] = {}
    for ref, pb in playback_info.items():
        if ref.is_episode:
            episodes.setdefault(ref.ffid, []).append(pb)
    return episodes


def _aired_refs(row: Optional[MediaAiredRow], ffid: int, season: Optional[int] = None) -> list[MediaRef]:
    """
    Return the refs of the aired episodes of the show `ffid` from its aired map (`media.db#aired`, the regular seasons), of the
    `season` only if given; empty with no map or a map without ranges (a show with no seasons in its metadata).
    """
    if row is None:
        return []
    return row.episode_refs(season)  # the map of the show `ffid`


def _series_ids(ref: MediaRef) -> AllIdsDict:
    """The IDs of its series a season / episode ref carries (but `tmdb`, the ref key): not the IDs of the season / episode."""
    if ref.season is None:
        return {}
    return cast('AllIdsDict', {srv: val for srv, val in ref.video_ids.all_ids().items() if srv != 'tmdb'})


#: Facets of the TMDB details (`FFItem.facets`): kind -> (the details key, the code key, the name key, the logo key).
FACET_SOURCES: dict[str, tuple[str, str, str, str | None]] = {
    'genre':    ('genres', 'id', 'name', None),
    'language': ('spoken_languages', 'iso_639_1', 'english_name', None),
    'country':  ('production_countries', 'iso_3166_1', 'name', None),
    'company':  ('production_companies', 'id', 'name', 'logo_path'),
    'network':  ('networks', 'id', 'name', 'logo_path'),
}


class InfoProvider:
    """Media info provider."""

    # Must be supported by TMDB API get_temss() to mark as broken.
    _supported_details_types = {'movie', 'show', 'season', 'episode', 'person', 'collection'}

    Progress = Progress

    # All language aliases: `language_aliases()`

    # Field names in translation object.
    TRANSLATE_FILEDS: ClassVar[Iterable[str]] = ('homepage', 'overview', 'runtime', 'tagline', 'title')

    # Skeleton EN locales
    EN_LOCALES: ClassVar[Sequence[str]] = ('en-US', 'en-GB', 'en')
    # Media (like image) non-locales
    NON_LOCALES: ClassVar[Sequence[str]] = ('xx-XX', 'xx', 'null')

    def __init__(self, tmdb: Optional[TmdbApi] = None, trakt: TraktApi | None = None, mdblist: MdbList | None = None) -> None:
        if tmdb is None:
            if trakt is not None and hasattr(trakt, 'tmdb'):
                tmdb = trakt.tmdb
            else:
                lang: str = tmdb_locale()
                tmdb = MyTmdb(lang=lang)

        self.tmdb: TmdbApi = tmdb
        self.trakt: TraktApi | None = trakt
        self._mdbist: MdbList | None = mdblist
        #: API locale labels
        self.api_labels: KodiLabels = KodiLabels(tmdb_locale())
        #: Art services
        self.art = Art()

    def reset(self) -> None:
        """Reset settings to obtain settings change."""
        # Forget current language, will be taken from settings (api.language).
        self.tmdb.lang = tmdb_locale()
        self.api_labels = KodiLabels(self.tmdb.lang)
        self.art.reset()
        video_db.reset()  # the FF plays of Kodi DB: read once per call

    @property
    def mdblist(self) -> MdbList | None:
        """MDBList API."""
        if self._mdbist is None or not self._mdbist.api_key:
            return None
        return self._mdbist

    def _parse_stamp(self) -> str:
        """Return stamp of the parser version and the settings the parser uses (art), cached nodes keep it."""
        return f'{PARSE_VERSION}:{self.art.settings!r}'

    @staticmethod
    def _effective_crew_limit(limit: Optional[int]) -> int:
        """Return real cast / crew limit: None means the user setting, zero means no limit (see parse_credits)."""
        if limit is None:
            limit = settings.getInt('actor_count_limit')
        return limit or 0

    @staticmethod
    def _crew_sufficient(stored: Optional[int], want: int) -> bool:
        """Return True if a node parsed with `stored` limit has enough persons for `want` limit (zero is no limit)."""
        if stored is None:
            return False  # unknown, e.g. cached by an older version
        return stored == 0 or (want != 0 and stored >= want)

    @staticmethod
    def _trim_crew(item: FFItem, want: int) -> None:
        """Cut cast / crew of a node cached with a higher limit, to return the same as a fresh parse does."""
        if want == 0 or item.crew_limit is None or (item.crew_limit != 0 and item.crew_limit <= want):
            return
        vtag = item.vtag
        vtag.setCast(vtag.getActors()[:want])
        vtag.setDirectors(vtag.getDirectors()[:want])
        vtag.setWriters(vtag.getWriters()[:want])
        vtag.setCrew(())  # the crew list is built only with no limit
        item.crew_limit = want

    def parse_credits(self, item: TmdbItemJson, *, limit: Optional[int] = None) -> Credits:
        """Parse movie/show/season/episode credits (cast and crew)."""

        def make_img(person: JsonData) -> str:
            img = person.get('profile_path')
            if img:
                img = f'{iurl}{img}'
            return img or ''

        def make_actor(persons: list[JsonData], i: int = -1) -> Iterator[FFActor]:
            for p in persons:
                # TODO: id, gender, popularity
                yield FFActor(name=p['name'], role=p.get('character'), order=p.get('order', i), thumbnail=make_img(p),
                              ffid=VideoIds.ffid_from_tmdb(p))

        def make_crew_name(persons: list[JsonData], jobs: set[str]) -> Iterator[str]:
            for p in persons:
                if p.get('job') in jobs:
                    # TODO: id, gender, popularity, job, department
                    yield p['name']

        def make_crew(persons: list[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                # TODO: id, gender, popularity, job, department
                yield FFActor(name=p['name'], role=p.get('job'), order=p.get('order', i), thumbnail=make_img(p),
                              ffid=VideoIds.ffid_from_tmdb(p))

        def make_agg_actor(persons: list[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                # TODO: id, gender, popularity
                character = ', '.join(ch for r in p.get('roles', ()) for ch in (r.get('character'),) if ch)
                yield FFActor(name=p['name'], role=character, order=p.get('order', i), thumbnail=make_img(p),
                              ffid=VideoIds.ffid_from_tmdb(p))

        def make_agg_crew_name(persons: list[JsonData], jobs: set[str]) -> Iterator[str]:
            for p in persons:
                for job in p.get('jobs', ()):
                    # TODO: id, gender, popularity, job, department
                    if job['job'] in jobs:
                        yield p['name']

        def make_agg_crew(persons: list[JsonData]) -> Iterator[FFActor]:
            for i, p in enumerate(persons):
                for job in p.get('jobs', ()):
                    # TODO: id, gender, popularity, job, department
                    if isinstance(job, Mapping):
                        job = job.get('job')
                    if isinstance(job, str):
                        yield FFActor(name=p['name'], role=job, order=p.get('order', i), thumbnail=make_img(p),
                                      ffid=VideoIds.ffid_from_tmdb(p))

        if limit is None:
            limit = settings.getInt('actor_count_limit')
        no_limit = 10**9
        if not limit:
            limit = no_limit
        iurl = self.tmdb.person_image_url
        dir_jobs = {'Director'}
        wr_jobs = {'Writer', 'Staff Writer', 'Story'}
        # TODO: parse "guest_stars" ?
        crew = ()
        if 'aggregate_credits' in item:
            credits = item['aggregate_credits']
            actors = make_agg_actor(credits.get('cast', ()))
            directors = make_agg_crew_name(credits.get('crew', ()), dir_jobs)
            writers = make_agg_crew_name(credits.get('crew', ()), wr_jobs)
            if limit >= no_limit:
                crew = make_agg_crew(credits.get('crew', ()))
        else:
            credits = item.get('credits', {})
            actors = make_actor(credits.get('cast', ()))
            directors = make_crew_name(credits.get('crew', ()), dir_jobs)
            writers = make_crew_name(credits.get('crew', ()), wr_jobs)
            if limit >= no_limit:
                crew = make_crew(credits.get('crew', ()))
        actors = list({a.getName(): a for a in actors}.values())
        directors = list(dict.fromkeys(directors))
        writers = list(dict.fromkeys(writers))
        crew = tuple(dict.fromkeys(crew))
        if limit:
            actors, directors, writers = actors[:limit], directors[:limit], writers[:limit]
        return Credits(actors=actors, directors=directors, writers=writers, crew=crew)

    def translation_order(self,
                          *,
                          original_language: str,
                          original_coutries: Sequence[str],
                          locale: str | None = None,
                          ) -> tuple[str, ...]:

        aliases = language_aliases(const.tmdb.language_aliases)

        def lang_aliases(lng: str) -> Sequence[str]:
            return aliases.get(lng, (lng,))

        if locale is None:
            locale = tmdb_locale()
        lang = locale.partition('-')[0]

        orig_langs: Sequence[str] = lang_aliases(original_language)
        trans_order = tuple(dict.fromkeys((locale, *(lang_aliases(lang)), *self.EN_LOCALES, *self.NON_LOCALES,
                                           *(f'{lng}-{c}' for lng in orig_langs for c in original_coutries),
                                           *orig_langs)))
        return trans_order

    def parse_tmdb_item(self,
                        item: TmdbItemJson,
                        *,
                        locale: str | None = None,
                        crew_limit: int | None = None,
                        parent_ffitem: FFItem | None = None,
                        details: InfoDetails | None = None,
                        _primary: bool = True,
                        ) -> Optional[FFItem]:
        """Parse single movie/show/season/episode data.

        `details` is the request's InfoDetails; when given, each parsed node gets its content
        fingerprint (`FFItem.details`) so it can be cached and matched (`_node_details`). `_primary`
        is False for sub-nodes built by recursion (their fingerprint uses the shifted flag group).
        """

        def dget(dct: dict, key: str, default: Any = None) -> Any:
            keys = key.split('/')
            for key in keys[:-1]:
                dct = dct.get(key, {})
            return dct.get(keys[-1], default)

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item, *en_translations, *orig_translations):
                for key in keys:
                    value = dget(data, key)
                    if value:
                        meth(value)
                        return

        def set_dt_if(meth: Callable, value: str, fmt: str = '%Y-%m-%d') -> None:
            if value:
                try:
                    dt = fromisoformat(value)
                except ValueError:
                    pass
                else:
                    meth(dt)

        def translate(*keys:
                      Literal['title', 'name', 'tagline', 'overview'],
                      default: str = '',
                      order: Optional[Sequence[str]] = None,
                      direct: bool = True,
                      ) -> str:
            if order is None:
                order = trans_order
            for lang in order:
                for key in keys:
                    if val := item_translations.get(lang, {}).get(key):
                        return val
            if direct:
                for key in keys:
                    if val := item.get(key):
                        return val
            return default

        if not item.get('success', True):
            return None

        if locale is None:
            locale = tmdb_locale()
        lang = locale.partition('-')[0]

        # Translation order.
        orig_lang: str = item.get('original_language') or 'en'
        orig_countries: Sequence[str] = item.get('origin_country') or ()
        trans_order = self.translation_order(original_language=orig_lang, original_coutries=orig_countries, locale=locale)
        en_trans_order = self.EN_LOCALES

        # Translations by locale (eg. en-US) and language (eg. en),
        # values: name, homepage, tagline, overview.
        item_translations: dict[str, JsonData] = {f"{t['iso_639_1']}-{t['iso_3166_1']}": t['data']
                                                  for t in item.get('translations', {}).get('translations', ())}
        # Add default translation if it's not in "translations" object.
        if 'original_language' in item:
            data = {key: value for key in ('title', 'name') if (value := item.get(f'original_{key}'))}
            for c in item.get('origin_country', ()):
                item_translations.setdefault(f'{orig_lang}-{c}', data)
            item_translations.setdefault(orig_lang, data)
        else:
            item_translations.setdefault(locale, item)
        # Fix missing names if translation is item directly.
        # If lang == orig_lang same values (as "title") has empty value in translation object. But item['title'] has translated name.
        if orig_lang == lang:  # fix missing names if translation is item directly
            for key in self.TRANSLATE_FILEDS:
                if value := item.get(key):
                    for c in ('', *orig_countries):
                        tr = item_translations.get(f'{lang}-{c}' if c else lang, {})
                        if not tr.get(key):
                            tr[key] = value
        # Add iso_639_1 keys (language only, without country code).
        item_translations = {k: tr for loc, tr in item_translations.items()  # if tr.get('name') or tr.get('title')
                             for k in (loc, loc.partition('-')[0])}
        # Fix broken translation for original language.
        if orig_lang == lang and lang not in item_translations:
            item_translations[lang] = {k: item[k] for k in self.TRANSLATE_FILEDS if item.get(k)}

        en_translations: Sequence[JsonData] = tuple(tr for lng in self.EN_LOCALES if (tr := item_translations.get(lng)))
        orig_translations: Sequence[JsonData]
        if orig_lang:
            orig_translations = tuple(tr for lng, tr in item_translations.items() if lng.partition('-')[0] == orig_lang)
        else:
            orig_translations = ()

        ref = MediaRef(*item['_ref'])
        ff = FFItem(ref)
        if ref.season is not None:
            if 'id' not in item:
                fflog(json.dumps(item, indent=2, cls=JsonEncoder))
            if ref.is_season:
                # fake tmdb season id (show_id and season_number)
                # NOTE: now season FFID is replaced to volatile FFID in InfoProvider._set_volatile_ffid().
                if sz_ref := ref.denormalize():
                    ff.ffid = sz_ref.ffid
                else:
                    # TODO: find first episode and use its ffid as 'season' ffid
                    ...
        if not ff.ffid:
            ff.ffid = VideoIds.ffid_from_tmdb(item)
        if ref.real_type in ('movie', 'episode'):
            ff.mode = ff.Mode.Playable
        else:
            ff.mode = ff.Mode.Folder
        ff.source_data = item
        ff.collection_data = item.get('belongs_to_collection') or None
        ff.parse_stamp = self._parse_stamp()
        if details is not None:
            ff.details = _node_details(details, ref, primary=_primary)   # content fingerprint (for cache)

        vtag = ff.getVideoInfoTag()
        titletag: str = 'title' if ref.type == 'movie' else 'name'

        if 'id' not in item:
            fflog.error(f'ERROR: no ID !!!   XXXXXXXXXXXXXXXXX\n\n{json.dumps(item, indent=2, cls=JsonEncoder)}')
        elif ff.ffid in VideoIds.KODI:
            vtag.setDbId(ff.ffid)  # Kodi DBID
        set_if(vtag.setIMDBNumber, 'imdb_id', 'external_ids/imdb_id')
        vtag.setUniqueIDs({name: str(val)
                           for name, key in (('tmdb', 'id'), ('tmdb_id', 'id'), ('imdb', 'imdb_id'), ('imdb', 'external_ids/imdb_id'),
                                             ('tvdb', 'tvdb_id'), ('tvdb', 'external_ids/tvdb_id'))
                           for val in (dget(item, key),) if val},
                          'imdb')  # default id type
        vtag.setMediaType(ref.real_type)

        # season and episode should be set in FFItem(ref)
        # skip vtag.setSeason()
        # skip vtag.setEpisode()

        # duration
        runtime = item.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)

        # year and dates (premiered, first aired)
        date = None
        if ref.type == 'movie':
            date_keys = ('release_date', )
        else:
            date_keys = ('first_air_date', 'air_date')
        for date_key in date_keys:
            if date_str := item.get(date_key):
                try:
                    date = fromisoformat(date_str)
                    break
                except ValueError:
                    pass
        if date:
            vtag.setYear(date.year)
        set_if(vtag.setFirstAired, 'first_air_date', 'air_date')
        set_if(vtag.setPremiered, 'release_date')
        # fallback to first aired date of first episode
        if not date and ref.is_season and (episodes := item.get('episodes')):
            if date_str := episodes[0].get('air_date'):
                try:
                    date = fromisoformat(date_str)
                    vtag.setYear(date.year)
                    vtag.setFirstAired(date_str)
                except ValueError:
                    pass

        # titles
        vtag.setTitle(translate('title', 'name', default=ff.title))
        set_if(vtag.setOriginalTitle, f'original_{titletag}')
        orig_en_title = vtag.getOriginalTitle() if item.get('original_language', 'en') == 'en' else ''
        vtag.setEnglishTitle(translate('title', 'name', order=en_trans_order, direct=False, default=orig_en_title))
        if ref.type == 'show':
            if ref.season is None:  # show
                vtag.setTvShowTitle(ff.title)
                vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
            elif parent_ffitem:  # season or episode
                vtag.setTvShowTitle(parent_ffitem.vtag.getTVShowTitle())
                vtag.setEnglishTvShowTitle(parent_ffitem.vtag.getEnglishTvShowTitle())
        ff.label = ff.title
        if aliases := item.get('alternative_titles'):
            ff.aliases_info = self._parse_alternative_titles(aliases, locale=(*self._aliases_locales(), *orig_countries))

        # locale (language, country)
        ff.setProperty('original_language', orig_lang)
        ff.setProperty('original_countries', ','.join(orig_countries))

        # plot, outline and tag line
        vtag.setPlotBase(translate('overview', default=vtag.getPlot()))
        # vtag.setPlotOutline()
        vtag.setTagLine(translate('tagline', default=vtag.getTagLine()))

        # set genres
        vtag.setGenres([g['name'] for g in item.get('genres', ())])

        # casts / actors, directors, writers; a node without them (person, collection) has nothing cut: no limit (cache sufficiency)
        ff.crew_limit = 0
        if ref.type == 'person':
            self._parse_tmdb_person(item, ff, en_translations=en_translations, orig_translations=orig_translations)
        elif ref.type == 'collection':
            self._parse_tmdb_collection(item, ff, en_translations=en_translations, orig_translations=orig_translations)
        else:
            credits = self.parse_credits(item, limit=crew_limit)
            ff.crew_limit = self._effective_crew_limit(crew_limit)
            vtag.setCast(credits.actors)
            vtag.setDirectors(credits.directors)
            vtag.setWriters(credits.writers)
            vtag.setCrew(credits.crew)  # FF extension

            # --- art ---
            ff.setArt(self.art.parse_art(item=item, translation_order=trans_order, ref=ref))

        # countries and MPAA
        countries = country_translations()
        vtag.setLanguageCodes([item.get('original_language') or 'en'])
        vtag.setCountryCodes([c['iso_3166_1'] for c in item.get('production_countries', ())])
        vtag.setCountries([countries.get(c['iso_3166_1'], c['name']) for c in item.get('production_countries', ())])
        vtag.setMpaaList(sorted(cert for rel in item.get('release_dates', {}).get('results', ())
                                for cert in (rel.get('certification', ''),) if cert))
        vtag.setStudios([name for st in item.get('production_companies', ()) for name in (st.get('name'),) if name])

        # trailers:
        trailers_lang_priority = {lang: 0, 'en': 1}
        trailers = sorted(
            item.get('videos', {}).get('results', []),
            key=lambda t: (not t['official'], trailers_lang_priority.get(t['iso_639_1'], 9))
        )
        for t in trailers:
            if t['type'] == 'Trailer' and t['site'] == 'YouTube':
                vtag.setTrailer(f'plugin://plugin.video.youtube/play/?video_id={t["key"]}')
                break

        # ratings:
        vtag.setRatings({'tmdb': (item.get('vote_average', 0.0), item.get('vote_count', 0))}, 'tmdb')

        # facets for discover (the details only, an item of a list has no them) and the video count
        if 'genres' in item:
            ff.facets = {kind: [{'code': it[code], 'name': it.get(name) or '', **({'logo': logo} if lkey and (logo := it.get(lkey)) else {})}
                                for it in item.get(src) or ()]
                         for kind, (src, code, name, lkey) in FACET_SOURCES.items() if src in item}
            if (keywords := item.get('keywords')) is not None:
                ff.facets['keyword'] = [{'code': it['id'], 'name': it['name']} for it in keywords.get('keywords') or keywords.get('results') or ()]
        if (videos := item.get('videos')) is not None:
            ff.video_count = len(videos.get('results') or ())

        # episode groups (show only)
        if episode_groups := item.get('episode_groups', {}):
            self._parse_episode_groups(episode_groups, ff)
        if 'episode_groups' in item:  # the groups are not cached, their count is (the details menu)
            ff.episode_group_count = len(item['episode_groups'].get('results') or ())

        # rest:
        if episode_type := self.tmdb.parse_episode_type(item):
            vtag.setEpisodeType(episode_type)

        # vtag.setDateAdded() – LIBRARY
        # vtag.setEpisodeGuide() – JSON ?!
        # vtag.setFilenameAndPath ???

        # vtag.setPath ???
        # vtag.setProductionCode() ?
        # vtag.setSet() / vtag.setSetId() / vtag.setSetOverview() ???
        # vtag.setShowLinks()

        # vtag.setTags() - append_to_response=keywords & "keywords"
        # vtag.setTop250() ?
        # vtag.setTrailer()
        # vtag.setTvShowStatus() ?
        # vtag.setUniqueID() / vtag.setUniqueIDs()
        # vtag.setUserRating()

        # vtag.setSortTitle()
        # vtag.setSortSeason()
        # vtag.setSortEpisode()

        # vtag.setLastPlayed() - TRAKT
        # vtag.setPlaycount() – TRAKT
        # vtag.setResumePoint() – TRAKT

        # music videos info: vtag.setAlbum(), vtag.setArtists() vtag.setTrackNumber()

        # -- item --
        # setArt()
        # setAvailableFanart()
        # setContentLookup() – PLAYER
        # setDateTime() ???
        # setInfo() !!!  overlay, setoverview
        # setIsFolder()
        # setLabel()
        # setLabel2()
        # setProperties() / setProperty
        # setSubtitles() ???

        # --- seasons & episodes ---
        if ref.is_show:
            set_if(vtag.setSeriesStatus, 'status')
        if ref.type == 'show':
            # propagate seasons and episodes translations
            def update_episodes(it: JsonData) -> None:
                locales = it.get('_locales', {})
                for sub_it, *loc_items in episodes_iter(it, *locales.values()):
                    for loc, loc_it in zip(locales, loc_items):
                        sub_it.setdefault('_locales', {}).setdefault(loc, {}).update(loc_it)
            locales = item.get('_locales', {})
            for sub_it, *loc_items in seasons_iter(item, *locales.values()):
                for loc, loc_it in zip(locales, loc_items):
                    sub_it.setdefault('_locales', {}).setdefault(loc, {}).update(loc_it)
                    update_episodes(sub_it)
            update_episodes(item)
            # get extra info
            if count := item.get('number_of_episodes'):
                ff.episodes_count = count
            if ep := item.get('last_episode_to_air'):
                ff.last_episode_to_air = self._make_sub_item(ff, ep, {}, {}, main_item=item, details=details)
            if ep := item.get('next_episode_to_air'):
                ff.next_episode_to_air = self._make_sub_item(ff, ep, {}, {}, main_item=item, details=details)
            # Aired episodes from the show details have no translations: such a cached row is merged into
            # a full episode row (never overwrites it) and never satisfies an episode request by itself.
            for aired in (ff.last_episode_to_air, ff.next_episode_to_air):
                if aired is not None and details is not None:
                    aired.details = InfoDetails.INFO_LANG
            # count episodes if there is only show seasons (without 'season/1' etc.)
            if seasons := item.get('seasons'):
                episode_counts = {it['season_number']: it['episode_count'] for it in seasons}
                if (not ff._continuous_episode_number
                        and (ep := ff.last_episode_to_air)
                        and ((cnt := episode_counts.get(ep.ref.season)) is None or not 1 <= (ep.ref.episode or 0) <= cnt)):
                    ff._continuous_episode_number = True
                if (not ff._continuous_episode_number
                        and (ep := ff.next_episode_to_air)
                        and ((cnt := episode_counts.get(ep.ref.season)) is None or not 1 <= (ep.ref.episode or 0) <= cnt)):
                    ff._continuous_episode_number = True
            # parse sub-item (seasons and episodes in parent item)
            self._parse_tmdb_item_children(item, ff, en_translations=en_translations, orig_translations=orig_translations,
                                           details=details)
            if ff.continuous_episode_number:
                enum = 1
                for sz in ff.season_iter():
                    if sz.ref.season:  # the specials have their own numbers
                        sz._first_episode_number = enum
                        enum += sz.episodes_count or sz.children_count  # a full season (with episodes) has no `episodes_count`
            # fix season air date (from the first episode date)
            for sz in ff.season_iter():
                if sz.date is None:
                    if (ep := next(sz.episode_iter(), None)) and ep.date:
                        sz.vtag.setFirstAired(ep.date)
            # guess seasons date if missing (from previous season)
            if lst := ff.last_episode_to_air:
                date = lst.date if lst.ref.season == 1 else FFItem.AIRED_DATE
                for sz in ff.season_iter():
                    if sz.date is None:
                        sz._guessed_date = date
                    else:
                        date = sz.date
                    if sz.ref.season == lst.ref.season:
                        break

        return ff

    def _make_sub_item(self, ff: FFItem, it: JsonData, en_it: JsonData, orig_it: JsonData, *, main_item: JsonData,
                       details: InfoDetails | None = None) -> FFItem:
        ref = ff.ref
        fi = FFItem(evolve(ref, **{itype: num for itype in ('season', 'episode') if (num := it.get(f'{itype}_number')) is not None}))
        vtag = fi.vtag
        # NOTE: now season FFID is replaced to volatile FFID in InfoProvider._set_volatile_ffid().
        if fi.ref.is_season and (denorm := fi.ref.denormalize()):
            fi.ffid = denorm.ffid
        if not fi.ffid:
            fi.ffid = VideoIds.ffid_from_tmdb(it)
        req: MediaRequest | None = main_item.get('_request') if main_item else None
        fi.title = it.get('name', str(fi.season))
        fi.label = fi.title
        vtag.setUniqueIDs({'tmdb': str(it['id'])})
        if has_air := it.get('air_date'):
            air = datetime.fromisoformat(has_air).date()
            vtag.setFirstAired(str(air))
            vtag.setYear(air.year)
        if overview := it.get('overview'):
            fi.vtag.setPlotBase(overview)
        elif overview := en_it.get('overview'):
            fi.vtag.setPlotBase(overview)
        if 'vote_average' in it:
            vtag.setRatings({'tmdb': (it['vote_average'], it.get('vote_count', 0))}, 'tmdb')
        art, ff_art = {}, ff.getArt()
        if poster := it.get('poster_path'):
            art['poster'] = f'{self.tmdb.art_image_url}{poster}'
        if landscape := it.get('still_path'):
            art['landscape'] = f'{self.tmdb.art_landscape_url}{landscape}'
        if fanart := it.get('backdrop_path'):
            fanart = f'{self.tmdb.art_landscape_url}{fanart}'
            art['fanart'] = fanart
            art.setdefault('landscape', fanart)
        runtime = it.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)
        if count := it.get('episode_count'):
            fi._children_count = fi.episodes_count = count
        if episode_type := self.tmdb.parse_episode_type(it, tvshow_status=ff.vtag.getSeriesStatus()):
            vtag.setEpisodeType(episode_type)
        if title := en_it.get('name'):
            vtag.setEnglishTitle(title)
        elif req and req.locale.partition('-')[0] == 'en':
            vtag.setEnglishTitle(fi.title)
        if title := orig_it.get('name'):
            vtag.setOriginalTitle(title)
        elif req and req.locale.partition('-')[0] == main_item.get('original_language', 'en'):
            vtag.setOriginalTitle(fi.title)
        vtag.setTvShowTitle(ff.vtag.getTVShowTitle())
        vtag.setEnglishTvShowTitle(ff.vtag.getEnglishTvShowTitle())
        if img := ff_art.get('poster'):
            art['tvshow.poster'] = img
        if img := ff_art.get('fanart'):
            art['tvshow.fanart'] = img
        if art:
            fi.setArt(art)
        if en_title := en_it.get('name'):
            vtag.setEnglishTitle(en_title)
        fi.source_data = it
        # a sub-item has no own persons and art settings, it is as good as its parent (cache sufficiency)
        fi.crew_limit = ff.crew_limit
        fi.parse_stamp = ff.parse_stamp
        if details is not None:
            fi.details = _node_details(details, fi.ref, primary=False)   # content fingerprint (for cache)
        if ref.is_show:
            fi.show_item = ff
        elif ref.is_season:
            fi.season_item = ff
            fi.show_item = ff.show_item
        return fi

    def _parse_tmdb_item_children(self, item: JsonData, ff: FFItem, *,
                                  en_translations: Sequence[JsonData],
                                  orig_translations: Sequence[JsonData],
                                  details: InfoDetails | None = None) -> None:
        """Parse single season/episode data for tv-show item."""

        ref = ff.ref
        if ref.season is None:
            # season_number > 0 -- omit season "0" (extra materials)
            seasons = item.get('seasons', ())
            if seasons:
                # full season info (with episodes) of seasons with details (InfoDetails.SHOW_SEASONS or requested seasons),
                # shorten seasons info of the others
                locales = item.get('_locales', {})
                variant_seasons = seasons_iter(seasons, locales.get(LOCALE_EN, {}), locales.get(LOCALE_ORIG, {}))
                ff.children_items = [sz for sss in variant_seasons if sss[0]['season_number'] > 0
                                     for sz in (self.parse_tmdb_item(sss[0], parent_ffitem=ff, details=details, _primary=False) if 'episodes' in sss[0]
                                                else self._make_sub_item(ff, *sss, main_item=item, details=details),) if sz]
                # update kodi seasons
                ff.vtag.addSeasons([(sz.season, sz.title) for sz in ff.children_items])
        elif ref.episode is None:
            locales = item.get('_locales', {})
            variant_episodes = episodes_iter(item, locales.get(LOCALE_EN, {}), locales.get(LOCALE_ORIG, {}))
            ff.children_items = [self._make_sub_item(ff, *eee, main_item=item, details=details) for eee in variant_episodes]
            if 'episodes' in item:
                # a full season declares its own episodes: the count of the show data (its stub) may differ (TMDB), the
                # stored stub count would survive the overwrite and the cached season would be incomplete for ever
                ff._children_count = len(ff.children_items)

    def _parse_tmdb_person(self,
                           item: JsonData,
                           ff: FFItem,
                           en_translations: Sequence[JsonData],
                           orig_translations: Sequence[JsonData]) -> None:
        """Parse single person data."""

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item, *en_translations, *orig_translations):
                for key in keys:
                    value = data.get(key)
                    if value:
                        meth(value)
                        return

        vtag = ff.vtag
        set_if(vtag.setPlotOutline, 'biography')
        # year and dates (premiered, first aired)
        date = None
        try:
            birthday = item.get('birthday')
            if birthday:
                date = fromisoformat(birthday)
        except ValueError:
            pass
        if date:
            vtag.setYear(date.year)
            vtag.setPremiered(str(date))

        imgs = item.get('images', {}).get('profiles', [])
        if imgs:
            path = imgs[0]['file_path']
            if path:
                path = f'{self.tmdb.art_image_url}{path}'
                ff.setArt({'thumb': path, 'icon': path})

    def _parse_tmdb_collection(self,
                               item: JsonData,
                               ff: FFItem,
                               en_translations: Sequence[JsonData],
                               orig_translations: Sequence[JsonData]) -> None:
        """Parse single collection data."""

    def parse_item(self, item: JsonData, *, type: Optional[RefType] = None) -> Optional[FFItem]:
        """Parse abstract item (get id, name, poster, etc.)."""

        def set_if(setter: Callable, key: str) -> None:
            val = item.get(key)
            if val:
                setter(val)

        if item is None:
            return None
        ffid = VideoIds.make_ffid(tmdb=item['id'])
        ff = FFItem(ffid=ffid, type=type)
        vtag = ff.vtag
        ff.label = ff.title = item.get('title', item.get('name', ''))
        set_if(vtag.setPlotBase, 'overview')
        art = {}
        if poster := item.get('poster_path'):
            poster = f'{self.tmdb.person_image_url}/{poster}'
            art.update({'thumb': poster, 'poster': poster})
        if fanart := item.get('backdrop_path'):
            fanart = f'{self.tmdb.art_landscape_url}{fanart}'
            art['fanart'] = fanart
            art.setdefault('landscape', fanart)
        if art:
            ff.setArt(art)
        return ff

    def _parse_episode_groups(self, episode_groups_data: JsonData, ff: FFItem) -> None:
        """Parse episode groups data."""
        ff.episode_group.groups = [FFEpisodeGroup(tmdb_id=it['id'], name=it['name'], description=it.get('description', ''),
                                                  episode_count=it.get('episode_count', ()), group_count=it.get('group_count', ()),
                                                  type=FFEpisodeGroupType(it.get('type', 0)))
                                   for it in episode_groups_data.get('results', ())]

    def parse_items(self, items: SequenceProto[JsonData], *, type: Optional[RefType] = None) -> list[Optional[FFItem]]:
        return [self.parse_item(it, type=type) for it in items]

    def item_to_row(self, item: FFItem, *, lang: Optional[str] = None, now: Optional[float] = None) -> MediaInfoRow:
        """Convert a single FFItem node to a cache media-info row (policy applied).

        ffinfo is the "smart" side: it sets the freshness deadline (:func:`compute_expires_at` on the
        live node), the row language, the content fingerprint (``details``) and the denormalized ids.
        """
        if now is None:
            now = cur_time()
        if lang is None:
            lang = self.tmdb.locale
        ref: MediaRef = item.ref
        ids = item.vtag.getUniqueIDs()
        return MediaInfoRow(
            xref=ref,                                   # converter: MediaRef -> normalized XMediaRef
            ffid=item.ffid or 0,
            lang=lang,
            details=int(item.details.value),
            children_count=item.children_count,
            premiere=item.date,                         # converter: date -> unix timestamp
            expires_at=compute_expires_at(item, now),   # already a unix timestamp (converter passthrough)
            tmdb=int(ids.get('tmdb') or 0),
            imdb=ids.get('imdb') or '',
            json_string=item.__to_json__(),             # converter: dict -> JSON string
            title=item.title,
        )

    def item_to_rows(self, trees: Iterable[FFItem | None], *, lang: Optional[str] = None, now: Optional[float] = None) -> list[MediaInfoRow]:
        """Build one cache row per node of the live graphs, last / next aired episodes too (``store`` skips NONE rows).

        A node in several trees (a season of a TMDB answer is its own key and a part of the show) is one row,
        of the same node as `_tree_nodes()` gives the caller.
        """
        if now is None:
            now = cur_time()
        return [self.item_to_row(node, lang=lang, now=now) for node in self._tree_nodes(trees).values()]

    def parse_tmdb_skel_item(self,
                             item: TmdbItemJson,
                             *,
                             locale: Optional[str] = None,
                             options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS | SkelOptions.SHOW_EPISODE_DATE_APPROXIMATE,
                             ) -> FFItem:
        """Create items with skeleton children items (eg. episodes based on episodes count only)."""

        def dget(dct: dict, key: str, default: Any = None) -> Any:
            keys = key.split('/')
            for key in keys[:-1]:
                dct = dct.get(key, {})
            return dct.get(keys[-1], default)

        def set_if(meth: Callable, *keys: str) -> None:
            for data in (item,):
                for key in keys:
                    value = dget(data, key)
                    if value:
                        meth(value)
                        return

        ref = MediaRef(*item['_ref'])
        if item.get('success') is False:
            msg = item.get('status_message', '')
            raise ValueError(f'TMDB: get {ref} failed: {msg}')
        ff = FFItem(ref)
        if not ff.ffid:
            ff.ffid = VideoIds.ffid_from_tmdb(item)
        if ref.real_type in ('movie', 'episode'):
            ff.mode = ff.Mode.Playable
        else:
            ff.mode = ff.Mode.Folder
        ff.source_data = item
        vtag = ff.getVideoInfoTag()
        titletag: str = 'title' if ref.type == 'movie' else 'name'

        if 'id' not in item:
            fflog(f'ERROR: XXXXXXXXXXXXXXXXX\n\n{json.dumps(item, indent=2, cls=JsonEncoder)}')
        elif ff.ffid in VideoIds.KODI:
            vtag.setDbId(ff.ffid)  # Kodi DBID
        set_if(vtag.setIMDBNumber, 'imdb_id', 'external_ids/imdb_id')
        vtag.setUniqueIDs({name: str(val)
                           for name, key in (('tmdb', 'id'), ('tmdb_id', 'id'), ('imdb', 'imdb_id'), ('imdb', 'external_ids/imdb_id'))
                           for val in (dget(item, key),) if val},
                          'imdb')  # default id type
        vtag.setMediaType(ref.real_type)

        # duration
        runtime = item.get('runtime')
        if runtime is not None:
            vtag.setDuration(runtime * 60)

        # year and dates (premiered, first aired)
        date = None
        if ref.type == 'movie':
            date_keys = ('release_date', )
        else:
            date_keys = ('first_air_date', 'air_date')
        for date_key in date_keys:
            date_str = item.get(date_key)
            if date_str:
                try:
                    date = fromisoformat(date_str)
                    break
                except ValueError:
                    pass
        if date:
            vtag.setYear(date.year)
        if date:
            if ref.type == 'show':
                vtag.setFirstAired(date)
            else:
                vtag.setPremiered(date)

        # titles
        set_if(vtag.setTitle, 'title', 'name')
        set_if(vtag.setOriginalTitle, f'original_{titletag}')
        orig_lang = item.get('original_language', 'en')
        en_title = vtag.getOriginalTitle() if orig_lang == 'en' else vtag.getTitle()  # api lang is EN
        vtag.setEnglishTitle(en_title)
        if ref.main_type == 'show':
            vtag.setTvShowTitle(ff.title)
            vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
        if locale and locale not in self.EN_LOCALES:
            lang, _, region = locale.partition('-')
            if orig_lang == lang or locale in {f'{orig_lang}-{c}' for c in item.get('origin_country', ())}:
                # original title matches locale
                if title := item.get('original_title') or item.get('original_name'):
                    vtag.setTitle(title)
                    if ref.main_type == 'show':
                        vtag.setTvShowTitle(ff.title)
            elif translations := item.get('translations', {}).get('translations'):
                # search title in translations
                if title := (tr := next(iter(chain((it for it in translations if lang == it['iso_639_1'] and region == it['iso_3166_1']),
                                                   (it for it in translations if lang == it['iso_639_1']))), {}).get('data', {})).get('title') or tr.get('name'):
                    vtag.setTitle(title)
                    if ref.main_type == 'show':
                        vtag.setTvShowTitle(ff.title)
        ff.label = ff.title

        # ratings
        vtag.setRatings({'tmdb': (item.get('vote_average', 0.0), item.get('vote_count', 0))}, 'tmdb')

        # --- seasons & episodes ---
        return_ffitem: FFItem = ff
        if ref.type == 'show':
            if seasons := item.get('seasons'):
                last_ref: Optional[MediaRef]
                # episode-to-episode air date delta (air date step), used with SkelOptions.SHOW_EPISODE_DATE_APPROXIMATE
                ep_air_delta = timedelta()
                next_date: Optional[dt_date] = None
                if next_to_air := item.get('next_episode_to_air', {}):
                    next_ref = ref.with_season(next_to_air['season_number']).with_episode(next_to_air['episode_number'])
                    if date := next_to_air.get('air_date'):
                        next_date = dt_date.fromisoformat(date)
                else:
                    next_ref = None
                if last := item.get('last_episode_to_air', {}):
                    last_ref = ref.with_season(last['season_number']).with_episode(last['episode_number'])
                    last_aired = dt_date.fromisoformat(last['air_date'])
                    # guess air date delta from number of aired episodes from the last season
                    if last_ref.episode and last_ref.episode > 1:
                        if last_season_aired := next(iter(sz.get('air_date') for sz in seasons if sz['season_number'] == last_ref.season), None):
                            ep_air_delta = (last_aired - dt_date.fromisoformat(last_season_aired)) / last_ref.episode
                    # guess air date delta from from last and next air(ed) episodes
                    elif next_date:
                        ep_air_delta = next_date - last_aired
                else:
                    last_ref = None
                    last_aired = None
                ff.children_items = []
                for sz in seasons:
                    if (snum := sz['season_number']) > 0:  # skip special "Season 0"
                        if ref.season is not None and ref.season != snum:
                            continue
                        zref = ref.with_season(snum)
                        fz = FFItem(zref, ffid=VideoIds.ffid_from_tmdb(sz))
                        if ref.season is not None:
                            return_ffitem = fz
                        fz.show_item = ff
                        ff.children_items.append(fz)
                        fz.vtag.setTvShowTitle(vtag.getTitle())
                        fz.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                        sz_aired: Optional[dt_date] = None
                        if aired := sz.get('air_date'):
                            sz_aired = dt_date.fromisoformat(aired)
                            fz.vtag.setFirstAired(sz_aired)
                            fz.vtag.setYear(sz_aired.year)
                        if title := sz.get('name'):
                            fz.title = title
                        # season details contain episode list
                        if (zz := item.get(f'season/{snum}', {})) and 'episodes' in zz:
                            fz.children_items = []
                            for ep in zz['episodes']:
                                fe = FFItem(zref.with_episode(ep['episode_number']))
                                fe.show_item = ff
                                fe.season_item = fz
                                fz.children_items.append(fe)
                                fe.vtag.setTvShowTitle(vtag.getTitle())
                                fe.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                                if aired := ep.get('air_date'):
                                    ep_aired = dt_date.fromisoformat(aired)
                                    fe.vtag.setFirstAired(ep_aired)
                                    fe.vtag.setYear(ep_aired.year)
                                if name := ep.get('name'):
                                    fe.vtag.setTitle(name)
                                    fe.vtag.setEnglishTitle(name)
                        # no details, need to approximate episode air dates
                        elif count := sz.get('episode_count'):
                            fz.children_items = []
                            for enum in range(1, count + 1):
                                fe = FFItem(zref.with_episode(enum))
                                fe.show_item = ff
                                fe.season_item = fz
                                fz.children_items.append(fe)
                                fe.vtag.setTvShowTitle(vtag.getTitle())
                                fe.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                                # exact last aired match
                                if last_ref == fe.ref and last_aired:
                                    fe.vtag.setFirstAired(last_aired)
                                    fe.vtag.setYear(last_aired.year)
                                    # tune date approximation
                                    if sz_aired:
                                        ep_date = sz_aired + (enum - 1) * ep_air_delta
                                        if last_aired > ep_date:
                                            sz_aired += last_aired - ep_date
                                # exact last aired match
                                elif next_ref == fe.ref and next_date:
                                    fe.vtag.setFirstAired(next_date)
                                    fe.vtag.setYear(next_date.year)
                                    # tune date approximation
                                    if sz_aired:
                                        ep_date = sz_aired + (enum - 1) * ep_air_delta
                                        if next_date > ep_date:
                                            sz_aired += next_date - ep_date
                                # air date linear approximate
                                elif options & SkelOptions.SHOW_EPISODE_DATE_APPROXIMATE:
                                    # old episodes
                                    if last_aired and sz_aired:
                                        ep_date = min(last_aired, sz_aired + (enum - 1) * ep_air_delta)
                                        fe.vtag.setFirstAired(ep_date)
                                        fe.vtag.setYear(ep_date.year)
                                elif options & SkelOptions.SHOW_EPISODE_DATE_FIRST:
                                    if sz_aired:
                                        fe.vtag.setFirstAired(sz_aired)
                                        fe.vtag.setYear(sz_aired.year)
                                elif options & SkelOptions.SHOW_EPISODE_DATE_LAST:
                                    if last_ref and sz_aired:
                                        ep_date = None
                                        if snum < last_ref.season:
                                            if aired := next(iter(sz.get('air_date') for sz in seasons if sz['season_number'] == snum + 1), None):
                                                ep_date = max(sz_aired, dt_date.fromisoformat(aired) - timedelta(days=1))
                                        elif last_aired:
                                            ep_date = last_aired
                                        if ep_date:
                                            fe.vtag.setFirstAired(ep_date)
                                            fe.vtag.setYear(ep_date.year)
                                # if last_aired:
                                #     fe.vtag.setFirstAired(last_aired) # all episodes up to last aired are marked with the same date
                                # newer then last aired – we don't know nothing about them (except explicit "next_episode_to_air")
                                if last_ref == fe.ref:
                                    last_aired = None
                                    sz_aired = None

            if ref.is_episode:
                for ep in item.get(f'season/{ref.season}', {}).get('episodes', ()):
                    if (enum := ep['episode_number']) == ref.episode:
                        eref = ref
                        fe = FFItem(eref, ffid=VideoIds.ffid_from_tmdb(ep))
                        fe.show_item = ff
                        fe.season_item = return_ffitem
                        return_ffitem = fe
                        fe.vtag.setTvShowTitle(vtag.getTitle())
                        fe.vtag.setEnglishTvShowTitle(vtag.getEnglishTitle())
                        if aired := ep.get('air_date'):
                            ep_aired = dt_date.fromisoformat(aired)
                            fe.vtag.setFirstAired(ep_aired)
                            fe.vtag.setYear(ep_aired.year)
                        if title := ep.get('name'):
                            fe.title = title
                        break

        return return_ffitem

    def row_to_item(self, row: MediaInfoRow) -> FFItem:
        """Convert cache media info row to FFItem (single node; children are separate rows)."""
        item = FFItem(row.ref)
        item.__set_json__(row.data)   # `row.data` lazily decodes the stored JSON
        # A node stored together with its children has no declared count in JSON, but it is needed
        # to detect missing children and to create degraded episodes if the children are not used.
        if item._children_count is None and row.children_count:
            item._children_count = row.children_count
        return item

    def _rows_to_items(self, rows: Mapping[MediaRef, MediaInfoRow]) -> FFItemDict:
        """
        Convert cache rows to items. A broken row (e.g. its JSON) is skipped like a missing one, then it is refetched.

        The broken row is removed: the refetched node is stored by a merge into the stored row when it has fewer
        content aspects, the broken key would survive (and the node would be fetched on every listing).
        """
        items: FFItemDict = {}
        broken: list[MediaRef] = []
        for ref, row in rows.items():
            try:
                items[ref] = self.row_to_item(row)
            except Exception:
                fflog_exc()
                broken.append(ref)
        if broken:
            media.invalidate(broken)
        return items

    @staticmethod
    def _link_cached_tree(items: Mapping[MediaRef, FFItem]) -> None:
        """Reattach cached descendant nodes as `children_items` of their parents.

        Cache stores one row per ref (implicit graph): `fetch(descendants=True)` returns the show row
        plus its season/episode rows flat. Here we wire seasons under their show and episodes under
        their season (back-refs + sorted `children_items`) and resolve the show's last/next episode
        objects from the same set.
        """
        for ref, it in items.items():
            parent_ref = ref.season_ref if ref.is_episode else (ref.show_ref if ref.is_season else None)
            parent = items.get(parent_ref) if parent_ref is not None else None
            if parent is None:
                continue
            if ref.is_season and not ref.season:
                # specials are never listed among the show seasons (see parse_tmdb_item)
                it.show_item = parent
                continue
            if ref.is_episode and it.details and not it.details & ~InfoDetails.INFO_LANG:
                # the last / next aired episode object of the show (a stub of the request language only) is not
                # an episode of the season, it would count in its completeness (linked as the show's last / next below)
                it.season_item = parent
                it.show_item = items.get(ref.show_ref) or parent.show_item
                continue
            if parent.children_items is None:
                parent.children_items = []
            parent.children_items.append(it)
            if ref.is_episode:
                it.season_item = parent
                it.show_item = items.get(ref.show_ref) or parent.show_item
            else:  # season
                it.show_item = parent
        for it in items.values():
            if it.children_items:
                it.children_items.sort(key=lambda c: (c.ref.season or 0, c.ref.episode or 0))
            if it.ref.is_show:
                if it.last_episode_ref is not None and (ep := items.get(it.last_episode_ref)) is not None:
                    it.last_episode_to_air = ep
                if it.next_episode_ref is not None and (ep := items.get(it.next_episode_ref)) is not None:
                    it.next_episode_to_air = ep

    @staticmethod
    def _incomplete(item: FFItem) -> bool:
        """Return True if a (cached) container has fewer children than declared (cache completeness)."""
        return bool(item.children_count) and not item.children_complete

    def _parse_tmdb_answer(self,
                           data: Mapping[MediaRef, TmdbItemJson],
                           *,
                           crew_limit: int | None,
                           details: InfoDetails,
                           ref_details: Mapping[MediaRef, InfoDetails],
                           ) -> list[FFItem | None]:
        """Parse a `get_media_dict_by_ref()` answer, an item per key (in order); a season of its show tree is parsed once.

        A show answer brings its seasons with episodes (`season/N`) in the show season list and as season keys too: the same
        data, the show entry is updated by the season one (`get_media_by_ref()`), the episode list is shared. Such a season
        key takes the season node of the show tree with the fingerprint of the key request. A season of its own data
        (own request, specials not in the show tree) is parsed.
        """
        def parse(ref: MediaRef, item: TmdbItemJson) -> FFItem | None:
            return self.parse_tmdb_item(item, crew_limit=crew_limit, details=ref_details.get(ref, details))

        def season(ref: MediaRef, item: TmdbItemJson) -> FFItem | None:
            sz = tree.get(ref)
            if sz is not None and ref.is_season and (eps := item.get('episodes')) is not None and (sz.source_data or {}).get('episodes') is eps:
                sz.details |= _node_details(ref_details.get(ref, details), ref, primary=True)
                return sz
            return parse(ref, item)

        shows = {ref: parse(ref, item) for ref, item in data.items() if ref.season is None}
        tree = self._tree_nodes(shows.values())
        return [shows[ref] if ref in shows else season(ref, item) for ref, item in data.items()]

    @staticmethod
    def _tree_nodes(trees: Iterable[FFItem | None]) -> FFItemDict:
        """Return all nodes of (fresh) trees by ref.

        A top-level node wins over the same ref found inside another tree (TMDB returns a requested season
        parsed on its own, with episodes, next to its show, where the season has no episodes). A tree node
        of any tree wins over the last / next aired-episode object (of the show without episodes).
        """
        roots = [tree for tree in trees if tree is not None]
        nodes: FFItemDict = {root.ref: root for root in roots}
        graphs = [tuple(root._iter_tree()) for root in roots]
        aired = {id(ep) for graph in graphs for node in graph for ep in (node._last_episode_to_air, node._next_episode_to_air) if ep is not None}
        for graph in graphs:
            for node in graph:
                if id(node) not in aired:
                    nodes.setdefault(node.ref, node)
        for graph in graphs:
            for node in graph:
                nodes.setdefault(node.ref, node)
        return nodes

    def _update_items_progress(self,
                               items: Mapping[MediaRef, FFItem],
                               *,
                               progress: Progress,
                               ) -> None:
        # Append progress info. Rows of nodes in the trees are needed (update_item_progress walks them),
        # a show or season ref gives all its episodes (they make its progress).
        def tree_refs() -> Iterator[MediaRef]:
            stack = list(items.values())
            while stack:
                it = stack.pop()
                yield it.ref
                if it.children_items and it.ref.type != 'show':
                    stack.extend(it.children_items)

        if progress is Progress.BASIC or progress is Progress.FULL:
            refs = set(tree_refs())
            # the rows of a show / season ref are all its episodes: their refs (and the seasons of a show) are not asked again
            shows = {ref.ffid for ref in refs if ref.is_show}
            seasons = {(ref.ffid, ref.season) for ref in refs if ref.is_season}
            refs = {ref for ref in refs if ref.season is None or not (ref.ffid in shows or (ref.is_episode and (ref.ffid, ref.season) in seasons))}
            playback_info = self.playback_info(refs)
            episodes = _episodes_by_show(playback_info)
            # the progress of a show / season follows its aired episodes: the aired maps of the played ones only (no plays - no progress)
            played = {ffid for ffid, rows in episodes.items() if any(pb.play_count or pb.progress for pb in rows)}
            aired = self.aired_map(it.ref for it in items.values() if it.ref.type == 'show' and it.ref.episode is None and it.ref.ffid in played)
            for it in items.values():
                self.update_item_progress(it, playback_info=playback_info, episodes=episodes, aired=aired)

    def _set_volatile_ffid(self, items: FFItemDict) -> None:
        """Change seasons FFID for volatile one."""
        def list_all(items: Iterable[FFItem]) -> Iterator[tuple[MediaRef, FFItem]]:
            for ffitem in items:
                yield ffitem.ref, ffitem
                if children := ffitem.children_items:
                    yield from list_all(children)

        all_items = dict(list_all(items.values()))

        if const.core.volatile_ffid and const.core.volatile_seasons:
            if seasons_refs := [ref for ref in all_items if ref.is_season]:
                for ref, ffid in service_client.create_ffid_dict(seasons_refs).items():
                    all_items[ref].ffid = ffid

    def find_item(self,
                  ref: MediaRef | FFItem | MediaRequest,
                  *,
                  progress: Progress = Progress.BASIC,
                  crew_limit: Optional[int] = None,
                  details: InfoDetails | str | None = None,
                  ) -> Optional[FFItem]:
        """Get single item info, ref can be denormalized."""
        if details is None:
            details = InfoDetails.new(const.media.info_details)
        elif isinstance(details, str):
            details = InfoDetails.new(details)
        # Take refs (from FFItem, ref.ref is correct too).
        req = ref
        ref = ref.ref
        # Resolve volatile FFID.
        if ref.is_volatile and const.core.volatile_ffid and (norm := service_client.get_ffid_ref(ref.ffid)):
            ref = norm
        # Resolve external ID (IMDb, MDBList, Trakt, TVDB) the way of lists: the ID map first (`resolve_ids()`).
        if not ref.tmdb_id and (ref := self.lookup_refs([ref])[0]) is None:
            return None
        # Normalize ref (ex. episode ID instead of show/season/episode).
        if not ref.is_normalized:
            rows = media.find_denormalized([ref])
            norm = next((row.ref for row in rows.values() if row.denormalized_ref == ref), None) or ref.normalize()
            if norm is None:
                if self.trakt is None:
                    return None
                try:
                    vid = ref.video_ids
                    mid = self.trakt.id_lookup(id=vid.value or 0, service=vid.service() or 'tmdb', type=ref.type)
                except ValueError:
                    fflog_exc()
                    return None
                if mid.ref is None:
                    return None
                norm = mid.ref
            ref = norm
        # The same cache and TMDB path as for lists (cache sufficiency, the whole show tree, show and season join).
        request = req if isinstance(req, MediaRequest) and req.ref == ref else ref
        _, _, items = self._get_items([request], crew_limit=crew_limit, progress=progress, details=details,
                                      user_ratings=False)
        if (ffitem := items.get(ref)) is None:
            fflog(f'No {ref} found in TMDB')
        return ffitem

    def _broken_item(self, ff: FFItem) -> FFItem:
        """Mark an input item with no info in TMDB as broken (shown as its list gave it, `const.folder.style.broken`)."""
        if ff.type not in self._supported_details_types:
            return ff
        ref = ff.ref
        fflog(f'BROKEN ITEM: {ref} {ff.vtag.getUniqueIDs()}')
        ff.broken = True
        if not ff.title:  # a bare ref (e.g. an own list)
            ff.title = f'{ref.type} {ref.tmdb_id or ref.ffid}'
        if const.folder.style.broken:
            ids = '\n'.join(f'{k}: {v}' for k, v in {'ffid': f'{ref:i}', **ff.vtag.getUniqueIDs()}.items())
            note: str = L(32981, 'No data in TMDB')
            ff.vtag.setPlotBase('\n\n'.join(x for x in (ff.vtag.getPlot(), f'[B]{note}[/B]\n{ids}') if x))
        return ff

    @overload
    def get_items(self,
                  refs: Pagina[MediaRef] | Pagina[FFItem] | Pagina[FFRef] | ItemList[MediaRef] | ItemList[FFItem] | ItemList[FFRef],
                  *,
                  crew_limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  details: InfoDetails | str | None = None,
                  keep_missing: Literal[False] = False,
                  duplicate: bool = True,
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  ) -> ItemList[FFItem]: ...

    @overload
    def get_items(self,
                  refs: Pagina[MediaRef] | Pagina[FFItem] | Pagina[FFRef] | ItemList[MediaRef] | ItemList[FFItem] | ItemList[FFRef],
                  *,
                  crew_limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  details: InfoDetails | str | None = None,
                  keep_missing: Literal[True],
                  duplicate: bool = True,
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  ) -> ItemList[FFItem | None]: ...

    @overload
    def get_items(self,
                  refs: Iterable[MediaRef | FFItem | MediaRequest],
                  *,
                  crew_limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  details: InfoDetails | str | None = None,
                  keep_missing: Literal[False] = False,
                  duplicate: bool = True,
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  ) -> list[FFItem]: ...

    @overload
    def get_items(self,
                  refs: Iterable[MediaRef | FFItem | MediaRequest],
                  *,
                  crew_limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  details: InfoDetails | str | None = None,
                  keep_missing: Literal[True],
                  duplicate: bool = True,
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  ) -> list[FFItem | None]: ...

    @overload  # generic, used with GetItemKwargs (**kwargs)
    def get_items(self,
                  refs: Iterable[MediaRef | FFItem | MediaRequest],
                  *,
                  crew_limit: Optional[int] = None,
                  progress: Progress = Progress.BASIC,
                  details: InfoDetails | str | None = None,
                  keep_missing: bool,
                  duplicate: bool,
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  ) -> list[FFItem | None] | ItemList[FFItem | None]: ...

    def get_items(self,
                  refs: Iterable[MediaRef | FFItem | MediaRequest] | Pagina[MediaRef | FFItem],
                  *,
                  #: Limit the crew (actors, cast etc.).
                  crew_limit: Optional[int] = None,
                  #: Obtain progress mode.
                  progress: Progress = Progress.BASIC,
                  #: Scan episodes too (mostly not necessary).
                  details: InfoDetails | str | None = None,
                  #: If true, return None in ref is not obtained (useful for zip()) else skip missing item.
                  keep_missing: bool = False,
                  #: Keep refs duplicates in return list.
                  duplicate: bool = True,
                  #: Convert to episode groups. If ID (str) is used extra data will be collected.
                  episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                  #: Get user ratings from rating services (if enabled in settings).
                  user_ratings: bool = True,
                  ) -> Any:
        """Get list of item info in order, refs must be normalized."""
        # arguments: GetItemKwargs

        # Find one item in received info.
        def get_ff(ref: MediaRef, source: MediaRef | FFItem | None) -> FFItem | None:
            if ff := used.get(ref):
                if ff and duplicate:
                    return self._set_dynamic_stuff(ff.clone(), source) if isinstance(source, FFItem) else ff.clone()
                return ff
            ff = items.get(ref)
            if not ff and isinstance(source, FFItem):
                ff = self._broken_item(source)  # no info in TMDB: the input item as its list gave it
            if duplicate and ff and isinstance(source, FFItem):
                self._set_dynamic_stuff(ff, source)
            used[ref] = ff
            return ff

        if not hasattr(refs, '__getitem__'):
            refs = tuple(refs)
        if TYPE_CHECKING:
            refs = tuple(refs)  # only for type-checking
        # Get info.
        requests, req_refs, items = self._get_items(refs, crew_limit=crew_limit, progress=progress, details=details, episode_group=episode_group,
                                                    user_ratings=user_ratings)
        # Get item from MediaRequest
        refs_argument = refs
        # refs = [ref.item if isinstance(ref, MediaRequest) else ref for ref in refs]
        # Refs "used" to clone ref (and item) duplicated.
        used: dict[MediaRef, FFItem | None] = {}
        # Return list of FFItem in `refs` order.
        if keep_missing:
            it_gen = [None if req is None or ref is None else get_ff(ref, req.item) for req, ref in zip(requests, req_refs)]
        else:
            it_gen = [item for req, ref in zip(requests, req_refs) if req is not None and ref is not None and (item := get_ff(ref, req.item))]
        if isinstance(refs_argument, (Pagina, ItemList)):
            return ItemList.from_list(it_gen, refs_argument)
        return list(it_gen)

    def get_item_dict(self,
                      refs: Iterable[MediaRef | FFItem | MediaRequest],
                      *,
                      crew_limit: Optional[int] = None,
                      progress: Progress = Progress.BASIC,
                      details: InfoDetails | str | None = None,
                      #: Convert to episode groups. If ID (str) is used extra data will be collected.
                      episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                      ) -> FFItemDict:
        """Get dict of item info, refs must be normalized."""
        # Get info.
        if not isinstance(refs, Sequence):
            refs = tuple(refs)
        _, _, items = self._get_items(refs, crew_limit=crew_limit, progress=progress, details=details, episode_group=episode_group)
        # Restore children (seasons and episodes).
        stack = list(items.values())
        while stack:
            it = stack.pop()
            items.setdefault(it.ref, it)
            if it.children_items:
                stack.extend(it.children_items)
        # Return all known items.
        return items

    def get_item(self,
                 ref: Union[MediaRef, FFItem],
                 *,
                 crew_limit: Optional[int] = None,
                 progress: Progress = Progress.BASIC,
                 details: InfoDetails | str | None = None,
                 #: Convert to episode groups. If ID (str) is used extra data will be collected.
                 episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                 ) -> Optional[FFItem]:
        """Get single item info in order, refs must be normalized."""
        lst = self.get_items([ref], crew_limit=crew_limit, progress=progress, details=details, episode_group=episode_group)
        return lst[0] if lst else None

    @logtime
    def _get_items(self,
                   refs: Sequence[MediaRef | FFItem | MediaRequest | None],
                   *,
                   #: Limit the crew (actors, cast etc.).
                   crew_limit: Optional[int] = None,
                   #: Obtain progress mode.
                   progress: Progress = Progress.BASIC,
                   #: Scan episodes too (mostly not necessary).
                   details: InfoDetails | str | None = None,
                   #: Media info locale (for titles etc.).
                   locale: str | None = None,
                   #: Convert to episode groups. If ID (str) is used extra data will be collected.
                   episode_group: str | FFEpisodeGroup | dict[MediaRef, MediaRef] | None = None,
                   #: Get user ratings from rating services (if enabled in settings).
                   user_ratings: bool = True,
                   ) -> tuple[Sequence[MediaRequest | None], Sequence[MediaRef | None], FFItemDict]:
        """Helper. Get list of item info in order, refs must be normalized."""
        if details is None:
            details = InfoDetails.new(const.media.info_details)
        elif isinstance(details, str):
            details = InfoDetails.new(details)
        if not locale:
            locale = self.tmdb.locale
        # Need to get episode group data from TMDB
        need_episode_group = False
        if episode_group:
            details |= InfoDetails.EPISODE_GROUPS
            if (isinstance(episode_group, str)
                    or (isinstance(episode_group, FFEpisodeGroup) and episode_group.items is None)):
                # if no details, need to get new details
                if isinstance(episode_group, FFEpisodeGroup):
                    episode_group = episode_group.tmdb_id

        # Input requests (or ffitems or refs).
        requests = [None if req is None else MediaRequest.new(req, default_details=details, default_locale=locale) for req in refs]
        req_refs = [None if req is None else req.ref for req in requests]
        del refs
        # Try to recover volatile ffid if allowed.
        if const.core.volatile_ffid:
            if volatile := [req.ref.ffid for req in requests if req and req.ref.is_volatile]:
                if norm := service_client.get_ffid_ref_dict(volatile):
                    req_refs = [ref if x is not None and x.is_volatile and (ref := norm.get(x.ffid)) else x for x in req_refs]
                    assert len(req_refs) == len(requests)
        # Resolve external IDs (IMDB, Trakt, tvdb).
        req_refs = self.lookup_refs(req_refs)
        assert len(req_refs) == len(requests)
        # Expand season/episode ref to all possible refs (parent season and show).
        all_refs: set[MediaRef] = {ref for ref in req_refs if ref}  # DO NOT expand season/episode ref, TMDB module already do it
        # Details of each requested ref: of its requests (all of them if it is requested more times); the function
        # `details` is the default of plain refs (MediaRequest.new), so a request with own details is judged by them.
        ref_details: dict[MediaRef, InfoDetails] = {}
        for req, ref in zip(requests, req_refs):
            if req is not None and ref is not None:
                ref_details[ref] = ref_details.get(ref, InfoDetails.NONE) | req.details
        # Seasons requested with their show (`MediaRequest.seasons`, e.g. for an episode group): needed with their episodes.
        wanted_seasons: set[MediaRef] = {MediaRef(ref.type, ref.ffid, season) for req, ref in zip(requests, req_refs)
                                         if req is not None and ref is not None and ref.is_show for season in (req.seasons or ())}

        def full_seasons_of(ref: MediaRef) -> bool:
            """True if all seasons of the show of `ref` are required with their episodes (SHOW_SEASONS of its request)."""
            return bool(ref_details.get(ref, ref_details.get(ref.show_ref, details)) & InfoDetails.SHOW_SEASONS)

        def full_season_of(ref: MediaRef) -> bool:
            """True if the season `ref` / the season of the episode `ref` is required with all its episodes (SEASON_EPISODES of its request)."""
            return bool(ref_details.get(ref, details) & InfoDetails.SEASON_EPISODES)

        # Seasons required with all their episodes: the requested ones (`MediaRequest.seasons` too) and the seasons of the
        # requested episodes with SEASON_EPISODES (else the season node alone / the episode row alone).
        full_seasons: set[MediaRef] = wanted_seasons | {
            sz_ref for ref in all_refs if (ref.is_season or ref.is_episode) and full_season_of(ref) and (sz_ref := ref.season_ref) is not None}
        # Get rows from cache at once: episodes of the full seasons only, all of them if all seasons are required.
        all_episodes = any(d & InfoDetails.SHOW_SEASONS for d in ref_details.values())
        rows = media.fetch(all_refs | wanted_seasons, lang=locale, descendants=True, episodes_of=None if all_episodes else full_seasons)
        # Rebuild items from cache: descendants come as separate rows -> reassemble the tree, then
        # keep only the requested refs at the top level (children stay attached via children_items).
        cached = self._rows_to_items(rows)
        # last / next aired episodes of cached shows are separate rows, out of the loaded episodes (see `all_episodes`)
        if aired := {ref for it in cached.values() if it.ref.is_show
                     for ref in (it.last_episode_ref, it.next_episode_ref) if ref is not None and ref not in cached}:
            cached.update(self._rows_to_items(media.fetch(aired, lang=locale)))
        self._link_cached_tree(cached)
        items = {ref: it for ref, it in cached.items() if ref in all_refs}
        for it in cached.values():
            self._trim_crew(it, self._effective_crew_limit(crew_limit))
        # Episodes cached below a season which is not requested itself: a fresh show has episodes only with SHOW_SEASONS
        # and a partially cached season would hide the rest of its episodes (no degraded episodes are created then).
        for ref, it in cached.items():
            if ref.is_season and ref not in all_refs and ref not in wanted_seasons and it.children_items is not None:
                if self._incomplete(it) or (ref.show_ref in all_refs and not full_seasons_of(ref.show_ref)):
                    it.children_items = None
        # Find missing refs and try get it from TMDB.
        allowed = get_typing_args(DetailsAllowed)
        missing = set(all_refs) - cached.keys() - {ref for ref in all_refs if ref is None or ref.type not in allowed}
        # Sufficiency axis: a cached node fetched with fewer content aspects than the request needs
        # (its fingerprint is not a superset of the required ITEM_MASK bits) is insufficient -> refetch.
        # NOTE: an episode is never a primary node (it comes from its season), even if requested directly.
        missing |= {ref for ref, it in items.items()
                    if (it.details & (req_mask := _node_details(ref_details.get(ref, details), ref, primary=not ref.is_episode))) != req_mask}
        # Children sufficiency axis: the seasons of a cached show carry the season aspects of its request (e.g. SEASON_EN of
        # the seasons view: a show cached by a list has seasons in the request language only).
        missing |= {ref for ref, it in items.items() if ref.is_show and any(
            (sz.details & (mask := _node_details(ref_details.get(ref, details), sz.ref, primary=False))) != mask for sz in it.season_iter())}
        # Container-completeness axis: a cached container whose children were NOT all cached (e.g. a
        # season requested for its episodes, which the show-level store did not persist) is treated as
        # missing so TMDB fills the tree. Only checked for requested refs -> children in a parent view
        # (e.g. seasons under a show) do NOT trigger a fetch of their own children.
        missing |= {ref for ref, it in items.items() if self._incomplete(it) and (not ref.is_season or full_season_of(ref))}
        # All seasons axis: a cached show requested with SHOW_SEASONS needs episodes of every season.
        missing |= {ref for ref, it in items.items() if ref.is_show and full_seasons_of(ref) and any(map(self._incomplete, it.season_iter()))}
        # Requested seasons axis: a cached show requested with some seasons (`MediaRequest.seasons`) needs their episodes.
        missing |= {sz_ref.show_ref for sz_ref in wanted_seasons
                    if sz_ref.show_ref in items and ((sz := cached.get(sz_ref)) is None or self._incomplete(sz))}
        # Parent axis: a cached season / episode needs its show and an episode its season, with all its episodes if
        # SEASON_EPISODES (a fresh one always has them), with all episodes of every season if they are required.
        missing |= {ref for ref, it in items.items()
                    if ref.season is not None and (it.show_item is None
                                                   or (ref.is_episode and (it.season_item is None
                                                                           or (full_season_of(ref) and self._incomplete(it.season_item))))
                                                   or (full_seasons_of(ref) and any(map(self._incomplete, it.show_item.season_iter()))))}
        # Settings axis: a cached node parsed with other user settings (art quality / order) is outdated.
        parse_stamp = self._parse_stamp()
        missing |= {ref for ref, it in items.items() if it.parse_stamp != parse_stamp}
        # Cast / crew axis: a cached node parsed with a lower limit has not enough persons -> refetch.
        want_crew = self._effective_crew_limit(crew_limit)
        missing |= {ref for ref, it in items.items() if not self._crew_sufficient(it.crew_limit, want_crew)}
        # Not in TMDB axis: a ref TMDB answered "not found" recently has a marker in the ID map, not asked now.
        if missing and (gone := {ref for ref, links in media.ids_of(missing, {'tmdb'}).items() if links.get('tmdb') == ['']}):
            missing -= gone
        if missing:
            # Get data from TMDB for all missing info at once.
            need = [req.copy(item=ref) for req, ref in zip(requests, req_refs) if req is not None and ref in missing]
            data = self.tmdb.get_media_dict_by_ref(need, details=details)
            if isinstance(data, Mapping):
                self._mark_not_found(data)
                # XXX --- DEBUG ---
                # if 0:
                #     from .tricks import JsonEncoder
                #     def safe_data(d):
                #         if isinstance(d, Mapping):
                #             return {f'{k}' if isinstance(k, MediaRef) else k: safe_data(v) for k, v in d.items()}
                #         if not isinstance(d, str) and isinstance(d, Sequence):
                #             return [safe_data(v) for v in d]
                #         return d
                #     with open('/tmp/media.json', 'w') as f:
                #         json.dump(safe_data(data), f, indent=2, ensure_ascii=False, cls=JsonEncoder)
                # XXX ---
                # Parse data and create items.
                # the fingerprint of a node is of its request (e.g. with episode groups), as the axes above
                new_items = self._parse_tmdb_answer(data, crew_limit=crew_limit, details=details, ref_details=ref_details)
                # Save new items in the cache.
                if const.core.info.save_cache:
                    media.store(self.item_to_rows(new_items, lang=locale))
                self._store_media_ids(new_items)
                # Take new items, now we should have all items. Requested nodes of fresh trees replace cached ones
                # (e.g. an episode or a season is not a top-level fresh item).
                items.update((item.ref, item) for item in new_items if item)
                fresh = self._tree_nodes(new_items)
                items.update((ref, fresh[ref]) for ref in missing if ref in fresh)
                self._mark_absent(missing - fresh.keys(), fresh)
        # Cached seasons / episodes come without theirs (not requested) show, its seasons and the season,
        # fresh ones always have them (TMDB returns the whole show).
        for ffitem in tuple(items.values()):
            if ffitem.ref.season is not None:
                show = ffitem.show_item
                for parent in (show, ffitem.season_item, *(show.season_iter() if show is not None else ())):
                    if parent is not None and parent.ref not in items:
                        items[parent.ref] = parent
        # Restore episodes (of the seasons required with all their episodes).
        if details & InfoDetails.EPISODE_SKIP:
            all_seasons = [it for ref, it in items.items()
                           if ref.is_season and it.children_items and (ref in full_seasons or full_seasons_of(ref))]
            items.update((it.ref, it) for sz in all_seasons for it in sz.children_items or ())

        # Get user ratings.
        if user_ratings and (mode := const.ratings.all_folders) and mode != 'none' and settings.getBool('get_user_ratings'):
            from .ratings import enabled_rating_services
            rating_services = enabled_rating_services(action='get')
            with ThreadPoolExecutor() as ex:
                futures = {key: ex.submit(srv.list_ratings, all_refs) for key, srv in rating_services.items()}  # per account
                ratings = {}
                for srv_name, fut in futures.items():
                    for ref, rate in fut.result().items():
                        ratings.setdefault(ref, {})[srv_name] = rate.rating
            rate_funcs = {
                'min': lambda r: min(r.values()),
                'max': lambda r: max(r.values()),
                'avg': lambda r: int(sum(r.values()) / len(r) + .5),
                'first': lambda r: next(iter(r)),
            }
            func = rate_funcs.get(mode, (lambda r: r.get(mode)))
            for ref, rates in ratings.items():
                if rates and (item := items.get(ref)) and (rating := func(rates)):
                    item.vtag.setUserRating(rating)

        # Convert to episode groups if needed.
        # if isinstance(episode_group, str):
        #     episode_group = next(iter(gr for show in items.values() if show.episode_group.groups
        #                               for gr in show.episode_group.groups if gr.tmdb_id == episode_group), None)
        #     if episode_group and episode_group.items is None:
        #         episode_group = self.tmdb.episode_group(episode_group.tmdb_id)
        if need_episode_group and isinstance(episode_group, str):
            episode_group = self.tmdb.episode_group(episode_group)
        if episode_group:
            if isinstance(episode_group, FFEpisodeGroup) and episode_group.items is not None:
                for show in tuple(items.values()):
                    if show.ref.is_show:
                        if self.switch_episode_group(show, group=episode_group):
                            for sz in show.season_iter():
                                items[sz.ref] = sz
                                for ep in sz.episode_iter():
                                    items[ep.ref] = ep

        # Join show info (e.g. show_item in episode).
        for ref, ffitem in items.items():
            if ref.season is not None:  # season 0 (specials) is a season too
                # the show could be not requested, then take the one linked from the cache
                show = items.get(MediaRef.tvshow(ref.ffid)) or ffitem.show_item
                ffitem.show_item = show
                if show is not None:
                    ffitem.vtag.setTvShowTitle(show.title)
                    ffitem.vtag.setEnglishTvShowTitle(show.vtag.getEnglishTitle())
                if ref.episode is not None:
                    season = items.get(MediaRef.tvshow(ref.ffid, ref.season))
                    if season:
                        season.show_item = show
                        ffitem.season_item = season
                else:
                    show_title = show.vtag.getTvShowTitle() if show else ''
                    show_en_title = show.vtag.getEnglishTvShowTitle() if show else ''
                    for ep in ffitem.episode_iter():
                        ep.show_item = show
                        ep.season_item = ffitem
                        if show_title:
                            ep.vtag.setTvShowTitle(show_title)
                            ep.vtag.setEnglishTvShowTitle(show_en_title)
            elif ref.type == 'show':
                show_title = ffitem.vtag.getTvShowTitle()
                for sz in ffitem.season_iter():
                    sz.show_item = ffitem
                    sz.vtag.setTvShowTitle(show_title)
                    for ep in sz.episode_iter():
                        ep.show_item = ffitem
                        ep.season_item = sz
                        ep.vtag.setTvShowTitle(show_title)
        # Change seasons FFID for volatile one.
        self._set_volatile_ffid(items)
        # Append progress info.
        self._update_items_progress(items, progress=progress)
        # Rewrite roles and another dynamic stuff (for input ffitems).
        for req, ref in zip(requests, req_refs):
            if ref is not None and (oitem := items.get(ref)) is not None and req is not None and (iitem := req.ffitem) is not None:
                self._set_dynamic_stuff(oitem, iitem)
        # Return finding parts (request, FFItems from request, found FFItems).
        return requests, req_refs, items

    def resolve_ids(self, items: Iterable[MediaRef | FFItem | None], services: Iterable[IdService]) -> dict[MediaRef, AllIdsDict]:
        """Resolve external IDs (TMDB, IMDB, Trakt, TvDB...) for the given refs/ffitems.

        One core, best-method-first with early exit so we never hit a slower service once the request
        is satisfied (keeps rate-limits low): seed from the input -> (a) DB cache (no network) ->
        (b) MDBList bulk (primary; one POST resolves imdb/tmdb/trakt/tvdb/mal/mdblist) ->
        (c) TMDB (resolve tmdb from imdb via /find, and external_ids from a known tmdb) ->
        (d) Trakt per-item fallback. Each stage only fills the still-missing, type-supported services.
        A season / episode ref carries the IDs of its series: the series sources (MDBList, TMDB /find, Trakt) give it
        only the series ``tmdb`` (the ref key), its own IDs (e.g. ``imdb`` of an episode) come from TMDB only.

        :param items: refs or ffitems to resolve (``None`` entries are ignored).
        :param services: id services wanted (e.g. ``{'tmdb'}``, ``{'imdb'}``).
        :return: mapping ``{ref: AllIdsDict}`` with whatever could be resolved.
        """
        services = set(services)

        def ref_missing(ref: MediaRef, vid: AllIdsDict) -> set[IdService]:
            """Requested services still missing for `ref` (an unsupported service is never required).

            ``tmdb`` is the system's canonical key (every ffid is tmdb-based, season/episode through the
            parent show), so it is always resolvable when requested even for types whose direct
            ``SERVICE_MEDIA_ID`` entry omits it.
            """
            sup = SERVICE_MEDIA_ID.get(ref.real_type)
            series = _series_ids(ref)
            return {srv for srv in services
                    if (not vid.get(srv) or vid.get(srv) == series.get(srv)) and (srv == 'tmdb' or sup is None or srv in sup)}

        def has_all_ids() -> bool:
            return all(not ref_missing(ref, vid) for ref, vid in found.items())

        def own_ids() -> dict[MediaRef, AllIdsDict]:
            """The result without the series IDs a season / episode ref carries (only its key)."""
            for ref, vid in found.items():
                for srv, val in _series_ids(ref).items():
                    if vid.get(srv) == val:
                        del vid[srv]  # type: ignore[misc]  # AllIdsDict key
            return found

        found: dict[MediaRef, AllIdsDict] = {}
        want_imdb = 'imdb' in services

        # Seed from the input refs / ffitems.
        for ref in items:
            if ref is None:
                continue
            vid: AllIdsDict = found.setdefault(ref.ref, {})
            vid.update(ref.ref.video_ids.all_ids())
            if isinstance(ref, FFItem):
                if want_imdb and (imdb := ref.vtag.getIMDBNumber()):
                    vid['imdb'] = imdb
                # the tmdb of a season / episode item is its own TMDB ID, the ref key is the series one
                vid.update({k: v for k, v in ref.all_ids.items() if k != 'tmdb' or ref.ref.season is None})  # type: ignore[misc]
        if has_all_ids():
            return own_ids()

        # (a) DB: the ID map and the media rows (cheap, no network).
        if db_ids := media.known_ids(list(found), services):
            for ref, ids in db_ids.items():
                if ids:
                    found.setdefault(ref, {}).update((k, v) for k, v in ids.items() if v)  # type: ignore  # just filter AllIdsDict
            if has_all_ids():
                return own_ids()

        # "nothing found" markers: refs asked recently without a wanted ID are not asked again now
        pending = dict(found)
        missing = {ref: miss for ref, vid in found.items() if (miss := ref_missing(ref, vid))}
        for ref, links in media.ids_of(list(missing), services).items():
            if all(links.get(srv) == [''] for srv in missing[ref]):
                pending.pop(ref, None)
        if pending:
            self._resolve_remote(pending, services, ref_missing)
            self._store_resolved(pending, services)
            found.update(pending)
        return own_ids()

    def _resolve_remote(self, found: dict[MediaRef, AllIdsDict], services: set[IdService],
                        ref_missing: Callable[[MediaRef, AllIdsDict], set[IdService]]) -> None:
        """Resolve the missing IDs of `found` in place: (b) MDBList bulk, (c) TMDB, (d) Trakt (see `resolve_ids()`)."""

        def has_all_ids() -> bool:
            return all(not ref_missing(ref, vid) for ref, vid in found.items())

        main_type: set[MainMediaType] = {'movie', 'show'}

        # (b) MDBList bulk (primary): one POST per (type, provider) resolves every cross-service id.
        if self.mdblist is not None:
            from ..api.mdblist import MediaProvider as MdblistMediaProvider
            mdblist_providers: tuple[MdblistMediaProvider, ...] = get_typing_args(MdblistMediaProvider)
            mdblist_providers_set: set[MdblistMediaProvider] = set(mdblist_providers)
            mdblist_requests: dict[tuple[MainMediaType, MdblistMediaProvider], dict[MediaRef, int | str]] = {}
            has_mdblist_providers: set[MdblistMediaProvider]
            mdblist_provider: MdblistMediaProvider
            for ref, vid in found.items():
                wanted = services - vid.keys() if ref.season is None else {'tmdb'} - vid.keys()  # a season / episode: the series tmdb only
                if ((typ := ref.type) in main_type
                        and wanted & mdblist_providers_set
                        and (has_mdblist_providers := vid.keys() & mdblist_providers_set)):  # type: ignore  # set[A] & set[Any] must be set[A]
                    for mdblist_provider in mdblist_providers:
                        if mdblist_provider in has_mdblist_providers and (val := vid.get(mdblist_provider)) is not None:
                            mdblist_requests.setdefault((typ, mdblist_provider), {})[ref] = val
            if mdblist_requests:
                with ThreadPoolExecutor() as pool:
                    futures: dict[tuple[MainMediaType, MdblistMediaProvider], Future] = {
                        (typ, prov): pool.submit(self.mdblist.get_full_ids, prov, typ, list(vals.values()))
                        for (typ, prov), vals in mdblist_requests.items()}
                    for (typ, mdblist_provider), fut in futures.items():
                        for item in fut.result():
                            for ref, val in mdblist_requests[(typ, mdblist_provider)].items():
                                if item.get(mdblist_provider) == val:
                                    found[ref].update(item if ref.season is None else {'tmdb': item['tmdb']} if item.get('tmdb') else {})
                                    break
            if has_all_ids():
                return

        # (c) TMDB: resolve tmdb from imdb via /find (reverse), then external_ids from a known tmdb (forward).
        if 'tmdb' in services:
            find_types: set[RefType] = {*main_type, 'person'}  # /find gives persons too (IMDb `nm…`, e.g. person lists of IMDb)
            find_targets = [ref for ref, vid in found.items()
                            if not vid.get('tmdb') and vid.get('imdb') and ref.type in find_types and 'tmdb' in ref_missing(ref, vid)]
            if find_targets:
                def find_tmdb(ref: MediaRef) -> tuple[MediaRef, MediaRef | None]:
                    if imdb := found[ref].get('imdb'):
                        return ref, self.tmdb.find_id('imdb', imdb)
                    return ref, None
                with ThreadPoolExecutor(TmdbApi.connections()) as pool:  # a request of TMDB each
                    for ref, mref in pool.map(find_tmdb, find_targets):
                        if mref is not None and (tid := mref.video_ids.tmdb):
                            found[ref]['tmdb'] = tid
            if has_all_ids():
                return
        if services - {'tmdb'}:
            tmdb_refs = {ref if ref.tmdb_id else MediaRef.from_tmdb(ref.type, int(tmdb), ref.season, ref.episode): ref
                         for ref, vid in found.items() if ref.type in main_type and (tmdb := vid.get('tmdb')) and ref_missing(ref, vid)}
            if tmdb_refs:
                res = self.tmdb.get_media_dict_by_ref(list(tmdb_refs), details=InfoDetails.INFO_LANG | InfoDetails.COMMON_DETAILS)
                links: list[media.MediaIdLink] = []
                absent: list[media.MediaIdLink] = []
                for tref, it in res.items():
                    ref = tmdb_refs.get(tref, tref)
                    if not it.get('id'):
                        continue  # no answer (an error): asked again next time
                    vid = found.setdefault(ref, {})
                    if ref.season is None:
                        vid['tmdb'] = it['id']  # a season / episode keeps the series tmdb (the ref key), not its own TMDB ID
                    ext = {k.replace('_id', ''): v for k, v in it.get('external_ids', {}).items() if v}
                    vid.update(ext)  # type: ignore[typeddict-item]  # AllIdsDict keys
                    # TMDB is the authority of its IDs: kept for the asked ref (also an episode), a wanted one it has not - marked
                    links.extend((ref, srv, str(val)) for srv, val in ext.items() if srv in TMDB_ID_SERVICES)
                    absent.extend((ref, srv, '') for srv in ref_missing(ref, vid) if srv in TMDB_ID_SERVICES)
                media.store_ids(links, source='tmdb', replace=True, unique=UNIQUE_ID_SERVICES)
                media.store_ids(absent, source='tmdb', ttl=const.media.ids.missing_ttl)
            if has_all_ids():
                return

        # (d) Trakt per-item fallback (no bulk endpoint): query with any known id to fill the rest.
        if self.trakt is not None:
            for ref, vid in found.items():
                if not ref_missing(ref, vid) or ref.real_type not in ('movie', 'show', 'season', 'episode'):
                    continue
                if ref.season is not None and 'tmdb' not in ref_missing(ref, vid):
                    continue  # a season / episode: the series tmdb only (by the series IDs it carries)
                for srv in ('imdb', 'tmdb', 'tvdb', 'trakt'):
                    if val := vid.get(srv):
                        try:
                            mid = self.trakt.id_lookup(id=val, service=srv, type=ref.type)
                        except Exception:
                            fflog_exc()
                            continue
                        if mid is not None and mid.vid is not None:
                            ids = {k: v for k, v in mid.vid.all_ids().items() if v}
                            vid.update(ids if ref.season is None else {'tmdb': ids['tmdb']} if ids.get('tmdb') else {})  # type: ignore  # AllIdsDict
                        break

    def _store_resolved(self, found: dict[MediaRef, AllIdsDict], services: set[IdService]) -> None:
        """
        Keep the resolved IDs in the ID map (permanent; a not authoritative source never overrides a link) and a
        "nothing found" marker (`const.media.ids.missing_ttl`) for refs still without a wanted TMDB ID.
        """
        links: list[media.MediaIdLink] = []
        missing: list[media.MediaIdLink] = []
        for ref, vid in found.items():
            if tmdb := vid.get('tmdb'):
                # whole titles only: the IDs of an episode ref may be of its series (an IMDb episode ref is the series
                # ref with season / episode); episodes come from TMDB only (its external IDs of that episode)
                if ref.type in ('movie', 'show') and ref.season is None:
                    main = MediaRef(ref.type, VideoIds.ffid_from_tmdb_id(int(tmdb)))
                    links.extend((main, srv, str(val)) for srv, val in vid.items() if srv != 'tmdb' and val and srv in ID_LINK_SERVICES)
            elif 'tmdb' in services and not ref.tmdb_id:
                missing.append((ref, 'tmdb', ''))
        media.store_ids(links, source='resolve', unique=UNIQUE_ID_SERVICES)
        media.store_ids(missing, source='resolve', ttl=const.media.ids.missing_ttl)

    def _mark_not_found(self, data: Mapping[MediaRef, Any]) -> None:
        """Mark refs TMDB answered "not found" (404, code 34; a removed entry) in the ID map for `const.media.ids.missing_ttl`."""
        if gone := [(ref, 'tmdb', '') for ref, d in data.items() if isinstance(d, Mapping) and d.get('success') is False and d.get('status_code') == 34]:
            fflog(f'[IDS] not in TMDB: {", ".join(f"{ref:a}" for ref, _, _ in gone)}')
            media.store_ids(gone, source='tmdb', ttl=const.media.ids.missing_ttl)

    def _mark_absent(self, refs: Iterable[MediaRef], fresh: FFItemDict) -> None:
        """
        Mark seasons / episodes missing in the fresh tree of their show (TMDB lists all seasons of a show, a fetched season
        all its episodes) as not in TMDB, like `_mark_not_found()` (e.g. a season numbered otherwise elsewhere).
        The absence is as fresh as the tree: the marker lives up to the freshness of the show (`compute_expires_at()`, short for
        an airing show), at most `const.media.ids.missing_ttl`.
        """
        gone: dict[MediaRef, list[media.MediaIdLink]] = {}  # by the show
        for ref in refs:
            if ref.season is None or (show_ref := ref.show_ref) is None or (show := fresh.get(show_ref)) is None or not show.children_items:
                continue  # not a season / episode, or its show is not fetched with its seasons
            season = fresh.get(ref.season_ref) if ref.is_episode else None  # type: ignore[arg-type]  # a season ref of an episode
            if ref.is_season or season is None or (season.children_items and not self._incomplete(season)):
                gone.setdefault(show_ref, []).append((ref, 'tmdb', ''))
        now = cur_time()
        for show_ref, links in gone.items():
            ttl = min(const.media.ids.missing_ttl, compute_expires_at(fresh[show_ref], now) - int(now))
            fflog(f'[IDS] not in TMDB (for {ttl} s): {", ".join(f"{ref:a}" for ref, _, _ in links)}')
            media.store_ids(links, source='tmdb', ttl=ttl)

    def _store_media_ids(self, items: Iterable[FFItem | None]) -> None:
        """Keep the external IDs of fresh TMDB media in the ID map: TMDB is the authority (replaces, moves a corrected ID)."""
        links: list[media.MediaIdLink] = []
        for item in self._tree_nodes([it for it in items if it]).values():
            if item.ref.tmdb_id:
                ids = item.vtag.getUniqueIDs()
                links.extend((item.ref, srv, str(val)) for srv, val in ids.items() if srv in TMDB_ID_SERVICES and val)
        media.store_ids(links, source='tmdb', replace=True, unique=UNIQUE_ID_SERVICES)

    def correct_ids(self, since: dt_date) -> Optional[int]:
        """
        Correct the ID map by the changes of TMDB since `since`: titles of the map changed in TMDB get their
        external IDs again (TMDB is the authority, a removed entry drops its links); with `const.media.ids.expire_changed`
        media rows of every changed title expire (fresh data on the next view). Return the number of corrected
        titles (their IDs differ from the map), None on failure (asked again next time).
        """
        corrected = 0
        for typ, tmdb_type in (('movie', 'movie'), ('show', 'tv')):
            ids = self.tmdb.changed_ids(cast('MainMediaType', typ), start=since)
            if ids is None:
                return None
            changed = [MediaRef.from_tmdb(cast('MainMediaType', typ), i) for i in ids]
            if const.media.ids.expire_changed:
                media.expire(changed)
            mapped = [ref for ref in media.tmdb_refs_with_ids(ref.ffid for ref in changed) if ref.type == typ]
            old_ids = media.ids_of(mapped, TMDB_ID_SERVICES)
            answered: list[MediaRef] = []
            removed = 0
            for ref in mapped:
                ext = self.tmdb.external_ids(cast('MainMediaType', typ), ref.video_ids.tmdb or 0)
                if ext is False:
                    media.delete_ids([ref])  # the TMDB entry is removed
                    removed += 1
                elif isinstance(ext, Mapping):
                    links = [(ref, srv, str(val)) for key, val in ext.items()  # e.g. `imdb_id` -> `imdb`
                             if val and (srv := key[:-3] if key.endswith('_id') else key) in TMDB_ID_SERVICES]
                    media.store_ids(links, source='tmdb', replace=True, unique=UNIQUE_ID_SERVICES)
                    answered.append(ref)
            new_ids = media.ids_of(answered, TMDB_ID_SERVICES)
            fixed = sum(old_ids.get(ref) != new_ids.get(ref) for ref in answered)  # the links of the map really changed
            corrected += fixed
            fflog(f'[IDS] TMDB changes of {tmdb_type} since {since}: {len(ids)} changed, {len(mapped)} in the ID map,'
                  f' {fixed} corrected, {removed} removed')
        return corrected

    def lookup_ids(self, refs: Iterable[MediaRef | FFItem], services: Iterable[IdService]) -> dict[MediaRef, AllIdsDict]:
        """Lookup external service IDs (TMDB, IMDB, Trakt, TvDB...). Thin alias over :meth:`resolve_ids`."""
        return self.resolve_ids(refs, services)

    def lookup_refs(self, refs: Iterable[MediaRef | None]) -> Sequence[MediaRef | None]:
        """Rebuild external refs (IMDB, Trakt, TvDB, MDBList) onto their TMDB id; keep order 1:1.

        Thin adapter over :meth:`resolve_ids` (``services={'tmdb'}``), which already batches the
        MDBList bulk / TMDB find / Trakt fallback. ``None`` and already-TMDB refs pass through
        unchanged; an external ref maps to its rebuilt TMDB ref (type/season/episode preserved) or
        ``None`` when it cannot be resolved.
        """
        if type(refs) is not list or TYPE_CHECKING:
            refs = list(refs)
        external = [ref for ref in refs if ref is not None and not ref.tmdb_id]
        if not external:
            return refs
        ids = self.resolve_ids(external, {'tmdb'})
        return [ref if ref is None or ref.tmdb_id else self._ref_with_tmdb(ref, ids.get(ref.ref, {}).get('tmdb'))
                for ref in refs]

    # @logtime
    # @profiler(sort_by='tottime')
    def _set_dynamic_stuff(self, item: FFItem, source: Optional[FFItem]) -> FFItem:
        """
        Carry the usage state of the input item `source` over to the found `item`: the DYNAMIC vars (`kind`, as `clone()`:
        the role, the description style, the properties, the list data in `source_data`, …), the data ffinfo got for the
        item now (its progress, its TMDB `source_data`) stay; the context menu and `temp` (not declared) too.
        """
        if source:
            fetched = item.progress, item.source_data
            source.__copy_state_into__(item, 'dynamic')
            source.vtag.__copy_state_into__(item.vtag, 'dynamic')
            item.progress = fetched[0] or item.progress
            item.source_data = fetched[1] or item.source_data
            item.cm_menu.extend(source.cm_menu)
            item.temp.__dict__.update(source.temp.__dict__)
        return item

    @staticmethod
    def _ref_with_tmdb(ref: MediaRef, tmdb: int | None) -> MediaRef | None:
        """Rebuild `ref` onto a TMDB id, keeping its type/season/episode; ``None`` if `tmdb` is falsy."""
        if not tmdb:
            return None
        return evolve(ref, ffid=VideoIds.ffid_from_tmdb_id(tmdb))

    def find_ids(self, source: ExternalIdType, refs: Iterable[MediaRef | None]) -> Sequence[MediaRef | None]:
        """Resolve each ref to a TMDB-based ref using its `source` id (order preserved).

        Thin adapter over :meth:`resolve_ids` (``services={'tmdb'}``); ``None`` inputs and unresolved
        refs map to ``None`` in place so the result lines up 1:1 with `refs`.
        """
        refs = list(refs)
        ids = self.resolve_ids((ref for ref in refs if ref is not None), {'tmdb'})
        return [None if ref is None else self._ref_with_tmdb(ref, ids.get(ref.ref, {}).get('tmdb')) for ref in refs]

    @overload
    def get_en_skel_items(self,
                          refs: SequenceProto[Union[MediaRef, FFItem]],
                          *,
                          keep_missing: Literal[False] = False,
                          locale: Optional[str] = None,
                          options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS,
                          ) -> list[FFItem]: ...

    @overload
    def get_en_skel_items(self,
                          refs: SequenceProto[Union[MediaRef, FFItem]],
                          *,
                          keep_missing: Literal[True],
                          locale: Optional[str] = None,
                          options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS,
                          ) -> list[Optional[FFItem]]: ...

    def get_en_skel_items(self,
                          refs: Union[SequenceProto[Union[MediaRef, FFItem]], Pagina[Union[MediaRef, FFItem]]],
                          *,
                          keep_missing: bool = False,
                          locale: Optional[str] = None,
                          options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS,
                          ) -> Any:
        """Get list of item info in order, refs must be normalized."""

        # Find one item in received info.
        def get_ff(ref: MediaRef) -> Optional[FFItem]:
            if ff := items.get(ref):
                return ff
            if ff := in_items.get(ref):
                ff = self._broken_item(ff)  # no info in TMDB: the input item as its list gave it
            return ff

        # Get info.
        in_refs, in_items, items = self._get_en_skel_items(refs, locale=locale, options=options)
        # Return list of FFItem in `refs` order.
        if keep_missing:
            it_gen = [get_ff(ref) for ref in in_refs if ref]
        else:
            it_gen = [item for ref in in_refs if ref and (item := get_ff(ref))]
        if isinstance(refs, Pagina):
            return ItemList(it_gen, page=refs.page, total_pages=refs.total_pages)
        return list(it_gen)

    def _get_en_skel_items(self,
                           refs: Sequence[Union[MediaRef, FFItem]],
                           *,
                           locale: Optional[str] = None,
                           options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS,
                           ) -> tuple[Sequence[Optional[MediaRef]], FFItemDict, FFItemDict]:
        """Get skeleton items by refs (or ffitems). Only base EN info."""
        # fix locale
        if locale:
            lng, _, rgn = locale.replace('_', '-').partition('-')
            locale = f'{lng}-{rgn.upper()}'
        # Take refs (from FFItem, ref.ref is correct too).
        in_items = {x.ref: x for x in refs if isinstance(x, FFItem)}
        refs = [x.ref for x in refs]
        # Easy normalize refs (TMDB seasons only).
        refs = [x.normalize() or x for x in refs]
        # Resolve external IDs (IMDB only).
        if any(not ref.tmdb_id for ref in refs):
            tmdb_refs = self.tmdb.find_ids('imdb', (vid.imdb for ref in refs for vid in (ref.video_ids,) if vid.imdb))
            xit = iter(tmdb_refs)
            in_refs = [next(xit) if vid.imdb else ref for ref in refs for vid in (ref.video_ids,)]
        else:
            in_refs = refs
        # Get rows from cache at once.
        # TODO: cache support !!!
        items, missing = {}, tuple({ref for ref in in_refs if ref})
        if True:
            # Need translation if different locale.
            if locale and locale not in self.EN_LOCALES:
                options |= SkelOptions.TRANSLATIONS
            # Get data from TMDB for all missing info at once.
            data = self.tmdb.get_skel_en_media(missing, options=options)
            if data:
                # Parse data and create items. A single broken/missing TMDB entry must not
                # discard all the other (valid) items fetched together in this batch.
                new_items: list[FFItem] = []
                for d in data.values():
                    try:
                        new_items.append(self.parse_tmdb_skel_item(d, locale=locale, options=options))
                    except ValueError as exc:
                        fflog(f'Skipping broken TMDB item: {exc}')
                # Save new items in he cache.
                # if const.core.info.save_cache:
                #     set_media_info([self.item_to_row(item) for item in new_items if item])
                # Take new items, now we should have all items.
                items.update((item.ref, item) for item in new_items if item)
        # Change seasons FFID for volatile one.
        self._set_volatile_ffid(items)
        # Rewrite roles and another dynamic stuff.
        for ref, ffitem in items.items():
            self._set_dynamic_stuff(ffitem, in_items.get(ref))
        # Return finding parts (request, FFItems from request, found FFItems).
        return in_refs, in_items, items

    def item_genres(self, item: FFItem, *, translations: Optional[dict[CodeId, str]] = {}) -> list[FFItem]:
        """Return itm collection."""
        if item.facets is not None:
            genres = {g['code']: g['name'] for g in item.facets.get('genre', ())}
            if translations is not None:
                genres = {gid: translations.get(gid, gname) for gid, gname in genres.items()}
            return [FFItem(type='genre', ffid=gid, mode=FFItem.Mode.Folder, label=gname)
                    for gid, gname in genres.items()]
        return []

    def item_collection(self, item: FFItem) -> Optional[FFItem]:
        """Return itm collection."""
        if item.source_data:
            return self.parse_item(item.source_data.get('belongs_to_collection'), type='collection')
        if item.collection_data:  # cached item, there is no source data
            return self.parse_item(item.collection_data, type='collection')
        return None

    # --- trakt sync progress ---

    @logtime
    def playback_info(self, refs: Optional[Iterable[MediaRef]], *, kodi: bool = True) -> MediaPlayInfoDict:
        """
        Return playback rows (movies, episodes; a show or season ref: all its episodes; None: all) merged from the accounts
        enabled for reading the watched or the progress (`lib.ff.progress`); an account enabled for one of them gives only it.
        Rows of the local Kodi account (skipped if not `kodi`) are read from Kodi video DB, rows of other accounts from `playback.db`
        (there the local account has only its removals, see `apply_local()`). Only the media watched or in progress are returned.
        """
        if refs is not None:
            refs = tuple(refs)
        parts, local = self.progress_accounts(kodi=kodi)
        rows: dict[str, list[MediaPlayInfo]] = {account_id: [] for account_id in parts}
        found = [pb for account_id in local for pb in self.kodi_rows(refs, account_id=account_id)]
        found.extend(get_playback_rows(refs, accounts=list(parts)))
        for pb in found:
            if self._read_part(pb, *parts[pb.account_id], removals=True):
                rows[pb.account_id].append(pb)
        return {ref: pb for ref, pb in merge_playback(rows).items() if pb.play_count or pb.progress}

    def account_rows(self, account_id: str) -> list[MediaPlayInfo]:
        """
        Return playback rows of one account (all its movies and episodes) with only what it reads (the watched, the progress),
        like `playback_info()` without the merge; none if it reads neither.
        """
        parts, local = self.progress_accounts()
        if (part := parts.get(account_id)) is None:
            return []
        found = self.kodi_rows(None, account_id=account_id) if account_id in local else get_playback_rows(None, accounts=[account_id])
        return [pb for pb in found if self._read_part(pb, *part)]

    @staticmethod
    def _read_part(pb: MediaPlayInfo, watched: bool, progress: bool, *, removals: bool = False) -> bool:
        """
        Clear the part of the row its account does not read (the watched, the progress, their removal times); return False
        if nothing is left (with `removals` a removal time is something, for the merge).
        """
        if not watched:
            pb.play_count = pb.last_watched_at = pb.unwatched_at = None
        if not progress:
            pb.clear_progress()
            pb.unpaused_at = None
        return bool(pb.play_count or pb.progress or (removals and (pb.unwatched_at or pb.unpaused_at)))

    def progress_accounts(self, *, kodi: bool = True) -> tuple[dict[str, tuple[bool, bool]], list[str]]:
        """
        Return the accounts of the merged progress: account ID -> (reads the watched, reads the progress) of the accounts enabled
        for one of them, and the IDs of the local Kodi accounts among them (skipped if not `kodi`).
        """
        enabled = [acc for acc in accounts() if kodi or acc.type.name != 'kodi']
        parts = {acc.id: (account_enabled(acc, 'watched', 'read'), account_enabled(acc, 'progress', 'read')) for acc in enabled}
        parts = {account_id: part for account_id, part in parts.items() if any(part)}
        return parts, [acc.id for acc in enabled if acc.type.name == 'kodi' and acc.id in parts]

    def watched_shows(self, *, account: Optional[str] = None, stale: Optional[list[MediaRef]] = None, first: Optional[int] = None) -> list[MediaRef]:
        """
        Return the shows in progress, the latest played first (a watch or a pause of its episode): the shows with a watched
        episode (no specials; or only a started one with `const.indexer.tvshows.progress.show_watching`) in the merged rows of
        the accounts (`progress_accounts()`; only the shows the `account` played if given), below 100 % of their aired
        episodes (all with `const.indexer.tvshows.progress.show_full_watched`). Light rows of all shows and their
        aired episodes from the media cache (`media.aired_of()`, no media rows); a page gets its details later.
        The shows with no current aired episodes are updated now (`update_aired()`, TMDB if not cached), or with `stale`
        those of the `first` shows only (the pages shown, the first one by default, `const.indexer.tvshows.progress.page_size`:
        a page gets the details of its shows anyway, a show watched in 100 % is not shown; a show out moves the next one up,
        read too) and the others added to it (the caller updates them, the service in the background) and kept in progress.
        """
        parts, local = self.progress_accounts()
        found = list(get_played_episodes(list(parts)))  # the local accounts: their removals only
        found.extend(PlayedEpisode.from_row(pb) for account_id in local for pb in self.kodi_rows(None, account_id=account_id)
                     if pb.ref.is_episode and pb.ref.season and pb.ref.episode)
        rows: dict[str, list[PlayedEpisode]] = {account_id: [] for account_id in parts}
        for pb in found:
            if self._read_part(pb, *parts[pb.account_id], removals=True):
                rows[pb.account_id].append(pb)
        # the episodes merged by the rules of the merged progress (`lib.ff.progress`), on light rows
        watched: dict[int, set[tuple[int, int]]] = {}
        played: dict[int, int] = {}
        for (ffid, season, episode), group in group_rows(rows, attrgetter('key')).items():
            play_count, last_watched_at, resume, *_ = merge_state(group)
            if play_count:
                watched.setdefault(ffid, set()).add((season, episode))
            elif resume is None or not 0 < (resume.progress or 0) < 100:
                continue
            played[ffid] = max(played.get(ffid, 0), last_watched_at or 0, resume.paused_at or 0 if resume else 0)
        own = {pb.ffid for pb in rows.get(account, ()) if pb.play_count or pb.progress} if account else set()
        started = const.indexer.tvshows.progress.show_watching
        refs = [MediaRef.tvshow(ffid) for ffid in sorted(played, key=played.__getitem__, reverse=True)
                if (started or ffid in watched) and (account is None or ffid in own)]
        if const.indexer.tvshows.progress.show_full_watched:
            return refs
        missing: list[MediaRef] | None = None if stale is None else []
        aired = self.aired_map(refs, stale=missing)

        def in_progress(ref: MediaRef) -> bool:
            """Return False if all aired episodes of the show are watched (its aired episodes known)."""
            if (row := aired.get(ref.ffid)) is not None and row.count:
                seen = watched.get(ref.ffid, set())
                if ranges := row.ranges:
                    seen = {(s, e) for s, e in seen if any(rs == s and start <= e <= end for rs, start, end in ranges)}
                return len(seen) < row.count
            return True

        if first is None:
            first = const.indexer.tvshows.progress.page_size
        while True:
            shows = [ref for ref in refs if in_progress(ref)]
            if missing is None or not (head := [ref for ref in shows[:first] if ref in missing]):
                break
            aired.update(self.update_aired(head))  # a show not found stays in progress (as with no `stale`)
            missing = [ref for ref in missing if ref not in head]
        if stale is not None and missing:
            stale.extend(missing)
        return shows

    def update_aired(self, refs: Sequence[MediaRef]) -> dict[int, MediaAiredRow]:
        """
        Read the aired episodes of the shows `refs` from their metadata (the one place of the rule, see `aired_map()`): the season sizes and the next episode to air (`surrogate_episode_refs()`), the episodes of the shows with mixed
        numbering (`number_episodes()`); `const.indexer.tvshows.progress.show_details`, TMDB if not cached. Store them in the media
        cache (`media.aired_of()`, valid until the next air, `aired_expires_at()`); a show not found gets an empty row for
        `const.media.ids.missing_ttl` (kept in progress, not asked every time). Return the new rows by show FFID.
        """
        if not refs:
            return {}
        items = self.get_items(list(refs), details=const.indexer.tvshows.progress.show_details, progress=Progress.NO, user_ratings=False)
        self.number_episodes(items)
        now = cur_time()
        rows: dict[int, MediaAiredRow] = {}
        for it in items:
            if it is None or not it.ref.is_show:
                continue
            ranges: list[list[int]] = []  # [season, first, last]
            for ref in it.surrogate_episode_refs(aired=True):
                if not ref.season or not ref.episode:
                    continue
                if ranges and ranges[-1][0] == ref.season and ranges[-1][2] + 1 == ref.episode:
                    ranges[-1][2] = ref.episode
                else:
                    ranges.append([ref.season, ref.episode, ref.episode])
            rows[it.ref.ffid] = MediaAiredRow(ffid=it.ref.ffid, episodes=json.dumps(ranges), count=sum(last - first + 1 for _, first, last in ranges)
                                              or it.aired_episodes_count, expires_at=aired_expires_at(it, now))
        missing = [MediaAiredRow(ffid=ref.ffid, expires_at=int(now) + const.media.ids.missing_ttl) for ref in refs if ref.ffid not in rows]
        media.store_aired([*rows.values(), *missing])
        return rows

    def aired_map(self, refs: Iterable[MediaRef], *, stale: Optional[list[MediaRef]] = None) -> dict[int, MediaAiredRow]:
        """
        Return the aired episodes of the shows of `refs` (a season / an episode: of its show) by show FFID: the aired map of the
        media cache (`media.aired_of()`), the one source of the aired episodes of a show (the progress, the shows in progress,
        the last / next episode, marking, UpNext). A missing or expired map is read now (`update_aired()`, TMDB if not cached),
        or with `stale` only added to it (the caller updates them, the service in the background).
        """
        shows = list({ref.ffid: MediaRef.tvshow(ref.ffid) for ref in refs if ref.type == 'show'}.values())
        now = cur_time()
        aired = {ffid: row for ffid, row in media.aired_of(ref.ffid for ref in shows).items() if row.expires_at is None or row.expires_at > now}
        if missing := [ref for ref in shows if ref.ffid not in aired]:
            if stale is None:
                aired.update(self.update_aired(missing))
            else:
                stale.extend(missing)
        return aired

    def kodi_rows(self, refs: Optional[Iterable[MediaRef]], *, account_id: str) -> list[MediaPlayInfo]:
        """
        Return playback rows of the local Kodi account from Kodi video DB, like `get_playback_rows()`: the plays of `refs`
        only (a show / season: its episodes, read by their play URLs), all plays if None (the service, the account history);
        the plays of a media (FF play URLs, STRM files of the library) merged to one row. The FF media playing now has its
        row ahead of Kodi video DB until Kodi writes the play (`LivePlay`).
        """
        if refs is not None:
            refs = list(refs)
        plays = video_db.get_plays(refs, library=True)
        rows = [info.play_info(account_id) for info in plays if info.ref.ffid not in VideoIds.KODI]  # KODI: broken item (invalid FFID)
        # one row of a media (its FF3 / FF2 play URL, its STRM file of the library): an account is consistent by itself
        merged = list(merge_playback({account_id: rows}, strategy='union').values())
        for pb in merged:
            pb.account_id = account_id  # a merged row is a new one
        if (live := live_play()) is not None and (ref := live.media_ref) is not None and (refs is None or {ref, *ref.parents()} & {*refs}):
            if (row := live.row(account_id, next((pb for pb in merged if pb.ref == ref), None))) is not None:
                merged = [pb for pb in merged if pb.ref != ref] + [row]
        return merged

    # def progress_analize(self, progress_list: TraktPlaybackList) -> list[FFItem]:
    #     """Return FFItem with progreass from low-level trakty sync progeress rows."""

    def find_last_next_episodes(self, it: FFItem, *, policy: Optional[NextWatchPolicy] = None,
                                aired: Optional[Mapping[int, MediaAiredRow]] = None) -> tuple[Optional[MediaRef], Optional[MediaRef]]:
        """
        Return the refs of the last and the next episode of the show `it` by `policy`: its aired episodes from its aired map
        (`aired_map()`, given or read now; without ranges from the metadata, `surrogate_episode_refs()`) and its watched
        episodes from its progress (`Progress.FULL`, `update_item_progress()`).
        """
        if policy is None:
            policy = NextWatchPolicy(const.indexer.tvshows.progress.next_policy)
        if aired is None:
            aired = self.aired_map([it.ref])
        episodes = tuple(_aired_refs(aired.get(it.ref.ffid), it.ref.ffid) or it.surrogate_episode_refs(aired=True))
        if not episodes:
            return None, None
        watched: dict[MediaRef, datetime] = {}
        if it.progress is not None:
            watched = {epp.ref: epp.last_watched_at for epp in it.progress.bar if epp.has_last_watched_at}

        lst = nxt = None
        # Example: last watched: B, episodes: aBcDef
        if policy == NextWatchPolicy.LAST:
            # find first unwatched episode after latest watched episode (result: D, e)
            for ep in episodes:
                if ep in watched:
                    lst = ep
            for pe, ne in pairwise(episodes):
                if pe in watched and ne not in watched:
                    nxt = ne
        elif policy == NextWatchPolicy.CONTINUED:
            # find last watched episode (result: B, c)
            ind, lst = max(enumerate(episodes), key=lambda x: watched.get(x[1]) or datetime.min)
            for i in range(ind + 1, len(episodes)):
                if (ep := episodes[i]) not in watched:
                    nxt = ep
                    break
        elif policy == NextWatchPolicy.FIRST:
            # find first unwatched episode (result: B, c)
            for pe, ne in pairwise(episodes):
                if pe in watched and ne not in watched:
                    lst, nxt = pe, ne
                    break
        elif policy == NextWatchPolicy.NEWEST:
            # return newest episode (result: D, f)
            for ep in episodes:
                if ep in watched:
                    lst = ep
                else:
                    nxt = ep
        return lst, nxt  # last, next

    def aired_episode_refs(self, ref: MediaRef, *, episode_group: str | None = None) -> list[MediaRef]:
        """
        Return the refs of the aired episodes of the show / season `ref` (to mark them watched / unwatched) from its aired map
        (`aired_map()`; without ranges from the metadata, `surrogate_episode_refs()`); the specials (season 0): all of them
        (no airing order, not in the map). A movie / an episode: itself. A season of the `episode_group` (its ref is the real
        season of the same number): its aired episodes (the real refs) from the group.
        """
        if episode_group and ref.is_season:
            group = self.tmdb.episode_group(episode_group, show=ref.ffid)
            season = next((sz for sz in group.items or () if sz.ref.season == ref.season), None) if group else None
            return [ep.ref for ep in season.episode_iter() if not ep.unaired] if season else []
        if not (ref.type == 'show' and ref.episode is None):
            return [ref]
        if ref.season != 0 and (row := self.aired_map([ref]).get(ref.ffid)) is not None and row.ranges:
            return _aired_refs(row, ref.ffid, ref.season)
        if (it := next(iter(self.get_items([ref], progress=Progress.NO, user_ratings=False)), None)) is None:
            return []
        self.number_episodes([it])
        return list(it.surrogate_episode_refs(aired=ref.season != 0))

    def number_episodes(self, items: Iterable[Optional[FFItem]]) -> None:
        """
        Give the seasons their episodes where the episode numbers do not follow from the metadata (`FFItem.episode_numbers_known`,
        TMDB shows with mixed numbering): all seasons of a show, a season itself, the season of an episode. The episodes come
        from the cache (TMDB once); other shows are not touched (their numbers come from the season sizes).
        """
        nodes: list[FFItem] = []
        for it in items:
            if it is None or it.ref.type != 'show' or it.episode_numbers_known:
                continue
            if it.ref.is_show:
                nodes.extend(sz for sz in it.season_iter() if sz.ref.season)
            elif it.ref.is_season:
                nodes.append(it)
            else:
                show = it.show_item
                nodes.extend(sz for sz in (it.season_item, show and show.get_season_item(it.ref.season or 0)) if sz is not None)
        nodes = [sz for sz in nodes if not sz.children_complete]
        if not nodes:
            return
        details = InfoDetails.new(const.media.info_details) | InfoDetails.SEASON_EPISODES
        seasons = {sz.ref: sz for sz in self.get_items(list({sz.ref for sz in nodes}), details=details, progress=Progress.NO, user_ratings=False)}
        for sz in nodes:
            if (full := seasons.get(sz.ref)) is not None and full.children_complete:
                sz.children_items = full.children_items
                del sz.aired_episodes_count
                if sz.show_item is not None:
                    del sz.show_item.aired_episodes_count

    def progress_shows_page(self, refs: Sequence[MediaRef]) -> list[tuple[FFItem, Optional[FFItem]]]:
        """
        Return the shows of a page of the shows in progress with their next episodes (None if no next one): the shows with
        their seasons (`const.indexer.tvshows.progress.show_details`, no episodes) and the merged progress, the next
        episodes with their own data only (the default `const.media.info_details`, no siblings).
        The plugin page and the service warm-up of pages use it.
        """
        shows = self.get_items(refs, details=const.indexer.tvshows.progress.show_details, progress=Progress.FULL)
        aired = self.aired_map(it.ref for it in shows)
        nexts = {it.ref: nxt for it in shows if (nxt := self.find_last_next_episodes(it, aired=aired)[1]) is not None}
        # the user ratings of the shows only (as the episodes in the show trees before); the progress of the next episodes and
        # their seasons only (the shows have it from the first call)
        episodes = {ep.ref: ep for ep in self.get_items(list(nexts.values()), progress=Progress.NO, user_ratings=False)} if nexts else {}
        if episodes:
            self._update_items_progress({**{ep.ref: ep for ep in episodes.values()},
                                         **{sz.ref: sz for ep in episodes.values() if (sz := ep.season_item) is not None}}, progress=Progress.FULL)
        return [(it, episodes.get(nexts[it.ref]) if it.ref in nexts else None) for it in shows]

    def update_item_progress(self,
                             it: FFItem,
                             *,
                             playback_info: Optional[MediaPlayInfoDict] = None,
                             episodes: Optional[Mapping[int, Sequence[MediaPlayInfo]]] = None,
                             aired: Optional[Mapping[int, MediaAiredRow]] = None,
                             ) -> FFItem:
        """
        Update item (and its children) progress from the merged playback rows of accounts (`playback_info()`): movies and
        episodes from their rows, shows and seasons derived from their episodes (`episodes`: rows of episodes by show FFID)
        over their aired episodes (`aired`: the aired maps by show FFID, see `aired_map()`; the specials and a show without
        a map: from the metadata).
        """
        if playback_info is None:
            playback_info = self.playback_info([it.ref])
        if episodes is None:
            episodes = _episodes_by_show(playback_info)
        ref = it.ref
        slug: Optional[str] = None
        if ref.type == 'show' and ref.episode is None:  # show or season
            rows = episodes.get(ref.ffid, ())
            skeleton = _aired_refs(aired.get(ref.ffid), ref.ffid, ref.season) if aired and ref.season != 0 else []
            if (progress := show_progress(it, rows, aired=skeleton or None)) is not None:
                it.progress = progress
            if ref.is_show:
                slug = next((pb.tv_slug for pb in rows if pb.tv_slug), None)
        elif pb := playback_info.get(ref):
            it.progress = pb.as_media_progress()
            slug = pb.slug
        vtag = it.vtag
        if slug and not vtag.getUniqueID('slug'):
            vtag.setUniqueID(slug, 'slug')
        for ch in it.children_items or ():
            if ch.progress is None:
                self.update_item_progress(ch, playback_info=playback_info, episodes=episodes, aired=aired)
        return it

    def progressbar_str(self, watched: SequenceProto[Any], *, width: int = CONST_REF.indexer.progressbar.width) -> str:
        """Return ||| progressbar for MediaProgress.bar."""
        width = const_value(width)
        pbar = const.indexer.progressbar  # one read: one const
        col0 = pbar.empty.color
        col1 = pbar.partial.color
        col2 = pbar.fill.color
        col3 = pbar.watched.color
        ch0 = pbar.empty.char
        ch1 = pbar.partial.char
        ch2 = pbar.fill.char
        ch3 = pbar.watched.char
        bar, color = '', ''
        for i in range(width):
            a = len(watched) * i // width
            b = max(a + 1, len(watched) * (i + 1) // width)
            block = watched[a:b]
            if all(block):
                col, ch = col2, ch2
            elif any(block):
                col, ch = col1, ch1
            elif any(e is AREADY_WATCHED for e in block):
                col, ch = col3, ch3
            else:
                col, ch = col0, ch0
            if color != col:
                if color:
                    bar += '[/COLOR]'
                if col:
                    bar += f'[COLOR {col}]'
                color = col
            bar += ch
        if color:
            bar += '[/COLOR]'
        return bar

    def progress_descr_style(self, progress: MediaProgress) -> str:
        if settings.getBool('show.progressbar'):
            """Return progress description (tagline) style."""
            p = progress
            mtype = progress.ref.real_type
            # get const settings
            ON, OFF = 1, 0
            if mtype == 'movie':
                style = const.indexer.movies.progressbar.style
                bar_mode = ProgressBarMode(const.indexer.movies.progressbar.mode)
                width = const.indexer.movies.progressbar.width
            elif mtype == 'episode':
                style = const.indexer.episodes.progressbar.style
                bar_mode = ProgressBarMode(const.indexer.episodes.progressbar.mode)
                width = const.indexer.episodes.progressbar.width
            else:
                style = const.indexer.progressbar.style
                bar_mode = ProgressBarMode(const.indexer.progressbar.mode)
                width = const.indexer.progressbar.width
            # preselect mode
            if bar_mode is ProgressBarMode.NONE:
                return ''
            if bar_mode is ProgressBarMode.WATCHING:
                if 0 < p.progress < 100:
                    bar_mode = ProgressBarMode.PERCENT
                else:
                    return ''
            elif bar_mode is ProgressBarMode.PERCENT_AND_WATCHED:
                if progress.play_count and 0 < p.progress < 100:  # watching already watched video
                    OFF = AREADY_WATCHED
                bar_mode = ProgressBarMode.PERCENT
            # select mode
            pp = p.total_progress
            if bar_mode is ProgressBarMode.WATCHED:
                bar = p.bar
            elif bar_mode is ProgressBarMode.PERCENT:
                if progress.play_count and not 0 < p.progress < 100:
                    bar = (ON,)
                else:
                    pp = p.progress
                    bar = (ON,) * int(p.progress + .5) + (OFF,) * (100 - int(p.progress + .5))
            else:
                bar = (OFF,)
            # draw bar
            return style.format('{}', descr='{}', tagline='{}', p=p, progress=pp, percent=round(pp),
                                watching_progress=p.progress, progressbar=self.progressbar_str(bar, width=width))

    def update_item_kodi_data(self, items: SequenceProto[FFItem]) -> None:
        """
        Apply Kodi video DB data to items before they go to Kodi: raw playback info (FFItem.kodi_data, the watched
        detection mode) and the stream details of an item played before.

        Kodi fills missing stream details of a list item which is in its DB in a background thread
        (CVideoThumbLoader::LoadItemCached: Reset() and add), while the GUI reads them for a label: a Kodi race
        (master, K22: crash in CStreamDetails::GetPreferredAudioStreamIndex). An item with its stream details is skipped.
        """
        watched_mode = const.core.media_watched_mode is MediaWatchedMode.WATCH_LISTITEM
        plays = {pb.ref: pb for pb in video_db.get_plays_for(items, streams=True)}
        for item in items:
            if pb := plays.get(item.ref):
                if watched_mode:
                    item.kodi_data = pb
                if pb.streams and not item.isFolder():
                    pb.add_streams(item.vtag)

    def web_url(self, ref: MediaRef) -> str:
        """Return link to media for humans."""
        if ref.tmdb_id:
            return self.tmdb.web_url(ref)
        return ''

    def _aliases_locales(self, locale: Union[None, str, Iterable[str]] = None) -> Iterable[str]:
        """Return locale for aliases search."""
        if locale is None:
            locale = (self.tmdb.lang or 'pl', 'en_US', 'en_GB')
        elif isinstance(locale, str):
            locale = (locale, 'en_US', 'en_GB')
        return locale

    def _parse_alternative_titles(self, data: JsonData, *, locale: str | Iterable[str] | None = None) -> tuple[FFTitleAlias, ...]:
        """Parse title aliases from TMDB data."""
        rx = re.compile(r'[-_]')
        locale = self._aliases_locales(locale)
        countries = {rx.split(loc)[-1].upper() for loc in locale}
        return tuple(FFTitleAlias(title=it['title'], country=it['iso_3166_1'].lower())
                     for it in data.get('results', data.get('titles', ()))
                     if it['iso_3166_1'] in countries)

    @overload
    def get_title_aliases(self, item: MediaRef, *, locale: str | Iterable[str] | None = None, orig_only_romanized: bool = True) -> FFItem | None: ...

    @overload
    def get_title_aliases(self, item: FFItem, *, locale: str | Iterable[str] | None = None, orig_only_romanized: bool = True) -> FFItem: ...

    def get_title_aliases(self,
                          item: MediaRef | FFItem,
                          *,
                          locale: str | Iterable[str] | None = None,
                          orig_only_romanized: bool = True,
                          ) -> FFItem | None:
        """Get ot update title alaises (from trakt.tv). Could update trakt_slug unique ID."""
        if not isinstance(item, FFItem):
            if (it := self.get_item(item)) is None:
                return None
            item = it
        ref = item.ref
        if (mtype := ref.type) not in ('movie', 'show'):
            return None
        # TMDB aliases.
        if const.media.aliases_service == 'tmdb':
            # already loaded (append_to_response)
            pass
        # Anything else means const.media.aliases_service == 'trakt'
        elif self.trakt is not None and (mtype := ref.real_type) in ('movie', 'show'):
            # get trakt ID
            ids = item.ids
            tid = ids.get('trakt', ids.get('slug'))  # type: ignore
            # missing, lookup trakt ID by TMDB ID
            if not tid and (real_type := ref.real_type) in ('movie', 'show', 'season', 'episode'):
                multi = self.trakt.id_lookup(ids.get('tmdb') or 0, service='tmdb', type=real_type)
                if multi:
                    if multi.vid.trakt:
                        tid = multi.vid.trakt
                    if multi.trakt_slug and not item.vtag.getUniqueID('trakt_slug'):
                        # update trakt_slug unique ID
                        item.vtag.setUniqueID(multi.trakt_slug, 'trakt_slug')
            # fallaback to IMDB ID
            if not tid:
                tid = ids.get('imdb')
            # get aliases from trakt
            if tid:
                rx = re.compile(r'[-_]')
                locale = self._aliases_locales(locale)
                countries = {rx.split(loc)[-1].lower() for loc in locale}
                orig_coutries = {c.lower() for c in item.vtag.getCountryCodes()}
                aliases = dict.fromkeys(FFTitleAlias(**it)
                                        for it in self.trakt.aliases(mtype, tid)
                                        if (it['country'] in countries
                                            or (it['country'] in orig_coutries and (not orig_only_romanized or is_romanized(it['title'])))))
                item.aliases_info = tuple(aliases)

            # Fallback to TMDB aliases if nothing found yet.
            if not item.aliases_info and (tmdb_id := ref.tmdb_id):
                # Get TMDB aliases.
                if data := self.tmdb.aliases(mtype, tmdb_id):
                    item.aliases_info = self._parse_alternative_titles({'results': data}, locale=locale)

    def get_episode_groups(self, show: FFRef | int) -> list[FFEpisodeGroup]:
        """Get episode groups for the show."""
        if isinstance(show, FFItem) and (groups := show.episode_group.groups) is not None:
            return groups
        groups = self.tmdb.episode_groups(show)
        if isinstance(show, FFItem):
            show.episode_group.groups = groups
        return groups

    def get_episode_group_items(self, group: str, *, info: bool = True, details: InfoDetails | str | None = InfoDetails.DEFAULT) -> list[FFItem]:
        """Get episode group items from TMDB by group hex ID."""
        items = self.tmdb.episode_group_list(group)
        if info:
            items = self.get_items(items, details=details)
        return items

    def switch_episode_group(self,
                             item: FFItem,
                             group: str | FFEpisodeGroup | None,
                             *,
                             #: Force safe operation, request all data from TMDB. If false use data from item if possible.
                             safe: bool = False,
                             ) -> FFItem | None:
        """
        Switch FFItem episode group. None means no episode group (tmdb order). Works only for show and episode.
        Group must exists in the item (media).
        Return the item or None if could not switch (the episode is not in the group).
        NOTE: item.ref.episode and item.episode could differ. The season too.
        The show is changed with all episodes (and new quasi-seasons).
        The episode is changed itself (season and episode numbers only).
        """
        # was tmdb order and is the same
        if item.episode_group.current is None and group is None:
            return
        ref = item.ref
        if not (ref.is_show or ref.is_episode):
            raise TypeError(f'Item {item.ref} is not show or episode')

        # show must contains all original episodes to avoid miss any episode
        # if the show has no episode groups should have episodes, if not user get_episodes=True.
        refreshed = False
        if ref.is_show and safe:
            details = InfoDetails.new(const.media.info_details)
            details &= InfoDetails.SEASON_MASK | InfoDetails.EPISODE_MASK
            details |= InfoDetails.INFO_LANG | InfoDetails.SHOW_SEASONS | InfoDetails.SEASON_EPISODES
            if it := self.get_item(item, details=details):
                item.children_items = it.children_items
                refreshed = True

        # -- switch to tmdb order (reset episode group) --
        if group is None:
            # reset single episode
            if ref.is_episode:
                item.season = ref.season
                item.episode = ref.episode
            # reset ffitem and all dependencies (show, seasons, episodes), only if not obtained from TMDB already
            elif not refreshed:
                # recover all original episodes
                episodes = list(item.episode_iter(special=True))
                for ep in episodes:
                    ep.season = ep.ref.season
                    ep.episode = ep.ref.episode
                # recover seasons, without details
                sz_label = self.api_labels('Season')  # Kodi global string: "Season"
                item.children_items = []
                for sz_num in sorted({ep.ref.season or 0 for ep in episodes}):
                    sz = FFItem(ref=MediaRef.tvshow(item.ref.ffid, sz_num), type='season', label=f'{sz_label} {sz_num}', mode=FFItem.Mode.Folder)
                    sz.season = sz_num
                    sz.title = sz.label
                    sz.vtag.setEnglishTitle(f'Season {sz_num}')
                    sz.vtag.setTvShowTitle(item.vtag.getTvShowTitle())
                    sz.vtag.setEnglishTvShowTitle(item.vtag.getEnglishTvShowTitle())
                    sz.children_items = [ep for ep in episodes if ep.ref.season == sz_num]
                    if sz.children_items:
                        sz.vtag.setFirstAired(sz.children_items[0].date)
                    item.children_items.append(sz)
            item.episode_group.current = None
            return item

        # -- switch to specific group --

        # group ID (str)
        if isinstance(group, str):
            if item.episode_group.groups is None:
                item.episode_group.groups = self.tmdb.episode_groups(item)
            try:
                # find group ID in show episode groups
                group = next(iter(gr for gr in item.episode_group.groups if gr.tmdb_id == group))
            except StopIteration:
                raise KeyError(group) from None
        # group object (FFEpisodeGroup), safe – get data from TMDB
        else:
            # find group ID in show episode groups, if not, just user `group`
            if item.episode_group.groups is not None:
                group = next(iter(gr for gr in item.episode_group.groups if gr.tmdb_id == group), group)

        # the same group?
        if (current_id := item.episode_group.tmdb_id) and current_id == group.tmdb_id:
            return None

        # the episode group details (mapping children)
        if group.items is None:
            ffgroup = self.tmdb.episode_group(show=item, group=group.tmdb_id)
            if ffgroup is None or ffgroup.items is None:
                raise KeyError(f'No episode group {group.tmdb_id} in item {item.ref}')
            group.items = ffgroup.items
        # mapping for the requested group
        mapping = group.mapping()

        # switch the episode itself only
        if ref.is_episode:
            if eref := mapping.get(ref):
                item.season = eref.season
                item.episode = eref.episode
                item.episode_group.current = group
                return item
            # no mapping, no episode in the episode group
            fflog.info(f'No episode mapping for {ref} in group {group.name!r} ({group.tmdb_id})')
            # item.season = 0
            # item.episode = 0
            # item.episode_group.current = group
            return None

        # switch show and all its children, the show shoud contains episodes
        episodes = {ep.ref: ep for ep in item.episode_iter(special=True)}
        marks = {it.ref: it for it in item.progress.bar} if item.progress is not None else {}
        item.children_items = []
        for gr in group.items:
            # sz = gr.clone()  ###
            sz = FFItem(ref=gr.ref, type='season', mode=FFItem.Mode.Folder)  # a folder: its info tag goes to Kodi
            sz.title = gr.title
            sz.episode_group.current = group  # its ref is the real season of the same number
            item.children_items.append(sz)
            sz.children_items = []
            if gr.children_items is not None:
                if gr.children_items and (date := gr.children_items[0].date):
                    sz.vtag.setFirstAired(date)
                for ep in gr.children_items:
                    ep = episodes.get(ep.ref, ep)
                    if eref := mapping.get(ep.ref):
                        ep.season = eref.season
                        ep.episode = eref.episode
                        ep.episode_group.current = group
                    sz.children_items.append(ep)
            # the progress of the group season from the bar of the show (its aired episodes, real refs), None if no one is watched
            bar: list[MediaProgressItem] = [marks.get(ep.ref) or MediaProgressItem(ep.ref) for ep in sz.children_items if not ep.unaired]
            sz.progress = bar_progress(sz.ref, bar) if any(bar) else None

        item.episode_group.current = group
        return item

    def reset_episode_group(self, item: FFItem) -> FFItem:
        """Reset episode group, set TMDB original season and episode order. Return the item."""
        self.switch_episode_group(item, group=None)
        return item

    def media_images(self, ref: FFRef, *, locale: str | None = None) -> ArtInfo:
        """Generic function to get images for movies, shows, seasons, episodes, collections or persons."""
        if isinstance(ref, FFItem):
            orig_lang = ref.getProperty('original_language') or 'en'
            orig_countries = [country.lower() for country in ref.getProperty('original_countries').split(',') if country]
        else:
            orig_lang = 'en'
            orig_countries = []
        trans_order = self.translation_order(original_language=orig_lang, original_coutries=orig_countries, locale=locale)
        return self.tmdb.media_images(ref, locale=trans_order)

    def retreive_category_data(self, item: FFItem) -> bool:
        """Retreive category data for the item, return True if data was retreived."""
        if item.category == 'anime':
            from ..api.kitsu import get_movie_cours, get_cour_structure, CourInfo, AnimeInfo
            ref = item.ref
            if tmdb := ref.tmdb_id:
                data: CourInfo | None = None
                if ref.type == 'movie':
                    if cours := get_movie_cours(tmdb_id=tmdb):
                        data = cours[0]
                        item.anime_info = AnimeInfo(cours=cours)
                elif ref.type == 'show':
                    if cours := get_cour_structure(tmdb_id=tmdb):
                        data = cours[0]
                        item.anime_info = AnimeInfo(cours=cours)
                if data:
                    item.vtag.setUniqueID(str(data['kitsu_id']), 'kitsu')
                    if val := data.get('mal_id'):
                        item.vtag.setUniqueID(str(val), 'mal')
                    if val := data.get('anilist_id'):
                        item.vtag.setUniqueID(str(val), 'anilist')
                    if val := data.get('title'):
                        item.setProperty('kitsu.title', val)
                    return True
        else:
            # general - do nothing
            return True
        return False


def is_romanized(s: str) -> bool:
    """Check if string is romanized (contains only latin letters, digits, space and some punctuation)."""
    from unicodedata import category
    allowed_categories = {
        'Ll',  # Letter, lowercase
        'Lu',  # Letter, uppercase
        'Nd',  # Number, decimal digit
        'Pd',  # Punctuation, dash
        'Po',  # Punctuation, other
        'Zs',  # Separator, space
    }
    allowed_letters = '+'
    return all(category(c) in allowed_categories or c in allowed_letters for c in s)


#: Global media info provider.
ffinfo = InfoProvider(tmdb=tmdb_provider, trakt=trakt_provider, mdblist=mdblist_provider)


def main(*, parser: ArgumentParser | None = None) -> None:
    from sys import stderr
    from pathlib import Path
    from pprint import pformat
    from textwrap import wrap
    import sty
    # from .tricks import dump_obj_gets
    from .cmdline import DebugArgumentParser, RatingAction, parse_ref
    from ..fake.fake_term import print_table, formatting, text_width, text_left, dim
    from .ratings import all_rating_services

    def parse_any_id(s: str) -> int:
        return VideoIds.guess_id(s).ffid

    def parse_id(v: str) -> tuple[int, ...]:
        ids = tuple(map(int, v.split('/')))
        if ids[0] < VideoIds.TMDB.start:
            return (ids[0] + VideoIds.TMDB.start, *ids[1:])
        return ids

    def parse_request(s: str) -> MediaRequest:
        """Parse request (ref, details, lang) string."""
        vv = s.split(':', 2)
        ref = parse_ref(vv[0])
        try:
            details = InfoDetails.new(vv[1]) if len(vv) > 1 else InfoDetails.NOT_DEFINED
        except KeyError as e:
            fflog.error(f'Unknown InfoDetails flag {e.args[0]!r}')
            raise ValueError(s)
        lang = vv[2] if len(vv) > 2 else ''
        return MediaRequest(ref, details=details, locale=lang)

    def parse_ref_or_request(s: str) -> MediaRef | MediaRequest:
        """Parse pure ref or request (ref, details, lang) string."""
        if ':' in s:
            return parse_request(s)
        return parse_ref(s)

    @overload
    def update_media_request(req: MediaRef, *, details: InfoDetails = InfoDetails.DEFAULT) -> MediaRef: ...

    @overload
    def update_media_request(req: MediaRequest, *, details: InfoDetails = InfoDetails.DEFAULT) -> MediaRequest: ...

    def update_media_request(req: MediaRef | MediaRequest, *, details: InfoDetails = InfoDetails.DEFAULT) -> MediaRef | MediaRequest:
        """Update media request with default details and locale."""
        if isinstance(req, MediaRequest):
            if not req.locale:
                req.locale = getattr(args, 'req_locale', '')
            if req.details == InfoDetails.NOT_DEFINED:
                req.details = getattr(args, 'details', details)
        return req

    def show_info(item: FFItem, *, indent: int = 0, aliases: bool = False, width: int = 199) -> None:
        pre = ' ' * indent
        it = item
        print(f'{pre}{sty.ef.bold}{sty.fg(35)}-- Info --{sty.rs.all}')
        vtag = it.getVideoInfoTag()
        descr = formatting(str(vtag.getPlot() or '')).replace('\n', f'{dim}[CR]{sty.rs.bg}')
        tagline = formatting(str(vtag.getTagLine() or '')).replace('\n', f'{dim}[CR]{sty.rs.bg}')
        if text_width(descr) > width:
            descr = f'{text_left(descr, width)}{dim}…{sty.rs.bg}'
        if aliases:
            ffinfo.get_title_aliases(item)
        progress = f'{it.progress.progress:.2f}%' if it.progress else 'None'
        print_table((
            ('REF:', f'{it.ref:a}'),
            ('Label:', repr(it.getLabel())),
            ('Label2:', repr(it.getLabel2())),
            ('Title:', repr(vtag.getTitle())),
            ('TVShowTitle:', repr(vtag.getTVShowTitle())),
            ('EnglishTitle:', repr(vtag.getEnglishTitle())),
            ('EnglishTVShowTitle:', repr(vtag.getEnglishTvShowTitle())),
            ('OriginalTitle:', repr(vtag.getOriginalTitle())),
            ('Year:', repr(vtag.getYear())),
            ('Duration:', repr(vtag.getDuration())),
            ('IDs:', repr(vtag.getUniqueIDs())),
            ('Art:', pformat(it.getArt())),
            ('Descr:', descr),
            ('Tagline:', tagline),
            ('Progress:', progress),
            ('Aliases:', pformat([f'[{a.country}] {a.title}' for a in item.aliases_info], width=width)),
            ('Keywords:', '\n'.join(wrap(', '.join(sorted(item.keywords)), width=width))),
            ('Episode groups:', '\n'.join(f'- [{g.tmdb_id}] {g.name} ({g.type.name}): groups={g.group_count}, episodes={g.episode_count}' for g in item.episode_group.groups or ())),
            ('Abosulte number:', repr(it.absolute_episode_number())),
        ), indent=indent+1)
        print(f'{pre}{sty.ef.bold}{sty.fg(35)}--{sty.rs.all}')

    def print_full(item: Optional[FFItem], *, level: int = 0, parents: bool = True, recursive: bool = True,
                   ref: Optional[MediaRef] = None, details: bool = False, aliases: bool = False) -> None:
        today = dt_date.today()
        indent = '  ' * level
        if item:
            info = {}
            if ref is None:
                ref = item.ref
            elif ref != item.ref:
                print(f'{indent}{ref:a} =/= {item.ref:a} !!!')
            info[None] = f'{indent}{ref:a}, {item=}, en:{item.vtag.getEnglishTitle()!r}, orig:{item.vtag.getOriginalTitle()!r}'
            if item.date and item.date > today:
                date_str = f'{sty.fg.red}{item.date}{sty.rs.fg}'
            else:
                date_str = f'{item.date}'
            info['date'] = date_str
            # rate = item.vtag.getRating()
            if urate := item.vtag.getUserRating():
                info['user_rating'] = urate
            print(', '.join(f'{k}:{v}' if k is not None else v for k, v in info.items()))
            if details:
                show_info(item, indent=2*level, aliases=aliases)
            if parents:
                if it := item.season_item:
                    print(f'{indent}  - season: {it.ref:a}, {it!r}, en:{it.vtag.getEnglishTitle()!r}')
                if it := item.show_item:
                    print(f'{indent}  - show:   {it.ref:a}, {it!r}, en:{it.vtag.getEnglishTitle()!r}')
            if recursive:
                for ch in item.children_items or ():
                    print_full(ch, level=level + 1, parents=False, aliases=aliases)
        else:
            if ref is None:
                print(f'{indent}-- None')
            else:
                print(f'{indent}{ref:a} -- None')

    def add_args(pp: DebugArgumentParser, *, default_info: bool = False, default_details: InfoDetails | str | None = const.media.info_details) -> None:
        default_details = InfoDetails.new(default_details)
        if default_details is InfoDetails.DEFAULT:
            dd_str = 'DEFAULT'
        elif default_details & InfoDetails.DEFAULT == InfoDetails.DEFAULT:
            dd_str = f'DEFAULT,{default_details & ~InfoDetails.DEFAULT}'
        else:
            dd_str = str(default_details)
        dd_str = dd_str.replace('InfoDetails.', '').replace('|', ',').lower()
        pp.add_argument('-r', '--recursive', action='store_true', help='print children')
        pp.add_argument('-d', '--details', metavar='FLAG[,FLAG]…', type=InfoDetails.new, default=default_details,
                        help=f'set media detail flags (see InfoDetails) [{dd_str}]')
        # pp.add_argument('-c', '--aggregate-credits', action='store_true', help='get aggregate credits')
        pp.add_argument('--req-locale', default='', help='language (e.g. pl-PL) for InfoDetails.INFO_ORIG')
        pp.add_argument('-i', '--info', action='store_true', default=default_info, help='print extra info')
        pp.add_argument('--no-info', dest='info', action='store_false', help='do not print extra info')
        pp.add_argument('-J', '--json', action='store_true', help='print json')

    if parser is None:
        p = DebugArgumentParser(dest='op')
        p.add_argument('-K', '--kodi-path', metavar='PATH', type=Path, help='path to KODI user data')
        p.add_argument('--lang', help='language (default: pl_PL)')
        p.add_argument('--api-lang', help='override override media API language (default from settings)')
    else:
        p = DebugArgumentParser(dest='op', parents=[parser])
    with p.with_subparser('get', help='get (find) media request') as pp:
        pp.add_argument('id', type=parse_ref_or_request, metavar='REF[:DETAILS[:LANG]]', help='media request')
        pp.add_argument('--force-tmdb', action='store_true', help='skip cache and force TMDB')
        add_args(pp, default_info=True, default_details=const.media.info_details)
        # pp.add_argument('--append-seasons', default=[], type=lambda s: [int(v) for v in s.split(',')], help='extra seasons for show')
        pp.add_argument('-p', '--progress', choices=[x.value for x in ffinfo.Progress], default='basic', help='get progress mode [basic]')
        pp.add_argument('-A', '--aliases', action='store_true', help='print aliases')
    with p.with_subparser('find') as pp:
        # pp.add_argument('type', choices=('movie', 'show', 'season', 'episode'))
        # pp.add_argument('id', type=parse_tmdb_id)
        # pp.add_argument('season', type=int, nargs='?')
        # pp.add_argument('episode', type=int, nargs='?')
        pp.add_argument('id', type=parse_ref_or_request, metavar='REF[:DETAILS[:LANG]]', help='media request')
        pp.add_argument('--aggregate-credits', action='store_true', help='get aggregate credits (flag AGGREGATE_CREDITS)')
        add_args(pp, default_info=True)
        pp.add_argument('-p', '--progress', choices=[x.value for x in ffinfo.Progress], default='basic', help='get progress mode [basic]')
        pp.add_argument('-A', '--aliases', action='store_true', help='print aliases')
    with p.with_subparser('list') as pp:
        pp.add_argument('ids', nargs='+', type=parse_ref_or_request, help='list of ids (movie/id, show/id[/season[/episode]]')
        add_args(pp)
    with p.with_subparser('dict') as pp:
        # pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('ids', nargs='+', type=parse_ref_or_request, help='list of media (movie/id, show/id[/season[/episode]]')
        add_args(pp)
    with p.with_subparser('skel') as pp:
        # pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('ids', nargs='+', type=parse_ref, help='list of ids (movie, show[/season[/episode]]')
        pp.add_argument('-r', '--recursive', action='store_true', help='print children')
        pp.add_argument('-p', '--parents', action='store_true', help='print parents (for season or episode)')
        pp.add_argument('-i', '--info', action='store_true', help='print extra info')
        pp.add_argument('-D', '--print-only-date', action='store_true', help='print only ref and date')
        pp.add_argument('-l', '--locale', help='change skeleton language/locale')
        pp.add_argument('-s', '--show', choices=('first', 'last', 'all', 'none'), default='last',
                        help='show seasons options [last]')
        pp.add_argument('-d', '--date', choices=('first', 'last', 'approx', 'none'), default='approx',
                        help='episode date guess [approx]')
    with p.with_subparser('episode_group') as pp:
        pp.add_argument('id', help='episode group TMDB ID')
        pp.add_argument('-i', '--info', action='store_true', help='print extra info')
        pp.add_argument('-r', '--recursive', action='store_true', help='print children')
        pp.add_argument('--mode', choices=('refs', 'items', 'switch'), default='refs', help='mode')
    with p.with_subparser('ratings') as pp:
        pp.add_argument('type', nargs='?', choices=('movie', 'show', 'season', 'episode', 'all'), default='all', help='get rating type')
        pp.add_argument('rating', nargs='*', type=int, action='extend', default=[], help='get rating value(s)')
        pp.add_argument('-s', '--set', action=RatingAction, nargs='+', metavar=('RATING', 'REF'), help='set rating for media ref')
        pp.add_argument('-r', '--remove', type=parse_ref, metavar='REF', nargs='+', help='remove rating for media ref')
        pp.add_argument('-S', '--services', type=lambda v: [s.strip() for s in v.split(',')], default=True, metavar='|'.join(all_rating_services) + '[,...]',
                        help='rating services to use (default: all)')
    with p.with_subparser('ids') as pp:
        pp.add_argument('services', metavar='SERVICE[,SERVICE]...', help='comma separated list of services to get IDs for')
        pp.add_argument('ids', nargs='+', metavar='SERVICE:ID', type=parse_ref, help='list of media refs')

    args = p.parse_args()
    # print(args); raise SystemExit(0)  # DEBUG

    if args.lang or args.api_lang:
        from ..fake.fake_api import set_locale
        set_locale(args.lang, api=args.api_lang)

    if ids := getattr(args, 'ids', None):
        for req in ids:
            update_media_request(req)

    if True:
        from .. import service
        from ..service.fake_client import FakeServiceClient
        from ..service import client
        service.SERVICE = True  # direct access, like in the service
        service_client = client.service_client = FakeServiceClient()  # NOQA: F811

    item: Optional[FFItem]
    if args.op == 'get':
        if args.force_tmdb:
            # x = ffinfo.tmdb.get_media_list_by_ref([MediaRef('show', 84958)])
            x = ffinfo.tmdb.get_media_by_ref(args.id)
            print(json.dumps(x, indent=2))
            y = ffinfo.parse_tmdb_item(x)
            print(('-----------------------------------------------------------------'
                   f' ({len(json.dumps(y.__to_json__()))} B)'), file=stderr)
            print(json.dumps(y.__to_json__(), indent=2), file=stderr)
            media.store([ffinfo.item_to_row(y)])
            # xx = get_media_info([ref])
        else:
            req = update_media_request(args.id)
            item = ffinfo.get_item(req, details=args.details, progress=ffinfo.Progress(args.progress))
            print_full(item, recursive=args.recursive, ref=req.ref, details=args.info, aliases=args.aliases)
            if item and args.json:
                print(json.dumps(item.__to_json__(), indent=2, cls=JsonEncoder))
    elif args.op == 'find':
        # ref = MediaRef(args.type, args.id, args.season, args.episode)
        if args.aggregate_credits:
            args.details |= InfoDetails.AGGREGATE_CREDITS
        ref = update_media_request(args.id)
        item = ffinfo.find_item(ref, details=args.details, progress=ffinfo.Progress(args.progress))
        print_full(item, recursive=args.recursive, ref=ref, details=args.info)
        if item and args.json:
            print(json.dumps(item.__to_json__(), indent=2, cls=JsonEncoder))
    elif args.op == 'list':
        requests: list[MediaRef | MediaRequest] = args.ids
        items = ffinfo.get_items(requests, details=args.details, keep_missing=True)
        for ref, item in zip(requests, items):
            print_full(item, recursive=args.recursive, ref=ref.ref, details=args.info)
        if args.json:
            print(json.dumps([it.__to_json__() for it in items], indent=2))
    elif args.op == 'dict':
        requests: list[MediaRef | MediaRequest] = args.ids
        for ref, item in ffinfo.get_item_dict(requests, details=args.details).items():
            print_full(item, recursive=args.recursive, ref=ref, details=args.info)
    elif args.op == 'skel':
        sz_opts = {
            'none': SkelOptions.NONE,
            'first': SkelOptions.SHOW_FIRST_SEASONS,
            'last': SkelOptions.SHOW_LAST_SEASONS,
            'all': SkelOptions.SHOW_ALL_SEASONS,
        }
        ep_opts = {
            'none': SkelOptions.NONE,
            'first': SkelOptions.SHOW_EPISODE_DATE_FIRST,
            'last': SkelOptions.SHOW_EPISODE_DATE_LAST,
            'approx': SkelOptions.SHOW_EPISODE_DATE_APPROXIMATE,
        }
        opt = sz_opts[args.show] | ep_opts[args.date]
        for ref, item in zip(args.ids, ffinfo.get_en_skel_items(args.ids, locale=args.locale, options=opt)):
            if args.print_only_date:
                def print_date(it: FFItem):
                    print(f'{it.ref:20} : {it.date}')
                    if args.recursive:
                        for it in it.children_items or ():
                            print_date(it)
                print_date(item)
            else:
                print_full(item, recursive=args.recursive, details=args.info, parents=args.parents)
    elif args.op == 'episode_group':
        def parse() -> tuple[MediaRef | None, str | None]:
            ref, sep, gr = args.id.rpartition(':')
            if not sep and ('/' in gr or (gr.isdecimal() and len(gr) < 16)):  # media ref, list all episode groups
                return parse_ref(gr, type='show'), None
            if ref:
                ref = parse_ref(ref, type='show')
            if ref and gr.isdecimal() and len(gr) < 3:
                gr = ffinfo.tmdb.episode_groups(show=ref)[int(gr)].tmdb_id
            else:
                try:
                    if len(gr) < 24:
                        raise ValueError()
                    int(gr, 16)
                except ValueError:
                    if ref and (eg := next(iter(g for g in ffinfo.tmdb.episode_groups(show=ref) if g.name == gr), None)):
                        gr = eg.tmdb_id
            return ref, gr

        if args.mode == 'refs':
            ref, gr = parse()
            if ref and not gr:
                for group in ffinfo.tmdb.episode_groups(show=ref):
                    print(f'- [{group.tmdb_id}] {group.name} ({group.type.name}): groups={group.group_count}, episodes={group.episode_count}')
            elif gr:
                refs = ffinfo.tmdb.episode_group_mapping(show=ref, group=gr)
                for r1, r2 in refs.items():
                    print(f'{r1:a} -> {r2:a}')
        elif args.mode == 'items':
            ref, gr = parse()
            if gr:
                for it in ffinfo.get_episode_group_items(gr, info=True):
                    print_full(it, recursive=args.recursive, ref=it.ref, details=args.info)
        elif args.mode == 'switch':
            ref, gr = parse()
            if ref and gr:
                details = InfoDetails.new(const.media.info_details)
                details |= InfoDetails.SHOW_EPISODE_GROUPS | InfoDetails.SHOW_SEASONS  # | InfoDetails.SEASON_EPISODES
                details |= InfoDetails.SEASON_EN | InfoDetails.EPISODE_EN
                if item := ffinfo.find_item(ref, details=details):
                    print('\n --- \n')
                    print_full(item, recursive=args.recursive, ref=item.ref, details=args.info)
                    # raise SystemExit(0)
                    ffinfo.switch_episode_group(item, group=gr)
                    print('\n --- \n')
                    print_full(item, recursive=args.recursive, ref=item.ref, details=args.info)
                    ffinfo.reset_episode_group(item)
                    print('\n --- \n')
                    print_full(item, recursive=args.recursive, ref=item.ref, details=args.info)
        else:
            print(f'Unknown mode: {args.mode!r}')
    elif args.op == 'ratings':
        def print_it(it: FFItem) -> None:
            info = raw_rating = ''
            if it.season is not None and (title := it.vtag.getTvShowTitle()):
                info = f'   [{title or "–"} ({it.getProperty("show.year")})]'
            for srv in all_rating_services.values():
                if (rs := it.getProperty(f'{srv.name}.user_rating') or it.getProperty('user_rating')):
                    it.vtag.setUserRating(srv.from_service_rating(float(rs)))
                    if '.' in rs:
                        raw_rating = f'[{rs:>4}]'
                    else:
                        raw_rating = f'[{rs:>2}]'
                    # info += f'  {{{rs}}}'
                    break
            print(f' - {it.ref:20a} {it.vtag.getUserRating():>2}  {raw_rating}  {it.title or "–"} ({it.year or ""}){info}')
        from ..api.mdblist import mdblist
        if args.services is True:
            args.services = list(all_rating_services)
        if args.type == 'all':
            args.type = None
        if args.set:
            if 'trakt' in args.services and ffinfo.trakt is not None:
                print(ffinfo.trakt.add_user_ratings(args.set[1:], rating=args.set[0]))
            if 'tmdb' in args.services and ffinfo.tmdb is not None:
                for ref in args.set[1:]:
                    print(ffinfo.tmdb.add_user_rating(ref, rating=args.set[0]))
            if 'mdblist' in args.services:
                print(mdblist.add_user_ratings(args.set[1:], rating=args.set[0]))
        elif args.remove:
            if 'trakt' in args.services and ffinfo.trakt is not None:
                print(ffinfo.trakt.remove_user_ratings(args.remove))
            if 'tmdb' in args.services and ffinfo.tmdb is not None:
                for ref in args.remove:
                    print(ffinfo.tmdb.remove_user_rating(ref))
            if 'mdblist' in args.services:
                print(mdblist.remove_user_ratings(args.remove))
        else:
            if 'trakt' in args.services and ffinfo.trakt is not None:
                print('Trakt ratings')
                for it in ffinfo.trakt.user_ratings(args.type, rating=args.rating):
                    print_it(it)
            if 'tmdb' in args.services and ffinfo.tmdb is not None:
                print('TMDB ratings')
                for it in ffinfo.tmdb.user_ratings(args.type):
                    print_it(it)
            if 'mdblist' in args.services:
                print('MDBList ratings')
                for it in mdblist.user_ratings():
                    print_it(it)
    elif args.op == 'ids':
        items = ffinfo.lookup_ids(args.ids, args.services.split(','))
        for ref, it in items.items():
            print(f'{ref:a} : {it}')
    elif not args.op:
        avaliable = ', '.join(sorted(p._ff_subparsers.choices))
        print(f'No operation specified, avaliable: {avaliable}.\nUse -h for help.')
        return

    print(f'---\n  (( {ffinfo.tmdb._DEBUG_STATS} ))')


if __name__ == '__main__':
    main()
