"""
One-time migration of accounts out of the settings (FanFilm versions before the accounts).

Formerly every account type had its settings account (data in `settings.xml`). After it an account is an entry of
`/accounts` in the user configuration (`config.json`, configuration only) with its data in `accounts.db`; the type
name is only an alias (`lib.ff.accounts`). It runs when the configuration has no `/accounts` yet.

- a settings account with data gets the ID from its user nick (`trakt.<nick>`, `typ.1` without a nick), its data are
  moved to `accounts.db` and its rows in `accounts.db` / `lists.db` / `playback.db` get the new ID;
  without data it is removed (with its rows);
- `imdb.user` (CSV) becomes public IMDb accounts, `{type}.rating` / `mdblist.tracking` the account switches;
- the accounts signed in by their state in `accounts.db` come back (a lost `/accounts`: `config.json` removed or an old
  one restored): their IDs, the type labels (with the ID of one of no nick); what only `/accounts` had (the accounts not signed in, the public
  ones, own labels, switches, the order) is lost;
- `settings.xml` is backed up first, the moved settings are cleared after `/accounts` is written.

It may run again over the data it moved before (a lost `/accounts` with the settings not cleared, `accounts.db` of another
installation): the data the new ID already has is kept (newer: e.g. a refreshed token), the one of the settings dropped.

The caller (`AccountStore._load()`) writes the returned entries; another process migrating at the same time is awaited.
"""

from __future__ import annotations
from typing import Any, Callable, Iterator, TYPE_CHECKING
from typing_extensions import TypeAlias
from pathlib import Path
from time import time, sleep
import json
import os
from .logs import fflog, fflog_exc
if TYPE_CHECKING:
    from .config import ConfigStore

#: Raw account entry of `/accounts` (string: `dict[]` is not subscriptable in py3.8).
Entry: TypeAlias = 'dict[str, Any]'

#: Settings moved to accounts (cleared after the migration), by type.
MOVED_SETTINGS: dict[str, tuple[str, ...]] = {
    'trakt': ('trakt.token', 'trakt.internal', 'trakt.user', 'trakt.last_activity', 'trakt.rating'),
    'tmdb': ('tmdb.username', 'tmdb.password', 'tmdb.sessionid', 'tmdb.access_token', 'tmdb.rating'),
    'imdb': ('imdb.user', 'imdb.at-main', 'imdb.user_agent', 'imdb.rating'),
    'mdblist': ('mdblist.api_key', 'mdblist.rating', 'mdblist.tracking'),
}
#: Old switches (the settings `{type}.{name}`) -> their cells.
OLD_SWITCHES: dict[str, tuple[str, ...]] = {
    'rating': ('ratings.read', 'ratings.write'),
    'tracking': ('progress.read', 'progress.write', 'watched.read', 'watched.write'),
}
#: Lock of the migration between processes: older one is stale (seconds).
LOCK_STALE: float = 120
#: How long to wait for another process migrating (seconds).
LOCK_WAIT: float = 30


def migrate(config: ConfigStore) -> tuple[list[Entry], bool]:
    """
    Return the account entries migrated from the settings and True if migrated here (the caller writes them to
    `/accounts`, then `clear_settings()`). The lock file keeps one process at it; another one waits and returns the
    entries it wrote.
    """
    from .accounts import ACCOUNTS_CONFIG
    path = config.path()
    with MigrationLock(path.with_name(f'{path.name}.accounts.lock')) as owner:
        if not owner or config.get(ACCOUNTS_CONFIG) is not None:  # done by another process
            return config.get(ACCOUNTS_CONFIG) or [], False
        return _migrate(), True


class MigrationLock:
    """Lock file of the migration (atomic create), True if this process owns it, False after another process finished."""

    def __init__(self, path: Path) -> None:
        #: Lock file.
        self.path: Path = path
        #: True if created here.
        self.owner: bool = False

    def __enter__(self) -> bool:
        """Take the lock or wait for its owner (a stale lock is taken over)."""
        deadline = time() + LOCK_WAIT
        while True:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                os.close(os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                self.owner = True
                return True
            except FileExistsError:
                try:
                    if time() - self.path.stat().st_mtime > LOCK_STALE:
                        self.path.unlink()
                        continue
                except OSError:
                    continue  # removed by its owner meanwhile
            if time() > deadline:
                fflog.warning(f'[ACCOUNTS] migration lock {self.path} is held too long')
                return False
            sleep(.2)
            if not self.path.exists():
                return False  # the owner finished

    def __exit__(self, *exc: Any) -> None:
        """Release the own lock."""
        if self.owner:
            try:
                self.path.unlink()
            except OSError:
                pass


def _migrate() -> list[Entry]:
    """Migrate the settings accounts (see the module doc), return the entries (the caller writes them)."""
    from .accounts import SERVICE_TYPES
    from .settings import settings
    fflog('[ACCOUNTS] migration of accounts out of the settings')
    try:
        settings.make_backup()
    except Exception:
        fflog_exc()
    taken: set[str] = set()
    result = [new for typ in SERVICE_TYPES.values() if typ.multi
              and (new := _settings_account({'id': typ.name, 'type': typ.name}, taken)) is not None]
    order = {name: i for i, name in enumerate(SERVICE_TYPES)}
    # stable: a recovered one after the settings one of its type, a public IMDb one after the other IMDb accounts
    return sorted(result + _recovered(taken) + _public_imdb(taken), key=lambda entry: order[entry['type']])


def clear_settings() -> None:
    """Clear and remove the moved settings (after `/accounts` is written)."""
    from .settings import settings
    settings.clear_moved_settings([sid for sids in MOVED_SETTINGS.values() for sid in sids])


def _setting(sid: str) -> str:
    """Return a moved setting (they have no definition: read as a string)."""
    from .settings import settings
    return settings.moved_setting(sid)


def _settings_account(entry: Entry, taken: set[str]) -> Entry | None:
    """Return the account entry of the settings account `entry` with its new ID, None if it has no data (its rows removed)."""
    from .accounts import SERVICE_TYPES, Account, account_client, new_account_id
    from .db.accounts import account_data_store, rename_account_data, remove_account_data
    from .db.lists import rename_scope, remove_scope
    from .db.playback import rename_account_rows, remove_account_rows
    old = entry['id']
    typ = SERVICE_TYPES[old]
    store = account_data_store(old)
    secrets = dict(_settings_secrets(old))
    for key, value in secrets.items():
        store.set(key, value, ttl=None)
    if not secrets:
        fflog(f'[ACCOUNTS] settings account {old!r} has no data, removed')
        remove_account_data(old)
        remove_scope(old)
        remove_account_rows(old)
        return None
    nick = _nick(old, lambda: account_client(Account(id=old, type=typ, label=typ.label)))
    new_id = new_account_id(typ.name, f'{typ.label} {nick}', taken)
    taken.add(new_id)
    rename_account_data(old, new_id)
    rename_scope(old, new_id)
    rename_account_rows(old, new_id)
    new: Entry = {k: v for k, v in entry.items() if k != 'settings'}
    new['id'] = new_id
    _set_switches(new, old, {name: value.lower() == 'true' for name in OLD_SWITCHES if (value := _setting(f'{old}.{name}'))})
    fflog(f'[ACCOUNTS] settings account {old!r} -> {new_id!r}')
    return new


def _settings_secrets(type_name: str) -> Iterator[tuple[str, Any]]:
    """Yield the data of the settings account of the type (`accounts.db` keys and values), nothing if it has none."""
    if type_name == 'trakt':
        if token := _setting('trakt.token'):
            try:
                internal = json.loads(_setting('trakt.internal') or '{}')
            except ValueError:
                internal = {}
            yield 'token', {'access_token': token, 'refresh_token': internal.get('refresh_token', ''), 'expires_at': internal.get('expires_at', 0)}
    elif type_name == 'tmdb':
        session_id, access_token = _setting('tmdb.sessionid'), _setting('tmdb.access_token')
        user, password = _setting('tmdb.username'), _setting('tmdb.password')
        if session_id or access_token:
            yield 'token', {'session_id': session_id or None, 'access_token': access_token or None}
        if user and password:
            yield 'login', {'user': user, 'password': password}
    elif type_name == 'mdblist':
        if key := _setting('mdblist.api_key'):
            yield 'api_key', key
    elif type_name == 'imdb':
        if cookie := _setting('imdb.at-main'):
            yield 'at-main', cookie
            if agent := _setting('imdb.user_agent'):
                yield 'user_agent', agent


def _nick(type_name: str, client: Callable[[], Any]) -> str:
    """Return the user nick of the settings account: the kept profile, the settings, the service (one request), '' if unknown."""
    from .db.accounts import account_data_store
    if nick := (account_data_store(type_name).get('profile') or {}).get('username'):
        return str(nick)
    if type_name == 'trakt':
        return _setting('trakt.user')  # the user slug
    try:
        if profile := client().refresh_profile():
            return str(profile.get('username') or '')
    except Exception:
        fflog_exc(f'[ACCOUNTS] no profile of {type_name!r}')
    if type_name == 'tmdb':
        return _setting('tmdb.username')
    return ''


def _set_switches(entry: Entry, type_name: str, old: dict[str, bool]) -> None:
    """Set the switches of cells of the entry from the old switches (only the cells the type has, not its defaults)."""
    from .accounts import SERVICE_TYPES
    typ = SERVICE_TYPES[type_name]
    switches = dict(entry.get('switches') or {})
    for name, value in old.items():
        for cell in OLD_SWITCHES[name]:
            capability, _, direction = cell.partition('.')
            if direction in typ.capabilities.get(capability, ()) and value != typ.switches.get(cell, True):  # type: ignore[arg-type]
                switches[cell] = value
    if switches:
        entry['switches'] = switches


def _recovered(taken: set[str]) -> list[Entry]:
    """
    Return the entries of the accounts signed in by their state in `accounts.db` not taken yet (their namespaces: the IDs
    of the accounts of the types with users; the type aliases, the internal stores skipped), by their IDs.
    """
    from .accounts import ACCOUNT_ID_RX, SERVICE_TYPES, Account, account_client
    from .account_admin import account_nick
    from .db.accounts import account_data_namespaces
    result: list[Entry] = []
    for aid in sorted(account_data_namespaces() - taken):
        type_name, _, slug = aid.partition('.')
        typ = SERVICE_TYPES.get(type_name)
        if typ is None or not typ.multi or not typ.capabilities or not slug or not ACCOUNT_ID_RX.fullmatch(aid):
            continue
        account = Account(id=aid, type=typ, label=typ.label)
        if (client := account_client(account)) is None or not client.credentials():
            continue
        taken.add(aid)
        entry: Entry = {'id': aid, 'type': typ.name}
        if not account_nick(account):  # a known nick: the type label (the views add the nick, as to a migrated settings account)
            entry['label'] = f'{typ.label} {slug}'
        result.append(entry)
        fflog(f'[ACCOUNTS] account {aid!r} recovered from accounts.db')
    return result


def _public_imdb(taken: set[str]) -> list[Entry]:
    """Return public IMDb accounts of the users of `imdb.user` (CSV) not taken yet."""
    result: list[Entry] = []
    for name in _setting('imdb.user').split(','):
        if (user := name.strip().lower()):
            user = f'ur{user}' if user.isdecimal() else user
            if (aid := f'imdb.{user}') not in taken:
                taken.add(aid)
                result.append({'id': aid, 'type': 'imdb', 'label': f'IMDb {user}', 'user': user})
    return result
