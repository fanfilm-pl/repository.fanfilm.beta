"""
List cache policy (the "smart" side of ``lists.db``).

User lists of accounts are cached whole (up to ``const.lists.cache.limit`` items) as raw items of the service, so the
service parser makes the same FFItems of them as of a fresh response, and a Kodi page is cut locally.
General lists of a type (TMDB discover, Trakt trending, search, ...; the scope is the type name) are cached by the
page of the service (a page is an entry, pages over ``const.lists.cache.page_limit`` are not stored), small or
composed ones whole; their TTL is of their kind (``const.lists.cache.general``).

* **One read path** -- :func:`cached_list`: a fresh list is read from the DB; a missing, expired or stale one is
  fetched and stored; when the service fails, the last stored list is used (also an expired one).
* **Freshness is derived at read time, not configured per type** -- a general list lives the TTL of its kind; a list the account sync watches (its bucket is
  synced and the sync is alive: its last check of changes is newer than two current sync intervals) has no deadline, the sync
  marks it stale on a change -- if the cursor of its bucket is a time of the service; a fingerprint cursor (the count and
  the newest item of a service without activities) misses rare changes, so its list is fetched after
  ``const.lists.cache.fingerprint_ttl`` anyway; other lists (also when the sync stops) live `ttl` from their fetch. A zero TTL
  (``listCache`` off) means no cache at all.
* **External IDs** -- a fetched list with refs outside TMDB (e.g. IMDb) is mapped to TMDB whole at once (the ID
  map of ``media.db``), so its pages need no ID lookup.
* **Changes** -- an own change (add / remove / rate / new list) and the account sync only mark lists stale
  (:func:`mark_stale`, the list and its sub-lists by the hierarchical name); the next read fetches.

The policy is kept in this light module (like ``db.freshness``), the service API modules call it.
"""

from __future__ import annotations
from time import time
from typing import Any, Callable, Iterable, Mapping, Sequence, TYPE_CHECKING, cast
from attrs import frozen, field
from .db import lists as lists_db
from .db.lists import ListRow, StoredList
from .logs import fflog, fflog_exc
from const import const
if TYPE_CHECKING:
    from .types import JsonData
    from ..defs import MediaRef
    from .sync import SyncBucket


@frozen
class FetchedList:
    """A list fetched from the service: items (reference, raw item) in order."""

    #: Items: the media reference (None if unknown) and the raw item of the service.
    items: Sequence[tuple[MediaRef | None, JsonData]]
    #: Number of items of the whole list, if the service gives it (default: the number of items).
    total: int | None = None
    #: List meta data of the service (e.g. its sort).
    meta: Mapping[str, Any] = field(factory=dict)


def list_params(**params: Any) -> str:
    """Return the normalized query parameters (sorted, None skipped) - a part of the list key."""
    return '&'.join(f'{key}={value}' for key, value in sorted(params.items()) if value is not None)


def _seconds(expr: str | int) -> int:
    """Evaluate a TTL value to int seconds; a string is a settings expression (e.g. ``'HOUR if {listCache} else 0'``)."""
    if isinstance(expr, str):
        from .settings import settings
        return int(settings.eval(expr))
    return int(expr)


def synced(account_id: str, bucket: str | None = None) -> bool:
    """
    Return True if the account sync watches the bucket (any bucket if not given) and the sync is alive: changes mark
    the list stale, so it has no deadline. The sync is alive when its last check of changes is newer than two current
    intervals (`sync_interval()`: longer while Kodi is idle).
    """
    from .accounts import get_account
    from .sync import sync_client, sync_alive
    account = get_account(account_id)
    if account is None or (client := sync_client(account)) is None:
        return False
    return (bucket is None or bucket in client.SYNC_BUCKETS) and sync_alive(account, client)


def _sync_fresh(row: ListRow, account_id: str, bucket: str | None) -> bool:
    """
    Return True if a list the alive sync watches is fresh by its bucket cursor: a time of the service (or no bucket / no
    cursor yet) - always, a fingerprint - younger than `const.lists.cache.fingerprint_ttl`.
    """
    from .sync import bucket_cursor, cursor_time
    if not bucket or (cursor := bucket_cursor(account_id, cast('SyncBucket', bucket))) is None or cursor_time(cursor) is not None:
        return True
    return row.fetched_at > time() - const.lists.cache.fingerprint_ttl


def list_ttl(account_id: str, bucket: str | None = None) -> int:
    """Return the TTL of a list of the account from its fetch (0: no cache), used when the sync does not watch it."""
    return max(0, _seconds(const.lists.cache.ttl))


def general_ttl(kind: str) -> int:
    """Return the TTL of a general list of the kind (`const.lists.cache.general`, 0: no cache)."""
    return max(0, _seconds(const.lists.cache.general[kind]))


def _fetched(fetched: FetchedList, refs: Iterable[MediaRef] | None) -> StoredList:
    """Return the fetched list as a (not stored) list, only the items of `refs` if given."""
    items = fetched.items
    if refs is not None:
        xrefs = {ref.xref for ref in refs}
        items = [(ref, data) for ref, data in items if ref is not None and ref.xref in xrefs]
    total = len(fetched.items) if fetched.total is None else fetched.total
    return StoredList(row=ListRow(total=total, meta_json=lists_db.dump(fetched.meta)), items=[data for _, data in items])


def cached_list(scope: str,
                name: str,
                fetch: Callable[[], FetchedList | None],
                *,
                params: str = '',
                bucket: str | None = None,
                kind: str | None = None,
                page: int | None = None,
                refs: Iterable[MediaRef] | None = None,
                ) -> StoredList | None:
    """
    Return the list `name` of the account `scope`: from the cache or fetched (None: the service failed, nothing stored).

    `params` is the normalized query (`list_params()`), `bucket` the sync bucket of the list (derives the TTL; None - any
    bucket of the account, '' - none: e.g. a public list of another user),
    `kind` makes it a general list of the type `scope` (its TTL in `const.lists.cache.general`, no sync),
    `page` the page of the service as an entry (a page over `const.lists.cache.page_limit` is not stored),
    `refs` returns only the items of these references (e.g. ratings of a folder).
    """
    if refs is not None:
        refs = tuple(refs)
    if page is not None:
        params = f'{params}&page={page}' if params else f'page={page}'
    ttl = general_ttl(kind) if kind else list_ttl(scope, bucket)
    if page and page > const.lists.cache.page_limit:
        ttl = 0
    stored = lists_db.load(scope, name, params, refs=refs) if ttl else None
    if stored is not None and (stored.fresh() or (not kind and not stored.row.stale and synced(scope, bucket) and _sync_fresh(stored.row, scope, bucket))):
        return stored
    try:
        fetched = fetch()
    except Exception:
        fflog_exc()
        fetched = None
    if fetched is None:
        if stored is not None:
            fflog(f'[LISTS] {scope}: {name} {params}: the service failed, the stored list is used')
        return stored
    if ttl:
        limit = const.lists.cache.limit
        total = len(fetched.items) if fetched.total is None else fetched.total
        lists_db.store(scope, name, params, fetched.items[:limit], ttl=ttl, total=total, complete=len(fetched.items) <= limit,
                       meta=fetched.meta)
    _map_ids(fetched)
    return _fetched(fetched, refs)


def _map_ids(fetched: FetchedList) -> None:
    """Map external refs of the whole list to TMDB at once (MDBList bulk by 200), pages read the ID map later."""
    if external := [ref for ref, _ in fetched.items if ref is not None and not ref.tmdb_id]:
        from .info import ffinfo
        try:
            ffinfo.lookup_refs(external)
        except Exception:
            fflog_exc()


def mark_stale(scope: str, name: str | None = None) -> None:
    """Mark the lists of the account (all, or `name` with its sub-lists) as changed: the next read fetches them."""
    count = lists_db.mark_stale(scope, name)
    fflog(f'[LISTS] {scope}: {name or "*"} stale ({count})')


def remove_scope(scope: str) -> None:
    """Remove the lists of the account (e.g. its user changed)."""
    lists_db.remove_scope(scope)


def cleanup() -> int:
    """
    Remove lists of removed accounts and lists expired long ago, except lists of accounts with an alive sync (they have
    no deadline). An account scope is `type.<slug>`; other scopes (types, `tv`) are general lists, they stay till they
    expire. Run by the service. Return the count.
    """
    from .accounts import account_store
    ids = [acc.id for acc in account_store.accounts()]  # also the hidden ones (a type switched off): not removed
    return (lists_db.remove_other_scopes([*ids, *(scope for scope in lists_db.scopes() if '.' not in scope)])
            + lists_db.cleanup(grace=const.lists.cache.cleanup_grace, keep_scopes=[aid for aid in ids if synced(aid)]))
