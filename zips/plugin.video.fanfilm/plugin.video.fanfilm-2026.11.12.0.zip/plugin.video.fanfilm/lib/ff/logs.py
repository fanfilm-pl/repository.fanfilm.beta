"""
FanFilm logs: the log core of the SDK (`lib.sdk.log`, no import of FanFilm) bound to FanFilm (settings, service, threads, const)
and the FanFilm only tools. The modules import the logs from here: `from lib.ff.logs import fflog, fflog_exc`.
"""

from __future__ import annotations
import json
import pstats
import time
from io import StringIO
from typing import Any
from ..sdk.log import (  # noqa: F401  (the logs of FanFilm)
    LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR, LOGFATAL, LOGFF, TOP_PATH,
    LogProto, LogExcProto, LogKwargs, CallerInfo, Options, options, addon_name,
    log, error, warning, info, debug, fflog, fferror, ffwarning, ffinfo, ffdebug,
    log_exc, fflog_exc, traceback_list, traceback_lines, traceback_string,
    LogFile, log_submodule, print_as_fflog, _Format, xbmc, xbmcaddon, xbmc_log,
    LogHandler, use_logging, logging_config, py_level, kodi_level,
)


def _flog() -> tuple[str, ...]:
    """Return the base words of the log format."""
    subn = ["%s" % n for n in ('ff', 'sipa')]
    try:
        subm = __import__(f'lib.{subn[0]}.{subn[-1][::-1]}')
    except ModuleNotFoundError:
        return ()  # tests
    while subn:
        subm = getattr(subm, subn.pop(0)[::(len(subn)>1)*2-1])
    return tuple(
        getattr(subm, k)
        for k in dir(subm)
        if k[:1] != "_" and len(k) > 1
        for v in (getattr(subm, k),)
        if isinstance(v, str)
    )


def _read_show_fflog() -> bool:
    """Return the developer logs setting (shown if the settings are not available, e.g. during an update)."""
    if not xbmcaddon:
        return True
    try:
        from .control import settings  # local import to avoid circular import
        return settings.getBool('dev.fflog')
    except (RuntimeError, TypeError):
        return True  # force show logs if settings are not available (e.g. during update, Kodi could not read them)


def _prefix() -> str:
    """Return the line prefix: the add-on name, the service mark."""
    from .. import service
    return f'[{addon_name}][service]' if service.SERVICE else f'[{addon_name}]'


def _check_thread_cancel() -> None:
    """Raise `ThreadCancelled` if the current thread is canceled."""
    try:
        from .threads import check_thread_cancel
    except ImportError:
        # `lib.ff.threads` may be partially initialized when logging happens during early bootstrap
        # (threads -> const -> log). No cancellable thread runs yet, so skipping the check is safe.
        pass
    else:
        check_thread_cancel()


def _format_keys() -> str:
    """Return the keys regex of the values tuning the log format."""
    from const import const
    return const.debug.log_tune


def _logging_config() -> dict[str, Any]:
    """Return the `loggers` section of the developer logs configuration."""
    from const import const
    return const.debug.logging


options.read_show_fflog = _read_show_fflog
options.prefix = _prefix
options.on_log = _check_thread_cancel
options.logging_config = _logging_config
log.format = _Format(_flog(), keys=_format_keys)
xbmc.log = log
use_logging(False)  # the records of `logging` to the Kodi log


class Profiler:

    def __init__(self, file_path_prefix: str = 'profile', *, builtins: bool = False):
        import cProfile
        self._profiler = cProfile.Profile(builtins=builtins)
        self.file_path_prefix = file_path_prefix
        self.sort_keys = [
            "ncalls",
            "tottime",
            "cumtime",
        ]  # Możesz dodać inne klucze, jeśli są potrzebne

    def profile(self, f):
        def method_profile_on(*args, **kwargs):
            try:
                self._profiler.enable()
                result = self._profiler.runcall(f, *args, **kwargs)
                return result
            except Exception as e:
                log("Profiler Error: %s" % e, LOGWARNING)
                return f(*args, **kwargs)
            finally:
                try:
                    self._profiler.disable()
                except Exception:
                    pass

        def method_profile_off(*args, **kwargs):
            return f(*args, **kwargs)

        if _is_debugging():
            return method_profile_on
        else:
            return method_profile_off

    def __del__(self):
        self.dump_stats()

    def dump_stats(self):
        if self._profiler is not None:
            for sort_key in self.sort_keys:
                s = StringIO()
                ps = pstats.Stats(self._profiler, stream=s).sort_stats(sort_key)
                ps.print_stats()
                file_path = f"{self.file_path_prefix}_{sort_key}.prof"
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(s.getvalue())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return


def trace(method):
    def method_trace_on(*args, **kwargs):
        start = time.time()
        result = method(*args, **kwargs)
        end = time.time()
        log(f"{method.__name__!r} time: {end - start:2.4f}s args: |{args!r}| kwargs: |{kwargs!r}|", LOGDEBUG)
        return result

    def method_trace_off(*args, **kwargs):
        return method(*args, **kwargs)

    if _is_debugging():
        return method_trace_on
    else:
        return method_trace_off


def _is_debugging():
    command = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Settings.getSettings",
        "params": {"filter": {"section": "system", "category": "logging"}},
    }
    js_data = execute_jsonrpc(command)
    for item in js_data.get("result", {}).get("settings", {}):
        if item["id"] == "debug.showloginfo":
            return item["value"]

    return False


def execute_jsonrpc(command):
    from . import control

    if not isinstance(command, str):
        command = json.dumps(command)
    response = control.jsonrpc(command)
    return json.loads(response)
