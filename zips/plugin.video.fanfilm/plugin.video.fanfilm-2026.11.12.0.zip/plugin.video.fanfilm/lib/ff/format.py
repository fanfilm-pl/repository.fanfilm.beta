r"""
Safe string formatter: expressions in fields, `!!default`, missing fields and Kodi-like `[...]` sections.

Ported from transys (`transys/tools/format.py`, the formatter part only).
"""

from __future__ import annotations
from typing import Mapping, TypeVar, TYPE_CHECKING
from typing_extensions import Literal, Protocol, TypeAlias
import re
import string
from inspect import isclass
from functools import wraps
import threading
from enum import Enum
from attrs import frozen
try:
    from simpleeval import (EvalWithCompoundTypes, SimpleEval, simple_eval,
                            DEFAULT_FUNCTIONS as eval_default_functions)
except ModuleNotFoundError:
    if TYPE_CHECKING:
        raise
    simple_eval = None
    eval_default_functions = {}
    SimpleEval = TypeVar('SimpleEval', bound='type')
if TYPE_CHECKING:
    from typing import Any, Sequence, Iterator, Iterable, Callable


class EvaluatorClass(Protocol):
    """Anything that evaluates an expression, `simpleeval.SimpleEval` and its kin."""


#: RegEx for UUID
re_uuid = re.compile(r'[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}')

#: Python-line quote in a format string.
re_quote = re.compile(r'''(?:"""(?:\\.|.)*?""")|(?:"(?:\\.|.)*?")'''
                      r"""|(?:'''(?:\\.|.)*?''')|(?:'(?:\\.|.)*?')""")


def fparser(s: str) -> Iterator[tuple[str, str | None, str | None, str | None]]:
    """
    Like _string.formatter_parser() returns (literal_text, field_name, format_spec, conversion).
    Supports "{}" inside field_name, can work with simple_eval.
    That is what lets a formatter take a whole expression, an f-string inside a join inside a
    comprehension, as a single field:
    ('out: {", ".join(f"({x})" for x in hosts)}', hosts=("a", "bb", "ccc")) -> 'out: (a), (bb), (ccc)'
    """
    i, lvl = 0, 0
    # literal_text, field_name, format_spec, conversion
    oi, vec = 0, ['', None, None, None]
    while i < len(s):
        c = s[i]
        nc = s[i+1:i+2]
        if lvl == 0 and c in '{}' and c == nc:
            # "{{" and "}}" are escapes in the literal text only, never inside a replacement field
            vec[oi] += c
            i += 1
        elif c == '{':
            if lvl == 0:
                oi = 1
                vec[1] = vec[2] = ''
            else:
                vec[oi] += c
            lvl += 1
        elif c == '}':
            lvl -= 1
            if lvl < 0:
                raise ValueError("Single '}' encountered in format string")
            if lvl == 0:
                yield tuple(vec)
                oi, vec = 0, ['', None, None, None]
            else:
                vec[oi] += c
        elif lvl == 1 and c == '!' and oi == 1 and nc != '=':
            # "!" starts a conversion, but "!=" is the only operator with it, so it stays in the field
            oi = 3
            vec[oi] = ''
        elif lvl == 1 and c == ':' and oi in (1, 3):
            oi = 2
            vec[oi] = ''
        else:
            if lvl > 0:
                rx = re_quote.match(s, i) if c in ('"', "'") else None
                if rx:
                    a, b = rx.span()
                    vec[oi] += s[a:b]
                    i += b - a - 1
                elif c in '[(':
                    # a ":" or "!" inside brackets (`(x := 1)`, `d[1:2]`, `lambda a: a`) is not a spec or conversion
                    lvl += 1
                    vec[oi] += c
                elif c in '])':
                    lvl -= 1
                    vec[oi] += c
                else:
                    vec[oi] += c
            else:
                vec[oi] += c
        i += 1
    if lvl:
        raise ValueError("Single '{' encountered in format string")
    if vec[0] or vec[1] is not None:
        yield tuple(vec)


#: Section marks and their escapes in a literal text, `[...]` style.
re_section = re.compile(r'\\[\[\]]|[\[\]]')

#: Section marks and their escapes in a literal text, `\[...\]` style.
re_escaped_section = re.compile(r'\\\\|\\[\[\]]|[\[\]]')


class Sections(Enum):
    r"""How a `[...]` section is written in a format string."""

    #: There are no sections, a bracket is a plain text.
    NONE = 'none'
    #: "[" opens a section, "\[" is a plain bracket. The Kodi LabelFormatter style.
    PLAIN = 'plain'
    #: "\[" opens a section, "[" is a plain bracket, "\\" is a plain backslash. Safe for any text.
    ESCAPED = 'escaped'

    def __bool__(self) -> bool:
        """False for NONE only, so the mode reads as a plain flag."""
        return self is not Sections.NONE

    @classmethod
    def make(cls, value: Sections | bool | str) -> Sections:
        """Take the mode itself, its name, or a bool where True is the `[...]` style."""
        if isinstance(value, cls):
            return value
        if isinstance(value, bool):
            return cls.PLAIN if value else cls.NONE
        return cls(value)


#: Any node of the parsed format string.
FormatNode: TypeAlias = 'FormatLiteral | FormatField | FormatSection'
#: Sequence of format nodes, the content of the format string or of a single section.
FormatNodes: TypeAlias = 'list[FormatNode]'
#: Rendered node: the text and True if it is filled (has a non-empty value).
FormatResult: TypeAlias = 'tuple[str, bool]'
#: Piece of a literal text: True and the section mark itself, or False and a plain text.
SectionToken: TypeAlias = 'tuple[bool, str]'


class MissingField(str):
    """
    Value of a field that could not be resolved. Formats as the plain `{name}` it was made of.
    It is false, so `{a or b}` and `{x if a else y}` work even for a name that does not exist at all.
    """

    def __bool__(self) -> bool:
        """A missing field is always false, whatever its text is."""
        return False


@frozen
class FormatLiteral:
    """Static text of the format string."""

    #: The text itself, already unescaped.
    text: str


@frozen
class FormatField:
    """Replacement field `{name!conversion:spec}` of the format string."""

    #: Field name (or expression if evaluated), auto-numbered if empty.
    name: str
    #: Format spec, could contain nested replacement fields.
    spec: str
    #: Conversion letter (`s`, `r`, `a`, `e`) or None.
    conversion: str | None


@frozen
class FormatSection:
    """Optional `[...]` section, skipped if none of its fields is filled."""

    #: Content of the section.
    children: FormatNodes


class FormatState:
    """Mutable state shared by all nodes rendered from a single format string."""

    __slots__ = ('args', 'kwargs', 'used_args', 'auto_index', 'depth')

    def __init__(self, args: Sequence[Any], kwargs: Mapping[str, Any]) -> None:
        """Prepare state for the given format arguments."""
        #: Positional arguments.
        self.args: Sequence[Any] = args
        #: Keyword arguments.
        self.kwargs: Mapping[str, Any] = kwargs
        #: Keys of all arguments used so far, for `check_unused_args()`.
        self.used_args: set[Any] = set()
        #: Next index for auto-numbered `{}` fields, False if manual numbering is already in use.
        self.auto_index: int | bool = 0
        #: Current format spec recursion depth.
        self.depth: int = 0


def split_sections(text: str, mode: Sections = Sections.PLAIN) -> Iterator[SectionToken]:
    r"""
    Split a literal text into section marks and plain chunks, `mode` says how a mark is written.
    Yields `(True, "[")` or `(True, "]")` for a mark and `(False, text)` for anything else,
    with the escapes of the mode already resolved.
    """
    escaped = mode is Sections.ESCAPED
    # every mark of the escaped style starts with a backslash, of the plain style with a bracket
    if ('\\' not in text) if escaped else ('[' not in text and ']' not in text):
        if text:
            yield False, text
        return
    pos, chunk = 0, []
    for mch in (re_escaped_section if escaped else re_section).finditer(text):
        a, b = mch.span()
        mark = mch.group()
        chunk.append(text[pos:a])
        pos = b
        if mark == '\\\\' or (mark[:1] == '\\') is not escaped:
            chunk.append(mark[-1])
        else:
            joined = ''.join(chunk)
            if joined:
                yield False, joined
            chunk = []
            yield True, mark[-1]
    chunk.append(text[pos:])
    joined = ''.join(chunk)
    if joined:
        yield False, joined


class EvaluatorNames(dict):
    """Evaluator names, where an unknown name is a `MissingField` instead of an error."""

    def __init__(self, names: Mapping[str, Any], functions: Mapping[str, Callable]) -> None:
        """Keep the function table, a function is a value of its own once no name shadows it."""
        super().__init__(names)
        #: Evaluator functions, reachable as names too, ex. `{max(v, key=len)}`.
        self.functions: Mapping[str, Callable] = functions

    def __missing__(self, key: str) -> Any:
        """A name is a function if there is one, otherwise it is a missing field."""
        function = self.functions.get(key)
        if function is None:
            return MissingField('{%s}' % key)
        return function


def join_values(sep: str, *values: Any) -> str:
    """
    Join `values` with `sep`, skipping the empty ones. Available in an expression as `join()`.
    A value is empty when it is None, is a missing field or its text is empty, exactly as in a `[...]`
    section, so `0` and `False` are joined. A single iterable argument is joined item by item:
    join(", ", hosts) == join(", ", *hosts).
    """
    if len(values) == 1 and not isinstance(values[0], str) and hasattr(values[0], '__iter__'):
        values = tuple(values[0])
    texts = ('' if value is None or isinstance(value, MissingField) else str(value) for value in values)
    return sep.join(text for text in texts if text)


def defined(*values: Any) -> bool:
    """
    True when every value exists, that is none of them is a missing field. In an expression as `defined()`.
    Asks the same question as `!!default`, while `or` and `if` ask whether the value is true:
    ("{a if defined(a) else b}", a="", b="B") -> ""    while   ("{a or b}", a="", b="B") -> "B"
    """
    return all(not isinstance(value, MissingField) for value in values)


def missing_aware(func: Callable) -> Callable:
    """
    Wrap a function so that a missing field among its arguments becomes the result.
    The whole expression is then unresolved, instead of the function taking the plain "{name}" text
    for a value of its own: `{len(v)}` with no `v` gives "{len(v)}", not the length of "{v}".
    """
    @wraps(func)
    def call(*args: Any, **kwargs: Any) -> Any:
        """Return the first missing argument, or the result of the wrapped function."""
        for value in args:
            if isinstance(value, MissingField):
                return value
        for value in kwargs.values():
            if isinstance(value, MissingField):
                return value
        return func(*args, **kwargs)

    return call


#: Functions added to the evaluator of every SafeFormatter, on top of the `functions` argument.
#: A missing field passed to one of them makes the whole expression unresolved, except in `bool()`,
#: `defined()` and `join()`, which are the ones that ask about a missing field on purpose.
format_functions: dict[str, Callable] = {
    'join': join_values,
    'defined': defined,
    'bool': bool,
    'len': missing_aware(len),
    'min': missing_aware(min),
    'max': missing_aware(max),
}


class SafeFormatter(string.Formatter):
    r"""
    Safe string formatter.

    Leave unknown arguments, or use default value or evaluate expr:
    ("{a:!!def} {999}") -> "def {999}"
    ("{a + 2}", a=42)   -> "44"

    A missing field is false, so the evaluator writes both a fallback and a condition, and neither of
    them needs the name to exist at all:
    ("{a or b}", b="B")             -> "B"
    ("{'(HD)' if hd else ''}")      -> ""
    ("{join(', ', a, b)}", a="x")   -> "x"

    There are two different questions, as in the shell "${a-b}" and "${a:-b}". `!!default`, `!!{b}` and
    `defined()` ask whether the *name* exists, `or` and `if` ask whether the value is true. They part
    ways on a value that exists but is false:
                                       no "a"   a=""   a=0    a=None   a="A"
    ("{a:!!{b}}", b="B")            ->   "B"     ""    "0"    "None"    "A"
    ("{a if defined(a) else b}")    ->   "B"     ""    "0"    "None"    "A"
    ("{a or b}",  b="B")            ->   "B"    "B"    "B"      "B"     "A"
    Take `or` when a false value should fall through anyway: it chains freely, while `!!` nests inside
    the format spec and is capped by `max_spec_depth`.

    A missing field given to `len()`, `min()` or `max()` makes the whole expression unresolved, so it is
    never taken for its own "{name}" text. `bool()`, `defined()` and `join()` are the ones that ask about
    a missing field on purpose, and answer instead.

    A section drops an empty text, a None and a missing field, but `False`, `0` and `[]` are values and
    do show. A condition that must print nothing has to say so, either with a `None` a section drops, or
    for a constant text with the multiplication idiom:
    ("[x{'(HD)' if hd else None}]", hd=0)  -> ""
    ("[x{bool(hd) * '(HD)'}]",      hd=0)  -> ""
    An "and" alone is not enough, `{hd and '(HD)'}` prints "0" for hd=0.

    A "!=" in an expression needs `extended=True`, the stdlib parser reads its "!" as a conversion.

    A section is dropped unless at least one of its fields is filled, like the square brackets of Kodi
    LabelFormatter:
    ("[{n}. ][{t} - {a}][ ({y})]", n=10, t="40", a="U2", y=1983) -> "10. 40 - U2 (1983)"
    ("[{n}. ][{t} - {a}][ ({y})]", n=10, a="U2", y=1983)         -> "10. U2 (1983)"

    `sections` says how a section is written, and the examples here are in the `Sections.PLAIN` style:
    `Sections.ESCAPED` (the default) takes `\[` and `\]` for the marks and leaves a bare bracket alone,
    which is what makes it safe for a text full of brackets; it asks for `\\` to write a plain backslash.
    `Sections.PLAIN` (also `sections=True`) is the other way round, and `Sections.NONE` (also
    `sections=False`) has no sections at all.

    A field is filled if its value is not None, is not missing and does not format to an empty string.
    Text outside of any section is always kept.

    Inside a section a static text is the prefix of the field just after it (the trailing one is the
    suffix of the last field). It shows only together with that field, and never as the first thing in
    the section, so a separator can not open nor close it:
    ("[{a},{b},{c}]", a=1, c=3) -> "1,3"

    A nested section is subordinate: it is dropped when its own section has plain fields and none of them
    is filled. This is how one part is made to depend on another:
    ("[[{user}@]{host}[:{port}]]", user="u", port=80) -> ""
    A section built of nested sections only is a plain group, its parts do not depend on each other:
    ("[[{a}],[{b}],[{c}]]", a=1, c=3) -> "1,3"
    So a part is freed from the section it sits in by wrapping the plain field into a section of its own:
    ("[[{a}][-{b}]]", a=1) -> "1"   while   ("[{a}-[{b}]]", b=2) -> ""

    Paired characters must sit in one section with their own field and nothing else, so write
    `[[({a})] [{b}]]` and not `[({a}) {b}]`, where a missing "b" leaves the "(" of "a" unclosed.
    """

    _escape_trans = {
        '\\': '\\\\',
        '\'': '\\\'',
        '\"': '\\\"',
        '\a': '\\a',
        '\b': '\\b',
        '\f': '\\f',
        '\n': '\\n',
        '\r': '\\r',
        '\t': '\\t',
        '\v': '\\v',
        '\000': '\\000',
    }

    #: How deep replacement fields could be nested in a format spec (like in `string.Formatter`).
    #: Used with `sections` only, the stdlib formatter keeps its own limit of the same value.
    max_spec_depth: int = 2

    #: How many parsed format strings are kept. The whole cache is dropped when it is full,
    #: which is cheap and enough for the usual case of a handful of masks used over and over.
    max_cache: int = 100

    def __init__(self, *,
                 evaluate: bool | type[EvaluatorClass] | Literal['simple'] = True,
                 escape: bool = True,
                 extended: bool = False,
                 informal_keys: bool = False,
                 #: How `[...]` sections are written, see `Sections` and the class doc.
                 sections: Sections | bool | str = Sections.ESCAPED,
                 #: Let `!!default` fire for a plain value that merely looks like an unresolved `{name}`.
                 unresolved_default: bool = False,
                 names: dict[str, Any] | None = None,
                 functions: dict[str, Callable] | None = None,
                 ) -> None:
        """Set up the parser, the evaluator and the section style, all of them are attributes too."""
        super().__init__()
        #: Evaluator of the format call running in this thread, see the `evaluator` property.
        self._evaluator_local = threading.local()
        #: Evaluator class.
        self.evaluator_class: EvaluatorClass | None = None
        if isclass(evaluate):
            self.evaluator_class = evaluate
        elif simple_eval and evaluate:
            if evaluate == 'simple':
                self.evaluator_class = SimpleEval
            else:
                self.evaluator_class = EvalWithCompoundTypes
        #: Evaluator built-in names (kwargs). If no evaluator `names` are merged with `kwargs`.
        self.evaluator_names: dict[str, Any] | None = names
        #: Evaluator built-in functions. The simpleeval defaults and `format_functions` are always
        #: there, `functions` adds to them and can shadow them by name.
        self.evaluator_functions: dict[str, Callable] = {
            **eval_default_functions, **format_functions, **(functions or {})}
        #: Enable escape conversion `!e`.
        self.escape: bool = escape
        #: Extended (and slower) format parser (allows use advanced expressions).
        self.extended: bool = extended
        #: Access by informal keys like "a.b/c.extra-key".
        self.informal_keys: bool = informal_keys
        #: How sections are written, `Sections.NONE` is false so it still reads as a flag.
        self.sections: Sections = Sections.make(sections)
        #: Parsed format strings, the node tree depends only on the string, the mode and the parser.
        self.nodes_cache: dict[Any, FormatNodes] = {}
        #: Treat a `{name}` looking value as unresolved, for a text formatted more than once.
        self.unresolved_default: bool = unresolved_default

    @property
    def evaluator(self) -> SimpleEval | None:
        """Evaluator of the format call running in this thread, None outside of one."""
        return getattr(self._evaluator_local, 'evaluator', None)

    @evaluator.setter
    def evaluator(self, evaluator: SimpleEval | None) -> None:
        """Set the evaluator of this thread only. A formatter is shared, `safe_format` is a singleton."""
        self._evaluator_local.evaluator = evaluator

    def parse(self, format_string: str) -> Iterable[tuple[str, str | None, str | None, str | None]]:
        """Loop over the format_string and return an iterable of tuples."""
        if self.extended:
            return fparser(format_string)
        return super().parse(format_string)

    def vformat(self, format_string: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> str:
        """Do the actual work of formatting."""
        if self.evaluator_names:
            names = {**self.evaluator_names, **kwargs}
        else:
            names = kwargs
        if not self.evaluator_class:
            return self.vformat_nodes(format_string, args, names, kwargs)
        # an evaluated function may format again through this very formatter, so the outer evaluator
        # is put back afterwards instead of being left overwritten
        outer = self.evaluator
        self.evaluator = self.evaluator_class(names=EvaluatorNames(names, self.evaluator_functions),
                                              functions=self.evaluator_functions)
        try:
            # the evaluator already knows `evaluator_names`, fields are resolved from plain `kwargs`
            return self.vformat_nodes(format_string, args, kwargs, kwargs)
        finally:
            self.evaluator = outer

    def vformat_nodes(self, format_string: str, args: Sequence[Any], names: Mapping[str, Any],
                      kwargs: Mapping[str, Any]) -> str:
        """Format with the evaluator already in place, `names` is what a field is resolved from."""
        if self.sections:
            state = FormatState(args, names)
            text, filled = self.render_nodes(self.cached_nodes(format_string), state, root=True)
            self.check_unused_args(state.used_args, args, kwargs)
            return text
        return super().vformat(format_string, args, names)

    def cached_nodes(self, format_string: str) -> FormatNodes:
        """Node tree of the format string, parsed once. The tree is shared, it must not be modified."""
        if not self.max_cache:
            return self.build_nodes(format_string)
        key = (format_string, self.sections, self.extended)
        nodes = self.nodes_cache.get(key)
        if nodes is None:
            nodes = self.build_nodes(format_string)
            if len(self.nodes_cache) >= self.max_cache:
                self.nodes_cache.clear()
            self.nodes_cache[key] = nodes
        return nodes

    def build_nodes(self, format_string: str) -> FormatNodes:
        """Parse the format string into a tree of literals, fields and `[...]` sections."""
        root: FormatNodes = []
        stack: list[FormatNodes] = [root]
        for literal, name, spec, conversion in self.parse(format_string):
            if literal:
                for mark, token in split_sections(literal, self.sections):
                    if not mark:
                        stack[-1].append(FormatLiteral(token))
                    elif token == '[':
                        children: FormatNodes = []
                        stack[-1].append(FormatSection(children))
                        stack.append(children)
                    else:
                        if len(stack) == 1:
                            raise ValueError("Single ']' encountered in format string")
                        stack.pop()
            if name is not None:
                stack[-1].append(FormatField(name, spec or '', conversion))
        if len(stack) > 1:
            raise ValueError("Single '[' encountered in format string")
        return root

    def render_nodes(self, nodes: FormatNodes, state: FormatState, *, root: bool = False) -> FormatResult:
        """Render nodes, return the text and True if it is filled. In a section drop the text around empty fields."""
        # `literals[i]` is the static text just before `dynamic[i]`, `literals[-1]` is the trailing one
        literals: list[str] = ['']
        dynamic: list[FormatResult] = []
        fields: list[int] = []
        for node in nodes:
            if isinstance(node, FormatLiteral):
                literals[-1] += node.text
                continue
            if isinstance(node, FormatField):
                fields.append(len(dynamic))
                dynamic.append(self.render_field(node, state))
            else:
                # rendered even if it is dropped below, so that the auto-numbered `{}` keep the written order
                dynamic.append(self.render_nodes(node.children, state))
            literals.append('')
        if root:
            # outside of any section all the static text is kept and even an empty field keeps its text
            out = [literals[0]]
            for i, (text, filled) in enumerate(dynamic):
                out.append(text)
                out.append(literals[i + 1])
            return ''.join(out), any(filled for text, filled in dynamic)
        if not dynamic:
            # a section with no field at all, ex. "[abc]", is a plain text
            return literals[0], bool(literals[0])
        if fields and not any(dynamic[i][1] for i in fields):
            # nested sections are subordinate, the section needs at least one filled field of its own
            return '', False
        out, seen = [], False
        for i, (text, filled) in enumerate(dynamic):
            if filled:
                # a static text is the prefix of the field it stands before, and never opens the section
                if seen or i == 0:
                    out.append(literals[i])
                out.append(text)
                seen = True
        if dynamic[-1][1]:
            out.append(literals[-1])
        text = ''.join(out)
        return text, bool(text)

    def render_field(self, node: FormatField, state: FormatState) -> FormatResult:
        """Render a single replacement field, return the text and True if the value is filled."""
        name = node.name
        if name == '':
            if state.auto_index is False:
                raise ValueError('cannot switch from manual field specification to automatic field numbering')
            name = str(state.auto_index)
            state.auto_index += 1
        elif name.isdigit():
            if state.auto_index:
                raise ValueError('cannot switch from manual field specification to automatic field numbering')
            state.auto_index = False
        value, key = self.get_field(name, state.args, state.kwargs)
        state.used_args.add(key)
        spec = self.render_spec(node.spec, state)
        text = self.format_field(self.convert_field(value, node.conversion), spec)
        # a missing field is filled only when the `!!default` in the spec replaces it
        filled = value is not None and (not isinstance(value, MissingField) or '!!' in spec)
        return text, filled and bool(text)

    def render_spec(self, spec: str, state: FormatState) -> str:
        """Render replacement fields nested in a format spec. Sections are not handled there."""
        state.depth += 1
        try:
            # every spec counts as a recursion level, even an empty one, just like in `string.Formatter`
            if state.depth > self.max_spec_depth:
                raise ValueError('Max string recursion exceeded')
            if '{' not in spec:
                return spec
            out = []
            for literal, name, sub_spec, conversion in self.parse(spec):
                out.append(literal)
                if name is not None:
                    text, filled = self.render_field(FormatField(name, sub_spec or '', conversion), state)
                    out.append(text)
            return ''.join(out)
        finally:
            state.depth -= 1

    def convert_field(self, value: Any, conversion: str | None) -> str:
        """Converts the value (returned by get_field()) given a conversion type."""
        known = conversion in (None, 's', 'r', 'a') or (self.escape and conversion == 'e')
        if isinstance(value, MissingField) and known:
            # a missing field is not converted, it stays recognizable and keeps its plain "{name}" text,
            # but an unknown conversion still has to be reported, whether the field is there or not
            return value
        if self.escape and conversion == 'e':
            esc = self._escape_trans
            return ''.join(esc.get(c, c) for c in str(value))
        return super().convert_field(value, conversion)

    def get_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> tuple[Any, Any]:
        """Convert field_name as returned by parse() to an object to be formatted."""
        try:
            return super().get_field(field_name, args, kwargs)
        except (KeyError, AttributeError, IndexError):
            if field_name.isdigit():
                # missing positional argument
                return self.missing_field(field_name, args, kwargs)
        except Exception:
            pass
        if self.evaluator:
            try:
                value = self.evaluator.eval(field_name)
            except Exception:
                # a broken expression is not an error here, it falls back to the informal keys and
                # then to `missing_field()`, so the format string is kept as it was written
                pass
            else:
                # an expression worth nothing but a missing field is unresolved as a whole, so that
                # `missing_field()` still decides what to do with it
                if not isinstance(value, MissingField):
                    return value, ()
        if self.informal_keys and '.' in field_name:
            data = kwargs
            try:
                for fld in field_name.split('.'):
                    if fld.isdigit():
                        fld = int(fld)
                    data = data[fld]
                return data, ()
            except (KeyError, AttributeError, IndexError):
                pass
        return self.missing_field(field_name, args, kwargs)

    def missing_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> tuple[Any, Any]:
        """
        Return missing files, by default keep format string.
        An override returning a `MissingField` means "still missing": it is false, drops its `[...]`
        section and lets `!!default` fire. Returning a plain `str` means "here is a value" instead.
        """
        return MissingField('{%s}' % field_name), ()

    def format_field(self, value: Any, format_spec: str) -> str:
        """Call the global format() built-in, support for default values."""
        format_spec, sep, val = format_spec.partition('!!')
        unknown = isinstance(value, MissingField)
        if not unknown and self.unresolved_default:
            unknown = isinstance(value, str) and value[:1] == '{' and value[-1:] == '}'
        if sep and unknown:
            if '::' in val:
                # "!!VALUE::SPEC" carries its own spec, the default is converted for it as well
                val, sep, format_spec = val.partition('::')
            try:
                if format_spec[-1:] in 'bcdoxX':
                    value = int(val)
                elif format_spec[-1:] in 'eEfFgG':
                    value = float(val)
                else:
                    value = val
            except ValueError:
                # format_spec = format_spec[:-1] + 's'
                format_spec = 's'
                value = val
        try:
            return super().format_field(value, format_spec)
        except (ValueError, TypeError):
            # a spec the value can not take is not an error here, it is kept in the text as it was written
            text = str(value)
            if format_spec:
                if isinstance(value, MissingField):
                    return f'{text[:-1]}:{format_spec}}}'
                return f'{text}:{format_spec}'
            return text

    def add_name(self, name: str, value: Any) -> None:
        """Register `name` in easy-eval names. A callable put here is a value, `{name()}` needs a function."""
        if self.evaluator_names is None:
            self.evaluator_names = {}
        self.evaluator_names[name] = value

    def add_function(self, name: str, function: Callable) -> None:
        """Register `function` in easy-eval functions, so that `{name(...)}` can call it."""
        self.evaluator_functions[name] = function


safe_format = SafeFormatter().format
safe_xformat = SafeFormatter(extended=True).format
safe_sformat = SafeFormatter(sections=Sections.PLAIN).format
