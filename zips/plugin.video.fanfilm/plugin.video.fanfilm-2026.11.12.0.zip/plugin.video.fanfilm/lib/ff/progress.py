"""
Progress merged from the playback rows of accounts: the one block of the rules, a row says nothing about its source.

Movies and episodes are merged field by field (`merge_playback()`); shows and seasons are derived from the merged
episodes (`show_progress()`), the same way for all accounts.
"""

from __future__ import annotations
from datetime import datetime
from operator import attrgetter
from typing import Callable, Hashable, Iterable, Mapping, Optional, Sequence, TypeVar
from typing_extensions import Literal, TypeAlias
from ..defs import MediaRef, MediaProgress, MediaProgressItem
from .db.playback import MediaPlayInfo, PlayedEpisode
from .item import FFItem
from .calendar import utc_from_timestamp
from const import const

#: Merge strategy: 'union' - every field by its rule over all accounts, 'first' - the first account (in order) with the media.
MergeStrategy: TypeAlias = Literal['union', 'first']

#: Fields describing the media (not the progress): the first non-empty value in order of accounts.
MEDIA_FIELDS: tuple[str, ...] = ('ffid', 'tmdb', 'imdb', 'trakt', 'tvdb', 'slug', 'tv_slug', 'duration', 'aired_at')

#: A playback row type: a full one or a light one of an episode (the same fields the merge reads) (`group_rows()`).
R = TypeVar('R', MediaPlayInfo, PlayedEpisode)
#: A media key of the rows (`group_rows()`).
K = TypeVar('K', bound=Hashable)


def merge_state(rows: Sequence[R]) -> tuple[Optional[int], Optional[int], Optional[R], int, int]:
    """
    Return the merged state of the rows of one media (in order of accounts): (play count, last watch time, the row of the
    resume point or None, the newest unwatch time, the newest removed resume point time). The max play count and last watch
    time (watched by any), the newest resume point (dropped if the media was watched after it). With
    `const.media.progress.removals` the newest event wins: only the watches after the newest unwatch of any account count,
    a resume point only after the newest removed one.
    """
    unwatched = unpaused = 0
    if const.media.progress.removals:
        unwatched = max((pb.unwatched_at or 0 for pb in rows), default=0)
        unpaused = max((pb.unpaused_at or 0 for pb in rows), default=0)
    watched = [pb for pb in rows if (pb.last_watched_at or 0) > unwatched] if unwatched else rows
    play_count = max((pb.play_count for pb in watched if pb.play_count is not None), default=0 if unwatched else None)
    last_watched_at = max((pb.last_watched_at for pb in watched if pb.last_watched_at), default=None)
    resume = max((pb for pb in rows if pb.progress and (not unpaused or (pb.paused_at or 0) > unpaused)), key=lambda pb: pb.paused_at or 0,
                 default=None)
    if resume is not None and (resume.paused_at or 0) < (last_watched_at or 0):
        resume = None
    return play_count, last_watched_at, resume, unwatched, unpaused


def merge_rows(rows: Sequence[MediaPlayInfo]) -> MediaPlayInfo:
    """
    Return one row of the media from its rows (in order of accounts) by `merge_state()`; the media fields: the first
    non-empty value. A row of one account is consistent by itself.
    """
    if len(rows) == 1:
        return rows[0]
    out = MediaPlayInfo(ref=rows[0].ref)
    for name in MEDIA_FIELDS:
        if (value := next((v for pb in rows if (v := getattr(pb, name))), None)) is not None:
            setattr(out, name, value)
    out.play_count, out.last_watched_at, resume, unwatched, unpaused = merge_state(rows)
    if const.media.progress.removals:
        out.unwatched_at, out.unpaused_at = unwatched or None, unpaused or None
    if resume is not None:
        out.update_playback(resume)
    return out


def group_rows(accounts: Mapping[str, Iterable[R]], key: Callable[[R], K], *, strategy: MergeStrategy | None = None) -> dict[K, list[R]]:
    """
    Group the playback rows of accounts (account ID -> rows, in order of accounts) by their media `key`. `strategy` (default
    `const.media.progress.merge`): 'union' - the rows of all accounts, 'first' - the rows of the first account with the media
    (many rows of the media in one account, e.g. old plugin URLs, stay together).
    """
    if strategy is None:
        strategy = const.media.progress.merge
    groups: dict[K, list[R]] = {}
    for rows in accounts.values():
        own: set[K] = set()
        for pb in rows:
            group = groups.setdefault(k := key(pb), [])
            if strategy == 'first' and group and k not in own:
                continue  # a previous account has the media
            own.add(k)
            group.append(pb)
    return groups


def merge_playback(accounts: Mapping[str, Iterable[MediaPlayInfo]], *, strategy: MergeStrategy | None = None) -> dict[MediaRef, MediaPlayInfo]:
    """
    Merge the playback rows of accounts (account ID -> rows, in order of accounts) to one row per media (`group_rows()`,
    `merge_rows()`).
    """
    return {ref: merge_rows(rows) for ref, rows in group_rows(accounts, attrgetter('ref'), strategy=strategy).items()}


def show_progress(item: FFItem, episodes: Iterable[MediaPlayInfo], *, aired: Sequence[MediaRef] | None = None) -> MediaProgress | None:
    """
    Return progress of the show or season `item` derived from the merged rows of its `episodes`, None if no one is watched.

    The bar follows the aired episodes of the item: `aired` (from its aired map, `ffinfo.aired_map()`), else from its metadata
    (`surrogate_episode_refs()`, real or guessed from the season sizes), without them: the watched episodes and the rest up to
    `aired_episodes_count`. Watched = all aired episodes watched.
    """
    ref = item.ref
    def own(r: MediaRef) -> bool:  # an episode of the season, or a not special one of the show
        return ref.covers(r) and r.is_episode and (ref.is_season or bool(r.season))

    rows = {pb.ref: pb for pb in episodes if own(pb.ref)}
    if not any(pb.play_count or pb.progress for pb in rows.values()):
        return None
    if skeleton := tuple(aired or item.surrogate_episode_refs(aired=True)):
        bar = tuple(pb.as_media_progress_item() if (pb := rows.get(r)) else MediaProgressItem(r) for r in skeleton)
    elif total := item.aired_episodes_count:
        watched = tuple(pb.as_media_progress_item() for r, pb in sorted(rows.items()) if pb.play_count)[:total]
        bar = watched + (MediaProgressItem(ref),) * (total - len(watched))
    else:
        return None
    last_watched_at = max((pb.last_watched_at for pb in rows.values() if pb.last_watched_at), default=None)
    return bar_progress(ref, bar, last_watched_at=datetime.min if last_watched_at is None else utc_from_timestamp(last_watched_at))


def bar_progress(ref: MediaRef, bar: Sequence[MediaProgressItem], *, last_watched_at: datetime | None = None) -> MediaProgress:
    """
    Return progress of the container `ref` (show, season, a season of an episode group) with the `bar` of its aired episodes:
    watched = all of them watched; the last watch time is the latest of the bar if not given.
    """
    count = sum(1 for it in bar if it.play_count)
    if last_watched_at is None:
        last_watched_at = max((it.last_watched_at for it in bar if it.has_last_watched_at), default=datetime.min)
    return MediaProgress(ref, progress=100 * count / len(bar) if bar else 0.0, play_count=int(bool(bar) and count == len(bar)), bar=tuple(bar),
                         last_watched_at=last_watched_at)


def played_at(pb: MediaPlayInfo) -> int:
    """Return the last play time of the media (watched or paused, unix seconds), 0 if unknown."""
    return max(pb.last_watched_at or 0, pb.paused_at or 0)


def played_time(pb: MediaPlayInfo) -> datetime:
    """Return the last play time of the media (`played_at()`) as a local datetime, `datetime.min` if unknown."""
    return datetime.fromtimestamp(ts) if (ts := played_at(pb)) else datetime.min


def played_role(when: datetime, *, pb: MediaPlayInfo | None = None, role: str | None = None) -> str:
    """
    Return the role of a played item: `role` (`const.indexer.history.role` if None) formatted with the play time `when` (local)
    as `played_at`, the row `pb` (`percent`, `play_count`) and `date` (`const.folder.role_date_format`); '' if no role.
    """
    if role is None and not (role := const.indexer.history.role):
        return ''
    return role.format(pb=pb, percent=pb and pb.progress or '', play_count=pb and pb.play_count or 0, played_at=when, played_at_timestamp=when,
                       date=const.folder.role_date_format)


def played_items(rows: Iterable[MediaPlayInfo], *, role: str | None = None) -> list[FFItem]:
    """
    Return items of played media, the latest first; `role` (e.g. '{played_at:%Y-%m-%d}') is formatted with the row (`pb`),
    `played_at` (local datetime), `percent` and `play_count`.
    """
    items = []
    for pb in sorted(rows, key=played_at, reverse=True):
        item = pb.as_item()
        if role is not None:
            item.role = played_role(played_time(pb), pb=pb, role=role)
        items.append(item)
    return items
