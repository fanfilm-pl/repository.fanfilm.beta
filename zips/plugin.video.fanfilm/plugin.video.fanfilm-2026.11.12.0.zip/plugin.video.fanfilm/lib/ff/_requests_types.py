from __future__ import annotations
from typing import Iterable, Callable
from typing_extensions import TypedDict, NotRequired, Literal
from future.backports.http.cookiejar import CookieJar
import requests
from .types import JsonResult

Data = dict[str, str | int | float | None] | Iterable[tuple[str, str | int | float | None]] | str | bytes | None

Method = Literal['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']


class SomeRequestOrigArgs(TypedDict):
    # method: Literal['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']
    headers: NotRequired[dict[str, str] | None]
    cookies: NotRequired[dict[str, str] | CookieJar | None]
    files: NotRequired[dict[str, str | bytes] | Iterable[tuple[str, str | bytes]] | None]
    auth: NotRequired[tuple[str, str] | None]
    timeout: NotRequired[float | tuple[float, float] | None]
    allow_redirects: NotRequired[bool | None]
    proxies: NotRequired[dict[str, str] | None]
    hooks: NotRequired[dict[str, Callable[[requests.Response], None]] | None]
    stream: NotRequired[bool | None]
    verify: NotRequired[bool | str | None]
    cert: NotRequired[str | tuple[str, str] | None]


class RequestOrigArgsWithoutUrl(SomeRequestOrigArgs):
    params: NotRequired[Data]
    data: NotRequired[Data]
    json: NotRequired[JsonResult | None]


class RequestOrigArgs(RequestOrigArgsWithoutUrl):
    # method: Literal['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']
    url: str


class RequestMethodArgs(SomeRequestOrigArgs):
    pass


class RequestFunctionArgs(RequestOrigArgsWithoutUrl):
    pass
