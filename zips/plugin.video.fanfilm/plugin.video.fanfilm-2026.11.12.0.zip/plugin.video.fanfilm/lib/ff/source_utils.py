# -*- coding: utf-8 -*-

"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
from typing import Iterable, Iterator, TypeVar, TYPE_CHECKING
from typing_extensions import TypedDict
import re
from datetime import date
from random import randrange
from attrs import frozen, asdict as _attrs_asdict
from urllib.parse import quote_plus, urljoin, urlparse

import xbmc
from . import apis, cleantitle, requests
from .settings import settings
# TODO: TRAKT  from lib.ff import trakt
from lib.ff.debug import log_exception
from .logs import fflog_exc
from ..sdk.protocol.item import RX_SIZE, size_bytes, quality_of_resolution
from ..sdk.facts import parse
from .source_facts import audio_language, language_type
if TYPE_CHECKING:
    from typing import Sequence
    from ..sources import Source, SourceItem, SourceTitleAlias


S = TypeVar('S', bound='Source|SourceItem')


# ---------------------------------------------------------------------------
# TypedDicts
# ---------------------------------------------------------------------------

class ParsedFilename(TypedDict):
    """Result of parse_filename_title()."""
    title: str
    year: int | None
    season: int | None
    episode: int | None


FF_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0'
#: The fixed User-Agent of Chrome (`const.sources.user_agent.auto` off).
FIXED_CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
#: The fixed User-Agent of Edge (`const.sources.user_agent.auto` off).
FIXED_EDGE_UA = f'{FIXED_CHROME_UA} Edg/140.0.3485.94'
ANDROID_UA = 'Mozilla/5.0 (Linux; Android 8.0)'
if TYPE_CHECKING:  # the names of the module: `__getattr__()`
    CHROME_UA: str
    EDGE_UA: str
    DEFAULT_UA: str


def chrome_version(today: date | None = None) -> int:
    """Return the version of the stable Chrome of the day (`const.sources.user_agent`: its anchor, a step of days), never before the anchor."""
    from const import const
    version, released = const.sources.user_agent.anchor
    days = ((today or date.today()) - date.fromisoformat(released)).days
    return version + max(days, 0) // const.sources.user_agent.step


def browser_seed() -> int:
    """Return the random number of the installation (the system and the margin of its User-Agent), kept in the data of the old client."""
    from .db.sources import provider_store
    store = provider_store('ff/client')
    if (seed := store.get('ua_seed')) is None:
        seed = randrange(1 << 30)
        store.set('ua_seed', seed, ttl=None)
    return seed


def chrome_ua(*, edge: bool = False, fixed: str = '') -> str:
    """
    Return the User-Agent of Chrome (`edge`: of Edge): derived from the date and the installation (`const.sources.user_agent.auto`),
    else the fixed one (`fixed`, default: `FIXED_CHROME_UA` / `FIXED_EDGE_UA`).
    """
    from const import const
    ua = const.sources.user_agent
    if not ua.auto:
        return fixed or (FIXED_EDGE_UA if edge else FIXED_CHROME_UA)
    seed = browser_seed()
    system = ua.systems[seed % len(ua.systems)]
    version = chrome_version() - ua.margin[seed // len(ua.systems) % len(ua.margin)]
    agent = f'Mozilla/5.0 ({system}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.0.0 Safari/537.36'
    return f'{agent} Edg/{version}.0.0.0' if edge else agent


def __getattr__(name: str) -> str:
    """The User-Agents of a browser (`CHROME_UA`, `DEFAULT_UA`, `EDGE_UA`): `chrome_ua()` at the import of the name."""
    if name in ('CHROME_UA', 'DEFAULT_UA'):
        return chrome_ua()
    if name == 'EDGE_UA':
        return chrome_ua(edge=True)
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')

# _USER_AGENTS = [FF_UA, EDGE_UA, CHROME_UA]
# RANDOM_UA = choice(_USER_AGENTS)

RES_4K = [
    " 4k",
    " hd4k",
    " 4khd",
    " uhd",
    " ultrahd",
    " ultra hd",
    " 2160",
    " 2160p",
    " hd2160",
    " 2160hd",
]
RES_1080 = [
    " 1080",
    " 1080p",
    " 1080i",
    " hd1080",
    " 1080hd",
    " m1080p",
    " fullhd",
    " full hd",
    " fhd",
    " 1o8o",
    " 1o8op",
]
RES_720 = [" 720", " 720p", " 720i", " hd720", " 720hd", " 72o", " 72op"]
RES_SD = [
    " 576",
    " 576p",
    " 576i",
    " sd576",
    " 576sd",
    " 480",
    " 480p",
    " 480i",
    " sd480",
    " 480sd",
    " 360",
    " 360p",
    " 360i",
    " sd360",
    " 360sd",
    " 240",
    " 240p",
    " 240i",
    " sd240",
    " 240sd",
]
RES_SCR = [" scr", " screener", " dvdscr", " dvd scr", " r5", " r6"]
RES_CAM = [
    " camrip",
    " tsrip",
    " hdcam",  # czy to zaliczać też?
    " hqcam",  # czy to zaliczać też?
    " hd cam",  # czy to zaliczać też?
    " cam rip",
    " hdts",  # czy to zaliczać też?
    " hd-ts",  # czy to zaliczać też?
    " dvdcam",
    " dvdts",
    " cam",
    " telesync",
    " ts",
]
AVC = [" h 264 ", " h264 ", " x264 ", " avc "]

# ADDITIONAL FOR EN SOURCES INFOS
CODEC_H265 = ["hevc", "h265", "x265"]
CODEC_H264 = ["avc", "h264", "x264"]
CODEC_XVID = ["xvid"]
CODEC_DIVX = ["divx", "div2", "div3"]
CODEC_MPEG = [
    "mpeg",
    "m4v",
    "mpg",
    "mpg1",
    "mpg2",
    "mpg3",
    "mpg4",
    "msmpeg",
    "msmpeg4",
    "mpegurl",
]
CODEC_MP4 = ["mp4"]
CODEC_M3U = ["m3u8", "m3u"]
CODEC_AVI = ["avi"]
CODEC_MKV = ["mkv", "matroska"]

AUDIO_8CH = ["ch8", "8ch", "ch7", "7ch", "7 1", "ch7 1", "7 1ch"]
AUDIO_6CH = ["ch6", "6ch", "6 1", "ch6 1", "6 1ch", "5 1", "ch5 1", "5 1ch"]
AUDIO_2CH = ["ch2", "2ch", "stereo", "dualaudio", "dual", "2 0", "ch2 0", "2 0ch"]
AUDIO_1CH = ["ch1", "1ch", "mono", "monoaudio", "ch1 0", "1 0ch"]

# EN sources tem workaround
# quick workaround
host_limit = True  # control.setting("host.limit") or "true"  # XXX missing setting 'host.limit'
host_limit_count = 3  # int(control.setting('host.count')) or '3'  # XXX missing setting 'host.count'

TMDB_API_URL = "https://api.themoviedb.org/3"
TMDB_API_KEY = (
    settings.getString("tmdb.api_key") or apis.tmdb_API
)  # Używaj metody control.setting do uzyskania klucza


def check_host_limit(item, items):
    try:
        if not host_limit:
            return False
        items = [i["source"] for i in items if "source" in i] or list(items)
        return items.count(item) == host_limit_count
    except Exception:
        return False


def supported_video_extensions():  # ok
    supported_video_extensions = xbmc.getSupportedMedia("video").split("|")
    unsupported = [
        "",
        ".url",
        ".bin",
        ".zip",
        ".rar",
        ".001",
        ".disc",
        ".7z",
        ".tar.gz",
        ".tar.bz2",
        ".tar.xz",
        ".tgz",
        ".tbz2",
        ".gz",
        ".bz2",
        ".xz",
        ".tar",
    ]
    return [i for i in supported_video_extensions if i not in unsupported]


def get_host(url):  # EN Sources
    try:
        url = url.replace(r"\/", r"/").replace(r"///", r"//")
        elements = urlparse(url)
        domain = elements.netloc or elements.path
        domain = domain.split("@")[-1].split(":")[0]
        res = re.search(r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$", domain)
        if res:
            domain = res.group(1)
        domain = domain.lower()
    except Exception:
        elements = urlparse(url)
        host = elements.netloc
        domain = host.replace("www.", "")
    return domain


def get_codec(term):  # EN Sources
    if any(value in term for value in CODEC_H265):
        _codec = "HEVC | "
    elif any(value in term for value in CODEC_H264):
        _codec = "AVC | "
    elif any(value in term for value in CODEC_MKV):
        _codec = "MKV | "
    elif any(value in term for value in CODEC_DIVX):
        _codec = "DIVX | "
    elif any(value in term for value in CODEC_MPEG):
        _codec = "MPEG | "
    elif any(value in term for value in CODEC_MP4):
        _codec = "MP4 | "
    elif any(value in term for value in CODEC_M3U):
        _codec = "M3U | "
    elif any(value in term for value in CODEC_XVID):
        _codec = "XVID | "
    elif any(value in term for value in CODEC_AVI):
        _codec = "AVI | "
    else:
        _codec = "0"
    return _codec


def get_audio(term):  # EN Sources
    if any(value in term for value in AUDIO_8CH):
        _audio = "7.1 | "
    elif any(value in term for value in AUDIO_6CH):
        _audio = "5.1 | "
    elif any(value in term for value in AUDIO_2CH):
        _audio = "2.0 | "
    elif any(value in term for value in AUDIO_1CH):
        _audio = "Mono | "
    else:
        _audio = "0"
    return _audio


_QUALITY_FN_RE = re.compile(r'\b(2160|1080|720|576|480)[pPi]?\b', re.I)


def get_quality_from_filename(name: str) -> str | None:
    m = _QUALITY_FN_RE.search(name)
    if m:
        res = int(m.group(1))
        if res >= 2160:
            return '4K'
        elif res >= 1080:
            return '1080p'
        elif res >= 720:
            return '720p'
        elif res >= 576:
            return 'SD'
        else:
            return 'SD'
    return None


def get_quality(term1, term2=None):  # OK + workaround for en sources
    term = " {} ".format(term1 + (term2 or "")).lower()
    if any(i in term for i in RES_SCR):
        return "SCR"
    elif any(i in term for i in RES_CAM):
        return "CAM"
    elif any(i in term for i in RES_4K) and not any(i in term for i in RES_1080):
        return "4K"
    elif any(i in term for i in RES_1080):
        return "1080p"
    elif any(i in term for i in RES_720):
        return "720p"
    elif any(i in term for i in RES_SD):
        return "SD"
    elif "remux " in term and any(i in term for i in AVC):
        return "1080p"
    elif "remux " in term:
        return "4K"
    else:
        return "SD"


def check_sd_url(release_link):
    try:
        release_link = release_link.lower()
        release_link = re.sub(r"\.\w{2,4}$", "", release_link)  # extension out
        release_link = release_link.replace(" ", ".").replace("_", ".")

        # Wykrywanie CAM - tylko jako osobne słowo (z separatorami), nie część większego (np. "CAMBiO")
        # CAM występuje jako: .cam. lub -cam. lub -cam- lub na końcu: .cam lub -cam
        if any(
            i in release_link
            for i in [
                "camrip",
                "tsrip",
                "hdcam",
                "hqcam",
                "hdts",
                "hd-ts",
                "dvdcam",
                "dvdts",
                "telesync",
                ".ts",
                ".cam.",
                "-cam.",
                "-cam-",
            ]
        ) or release_link.endswith(".cam") or release_link.endswith("-cam"):
            return "CAM"


        if "2160" in release_link or ".4k" in release_link or ".uhd" in release_link:
            return "4K"
        elif "1440" in release_link:
            return "1440p"
        elif "1080i" in release_link:
            quality = "1080i"
        elif "1080" in release_link:
            quality = "1080p"
        elif "720" in release_link:
            quality = "720p"
        elif ".hd." in release_link:
            quality = "720p"
        elif any(i in release_link for i in ["dvdscr", "r5", "r6"]):
            quality = "SCR"
        # CAM jest już wykrywany na początku funkcji
        else:
            quality = "SD"
        return quality
    except Exception:
        return "SD"


#: Return quality string from pixel dimensions (pass width, height, or both).
quality_from_resolution = quality_of_resolution


def is_host_valid(url, domains):  # ok
    try:
        host = __top_domain(url)
        hosts = [
            domain.lower() for domain in domains if host and host in domain.lower()
        ]

        if hosts and "." not in host:
            host = hosts[0]
        if hosts and any([h for h in ["google", "picasa", "blogspot"] if h in host]):
            host = "gvideo"
        if hosts and any([h for h in ["akamaized", "ocloud"] if h in host]):
            host = "CDN"
        return any(hosts), host
    except Exception:
        log_exception()
        return False, ""


def __top_domain(url):  # ok
    elements = urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split("@")[-1].split(":")[0]
    regex = r"(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$"
    res = re.search(regex, domain)
    if res:
        domain = res.group(1)
    domain = domain.lower()
    return domain


def subtitles_dir(provider: str) -> str:
    """Return the (created) temp folder of the subtitles downloaded by the provider, see cleanup_subtitles()."""
    import os
    path = os.path.join(_subtitles_root(), provider)
    os.makedirs(path, exist_ok=True)
    return path


def _subtitles_root() -> str:
    """Return the temp folder of the subtitles of all providers (in the folder of FanFilm)."""
    import os
    from .control import plugin_id, transPath
    return os.path.join(transPath('special://temp'), plugin_id, 'subtitles')


def cleanup_subtitles() -> int:
    """Remove the subtitle files older than `const.sources.subtitles_max_age` and the old provider folders. Return the count."""
    import os
    import shutil
    import time
    from .control import transPath
    from const import const
    for old in ('moviebox_subs', 'kisskh_subs'):   # before the folder of FanFilm
        shutil.rmtree(os.path.join(transPath('special://temp'), old), ignore_errors=True)
    removed = 0
    limit = time.time() - const.sources.subtitles_max_age
    for folder, _, files in os.walk(_subtitles_root()):
        for name in files:
            path = os.path.join(folder, name)
            try:
                if os.path.getmtime(path) < limit:
                    os.remove(path)
                    removed += 1
            except OSError:
                pass
    return removed


def append_headers(headers: dict[str, str]) -> str:  # ok
    return "|%s" % "&".join(
        ["%s=%s" % (key, quote_plus(headers[key])) for key in headers]
    )


_M3U8_RESOLUTION_RE = re.compile(r'RESOLUTION=\s*\d+\s*x\s*(\d+)', re.I)


def probe_m3u8_quality(url: str, headers: dict[str, str] | None = None,
                       timeout: float = 4.0,
                       on_unknown: str | None = None) -> str | None:
    """Fetch HLS master playlist, return quality label from max RESOLUTION.

    Returns one of '4K' / '1440p' / '1080p' / '720p' / 'SD' on success.
    Returns None when the fetch itself fails (timeout / non-2xx / exception)
    — distinguishes "dead URL" from "valid m3u8 without resolution metadata"
    so callers can filter unreachable streams.
    Returns `on_unknown` (default None) when the m3u8 has no RESOLUTION tags
    (single-bitrate stream) but was fetched successfully.
    """
    try:
        r = requests.get(url, headers=headers or {}, timeout=timeout)
        if not r.ok:
            return None
        heights = [int(m.group(1)) for m in _M3U8_RESOLUTION_RE.finditer(r.text)]
        if not heights:
            return on_unknown
        h = max(heights)
        if h >= 2160:
            return '4K'
        if h >= 1440:
            return '1440p'
        if h >= 1080:
            return '1080p'
        if h >= 720:
            return '720p'
        return 'SD'
    except Exception:
        return None


_RE_HLS_VARIANT = re.compile(
    r'#EXT-X-STREAM-INF:[^\n]*RESOLUTION=(\d+)x(\d+)[^\n]*\n(\S+)',
    re.MULTILINE,
)


def parse_hls_variants(text: str, base_url: str) -> list[tuple[int, int, str]]:
    """Parse #EXT-X-STREAM-INF lines from an HLS master playlist into
    (width, height, resolved_variant_url) tuples.

    Each variant path is resolved against `base_url` (the master playlist's
    own URL) via urljoin - relative paths may or may not have a leading '/'
    depending on the CDN, and only urljoin handles both correctly.
    """
    return [(int(w), int(h), urljoin(base_url, path.strip()))
            for w, h, path in _RE_HLS_VARIANT.findall(text)]


_ENC_DEC_BASE = 'https://enc-dec.app/api'


def enc_dec_result(endpoint: str, *, params: dict[str, str] | None = None,
                   json_body: dict[str, Any] | None = None,
                   timeout: float = 10.0) -> Any:
    """Call an enc-dec.app endpoint, return its `result` field or None on failure.

    Shared token/payload decoder for streaming sources whose own API responses
    are encrypted (videasy, kisskh, ...) - see https://enc-dec.app. GET with
    *params* when given, otherwise POST *json_body*. Returns None on a network
    error, non-2xx response, or the API's own {"status": <not 200>} envelope,
    so callers can treat "no answer" uniformly regardless of the failure mode.
    """
    try:
        url = f'{_ENC_DEC_BASE}/{endpoint}'
        resp = requests.post(url, json=json_body, timeout=timeout) if json_body is not None \
            else requests.get(url, params=params, timeout=timeout)
        if not resp.ok:
            return None
        payload = resp.json()
        if not isinstance(payload, dict) or payload.get('status') != 200:
            return None
        return payload.get('result')
    except Exception:
        fflog_exc()
        return None


def human_readable_size(size_bytes: int | None) -> str:
    import math

    if size_bytes is None:
        return ''
    if size_bytes == 0:
        return '0 B'
    units = ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB')
    exp = int(math.log(size_bytes, 1024))
    val: float = size_bytes / 1024 ** exp
    if val < 10:
        val = round(val, 2)
    elif val < 100:
        val = round(val, 1)
    else:
        val = int(val)
    return f'{val} {units[exp]}'


# old name
convert_size = human_readable_size


def is_ai_lector(text: str) -> bool:
    """Detect AI-generated 'lektor' markers in filenames/labels (PL.AI, PL.Ai, lektor_pl_ai, etc)."""
    if not text:
        return False
    t = text.lower()
    # normalize brackets/extra whitespace; keep dots/underscores/dashes in place
    t = re.sub(r'[\[\]\(\)]+', ' ', t)
    # allow up to 2 separator chars (space, dot, underscore, dash) between tokens
    # so "lektor. AI", "PL.AI", "PL_AI", "lektor_pl_ai", "ai lektor" all match
    return bool(re.search(
        r'\b(?:pl[ _.-]{0,2}ai|ai[ _.-]{0,2}pl|lektor[ _.-]{0,2}(?:pl[ _.-]{0,2})?ai|ai[ _.-]{0,2}lektor|plai)\b',
        t, flags=re.I,
    ))


def get_lang_by_type(text: str) -> tuple[str, str]:
    """
    Return the language of the audio and the language type (`Lektor`, `Dubbing Kino`, `Napisy`, `Multi`...) of a text (a file
    name, a label of a site) from its facts; a lektor or a dubbing of no language is Polish, subtitles give no language.
    """
    facts = parse(text)
    tracks = [{**track, 'lang': 'pl'} if 'kind' in track and 'lang' not in track else track for track in facts.get('audio', ())]
    return audio_language(tracks), language_type(facts, tracks)  # type: ignore[arg-type]


def parse_source_quality_lang(filename: str) -> tuple[str, str, str]:
    """Return (quality, language, info) from a warez filename.

    Convenience combining check_sd_url + get_lang_by_type for the common scraper pattern.
    """
    quality = check_sd_url(filename)
    language, info = get_lang_by_type(filename)
    return quality, language, info


def convert_size_to_bytes(size: str | int) -> int:
    """Return the bytes of the (first) size in the text (`7.2 GB`), 0 if none (`size_bytes()` of the protocol)."""
    if isinstance(size, int):
        return size
    return (size_bytes(match[0]) or 0) if (match := RX_SIZE.search(size)) else 0




def get_netflix_ep_id(netflix_id: str, season: int | str, episode: int | str, episode_titles: list[str] | None = None) -> tuple[str, str] | None:
    """Fetch Netflix episode ID (epid) and season ID (seasid) from uNoGS API.

    If *episode_titles* is provided, matches by episode title (preferred — handles
    TMDB vs Netflix season numbering mismatches). Falls back to (season, episode).
    """
    try:
        user_id = {'user_name': '1683364584.456'}
        response = requests.post('http://unogs.com/api/user', data=user_id, timeout=10)
        token = response.json().get('token', {}).get('access_token')
        if not token:
            return None

        headers = {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'REFERRER': 'http://unogs.com',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest',
        }

        r = requests.get(f'http://unogs.com/api/title/episodes?netflixid={netflix_id}', headers=headers, timeout=10)
        r.raise_for_status()
        apianswer = r.json()

        # Try title match first (bypasses TMDB vs Netflix numbering mismatches)
        if episode_titles:
            clean_targets = {cleantitle.get(t) for t in episode_titles if t}
            clean_targets.discard(None)
            for season_data in apianswer:
                for ep in season_data.get('episodes', []):
                    if cleantitle.get(ep.get('title', '')) in clean_targets:
                        return str(ep['epid']), str(ep['seasid'])

        # Fall back to season/episode number match
        target_s, target_e = int(season), int(episode)
        season_data = next((s for s in apianswer if s.get('season') == target_s), None)
        if not season_data:
            return None

        ep_data = next((e for e in season_data.get('episodes', []) if e.get('epnum') == target_e), None)
        if not ep_data:
            return None

        return str(ep_data['epid']), str(ep_data['seasid'])
    except Exception:
        log_exception()
        return None


def numbers_in_pattern(pat, mode=0, prefix=""):
    numbers = (
        "zero",
        "one|jeden|i",
        "two|dwa|ii",
        "three|trzy|iii",
        "four|cztery|iv",
        "five|pięć|v",
        "six|sześć|vi",
        "seven|siedem|vii",
        "eight|osiem|viii",
        "nine|dziewięć|ix",
    )
    if mode != 2:
        pat = re.sub(
            r"(?<!\|)\b\d\b(?!\|)",
            lambda x: f"({prefix}{x.group()}|{numbers[int(x.group())-0]})",
            pat,
        )  # cyfry na słowa
    if mode != 1:
        pat = re.sub(
            r"(?<!\|)\b(\w{3,8}|[iIvVxX]{1,2})\b(?!\|)",
            lambda x: f"({prefix}{x.group()}|{[x.group().lower() in n.split('|') for n in numbers].index(True)+0})"
            if any(x.group().lower() in n.split('|') for n in numbers)
            else x.group(),
            pat,
        )  # słowa na cyfry
    return pat


_DIAKRYT: dict[str, str] = {
    "ą": "a",
    "ć": "c",
    "ę": "e",
    "ł": "l",
    "ń": "n",
    "ó": "o",
    "ś": "s",
    "ż": "z",
    "ź": "z",
}
_DIAKRYT_REV: dict[str, str] = {v: k for k, v in _DIAKRYT.items()}
_DIAKRYT_REV["z"] = "żź"  # korekta – ź i ż oba na z

_DIAKRYT_TABLE = str.maketrans(
    ''.join(_DIAKRYT) + ''.join(_DIAKRYT).upper(),
    ''.join(_DIAKRYT.values()) + ''.join(_DIAKRYT.values()).upper(),
)


def strip_diacritics(text: str) -> str:
    return text.translate(_DIAKRYT_TABLE)


def _diacritic_replacer(L="", mode=0, prefix="[", postfix="]"):
    def _replace(L):
        # if type(L) is not str:
        if isinstance(L, re.Match):
            L = L.group()
        l = L.lower()
        if l in _DIAKRYT and mode != 2:
            return f"{prefix}{l}{_DIAKRYT[l]}{postfix}"  # ą -> [ąa]
        elif l in _DIAKRYT_REV and mode != 1:
            return f"{prefix}{l}{_DIAKRYT_REV[l]}{postfix}"  # a -> [aą]
        else:
            return L

    if L:
        return _replace(L)
    else:
        return _replace


def normalize_unicode_in_pattern(pattern, prefix="[", postfix="]", qm="?"):
    t1 = pattern
    t2 = cleantitle.normalize(t1)
    if t1 != t2:
        if len(t1) == len(t2):
            t3 = ""
            for i, t in enumerate(t1):
                t3 += f"{prefix}{t}{t2[i]}{qm}{postfix}" if t != t2[i] else t
            t2 = t3.replace(prefix+prefix, prefix).replace(postfix+postfix, postfix)
            # dodatkowe czyszczenia
            # pr = re.escape(prefix)
            # po = re.escape(postfix)
            # t2 = re.sub(rf"(?<={pr})(\w*(?:{pr})?\w+{po}[\w\?]*)?(?={po})", lambda x: x.group().replace(prefix,"").replace(postfix,""), t2)
            # t2 = re.sub(fr"(?<={pr})(\w)(\w)(\2|\1)(?=\??{po})", r"\1\2", t2)
    return t2


_ROMAN_VALUES: list[tuple[int, str]] = [
    (1000, 'M'),
    (900, 'CM'),
    (500, 'D'),
    (400, 'CD'),
    (100, 'C'),
    (90, 'XC'),
    (50, 'L'),
    (40, 'XL'),
    (10, 'X'),
    (9, 'IX'),
    (5, 'V'),
    (4, 'IV'),
    (1, 'I'),
]


_ROMAN_BY_CHAR: dict[str, int] = {r: i for i, r in _ROMAN_VALUES if len(r) == 1}


def roman_to_int(s: str) -> int:
    """Convert Roman numeral string to integer. Returns 0 for invalid input."""
    result = 0
    prev = 0
    for ch in reversed(s.upper()):
        curr = _ROMAN_BY_CHAR.get(ch, 0)
        result += curr if curr >= prev else -curr
        prev = curr
    return result


# def get_trakt_id_from_tmdb(tmdb_id):
#     result = trakt.getTraktAsJson(f"/search/tmdb/{tmdb_id}?type=show")
#     if result:
#         return result[0]["show"]["ids"]["trakt"]
#     return None


# def get_absolute_number_trakt(tmdb, episode, season):
#     trakt_show_id = get_trakt_id_from_tmdb(tmdb)
#     if not trakt_show_id:
#         return None

#     seasons = trakt.getTraktAsJson(f"/shows/{trakt_show_id}/seasons")
#     if not seasons:
#         return None

#     # Convert to integers if they are strings
#     season = int(season)
#     episode = int(episode)

#     absolute_number = 0

#     for season_data in seasons:
#         if season_data["number"] < season:
#             absolute_number += season_data["aired_episodes"]
#         elif season_data["number"] == season:
#             absolute_number += episode
#             break

#     return absolute_number



def detect_script(s, mode=0):
    from unicodedata import category

    def _detect_char_script(c):
        v = ord(c or ' ')
        # print(c, hex(v), v, (category(c)))  # debug
        if not (c and category(c)[0] == 'L'):  # if not a letter
            return ""
        if 0x20 <= v < 0x370:
            return False
        if 0x370 <= v <= 0x3ff:
            return 'gr'
        if 0x400 <= v <= 0x52f:
            return "rus"
        return True

    s = s.strip()
    if not len(s):
        return None

    if mode == 0:  # whole text (only letters)
        r = [_detect_char_script(l) for l in s if category(l)[0] == 'L']
    elif mode == 2:
        r = [_detect_char_script(s[i]) for i in [0, -1]]  # first and last letter
    else:
        r = []
    if r.count("gr"):
        return "gr"
    if r.count("rus"):
        return "rus"
    return any(r)


def deduplicate_list_ci(items: list[str]) -> list[str]:
    """Deduplicate list preserving order (case-insensitive).

    Args:
        items: List of strings to deduplicate

    Returns:
        List with duplicates removed (case-insensitive), preserving original order
    """
    seen_lower = set()
    unique = []
    for item in items:
        item_lower = item.lower()
        if item_lower not in seen_lower:
            seen_lower.add(item_lower)
            unique.append(item)
    return unique


def is_anime(ffitem) -> bool:
    """Check if content (movie or TV show) is anime.

    Args:
        ffitem: FFItem object with keywords attribute

    Returns:
        True if content is tagged as anime, False otherwise
    """
    return ffitem.category == 'anime'


# można będzie dopisywać frazy, które mogą być pomijane przy szukaniu
antifalse_filter_exceptions = [
    "The TV Series",
]


def extract_cookie(cookie: str, cookie_name: str) -> str:
    """Get cookie value from string."""
    import json
    # replace all cookies to wanted one
    cookie_re = re.escape(cookie_name)
    cookie = re.sub(rf'^.*\b{cookie_re}=([^;]*)(?:;.*|$)', r'\1', cookie)
    # JSON, used by Copy Cookies web extension
    if re.search(rf'"name"\s*:\s*"{cookie_re}"', cookie):
        try:
            for cookies in json.loads(cookie):
                if cookies.get('name') == cookie_name:
                    return cookies.get('value', '')
        except json.JSONDecodeError:
            pass
        return ''
    return cookie.strip(' "\'')


def provider_cookie(provider: str, cookie_name: str, key: str = 'cookies_cf') -> str:
    """Return a cookie of the setting `key` of a native provider (the cookies of a site, `lib.sources.natives.CF_COOKIE`)."""
    from ..sources.natives import provider_value
    return extract_cookie(provider_value(provider, key), cookie_name)


def sources_with_links(sources: Iterable[S]) -> list[S]:
    """Wywalanie zepsutych url (jesli nie są to pliki lokalne)."""
    def match(s: S) -> bool:
        if s.get('local'):
            return True
        if (url := getattr(s, 'url', ...)) is ...:  # support for Source object and SourceItem dict
            url = s.get('url', '')
        if not url:
            return False
        return '://' in url or url.startswith('DRMFF')

    return [src for src in sources if match(src)]


# ---------------------------------------------------------------------------
# Asian content detection (shared by dramaclub24, dramaqueen, …)
# ---------------------------------------------------------------------------

ASIAN_COUNTRIES: frozenset[str] = frozenset({'KR', 'JP', 'CN', 'TW', 'HK'})
ASIAN_LANGUAGES: frozenset[str] = frozenset({'ko', 'ja', 'zh'})

# TMDB keyword → frozenset of ISO 3166-1 country codes it implies.
# Used as fallback when production country alone is insufficient
# (e.g. Shōgun: US co-production with Japanese keywords).
ASIAN_KEYWORD_COUNTRIES: dict[str, frozenset[str]] = {
    'japan':        frozenset({'JP'}),
    'japanese':     frozenset({'JP'}),
    'samurai':      frozenset({'JP'}),
    'jidaigeki':    frozenset({'JP'}),
    'feudal japan': frozenset({'JP'}),
    'sengoku period': frozenset({'JP'}),
    'edo period':   frozenset({'JP'}),
    'meiji period': frozenset({'JP'}),
    'anime':        frozenset({'JP'}),
    'manga':        frozenset({'JP'}),
    'ninja':        frozenset({'JP'}),
    'korea':        frozenset({'KR'}),
    'korean':       frozenset({'KR'}),
    'k-drama':      frozenset({'KR'}),
    'seoul':        frozenset({'KR'}),
    'china':        frozenset({'CN'}),
    'chinese':      frozenset({'CN'}),
    'hong kong':    frozenset({'HK'}),
    'taiwan':       frozenset({'TW'}),
    'taiwanese':    frozenset({'TW'}),
    'wuxia':        frozenset({'CN'}),
    'thailand':     frozenset({'TH'}),
    'thai':         frozenset({'TH'}),
}


def get_asian_country_codes(item) -> frozenset[str]:
    """Return effective Asian country codes for an ffitem/show_item.

    Checks production countries first, then falls back to TMDB keywords.
    Returns a frozenset of ISO 3166-1 codes (may include non-ASIAN_COUNTRIES
    codes if keywords imply them — callers decide what to do with the result).
    """
    try:
        codes = frozenset(item.vtag.getCountryCodes())
    except Exception:
        codes = frozenset()

    asian = codes & ASIAN_COUNTRIES
    if asian:
        return asian

    # Keyword fallback
    try:
        keywords = set((item.keywords or {}).keys())
    except Exception:
        return frozenset()

    extra: set[str] = set()
    for kw, implied in ASIAN_KEYWORD_COUNTRIES.items():
        if kw in keywords:
            extra |= implied
    return frozenset(extra)


def is_asian_content(item) -> bool:
    """Return True if item is Asian content by country, language or keyword."""
    try:
        if ASIAN_LANGUAGES & set(item.vtag.getLanguageCodes()):
            return True
    except Exception:
        pass
    return bool(get_asian_country_codes(item))


# ---------------------------------------------------------------------------
# Indian / Bollywood content detection (used by filmlinks4u, …)
# ---------------------------------------------------------------------------

INDIAN_COUNTRIES: frozenset[str] = frozenset({'IN'})
INDIAN_LANGUAGES: frozenset[str] = frozenset({'hi', 'ta', 'te', 'ml', 'kn', 'bn', 'mr', 'pa', 'gu'})
INDIAN_KEYWORDS: frozenset[str] = frozenset({
    'bollywood', 'india', 'indian', 'indian cinema',
    'hindi cinema', 'kollywood', 'tollywood', 'mollywood',
    'mumbai', 'delhi', 'shankar', 'dharma productions',
})


def is_indian_content(item) -> bool:
    """Return True if item is Indian/Bollywood content by country, language or keyword."""
    try:
        codes = set(item.vtag.getCountryCodes())
        if INDIAN_COUNTRIES & codes:
            return True
        langs = set(item.vtag.getLanguageCodes())
        if INDIAN_LANGUAGES & langs:
            return True
    except Exception:
        pass
    try:
        keywords = set((item.keywords or {}).keys())
        if INDIAN_KEYWORDS & keywords:
            return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Shared scraper utilities
# ---------------------------------------------------------------------------

# A film year 1900 - 2099 as its own word. A lookbehind / lookahead for a word
# boundary, but \b misses the underscore (a word char), so "Resident_Evil_2002"
# would hide the year; (?<![^\W_]) treats the underscore as a separator too.
RE_YEAR = re.compile(r"(?<![^\W_])(?:19|20)\d{2}(?![^\W_])")


def get_original_title(aliases: Sequence[SourceTitleAlias] | None) -> str:
    """Extract the original (non-localised) title from TMDB aliases, skipping non-Latin scripts."""
    return next(iter((a['title'] for a in aliases or () if a['country'] == 'original')), '')


def prepare_alias_search_list(aliases: Sequence[SourceTitleAlias], year: str | int) -> list[str]:
    """Clean raw TMDB aliases into a deduplicated list of search-compatible strings.

    Strips year, empty brackets, non-Latin scripts. Applies NFKC normalisation.
    """
    import unicodedata
    year_str = str(year)
    result = []
    for a in aliases:
        t = a['title'].replace(year_str, "").replace("()", "").strip()
        t = unicodedata.normalize("NFKC", t)
        t = re.sub(r' ?(\d)/', r' \1 ', t)  # ⅓-style fractions → "1 3"
        t = t.strip()
        if t and not detect_script(t):
            result.append(t)
    return deduplicate_list_ci(result)


def year_matches(text: str, expected_year: int, tolerance: int = 1) -> bool:
    """Check if any year found in text is within tolerance of expected_year."""
    if expected_year <= 0:
        return True
    years = [int(y) for y in RE_YEAR.findall(text)]
    if not years:
        return True
    return any(abs(yr - expected_year) <= tolerance for yr in years)


def format_episode_key(season, episode, with_wildcard: bool = False) -> str:
    """Format season/episode as sNNeNN (e.g. s01e05)."""
    s = str(int(season)).zfill(2)
    e = str(int(episode)).zfill(2)
    return f"s{s}*e{e}" if with_wildcard else f"s{s}e{e}"


def search_queries(title: str, local_title: str) -> Iterator[str]:
    """Yield deduplicated search queries: original title first, then local if different."""
    if title:
        yield title
    if local_title and cleantitle.get_simple(title or '') != cleantitle.get_simple(local_title):
        yield local_title


def search_queries_extended(title: str, local_title: str) -> Iterator[str]:
    """Yield deduplicated search query variants for sites with tricky search.

    Tries (in order, skipping duplicates per cleantitle):
      original → "." as ":" → "–"/"-" normalised → "." removed
    Extracted from old zaluknijcc.py manual search fallback chain.
    """
    seen: set = set()

    def _emit(s: str):
        s = s.strip()
        key = cleantitle.get_simple(s)
        if s and key not in seen:
            seen.add(key)
            return s
        return None

    titles = [title or "", local_title or ""]
    transforms = [
        lambda t: t,
        lambda t: t.replace(".", ":"),
        lambda t: t.replace("–", "-").replace(" - ", " "),
        lambda t: t.replace(".", ""),
    ]

    for fn in transforms:
        for t in titles:
            if v := _emit(fn(t)):
                yield v


# ---------------------------------------------------------------------------
# Country variant conflict detection (franchise show disambiguation)
# E.g. reject "The.Office.UK.S01E01" when searching for "The Office (US)".
# ---------------------------------------------------------------------------

# 2-letter country codes used as franchise variant identifiers in filenames.
# Intentionally excludes common English words: 'in', 'no', 'be', 'it'.
FRANCHISE_CC = frozenset({
    'uk', 'au', 'us', 'pl', 'de', 'fr', 'nl', 'se',
    'dk', 'fi', 'cz', 'hu', 'ro', 'tr', 'ru', 'il',
    'br', 'mx', 'ar', 'jp', 'kr', 'cn', 'pt', 'ch', 'za', 'nz', 'ca', 'es',
})
_EP_MARKER_RE = re.compile(r'^s\d{1,2}e\d{2,4}$')
_CC_NONALNUM_RE = re.compile(r'[^a-z0-9 ]')


def extract_alias_country_codes(aliases: Sequence[SourceTitleAlias], base_title: str) -> set[str]:
    """Extract 2-letter country codes from TMDB aliases that qualify the base title.
    E.g. "The Office (US)" alias + base "The Office" → {'us'}.
    Returns empty set if no qualifier found → country check is skipped.
    """
    base_words = set(_CC_NONALNUM_RE.sub(' ', base_title.lower()).split())
    result = set()
    for a in (aliases or []):
        if alias_str := a['title']:
            words = _CC_NONALNUM_RE.sub(' ', alias_str.lower()).split()
            if len(words) >= 2 and words[-1] in FRANCHISE_CC and base_words.issubset(set(words)):
                result.add(words[-1])
    return result


def detect_country_variant_conflict(filename_words_lower: list[str], titles: Iterable[str]) -> str | None:
    """Return a conflicting 2-letter country code if the filename appears to be a
    country-specific remake that doesn't match our search target, else None.

    Scans ALL words before the SxxExx episode marker for franchise country codes.
    Using all-pre-episode words (not just the adjacent ones) correctly handles
    patterns like "The.Office.PL.Pilot.S01E01" where an episode name sits between
    the country code and the episode marker.

    If titles carry no country qualifier, returns None (no filter applied).

    Args:
        filename_words_lower: list of lowercase words (dots/special chars stripped).
        titles: iterable of search title strings (any case/format).
    """
    ep_idx = next((i for i, w in enumerate(filename_words_lower) if _EP_MARKER_RE.match(w)), None)
    if ep_idx is None or ep_idx == 0:
        return None

    # Collect all franchise CCs that appear before the episode marker
    cc_in_pre_ep = {w for w in filename_words_lower[:ep_idx] if w in FRANCHISE_CC}
    if not cc_in_pre_ep:
        return None

    # Collect expected country codes from TMDB-provided titles (e.g. "the office us" → 'us')
    our_countries = set()
    for t in titles:
        words_t = _CC_NONALNUM_RE.sub(' ', t.lower()).split()
        if len(words_t) >= 2 and words_t[-1] in FRANCHISE_CC:
            our_countries.add(words_t[-1])

    if not our_countries:
        return None

    conflicts = cc_in_pre_ep - our_countries
    return next(iter(conflicts)) if conflicts else None


def check_parsed_title_cc(parsed_title: str, search_title: str, expected_cc: set[str]) -> str | None:
    """Return a conflicting country code if parsed_title has an extra CC not in expected_cc.
    Returns None if no conflict or expected_cc is empty (→ no check performed).
    Used by scrapers that compare the already-extracted title portion of a filename.
    """
    if not expected_cc:
        return None
    parsed_words = set(_CC_NONALNUM_RE.sub(' ', parsed_title.lower()).split())
    search_words = set(_CC_NONALNUM_RE.sub(' ', search_title.lower()).split())
    for word in parsed_words - search_words:
        if word in FRANCHISE_CC and word not in expected_cc:
            return word
    return None


def build_alias_list(title: str, local_title: str, aliases: Sequence[SourceTitleAlias], year: int) -> list[str]:
    """Build deduplicated alias list: title + local_title + originalname + filtered alias titles."""
    seen: dict[str, None] = {}
    year_str = str(year)

    def _add(t: str) -> None:
        t = t.strip() if t else ""
        if t:
            seen[t] = None

    _add(title)
    _add(local_title)
    _add(get_original_title(aliases))

    for alias_item in aliases:
        alias_title = alias_item['title']
        alias_title = alias_title.replace(year_str, "").replace("()", "").strip()
        if alias_title and not detect_script(alias_title):
            _add(alias_title)

    return list(seen)


def build_relevant_franchises(titles: list[str], franchise_names: dict[str, list[str]], sep: str) -> dict[str, list[str]]:
    """Return the subset of *franchise_names* patterns relevant to *titles*.

    Builds escaped regex patterns for each franchise name and returns only
    the entries whose key appears in at least one of the given titles.
    """
    franchise_aliases = {
        k: [sep.join(map(re.escape, n.split())) for n in v]
        for k, v in franchise_names.items()
    }
    relevant: dict = {}
    for t in titles:
        tl = t.lower()
        for key, patterns in franchise_aliases.items():
            if key.lower() in tl:
                relevant[key] = patterns
    return relevant


# ---------------------------------------------------------------------------
# Warez filename utilities  (shared across Polish scrapers)
# ---------------------------------------------------------------------------

_WAREZ_TOKENS_PAT = (
    r"po?l(?:dub|sub)?|lektor|dubbing|subbed|napisy|polish"
    r"|eng?|de|fr|es|it|nl|us|dual|multi|p2p"
    r"|bluray|blu-ray|bdrip|brip|hdrip|dvdrip|hdtv|hddvd|hdcam"
    r"|web[.\-]?dl|webrip|webhdrip|remux|3d|imax"
    r"|cam(?:rip)?|ts|telesync|tc|telecine|scr|screener|r5"
    r"|fullhd|uhd|4k|2160p|1080p|720p|480p|hdr|sdr"
    r"|bd|dvd|proper|repack|retail|extended|theatrical|unrated"
    r"|amzn|nf|dsnp|hmax|atvp|md|x264|x265|hevc|avc|web"
    r"|s\d{1,2}(?:e\d{1,3})?|sezon|odcinek|ep(?:isode)?"
)
WAREZ_TOKENS_RE = re.compile(r'\b(?:' + _WAREZ_TOKENS_PAT + r')\b', re.IGNORECASE)

_RE_FN_EXT         = re.compile(r'\.\w{2,4}$')
_RE_FN_YEAR_PAR    = re.compile(r'^(.+?)\s*\((\d{4})\)')
_RE_FN_EP          = re.compile(
    r'[Ss](?P<sea>\d{1,2})[Ee](?P<ep>\d{1,2})'
    r'|(?P<sea2>\d{1,2})[xX](?P<ep2>\d{1,2})'
    r'|(?:cz\.|odc\.|ep\.)\s*(?P<ep3>\d{1,3})',
    re.IGNORECASE,
)
_RE_FN_YEAR_BARE   = re.compile(
    r'^(.+?)\s+(\d{4})\s+(?:V\d+\s+)?(?:' + _WAREZ_TOKENS_PAT + r')',
    re.IGNORECASE,
)
_RE_FN_TITLE_TRAIL = re.compile(
    r'[\s.]+(?:4[Kk]|UHD|HDTV|WEB[\s.-]?DL|WEBRip|BluRay|BDRip|BRRip|DVDRip|\d{3,4}[pPiI])\s*$',
    re.IGNORECASE,
)
_RE_FN_ARTICLE     = re.compile(r'^(?:the|a|an)\s+', re.IGNORECASE)
_RE_FN_ROMAN       = re.compile(r'\b(viii|vii|vi|iv|ix|iii|ii|x|v|i)\b', re.IGNORECASE)
_RE_EP_RANGE       = re.compile(r"(?:s([\dO]{2})-?)?e(\d{2,4})-e?(\d{2,4})(?!\w)", re.I)
_RE_EP_UNIV2       = re.compile(
    r"(S\d{2})?[.,-]?(E(\d{2,4}))".replace(r"\d", r"[\dO]"),
    re.I,
)
# Year pattern for warez filenames: handles OCR O/0 substitution (e.g. 2O2O → 2020).
# An underscore separates words too ("Resident_Evil_2002_MULTi"), so no \b.
# Use this when matching years in filenames from warez sources (xt7, tb7, etc.).
RE_YEAR_FILENAME = re.compile(r'(?<![^\W_])(19[\dOo]{2}|2[Oo0][\dOo]{2})(?![^\W_])')

# Full episode-marker pattern: S01E05, .E05, cz., odc., ep., episode, odcinek, (05), - 05 [-, 1x05
# Used to detect TV episode filenames (e.g. to reject them in movie searches).
RE_EPISODE_FILENAME = re.compile(
    r'((S[\dO]{1,2})?[.,-]?E[\dO]{2,4}|\bcz\.|\bodc\.|\bep\.|episode|odcinek'
    r'|[\(\[]\d{2,3}[\)\]]|\- \d{2,3} [([-]|\b\dx\d{2}\b)',
    re.I,
)

# Season and episode in words (groups: season, episode): "Season.4.Odcinek.07", "Sezon 1 - Odcinek 7", "Season 2 Episode 3".
# The episode word is required: "The.Final.Season.07" is not season 7.
RE_SEASON_EPISODE_WORDS = re.compile(
    r'(?<![^\W_])(?:season|sezon)[\W_]{0,3}0*(\d{1,2})[\W_]{1,5}(?:odcinek|odc|episode|ep)\.?[\W_]{0,3}0*(\d{1,4})(?!\d)',
    re.I,
)


def is_episode_filename(filename: str) -> bool:
    """Return True if *filename* contains a TV-episode marker (S01E01, odc., etc.).

    Use this to reject episode files when the search target is a movie.
    """
    return bool(RE_EPISODE_FILENAME.search(filename))


def parse_filename_title(filename: str) -> ParsedFilename:
    """Parse a warez filename into {title, year, season, episode}."""
    normalized = _RE_FN_EXT.sub('', filename).replace('.', ' ').replace('_', ' ')
    year_match = _RE_FN_YEAR_PAR.match(normalized)
    ep_match   = _RE_FN_EP.search(normalized)
    if year_match:
        title = year_match.group(1).strip()
        year  = int(year_match.group(2))
    elif ep_match:
        title = normalized[:ep_match.start()].strip()
        year  = None
    else:
        bare  = _RE_FN_YEAR_BARE.match(normalized)
        title = bare.group(1).strip() if bare else normalized
        year  = int(bare.group(2)) if bare else None
    # Strip trailing quality/source tokens repeatedly — a quality marker placed
    # before the episode marker (e.g. "Mandalorian 480p S01E01...") would otherwise
    # stay glued to the extracted title, and a chain of tokens ("Title 720p WEB-DL")
    # needs more than one pass to fully peel off.
    previous_title = None
    while previous_title != title:
        previous_title = title
        title = _RE_FN_TITLE_TRAIL.sub('', title).strip()
    if ep_match:
        sea         = ep_match.group('sea')  or ep_match.group('sea2')
        ep          = ep_match.group('ep')   or ep_match.group('ep2') or ep_match.group('ep3')
        season_val  = int(sea) if sea else 1
        episode_val = int(ep)  if ep  else None
    else:
        season_val = episode_val = None
    return {'title': title, 'year': year, 'season': season_val, 'episode': episode_val}


def build_title_pattern(title: str) -> str:
    """Build a flexible filename-matching regex pattern from a title string.

    Handles diacritics, Roman numerals, numbers-as-words, fractions, and
    non-alphanumeric separators.  Ported from tb7's prepare_pattern_for_titles_v2.
    """
    title   = title.lower()
    pattern = re.sub(r'([^\w&]+)', r"[\1 .–-]+", title)
    pattern = re.sub(r'(\[[^ \w]+ \.–\-\])\+', r'\1*', pattern)
    pattern = pattern.replace("[^", r"[\^").replace("[]", r"[\]").replace("[[", r"[\[")
    pattern = re.sub(
        r"(?<=\[)\W+?(?= \.–-])",
        lambda x: "".join(dict.fromkeys(re.sub("[ .–-]", "", x[0]))),
        pattern,
    )
    pattern = pattern.replace(r"&", r"(\&|and|i)")
    sp      = "[ .–-]+"
    pattern = re.sub(
        rf'(\d{re.escape(sp)})((\d){re.escape(sp)}(\d({re.escape(sp)})?))' ,
        rf'\1(i{sp})?\3[ .,/-]\4',
        pattern,
    )
    pattern = re.sub(rf'(\d)({re.escape(sp)})([a-zA-Z])', r'\1\2*\3', pattern).replace("+*", "*")
    pattern = numbers_in_pattern(pattern)
    pattern = normalize_unicode_in_pattern(pattern)
    return pattern


def build_title_filters(titles: Iterable[str], title: str = '', is_episode: bool = False,
                        ext_pat: str = '(avi|mkv|mp4|mpg|mov|ts|mts|2ts)') -> tuple[re.Pattern[str], re.Pattern[str] | None]:
    """Build filename title-matching regexes (ported from tb7).

    Unlike get_simple-based matching, the patterns keep digits in titles
    ("1923") and allow year / resolution / language tokens between the title
    and the episode marker ("SEAL.Team.2019.PL.S03E11").

    Returns ``(title_filter, title_filter2)``; the second one is only built
    for episodes (title placed after the episode marker) and is ``None``
    for movies.
    """
    # Build titles list for pattern matching
    title_list: list[str] = list(dict.fromkeys(title_variant.lower() for title_variant in titles if title_variant))

    # Add simplified versions of titles (only for matching, not for queries)
    extra_titles: list[str] = []
    for title_variant in title_list:
        # Remove prefixes: the, a, an
        if title_variant.startswith(('the ', 'a ', 'an ')):
            stripped: str = re.sub(r'^(the|a|an) ', '', title_variant, flags=re.IGNORECASE)
            if stripped not in title_list and stripped not in extra_titles:
                extra_titles.append(stripped)

        # Remove episode suffix (.s01e06 or .s01) from search queries
        ep_suffix: re.Match[str] | None = re.search(r'[. ]s\d{1,2}e\d{1,4}$|\.s\d{1,2}$', title_variant, flags=re.I)
        if ep_suffix:
            base: str = title_variant[:ep_suffix.start()]
            if base not in title_list and base not in extra_titles:
                extra_titles.append(base)

        # Add version without separators, e.g. "f1 film" -> "f1film"
        alnum_t: str = re.sub(r'[^a-zA-Z0-9]', '', title_variant)
        if len(alnum_t) > 2 and alnum_t != title_variant and alnum_t not in title_list and alnum_t not in extra_titles:
            extra_titles.append(alnum_t)

    if extra_titles:
        title_list += extra_titles

    if title and title not in title_list:
        title_list = [title] + title_list

    title_list = add_colon_reversed_titles(title_list)

    titles_pat_list: list[str] = list(dict.fromkeys(build_title_pattern(title_variant) for title_variant in title_list))

    title_pat: str = f"({'|'.join(titles_pat_list)})"

    # Year pattern (1900 - 2099)
    year_universal_pat: str = r'\b(19\d[\dOo]|2[Oo0][\dOo]{2})\b'

    # Resolution pattern
    res_pat: str = r'\b(SD|HD|UHD|2k|4k|480p?|540p?|576p?|720p?|1080[pi]?|1440p?|2160p?)\b'
    # Pattern for commonly occurring phrases
    custom_pat: str = r'\b(lektor|subbed|napisy|dubbing|polish|po?l(dub|sub)?|us|fr|de|dual|multi|p2p|web[.-]?(dl)?|remux|3d|imax)\b'

    # Group name pattern (should be at the very beginning)
    group_pat: str = r'^[.[][^.[\]]{3,}[.\]]'

    if not is_episode:  # For movies
        after_pat: str = fr"(\[\w*?\]|{res_pat}|{custom_pat}|{ext_pat}$)"

        movie_filter: re.Pattern[str] = re.compile(
            rf"^(\d{{1,2}}|{year_universal_pat}|{group_pat})?[ .-]*(\W?{title_pat}((?<!\d)\d|[ .-]1)?[ ./()-]{{1,4}})+((?<=[(])\d[)])?[ .-]?[(\[]?({year_universal_pat}|{after_pat})",
            flags=re.I)
        return movie_filter, None

    # For TV shows
    # Matches: S01E05, .e05, cz., odc., ep., episode, odcinek, (05), - 05 [-, 1x05, bare 2-3 digit number
    episode_universal_pat: str = r'((S\d{1,2})?[.,-]?E\d{2,4}|\bcz\.|\bodc\.|\bep\.|episode|odcinek|[\(\[]\d{2,3}[\)\]]|\- \d{2,3} [([-]|\b\dx\d{2}\b)'
    episode_universal_pat = episode_universal_pat.replace(r'\d', r'[\dO]').replace('0', '[0O]')
    episode_universal_pat = episode_universal_pat[:-1] + r'|\b\d{2,3}\b)'

    episode_universal_pat2: str = r'(S\d{2})?[.,-]?(E(\d{2,4}))'
    episode_universal_pat2 = episode_universal_pat2.replace(r'\d', r'[\dO]')

    # the season in words may go before the episode one ("Attack.on.Titan.Season.4.Odcinek.07", "Sezon 1 - Odcinek 7")
    season_words_pat: str = r'((season|sezon)[ ._-]*\d{1,2}[ ._-]*)?'

    title_filter: re.Pattern[str] = re.compile(
        rf"(^({group_pat})?|[/-]|\d{{1,2}})[ .]?(\W?{title_pat}((?<!\d)\d|[ .-]1)?[ ./()-]{{1,4}})+((?<=[(])\d[)])?[ .-]?[([]?([ .-]*({res_pat}|{year_universal_pat}|{custom_pat}))*[)\]]?[ .-]*{season_words_pat}[([]?{episode_universal_pat}",
        flags=re.I,
    )

    title_filter2: re.Pattern[str] = re.compile(
        rf"(^\d{{1,2}}\.?\W?|[([]?{episode_universal_pat2}\W*){title_pat}([ .]*[/-]|[ .]{{2,}})",
        flags=re.I
    )
    return title_filter, title_filter2


def _levenshtein(a: str, b: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > 2:
        return abs(la - lb)
    if la == 0:
        return lb
    if lb == 0:
        return la
    if la < lb:
        a, b, la, lb = b, a, lb, la
    prev = list(range(lb + 1))
    for i in range(1, la + 1):
        curr = [i] + [0] * lb
        for j in range(1, lb + 1):
            cost   = 0 if a[i - 1] == b[j - 1] else 1
            curr[j] = min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        prev = curr
    return prev[lb]


def match_filename_to_titles(filename: str, titles: Iterable[str], season: str | int | None = None, episode: str | int | None = None) -> tuple[bool, str]:
    """Check if *filename* matches any of the given *titles*.

    Step 1: sliding-window word match (rapideo-style).
    Step 2: Levenshtein fallback on the parsed filename title.

    Returns ``(matched: bool, reason: str)``.
    """
    normalized = re.sub(r'[^a-zA-Z0-9]+', ' ', cleantitle.normalize(filename)).lower()
    words      = normalized.split()
    seen_lower = {t.lower() for t in titles}

    # Multi-word sliding window
    for t in (t for t in titles if ' ' in t):
        twords = t.lower().split()
        for i in range(len(words) - len(twords) + 1):
            if words[i:i + len(twords)] == twords:
                if season and episode:
                    conflict = detect_country_variant_conflict(words, titles)
                    if conflict:
                        return False, f"country variant conflict ({conflict})"
                return True, f"multi-word title match ({t})"

    # Single-word check
    for t in (t for t in titles if ' ' not in t):
        tl = t.lower()
        if season and episode:
            for idx, word in enumerate(words):
                if not word.startswith(tl):
                    continue
                rest = word[len(tl):]
                if rest and rest[0].isalpha():
                    continue
                if idx + 1 < len(words):
                    nw = words[idx + 1]
                    if (
                        not re.search(r'^\d{4}$', nw)
                        and not WAREZ_TOKENS_RE.search(nw)
                        and nw not in seen_lower
                    ):
                        continue
                return True, f"single-word title match ({t})"
        else:
            if words and words[0] == tl:
                if len(words) == 1:
                    return True, f"single-word title match ({t})"
                for word in words[1:]:
                    if re.search(r'^\d{4}$', word) or WAREZ_TOKENS_RE.search(word) or word in seen_lower:
                        return True, f"single-word title match ({t})"
                    break

    # Levenshtein fallback on parsed filename title
    parsed_title = parse_filename_title(filename).get('title', '')
    if parsed_title:
        candidate = re.sub(r'[^a-zA-Z0-9]+', ' ', cleantitle.normalize(parsed_title)).lower().strip()
        variants  = {candidate}
        stripped  = _RE_FN_ARTICLE.sub('', candidate)
        if stripped != candidate:
            variants.add(stripped)
        all_variants = set()
        for v in variants:
            all_variants.add(v)
            roman_conv = _RE_FN_ROMAN.sub(lambda m: str(roman_to_int(m.group(0))), v)
            if roman_conv != v:
                all_variants.add(roman_conv)
        alias_cleans = {cleantitle.get_simple(t) for t in titles}
        for cv in all_variants:
            clean = cleantitle.get_simple(cv)
            if clean and (clean in alias_cleans or any(_levenshtein(clean, a) <= 2 for a in alias_cleans if a)):
                return True, "fuzzy title match"

    return False, ""


# ---------------------------------------------------------------------------
# Shared parsed-title matching  (used by rapideo / tb7)
# ---------------------------------------------------------------------------

_RE_FN_GROUP_TAG = re.compile(r'^\s*\[[^\]]+\]\s*')


def build_alias_cleans(titles: Iterable[str]) -> set[str]:
    """Build a set of get_simple-cleaned strings for use with match_parsed_title.

    Handles 'Show: Subtitle' splitting, reversed subtitle ordering, Roman<->Arabic
    numeral conversion (e.g. alias "Episode IV" also matches filename "Episode 4"),
    leading-article stripping (e.g. alias "The Lord of the Rings..." also matches a
    filename released as "Lord of the Rings..."), and filters out parts shorter than
    3 characters after cleaning.
    """
    alias_cleans: set[str] = set()

    def add_clean(text: str, *, min_len: int = 0) -> None:
        """Clean *text* and add it (plus its Roman-numeral and leading-article
        variants) to alias_cleans. Applied to whole titles, split parts and the
        reversed subtitle form alike, so none of those miss either conversion."""
        if not text:
            return
        candidates = {text}
        for cand in list(candidates):
            roman_conv = _RE_FN_ROMAN.sub(lambda m: str(roman_to_int(m.group(0))), cand)
            candidates.add(roman_conv)
        for cand in list(candidates):
            stripped = _RE_FN_ARTICLE.sub('', cand)
            candidates.add(stripped)
        for cand in candidates:
            clean = cleantitle.get_simple(cand)
            if clean and len(clean) >= min_len:
                alias_cleans.add(clean)

    for title in filter(None, titles):
        title_norm = cleantitle.normalize(title)
        variants = [title, title_norm] if title_norm != title else [title]
        for variant in variants:
            add_clean(variant)
            for sep in (' - ', ': '):
                for part in variant.split(sep):
                    add_clean(part.strip(), min_len=3)
            if ': ' in variant:
                head, _, tail = variant.partition(': ')
                add_clean(f'{tail} {head}')
    return alias_cleans


def match_parsed_title(title: str, alias_cleans: set[str]) -> bool:
    """Check if an already-parsed title string matches any entry in alias_cleans.

    Strips leading [GROUP] tag, splits on ' - ' separators, handles English
    articles and Roman numerals, then compares via get_simple + Levenshtein(≤2).
    """
    title = _RE_FN_GROUP_TAG.sub('', title).strip()
    parts = [p.strip() for p in title.replace(': ', ' - ').split(' - ') if p.strip()]
    if not parts:
        return False
    for part in parts:
        variants: set[str] = {part}
        stripped = _RE_FN_ARTICLE.sub('', part)
        if stripped != part:
            file_article = part[:len(part) - len(stripped)].strip().lower()
            # "A Teacher" is not "The Teacher": drop the article only when the searched
            # title does not carry a different one
            if not any(cleantitle.get_simple(f'{article} {stripped}') in alias_cleans
                       for article in ('the', 'a', 'an') if article != file_article):
                variants.add(stripped)
        all_variants: set[str] = set()
        for v in variants:
            all_variants.add(v)
            roman_conv = _RE_FN_ROMAN.sub(lambda m: str(roman_to_int(m.group(0))), v)
            if roman_conv != v:
                all_variants.add(roman_conv)
        for cv in all_variants:
            clean = cleantitle.get_simple(cv)
            if not clean:
                continue
            if clean in alias_cleans:
                return True
            # a typo keeps the first letter - otherwise "reacher"~"teacher", "ark"~"dark" pass as the same title
            if len(clean) >= 3 and any(a[0] == clean[0] and _levenshtein(clean, a) <= (1 if ' ' not in a else 2) for a in alias_cleans if a):
                return True

    # Fallback: handle filenames where PL + EN titles are concatenated without separator
    # e.g. "Maszyna.do.zabijania.War.Machine.2026" → parsed "Maszyna do zabijania War Machine"
    # → clean "maszynadozabijaniawarmachine" = concat of two alias_cleans.
    # Also handles typos in one part, with an edit budget that scales with length
    # so a short leftover word isn't taken for a typo'd title
    # (e.g. "Lucky.Luke" → "lucky" + "luke", and "luke" is 2 edits from "lucky").
    def _ac_matches(segment: str) -> bool:
        return segment in alias_cleans or (
            len(segment) >= 6
            and any(_levenshtein(segment, a) <= min(2, (len(segment) - 2) // 4) for a in alias_cleans if a)
        )

    full_clean = cleantitle.get_simple(' '.join(parts))
    for ac in alias_cleans:
        if not ac or len(ac) < 4:
            continue
        if full_clean.startswith(ac):
            remainder = full_clean[len(ac):]
            if remainder and _ac_matches(remainder):
                return True
        if full_clean.endswith(ac):
            prefix = full_clean[:-len(ac)]
            if prefix and _ac_matches(prefix):
                return True

    return False


def match_filename_title_parsed(filename: str, alias_cleans: set[str]) -> bool:
    """Convenience wrapper: parse filename title then call match_parsed_title."""
    return match_parsed_title(parse_filename_title(filename)['title'], alias_cleans)


def check_year_in_filename(filename: str, year: int | str | None, premiered: str | None, year_in_title: str = '', current_year: int = 0,
                           episode_year: int = 0) -> bool | None:
    """Check whether the year embedded in *filename* matches *year* / *premiered*.

    *episode_year* (air year of the searched episode) caps how late a season
    year in the filename may be, so a later remake with the same title is
    still rejected.

    Returns ``True`` (match), ``False`` (mismatch), or ``None`` (no year found).
    """
    if not premiered and not year:
        return None
    if year_in_title:
        filename = filename.replace(year_in_title, "")
    m = re.search(r"(?<![^\W_])\d{4}(?![^\W_])", filename)
    if m:
        found = m[0]
        if not current_year:
            import time
            current_year = int(time.strftime('%Y'))
        if 1900 <= int(found) <= int(current_year) + 1:
            if (
                (premiered and (premiered.startswith(found) or premiered.endswith(found)))
                or (year and str(year) == found)
            ):
                return True
            # A later year is usually the season/episode air year (e.g. "SEAL.Team.2019.S03E11"
            # for a 2017 show); a year before the show started, or after the episode aired
            # (a remake), points to a different show.
            show_years: list[int] = [int(show_year) for show_year in (str(year or ''), (premiered or '')[:4]) if show_year.isdigit()]
            if show_years and int(found) > min(show_years) and (not episode_year or int(found) <= episode_year + 1):
                return True
            return False
    return None


def filename_passes_episode(filename, season, episode, absolute_episode=None):
    """Return ``True`` if *filename* contains the expected season/episode marker.

    Handles S01E05 notation, O/0 letter substitution, episode ranges, and
    anime absolute episode numbers.  Always returns ``True`` when *season* or
    *episode* are falsy.
    """
    if not season or not episode:
        return True

    season_int  = int(season)
    episode_int = int(episode)
    season_num  = f"{season_int:02d}"

    # season and episode in words decide alone ("Season.4.Odcinek.07" is S04E07, not S01E07 by its "Odcinek 07")
    if words := RE_SEASON_EPISODE_WORDS.search(filename):
        return int(words[1]) == season_int and int(words[2]) == episode_int

    # Main sXXeYY pattern
    ep_pat = rf"s0?{season_int}[.,-]?e(\d{{2,4}}-?)?e?0?{episode_int}(?!\d)"
    if season_num == "01":
        ep_pat = (
            rf"({ep_pat}"
            rf"|(?<![se]\d{{1}}[.,-])(?<![se]\d{{1}})(?<![se]\d{{2}}[.,-])(?<![se]\d{{2}})"
            rf"(?<!e\d{{3}}[.,-])(?<!e\d{{3}})(?<!e\d{{4}}[.,-])(?<!e\d{{4}})"
            rf"e(\d{{2,4}}-?)?e?0?{episode_int}(?!\d))"
        )
    ep_pat = ep_pat.replace(r"\d", r"[\dO]").replace("0", "[0O]")
    ep_re  = re.compile(ep_pat, re.I)

    # Season-1 alternative patterns (cz./odc./ep. markers)
    if season_num == "01":
        ep2_pat = (
            rf"(?<!\d[2-9])[ .](cz\.|odc\.|ep\.|episode|odcinek)[ .-]{{,3}}0{{,2}}{episode_int}\b"
            rf"|[([]0{{,2}}{episode_int}[)\]](?!\.[a-z]{{2,3}}$)"
            rf"|\- 0{{,2}}{episode_int} [([-]"
            rf"|\b0?{season_int}x0{{,2}}{episode_int}\b"
            rf"|\b0{{,2}}{episode_int}\.[a-z]{{2,3}}$"
            rf"|[a-z][ .]0{{,2}}{episode_int}[ .][a-z]"
        )
        ep2_pat = ep2_pat.replace("0", "[0O]")
        ep2_re = re.compile(ep2_pat, re.I)
    else:
        ep2_re = re.compile("impossibletomatch")

    abs_ep_re = None
    if absolute_episode:
        abs_ep_re = re.compile(rf"\be0*{int(absolute_episode)}(?!\d)", re.I)

    def _ep_in_range(fn):
        rang = _RE_EP_RANGE.search(fn)
        if rang:
            s_grp = rang.group(1)
            if (not s_grp and season_int == 1) or (s_grp and int(s_grp.replace('O', '0')) == season_int):
                return episode_int in range(int(rang.group(2)), int(rang.group(3)) + 1)
        return False

    return bool(
        ep_re.search(filename)
        or _ep_in_range(filename)
        or (not _RE_EP_UNIV2.search(filename) and ep2_re.search(filename))
        or (abs_ep_re and abs_ep_re.search(filename))
    )


# =============================================================================
# Shared types for PL scrapers
# =============================================================================

class ShowDataDict(TypedDict):
    """Typed-dict form of ShowData — tvshow() return value / episode() url parameter."""
    title: str
    local_title: str
    aliases: list[SourceTitleAlias]  # TODO: convert to Sequence
    year: int
    tmdb: str | None


@frozen
class ShowData:
    """Carries show identity between tvshow() and episode() calls.

    Serialised to dict by tvshow() via show_data_asdict(), deserialised in episode() via ShowData(**url).
    """
    title: str
    local_title: str
    aliases: list[SourceTitleAlias]  # TODO: convert to Sequence
    year: int
    tmdb: str | None = None


def show_data_asdict(sd: ShowData) -> ShowDataDict:
    """Return ShowData as a plain dict (wraps attrs asdict)."""
    return _attrs_asdict(sd)  # type: ignore[return-value]


def confirm_transfer_dialog(filename: str, charge: str = "", remaining: str = "", note: str = "") -> bool:
    """Show a 'confirm download / transfer cost' yesno dialog.

    Closes any open notification popup first, then shows:
      <note>                                       (if provided)
      [I]filename[/I]
      Od transferu zostanie odliczone: <charge>   (if provided)
      Aktualnie posiadasz: <remaining>             (if provided)

    Returns True when the user confirms ("Pobierz"), False on cancel.
    """
    import xbmcgui
    from lib.ff import control as _control
    body = f"{note}\n" if note else ""
    body += f"[I]{filename}[/I]"
    if charge:
        body += f"\nOd transferu zostanie odliczone: [B]{charge.replace(' ', chr(0xa0))}[/B]"
    if remaining:
        body += f"\nAktualnie posiadasz: [B]{remaining.replace(' ', chr(0xa0))}[/B]"
    if _control.condVisibility('Window.IsActive(notification)'):
        _control.execute('Dialog.Close(notification,true)')
    return xbmcgui.Dialog().yesno(
        "Czy chcesz pobrać ten plik?",
        body,
        yeslabel="Pobierz",
        nolabel="Anuluj",
    )


def add_colon_reversed_titles(titles: list[str]) -> list[str]:
    """Append colon-reversed variants to *titles* and return the extended list.

    For any title containing ': ' but no '-', adds the reversed form:
      "Spirited Away: In the Land of Gods"  ->  "In the Land of Gods - Spirited Away"

    Used by the three PL premium scrapers when building the title filter list.
    """
    tmp = []
    for t in titles:
        if ': ' in t and '-' not in t:
            rev = ' - '.join(t.split(': ')[::-1])
            if rev not in titles and rev not in tmp:
                tmp.append(rev)
    return titles + tmp
