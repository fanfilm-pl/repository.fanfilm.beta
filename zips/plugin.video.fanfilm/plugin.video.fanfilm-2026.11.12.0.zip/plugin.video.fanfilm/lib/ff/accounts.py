"""
User data service accounts.

A service type (Trakt, TMDB, ...) declares what it can do; an account is an instance of a type. One rule tells
whether an account is enabled for a capability (progress, watched, ratings, lists) in a direction (read, write).

Accounts are configured in `config.json` (`/accounts`, see `lib.ff.config`): the order is the priority, the type name is the
alias of the first account of the type. The data of an account (tokens, keys, cookies, profile, sync cursors) are in
`accounts.db`. An inactive account (`active: false`) keeps its data and affects nothing. The accounts of the settings
(of old versions) are migrated once (`lib.ff.account_migration`).
"""

from __future__ import annotations
from typing import Any, Callable, ClassVar, Generator, Iterable, Mapping, Sequence, cast, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from threading import Lock, RLock, local
from contextlib import contextmanager
import re
from attrs import frozen, field
from .config import ConfigStore, config
from .logs import fflog, fflog_exc
from ..kolang import L
if TYPE_CHECKING:
    from . import requests
    from ..indexers.lists.menu import MediaVariant
    from cdefs import RatingAction, RatingServiceName, ListSection
    from .ratings import RatingScale

#: What kind of user data: playback progress (resume point, scrobble), watched state (history, show progress),
#: user ratings, lists (watchlist, favorites, collection, own lists, ...).
Capability: TypeAlias = Literal['progress', 'watched', 'ratings', 'lists']
#: Direction of user data: `read` – the account is a source (menus, resume, merge), `write` – a sink (scrobble, Add-to, rate).
Direction: TypeAlias = Literal['read', 'write']
#: Account state: `authorized` – full rights of the type, `public` – only a user ID (read public data), `none` – unusable.
AuthState: TypeAlias = Literal['authorized', 'public', 'none']
#: Capabilities with their directions (string: `dict[]` / `frozenset[]` are not subscriptable in py3.8).
Capabilities: TypeAlias = 'dict[Capability, frozenset[Direction]]'

#: Read only.
READ: frozenset[Direction] = frozenset(('read',))
#: Read and write.
READ_WRITE: frozenset[Direction] = frozenset(('read', 'write'))
#: Switch cell: `capability.direction`, e.g. `progress.write` (§ 1 of the account model).
SwitchCell: TypeAlias = str
#: Switches of cells (string: `dict[]` is not subscriptable in py3.8).
Switches: TypeAlias = 'dict[SwitchCell, bool]'
#: Cells needed by a cell (string: `dict[]` / `tuple[]` are not subscriptable in py3.8).
Requires: TypeAlias = 'dict[SwitchCell, tuple[SwitchCell, ...]]'
#: A menu of lists an account can be hidden in (its switch cell `menu.<id>`; no switch - shown).
ListMenuId: TypeAlias = Literal['lists', 'movies', 'shows', 'persons', 'history']
#: The menus of lists in their order (the switches of an account).
LIST_MENU_IDS: tuple[ListMenuId, ...] = ('lists', 'movies', 'shows', 'persons', 'history')
#: The menu switches of an account in no menu of lists by default (the local Kodi: its rows are in Kodi itself).
HIDDEN_IN_MENUS: Switches = {f'menu.{menu}': False for menu in LIST_MENU_IDS}
#: A scrobble stop marks watched (Trakt, MDBList): sending progress needs sending watched.
SCROBBLE_REQUIRES: Requires = {'progress.write': ('watched.write',)}


@frozen(kw_only=True)
class GeneralList:
    """
    A general list of a service type (no account): what the menus and the window of general lists need of it. Its targets
    are of the indexer of the type (`ServiceLists.general_targets()`, `ServiceLists.general_entries()` joins them).
    """

    #: The key of the list in the type (stable: the user switches are stored by it, `lib.ff.lists_config`).
    key: str
    #: The label.
    label: Callable[[], str]
    #: The media variants (empty - one target without media, e.g. lists of lists: the menus without a media only).
    variants: tuple[MediaVariant, ...] = ()
    #: The thumb ('' - the one of the kind).
    thumb: str = ''
    #: The menus it is shown in by default (`ListMenuId`; the user switches, `lists_config.general_switched()`): none - the
    #: defaults are silent, the user switches a list on in the tab of general lists.
    places: tuple[ListMenuId, ...] = ()


@frozen
class ServiceType:
    """Service type: what the service can do in FanFilm."""

    #: Type name: the alias of the first account of the type (addresses, list pointers, module clients); the ID of the
    #: only account of a type without accounts per user (`multi` false).
    name: str
    #: Service name for UI.
    label: str
    #: Supported capabilities and their directions.
    capabilities: Capabilities = field(factory=dict)
    #: What a public account (a user ID only, no authorization) can do.
    public: Capabilities = field(factory=dict)
    #: True if the type has accounts of users (any number, removable); others have one account with the type name as its ID.
    multi: bool = False
    #: Factory of the API client of an account, `module:function` (None: the module client, the type alias), '' - none.
    client: str = ''
    #: Default user switches of cells (`progress.write`), a cell not given is on; an account overrides them (its
    #: `switches` field of its entry in `/accounts`).
    switches: Switches = field(factory=dict)
    #: Couplings: a cell is on only if the cells it needs are on (the account view shows "needed by").
    requires: Requires = field(factory=dict)
    #: The application client of the general lists of the type in its menu (`module:object`), '' - none. General
    #: lists (e.g. Trakt trending lists) are of the type, not of an account: they work without accounts.
    general: str = ''
    #: The general lists of the type in their order.
    general_lists: tuple[GeneralList, ...] = ()


#: All service types, the order is the order of accounts.
SERVICE_TYPES: dict[str, ServiceType] = {srv.name: srv for srv in (
    ServiceType('tmdb', 'TMDB', {'ratings': READ_WRITE, 'lists': READ_WRITE}, multi=True, client='lib.api.tmdb:make_client'),
    ServiceType('wetrakr', 'WeTrakr', {'progress': READ_WRITE, 'watched': READ_WRITE, 'ratings': READ_WRITE, 'lists': READ_WRITE},
                public={'lists': READ, 'ratings': READ}, multi=True, client='lib.api.wetrakr:make_client', requires=SCROBBLE_REQUIRES,
                general='lib.api.wetrakr:wetrakr_app',
                # the movies and the shows apart (not variants of one list): their labels are signed "on WeTrakr" (terms § 3)
                general_lists=(GeneralList(key='discover_movies', label=lambda: L(30668, 'Movies on WeTrakr'), variants=('movie',),
                                           thumb='services/wetrakr/main.png'),
                               GeneralList(key='discover_shows', label=lambda: L(30669, 'TV Shows on WeTrakr'), variants=('show',),
                                           thumb='services/wetrakr/main.png'),
                               GeneralList(key='public_lists', label=lambda: L(30670, 'Lists on WeTrakr'), thumb='services/wetrakr/lists.png'))),
    # progress / watched off by default: a key for ratings / lists does not start scrobbling
    ServiceType('mdblist', 'MDBList', {'progress': READ_WRITE, 'watched': READ_WRITE, 'ratings': READ_WRITE, 'lists': READ_WRITE}, multi=True,
                client='lib.api.mdblist:make_client', requires=SCROBBLE_REQUIRES, general='lib.api.mdblist:mdblist_app',
                general_lists=(GeneralList(key='popular_lists', label=lambda: L(30148, 'Popular Lists'), thumb='services/mdblist/popular.png'),
                               GeneralList(key='list_search', label=lambda: L(30659, 'List search'), thumb='common/search.png')),
                switches={'progress.read': False, 'progress.write': False, 'watched.read': False, 'watched.write': False}),
    # self-hosted: the server of an account is asked at its sign-in
    ServiceType('floppy', 'Floppy', {'progress': READ_WRITE, 'watched': READ_WRITE, 'ratings': READ_WRITE, 'lists': READ_WRITE}, multi=True,
                client='lib.api.floppy:make_client', requires=SCROBBLE_REQUIRES),
    ServiceType('justwatch', 'JustWatch', {'lists': READ_WRITE}, multi=True, client='lib.api.justwatch:make_client',
                general='lib.api.justwatch:justwatch_app',
                # new VOD releases (`/movie`, `/show` have them anyway)
                general_lists=(GeneralList(key='vod_new', label=lambda: L(30591, 'New VOD releases'), variants=('mixed', 'movie', 'show'),
                                           thumb='movies/newvod.png'),)),
    ServiceType('imdb', 'IMDb', {'ratings': READ_WRITE, 'lists': READ_WRITE}, public={'lists': READ}, multi=True,
                client='lib.api.imdb:make_client'),
    ServiceType('trakt', 'Trakt', {'progress': READ_WRITE, 'watched': READ_WRITE, 'ratings': READ_WRITE, 'lists': READ_WRITE}, multi=True,
                client='lib.api.trakt:make_client', requires=SCROBBLE_REQUIRES, general='lib.api.trakt:trakt_app',
                general_lists=(GeneralList(key='trending_lists', label=lambda: L(30147, 'Trending Lists'), thumb='services/trakt/trending.png'),
                               GeneralList(key='popular_lists', label=lambda: L(30148, 'Popular Lists'), thumb='services/trakt/popular.png'))),
    # local lists (`ownlists.db`): in the my menus, not in the main menu by default (the defaults are silent there)
    ServiceType('own', 'FanFilm', {'lists': READ_WRITE}, client='lib.ff.ownlists:make_client', switches={'menu.lists': False}),
    # in the menus of lists (history, progress) only when switched on
    ServiceType('kodi', 'Kodi', {'progress': READ, 'watched': READ_WRITE}, switches=HIDDEN_IN_MENUS),
)}


@frozen
class Account:
    """User data service account."""

    #: Account ID: `type.<slug>`, the type name for a type without accounts of users.
    id: str
    #: Service type.
    type: ServiceType
    #: Account name for UI.
    label: str
    #: False if the account is suspended: it keeps its data, but affects nothing.
    active: bool = True
    #: Other fields of the account entry in `/accounts` (e.g. a public user ID, switches).
    config: dict[str, Any] = field(factory=dict)


#: Allowed account ID.
ACCOUNT_ID_RX: re.Pattern[str] = re.compile(r'[a-z0-9][a-z0-9._-]*')
#: Fields of an account entry in `/accounts` (the rest goes to `Account.config`).
ACCOUNT_FIELDS: frozenset[str] = frozenset(('id', 'type', 'label', 'active'))
#: The accounts in the user configuration: a list of entries (the order is the priority).
ACCOUNTS_CONFIG: str = '/accounts'


class AccountStore:
    """
    Accounts: `/accounts` of the user configuration (`config.json`), the only place to get accounts.

    The accounts are read again when the file changes (another process, a hand edit). A broken file is never
    overwritten: only the accounts of the types without users are used then. Those missing are added (one per type).
    No `/accounts` yet: the accounts of the settings are migrated once (`lib.ff.account_migration`); a failed migration
    is like a broken file (nothing written: the next process migrates again, this one when the file changes).
    """

    def __init__(self, config: ConfigStore) -> None:
        #: The user configuration (the accounts are its `ACCOUNTS_CONFIG` list).
        self.config: ConfigStore = config
        #: Accounts in order. An immutable snapshot: readers iterate it without a lock; a change builds a new tuple
        #: and replaces the reference (an atomic swap).
        self._accounts: tuple[Account, ...] = ()
        #: The configuration data the accounts were read from (a new object after every change of the file).
        self._source: object = None
        #: Guards reading and writing (re-entrant: the migration uses clients of accounts).
        self._lock: RLock = RLock()
        #: True while the accounts are being read in this thread (a nested read gets the old snapshot).
        self._loading: bool = False

    def accounts(self) -> Sequence[Account]:
        """Return all accounts in order (read again if the configuration changed)."""
        if not self._accounts or self.config.data() is not self._source:  # first read or the file changed (also removed)
            with self._lock:
                if self._loading:
                    return self._accounts  # nested (the migration)
                self._loading = True
                try:
                    self._load()
                finally:
                    self._loading = False
        return self._accounts

    def _load(self) -> None:
        """Read the accounts (migrated once), add missing accounts of the types without users."""
        from .account_migration import migrate, clear_settings
        data = self.config.data()
        valid = self.config.valid
        entries = data.get('accounts')
        migrated = False
        if valid and entries is None:  # not migrated yet
            try:
                entries, migrated = migrate(self.config)
            except Exception:
                fflog_exc('[ACCOUNTS] migration of the accounts failed, only the accounts of the types without users are used')
                valid = False
        accounts: list[Account] = []
        if valid and entries is not None:
            try:
                accounts = parse_accounts(entries)
            except ValueError as exc:
                fflog.warning(f'[ACCOUNTS] broken {ACCOUNTS_CONFIG} ({exc}), only the accounts of the types without users are used')
                valid = False
        ids = {acc.id for acc in accounts}
        missing = [Account(id=typ.name, type=typ, label=typ.label) for typ in SERVICE_TYPES.values()
                   if not typ.multi and typ.capabilities and typ.name not in ids]
        accounts.extend(missing)
        dropped = isinstance(entries, list) and any(isinstance(e, dict) and (t := SERVICE_TYPES.get(e.get('type', ''))) is not None
                                                    and not t.capabilities for e in entries)  # a type without accounts now
        self._accounts = tuple(accounts)
        self._source = self.config.data()
        if (missing or migrated or dropped) and valid and self.save(accounts) and migrated:
            clear_settings()

    def save(self, accounts: Sequence[Account]) -> bool:
        """Write the accounts (the order, the entries) and use them, return False if the file can not be written."""

        def entry(acc: Account) -> dict[str, Any]:
            data: dict[str, Any] = {'id': acc.id, 'type': acc.type.name}
            if acc.label != acc.type.label:
                data['label'] = acc.label
            data['active'] = acc.active
            data.update(acc.config)
            return data

        with self._lock:
            if not self.config.set(ACCOUNTS_CONFIG, [entry(acc) for acc in accounts]):
                return False
            self._accounts = tuple(accounts)
            self._source = self.config.data()
            return True

    def auth_state(self, account: Account) -> AuthState:
        """Return the account state: a type switched off in `const` has none, a type without users is authorized, others by their client."""
        if not account_shown(account):
            return 'none'
        if not account.type.multi:
            return 'authorized'  # own, kodi
        if account_client(account).credentials():
            return 'authorized'
        return 'public' if account.type.public and account.config.get('user') else 'none'

    def switch(self, account: Account, capability: Capability, direction: Direction) -> bool:
        """Return the user switch of the account cell and of the cells it needs (`ServiceType.requires`)."""
        cell = f'{capability}.{direction}'
        if not switch_value(account, cell):
            return False
        return all(self.switch(account, *cast('tuple[Capability, Direction]', need.split('.'))) for need in account.type.requires.get(cell, ()))


def account_in_menu(account: Account, menu: ListMenuId) -> bool:
    """Return True if the account is shown in the menu of lists (its switch cell `menu.<id>`, no switch - shown)."""
    return switch_value(account, f'menu.{menu}')


def switch_value(account: Account, cell: SwitchCell) -> bool:
    """Return the own switch of the account cell (without the cells it needs): the account, else the type default, else on."""
    switches = account.config.get('switches')
    if isinstance(switches, dict) and isinstance(value := switches.get(cell), bool):
        return value
    return account.type.switches.get(cell, True)


def parse_accounts(entries: Any) -> list[Account]:
    """Parse the account entries (`ACCOUNTS_CONFIG`), skip (and log) invalid ones. Raise ValueError if not a list."""
    if not isinstance(entries, list):
        raise ValueError('not a list')
    accounts: list[Account] = []
    ids: set[str] = set()
    for entry in entries:
        typ = SERVICE_TYPES.get(entry.get('type', '')) if isinstance(entry, dict) else None
        if typ is not None and not typ.capabilities:
            continue  # a type without accounts (e.g. JustWatch, general lists only)
        account_id = entry.get('id') if isinstance(entry, dict) else None
        if (typ is None or not isinstance(account_id, str) or not ACCOUNT_ID_RX.fullmatch(account_id) or account_id in ids
                or not (account_id.startswith(f'{typ.name}.') if typ.multi else account_id == typ.name)):  # the type name is an alias
            fflog.warning(f'[ACCOUNTS] invalid account entry skipped: {entry!r}')
            continue
        assert isinstance(entry, dict)
        accounts.append(Account(id=account_id, type=typ, label=str(entry.get('label') or typ.label), active=entry.get('active', True) is not False,
                                config={k: v for k, v in entry.items() if k not in ACCOUNT_FIELDS}))
        ids.add(account_id)
    return accounts


#: Clients of accounts outside the settings (by account ID), see `account_client()`.
_clients: dict[str, Any] = {}


class NotDelivered(Exception):
    """A request of an account client in `delivery()` failed: transient (no connection, 401, 408, 429, 5xx) or rejected by the service."""

    def __init__(self, status: int) -> None:
        super().__init__(status)
        #: HTTP status of the failed request (0: no connection, no answer).
        self.status: int = status

    @property
    def transient(self) -> bool:
        """
        The change can be sent again later (no connection, a timeout, the rate limit, a server error; not authorized: a token
        not refreshed now - no connection, or dead: the account waits for a new sign-in with its changes, see `sync_block()`).
        """
        return self.status in (0, 401, 408, 429) or self.status >= 500


#: The thread sends changes (`delivery()`): a failed request raises `NotDelivered` instead of the quiet None.
_delivery: local = local()


@contextmanager
def delivery() -> Generator[None, None, None]:
    """A block sending changes: a failed request of an account client raises `NotDelivered` (see `failed_request()`)."""
    old: bool = getattr(_delivery, 'on', False)
    _delivery.on = True
    try:
        yield
    finally:
        _delivery.on = old


def failed_request(status: int) -> None:
    """A request of an account client failed (`status` 0: no connection): raise `NotDelivered` in `delivery()`, else nothing."""
    if getattr(_delivery, 'on', False):
        raise NotDelivered(status)


def all_found(result: Any, key: str = 'not_found') -> bool:
    """Return True if a batch write answer (`result`) has no item in `key` (lists, or counts, per media type)."""
    from collections.abc import Mapping as AbcMapping  # an answer proxy (wrapt, MDBList `Pages`) is not a `typing.Mapping`
    if not isinstance(result, AbcMapping):
        return False
    missing = result.get(key)
    if not isinstance(missing, AbcMapping):
        return True
    return not any(len(v) if isinstance(v, (list, tuple)) else v for v in missing.values() if isinstance(v, (list, tuple, int)))


#: Key of the account data: the end (UTC timestamp) of the daily request limit of the scope, see `set_limited()`.
LIMITED_KEY: str = 'limited'


def next_utc_midnight() -> int:
    """Return the next midnight UTC (timestamp): the reset of daily request limits."""
    from time import time
    return (int(time()) // 86400 + 1) * 86400


def set_limited(scope: str, until: int, *, label: str) -> None:
    """
    Keep the daily request limit of the scope (an account ID, the application: the type name) reached until `until`
    (UTC timestamp): its client asks nothing until then. A new limit is told quietly once (`label`: the account / service).
    """
    from time import time
    from .db.accounts import account_data_store
    store = account_data_store(scope)
    new = limited_until(scope) is None
    store.set(LIMITED_KEY, int(until), ttl=max(1, int(until - time())))
    fflog(f'[ACCOUNTS] {scope}: daily request limit reached, nothing is asked until {until}')
    if new:
        from .ui import ui
        from .calendar import from_timestamp
        from ..kolang import L
        ui.notify(label, L(32996, 'Daily request limit reached, until {time}').format(time=from_timestamp(until).strftime('%H:%M')))


def limited_until(scope: str) -> int | None:
    """Return the end (UTC timestamp) of the reached daily request limit of the scope, None if it is not reached."""
    from time import time
    from .db.accounts import account_data_store
    until = account_data_store(scope).get(LIMITED_KEY)
    return until if isinstance(until, int) and until > time() else None
#: Guards `_clients`.
_clients_lock: Lock = Lock()


class AccountClient:
    """
    Base of API clients of accounts: the account is given, or it is the alias of a type (the first account of the type,
    found at use, e.g. the module client `lib.api.trakt.trakt`), or none (the application client, no user).

    What the account can do is declared by the client: `LISTS` (the sections of lists, see `ListSection`) and `RATING`
    (the rating scale; `ratings()` -> raw ratings by media, `set_ratings(items, raw | None)`, optional `rating(ref)` - the rating
    of one media asked now, for the ratings window of a client without a sync of its ratings).
    """

    #: Sections of lists of the account (`watchlist`, `favorites`, `collection`, `user`), empty: no lists.
    LISTS: ClassVar[Mapping[str, ListSection]] = {}
    #: Rating scale of the account, None: no ratings.
    RATING: ClassVar[RatingScale | None] = None

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        #: The given account.
        self._account: Account | None = account
        #: The type name of the alias client ('' - not an alias).
        self._alias: str = alias

    @property
    def account(self) -> Account | None:
        """Return the account of the client: the given one or the first account of the alias type (None - none)."""
        if self._account is None and self._alias:
            return default_account(self._alias)
        return self._account



class DeviceAuth:
    """
    Mixin of an account client signed in by a device code (OAuth device flow), its token pair kept in the account data
    (`token`: `access_token`, `refresh_token`, `expires_at`, `scope` if told). The refresh token may rotate, so only the service refreshes
    (the plugin asks it); a refresh is under the lock of the account.

    The client gives the account data (`_store`, `scope`, `account`), its requests of the flow (`_device_code()`,
    `_poll_token()`, `_refresh_request()`, `_revoke_token()`), the link with the code in it (`_verification_url()`),
    the title of the window (`_auth_title()`), the refresh margin (`_refresh_before()`) and `refresh_profile()`.
    """

    #: Data keys of the account forgotten on sign out.
    SIGN_OUT_KEYS: ClassVar[tuple[str, ...]] = ('token', 'profile')
    #: Status codes of a refresh request telling that the refresh token does not work any more.
    DEAD_REFRESH: ClassVar[frozenset[int]] = frozenset({400, 401, 403})
    #: Token refresh locks per account (the double check of a refresh).
    _auth_locks: ClassVar[dict[str, RLock]] = {}
    _auth_locks_lock: ClassVar[Lock] = Lock()

    if TYPE_CHECKING:
        account: Account | None
        scope: str
        _store: Any

        def _device_code(self) -> requests.Response | None: ...
        def _poll_token(self, device_code: str) -> requests.Response | None: ...
        def _refresh_request(self, refresh: str) -> requests.Response | None: ...
        def _revoke_token(self, token: Mapping[str, Any]) -> None: ...
        def _verification_url(self, code: Mapping[str, Any]) -> str: ...
        def _auth_title(self) -> str: ...
        def _refresh_before(self) -> float: ...
        def refresh_profile(self) -> Mapping[str, Any] | None: ...

    def _auth_lock(self) -> RLock:
        """Return the token lock of the account."""
        with self._auth_locks_lock:
            return self._auth_locks.setdefault(self.scope, RLock())

    def _token(self) -> dict[str, Any]:
        """Return the token of the account (`access_token`, `refresh_token`, `expires_at`, the granted `scope` if told), {} if none."""
        return (self._store.get('token') or {}) if self.account is not None else {}

    def _keep_token(self, data: Mapping[str, Any]) -> None:
        """Keep the new token pair (before it is used: a refresh token may rotate)."""
        from .calendar import utc_timestamp
        refresh = data.get('new_refresh_token') or data.get('refresh_token')
        scope = data.get('scope') or self._token().get('scope')  # the granted scopes (a refresh answer may not tell them)
        self._store.set('token', {'access_token': data['access_token'], 'refresh_token': refresh,
                                  'expires_at': int(utc_timestamp() + int(data.get('expires_in') or 0)),
                                  **({'scope': str(scope)} if scope else {})}, ttl=None)

    def _access_token(self) -> str:
        """Return the access token of the account, refreshed before it expires ('' - none)."""
        from .calendar import utc_timestamp
        token = self._token()
        if not token.get('refresh_token'):
            return ''
        if int(token.get('expires_at') or 0) - utc_timestamp() < self._refresh_before():
            self.refresh_token()
            token = self._token()
        return str(token.get('access_token') or '')

    def refresh_token(self) -> bool:
        """Refresh the token pair. Only the service does it, the plugin asks the service (one session owner, the token rotates)."""
        from ..service import SERVICE
        if not SERVICE and self.account is not None:
            from ..service.client import service_client
            if (refreshed := service_client.account_refresh(self.account.id)) is not None:  # no service: refresh here
                return refreshed
        return self._refresh_token()

    def _refresh_token(self) -> bool:
        """Exchange the refresh token for a new pair (HTTP, under the lock of the account; another thread may have done it)."""
        from .calendar import utc_timestamp
        if self.account is None:
            return False
        with self._auth_lock():
            token = self._token()
            if not (refresh := token.get('refresh_token')):
                return False
            if int(token.get('expires_at') or 0) - utc_timestamp() >= self._refresh_before():
                return True  # refreshed meanwhile
            resp = self._refresh_request(refresh)
            if resp is not None and resp.status_code == 200 and isinstance(data := resp.json(), dict) and data.get('access_token'):
                self._keep_token(data)
                return True
            if resp is not None and resp.status_code in self.DEAD_REFRESH:
                fflog(f'[ACCOUNTS] {self.scope}: the refresh token does not work any more ({resp.status_code}), a new sign-in is needed')
                self._store.delete('token')
            return False

    def auth(self, *, force: bool = False) -> bool | None:
        """
        Sign in the account by the device code (shown with its link): True on success, False on failure, None if canceled by the user.
        Another user drops the account data.
        """
        from time import monotonic
        from .ui import ui
        from .kotools import xsleep
        from ..kolang import L
        if self.account is None:
            return False
        if not force and self._token().get('refresh_token'):
            return True
        resp = self._device_code()
        if resp is None or resp.status_code != 200 or not isinstance(code := resp.json(), dict) or not code.get('device_code'):
            ui.notify(self.account.label, L(32934, 'No device code ({status})').format(status=getattr(resp, 'status_code', '-')), error=True)
            return False
        interval, expires = float(code.get('interval') or 5), float(code.get('expires_in') or 600)
        start = monotonic()
        data: Any = None
        canceled = False
        with ui.auth_session(title=self._auth_title(), url=self._verification_url(code), code=code['user_code']) as session:
            while monotonic() - start < expires and not (canceled := session.is_canceled()):
                session.update(100 * (monotonic() - start) / expires)
                xsleep(interval)
                if (answer := self._poll_token(str(code['device_code']))) is None:
                    continue
                if answer.status_code == 200:
                    data = answer.json()
                    break
                try:
                    error = answer.json().get('error')
                except (ValueError, AttributeError):
                    error = None
                if answer.status_code == 429 or error == 'slow_down':
                    interval += 5
                elif error != 'authorization_pending':
                    fflog(f'[ACCOUNTS] {self.scope}: device token: {answer.status_code} {error}')
                    break
        if not isinstance(data, dict) or not data.get('access_token'):
            if canceled:
                return None
            ui.notify(self.account.label, L(30190, 'Authorization FAILED'), error=True)  # e.g. the code expired, access denied
            return False
        old = (self._store.get('profile') or {}).get('id')
        self._keep_token(data)
        if (profile := self.refresh_profile()) is not None and old and old != profile.get('id'):
            self._drop_user_data()
        return True

    def _drop_user_data(self) -> None:
        """Another user signed in: forget the sync cursors, the playback rows and the cached lists of the account."""
        from .db.accounts import reset_sync
        from .db.playback import remove_account_rows
        from .listcache import remove_scope
        assert self.account is not None
        reset_sync(self.account.id)
        remove_account_rows(self.account.id)
        remove_scope(self.account.id)

    def unauth(self) -> bool:
        """Sign out: revoke the token in the service and forget the account data of the sign-in (`SIGN_OUT_KEYS`)."""
        if self.account is None:
            return False
        if (token := self._token()).get('refresh_token'):
            self._revoke_token(token)
        for key in self.SIGN_OUT_KEYS:
            self._store.delete(key)
        return True

def account_client(account: Account) -> Any:
    """Return the API client of the account (one per account), None if the type has no client per account."""
    if not (path := account.type.client):
        return None
    with _clients_lock:
        client = _clients.get(account.id)
        if client is None or getattr(client, 'account', None) != account:  # a new account or changed (e.g. its key in the file)
            client = _clients[account.id] = _client_factory(path)(account)
        return client


def general_client(type_name: str) -> Any:
    """Return the application client of the general lists of the type (`ServiceType.general`), None if the type has none."""
    from importlib import import_module
    if not (path := SERVICE_TYPES[type_name].general):
        return None
    module, _, name = path.partition(':')
    return getattr(import_module(module), name)


def type_enabled(type_name: str) -> bool:
    """Return True if the accounts of the type are not switched off in `const` (`const.accounts.<type>.enabled`)."""
    from const import const
    return bool(getattr(getattr(const.accounts, type_name, None), 'enabled', True))


def account_shown(account: Account) -> bool:
    """Return True if the type of the account is enabled; the local Kodi (the account `kodi`) is always there."""
    return account.id == 'kodi' or type_enabled(account.type.name)


def general_available(type_name: str) -> bool:
    """
    Return True if the general lists of the type can be shown: the type has them, they are enabled in `const`
    (`const.indexer.<type>.enabled`, if there is; the accounts have `const.accounts`) and its application client is
    ready (`is_enabled()`, if it has, e.g. MDBList: an account with a key).
    """
    from const import const
    if (client := general_client(type_name)) is None:
        return False
    if not getattr(getattr(const.indexer, type_name, None), 'enabled', True):
        return False
    return bool(client.is_enabled()) if hasattr(client, 'is_enabled') else True


def alias_client(type_name: str) -> Any:
    """Return the client of the type alias (the module client, e.g. `lib.api.trakt.trakt`), None if the type has no client."""
    if not (path := SERVICE_TYPES[type_name].client):
        return None
    return _client_factory(path)(None)


def _client_factory(path: str) -> Callable[[Account | None], Any]:
    """Return the client factory of the type (`ServiceType.client`, `module:function`)."""
    from importlib import import_module
    module, _, name = path.partition(':')
    return getattr(import_module(module), name)


#: The accounts store (the user configuration).
account_store: AccountStore = AccountStore(config)


def accounts() -> list[Account]:
    """Return all accounts in order (the only place to get accounts), the accounts of the types switched off are hidden."""
    return [acc for acc in account_store.accounts() if account_shown(acc)]


def get_account(account_id: str) -> Account | None:
    """Return the account by ID or by the type name (the alias of the first account of the type), None if none."""
    accs = account_store.accounts()
    if (acc := next((acc for acc in accs if acc.id == account_id), None)) is None and account_id in SERVICE_TYPES:
        acc = next((acc for acc in accs if acc.type.name == account_id), None)
    return acc


def account_authorized(account: Account | str) -> bool:
    """Return True if the account has full rights of its type (e.g. a Trakt user is logged in)."""
    acc = account if isinstance(account, Account) else get_account(account)
    return acc is not None and account_store.auth_state(acc) == 'authorized'


def _rating_action_allowed(name: RatingServiceName, action: RatingAction) -> bool:
    """Return True if `const.ratings.filter` allows the rating `action` of the service `name`."""
    from const import const
    rules = const.ratings.filter
    allowed = rules.get(('*', '*'), True)
    allowed = rules.get(('*', action), allowed)
    allowed = rules.get((name, '*'), allowed)
    return rules.get((name, action), allowed)


def account_enabled(account: Account | str,
                    capability: Capability,
                    direction: Direction,
                    *,
                    action: RatingAction | None = None,
                    ) -> bool:
    """
    Return True if the account is enabled for the capability in the direction.

    The type supports it AND the account state allows it (authorized, public: only the type's public part, e.g. MDBList
    supporter) AND the user switch is on AND `const` does not filter it (ratings: `const.ratings.filter` by `action`).
    """
    acc = account if isinstance(account, Account) else get_account(account)
    if acc is None or not acc.active or not account_shown(acc):
        return False
    typ = acc.type
    if direction not in typ.capabilities.get(capability, ()):
        return False
    state = account_store.auth_state(acc)
    if state == 'none' or (state == 'public' and direction not in typ.public.get(capability, ())):
        return False
    # types with ratings are exactly the rating services (trakt, tmdb, mdblist, imdb)
    if capability == 'ratings' and action is not None and not _rating_action_allowed(cast('RatingServiceName', typ.name), action):
        return False
    return account_store.switch(acc, capability, direction)


def enabled_accounts(capability: Capability, direction: Direction, *, action: RatingAction | None = None) -> list[Account]:
    """Return enabled accounts for the capability in the direction, in order."""
    return [acc for acc in account_store.accounts() if account_enabled(acc, capability, direction, action=action)]


def enabled_clients(capability: Capability, direction: Direction) -> list[Any]:
    """Return API clients of enabled accounts for the capability in the direction, in order (accounts without a client skipped)."""
    return [client for acc in enabled_accounts(capability, direction) if (client := account_client(acc)) is not None]


def default_account(type_name: str) -> Account | None:
    """Return the default account of the service type (the first account of the type, the alias of the type name)."""
    return next((acc for acc in account_store.accounts() if acc.type.name == type_name), None)


def only_account(account: Account) -> bool:
    """Return True if the account is the only account of its type (a label may skip the account then)."""
    return sum(acc.type.name == account.type.name for acc in account_store.accounts()) == 1


def new_account_id(type_name: str, label: str, taken: Iterable[str] | None = None) -> str:
    """
    Return the ID of a new account of the type: `type.<slug>` from the label (without the type label), `-2`, `-3`...
    on a collision; never the bare type name (the alias). A type without accounts per user has the type name.
    """
    from .utils import slugify_latin
    typ = SERVICE_TYPES[type_name]
    if not typ.multi:
        return typ.name
    text = label.strip()
    if text.lower().startswith(typ.label.lower()):
        text = text[len(typ.label):]
    slug = re.sub(r'[^a-z0-9]+', '-', slugify_latin(text).lower()).strip('-') or '1'
    ids = {acc.id for acc in account_store.accounts()} if taken is None else set(taken)
    aid, n = f'{typ.name}.{slug}', 1
    while aid in ids:
        n += 1
        aid = f'{typ.name}.{slug}-{n}'
    return aid
