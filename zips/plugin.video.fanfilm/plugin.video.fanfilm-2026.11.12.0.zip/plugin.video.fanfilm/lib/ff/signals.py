"""
Signal / slot pattern: Signal, ASignal (async API), ClassSignal and ClassExcSignal (a signal per instance, like a property).

Bound method slots are held weakly (a deleted object disconnects itself, the signal never keeps it), other callables
strongly (functions, nested ones too, builtin methods, lambdas, partials: a weak one would disconnect silently).
`asyncio` is imported only when a coroutine slot is called from emit().
"""

from __future__ import annotations
from typing import Any, Callable, Coroutine, Collection, Generator, ClassVar, NoReturn, TypeVar, overload, TYPE_CHECKING
from typing_extensions import TypeAlias, ParamSpec, Generic, Self
import sys
from weakref import ref, WeakMethod, ReferenceType
from inspect import ismethod, iscoroutinefunction  # , isawaitable
from functools import partial
from enum import Enum
import logging
from attrs import define, frozen, evolve

if TYPE_CHECKING:
    import asyncio

#: Logger of the module.
logger: logging.Logger = logging.getLogger(__name__)


if not TYPE_CHECKING and sys.version_info < (3, 10):
    # HACK. Certain special cases in user-defined typing.Generics are not available.
    # See: https://github.com/python/typing_extensions/issues/126
    class Generic:
        """Generic replacement: subscription returns the class itself."""

        __slots__ = ()

        def __class_getitem__(cls, key: Any) -> Self:
            """Return the class itself (no generic alias)."""
            return cls


#: Generic type variable.
T = TypeVar('T')
#: Slot parameters.
PARAMS = ParamSpec('PARAMS')
# DEFAULT = ParamSpec('DEFAULT')
#: Coroutine function slot.
AsyncCallable: TypeAlias = Callable[PARAMS, Coroutine[Any, Any, Any]]
#: Any slot (function or coroutine function).
Slot: TypeAlias = 'Callable[PARAMS, Any] | AsyncCallable'
#: Stored slot: a weak reference of a bound method, the callable itself otherwise.
SlotRef: TypeAlias = 'Slot | ReferenceType[Slot]'
#: Slot positional arguments.
Args: TypeAlias = 'tuple[Any, ...]'
#: Slot keyword arguments.
KwArgs: TypeAlias = 'dict[str, Any]'
#: Slot result.
Result: TypeAlias = Any
#: Emit iterator: yields slots to call, receives (result, exception).
SlotsGen: TypeAlias = 'Generator[tuple[Slot, Args, KwArgs], tuple[Result, BaseException | None], None]'


def _caller_name(depth: int = 1) -> str:
    """Return the function name `depth` frames above the caller."""
    return sys._getframe(depth + 1).f_code.co_name


@define
class EmitResult:
    """Helper. emit() result value."""
    #: Emit result.
    result: Any = None


def _append_no_result(results: list[Any], value: Any) -> None:
    """Ignore the result."""


def _append_first_not_none_result(results: list[Any], value: Any) -> None:
    """Keep the first not-None result."""
    if value is not None and not results:
        results.append(value)


def _append_last_not_none_result(results: list[Any], value: Any) -> None:
    """Keep the last not-None result."""
    if value is not None:
        if results:
            results[-1] = value
        else:
            results.append(value)


def _append_all_not_none_results(results: list[Any], value: Any) -> None:
    """Keep all not-None results."""
    if value is not None:
        results.append(value)


def _append_first_result(results: list[Any], value: Any) -> None:
    """Keep the first result."""
    if not results:
        results.append(value)


def _append_last_result(results: list[Any], value: Any) -> None:
    """Keep the last result."""
    if results:
        results[-1] = value
    else:
        results.append(value)


def _append_all_results(results: list[Any], value: Any) -> None:
    """Keep all results."""
    results.append(value)


class ResultPolicy(Enum):
    """Grab slot results policy."""
    #: emit() returns None
    NONE = 0
    #: emit() returns first value
    FIRST = 1
    #: emit() returns last value
    LAST = 2
    #: emit() returns all values
    ALL = 3
    #: emit() returns first not-None value.
    FIRST_NOT_NONE = 4
    #: emit() returns all values except None.
    ALL_NOT_NONE = 5


class EmitPolicy(Enum):
    """Emit policy."""
    #: Emit to all slots
    ALL = 0
    #: Emit until slot returns not None
    UNTIL_NONE = 1
    #: Emit until slot returns true
    UNTIL_FALSE = 2


class ExceptionPolicy(Enum):
    """Handle slot exception policy."""
    #: Ignore all exceptions.
    IGNORE = 0
    #: Stop on first exception and raise it.
    RAISE_IMMEDIATELY = 1
    #: Execute all slots and raise first caught exception.
    RAISE_AFTER = 2
    #: Return exception (all exceptions if ResultPolicy.ALL).
    RETURN = 3


class Signal(Generic[PARAMS]):
    r"""
    Trivial signal/slot pattern implementation.
    """

    __slots__ = ('args', 'kwargs', 'sender', '_slots', 'opt', '_emitting', '_tasks')

    #: Shortcut: ResultPolicy.NONE.
    NoResult = ResultPolicy.NONE
    #: Shortcut: ResultPolicy.FIRST.
    ResultFirst = ResultPolicy.FIRST
    #: Shortcut: ResultPolicy.LAST.
    ResultLast = ResultPolicy.LAST
    #: Shortcut: ResultPolicy.ALL.
    ResultAll = ResultPolicy.ALL
    #: Shortcut: ResultPolicy.FIRST_NOT_NONE.
    ResultFirstNotNone = ResultPolicy.FIRST_NOT_NONE
    #: Shortcut: ResultPolicy.ALL_NOT_NONE.
    ResultAllNotNone = ResultPolicy.ALL_NOT_NONE

    #: Shortcut: EmitPolicy.ALL.
    EmitAll = EmitPolicy.ALL
    #: Shortcut: EmitPolicy.UNTIL_NONE.
    EmitUntilNone = EmitPolicy.UNTIL_NONE
    #: Shortcut: EmitPolicy.UNTIL_FALSE.
    EmitUntilFalse = EmitPolicy.UNTIL_FALSE

    #: Shortcut: ExceptionPolicy.IGNORE.
    ExceptionIgnore = ExceptionPolicy.IGNORE
    #: Shortcut: ExceptionPolicy.RAISE_IMMEDIATELY.
    ExceptionRaiseImmediately = ExceptionPolicy.RAISE_IMMEDIATELY
    #: Shortcut: ExceptionPolicy.RAISE_AFTER.
    ExceptionRaiseAfter = ExceptionPolicy.RAISE_AFTER
    #: Shortcut: ExceptionPolicy.RETURN.
    ExceptionReturn = ExceptionPolicy.RETURN

    @frozen(kw_only=True)
    class Options:
        """Options for Signal."""

        #: Default max recursion.
        MaxRecursion: ClassVar[int] = 10

        #: Signal name
        name: str | None = None
        #: Assign `sender` and `signal` to called function.
        assign_sender: bool = False
        #: What result should be returned from emit()
        result: ResultPolicy = ResultPolicy.FIRST
        #: Emit limit
        emit: EmitPolicy = EmitPolicy.ALL
        #: Slot exception policy.
        exception: ExceptionPolicy = ExceptionPolicy.IGNORE
        #: Allow emit signal again during emiiting
        max_recursion: int | None = MaxRecursion
        #: Log exception level, logging.NOTSET (0) for none.
        exception_log_level: int = logging.WARNING
        #: Exception types not logged.
        skip_log_exceptions: Collection[type[Exception]] = ()

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Create a signal: optional `Signal.Options` first, then default slot arguments."""
        #: Signal options.
        self.opt: Signal.Options
        if args and isinstance(args[0], Signal.Options):
            self.opt, args = args[0], args[1:]
        else:
            self.opt = self.Options()
        #: Default positional arguments.
        self.args: Args = args
        #: Default keyword arguments.
        self.kwargs: KwArgs = kwargs
        #: Signal sender object.
        self.sender: Any = None
        #: List of connected slots.
        self._slots: list[SlotRef] = []
        #: Emitting in progress (number of recursion emits).
        self._emitting: int = 0
        #: Hard references to running async-slot tasks (protects them from GC).
        self._tasks: set[asyncio.Task[Any]] = set()

    def _slot_destroyed(self, slot: SlotRef) -> None:
        """Remove a dead weak slot reference."""
        self._slots.remove(slot)

    def _make_ref(self, slot: Slot) -> SlotRef:
        """
        Return a slot reference: weak for a bound method (the signal does not keep its object, e.g. a window), strong for
        any other callable - a function (a nested one too), a builtin method (`list.append`), a lambda, a partial: a weak one
        would disconnect silently when the caller drops it.
        """
        if not callable(slot):
            raise ValueError(f'Connection to non-callable {slot.__class__.__name__!r} object failed')
        if ismethod(slot):
            return WeakMethod(slot, self._slot_destroyed)
        return slot

    def connect(self, slot: Slot[PARAMS], *, unique: bool = True) -> None:
        """Connect the signal to a slot.

        Connect this signal to given `slot`.
        If `unique` is True slot can be connected only once.
        """
        slot_ref: SlotRef = self._make_ref(slot)
        if unique and slot_ref in self._slots:
            return
        self._slots.append(slot_ref)

    def slots(self) -> list[Callable[..., Any]]:
        """Return the connected slots (the live ones)."""
        return [slot for held in self._slots if (slot := held() if isinstance(held, WeakMethod) else held) is not None]

    def disconnect(self, slot: Slot, *, all: bool = False) -> None:
        """Disconnect the signal and a slot.

        Disconnect this signal from given `slot`.
        If `all` is True, all instances will be disconnected
        (if was added in connect(unique=False).
        """
        slot_ref: SlotRef = self._make_ref(slot)
        try:
            self._slots.remove(slot_ref)
            while all:
                self._slots.remove(slot_ref)
        except ValueError:
            pass

    def _set_sender(self, func: Callable[..., Any], on: bool, *, sender: str | None = None) -> None:
        """Set (or clear) `signal` and `sender` attributes of the slot function."""
        if sender is None:
            sender = self.sender
        try:
            if ismethod(func):
                func.__func__.signal = self if on else None  # type: ignore[attr-defined]
                func.__func__.sender = sender if on else None  # type: ignore[attr-defined]
            else:
                func.signal = self if on else None  # type: ignore[attr-defined]
                func.sender = sender if on else None  # type: ignore[attr-defined]
        except Exception:
            pass

    def _emit_iter(self, eres: EmitResult, *, args: Args, kwargs: KwArgs, sender: str | None) -> SlotsGen:
        """
        Helper. Emit the signal iterator. Yields slots to call.

        Any arguments (`args`, `kwargs`) will be passed to receivers.
        """
        if self.args and args:
            args = self.args + args
        else:
            args = self.args or args
        if self.kwargs and kwargs:
            kwargs = {**self.kwargs, **kwargs}
        else:
            kwargs = self.kwargs or kwargs

        opt = self.opt
        if opt.max_recursion is not None and self._emitting > opt.max_recursion:
            logger.debug(f'Max signal recursion {opt.max_recursion} exceeded')
            return None

        raise_exception: BaseException | None = None
        try:
            self._emitting += 1
            self.sender = sender
            results: list[Any] = []
            loop_result_breaker = _emit_loop_break_mode.get(opt.emit, lambda r: False)
            append_result = _append_result_mode.get(opt.result, _append_no_result)

            for slot in tuple(self._slots):
                if isinstance(slot, ref):
                    slot_ref: ref[Slot] = slot
                    slot = slot_ref()
                if slot is None:
                    continue  # weakref died during emit (slot will be auto-removed)
                if opt.assign_sender:
                    self._set_sender(slot, True)
                try:
                    result, exc = yield slot, args, kwargs
                except Exception as e:
                    logger.error(f'Slot {slot!r} exception {e!r}')
                    raise
                finally:
                    if opt.assign_sender:
                        self._set_sender(slot, False)
                if exc is not None:
                    if opt.exception_log_level and not any(isinstance(exc, ie) for ie in opt.skip_log_exceptions):
                        logger.log(opt.exception_log_level, f'Slot {slot} exception:', exc_info=exc)
                    if opt.exception is ExceptionPolicy.RAISE_IMMEDIATELY:
                        raise exc
                    if opt.exception is ExceptionPolicy.RAISE_AFTER:
                        result = exc
                        if raise_exception is None:
                            raise_exception = exc
                    if opt.exception is ExceptionPolicy.RETURN:
                        result = exc
                append_result(results, result)
                if loop_result_breaker(result):
                    break
        finally:
            self._emitting -= 1
            self.sender = None

        if raise_exception is not None:
            raise raise_exception
        if opt.result in (self.ResultAll, self.ResultAllNotNone):
            eres.result = results
        else:
            eres.result = results[0] if results else None

    def emit(self, *args: Any, **kwargs: Any) -> Any:
        """
        Emit the signal.

        Any arguments (`args`, `kwargs`) will be passed to receivers.
        """
        async def acall_slot(slot: AsyncCallable, *, sender: str, args: Args, kwargs: KwArgs) -> Any:
            """Call the async slot, log its exception (a cancel is a `BaseException`: it goes on)."""
            try:
                if self.opt.assign_sender:
                    self._set_sender(slot, True, sender=sender)
                return await slot(*args, **kwargs)
            except Exception:
                # the exception can not be returned to the sender (separate task),
                # but it must not vanish silently
                logger.exception(f'Async slot {slot!r} exception (signal {self.opt.name!r})')
            finally:
                if self.opt.assign_sender:
                    self._set_sender(slot, False)

        sender = _caller_name(1)
        res = EmitResult()
        slots: SlotsGen = self._emit_iter(res, args=args, kwargs=kwargs, sender=sender)
        result: Result
        exc: BaseException | None
        try:
            slot, args, kwargs = next(slots)
            while True:
                result = exc = None
                call_test = slot.func if isinstance(slot, partial) else slot
                if iscoroutinefunction(call_test):
                    import asyncio
                    coro = acall_slot(slot, sender=sender, args=args, kwargs=kwargs)
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        result = asyncio.run(coro)
                    else:
                        # keep a hard reference, otherwise the task can be GC-ed mid-run
                        task = loop.create_task(coro)
                        self._tasks.add(task)
                        task.add_done_callback(self._tasks.discard)
                elif callable(slot):
                    try:
                        result = slot(*args, **kwargs)
                    except BaseException as e:
                        exc = e
                slot, args, kwargs = slots.send((result, exc))
        except StopIteration:
            pass
        return res.result

    async def aemit(self, *args: Any, **kwargs: Any) -> Any:
        """
        Async emit the signal.

        Any arguments (`args`, `kwargs`) will be passed to receivers.
        """
        result: Result
        exc: BaseException | None
        res = EmitResult()
        slots: SlotsGen = self._emit_iter(res, args=args, kwargs=kwargs, sender=_caller_name())
        try:
            slot, args, kwargs = next(slots)
            while True:
                result = exc = None
                try:
                    call_test = slot
                    if isinstance(slot, partial):
                        call_test = slot.func
                    if iscoroutinefunction(call_test):
                        result = await slot(*args, **kwargs)
                    # elif isawaitable(slot):
                    #     result = await slot
                    elif callable(slot):
                        result = slot(*args, **kwargs)
                except BaseException as e:
                    exc = e
                slot, args, kwargs = slots.send((result, exc))
        except StopIteration:
            pass
        return res.result


class ASignal(Signal):
    r"""
    Trivial signal/slot pattern implementation with async api.
    """

    async def connect(self, slot: Slot, *, unique: bool = True) -> None:  # type: ignore[override]
        """Connect the signal to a slot. See `Signal.connect()`."""
        return super().connect(slot, unique=unique)

    async def disconnect(self, slot: Slot, *, all: bool = False) -> None:  # type: ignore[override]
        """Disconnect the signal and a slot. See `Signal.connect()`."""
        return super().disconnect(slot, all=all)

    #: Emit is async here.
    emit = Signal.aemit  # type: ignore[assignment]


#: Result policy -> result collector.
_append_result_mode: dict[ResultPolicy, Callable[[list[Any], Any], None]] = {
    Signal.NoResult:           _append_no_result,
    Signal.ResultFirst:        _append_first_result,
    Signal.ResultLast:         _append_last_result,
    Signal.ResultAll:          _append_all_results,
    Signal.ResultFirstNotNone: _append_first_not_none_result,
    Signal.ResultAllNotNone:   _append_all_not_none_results,
}

#: Emit policy -> loop breaker (True stops the emit).
_emit_loop_break_mode: dict[EmitPolicy, Callable[[Any], bool]] = {
    Signal.EmitUntilNone:  lambda r: r is not None,
    Signal.EmitUntilFalse: lambda r: bool(r),
    Signal.EmitAll:        lambda r: False,
}


class ClassSignal:
    """
    Signal description objects for classes. Like property. The signal of an instance is kept in the instance: a slot leading back
    to it (a partial, a lambda) is an ordinary cycle the GC collects; held by the descriptor it would keep the instance for ever.
    """

    __slots__ = ('attr', 'name', 'options')

    def __init__(self, options: Signal.Options | None = None, *, name: str | None = None) -> None:
        """Create the signal descriptor; each instance of the owner class gets its own signal."""
        #: The attribute of the signal in an instance (a descriptor set on a class later gets no `__set_name__()`: from its name or itself).
        self.attr: str = f'_{name or id(self)}_signal'
        #: Signal name (the attribute name if not given).
        self.name: str | None = name
        #: Signal options.
        self.options: Signal.Options | None = options

    @overload
    def __get__(self, obj: None, cls: type | None = None) -> ClassSignal: ...

    @overload
    def __get__(self, obj: object, cls: type | None = None) -> Signal: ...

    def __get__(self, obj: object | None, cls: type | None = None) -> Any:
        """Return the descriptor for the class, the signal of the instance otherwise."""
        if obj is None:
            return self
        opt: tuple[Signal.Options, ...]
        if self.options is not None:
            if self.name is not None and self.options.name is None:
                opt = (evolve(self.options, name=self.name),)
            else:
                opt = (self.options,)
        elif self.name is not None:
            opt = (Signal.Options(name=self.name),)
        else:
            opt = ()
        return vars(obj).setdefault(self.attr, Signal(*opt))

    def __set__(self, obj: object, value: Any) -> NoReturn:
        """Refuse the assignment."""
        raise RuntimeError('Can NOT assign to a Signal object')

    def __set_name__(self, owner: object, name: str) -> None:
        """Take the attribute name as the signal name (if none) and as the name of the attribute of the signal in the instances."""
        self.attr = f'_{name}_signal'
        if self.name is None:
            self.name = name


class ClassExcSignal(ClassSignal):
    """
    Signal description objects for classes with exceptions propagate.
    """

    __slots__ = ()

    def __init__(self, options: Signal.Options | None = None, *, name: str | None = None,
                 skip_log_exceptions: Collection[type[Exception]] = ()) -> None:
        """Create the descriptor, slot exceptions raised immediately by default."""
        if options is None:
            options = Signal.Options(exception=Signal.ExceptionRaiseImmediately, skip_log_exceptions=skip_log_exceptions)
        super().__init__(options=options, name=name)


#: Old name of ClassSignal.
SignalProperty = ClassSignal
