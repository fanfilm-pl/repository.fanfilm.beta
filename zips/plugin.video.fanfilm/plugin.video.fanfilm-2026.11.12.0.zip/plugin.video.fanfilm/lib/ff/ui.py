"""
User interaction of account flows: Kodi dialogs or a terminal (CLI), chosen once.

Kodi is the default; the CLI sets `TerminalUI` with `set_ui()` before the service is forked (the child inherits it).
Import `ui` when it is used (`from ..ff.ui import ui` inside a function), a module level import keeps the old object.
"""

from __future__ import annotations
from typing import Sequence, TYPE_CHECKING
from typing_extensions import Self
from .logs import fflog
if TYPE_CHECKING:
    from datetime import date
    from types import TracebackType
    from ..windows.site_auth import SiteAuthWindow


class AuthSession:
    """Authorization in progress: the link (and QR code), an optional code to enter, progress, cancel by user."""

    def __init__(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None) -> None:
        """Start the authorization: show the link (QR code) and the optional code."""

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: TracebackType | None) -> None:
        self.close()

    def update(self, progress: float) -> None:
        """Update the progress (0..100)."""

    def is_canceled(self) -> bool:
        """Return True if the user canceled the authorization."""
        return False

    def close(self) -> None:
        """Close the session."""


class KodiAuthSession(AuthSession):
    """Authorization window in Kodi (modeless `SiteAuthWindow` with the QR code)."""

    def __init__(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None) -> None:
        from ..windows.site_auth import SiteAuthWindow
        fflog(f'[AUTH] {title}: {url} {code}')
        self._window: SiteAuthWindow | None = SiteAuthWindow(code=code, url=url, qrcode=url, qrcode_scale=qrcode_scale, modal=False, title=title)
        self._window.doModal()  # this dialog is modeless (!)

    def update(self, progress: float) -> None:
        """Update the progress (0..100)."""
        if self._window is not None:
            self._window.update(int(progress))

    def is_canceled(self) -> bool:
        """Return True if the user canceled the authorization."""
        return self._window is not None and self._window.dialog_is_canceled()

    def close(self) -> None:
        """Close the window (the QR code image is removed by the window)."""
        if self._window is not None:
            self._window.destroy()
            self._window = None


class TerminalAuthSession(AuthSession):
    """Authorization in a terminal: the link, the code and the QR code are printed, Ctrl-C cancels."""

    def __init__(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None) -> None:
        import re
        import sys
        import segno
        self.code: str = code
        title = re.sub(r'\[/?[^\]]+\]', '', title)  # no Kodi formatting
        print(f'{title}: visit {url}' + (f' and enter {code!r}' if code else ''))
        segno.make(url).terminal(out=sys.stderr, compact=True)

    def update(self, progress: float) -> None:
        """Print the progress (0..100)."""
        print(f'\r{self.code} {progress:5.1f}%', end='', flush=True)

    def close(self) -> None:
        """End the progress line."""
        print()


class KodiUI:
    """Interaction by Kodi dialogs."""

    #: Authorization session class.
    AUTH_SESSION: type[AuthSession] = KodiAuthSession

    def notify(self, heading: str, message: str, *, error: bool = False) -> None:
        """Show a notification."""
        from .control import infoDialog
        infoDialog(message, heading, 'ERROR' if error else 'INFO')

    def confirm(self, message: str, *, heading: str = '') -> bool:
        """Ask the user (yes / no)."""
        from .control import yesnoDialog
        return bool(yesnoDialog(message, heading=heading))

    def select(self, heading: str, items: Sequence[str]) -> int:
        """Ask the user to select an item, return its index or -1 if canceled."""
        from .control import selectDialog
        return selectDialog(list(items), heading=heading)

    def input(self, heading: str, default: str = '', *, hidden: bool = False) -> str | None:
        """Ask the user for a text, return None if canceled."""
        from xbmcgui import Dialog, INPUT_ALPHANUM, ALPHANUM_HIDE_INPUT
        text = Dialog().input(heading, default, type=INPUT_ALPHANUM, option=ALPHANUM_HIDE_INPUT if hidden else 0)
        return text or None

    def input_date(self, heading: str, default: date | None = None) -> date | None:
        """
        Ask the user for a date (the date dialog of Kodi: `DD/MM/YYYY`, the day and the month space-padded; no default: today), return
        None if canceled.
        """
        from datetime import date
        from xbmcgui import Dialog, INPUT_DATE
        text = Dialog().input(heading, '' if default is None else f'{default.day:02}/{default.month:02}/{default.year:04}', type=INPUT_DATE)
        try:
            day, month, year = (int(part) for part in text.split('/'))
            return date(year, month, day)
        except ValueError:  # canceled: no text
            return None

    def auth_session(self, *, title: str, url: str, code: str = '', qrcode_scale: int | None = None) -> AuthSession:
        """Start the authorization: show the link (QR code) and the optional code, use as a context manager."""
        return self.AUTH_SESSION(title=title, url=url, code=code, qrcode_scale=qrcode_scale)


class TerminalUI(KodiUI):
    """Interaction in a terminal (CLI)."""

    AUTH_SESSION = TerminalAuthSession

    def notify(self, heading: str, message: str, *, error: bool = False) -> None:
        """Print a notification."""
        print(f'{"ERROR " if error else ""}{heading}: {message}')

    def confirm(self, message: str, *, heading: str = '') -> bool:
        """Ask the user (yes / no) in the terminal."""
        return input(f'{heading}: {message} [y/N] ').strip().lower() in ('y', 'yes', 't', 'tak')

    def input(self, heading: str, default: str = '', *, hidden: bool = False) -> str | None:
        """Ask the user for a text in the terminal (empty: the default), return None if canceled (no text at all)."""
        from getpass import getpass
        prompt = f'{heading}{f" [{default}]" if default else ""}: '
        text = (getpass(prompt) if hidden else input(prompt)).strip() or default
        return text or None

    def select(self, heading: str, items: Sequence[str]) -> int:
        """Ask the user to select an item in the terminal, return its index or -1 if canceled."""
        print(heading)
        for i, item in enumerate(items, 1):
            print(f'  {i}. {item}')
        answer = input('> ').strip()
        return int(answer) - 1 if answer.isdecimal() and 1 <= int(answer) <= len(items) else -1


#: The current interaction.
ui: KodiUI = KodiUI()


def set_ui(new_ui: KodiUI) -> None:
    """Set the interaction for the process (CLI: `TerminalUI()`)."""
    global ui
    ui = new_ui
