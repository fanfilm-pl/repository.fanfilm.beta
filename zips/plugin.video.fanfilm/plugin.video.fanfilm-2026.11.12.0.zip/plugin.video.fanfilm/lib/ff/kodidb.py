"""
Direct access to Kodi MyVideo*.db.

Use carefully.
"""

from __future__ import annotations
import re
from pathlib import Path
from contextlib import contextmanager
from itertools import islice
from functools import lru_cache
from sqlite3 import connect as db_connect, Connection, Cursor, OperationalError
from time import sleep
from datetime import datetime
from urllib.parse import parse_qsl
import json
from typing import Any, Callable, Iterator, Iterable, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, TypedDict, cast
from attrs import frozen, fields, evolve
from ..defs import MediaRef, RefType, VideoIds
from .types import JsonResult, JsonData, Params
from .kotools import KodiRpc
from .item import FFItem
from .db import sql_dump
from ..indexers.defs import VideoSequenceMixin
from .settings import settings, advanced_settings
from .calendar import fromisoformat
from .logs import fflog, fflog_exc
from .control import plugin_url, ff2_plugin_url
from const import const
if TYPE_CHECKING:
    from typing_extensions import TypeAlias
    from mysql.connector import MySQLConnection, PooledMySQLConnection
    from xbmc import InfoTagVideo
    from .db.playback import MediaPlayInfo

from xbmcvfs import translatePath, File
from ..kodi import version as kodi_ver


QueryParams: TypeAlias = 'dict[str, str]'
# fid, bid, fname, play_count, lastPlayed, time_s, total_s
InfoRow: TypeAlias = 'tuple[int, int | None, str, int | None, str | None, float | None, float | None]'
#: The media of a file in Kodi library: (Kodi type `movie` / `episode`, its DBID).
LibraryMedia: TypeAlias = 'tuple[str, int]'
#: A row of an STRM file in Kodi DB: fid, bid, folder, file name, play count, lastPlayed, time_s, total_s, movie DBID, episode DBID.
StrmRow: TypeAlias = 'tuple[int, int | None, str, str, int | None, str | None, float | None, float | None, int | None, int | None]'
#: The state of a file of Kodi DB: (mtime in ns, size, inode), None if there is no such file.
FileStamp: TypeAlias = 'tuple[int, int, int] | None'



def int_on_none(value: Any) -> int | None:
    """Returns int or None."""
    if value is None:
        return None
    return int(value)


#: Video stream of the TT430 cancel placeholder (resources/media/tt430.mp4): codec, width, height, duration.
#: Kodi stores it for the canceled item when it extracts the stream details from the played placeholder.
TT430_VIDEO_STREAM: tuple[str, int, int, int] = ('h264', 1280, 720, 25800)
#: Duration (seconds) of the TT430 placeholder: Kodi stores a resume point of the played placeholder too.
TT430_DURATION: int = TT430_VIDEO_STREAM[3]


#: Values in one SQL `IN (…)` (SQLite before 3.32 takes at most 999 parameters).
SQL_CHUNK: int = 500

#: SQL condition of a bookmark (`b`) with the resume point of the TT430 placeholder (`KodiVideoInfo.placeholder_resume`).
PLACEHOLDER_RESUME_WHERE: str = f'ROUND(b.totalTimeInSeconds) = {TT430_DURATION}'


def _is_placeholder_stream(row: Mapping[str, Any]) -> bool:
    """True if the stream details row is the TT430 placeholder video (not the real media)."""
    return row.get('iStreamType') == 0 and (row.get('strVideoCodec'), row.get('iVideoWidth'), row.get('iVideoHeight'),
                                            row.get('iVideoDuration')) == TT430_VIDEO_STREAM


@frozen(kw_only=True)
class KodiVideoInfo:
    """Played/playing video DB row."""

    #: Media reference.
    ref: MediaRef
    #: files.fileId
    fid: int | None = None
    #: bookmark.bookmarkId
    bid: int | None = None
    #: files.strFilename
    fname: str = ''
    #: files.playCount
    play_count: int = 0
    #: Last played at (files.lastPlayed).
    played_at: int | None = None
    #: bookmark.timeInSeconds
    time_s: float = 0
    #: bookmark.totalTimeInSeconds
    total_s: float = 0
    #: TMDB of movie or tv-show if any
    tmdb: int | None = None
    #: IMDB of movie or tv-show if any
    imdb: str | None = None
    #: Video is in library
    library: bool | None = None
    #: Media label.
    label: str | None = None
    #: Stream details rows (streamdetails table, column -> value), only if requested (see KodiVideoDB.get_plays()).
    streams: tuple[Mapping[str, Any], ...] = ()

    @property
    def percent(self) -> float | None:
        """Progress in percent (0..100)."""
        if self.total_s:
            return 100 * self.time_s / self.total_s
        return None

    @property
    def has_progress(self) -> bool:
        """File has progress (is playing)."""
        return bool(self.total_s)

    @property
    def fake(self) -> bool:
        """True if info is fake."""
        return self.fid is None

    @property
    def placeholder_resume(self) -> bool:
        """True if the resume point is the one of the TT430 placeholder (its whole duration), not of the media."""
        return round(self.total_s) == TT430_DURATION

    def play_info(self, account_id: str) -> MediaPlayInfo:
        """
        Return the playback row of the local Kodi account: play count, resume point (a placeholder one is skipped)
        and the play time (`last_watched_at` if watched, `paused_at` if in progress).
        """
        from .db.playback import MediaPlayInfo
        resume = self.has_progress and not self.placeholder_resume
        return MediaPlayInfo(ref=self.ref, account_id=account_id, ffid=self.ref.ffid if self.ref.is_movie else 0,
                             play_count=self.play_count, progress=self.percent if resume else None,
                             duration=int(self.total_s) if resume else None,
                             last_watched_at=self.played_at if self.play_count else None,
                             paused_at=self.played_at if resume else None)

    def add_streams(self, vtag: InfoTagVideo) -> None:
        """
        Add the stream details (from Kodi video DB) to the video info tag of an item.

        The TT430 placeholder details stored for a canceled item (wrong 7 h 10 min, 720p) are skipped. If nothing is
        left an empty video stream is added: an item with stream details is not filled by Kodi from its DB (it would
        show the placeholder ones) and the empty stream shows nothing.
        """
        from xbmc import VideoStreamDetail, AudioStreamDetail, SubtitleStreamDetail
        rows = [row for row in self.streams if not _is_placeholder_stream(row)]
        if not rows and self.streams:
            vtag.addVideoStream(VideoStreamDetail())
            return
        for row in rows:
            typ = row.get('iStreamType')
            # positional arguments: their order is the Kodi API, the keyword names differ in lib.fake
            if typ == 0:  # CStreamDetail::VIDEO: width, height, aspect, duration, codec, stereomode, language, hdrtype
                vtag.addVideoStream(VideoStreamDetail(row.get('iVideoWidth') or 0, row.get('iVideoHeight') or 0,
                                                      row.get('fVideoAspect') or 0.0, row.get('iVideoDuration') or 0,
                                                      row.get('strVideoCodec') or '', row.get('strStereoMode') or '',
                                                      row.get('strVideoLanguage') or '', row.get('strHdrType') or ''))
            elif typ == 1:  # CStreamDetail::AUDIO: channels, codec, language
                channels = row.get('iAudioChannels')
                vtag.addAudioStream(AudioStreamDetail(-1 if channels is None else channels, row.get('strAudioCodec') or '',
                                                      row.get('strAudioLanguage') or ''))
            elif typ == 2:  # CStreamDetail::SUBTITLE: language
                vtag.addSubtitleStream(SubtitleStreamDetail(row.get('strSubtitleLanguage') or ''))

    def ffitem(self, *, role: str | None = None) -> FFItem:
        """Return FFItem from this video info."""
        # ref = self.ref
        # ff = FFItem(self.label, type=ref.type, ffid=ref.ffid, season=ref.season, episode=ref.episode)
        ff = FFItem(self.ref)
        if self.label:
            ff.label = self.label
        if self.tmdb:
            ff.vtag.setUniqueID(str(self.tmdb), 'tmdb', True)
        if self.imdb:
            ff.vtag.setUniqueID(self.imdb, 'imdb')
        if role is not None:
            played_at = datetime.min if self.played_at is None else datetime.fromtimestamp(self.played_at)
            ff.role = role.format(self, pb=self, info=self, percent=self.percent or '', play_count=self.play_count,
                                  played_at=played_at, played_at_timestamp=played_at)
        ff.kodi_data = self
        return ff


class VideoInfoList(VideoSequenceMixin[KodiVideoInfo], list):
    pass


def detect_db_version() -> str:
    """Return the Kodi video DB version found in the Kodi log ("Running database version MyVideos<version>"), the latest known one if not found."""
    fallback = '131'  # the latest known version
    log_path = Path(translatePath('special://logpath')) / 'kodi.log'
    rx = re.compile(r'Running database version MyVideos(\d+)\b|Attempting to update the database MyVideos\d* from version \d+ to (\d+)\b')
    try:
        with open(log_path, encoding='utf-8', errors='ignore') as f:
            # read first N lines or all lines
            lines = islice(f, const.dev.kodidb.number_or_log_lines) if const.dev.kodidb.number_or_log_lines > 0 else f
            for line in lines:
                if 'MyVideos' in line and (mch := rx.search(line)):
                    return mch[1] or mch[2]
    except FileNotFoundError:
        fflog(f'Kodi log file {log_path} not found, fallback to latest known version')
    except OSError as exc:
        fflog.warning(f'Failed to read {log_path} for MyVideos version: {exc}')
    return fallback


def video_db_version() -> str:
    """
    Return Kodi Video Database version (`const.dev.kodidb.ver`, empty: by the Kodi version, else from the Kodi log),
    see: https://kodi.wiki/view/Databases#Database_Versions
    """
    return _video_db_version(const.dev.kodidb.ver)


@lru_cache(maxsize=1)  # by the value of const: the log is read once, a reload of const changing the value gives a new one
def _video_db_version(forced: str) -> str:
    """Return Kodi Video Database version: `forced`, the known one of the Kodi version or the one of the Kodi log."""
    return forced or {
        19: '119',
        20: '121',
        21: '131',
    }.get(kodi_ver, '') or detect_db_version()


class MySqlCredentials(TypedDict):
    """Credentials for mysql connector."""
    host: str
    port: int
    user: str
    password: str


@frozen(kw_only=True)
class VideoDbConf:
    """
    Koid VideoDb configuration taken from advancedsettings.xml
    and keep in FF3 settings to avoid XML parse each time.
    """
    type: Literal['sqlite3', 'mysql'] = 'sqlite3'
    host: str = '127.0.0.1'
    port: int = 3306
    user: str = 'kodi'
    password: str = ''
    #: DB name without the version (`<name>`), Kodi uses the newest `<name><version>` DB (CDatabase::Update).
    name: str = 'MyVideos'
    #: TLS client key, certificate, CA, CA path, ciphers: like Kodi, TLS only if any is set (mysqldataset.cpp).
    key: str = ''
    cert: str = ''
    ca: str = ''
    capath: str = ''
    ciphers: str = ''

    def mysql_tls(self) -> dict[str, Any]:
        """Return TLS arguments of mysql connector: TLS off unless set (Kodi does the same, the TLS handshake costs ~20 ms)."""
        if not (self.key or self.cert or self.ca or self.capath or self.ciphers):
            return {'ssl_disabled': True}
        tls = {'ssl_key': self.key, 'ssl_cert': self.cert, 'ssl_ca': self.ca}
        return {k: v for k, v in tls.items() if v}

    def mysql_credentials(self) -> MySqlCredentials:
        """Return credentials for mysql connector (no DB, see `KodiVideoDB.connection()`)."""
        return {
            'host': self.host,
            'port': self.port,
            'user': self.user,
            'password': self.password,
        }


@frozen(kw_only=True)
class PlaysRead:
    """The FF plays read from Kodi DB (`KodiVideoDB.get_plays()`) with the state of its files before the read."""

    #: The state of Kodi DB files (`KodiVideoDB.db_stamp()`), None for MySQL (no files: kept for one plugin call only).
    stamp: tuple[FileStamp, ...] | None
    #: The rows of all FF play URLs.
    rows: list[InfoRow]
    #: The played STRM files of the library with their URLs and media (`KodiVideoDB._strm_files()`), None if not read.
    strm: list[tuple[InfoRow, str, LibraryMedia | None]] | None = None


def _in_lib_query(cur: Cursor, table: str, file_id: int) -> bool:
    """Returns True if video is in kodi library."""
    try:
        cur.execute(f'SELECT 1 FROM {table} WHERE idFile = {file_id}')
        return bool(cur.fetchall())
    except OperationalError as exc:
        fflog(f'Query library for {table}:{file_id} failed: {exc}')
        return False


def parse_datetime(val: str | None) -> int | None:
    """Parse datetime and convert to timestamp."""
    if not val:
        return None
    return int(fromisoformat(val).timestamp())


def _play_urls_where() -> str:
    """Return the SQL condition of the FF play URLs (FF3 and FF2) in `files.strFilename`."""
    return ' OR '.join(f"strFilename LIKE '{p}%'" for p in {plugin_url, ff2_plugin_url})


def _play_ref(fname: str, ffids: set[int] | None = None) -> tuple[MediaRef, str | None] | None:
    """Return the media ref of the FF play URL (FF3 `play/movie/…`, `play/show/…`; FF2 `?action=play…&tmdb=…`) and the IMDb ID
    of an FF2 URL, None if it is not an FF play or not of the media `ffids` (cheap: the plays of other media are skipped
    before any ref is made, `_make_info()`)."""
    if fname.startswith(plugin_url) and fname.startswith('play/', len(plugin_url)):
        kind, _, rest = fname[len(plugin_url) + 5:].partition('?')[0].partition('/')
        nums = rest.split('/')
        if all(num.isdigit() for num in nums) and (ffids is None or int(nums[0]) in ffids):
            if kind == 'movie' and len(nums) == 1:
                return MediaRef.movie(int(nums[0])), None
            if kind == 'show' and len(nums) == 3:
                return MediaRef.tvshow(*map(int, nums)), None
        return None
    if fname.startswith(ff2_plugin_url):
        params = dict(parse_qsl(fname.partition('?')[2]))
        if not (tmdb := params.get('tmdb', '')).isdigit() or (ffids is not None and VideoIds.TMDB.start + int(tmdb) not in ffids):
            return None  # a movie and a show of TMDB have the same FFID range
        if params.get('season', '').isdigit() and params.get('episode', '').isdigit():
            return MediaRef.from_tmdb('show', int(tmdb), int(params['season']), int(params['episode'])), params.get('imdb')
        return MediaRef.from_tmdb('movie', int(tmdb)), params.get('imdb')
    return None


def _make_info(row: InfoRow, ref: MediaRef, imdb: str | None = None, *, library: bool | None = None) -> KodiVideoInfo:
    """
    Create KodiVideoInfo of the play `ref` (see `_play_ref()`) from VideosDB SELECT, see KodiVideoDB.get_plays(); `library`:
    a STRM file of the library (`fname` is its path).
    """
    fid, bid, fname, play_count, played_at, time_s, total_s = row  # NOTE: in SEELCT order.
    vid = ref.video_ids
    return KodiVideoInfo(ref=ref, fid=fid, bid=bid, fname=fname, play_count=play_count or 0, played_at=parse_datetime(played_at),
                         time_s=time_s or 0, total_s=total_s or 0, tmdb=vid.tmdb, imdb=imdb or vid.imdb, library=library)


def _wanted_refs(refs: Iterable[MediaRef]) -> Callable[[MediaRef], bool]:
    """Return the test of a play ref: one of the movies / episodes of `refs` or an episode of their shows / seasons (`MediaRef.covers()` by sets: the plays are thousands)."""
    exact: set[MediaRef] = set()
    shows: set[int] = set()
    seasons: set[tuple[int, int]] = set()
    for ref in refs:
        if ref.type == 'show' and ref.season is None:
            shows.add(ref.ffid)
        elif ref.type == 'show' and ref.episode is None:
            seasons.add((ref.ffid, ref.season or 0))
        else:
            exact.add(ref)

    def wanted(ref: MediaRef) -> bool:
        return ref in exact or (ref.type == 'show' and ref.season is not None and (ref.ffid in shows or (ref.ffid, ref.season) in seasons))

    return wanted


class KodiVideoDB(KodiRpc):
    """Kodi MyVideo*.db."""

    VTYPES: dict[str, RefType] = {
        'tvshow': 'show',
    }
    KTYPES: dict[str, RefType] = {
        'movie': 'movie',
        'show': 'tvshow',     # type: ignore  (out of RefType)
        'tvshow': 'tvshow',   # type: ignore  (out of RefType)
        'season': 'season',
        'episode': 'episode',
    }
    RPC_LIST_METHODS = {
        'movie': 'VideoLibrary.GetMovies',
        'show': 'VideoLibrary.GetTVShows',
        'tvshow': 'VideoLibrary.GetTVShows',
        'season': 'VideoLibrary.GetSeasons',
        'episode': 'VideoLibrary.GetEpisodes',
    }

    _plugin = plugin_url.rstrip('/')
    _old_plugin = 'plugin://plugin.video.fanfilm'  # FF2
    _old_plugin_pattern = _old_plugin if _old_plugin == _plugin else fr'(?:{_plugin}|{_old_plugin})'
    _rx_movie_link = re.compile(fr'{_plugin}/play\d*/movie/(?P<ffid>\d+)\b(?:\?.*)?'
                                fr'|{_old_plugin_pattern}?.*\btmdb=(?P<tmdb>\d+).*')
    _rx_episode_link = re.compile(fr'{_plugin}/play\d*/(?:tv)?show/(?P<ffid>\d+)/(?P<season>\d+)/(?P<episode>\d+)(?:\?.*)?'
                                  fr'|{_old_plugin_pattern}?.*\btmdb=(?P<old_tmdb>\d+)?&season=(?P<old_season>\d+)&episode=(?P<old_episode>\d+).*')
    _rx_url_link = re.compile(r'[^:]*://[^/]*/play\d*?/(?P<type>[^/]+)/(?P<id>\d+)(?:/(?P<season>\d+)/(?P<episode>\d+))?.*')

    def __init__(self, *, path: Path | None = None, echo: bool | None = None) -> None:
        super().__init__()
        echo = const.dev.db.echo if echo is None else bool(echo)
        #: Path to video DB given (None: of the current version, `path`).
        self._path: Path | None = path
        #: The FF plays read last, kept while Kodi DB files do not change (the service, every plugin call of a reused
        #: interpreter); MySQL: for one plugin call (`reset()`), the service reads them every time.
        self._plays: PlaysRead | None = None
        #: Kodi video DB name in MySQL (the newest `<name><version>`), found on the first connection.
        self._mysql_database: str | None = None
        #: Debug echo queries.
        self._echo: bool = echo

    @property
    def path(self) -> Path:
        """Return the path to video DB: the given one or the one of the current version (`video_db_version()`)."""
        if self._path is not None:
            return self._path
        return Path(translatePath('special://database')) / f'MyVideos{video_db_version()}.db'

    @path.setter
    def path(self, path: Path) -> None:
        """Set the path to video DB."""
        self._path = path

    def video_db_conf(self) -> VideoDbConf:
        """Return video db configurtion."""
        if const.core.kodidb.advanced_settings:
            if cred := advanced_settings.get('videodatabase'):
                cred['password'] = cred.pop('pass', '')  # replace key "pass" → "password"
                for key in ('name', 'key', 'cert', 'ca', 'capath', 'ciphers'):
                    if key in cred:
                        cred[key] = str(cred[key])
                allowed = {f.name for f in fields(VideoDbConf)}
                return VideoDbConf(**{k: v for k, v in cred.items() if k in allowed})
        return VideoDbConf()

    @contextmanager
    def connection(self) -> Iterator[Connection]:
        """
        Open a connection to the DB for this call (closed after it): every thread reads on its own, a long read (all plays,
        the STRM files of the library) never holds up another one (the service handles the folders of the plugin meanwhile).
        """
        sets = self.video_db_conf()
        conn: Connection | MySQLConnection | PooledMySQLConnection
        if sets.type == 'mysql':
            import mysql.connector
            try:
                conn = mysql.connector.connect(**sets.mysql_credentials(), **sets.mysql_tls(), autocommit=True, charset='utf8', use_unicode=True)
                cur = conn.cursor()
                if self._mysql_database is None:
                    # the newest `<name><version>` DB is the one Kodi uses (it copies the DB to a new name on update)
                    cur.execute('SHOW DATABASES')
                    name = sets.name
                    dbs = [db for row in cur.fetchall() if (db := str(row[0])).startswith(name) and db[len(name):].isdecimal()]
                    self._mysql_database = max(dbs, key=lambda db: int(db[len(name):]), default=f'{name}{video_db_version()}')
                cur.execute(f'USE `{self._mysql_database}`')
                cur.close()
            except mysql.connector.Error as exc:
                fflog.error(f'mysql connection failed {exc} ({sets.user}@{sets.host}:{sets.port}, {self._mysql_database or sets.name})')
                raise
        else:
            conn = db_connect(f'file:{self.path}?mode=ro', uri=True, check_same_thread=False, timeout=10)
            if self._echo:
                conn.set_trace_callback(self._log_statement)
        try:
            yield conn  # type: ignore[misc]  # a MySQL connection has the same DB-API calls
        finally:
            conn.close()

    @property
    def errors(self) -> tuple[type[Exception], ...]:
        """DB errors to retry on (SQLite, and MySQL if used)."""
        if self.video_db_conf().type == 'mysql':
            import mysql.connector
            return OperationalError, mysql.connector.Error
        return OperationalError,

    @contextmanager
    def cursor(self) -> Iterator[Cursor]:
        """Create DB cursor."""
        with self.connection() as conn:
            cur = conn.cursor()
            try:
                yield cur
            finally:
                try:
                    conn.commit()
                finally:
                    cur.close()

    @property
    def echo(self) -> bool:
        """Echo queries (debug)."""
        return self._echo

    @echo.setter
    def echo(self, echo: bool) -> None:
        """Echo queries (debug)."""
        self._echo = bool(echo)  # the next connection (SQLite)

    def _log_statement(self, stmt: str):
        """Echo SQL statement."""
        fflog(f'(DB:{self.path.stem}) \033[38;5;244m {stmt!r} \033[0m', stack_depth=2)

    def get_plays(self,
                  refs: Iterable[MediaRef] | None = None,
                  *,
                  tries: int = 3,
                  streams: bool = False,
                  library: bool = False,
                  ) -> list[KodiVideoInfo]:
        """
        Return played or playing FF videos (FF3 and FF2 play URLs) with their stream details if `streams`: all of them, or
        the ones of `refs` (a show / season: its episodes); only the plays of their media are parsed (`_play_ref()`).
        With `library` the played FF STRM files of the library too (Kodi keeps their plays in the STRM file rows, see
        `_strm_files()`; `fname` is the path of the file): a media can have more plays than one.
        """
        where = _play_urls_where()
        if refs is not None:
            refs = set(refs)
        wanted: Callable[[MediaRef], bool] | None = None if refs is None else _wanted_refs(refs)
        ffids: set[int] | None = None if refs is None else {ref.ffid for ref in refs}
        last_exc: Exception | None = None
        from ..service import SERVICE
        for cnt in range(tries):
            try:
                # the state of the files before the read: a write of Kodi meanwhile changes it again (read next time)
                stamp = self.db_stamp()
                if (kept := self._plays) is not None and kept.stamp != stamp:
                    kept = None
                rows = None if kept is None else kept.rows
                strm = None if kept is None else kept.strm
                strm_rows: list[StrmRow] | None = None
                if rows is None or (library and strm is None):
                    # the connection only for the queries: the rows are parsed and the STRM files read after it
                    with self.cursor() as cur:
                        if rows is None:
                            rows = self._plays_select(cur, where)
                        if library and strm is None:
                            strm_rows = self._strm_select(cur)
                # row[2] - in order in SELECT above, it's `strFilename`
                plays = VideoInfoList(_make_info(row, *parsed) for row in rows
                                      if (parsed := _play_ref(row[2], ffids)) is not None and (wanted is None or wanted(parsed[0])))
                kept_strm = strm
                if library and strm is None:
                    strm = self._strm_files(strm_rows or [])
                    # an unreadable file (no URL, e.g. an offline share) is tried again after its TTL, not kept
                    kept_strm = strm if len(strm) == len(strm_rows or ()) else None
                if stamp is not None or not SERVICE:
                    self._plays = PlaysRead(stamp=stamp, rows=rows, strm=kept_strm)  # one record: the threads of the service
                if library and strm:
                    # a STRM file: the media of its URL, the info of the file (`fname`: its path)
                    plays.extend(_make_info(row, *parsed, library=True) for row, url, _ in strm
                                 if (parsed := _play_ref(url, ffids)) is not None and (wanted is None or wanted(parsed[0])))
                if streams and plays:
                    if wanted is None:
                        stream_where = f'f.idFile IN (SELECT idFile FROM files WHERE {where})'
                    else:
                        stream_where = f's.idFile IN ({",".join(str(pb.fid) for pb in plays)})'
                    with self.cursor() as cur:
                        cur.execute('SELECT s.* FROM streamdetails AS s JOIN files AS f ON f.idFile = s.idFile'
                                    f' WHERE {stream_where}')
                        names = [col[0] for col in cur.description]
                        stream_rows = cur.fetchall()
                    by_file: dict[int, list[Mapping[str, Any]]] = {}
                    for row in stream_rows:
                        data = dict(zip(names, row))
                        by_file.setdefault(data['idFile'], []).append(data)
                    plays = VideoInfoList(evolve(pb, streams=tuple(by_file[pb.fid])) if pb.fid in by_file else pb for pb in plays)
                return plays
            except self.errors as exc:
                last_exc = exc
                if cnt + 1 < tries:
                    sleep(.1)
        fflog(f'Access to kodi DB failed: {last_exc}')
        return VideoInfoList()

    def reset(self) -> None:
        """Start a plugin call: the FF plays of MySQL are read again (SQLite: again after a change of its files, `db_stamp()`)."""
        if (kept := self._plays) is not None and kept.stamp is None:
            self._plays = None

    def db_stamp(self) -> tuple[FileStamp, ...] | None:
        """
        Return the state of Kodi DB files (SQLite: the DB and its WAL, every commit of Kodi changes it), None for MySQL.
        """
        if self.video_db_conf().type == 'mysql':
            return None
        stamps: list[FileStamp] = []
        for path in (self.path, self.path.with_name(f'{self.path.name}-wal')):
            try:
                st = path.stat()
            except OSError:
                stamps.append(None)
            else:
                stamps.append((st.st_mtime_ns, st.st_size, st.st_ino))
        return tuple(stamps)

    @staticmethod
    def _plays_select(cur: Cursor, where: str, *, placeholder: bool = False) -> list[InfoRow]:
        """
        Return the rows of the FF play URLs (`where`, see `_play_urls_where()`), only the ones with the resume point of the TT430
        placeholder if `placeholder`.
        """
        if placeholder:
            where = f'({where}) AND {PLACEHOLDER_RESUME_WHERE}'
        cur.execute('SELECT'
                    ' f.idFile, b.idBookmark, strFilename, playCount, lastPlayed, timeInSeconds, totalTimeInSeconds'
                    ' FROM files AS f LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1'
                    f" WHERE {where}")
        return cur.fetchall()

    @staticmethod
    def _strm_select(cur: Cursor, *, played: bool = True, placeholder: bool = False) -> list[StrmRow]:
        """
        Return the rows of the STRM files of the library (only the played ones if `played`: watched or with a resume point,
        only the ones with the resume point of the TT430 placeholder if `placeholder`).
        """
        where = ' AND (f.playCount > 0 OR b.idBookmark IS NOT NULL)' if played else ''
        if placeholder:
            where += f' AND {PLACEHOLDER_RESUME_WHERE}'
        cur.execute('SELECT'
                    ' f.idFile, b.idBookmark, p.strPath, f.strFilename, f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds,'
                    ' m.idMovie, e.idEpisode'
                    ' FROM files AS f JOIN path AS p ON p.idPath = f.idPath'
                    ' LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1'
                    ' LEFT JOIN movie AS m ON m.idFile = f.idFile LEFT JOIN episode AS e ON e.idFile = f.idFile'
                    f" WHERE f.strFilename LIKE '%.strm'{where}")
        return cur.fetchall()

    @staticmethod
    def _strm_files(rows: Sequence[StrmRow], *, played: bool = True) -> list[tuple[InfoRow, str, LibraryMedia | None]]:
        """
        Return the STRM file rows (`_strm_select()`, read before: no connection to Kodi DB while the files are read) with the
        URL of the file and its library media: (the row with the path of the file, the URL, (Kodi type, DBID) or None); the
        files of other add-ons are skipped later (`_play_ref()`). The URLs are kept in the library DB (thousands of files are
        slow to read, a STRM file keeps its URL), a new file is read once, an unreadable one again after
        `const.library.strm.unreadable_ttl`; all files (not `played`): the files gone from the library are removed there.
        """
        from .db import library as library_db
        known = library_db.strm_urls()
        new: dict[str, str] = {}
        found: list[tuple[InfoRow, str, LibraryMedia | None]] = []
        for fid, bid, folder, fname, play_count, played_at, time_s, total_s, movie_id, episode_id in rows:
            path = f'{folder}{fname}'
            if (url := known.get(path)) is None:
                try:
                    url = load_strm_file(path)
                except (OSError, RuntimeError):
                    url = ''  # unreadable now: a removed file (Kodi cleans it later), a path of another device, an offline share
                new[path] = url
            if url:
                media: LibraryMedia | None = ('movie', movie_id) if movie_id else ('episode', episode_id) if episode_id else None
                found.append(((fid, bid, path, play_count, played_at, time_s, total_s), url, media))
        if new:
            library_db.store(new, unreadable_ttl=const.library.strm.unreadable_ttl)
        if not played:
            library_db.prune({f'{folder}{fname}' for _, _, folder, fname, *_ in rows})
        return found

    def library_plays(self, *, tries: int = 3) -> list[tuple[KodiVideoInfo, LibraryMedia]]:
        """
        Return the FF STRM files of the library (played or not) with their library media (Kodi type, DBID), see `_strm_files()`;
        `fname` of the info is the path of the file. Empty if Kodi DB fails.
        """
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    rows = self._strm_select(cur, played=False)
                return [(_make_info(row, *parsed, library=True), media) for row, url, media in self._strm_files(rows, played=False)
                        if media is not None and (parsed := _play_ref(url)) is not None]
            except self.errors as exc:
                if cnt + 1 >= tries:
                    fflog(f'Access to kodi DB failed: {exc}')
                else:
                    sleep(.1)
        return []

    def placeholder_plays(self, *, tries: int = 3) -> list[tuple[KodiVideoInfo, LibraryMedia | None]]:
        """
        Return the FF plays with the resume point of the TT430 placeholder (`KodiVideoInfo.placeholder_resume`): the FF play URLs
        (no library media) and the STRM files of the library with their library media (`fname` is the path of the file).
        Only these bookmarks are read: none once they are repaired. Empty if Kodi DB fails.
        """
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    rows = self._plays_select(cur, _play_urls_where(), placeholder=True)
                    strm_rows = self._strm_select(cur, placeholder=True)
                # row[2] - in order in SELECT, it's `strFilename`
                plays: list[tuple[KodiVideoInfo, LibraryMedia | None]] = [(_make_info(row, *parsed), None) for row in rows
                                                                          if (parsed := _play_ref(row[2])) is not None]
                if strm_rows:  # no library DB read when there is none (the usual case)
                    plays.extend((_make_info(row, *parsed, library=True), media) for row, url, media in self._strm_files(strm_rows)
                                 if (parsed := _play_ref(url)) is not None)
                return plays
            except self.errors as exc:
                if cnt + 1 >= tries:
                    fflog(f'Access to kodi DB failed: {exc}')
                else:
                    sleep(.1)
        return []

    def reread_plays(self, plays: Sequence[KodiVideoInfo], *, tries: int = 3) -> list[KodiVideoInfo]:
        """
        Return `plays` with their play state (play count, last play, resume point) read again from Kodi DB by their file IDs
        (e.g. after a write: what Kodi keeps, not what was sent); a play not found or the DB failing - as given.
        """
        if not (fids := [pb.fid for pb in plays if pb.fid is not None]):
            return list(plays)
        rows: dict[int, InfoRow] = {}
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    for i in range(0, len(fids), SQL_CHUNK):
                        cur.execute('SELECT f.idFile, b.idBookmark, f.strFilename, f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds'
                                    ' FROM files AS f LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1'
                                    f' WHERE f.idFile IN ({",".join(str(fid) for fid in fids[i:i + SQL_CHUNK])})')
                        rows.update((row[0], row) for row in cur.fetchall())
                break
            except self.errors as exc:
                if cnt + 1 >= tries:
                    fflog(f'Access to kodi DB failed: {exc}')
                    return list(plays)
                sleep(.1)
        return [evolve(pb, bid=row[1], play_count=row[3] or 0, played_at=parse_datetime(row[4]), time_s=row[5] or 0, total_s=row[6] or 0)
                if pb.fid is not None and (row := rows.get(pb.fid)) else pb for pb in plays]

    def get_play(self, ref: MediaRef, *, tries: int = 3, old_fanfilm: bool = True) -> KodiVideoInfo | None:
        """Return played or playing movie or episode by ref (its FF3 play, else its FF2 one if `old_fanfilm`)."""
        if not (ref.is_movie or ref.is_episode):
            return None
        plays = [pb for pb in self.get_plays([ref], tries=tries) if old_fanfilm or pb.fname.startswith(plugin_url)]
        plays.sort(key=lambda pb: not pb.fname.startswith(f'{plugin_url}play/'))  # FF3 first
        return next(iter(plays), None)

    def mark_watched(self, refs: Iterable[MediaRef], *, watched: bool = True, progress: Callable[[int, int], None] | None = None) -> int:
        """
        Set (un)watched directly in Kodi video DB via JSON-RPC (works for non-library items too): the movies and episodes
        of `refs` whose FF play is in another state (one read of Kodi DB, like Kodi's own mark of a folder); `progress(done, total)`
        after each of them. Return the number of the changed ones.

        Kodi writes every `Files.SetFileDetails` in its own transaction (50-200 ms, a new file row the most): the ones
        in the state already are skipped, a show marked again costs one read.
        """
        refs = [ref for ref in refs if ref.is_movie or ref.is_episode]
        plays = {pb.ref: pb for pb in self.get_plays(refs) if pb.fname.startswith(f'{plugin_url}play/')}

        def differs(pb: KodiVideoInfo | None) -> bool:
            """True if the play is not in the target state (watched: a play count, unwatched: no play count nor resume point)."""
            if watched:
                return pb is None or not pb.play_count
            return pb is not None and bool(pb.play_count or pb.has_progress)

        changes = [ref for ref in refs if differs(plays.get(ref))]
        plugin = plugin_url.rstrip('/')
        for i, ref in enumerate(changes, 1):
            if ref.is_movie:
                link = f'{plugin}/play/movie/{ref.ffid}'
            else:
                link = f'{plugin}/play/show/{ref.ffid}/{ref.season}/{ref.episode}'
            params: dict[str, Any] = {'file': link, 'media': 'video', 'playcount': 1 if watched else 0, 'resume': {'position': 0, 'total': 0}}
            if watched:
                # now: Kodi keeps the last played time of an unwatched file, an old one loses to the removal time of the unmark before
                params['lastplayed'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            try:
                self.rpc('Files.SetFileDetails', params=params)
            except Exception:
                fflog_exc()
            if progress is not None:
                progress(i, len(changes))
        return len(changes)

    def file_details(self, url: str) -> JsonData:
        """Return the play state of `url` (play count, last played, resume point) as `Files.SetFileDetails` params, raise the DB error."""
        info = self.read_play_by_url(url)
        played_at = info and info.played_at
        return {
            'file': url,
            'media': 'video',
            # `lastplayed` alone sets the play count to at least 1 (Kodi Files.SetFileDetails), so it is given too
            'playcount': info.play_count if info else 0,
            'lastplayed': datetime.fromtimestamp(played_at).strftime('%Y-%m-%d %H:%M:%S') if played_at else '',
            'resume': {'position': info.time_s if info else 0, 'total': info.total_s if info else 0},
        }

    def set_file_details(self, details: JsonData) -> None:
        """Set the play state of a file, `details` from file_details()."""
        try:
            self.rpc('Files.SetFileDetails', params=details)
        except Exception:
            fflog_exc()

    def get_play_by_url(self, url: str | Sequence[str], *, tries: int = 3) -> KodiVideoInfo | None:
        """"Return played or playing video by its URL (plugin://...), None if not found or the DB fails."""
        try:
            return self.read_play_by_url(url, tries=tries)
        except self.errors:
            return None

    def read_play_by_url(self, url: str | Sequence[str], *, tries: int = 3) -> KodiVideoInfo | None:
        """"Return played or playing video by its URL (plugin://...), None if not found; the DB error is raised after the last try."""

        select = ('SELECT f.idFile, b.idBookmark, strFilename, playCount, lastPlayed, timeInSeconds, totalTimeInSeconds'
                  ' FROM files AS f LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1 WHERE ')
        if isinstance(url, str):
            select += f' strFilename = {sql_dump(url)}'
        else:
            values = ','.join(sql_dump(u) for u in url)
            select += f' strFilename IN ({values})'

        row: InfoRow | None = None
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    cur.execute(select)
                    row = cur.fetchone()
                    fflog(f'[KodiDB] found url: {row=}')
                break
            except self.errors:
                if cnt + 1 >= tries:
                    raise
                sleep(.1)
        fflog(f'[KodiDB] {select=}, {row=}')
        if row:
            fid, bid, fname, play_count, played_at, time_s, total_s = row
            if 'tmdb=' in fname:
                # FF2
                params = dict(parse_qsl(fname.partition('?')[2]))
                tmdb = int(params['tmdb'])
                imdb = params.get('imdb')
                if (season := params.get('season')) and (episode := params.get('episode')):
                    ref = MediaRef('show', VideoIds(tmdb=tmdb).ffid, int(season), int(episode))
                else:
                    ref = MediaRef('movie', VideoIds(tmdb=tmdb).ffid)
            else:
                # FF3
                if mch := self._rx_url_link.fullmatch(fname):
                    if (season := mch['season']) and (episode := mch['episode']):
                        ref = MediaRef('show', int(mch['id']), int(season), int(episode))
                    else:
                        ref = MediaRef('movie', int(mch['id']))
                    vid = ref.video_ids
                    tmdb, imdb = vid.tmdb, vid.imdb
                else:
                    ref = MediaRef('', 0)
                    tmdb = imdb = None
            return KodiVideoInfo(ref=ref, fid=fid, bid=bid, fname=fname, tmdb=tmdb, imdb=imdb,
                                 play_count=play_count or 0, played_at=parse_datetime(played_at), time_s=time_s or 0, total_s=total_s or 0)
        return None

    def get_kodi_dbid(self, ref: MediaRef, *, tries: int = 3) -> int:
        """Return kodi dbid for given `ref` or zero if not found."""
        rtype = ref.real_type
        vtype = self.KTYPES.get(rtype, rtype)  # kodi media type
        if vtype not in ('movie', 'episode', 'tvshow'):  # season is not in `uniqueid` table of kodi DB
            return 0
        if vtype == 'episode':
            vtype = 'tvshow'  # search for tvshow for episode first

        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    vid = ref.video_ids
                    # XX # first try to find in `files` (FF3 only)
                    # XX plugin = plugin_url.rstrip('/')
                    # XX cur.execute(f'''SELECT media_id FROM uniqueid WHERE strFilename = '{plugin}/play/{vtype}/{"/".join(ref.id_tuple)}' ''')
                    # XX row = cur.fetchone()
                    # second, try to find in library (in `uniqueid`)
                    where = ' OR '.join(f'''(type = '{service}' AND value = {value!r})'''
                                        for service, value in (('tmdb', vid.tmdb), ('imdb', vid.imdb), ('tvdb', vid.tvdb))
                                        if value)
                    if not where:
                        return 0  # no any supported service (ID type)
                    cur.execute(f'SELECT media_id FROM uniqueid WHERE {where}')
                    row = cur.fetchone()
                    if row:
                        if rtype == 'episode':  # ok, we have tvshow id, next we have to find episode id
                            cur.execute(f'SELECT idEpisode FROM episode WHERE idShow = {row[0]} AND c12 = {ref.season} AND c13 = {ref.episode}')
                            if not (row := cur.fetchone()):
                                return 0  # no matching episode
                        return int(row[0])
                break
            except self.errors:
                if cnt + 1 < tries:
                    sleep(.1)
        return 0

    def get_plays_for(self, items: Sequence[MediaRef | FFItem], *, tries: int = 3, streams: bool = False) -> Iterator[KodiVideoInfo]:
        """
        Get KodiVideoInfo for given media (with their stream details if `streams`): only movies and shows (their seasons and
        episodes) have plays, other items (menus, persons, collections) are no query.
        """
        if refs := {item.ref for item in items if item.ref.type in ('movie', 'show')}:
            yield from self.get_plays(refs, tries=tries, streams=streams)

    def get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                            tries: int = 3, read_strm: bool = False) -> KodiVideoInfo | None:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        return self.rpc_get_play_by_kodi_id(type=type, id=id, tries=tries, read_strm=read_strm)
        return self.direct_get_play_by_kodi_id(type=type, id=id, tries=tries, read_strm=read_strm)

    def direct_get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                                   tries: int = 3, read_strm: bool = False) -> KodiVideoInfo | None:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        vtype = self.VTYPES.get(type, cast(RefType, type))
        for cnt in range(tries):
            try:
                with self.cursor() as cur:
                    ref: MediaRef | None = None
                    service = uid = None
                    tv_service = tv_uid = None
                    season = episode = None
                    strm = None
                    fname = ''
                    play_count = time_s = total_s = 0
                    played_at = ''
                    bid = fid = 0
                    if vtype == 'movie':
                        query = ('SELECT'
                                 '  u.type AS service, u.value AS uid, c22 AS strm,'
                                 '  f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds,'
                                 '  f.idFile, b.idBookmark'
                                 ' FROM movie as m'
                                 ' LEFT JOIN uniqueid AS u ON m.idMovie = u.media_id AND u.media_type = \'movie\''
                                 ' LEFT JOIN files AS f ON m.idFile = f.idFile'
                                 ' LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1'
                                 ' WHERE idMovie = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid, strm, play_count, played_at, time_s, total_s, fid, bid = row
                    elif vtype == 'show':
                        query = ('SELECT'
                                 '  ut.type AS tv_service, ut.value AS tv_uid'
                                 ' FROM tvshow AS s'
                                 ' LEFT JOIN uniqueid AS ut ON s.idShow = ut.media_id AND ut.media_type = \'tvshow\''
                                 ' WHERE idShow = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid = row
                    elif vtype == 'season':
                        query = ('SELECT'
                                 '  ut.type AS tv_service, ut.value AS tv_uid, z.idSeason as season'
                                 ' FROM seasons AS z'
                                 ' LEFT JOIN tvshow AS s ON z.idShow = s.idShow'
                                 ' LEFT JOIN uniqueid AS ut ON s.idShow = ut.media_id AND ut.media_type = \'tvshow\''
                                 ' WHERE z.idSeason = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            tv_service, tv_uid, season = row
                    elif vtype == 'episode':
                        query = ('SELECT'
                                 '  u.type AS service, u.value AS uid, ut.type AS tv_service, ut.value AS tv_uid,'
                                 '  e.c12 AS season, e.c13 AS epsiode, e.c18 AS strm,'
                                 '  f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds,'
                                 '  f.idFile, b.idBookmark'
                                 ' FROM episode as e'
                                 ' LEFT JOIN uniqueid AS u ON e.c20 = u.uniqueid_id'
                                 ' LEFT JOIN tvshow AS s ON e.idShow = s.idShow'
                                 ' LEFT JOIN uniqueid AS ut ON s.c12 = ut.uniqueid_id AND ut.media_type = \'tvshow\''
                                 ' LEFT JOIN files AS f ON e.idFile = f.idFile'
                                 ' LEFT JOIN bookmark AS b ON b.idFile = f.idFile AND b.type = 1'
                                 ' WHERE idEpisode = {id}')
                        cur.execute(query.format(id=id))
                        if row := cur.fetchone():
                            service, uid, tv_service, tv_uid, season, episode, strm, play_count, played_at, time_s, total_s, fid, bid = row
                            season, episode = int(season), int(episode)
                    else:
                        return None
                    if tv_service and tv_uid:
                        try:
                            vid = VideoIds(**{tv_service: tv_uid})
                            ref = MediaRef.tvshow(vid.ffid, season, episode)
                        except TypeError:
                            pass
                    if not ref and service and uid:
                        try:
                            vid = VideoIds(**{service: uid})
                            ref = MediaRef(vtype, vid.ffid)  # denormalized
                        except TypeError:
                            return None
                    if not ref and strm:
                        # fallback: read strm file to get play link
                        try:
                            fname = load_strm_file(strm)
                        except IOError:
                            return None  # no ref and no strm (no FF link)
                        if vtype == 'movie':
                            rx = self._rx_movie_link
                        elif vtype == 'episode':
                            rx = self._rx_episode_link
                        else:
                            return None  # should never catch, there is no strm fiel for season or show
                        try:
                            fname = load_strm_file(strm)
                            if mch := rx.fullmatch(fname):
                                mtype = 'movie' if vtype == 'movie' else 'show'
                                if mch['ffid']:
                                    ref = MediaRef(mtype, *map(int, mch.group('ffid', 'season', 'episode')))
                                else:  # old (stable2023, FF2)
                                    ref = MediaRef(mtype, VideoIds(tmdb=int(mch['old_tmdb'])).ffid, *map(int, mch.group('old_season', 'old_episode')))
                        except IOError:
                            pass
                    elif read_strm and strm:
                        try:
                            fname = load_strm_file(strm)
                        except IOError:
                            pass

                    if ref:
                        return KodiVideoInfo(ref=ref, fid=fid, bid=bid, fname=fname,
                                             play_count=play_count, played_at=played_at, time_s=time_s, total_s=total_s)
            except self.errors:
                if cnt + 1 < tries:
                    sleep(.1)
        return None

    def rpc_get_play_by_kodi_id(self, type: Literal['movie', 'tvshow', 'show', 'season', 'episode'], id: int, *,
                                tries: int = 3, read_strm: bool = False) -> KodiVideoInfo | None:
        """Return played or playing video by kodi id. Accepts FF and kodi types."""
        vtype = self.VTYPES.get(type, cast(RefType, type))
        # method = self.RPC_LIST_METHODS[type]
        if vtype == 'movie':
            data = video_db.rpc_object('VideoLibrary.GetMovieDetails', params={'movieid': id},
                                       fields=['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime', 'file'])
        elif vtype == 'show':
            data = video_db.rpc_object('VideoLibrary.GetTVShowDetails', params={'tvshowid': id},
                                       fields=['uniqueid', 'playcount'])
        elif vtype == 'season':
            data = video_db.rpc_object('VideoLibrary.GetSeasonDetails', params={'seasonid': id},
                                       fields=['playcount', 'season', 'tvshowid'])
            # NOTE: VideoLibrary.GetSeasonDetails() has no `uniqueid`
            #       `uniqueid` param raises RPC error: array element at index 0 does not match
            if data and 'error' not in data and 'uniqueid' not in data:
                data['uniqueid'] = {}
        elif vtype == 'episode':
            data = video_db.rpc_object('VideoLibrary.GetEpisodeDetails', params={'episodeid': id},
                                       fields=['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime', 'season', 'episode', 'tvshowid', 'file'])
        else:
            return None
        if 'uniqueid' not in data:
            return None

        uniqueid = data['uniqueid']
        vid = VideoIds.from_ids(uniqueid)
        if vtype in ('season', 'episode'):
            tvdata = video_db.rpc_object('VideoLibrary.GetTVShowDetails', params={'tvshowid': data['tvshowid']}, fields=['uniqueid'])
            tv_uniqueid = tvdata['uniqueid']
            tv_vid = VideoIds.from_ids(tv_uniqueid)
            ref = MediaRef.tvshow(tv_vid.ffid, data.get('season'), data.get('episode'))
            tmdb, imdb = int_on_none(tv_uniqueid.get('tmdb')), tv_uniqueid.get('imdb')
        else:
            ref = MediaRef(vtype, vid.ffid)
            tmdb, imdb = int_on_none(uniqueid.get('tmdb')), uniqueid.get('imdb')

        time_s = total_s = 0
        if resume := data.get('resume'):
            time_s = resume['position']
            total_s = resume['total']
        fflog(f'_____DB_____\n{data = }')
        return KodiVideoInfo(ref=ref, tmdb=tmdb, imdb=imdb, fname=data.get('file', ''),
                             play_count=data.get('playcount', 0), played_at=parse_datetime(data.get('lastplayed', '')),
                             time_s=time_s, total_s=total_s)

    # WTF !!!
    # Not a list, just an object and there is no ID !!!
    # {'id': 1, 'jsonrpc': '2.0', 'result': [{'name': 'VideoPlayer', 'playsaudio': True, 'playsvideo': True, 'type': 'video'}]}
    def get_players(self) -> Sequence[int]:
        """Return list of ID of available video players."""
        x = self.rpc_list('Player.GetActivePlayers', params={'media': 'video'})
        fflog(f'Player.GetActivePlayers: {json.dumps(x, indent=2)}')
        return ...

    def get_player_item(self) -> Sequence[int]:
        """Return current player item."""
        fields = []
        fields += ['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime', 'file']
        fields += ['uniqueid', 'playcount']
        fields += ['playcount', 'season', 'tvshowid']
        fields += ['uniqueid', 'playcount', 'lastplayed', 'resume', 'runtime', 'season', 'episode', 'tvshowid', 'file']
        x = self.rpc_list('Player.GetItem', params={'playerid': 1}, fields=list(set(fields)))
        fflog(f'Player.GetItem: {json.dumps(x, indent=2)}')
        return ...

    def get_library(self,
                    media_type: Literal['movie', 'show', 'season', 'episode'] | None,
                    *,
                    remove_duplicates: bool = False,
                    deep: bool = False,
                    ) -> Iterable[KodiVideoInfo]:
        """Get Kodi library movies, ... (rpc)."""

        def parse(media: Literal['movie', 'show', 'season', 'episode'], it: JsonData) -> KodiVideoInfo:
            if media == 'movie':
                ffid = VideoIds.from_ids(it['uniqueid']).ffid
            elif media == 'show':
                ffid = VideoIds.from_ids(it['uniqueid']).ffid
                tvs[it['tvshowid']] = ffid
            else:  # season, episode
                ffid = tvs[it['tvshowid']]
                media = 'show'  # main type
            ref = MediaRef(media, ffid, season=it.get('season'), episode=it.get('episode'))
            uniqueid = it.get('uniqueid', {})
            resume = it.get('resume', {})
            return KodiVideoInfo(ref=ref,
                                 fname=it.get('file', ''),
                                 play_count=it.get('playcount', 0),
                                 played_at=parse_datetime(it.get('lastplayed', '')),
                                 time_s=resume.get('position', 0),
                                 total_s=resume.get('total', 0),
                                 tmdb=int_on_none(uniqueid.get('tmdb')),
                                 imdb=uniqueid.get('imdb', ''),
                                 label=it.get('label'),
                                 library=True,
                                 )

        from .debug import logtime
        with logtime(name='kodi db'):
            fields = {
                'movie': ('playcount', 'lastplayed', 'resume', 'uniqueid', 'file'),
                'show': ('playcount', 'lastplayed', 'uniqueid', 'file'),
                'season': ('tvshowid', 'season', 'playcount'),  # Kodi seasons reject "file"
                'episode': ('tvshowid', 'season', 'episode', 'playcount', 'lastplayed', 'resume', 'uniqueid', 'file'),
            }
            count = {}
            if not media_type:
                types = ('movie', 'show', 'season', 'episode')
            elif media_type in ('show', 'season', 'episode'):
                if deep:
                    types = ('show', 'season', 'episode')
                elif media_type == 'episode':
                    types = ('show', 'season', 'episode')
                elif media_type == 'season':
                    types = ('show', 'season')
                else:
                    types = ('show',)
            else:
                types = (media_type,)
            items: dict[MediaRef, JsonData] = {}
            tvs: dict[int, int] = {}  # tvshowid → ffid
            for media in types:
                with logtime(name=f' - {media}'):
                    data = self.rpc_list(self.RPC_LIST_METHODS[media], fields=fields[media])
                    count[media] = len(data)
                    # fflog(f'{self.RPC_LIST_METHODS[media]}: {json.dumps(data, indent=2)}')
                    if data:
                        fflog(f'{media}[0]: {json.dumps(data[0], indent=2)}')
                    for it in data:
                        yield parse(media, it)
            print(items.keys())

        fflog(f'Number of items {sum(count.values())}, {count}')
        return ()
        return [KodiVideoInfo(ref=MediaRef('movie', VideoIds.from_ids(ids).ffid),
                              fname=it['file'],
                              play_count=it['playcount'],
                              played_at=parse_datetime(it['lastplayed']),
                              time_s=it['resume']['position'],
                              total_s=it['resume']['total'],
                              tmdb=int(ids.get('tmdb') or 0),
                              imdb=ids.get('imdb', ''),
                              library=True,
                              ) for it in data if (ids := it['uniqueid'])]

    def get_library_dict(self,
                         media_type: Literal['movie', 'show', 'season', 'episode'] | None,
                         *,
                         remove_duplicates: bool = False,
                         deep: bool = False,
                         ) -> dict[MediaRef, KodiVideoInfo]:
        """Get Kodi library media, ... (rpc) as dict."""
        return {it.ref: it for it in self.get_library(media_type=media_type,
                                                      remove_duplicates=remove_duplicates, deep=deep)}

    def get_library_ffitems(self,
                            media_type: Literal['movie', 'show', 'season', 'episode'] | None,
                            *,
                            remove_duplicates: bool = False,
                            deep: bool = False,
                            strict: bool = True,
                            ) -> Sequence[FFItem]:
        """Get Kodi library media, ... (rpc) as ffitems."""
        items = {it.ref: it.ffitem() for it in self.get_library(media_type=media_type,
                                                                remove_duplicates=remove_duplicates, deep=deep)}
        for ref, ff in items.items():
            if ref.season is not None:
                ff.show_item = items.get(ref.show_ref)  # type: ignore[reportArgumentType]
                if ref.episode is not None:
                    ff.season_item = items.get(ref.season_ref)  # type: ignore[reportArgumentType]
        if strict and media_type:
            return tuple(ff for ref, ff in items.items() if ref.real_type == media_type)
        return tuple(items.values())


def load_strm_file(path: str) -> str:
    """Load STRM file."""
    with File(path) as f:
        content = f.read().strip()
    for line in content.splitlines():
        if line[:1] != '#':  # skip kodi property, see: https://kodi.wiki/view/Internet_video_and_audio_streams#Property_support:
            return line
    return ''


video_db = KodiVideoDB()


if __name__ == '__main__':
    def main_test():
        from pprint import pprint
        from ..ff.cmdline import DebugArgumentParser, parse_ref

        p = DebugArgumentParser(dest='cmd')
        p.add_argument('--dbpath', type=Path, default=Path('~/.kodi/userdata/Database').expanduser() / f'MyVideos{video_db_version()}.db',
                       help='path to Kodi MyVideos.db')
        # p.add_argument('--rpc-port', type=int, default=9090, help='Kodi JSON-RPC port')
        with p.with_subparser('ref') as pp:
            pp.add_argument('media', nargs='?', type=parse_ref, help='media: movie/ID or show/ID/SEASON/EPISODE')
        with p.with_subparser('id') as pp:
            pp.add_argument('type', choices=('movie', 'show', 'season', 'episode'), help='kodi media type')
            pp.add_argument('id', type=int, help='kodi dbid')
            pp.add_argument('--read-strm', action='store_true', help='force read strm file')
        with p.with_subparser('lib') as pp:
            pp.add_argument('type', nargs='?', choices=('movie', 'show', 'season', 'episode'), help='kodi media type')
            pp.add_argument('--remove-duplicates', action='store_true', help='remove duplicates from library')
        args = p.parse_args()

        kodidb = KodiVideoDB(path=args.dbpath)
        if args.cmd == 'ref':
            ref: MediaRef = args.media
            if ref:
                print(kodidb.get_play(ref))
            else:
                pprint(kodidb.get_plays())
        elif args.cmd == 'id':
            print(kodidb.get_play_by_kodi_id(args.type, args.id, read_strm=args.read_strm))
        elif args.cmd == 'lib':
            lib = tuple(kodidb.get_library(media_type=args.type, remove_duplicates=args.remove_duplicates))
            print(lib)
            # print([it for it in lib if it.time_s])
            # print([it for it in lib if it.play_count])

    main_test()
