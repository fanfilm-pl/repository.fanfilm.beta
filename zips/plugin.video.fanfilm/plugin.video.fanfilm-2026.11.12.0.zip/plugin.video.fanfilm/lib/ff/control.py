"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
import sys
import os.path
import time
import threading
from urllib.parse import parse_qsl
from weakref import WeakValueDictionary
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from typing import Mapping, TypeVar, overload, TYPE_CHECKING
from typing_extensions import Literal, ParamSpec
from attrs import define, field

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .locales import kodi_locale
from .settings import settings
from .threads import Lock, Timer, CancelScope, current_thread, current_scope
from ..kolang import L
from const import const, CONST_REF
from cdefs import const_value
if TYPE_CHECKING:
    from typing import Any, Sequence, Callable, Iterator, Generator
    from .kotools import Notification
    from .menu import DirectoryState
    from .item import FFItem


#: The arguments of a function that writes to the handle of the call, see handle_write().
P = ParamSpec('P')
#: The result of a function that writes to the handle of the call, see handle_write().
R = TypeVar('R')

AddonInfo = Literal['author', 'changelog', 'description', 'disclaimer', 'fanart', 'icon', 'id', 'name',
                    'path', 'profile', 'stars', 'summary', 'type', 'version']


class CallScope(CancelScope):
    """
    One plugin call: its Kodi arguments, its answer to Kodi, its state (the folder, the finalizers).

    The stop scope of the call; its threads (FF ones, pool workers) find it through their scopes, see current_call().
    """

    def __init__(self, argv: Sequence[str], parent: CancelScope | None = None) -> None:
        super().__init__(parent)
        #: The Kodi arguments of the call (`sys.argv` of a plugin).
        self.argv: list[str] = list(argv)
        #: The plugin URL without the query (`sys.argv[0]`).
        self.addon: str = argv[0]
        plugin = argv[0].startswith('plugin://')  # a script (`RunScript(<add-on>, args…)`): its own arguments, no handle, no query
        #: The Kodi handle of the call, -1 without one (RunPlugin, a script).
        self.handle: int = int(argv[1]) if plugin and len(argv) > 1 else -1
        #: The simplified query arguments, for the full ones use main.get_params().
        self.params: dict[str, str] = dict(parse_qsl(argv[2][1:])) if plugin and len(argv) > 2 else {}
        #: The `action` query argument.
        self.action: str | None = self.params.get('action')
        #: Set when the call answered Kodi (`end_of_directory()` / `resolved_url()`), see `answered`.
        self.answer: threading.Event = threading.Event()
        #: The call comes from a FF folder, None: not read yet (see remember_plugin_folder()).
        self.folder: bool | None = None
        #: The functions called at the call end (`Finally.call()`).
        self.finalizers: list[Finally] = []
        #: The folder state of the call, created on the first use (see KodiDirectory.state()).
        self.directory: DirectoryState | None = None
        #: The FFItems created in the call, destroyed at its end; None: not registered (the plugin destroys all its items).
        self.items: WeakValueDictionary[int, FFItem] | None = None

    @property
    def answered(self) -> bool:
        """Return True if the call answered Kodi; Kodi waits for it on a call with a handle."""
        return self.answer.is_set()


def current_call() -> CallScope:
    """Return the plugin call of the current thread (its scope or a parent one), else the call of the interpreter arguments."""
    if (scope := current_scope()) is not None and (call := scope.find(CallScope)) is not None:
        return call
    return _interpreter_call


def reset() -> None:
    """Reset control stuff for reuse code (re-run in the same Python interpreter): the call of `sys.argv`."""
    global _interpreter_call
    _interpreter_call = CallScope(sys.argv)


def reset_all() -> None:
    """Reset all stuff for reuse code (re-run in the same Python interpreter): the plugin call and the service reload."""
    from .info import ffinfo
    from ..service.client import service_client
    L.reset()
    settings.reset()  # force recreate settings proxy
    reset()
    if navigator := sys.modules.get(f'{__package__.rpartition(".")[0]}.indexers.navigator'):  # loaded by a previous call only
        navigator.reset()
    ffinfo.reset()
    service_client.reset()
    # trakt.trakt_credentials_manager.reset()


#: The call of the interpreter arguments (`sys.argv`, set in reset()): the plugin call of the plugin interpreter,
#: the call of no handle in the service and CLI. A thread of another call finds its own one (see current_call()).
_interpreter_call: CallScope

reset()

HOME_WINDOW = 10_000
WINDOW_PROGRAMS = 10_001
WINDOW_PICTURES = 10_002
WINDOW_FILES = 10_003
WINDOW_SETTINGS_MENU = 10_004
WINDOW_VIDEO_NAV = 10_025
WINDOW_VIDEO_PLAYLIST = 10_028
WINDOW_ADDON_BROWSER = 10_040
WINDOW_DIALOG_KEYBOARD = 10_103
WINDOW_DIALOG_CONTEXT_MENU = 10_106
WINDOW_DIALOG_NUMERIC = 10_109
WINDOW_DIALOG_FILE_BROWSER = 10_126
WINDOW_DIALOG_BUSY = 10_138
WINDOW_DIALOG_PICTURE_INFO = 10_139
WINDOW_DIALOG_ADDON_SETTINGS = 10_140
WINDOW_DIALOG_BUSY_NOCANCEL = 10_160
WINDOW_MUSIC_NAV = 10_502
WINDOW_TV_CHANNELS = 10_700
WINDOW_TV_GUIDE = 10_702
WINDOW_SLIDESHOW = 12_007
WINDOW_DIALOG_COLOR_PICKER = 12_008
ACTIVE_WINDOW = -1


def setting(id: str) -> str:
    """Get K19 setting (everything is string)."""
    return settings.get_string(id, stack_depth=2)


def setSetting(id: str, value: str) -> None:
    """Set K19 setting (everything is string)."""
    settings.set_string(id, value, stack_depth=2)


def addon(*args, **kwargs):
    return xbmcaddon.Addon(*args, **kwargs)


def window(*args, **kwargs):
    """HOME window."""
    return xbmcgui.Window(HOME_WINDOW, *args, **kwargs)


def dialog(*args, **kwargs):
    return xbmcgui.Dialog(*args, **kwargs)


def progressDialog(*args, **kwargs):
    return xbmcgui.DialogProgress(*args, **kwargs)


def progressDialogBG(*args, **kwargs):
    return xbmcgui.DialogProgressBG(*args, **kwargs)


def windowDialog(*args, **kwargs):
    return xbmcgui.WindowDialog(*args, **kwargs)


def keyboard(*args, **kwargs):
    return xbmc.Keyboard(*args, **kwargs)


# def monitor(*args, **kwargs):
#     return xbmc.Monitor(*args, **kwargs)


def addonInfo(info: AddonInfo, *args, **kwargs) -> str:
    # author, changelog, description, disclaimer, fanart, icon, id, name, path, profile, stars, summary, type, version
    return xbmcaddon.Addon().getAddonInfo(info, *args, **kwargs)


def lang(string_id, *args, **kwargs):
    if isinstance(string_id, str):
        return string_id
    return xbmcaddon.Addon().getLocalizedString(string_id, *args, **kwargs)


def player(*args, **kwargs):
    return xbmc.Player(*args, **kwargs)


def getCurrentDialogId(*args, **kwargs):
    return xbmcgui.getCurrentWindowDialogId(*args, **kwargs)


def playlist(type=xbmc.PLAYLIST_VIDEO, *args, **kwargs):
    return xbmc.PlayList(type, *args, **kwargs)


plugin_id: str = addonInfo('id')
plugin_url: str = f'plugin://{plugin_id}/'
ff2_plugin_url: str = 'plugin://plugin.video.fanfilm/'  # old fixed FF2 name

integer = 1000

lang2 = xbmc.getLocalizedString


def handle_write(func: Callable[P, R]) -> Callable[P, R | None]:
    """Return the function writing to the handle of the plugin call that writes nothing (None) when the call is aborted."""
    @wraps(func)
    def write(*args: P.args, **kwargs: P.kwargs) -> R | None:
        """Write to the handle unless the call is aborted."""
        if current_call().is_set():
            return None  # aborted in the service: Kodi waits no more, its handle may be another call's already
        return func(*args, **kwargs)
    return write


# The writes to the handle of the plugin call: FF writes only through these (handle_write()).
#: Add a folder item.
addItem = handle_write(xbmcplugin.addDirectoryItem)
#: Add the folder items.
addItems = handle_write(xbmcplugin.addDirectoryItems)
#: Set the content (view) of the folder.
content = handle_write(xbmcplugin.setContent)
#: Set the category of the folder (`Container.PluginCategory`).
category = handle_write(xbmcplugin.setPluginCategory)
#: Add a sort method of the folder.
sortMethod = handle_write(xbmcplugin.addSortMethod)
#: Set a property of the folder.
property = handle_write(xbmcplugin.setProperty)

item = xbmcgui.ListItem


@handle_write
def end_of_directory(handle: int, succeeded: bool = True, updateListing: bool = False, cacheToDisc: bool = True) -> None:  # noqa: N803
    """Close the folder of the plugin call (`xbmcplugin.endOfDirectory()`): the call answered Kodi."""
    current_call().answer.set()
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, updateListing=updateListing, cacheToDisc=cacheToDisc)


@handle_write
def resolved_url(handle: int, succeeded: bool, listitem: xbmcgui.ListItem) -> None:
    """Give Kodi the item to play (`xbmcplugin.setResolvedUrl()`): the call answered Kodi."""
    current_call().answer.set()
    xbmcplugin.setResolvedUrl(handle, succeeded, listitem)


infoLabel = xbmc.getInfoLabel

condVisibility = xbmc.getCondVisibility

jsonrpc = xbmc.executeJSONRPC

button = xbmcgui.ControlButton

image = xbmcgui.ControlImage

openFile = xbmcvfs.File

make_dir = xbmcvfs.mkdir

deleteFile = xbmcvfs.delete

deleteDir = xbmcvfs.rmdir

listDir = xbmcvfs.listdir

existsPath = xbmcvfs.exists

transPath = xbmcvfs.translatePath

skinPath = xbmcvfs.translatePath("special://skin/")

addonPath = xbmcvfs.translatePath(addonInfo("path"))

dataPath = xbmcvfs.translatePath(addonInfo("profile"))

settingsFile = os.path.join(dataPath, "settings.xml")

viewsFile = os.path.join(dataPath, "views.db")

bookmarksFile = os.path.join(dataPath, "bookmarks.db")

episodesFile = os.path.join(dataPath, "episodes.json")

searchFile = os.path.join(dataPath, "search.1.db")

libcacheFile = os.path.join(dataPath, "library.db")

cacheFile = os.path.join(dataPath, "cache.db")

downloadsFile = os.path.join(dataPath, "downloads.1.db")

key = "RgUkXp2s5v8x/A?D(G+KbPeShVmYq3t6"

iv = "p2s5v8y/B?E(H+Mb"

skin = xbmc.getSkinDir()


def addon_file(fname: str) -> Path:
    """Return path to addon file."""
    return Path(addonPath) / fname


def resources_file(fname: str) -> str:
    """Return path to addon resources file (not media addon)."""
    return str(Path(addonPath) / 'resources' / fname)


# Modified `sleep` command that honors a user exit request
def sleep(time_msec, /):
    from .kotools import xsleep
    xsleep(time_msec / 1000)


def execute(function: str, wait: bool = False) -> None:
    """Execute Kodi built-in function."""
    from .logs import fflog
    fflog(f'Built-in ({function}) executed (wait={wait})', stack_depth=2)
    xbmc.executebuiltin(function, wait)


def run_plugin(url: str):
    from .logs import fflog
    fflog(f'RunPlugin({url}) executed', stack_depth=2)
    return xbmc.executebuiltin(f'RunPlugin({url})')


def addonIcon():
    return addonInfo("icon")


def addonThumb():
    from .theme import art
    return art('common/poster.png')


def addonPoster():
    from .theme import art
    return art('common/poster.png')


def addonBanner():
    from .theme import art
    return art('common/banner.png')


def addonFanart():
    from .theme import art
    return art('fanart.jpg')


def addonLandscape():
    from .theme import art
    return art('common/landscape.jpg')


def addonNext():
    from .theme import art
    return art('common/poster_next.jpg')


def addonId():
    return addonInfo("id")


def addonName():
    return addonInfo("name")


def artPath():
    return os.path.join(
        xbmcaddon.Addon("script.fanfilm.media").getAddonInfo("path"),
        "resources",
        "media",
    )


art_path = artPath()


def infoDialog(message, heading=addonInfo("name"), icon="", time=3000, sound=False):
    if icon == "":
        icon = addonIcon()
    elif icon == "INFO":
        icon = xbmcgui.NOTIFICATION_INFO
    elif icon == "WARNING":
        icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == "ERROR":
        icon = xbmcgui.NOTIFICATION_ERROR
    dialog().notification(heading, message, icon, time, sound=sound)


# key -> (first_call_ts, pending_timer). One lock, one dict: kept deliberately simple - no separate
# queue/burst-counter machinery. Kodi queues the popups itself (K21, K22 CGUIDialogKaiToast), they never overlap.
_pending: dict[str, tuple[float, 'Timer']] = {}
_lock = Lock()


def groupedInfoDialog(key: str, message: str, heading=addonInfo("name"), icon="",
                       debounce: float = CONST_REF.tune.notify.debounce, max_wait: float = CONST_REF.tune.notify.max_wait) -> None:
    """Collapse repeated calls sharing `key` into one popup: waits `debounce` seconds
    of silence, but never longer than `max_wait` since the first call (or the plugin call end,
    see flush_grouped_notifications())."""
    debounce, max_wait = const_value(debounce), const_value(max_wait)
    now = time.time()
    with _lock:
        first_ts, timer = _pending.get(key, (now, None))
        if timer:
            timer.cancel()
        wait = max(0.0, min(debounce, max_wait - (now - first_ts)))
        timer = Timer(wait, _show, args=(key, message, heading, icon))
        _pending[key] = (first_ts, timer)
        timer.start()


def _show(key: str, message: str, heading: str, icon: str) -> None:
    """Show a collapsed notification (the timer), unless it is flushed or replaced by a newer call meanwhile."""
    with _lock:
        entry = _pending.get(key)
        if entry is None or entry[1] is not current_thread():
            return
        del _pending[key]
    infoDialog(message, heading=heading, icon=icon)


def flush_grouped_notifications() -> None:
    """
    Show the pending grouped notifications now, the plugin call ends.

    A waiting timer is a script thread: Kodi would not reuse the interpreter until it ends (a new interpreter for
    the next call). The pending entries are taken under the lock, so a timer firing meanwhile shows nothing.
    """
    with _lock:
        timers = [timer for _, timer in _pending.values()]
        _pending.clear()
    for timer in timers:
        timer.cancel()
        _, message, heading, icon = timer.args
        infoDialog(message, heading=heading, icon=icon)


def notification(
    # Dialog heading (title).
    heading: str,
    # heading: str = field()
    # Dialog message.
    message: str,
    # message: str = field()
    # Icon to use. Default is FanFilm icon.
    icon: str | None = None,
    # Time in SECONDS (sic!). Default 5, None or -1 means forever.
    interval: float | None = 5,
    # Play notification sound, default True.
    sound: bool = True,
    # True if the notification is visible, if not, you must use show().
    visible: bool = False,
    # Startup show delay in seconds.
    delay: float = -1,  # -1 means auto (zero or almost zero)
    # Show works if True otherwise hidden notification (show is not enabled).
    enabled: bool = True
) -> Notification:
    from .kotools import Notification
    return Notification(heading=heading, message=message, icon=icon, interval=interval, sound=sound, visible=visible, delay=delay, enabled=enabled)


#: Home window property: the window about the ignored `local.py` was shown in this Kodi session (any process).
LOCAL_ERROR_SHOWN: str = 'fanfilm.local_error.shown'


def show_local_error(*, again: bool = True) -> None:
    """
    Tell the error of the ignored `local.py` (`cdefs.local_error`): the window the first time in a Kodi session, then
    a notification (`again`, e.g. every FF folder; the service shows only the window).
    """
    from cdefs import local_error
    if local_error is None:
        return
    window = xbmcgui.Window(HOME_WINDOW)
    if window.getProperty(LOCAL_ERROR_SHOWN):
        if again:
            hint = L(30700, 'local.py error, fix it (loaded again at the next call)') if const.core.const_reload else L(30788, 'local.py error, fix and restart Kodi')
            notification(addonName(), hint, icon='ERROR', sound=False).show()  # no details: maybe fixed already
        return
    window.setProperty(LOCAL_ERROR_SHOWN, '1')
    place = L(30701, '{path}, line {line}').format(path=local_error.path, line=local_error.line) if local_error.line else str(local_error.path)
    text = L(30702, 'Error in {place}:[CR]{error}[CR][CR]The whole file is ignored, FanFilm uses the default settings.').format(
        place=place, error=local_error.message)
    if source := local_error_source(local_error.path, local_error.line):
        text = f'{text}\n\n{source}'
    # not in the f-string: kolang does not see a text there
    fix = L(30163, 'Fix local.py, FanFilm loads it again at the next call') if const.core.const_reload else L(30789, 'Fix local.py and restart Kodi')
    text = f'{text}\n\n————————————————————\n[B]{fix}[/B]'
    dialog().textviewer(f'{addonName()} const local.py', text, usemono=True)


#: Home window property: the window about a broken style file was shown in this Kodi session (any process).
STYLE_ERROR_SHOWN: str = 'fanfilm.style_error.shown'


def show_style_error(path: Path, error: str) -> None:
    """Tell a broken style file of the windows (skipped as a whole): the window once in a Kodi session (the log has every one)."""
    window = xbmcgui.Window(HOME_WINDOW)
    if window.getProperty(STYLE_ERROR_SHOWN):
        return
    window.setProperty(STYLE_ERROR_SHOWN, '1')
    text = L(30505, 'Error in {path}:[CR]{error}[CR][CR]The whole file is ignored, the FanFilm windows use the rest of the style.', path=path, error=error)
    dialog().textviewer(f'{addonName()} style', text, usemono=True)


#: Home window property: the window about the withdrawn keys of `local.py` was shown in this Kodi session (any process).
LOCAL_OBSOLETE_SHOWN: str = 'fanfilm.local_obsolete.shown'


def obsolete_place(where: str) -> str:
    """
    Return the text of where a withdrawn const setting is now (`cdefs.OBSOLETE` value: an ID, `style:<token>` - a token of the
    style of the windows), the ID itself if unknown.
    """
    place, _, token = where.partition(':')
    if place == 'style':
        return L(30299, 'style: local-style.json (token {token})').format(token=token)
    places = {
        'lists.general': L(32944, 'Tools » Accounts and lists » General lists'),
        'lists.folders': L(32945, 'Tools » Accounts and lists » Folders'),
        'lists.feeds': L(32946, 'Tools » Accounts and lists » Data providers'),
        'removed': L(32947, 'removed'),
    }
    return places.get(where, where)


def show_local_obsolete() -> None:
    """Tell the withdrawn const keys assigned in `local.py` (`cdefs.local_obsolete`, ignored): the window once in a Kodi session."""
    from cdefs import local_obsolete, local_path
    if not local_obsolete:
        return
    window = xbmcgui.Window(HOME_WINDOW)
    if window.getProperty(LOCAL_OBSOLETE_SHOWN):
        return
    window.setProperty(LOCAL_OBSOLETE_SHOWN, '1')
    lines = '\n'.join(f'{use.line or "?":>4} | const.{use.path}\n     » {obsolete_place(use.where)}' for use in local_obsolete)
    text = L(32948, 'These settings of {path} are withdrawn, FanFilm ignores them (the rest of the file works):').format(path=local_path)
    hint = L(32949, 'Remove these lines from local.py')
    text = f'{text}\n\n{lines}\n\n————————————————————\n[B]{hint}[/B]'
    dialog().textviewer(f'{addonName()} const local.py', text, usemono=True)


def reload_local() -> list[str] | None:
    """
    Load a changed `local.py` again (`cdefs.const_reload()`, no call may run meanwhile: the plugin before its call, the
    service between them; `const.core.const_reload`); its error and withdrawn keys are shown again. Return the changed
    keys, None if not loaded.
    """
    from cdefs import const_reload, local_changed
    from .logs import fflog, fflog_exc
    if not const.core.const_reload or not local_changed():
        return None
    try:
        changed = const_reload()
    except Exception:
        fflog_exc()
        return None
    home = xbmcgui.Window(HOME_WINDOW)
    home.clearProperty(LOCAL_ERROR_SHOWN)  # the next FF folder shows them
    home.clearProperty(LOCAL_OBSOLETE_SHOWN)
    fflog(f'[FF] local.py loaded again, changed: {", ".join(changed) or "nothing"}'
          ' (the keys of `#. apply=` in const.py later, e.g. the port of the service server at its start)')
    return changed


def local_error_source(path: Path, line: int | None, *, around: int = 3) -> str:
    """Return the lines of `path` around the `line` of the error (numbered, the line highlighted), '' if not known."""
    if not line:
        return ''
    try:
        lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
    except OSError:
        return ''
    first, last = max(1, line - around), min(len(lines), line + around)
    width = len(str(last))
    out = []
    for num in range(first, last + 1):
        code = f'{num:>{width}} | {lines[num - 1]}'
        out.append(f'[B][COLOR {const.dialog.local_error.line_color}]{code}[/COLOR][/B]' if num == line else code)
    return '\n'.join(out)


def yesnoDialog(*lines: str, heading: str = addonInfo('name'), nolabel: str = '', yeslabel: str = '') -> bool:
    return dialog().yesno(heading, '\n'.join(lines), nolabel, yeslabel)


def selectDialog(list, heading=addonInfo("name")):
    return dialog().select(heading, list)


def show_changelog() -> None:
    """Show changelog.txt (addon root) in a text viewer, highlighting the current version."""
    try:
        text = addon_file('changelog.txt').read_text(encoding='utf-8')
    except OSError:
        return
    version = addonInfo('version')
    text = text.replace(version, f'[B][COLOR {const.dialog.changelog.version_color}]{version}[/COLOR][/B]')
    note = L(30631, 'You can disable this notification in Settings -> Maintenance.')
    heading = f'{addonName()} - {L(30634, "Changelog")}'
    dialog().textviewer(heading, f'[I]{note}[/I]\n\n{text}')


def apiLanguage() -> dict[str, str]:
    """Return dict with language (pl) or locale (pl-PL) for services."""
    # locale in ISO 639/1 & 3136/1 (eg. "pl-PL")
    locale: str = settings.getString('api.language')
    if locale and locale[0].isupper() and locale[-1].islower():  # old format: eg. "Polish"
        locale = 'pl-PL'  # force default
    if not locale or locale == 'AUTO':
        locale = kodi_locale()
    # language in ISO 639/1 (eg. "pl")
    lang: str = locale.partition('-')[0]
    return {
        'trakt': lang,
        'youtube': lang,
        'tmdb': locale,
        'image': lang,
    }


def api_language(service: Literal['tmdb', 'trakt', 'image', 'youtube']) -> str:
    """Return corrent language for given service."""
    langs = apiLanguage()
    return langs.get(service, langs['tmdb'])


def version():
    num = ""
    try:
        version = addon("xbmc.addon").getAddonInfo("version")
    except Exception:
        version = "999"
    for i in version:
        if i.isdigit():
            num += i
        else:
            break
    return int(num)


def cdnImport(uri, name):
    import imp

    from . import client

    path = os.path.join(dataPath, "py" + name)
    path = path.decode("utf-8")

    deleteDir(os.path.join(path, ""), force=True)
    make_dir(dataPath)
    make_dir(path)

    r = client.request(uri)
    p = os.path.join(path, name + ".py")
    f = openFile(p, "w")
    f.write(r)
    f.close()
    m = imp.load_source(name, p)

    deleteDir(os.path.join(path, ""), force=True)
    return m


def openSettings() -> None:
    xbmcaddon.Addon().openSettings()


def getCurrentViewId():
    """Returns the id of the control which is focused."""
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def current_window_id() -> int:
    """Return current window id."""
    return xbmcgui.getCurrentWindowId()


@overload
def get_window_property(key: str) -> str: ...


@overload
def get_window_property(window: int, key: str) -> str: ...


def get_window_property(window: int = HOME_WINDOW, key: str = ...) -> str:  # type: ignore
    """Return single property `key` from the window."""
    if key is ...:
        window, key = HOME_WINDOW, window
    if window == ACTIVE_WINDOW:
        window = xbmcgui.getCurrentWindowId()
    win = xbmcgui.Window(window)
    return win.getProperty(key)


def get_window_properties(window: int = HOME_WINDOW, *keys: str) -> Sequence[str]:
    """Return all properties `keys` from the window as tuple (in keuys order)."""
    if window == ACTIVE_WINDOW:
        window = xbmcgui.getCurrentWindowId()
    win = xbmcgui.Window(window)
    return tuple(win.getProperty(key) for key in keys)


def get_window_properties_dict(window: int = HOME_WINDOW, *keys: str) -> dict[str, str]:
    """Return all properties `keys` from the window as dict."""
    if window == ACTIVE_WINDOW:
        window = xbmcgui.getCurrentWindowId()
    win = xbmcgui.Window(window)
    return {key: win.getProperty(key) for key in keys}


def is_plugin_folder() -> bool:
    """Return True if the plugin call comes from a FF folder (FF3 listing), False otherwise (example in a widget)."""
    if (folder := current_call().folder) is None:  # outside a plugin call (service, CLI) or before its start
        return xbmc.getInfoLabel('Container.PluginName') == plugin_id
    return folder


def remember_plugin_folder() -> bool:
    """
    Read is_plugin_folder() once at the plugin call start and keep it for the call (in the plugin until the next call).

    At the call end Kodi already shows its result or another window (e.g. Home after a play from the list,
    so the call looked like a widget call) and it reads the GUI state while Kodi updates the list (no GUI lock).
    Threads of the call can still run after its end (e.g. providers), they get the value of their call.
    """
    call = current_call()
    call.folder = None
    call.folder = is_plugin_folder()
    return call.folder


def refresh(folder: str | None = None) -> None:
    """
    Refresh the current list; with `folder` only if that list is still shown (e.g. a delayed refresh after Back / Home).
    An empty `folder` is no list (Home, e.g. a play from a widget: the skin reloads its widgets), nothing is refreshed.
    """
    from .logs import fflog
    if folder == '':
        fflog('refresh: skipped, no list', stack_depth=2)
        return
    if folder is not None and (shown := xbmc.getInfoLabel('Container.FolderPath')) != folder:
        fflog(f'refresh: skipped, {folder!r} is not shown (now {shown!r})', stack_depth=2)
        return
    fflog('refresh: Container.Refresh executed', stack_depth=2)
    execute("Container.Refresh()")


#: Kodi setting changed to reload the widgets (`reload_widgets()`): a list of values, Kodi checks only their membership.
WIDGETS_RELOAD_SETTING: str = 'videolibrary.showunwatchedplots'
#: Video library path scanned by `WidgetsReload.SCAN`: it does not exist, the scan only announces its end.
WIDGETS_RELOAD_SCAN_PATH: str = 'special://temp/fanfilm-widgets-reload/'


def same_meaning_variant(values: Sequence[Any]) -> list[Any] | None:
    """
    Return another list with the same members as `values` (Kodi compares a list setting by its order and length): its last
    value repeated, or the repetition removed (alternately, at most one). None for an empty list (no such variant).
    """
    if not values:
        return None
    if len(values) > 1 and values[-1] == values[-2]:
        return list(values[:-1])
    return [*values, values[-1]]


def reload_widgets() -> bool:
    """
    Make Kodi reload its widgets (`const.core.widgets_reload`, see `WidgetsReload`): a change of `WIDGETS_RELOAD_SETTING`
    with the same meaning, Kodi announces `VideoLibrary.OnRefresh`. A widget not shown now reloads when shown again.
    Return True if a reload was requested.
    """
    from cdefs import WidgetsReload
    from .kotools import KodiRpc
    from .logs import fflog
    from .settings import advanced_settings
    from ..kodi import version as kodi_version
    if (mode := const.core.widgets_reload) is None:
        return False
    rpc = KodiRpc()

    def call(method: str, params: dict[str, Any]) -> Any:
        """Return the `result` of the JSON-RPC call, None if none."""
        data = rpc.rpc(method, params=params)
        return data.get('result') if isinstance(data, Mapping) else None

    def set_value(value: list[Any]) -> bool:
        return call('Settings.SetSettingValue', {'setting': WIDGETS_RELOAD_SETTING, 'value': value}) is True

    result = call('Settings.GetSettingValue', {'setting': WIDGETS_RELOAD_SETTING})
    if not isinstance(values := result.get('value') if isinstance(result, Mapping) else None, list):
        fflog(f'widgets reload: no {WIDGETS_RELOAD_SETTING}: {result!r}')
        return False
    if (variant := same_meaning_variant(values)) is not None:
        fflog(f'widgets reload: {WIDGETS_RELOAD_SETTING} {values} -> {variant}')
        return set_value(variant)
    if mode is WidgetsReload.TWICE:
        fflog(f'widgets reload: {WIDGETS_RELOAD_SETTING} empty, changed and back')
        return set_value([0]) and set_value([])
    if mode is WidgetsReload.SCAN:
        if kodi_version < 22 and advanced_settings.get('videolibrary', 'cleanonupdate'):
            fflog('widgets reload: skipped, a scan cleans the whole library on Kodi 21 with `cleanonupdate`')
            return False
        fflog('widgets reload: an empty video library scan')
        return call('VideoLibrary.Scan', {'directory': WIDGETS_RELOAD_SCAN_PATH, 'showdialogs': False}) == 'OK'
    fflog(f'widgets reload: skipped, {WIDGETS_RELOAD_SETTING} empty')
    return False


def wait_for_folder(folder: str, timeout: float) -> bool:
    """Wait until the media window shows `folder` (e.g. the list just given to Kodi); False at timeout or outside a media window."""
    from .kotools import xsleep
    end = time.monotonic() + timeout
    while xbmc.getCondVisibility('Window.IsMedia'):
        if xbmc.getInfoLabel('Container.FolderPath') == folder:
            return True
        if time.monotonic() >= end:
            break
        xsleep(.1)
    return False


def update(path: str | None = None, *, replace: bool = False, wait: bool = False) -> None:
    """Update current kodi container (item list) with new content."""
    from .logs import fflog
    fflog(f'refresh: Container.Update executed, {replace=}', stack_depth=2)
    if replace:
        return execute(f"Container.Update({path or ''},replace)", wait=wait)
    return execute(f"Container.Update({path or ''})", wait=wait)


def idle():
    from .logs import fflog
    fflog('idle: Dialog.Close(busydialognocancel) executed', stack_depth=2)
    execute("Dialog.Close(busydialognocancel)")  # Kodi 17


def queueItem():
    from .logs import fflog
    fflog('queueItem: Action(Queue) executed', stack_depth=2)
    return execute("Action(Queue)")


def metadataClean(metadata):
    """Filter out non-existing/custom keys. Otherwise there are tons of errors in Kodi 18 log."""
    if metadata is None:
        return metadata
    allowed = {
        "genre",
        "country",
        "year",
        "episode",
        "season",
        "sortepisode",
        "sortseason",
        "episodeguide",
        "showlink",
        "top250",
        "setid",
        "tracknumber",
        "rating",
        "userrating",
        # "watched",
        "playcount",
        "overlay",
        "cast",
        "castandrole",
        "director",
        "mpaa",
        "plot",
        "plotoutline",
        "title",
        "originaltitle",
        "sorttitle",
        "duration",
        "studio",
        "tagline",
        "writer",
        "tvshowtitle",
        "premiered",
        "status",
        "set",
        "setoverview",
        "tag",
        "imdbnumber",
        "code",
        "aired",
        "credits",
        "lastplayed",
        "album",
        "artist",
        "votes",
        "path",
        "trailer",
        "dateadded",
        "mediatype",
        "dbid",
    }
    return {k: v for k, v in metadata.items() if k in allowed}


def close_window(window_id: int, /) -> None:
    """Close given window by id."""
    from .logs import fflog
    fflog(f'Close window {window_id}', stack_depth=2)
    execute(f'Dialog.Close({window_id})')


def busy_dialog(show: bool = True, *, cancellable: bool = False, stack_depth: int = 1) -> None:
    """
    Change busy-dialog state (open or close).

    show         - open if True else close
    cancellable  - if True opened dialog could be cancelled by user
    """
    from .logs import fflog
    if show:
        win_id = WINDOW_DIALOG_BUSY if cancellable else WINDOW_DIALOG_BUSY_NOCANCEL
        fflog('Open busy-dialog', stack_depth=stack_depth + 1)
        execute(f'ActivateWindow({win_id})')
    else:
        fflog('Close busy-dialog', stack_depth=stack_depth + 1)
        execute(f'Dialog.Close({WINDOW_DIALOG_BUSY})')
        execute(f'Dialog.Close({WINDOW_DIALOG_BUSY_NOCANCEL})')


def close_busy_dialog(*, force: bool = False, stack_depth: int = 1) -> None:
    busy_dialog(False, stack_depth=stack_depth + 1)


@contextmanager
def busy_section(*,
                 complete_notif: bool | str | None = False,
                 sound: bool = True,
                 cancellable: bool = False,
                 stack_depth: int = 1,
                 delay: float = 0,
                 ) -> Generator[None, None, None]:
    """
    Section with busy dialog active.

    `delay` (seconds): the dialog opens only if the section still runs after it (a quick section shows nothing, no flash),
    the section closes only a dialog it opened.

    >>> with busy_section():
    ...    do_your_stuff()
    """
    timer: Timer | None = None
    lock = Lock()
    opened = ended = False
    if delay > 0:

        def open_late() -> None:
            """Open the dialog unless the section has ended meanwhile."""
            nonlocal opened
            with lock:
                if not ended:
                    busy_dialog(True, cancellable=cancellable)
                    opened = True

        timer = Timer(delay, open_late)
        timer.start()
    else:
        opened = True
        busy_dialog(True, cancellable=cancellable, stack_depth=stack_depth + 1)
    try:
        yield None
    finally:
        if timer is not None:
            timer.cancel()
            with lock:  # the timer opens nothing from now, `opened` is final
                ended = True
        if opened:
            busy_dialog(False, cancellable=cancellable, stack_depth=stack_depth + 1)
        if complete_notif:
            if not isinstance(complete_notif, str):
                complete_notif = L(32057, 'Process Complete')
            infoDialog(complete_notif, sound=sound)


def pretty_log_info() -> None:
    """Log info in pretty format."""
    from sqlite3 import sqlite_version
    from .logs import info as log
    from .kotools import get_platform
    from .kodidb import video_db
    from .theme import BASE_THEME, active_themes
    # author, changelog, description, disclaimer, fanart, icon, id, name, path, profile, stars, summary, type, version
    info = xbmcaddon.Addon().getAddonInfo
    name = info('name')
    ver = info('version')
    media_ver = xbmcaddon.Addon('script.fanfilm.media').getAddonInfo('version') or '---'
    themes = ', '.join((*active_themes(), BASE_THEME))
    kodi_ver = xbmc.getInfoLabel('System.BuildVersion') or '---'
    kodi_db_conf = video_db.video_db_conf()
    log(f'''=== {name} ===
    {plugin_id}: {ver}
    script.fanfilm.media: {media_ver}
    themes: {themes}
    kodi: {kodi_ver}
    kodi.db: type={kodi_db_conf.type}, video={kodi_db_conf.name}
    python: {sys.version}
    sqlite3: {sqlite_version}
    platform: {get_platform()}''')


@define
class Finally:
    """A function called at the end of the current plugin call."""

    func: Callable
    args: tuple[Any, ...] = ()
    kwargs: dict[str, Any] = field(factory=dict)

    def __call__(self) -> Any:
        return self.func(*self.args, **self.kwargs)

    @classmethod
    def call(cls, function: Callable, *args, **kwargs) -> 'Finally':
        fin = Finally(function, args, kwargs)
        current_call().finalizers.append(fin)
        return fin

    @classmethod
    def iter(cls) -> Iterator[Finally]:
        return iter(current_call().finalizers)

    @classmethod
    def clear(cls):
        current_call().finalizers.clear()
