"""
Provider add-ons (xdostawcy) on the FanFilm side: found by their manifest (`ff.providers.json`), their catalogs kept
with a stamp of the add-on files, the provider add-on serving a scraper add-on chosen by the rules (one add-on, one
handler), called by its worker or in this process (an import of the manifest `entry`).

FanFilm knows no scraper dialect: the add-ons and their providers are what the catalogs of the active provider add-ons
give (the choice of the user, `XPROVIDERS_CONFIG`, else `const.sources.xproviders.default_active`); an inactive provider
add-on does not run (no catalog, no worker, no import).
"""

from __future__ import annotations
from pathlib import Path
from time import monotonic
from typing import Any, Iterator, Sequence, Union
from typing_extensions import TypeAlias
from attrs import frozen
from ..sdk.addons.namespace import addon_namespace
from ..sdk.addons.paths import addon_paths
from ..sdk.manifest import Manifest, read_manifest, stamp
from ..sdk import worker
from ..sdk.protocol import PROTOCOL_VERSION
from ..sdk.protocol.catalog import Catalog, CatalogAddon, MatchKind, MATCH_ORDER
from ..sdk.xprovider import XProvider
from ..sdk.db import providers as providers_db
from .db.sources import provider_store
from .kotools import addon_enabled_in_kodi
from .logs import fflog
from .control import plugin_id
from const import const


def addons_path() -> Path:
    """Return the folder of the installed add-ons."""
    from xbmcvfs import translatePath
    return Path(translatePath('special://home/addons'))


class XProviderError(Exception):
    """A provider of a provider add-on failed (its error in the `find` stream, the add-on not available)."""


#: The namespace of the catalogs in the provider data store.
CATALOG_STORE = 'ff/xproviders'


#: The provider add-ons in the user configuration: `{<provider add-on ID>: {"active": bool}}` (none: `default_active()`).
XPROVIDERS_CONFIG: str = '/sources/xproviders'


def default_active(xprovider_id: str) -> bool:
    """Return the activity of a provider add-on without a choice of the user (`const.sources.xproviders.default_active`)."""
    policy = const.sources.xproviders.default_active
    return policy == 'always' or (policy == 'ours' and xprovider_id in const.sources.xproviders.ours)


def is_active(xprovider_id: str) -> bool:
    """Return True if the provider add-on is active (the choice of the user, else `default_active()`)."""
    from .config import config
    entry = (config.get(XPROVIDERS_CONFIG) or {}).get(xprovider_id)
    if isinstance(entry, dict) and 'active' in entry:
        return bool(entry['active'])
    return default_active(xprovider_id)


def set_active(xprovider_id: str, active: bool) -> None:
    """Set the activity of the provider add-on (the choice of the user)."""
    from .config import config
    chosen = dict(config.get(XPROVIDERS_CONFIG) or {})
    chosen[xprovider_id] = {**(chosen.get(xprovider_id) or {}), 'active': bool(active)}
    config.set(XPROVIDERS_CONFIG, chosen)


@frozen(kw_only=True)
class Claim:
    """A provider add-on which can serve a scraper add-on."""

    #: The provider add-on ID.
    xprovider: str
    #: The handler ID.
    handler: str
    #: The handler version.
    version: str
    #: How the handler matched the scraper add-on.
    match: MatchKind
    #: The catalog entry of the scraper add-on.
    addon: CatalogAddon

    @property
    def ours(self) -> bool:
        """Return True if the provider add-on is ours (`const.sources.xproviders.ours`)."""
        return self.xprovider in const.sources.xproviders.ours


def _version_key(version: str) -> tuple[int, ...]:
    """Return a version (`1.2.3`) to compare, the not numeric parts as zero."""
    return tuple(int(part) if part.isdigit() else 0 for part in version.split('.'))


def _rules(claim: Claim) -> tuple[Any, ...]:
    """Return the order of the claims after the version: the most specific match, ours, the provider add-on ID."""
    return MATCH_ORDER.index(claim.match), not claim.ours, claim.xprovider


def choose(claims: Sequence[Claim]) -> Claim | None:
    """
    Return the claim which serves a scraper add-on (the rules): the same handler from more provider add-ons - the newest
    version; different handlers - the most specific match (its ID, its structure, a heuristic); then ours before the
    others; then the provider add-on ID.
    """
    best: dict[str, Claim] = {}
    for claim in sorted(claims, key=lambda claim: (tuple(-num for num in _version_key(claim.version)), *_rules(claim))):
        best.setdefault(claim.handler, claim)
    return min(best.values(), key=_rules, default=None)


def folder_stamp(root: Path) -> str:
    """Return the stamp of the add-ons folder: its time changes when an add-on is installed or removed."""
    try:
        return str(root.stat().st_mtime_ns)
    except OSError:
        return '-'


def installed_manifests() -> list[Manifest]:
    """Return the manifests of the installed provider add-ons, enabled in Kodi or not (a wrong protocol major: skipped)."""
    root = addons_path()
    return [manifest for path in sorted(root.iterdir()) if path.is_dir() and path.name != plugin_id and (manifest := read_manifest(path))]


def manifests() -> list[Manifest]:
    """Return the manifests of the installed provider add-ons enabled in Kodi."""
    return [manifest for manifest in installed_manifests() if addon_enabled_in_kodi(manifest.id)]


def active_manifests() -> list[Manifest]:
    """Return the manifests of the provider add-ons which run: enabled in Kodi, active (`is_active()`)."""
    return [manifest for manifest in manifests() if is_active(manifest.id)]


#: The loaded provider add-ons of the interpreter: ID -> (stamp, object).
_loaded: dict[str, tuple[str, XProvider]] = {}


def load(manifest: Manifest) -> XProvider:
    """Return the provider add-on object (its `entry` imported in its namespace once an interpreter, again after a change)."""
    current = stamp(manifest.path)
    if (loaded := _loaded.get(manifest.id)) is not None:
        if loaded[0] == current:
            return loaded[1]
        fflog(f'[XPROVIDERS] {manifest.id}: changed, loaded again')
        loaded[1].close()
    module, _, name = manifest.entry.partition(':')
    own, dependencies = addon_paths(manifest.id, path=manifest.path)
    factory = getattr(addon_namespace(manifest.id, own, dependencies).load(module), name)
    obj: XProvider = factory({'protocol': PROTOCOL_VERSION, 'addons_path': str(addons_path()), 'path': str(manifest.path), 'mode': 'import'})
    _loaded[manifest.id] = (current, obj)
    return obj


def catalog(manifest: Manifest) -> Catalog | None:
    """
    Return the catalog of a provider add-on: stored with the stamps of the provider add-on, of the served add-ons and of
    the add-ons folder (an add-on installed or removed), asked again when one of them changes; None if the add-on is
    broken (logged).
    """
    store = provider_store(CATALOG_STORE)
    current = stamp(manifest.path)
    root = addons_path()
    folder = folder_stamp(root)
    entry = store.get(manifest.id)
    if (isinstance(entry, dict) and entry.get('stamp') == current and entry.get('folder') == folder
            and all(stamp(root / addon) == addon_stamp for addon, addon_stamp in (entry.get('served') or {}).items())):
        return entry.get('catalog')
    try:
        if (xp := xprovider(manifest.id)) is None:
            return None
        data = xp.catalog()
    except Exception as exc:
        fflog(f'[XPROVIDERS] {manifest.id}: no catalog: {exc!r}')
        return None
    served = {addon['id']: stamp(root / addon['id']) for addon in data.get('addons', ())}
    store.set(manifest.id, {'stamp': current, 'folder': folder, 'served': served, 'catalog': data}, ttl=None)  # valid until a stamp changes
    return data


def claims(addon: str) -> Iterator[Claim]:
    """Yield the claims of a scraper add-on: the active provider add-ons with it in their catalogs."""
    for manifest in active_manifests():
        if (data := catalog(manifest)) is None:
            continue
        versions = {handler['id']: handler['version'] for handler in data.get('handlers', ())}
        seen = False
        for entry in data.get('addons', ()):
            if entry['id'] == addon:
                if seen:
                    fflog.warning(f'[XPROVIDERS] {manifest.id}: the add-on {addon} twice in the catalog, the first one taken')
                    continue
                seen = True
                yield Claim(xprovider=manifest.id, handler=entry['handler'], version=versions.get(entry['handler'], ''), match=entry['match'],
                            addon=entry)


def owner(addon: str) -> Claim | None:
    """Return the claim serving the scraper add-on (None: nobody knows it: a provider add-on of its dialect is not installed / enabled)."""
    if (claim := choose(list(claims(addon)))) is not None:
        fflog(f'[XPROVIDERS] {addon}: served by {claim.xprovider} ({claim.handler} {claim.version}, {claim.match})')
    return claim


#: A provider add-on as FanFilm calls it: its worker (HTTP) or the object imported here.
XProviderApi: TypeAlias = Union[worker.WorkerClient, XProvider]
#: How long a worker found alive is not asked again (seconds).
ALIVE_TTL = 10.0
#: The workers found alive in the interpreter: ID -> (when, client).
_alive: dict[str, tuple[float, worker.WorkerClient]] = {}


def worker_client(xprovider_id: str) -> worker.WorkerClient | None:
    """Return the client of the running worker of the provider add-on (asked again after `ALIVE_TTL`), None if none runs."""
    if (known := _alive.get(xprovider_id)) is not None and monotonic() - known[0] < ALIVE_TTL:
        return known[1]
    if (client := worker.alive(xprovider_id)) is None:
        _alive.pop(xprovider_id, None)
        return None
    _alive[xprovider_id] = (monotonic(), client)
    return client


def start_worker(xprovider_id: str) -> None:
    """Start the worker script of the provider add-on (Kodi starts a second one too: the worker itself keeps one)."""
    from xbmc import executebuiltin
    fflog(f'[XPROVIDERS] {xprovider_id}: start the worker')
    executebuiltin(f'RunScript({xprovider_id})')


def xprovider(xprovider_id: str) -> XProviderApi | None:
    """
    Return the provider add-on of the ID, the run mode derived: its worker if it runs (`service`), else the import here
    (`import`, if the manifest allows it), else its worker is started and None (not available yet; also not installed or
    not compatible).
    """
    if (manifest := read_manifest(addons_path() / xprovider_id)) is None:
        return None
    if 'service' in manifest.modes and (client := worker_client(xprovider_id)) is not None:
        return client
    if 'import' in manifest.modes:
        return load(manifest)
    start_worker(xprovider_id)
    return None


def wanted_workers() -> list[Manifest]:
    """
    Return the provider add-ons whose workers should run: active, with the `service` mode, serving an add-on chosen by
    the user (or with no catalog yet: its worker gives it).
    """
    from .config import config
    from ..sources.addons.external import ADDONS_CONFIG
    chosen = {addon for addon, entry in (config.get(ADDONS_CONFIG) or {}).items() if isinstance(entry, dict) and entry.get('active')}
    store = provider_store(CATALOG_STORE)
    wanted = []
    for manifest in active_manifests():
        if 'service' not in manifest.modes:
            continue
        entry = store.get(manifest.id)
        served = {addon['id'] for addon in entry['catalog'].get('addons', ())} if isinstance(entry, dict) and entry.get('catalog') else None
        if served is None or served & chosen:
            wanted.append(manifest)
    return wanted


def keep_workers() -> None:
    """
    Start the workers which should run and do not, end the ones of the provider add-ons made inactive (the supervisor of
    the service: at the start and after a worker ended); drop the catalogs of the provider add-ons not installed.
    """
    wanted = {manifest.id for manifest in wanted_workers()}
    for xprovider_id in wanted:
        if worker.alive(xprovider_id) is None:
            start_worker(xprovider_id)
    installed = set()
    for manifest in installed_manifests():
        installed.add(manifest.id)
        if manifest.id not in wanted and not is_active(manifest.id) and (client := worker.alive(manifest.id)) is not None:
            fflog(f'[XPROVIDERS] {manifest.id}: inactive, the worker ended')
            client.exit()
    store = provider_store(CATALOG_STORE)
    for xprovider_id in store.keys():
        if xprovider_id not in installed:
            store.delete(xprovider_id)


def clear_data() -> None:
    """
    Remove the data of the providers of every provider add-on (the user asked for it): its running worker clears it
    (its memory too, no new interpreter), the one loaded here clears it in this process, else its database file is
    cleared here (nothing of it runs).
    """
    for manifest in manifests():
        try:
            cleared = False
            if (client := worker_client(manifest.id)) is not None:
                client.clear()
                cleared = True
            if (loaded := _loaded.get(manifest.id)) is not None:
                loaded[1].clear()
                cleared = True
            if not cleared:
                cleared = providers_db.clear_file(providers_db.database_path(manifest.id))
            fflog(f'[XPROVIDERS] {manifest.id}: provider data {"cleared" if cleared else "none"}')
        except Exception as exc:
            fflog(f'[XPROVIDERS] {manifest.id}: provider data not cleared: {exc!r}')
