"""
Themes of FanFilm: exchangeable images of lists and menus and the style of the windows from theme add-ons.

A theme is an add-on with `ff.theme.json` in its folder, found by a scan of the add-ons. Its images are in `resources/media/`
with the same relative paths as in `script.fanfilm.media`, the base theme (always installed). The active themes are a list,
the most important first, the base theme always the last one (never listed): a theme does not have to have every image,
an image is taken from the first active theme which has it, from the base one otherwise.

The style of the windows of a theme is `resources/style.json` (`lib.windows.style`: the layers of the active themes, the
least important first, a token of a more important one overrides).

A theme may declare variants (`"variants": ["dark", "light"], "variant": "dark"` - the default one, else the first one). The
variant is one for all the themes (`VARIANT_CONFIG`): `auto` (the default) - `dark` / `light` by the brightness of the text
of the skin (unknown: the default variant of every theme), or a name. A theme without the chosen variant uses its default one.
The colours of the skin in the FF windows are a switch of their own (`SKIN_COLORS_CONFIG`, any variant; `lib.windows.style.SKIN`).
The variant of a theme adds `resources/style.<variant>.json` over its style. The images of an FF window take the variant of the
surface they are drawn on (`dark` / `light`, `art()`): `resources/media.<variant>/` before the images of a theme, the base theme too
(`media.light/`: the dark counterparts of its light icons for a light surface). The window set of a theme (`resources/window/`,
`window.<variant>/`: its icons small and whole - Kodi draws the GUI without mipmaps, a big icon in a small control is jagged) goes before
its media in an FF window; an image the set does not have (or no set) - of its media.

The textures of the FF windows of a theme are in `resources/skin/media/` with the same relative paths as in the media folder of the
FF windows (`lib.windows.gui.MEDIA`): a texture of the first active theme which has it, the one of FF otherwise; the folder of the
variant of the surface first (`resources/skin/media.<variant>/`, as the images of an FF window). A theme may add files (a member of a
texture family, a texture a token of its style names); the base theme has none (the textures of FF are the base).

The widgets of the FF windows of a theme are in `resources/skin/widgets/<family>.xml` (`skin_widgets()`, `lib.windows.xgui`: a widget
of the name of a widget of FF replaces it when it keeps its face, the other ones are seen in the files of the theme only).

`ff.theme.json`: `{"name": …, "description": …, "image": "<path relative to the add-on folder>", "variants": […], "variant": …}`,
the name and the description are a text or `{<ISO 639-1 language>: text}`; no name - the name from `addon.xml`.
"""

from __future__ import annotations
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable, Mapping
from attrs import frozen
from .config import file_stat, FileStat
from .logs import fflog
from . import control
from ..kolang import L

#: The active themes in the user configuration: add-on IDs, the most important first (the base theme never listed: always the last).
THEMES_CONFIG: str = '/gui/themes'
#: The variant of the themes in the user configuration: `AUTO_VARIANT` (none too) or the name of a variant.
VARIANT_CONFIG: str = '/gui/theme_variant'
#: The colours of the skin in the FF windows (its accent, `lib.windows.style.SKIN`) in the user configuration: a switch, off by default.
SKIN_COLORS_CONFIG: str = '/gui/skin_colors'
#: The variant by the brightness of the text of the skin.
AUTO_VARIANT: str = 'auto'
#: The variant `AUTO_VARIANT` chooses for a skin of a light text (a dark skin).
DARK_VARIANT: str = 'dark'
#: The variant `AUTO_VARIANT` chooses for a skin of a dark text (a light skin).
LIGHT_VARIANT: str = 'light'
#: A name of a variant (a part of the file names).
RX_VARIANT: re.Pattern[str] = re.compile(r'[a-z0-9_-]+')
#: Not a variant: the other one of `DARK_VARIANT` / `LIGHT_VARIANT` by hand (`toggled_variant()`, the route `tools/theme/variant/toggle`).
TOGGLE_VARIANT: str = 'toggle'
#: The folder of the installed add-ons as Kodi names it (`addon_url()`): the same path on every system and in every profile.
ADDONS_URL: str = 'special://home/addons/'
#: The base theme, every image is there.
BASE_THEME: str = 'script.fanfilm.media'
#: The file which makes an add-on a theme.
THEME_FILE: str = 'ff.theme.json'
#: Folder of the list / menu images in the theme add-on (`resources/media.<variant>` the images of a variant).
MEDIA_DIR: str = 'resources/media'
#: Folder of the images of the FF windows in the theme add-on (`resources/window.<variant>` of a variant): the icons of `MEDIA_DIR` (the
#: same relative paths) whole and small (Kodi draws the GUI without mipmaps); an image it does not have - of `MEDIA_DIR`.
WINDOW_DIR: str = 'resources/window'
#: An image of the media folder of a theme (`MEDIA_DIR`, `WINDOW_DIR`, also of a variant: `media.<variant>`): its theme folder, its
#: relative path.
RX_MEDIA_IMAGE: re.Pattern[str] = re.compile(r'(?P<theme>.+?)[/\\](?:%s)(?:\.%s)?[/\\](?P<rel>.+)'
                                             % ('|'.join(r'[/\\]'.join(map(re.escape, folder.split('/'))) for folder in (MEDIA_DIR, WINDOW_DIR)),
                                                RX_VARIANT.pattern))
#: Folder of the textures of the FF windows in the theme add-on (`resources/skin/media.<variant>` the textures of a variant).
SKIN_MEDIA_DIR: str = 'resources/skin/media'
#: Folder of the widgets of the FF windows in the theme add-on (`<family>.xml` as in `resources/skins/widgets` of FF, no variants).
SKIN_WIDGETS_DIR: str = 'resources/skin/widgets'
#: The style of the windows in the theme add-on (the tokens it overrides, `lib.windows.style`; `style.<variant>.json` of a variant).
STYLE_FILE: str = 'resources/style.json'


@frozen
class ThemeInfo:
    """A theme add-on (for the choice of the user)."""

    #: Add-on ID.
    id: str
    #: The add-on folder.
    path: Path
    #: Its name in the Kodi language.
    name: str
    #: Its description in the Kodi language.
    description: str = ''
    #: Full path of its preview image, empty if none.
    image: str = ''
    #: Full path of its preview image in an FF window: the small one of `WINDOW_DIR` (the same name as `image`) if the theme has it, else `image`.
    window_image: str = ''
    #: Full path of its preview image in a small control (a list of 30 px): `<image>.small` of `WINDOW_DIR` if the theme has it, else `window_image`.
    small_image: str = ''
    #: Its variants, () none.
    variants: tuple[str, ...] = ()
    #: Its default variant, '' none.
    variant: str = ''


@frozen
class ThemeFiles:
    """The manifest of a theme folder FF uses, read again when its `ff.theme.json` changes."""

    #: The stat of its `ff.theme.json`, None: not a theme.
    stat: FileStat = None
    #: Its variants, () none.
    variants: tuple[str, ...] = ()
    #: Its default variant, '' none.
    variant: str = ''

    def own_variant(self, chosen: str) -> str:
        """Return the variant of the theme for the chosen one: the chosen one if it has it, else its default one ('' none)."""
        return chosen if chosen in self.variants else self.variant


#: The manifests of the themes by their folders.
_theme_index: dict[Path, ThemeFiles] = {}
#: The images of the themes by their folders and media folders (`MEDIA_DIR`, `WINDOW_DIR`: `art()`, `SKIN_MEDIA_DIR`: `skin_textures()`): the stat
#: of its `ff.theme.json` and its media folder (`<media>`, `<media>.<variant>`) -> the relative paths of its images.
_theme_images: dict[tuple[Path, str], tuple[FileStat, dict[str, frozenset[str]]]] = {}
#: The add-ons folder (once per interpreter).
_addons_path: Path | None = None


def addons_path() -> Path:
    """Return the folder of the installed add-ons."""
    global _addons_path
    if _addons_path is None:
        from xbmcvfs import translatePath
        _addons_path = Path(translatePath('special://home/addons'))
    return _addons_path


def addon_url(path: str) -> str:
    """Return the path of a file of an installed add-on (in `addons_path()`) as Kodi's path (`ADDONS_URL`), another path as it is."""
    try:
        return ADDONS_URL + Path(path).relative_to(addons_path()).as_posix()
    except ValueError:
        return path


def base_path() -> Path:
    """Return the folder of the base theme add-on."""
    return Path(control.art_path).parent.parent


def active_themes() -> tuple[str, ...]:
    """Return the IDs of the active themes, the most important first, without the base one (wrong values and repeats skipped)."""
    from .config import config
    ids = config.get(THEMES_CONFIG)
    if not isinstance(ids, list):
        return ()
    # an add-on ID, never a path
    return tuple(dict.fromkeys(theme_id for theme_id in ids if isinstance(theme_id, str) and theme_id and theme_id != BASE_THEME
                               and Path(theme_id).name == theme_id))


def theme_folders() -> tuple[Path, ...]:
    """Return the folders of the active themes (installed, with `ff.theme.json`), the most important first, the base one last."""
    folders = (addons_path() / theme_id for theme_id in active_themes())
    return (*(folder for folder in folders if (folder / THEME_FILE).is_file()), base_path())


def configured_variant() -> str:
    """Return the configured variant of the themes: its name or `AUTO_VARIANT` (also none or a wrong value)."""
    from .config import config
    variant = config.get(VARIANT_CONFIG)
    return variant if isinstance(variant, str) and RX_VARIANT.fullmatch(variant) else AUTO_VARIANT


def chosen_variant() -> str:
    """Return the variant of the themes: the configured one, for `auto` the one of the skin (`skin_variant()`)."""
    if (variant := configured_variant()) != AUTO_VARIANT:
        return variant
    return skin_variant()


def skin_variant() -> str:
    """Return the variant of the brightness of the default text of the skin (`text_variant()`), '' unknown."""
    from ..windows.skinfonts import active_skin_text_color
    return text_variant(color) if (color := active_skin_text_color()) else ''


def text_variant(color: str) -> str:
    """
    Return the variant of the surface of a text of the colour (`AARRGGBB`, the alpha skipped): a text is in contrast with its surface,
    a light text (the HLS lightness at least half) is on a dark surface - `dark`, a dark one on a light surface - `light`.
    """
    import colorsys
    lightness = colorsys.rgb_to_hls(*(int(color[i:i + 2], 16) / 255 for i in (2, 4, 6)))[1]
    return DARK_VARIANT if lightness >= .5 else LIGHT_VARIANT


def variant_label(variant: str) -> str:
    """Return the label of a variant: of `dark` / `light` in the Kodi language, the automatic one with the variant of the skin, else its name."""
    if variant == AUTO_VARIANT:
        skin = skin_variant()
        return L(30507, 'Automatic: {variant}', variant=variant_label(skin) if skin else L(30508, 'the default of every theme'))
    labels = {DARK_VARIANT: L(30531, 'Dark'), LIGHT_VARIANT: L(30533, 'Light')}
    return labels.get(variant, variant)


def toggled_variant() -> str:
    """Return the variant of the themes to choose by hand for `TOGGLE_VARIANT`: the other one of dark / light than the variant of now
    (`chosen_variant()`, also the automatic one; unknown: as dark)."""
    return LIGHT_VARIANT if (chosen_variant() or DARK_VARIANT) == DARK_VARIANT else DARK_VARIANT


def set_variant(variant: str) -> None:
    """Write the variant of the themes (`AUTO_VARIANT`: the default one, not stored)."""
    from .config import config
    config.set(VARIANT_CONFIG, variant, default=AUTO_VARIANT)


def skin_colors_chosen() -> bool:
    """Return True if the user chose the colours of the skin in the FF windows (`SKIN_COLORS_CONFIG`; any variant), off by default."""
    from .config import config
    return config.get_bool(SKIN_COLORS_CONFIG, False)


def set_skin_colors(chosen: bool) -> None:
    """Write the choice of the colours of the skin in the FF windows (off: the default one, not stored)."""
    from .config import config
    config.set(SKIN_COLORS_CONFIG, chosen, default=False)


def variant_choices(themes: Mapping[str, ThemeInfo]) -> list[str]:
    """
    Return the variants to choose (`themes`: the installed ones by their IDs): automatic, the variants of the active themes and of the
    base one, the configured one last if none of them has it (of a theme removed).
    """
    current = configured_variant()
    variants = [AUTO_VARIANT, *dict.fromkeys(name for theme_id in (*active_themes(), BASE_THEME) if (theme := themes.get(theme_id)) for name in theme.variants)]
    return variants if current in variants else [*variants, current]


def set_active_themes(ids: Iterable[str]) -> None:
    """Write the active themes, the most important first (the base one skipped: always the last one; none: the default, not stored)."""
    from .config import config
    config.set(THEMES_CONFIG, [theme_id for theme_id in dict.fromkeys(ids) if theme_id != BASE_THEME], default=[])


def add_theme(theme_id: str) -> None:
    """Add the theme at the top of the active ones (the most important one)."""
    set_active_themes((theme_id, *active_themes()))


def remove_theme(theme_id: str) -> None:
    """Remove the theme from the active ones."""
    set_active_themes(active for active in active_themes() if active != theme_id)


def move_theme(theme_id: str, step: int) -> None:
    """Move the active theme by the step among the active ones (-1: up, more important; 1: down), at most to their ends."""
    ids = list(active_themes())
    i = ids.index(theme_id)
    ids.insert(max(0, min(i + step, len(ids) - 1)), ids.pop(i))
    set_active_themes(ids)


def free_themes(themes: Iterable[ThemeInfo]) -> list[ThemeInfo]:
    """Return the themes of `themes` (installed) which can be added: not active, not the base one."""
    active = set(active_themes())
    return [theme for theme in themes if theme.id != BASE_THEME and theme.id not in active]


def theme_note(theme_id: str, themes: Mapping[str, ThemeInfo]) -> str:
    """
    Return what the row of an active theme tells besides its description (`themes`: the installed ones by their IDs): not installed,
    disabled in Kodi, the base one is always the last one ('' nothing).
    """
    from .kotools import addon_enabled_in_kodi
    if theme_id == BASE_THEME:
        return L(30520, 'always the last one, it has every image')
    if theme_id not in themes:
        return L(30506, '[I]not installed[/I]')
    return '' if addon_enabled_in_kodi(theme_id) else L(32922, '[I]disabled in Kodi[/I]')


def variant_file(path: Path, variant: str) -> Path:
    """Return the file of the variant of the file (`style.json` -> `style.<variant>.json`)."""
    return path.with_name(f'{path.stem}.{variant}{path.suffix}')


def _manifest(path: Path) -> dict[str, Any] | None:
    """Return the data of `ff.theme.json` of the folder, None if it is not a theme (no or broken file: logged)."""
    try:
        with open(path / THEME_FILE, encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as exc:
        fflog.warning(f'[THEME] broken {path / THEME_FILE} ({exc}), not used')
        return None
    if not isinstance(data, dict):
        fflog.warning(f'[THEME] broken {path / THEME_FILE} (not an object), not used')
        return None
    return data


def _variants(data: dict[str, Any]) -> tuple[tuple[str, ...], str]:
    """Return the variants of the theme data (wrong names skipped) and its default one (the first one if not one of them)."""
    names = data.get('variants')
    variants = tuple(dict.fromkeys(name for name in names if isinstance(name, str) and RX_VARIANT.fullmatch(name))) if isinstance(names, list) else ()
    default = data.get('variant')
    return variants, default if default in variants else variants[0] if variants else ''


def theme_files(path: Path) -> ThemeFiles:
    """Return the manifest of the theme in the folder, none if it is not a theme (anymore)."""
    stat = file_stat(path / THEME_FILE)
    if stat is None:
        return ThemeFiles()
    files = _theme_index.get(path)
    if files is None or files.stat != stat:  # not read yet or an update of the add-on (it writes `ff.theme.json` again)
        variants, variant = _variants(data) if (data := _manifest(path)) is not None else ((), '')
        files = _theme_index[path] = ThemeFiles(stat=stat, variants=variants, variant=variant)
    return files


def theme_images(path: Path, files: ThemeFiles, media: str = MEDIA_DIR) -> dict[str, frozenset[str]]:
    """
    Return the images of the theme in the folder (its manifest `files`) of the media folder (`MEDIA_DIR`, `WINDOW_DIR`, `SKIN_MEDIA_DIR`; also the
    widgets, `SKIN_WIDGETS_DIR`): its folders of the media and its variants with images -> their relative paths (walked again when its
    `ff.theme.json` changes).
    """
    indexed, images = _theme_images.get((path, media), (None, {}))
    if indexed != files.stat:
        images = {}
        for folder in (media, *(f'{media}.{name}' for name in files.variants)) if files.stat is not None else ():
            top = path / folder
            if found := frozenset(Path(root, name).relative_to(top).as_posix() for root, _, names in os.walk(top) for name in names):
                images[folder] = found
        _theme_images[path, media] = files.stat, images
    return images


def window_folders(variant: str) -> tuple[str, ...]:
    """
    Return the folders of the images of an FF window of a theme before its media folder (`MEDIA_DIR`), in their order (`variant`: the
    variant of the theme, `ThemeFiles.own_variant()`, '' none): the window set of the variant, the media of the variant, the window set.
    """
    return (f'{WINDOW_DIR}.{variant}', f'{MEDIA_DIR}.{variant}', WINDOW_DIR) if variant else (WINDOW_DIR,)


def art(rel: str, *, variant: str = '') -> str:
    """
    Return the path of the image (`rel` relative to the media folder): of the first active theme which has it, of the base one
    otherwise. `variant`: an image of an FF window, the variant of the surface it is drawn on (`lib.windows.style.image_variant()`:
    `dark` / `light` by the brightness of its text) - the folders of a window of a theme first (`window_folders()` of its variant,
    `ThemeFiles.own_variant()`), the base one too (a theme wins over the window folders of the base one); '' an image of a Kodi list (the
    skin draws its background: its brightness is not known) - the media folder of the chosen variant of an active theme, then the media folder.
    """
    for theme_id in active_themes():
        path = addons_path() / theme_id
        files = theme_files(path)
        images = theme_images(path, files)
        if variant:
            images = {**theme_images(path, files, WINDOW_DIR), **images}
            for folder in window_folders(files.own_variant(variant)):
                if rel in images.get(folder, ()):
                    return str(path / folder / rel)
        elif any(f'{MEDIA_DIR}.{name}' in images for name in files.variants):  # a list: the chosen variant of the theme (a stat only of a theme with such a folder)
            if rel in images.get(folder := f'{MEDIA_DIR}.{files.own_variant(chosen_variant())}', ()):
                return str(path / folder / rel)
        if rel in images.get(MEDIA_DIR, ()):
            return str(path / MEDIA_DIR / rel)
    # the base theme: its window folders by a stat (each one is as big as `MEDIA_DIR`: no walk in a cold interpreter)
    if variant:
        base = base_path()
        for folder in window_folders(theme_files(base).own_variant(variant)):
            if os.path.isfile(file := base / folder / rel):
                return str(file)
    return os.path.join(control.art_path, rel)


def media_rel(path: str) -> str:
    """
    Return the path of an image of a theme (`art()`: a file of the media folder of the base theme or of an active one, also of its
    variant) relative to the media folder (`art(media_rel(path), variant=…)`: the image in another variant), '' another image.
    """
    if not (mch := RX_MEDIA_IMAGE.fullmatch(path)):
        return ''
    folder = Path(mch['theme'])
    if folder == base_path() or (folder.parent == addons_path() and folder.name in active_themes()):
        return mch['rel'].replace('\\', '/')
    return ''


def skin_textures(variant: str | None) -> dict[str, str]:
    """
    Return the textures of the FF windows of the active themes (`theme_folders()`, the base one has none): the relative path -> the file
    of the first theme which has it, the folder of its variant first (`ThemeFiles.own_variant()` of `variant`: the variant of the
    surface, `lib.windows.style.image_variant()`); None: the files of every variant folder too (the names a texture may have). No
    active theme: none, nothing read.
    """
    textures: dict[str, str] = {}
    for path in reversed(theme_folders()[:-1]):  # the most important one last: its files win
        files = theme_files(path)
        images = theme_images(path, files, SKIN_MEDIA_DIR)
        own = files.variants if variant is None else (files.own_variant(variant),)
        for folder in (SKIN_MEDIA_DIR, *(f'{SKIN_MEDIA_DIR}.{name}' for name in own if name)):  # the variant after: it wins
            textures.update((rel, str(path / folder / rel)) for rel in images.get(folder, ()))
    return textures


def skin_widgets() -> dict[Path, tuple[Path, ...]]:
    """
    Return the widget families of the FF windows of the active themes (`theme_folders()`, the base one has none): the folder of a theme
    with widgets, the most important first -> its files `SKIN_WIDGETS_DIR/<family>.xml` (a family is a Python name, as the ones of FF).
    No active theme: none, nothing read.
    """
    found: dict[Path, tuple[Path, ...]] = {}
    for path in theme_folders()[:-1]:
        names = theme_images(path, theme_files(path), SKIN_WIDGETS_DIR).get(SKIN_WIDGETS_DIR, ())
        if families := sorted(name for name in names if name.endswith('.xml') and name[:-4].isidentifier()):
            found[path] = tuple(path / SKIN_WIDGETS_DIR / name for name in families)
    return found


def _text(value: Any, lang: str) -> str:
    """Return the text of `ff.theme.json`: the text or the one in the language (`en`, the first one if no such)."""
    if isinstance(value, dict):
        for key in (lang, 'en'):
            if isinstance(text := value.get(key), str):
                return text
        return next((text for text in value.values() if isinstance(text, str)), '')
    return value if isinstance(value, str) else ''


def read_theme(path: Path, lang: str) -> ThemeInfo | None:
    """Return the theme in the add-on folder, None if it is not a theme (no or broken `ff.theme.json`)."""
    if (data := _manifest(path)) is None:
        return None
    from .kotools import addon_name
    image = _text(data.get('image'), lang)
    small = path / WINDOW_DIR / image if image else None
    tiny = small.with_suffix(f'.small{small.suffix}') if small is not None else None
    variants, variant = _variants(data)
    window_image = str(small if small is not None and small.is_file() else path / image) if image else ''
    return ThemeInfo(id=path.name, path=path, name=_text(data.get('name'), lang) or addon_name(path),
                     description=_text(data.get('description'), lang), image=str(path / image) if image else '',
                     window_image=window_image, small_image=str(tiny) if tiny is not None and tiny.is_file() else window_image,
                     variants=variants, variant=variant)


def found_themes(lang: str | None = None) -> list[ThemeInfo]:
    """Return the installed themes: the base one first (also without `ff.theme.json`), the others by name (the add-ons folder is scanned)."""
    from .kotools import addon_name
    if lang is None:
        from xbmc import getLanguage, ISO_639_1
        lang = getLanguage(ISO_639_1)
    base = base_path()
    themes = [theme for path in addons_path().iterdir() if path.name != base.name and path.is_dir() and (theme := read_theme(path, lang))]
    themes.sort(key=lambda theme: theme.name.lower())
    return [read_theme(base, lang) or ThemeInfo(id=BASE_THEME, path=base, name=addon_name(base)), *themes]
