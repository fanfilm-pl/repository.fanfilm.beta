"""
The fixed entries of the menus of folders (`/`, `/movie`, `/show`, ...): their declaration (the label, the images, shown by
default) in the default order, the user switches and the user order (`config.json`, `/menus`). Only the changes are stored
(a value set back to its default is removed), so a changed default reaches everyone who did not change it.

The tree of the entries is derived from the keys: `movie.genre` is an entry of the menu of `movie`, `movie` an entry of the
main menu (`MAIN`); an entry with entries is a node (a menu), it has its own switch, the switches of its entries are kept.
Not here: the lists of the services (their own tabs, `lists_config`) and the conditions of the code (a data provider,
`const`), the indexers keep them.
"""

from __future__ import annotations
from typing import Iterable
from attrs import frozen
from .config import config, escape_key
from .lists_config import Text
from ..kolang import L

#: The settings of the menus in `config.json`.
MENUS_CONFIG: str = '/menus'
#: The key of the main menu (the root of the tree, no entry has it).
MAIN: str = 'main'


@frozen
class MenuEntry:
    """A fixed entry of a menu of folders."""

    #: The key (the menu of the entry is the key without its last part, `MAIN` for none).
    key: str
    #: The label.
    label: Text
    #: The thumb.
    thumb: str = ''
    #: The icon.
    icon: str = ''
    #: Shown by default.
    default: bool = True

    @property
    def parent(self) -> str:
        """Return the key of the menu of the entry."""
        return self.key.rpartition('.')[0] or MAIN


#: The fixed entries of the menus in their default order (the main menu: Tools and the developer menu are always there).
MENU_ENTRIES: tuple[MenuEntry, ...] = (
    # --- the main menu ---
    MenuEntry('progress', lambda: L(30751, 'Continue watching'), 'common/continue_watching.png', default=False),
    MenuEntry('movie', lambda: L(32001, 'Movies'), 'movies/main.png', 'DefaultMovies.png'),
    MenuEntry('show', lambda: L(32002, 'TV Shows'), 'tvshows/main.png', 'DefaultTVShows.png'),
    MenuEntry('anime', lambda: L(30518, 'Anime'), 'anime/main.png', 'DefaultTVShows.png', default=False),
    MenuEntry('person', lambda: L(30175, 'Persons'), 'persons/main.png', 'DefaultActor.png'),
    MenuEntry('lists', lambda: L(30471, 'Lists'), 'services/own/main.png'),
    MenuEntry('history', lambda: L(32036, 'History'), 'common/history.png'),
    MenuEntry('search', lambda: L(32010, 'Search'), 'common/search.png'),
    # --- movies ---
    MenuEntry('movie.search', lambda: L(32010, 'Search'), 'movies/search.png'),
    MenuEntry('movie.my', lambda: L(32003, 'My Movies'), 'movies/my.png', 'DefaultVideoPlaylists.png'),
    MenuEntry('movie.my.resume', lambda: L(32801, 'Currently watching'), 'movies/currentlywatching.png', 'DefaultVideoPlaylists.png'),
    MenuEntry('movie.my.history', lambda: L(32036, 'History'), 'movies/history.png'),
    MenuEntry('movie.trending', lambda: L(32017, 'People Watching'), 'movies/peoplewarching.png', 'DefaultRecentlyAddedMovies.png'),
    MenuEntry('movie.popular', lambda: L(32018, 'Most Popular'), 'movies/popular.png'),
    MenuEntry('movie.top_rated', lambda: L(32019, 'Top rated'), 'movies/toprated.png'),
    MenuEntry('movie.genre', lambda: L(32011, 'Genres'), 'movies/genres.png'),
    MenuEntry('movie.new', lambda: L(32005, 'New Movies'), 'movies/new.png', 'DefaultRecentlyAddedMovies.png'),
    MenuEntry('movie.vod_new', lambda: L(30591, 'New VOD releases'), 'movies/newvod.png'),
    MenuEntry('movie.cinema', lambda: L(32022, 'In Theaters'), 'movies/intheaters.png', 'DefaultRecentlyAddedMovies.png'),
    MenuEntry('movie.tv', lambda: L(32007, 'Today in TV'), 'movies/today.png'),
    MenuEntry('movie.boxoffice', lambda: L(32020, 'Box Office'), 'movies/boxoffice.png'),
    MenuEntry('movie.companies', lambda: L(30138, 'Companies'), 'movies/companies.png'),
    MenuEntry('movie.providers', lambda: L(30267, 'Providers'), 'movies/providers.png'),
    MenuEntry('movie.year', lambda: L(32012, 'Year'), 'movies/year.png'),
    MenuEntry('movie.language', lambda: L(32014, 'Languages'), 'movies/languages.png'),
    MenuEntry('movie.country', lambda: L(30104, 'Countries'), 'movies/country.png'),
    MenuEntry('movie.awards', lambda: L(32631, 'Awards'), 'movies/awards.png'),
    MenuEntry('movie.awards.oscar_winner', lambda: L(30166, 'Oscar Winner'), 'movies/oscars.png'),
    MenuEntry('movie.awards.oscar_nominee', lambda: L(30167, 'Oscar Nominee'), 'movies/oscars.png'),
    MenuEntry('movie.awards.best_picture_winner', lambda: L(30168, 'Oscar Best Picture Winner'), 'movies/oscars.png'),
    MenuEntry('movie.awards.oscar_best_picture_nominees', lambda: L(30169, 'Oscar Best Picture Nominee'), 'movies/oscars.png'),
    MenuEntry('movie.awards.best_director_winner', lambda: L(30170, 'Oscar Best Director Winner'), 'movies/oscars.png'),
    MenuEntry('movie.awards.oscar_best_director_nominees', lambda: L(30171, 'Oscar Best Director Nominee'), 'movies/oscars.png'),
    MenuEntry('movie.awards.golden_globe_winner', lambda: L(30309, 'Golden Globe Winner'), 'movies/golden.png'),
    MenuEntry('movie.awards.golden_globe_nominee', lambda: L(30410, 'Golden Globe Nominee'), 'movies/golden.png'),
    MenuEntry('movie.awards.razzie_winner', lambda: L(30172, 'Razzie Winner'), 'movies/razzie.png'),
    MenuEntry('movie.awards.razzie_nominee', lambda: L(30173, 'Razzie Nominee'), 'movies/razzie.png'),
    MenuEntry('movie.download', lambda: L(30319, 'Movies downloaded'), 'movies/download.png'),
    # --- tv shows ---
    MenuEntry('show.search', lambda: L(32010, 'Search'), 'tvshows/search.png'),
    MenuEntry('show.my', lambda: L(32004, 'My TV Shows'), 'tvshows/my.png', 'DefaultVideoPlaylists.png'),
    MenuEntry('show.my.resume', lambda: L(32805, 'Episodes in progress'), 'tvshows/progress.png'),
    MenuEntry('show.my.history', lambda: L(32036, 'History'), 'tvshows/history.png'),
    MenuEntry('show.progress', lambda: L(30250, 'Shows in progress'), 'tvshows/progress.png'),
    MenuEntry('show.trending', lambda: L(32017, 'People Watching'), 'tvshows/peoplewatching.png'),
    MenuEntry('show.popular', lambda: L(32018, 'Most Popular'), 'tvshows/mostpopular.png'),
    MenuEntry('show.top_rated', lambda: L(32019, 'Top rated'), 'tvshows/toprated.png'),
    MenuEntry('show.aired_today', lambda: L(32024, 'Airing today'), 'tvshows/airingtoday.png'),
    MenuEntry('show.premiere', lambda: L(32026, 'New TV Shows'), 'tvshows/new.png'),
    MenuEntry('show.vod_new', lambda: L(30591, 'New VOD releases'), 'tvshows/newvod.png'),
    MenuEntry('show.genre', lambda: L(32011, 'Genres'), 'tvshows/genres.png'),
    MenuEntry('show.network', lambda: L(32016, 'Networks'), 'tvshows/networks.png'),
    MenuEntry('show.providers', lambda: L(30267, 'Providers'), 'tvshows/providers.png'),
    MenuEntry('show.year', lambda: L(32012, 'Year'), 'tvshows/year.png'),
    MenuEntry('show.language', lambda: L(32014, 'Languages'), 'tvshows/languages.png'),
    MenuEntry('show.country', lambda: L(30104, 'Countries'), 'tvshows/country.png'),
    MenuEntry('show.awards', lambda: L(32631, 'Awards'), 'tvshows/awards.png'),
    MenuEntry('show.awards.emmy_winner', lambda: L(30413, 'Emmy Winner'), 'tvshows/emmy.png'),
    MenuEntry('show.awards.emmy_nominee', lambda: L(30174, 'Emmy Nominee'), 'tvshows/emmy.png'),
    MenuEntry('show.awards.golden_globe_winner', lambda: L(30309, 'Golden Globe Winner'), 'tvshows/golden.png'),
    MenuEntry('show.awards.golden_globe_nominee', lambda: L(30410, 'Golden Globe Nominee'), 'tvshows/golden.png'),
    MenuEntry('show.download', lambda: L(30320, 'TV Shows downloaded'), 'tvshows/download.png'),
    # --- anime ---
    MenuEntry('anime.movie_popular', lambda: L(30514, 'Popular movies'), 'anime/mostpopular.png'),
    MenuEntry('anime.show_popular', lambda: L(30515, 'Popular shows'), 'anime/mostpopular.png'),
    MenuEntry('anime.trending', lambda: L(32017, 'People Watching'), 'anime/peoplewatching.png'),
    MenuEntry('anime.premiere', lambda: L(30516, 'Premieres'), 'anime/new.png'),
    MenuEntry('anime.aired', lambda: L(30517, 'Last aired'), 'anime/airingtoday.png'),
    MenuEntry('anime.year', lambda: L(32012, 'Year'), 'anime/year.png'),
    MenuEntry('anime.movie_search', lambda: L(30263, 'Search movies'), 'movies/search.png'),
    MenuEntry('anime.show_search', lambda: L(30529, 'Search tvshows'), 'tvshows/search.png'),
    # --- persons ---
    MenuEntry('person.search', lambda: L(32010, 'Search'), 'persons/search.png'),
    MenuEntry('person.popular', lambda: L(32018, 'Most Popular'), 'persons/featured.png'),
    MenuEntry('person.my', lambda: L(30328, 'My Persons'), 'persons/my.png', 'DefaultVideoPlaylists.png'),
    # --- history ---
    MenuEntry('history.movie', lambda: L(32001, 'Movies'), 'movies/history.png', 'DefaultMovies.png'),
    MenuEntry('history.show', lambda: L(32002, 'TV Shows'), 'tvshows/history.png', 'DefaultTVShows.png'),
    # --- search ---
    MenuEntry('search.movie', lambda: L(32001, 'Movies'), 'movies/search.png', 'DefaultMovies.png'),
    MenuEntry('search.show', lambda: L(32002, 'TV Shows'), 'tvshows/search.png', 'DefaultTVShows.png'),
    MenuEntry('search.person', lambda: L(30175, 'Persons'), 'persons/search.png', 'people-search.png'),
    MenuEntry('search.keyword', lambda: L(30137, 'Keywords'), 'common/search_keywords.png'),
    MenuEntry('search.company', lambda: L(30138, 'Companies'), 'common/search_companies.png'),
    MenuEntry('search.collection', lambda: L(30151, 'Movies Collection'), 'common/search_collection.png'),
)

#: The entries by the key.
MENU_ENTRY: dict[str, MenuEntry] = {entry.key: entry for entry in MENU_ENTRIES}


def entries_of(menu: str) -> list[MenuEntry]:
    """Return the entries of the menu (its key, `MAIN` for the main menu) in the default order."""
    return [entry for entry in MENU_ENTRIES if entry.parent == menu]


def entry_shown(key: str) -> bool:
    """Return True if the entry is shown in its menu (the user switch, else the default; KeyError: no such entry)."""
    return config.get_bool(f'{MENUS_CONFIG}/{escape_key(key)}/shown', MENU_ENTRY[key].default)


def set_entry_shown(key: str, shown: bool) -> bool:
    """Show or hide the entry in its menu (the switches of its own entries are kept)."""
    return config.set(f'{MENUS_CONFIG}/{escape_key(key)}/shown', shown, default=MENU_ENTRY[key].default)


def menu_order(menu: str) -> list[str]:
    """
    Return the keys of the entries of the menu in the user order: the stored order without the unknown keys, an entry not
    in it (e.g. new in an update) after its default predecessor (the first without one).
    """
    default = [entry.key for entry in entries_of(menu)]
    saved = config.get(f'{MENUS_CONFIG}/{escape_key(menu)}/order')
    if not isinstance(saved, list):
        return default
    order = list(dict.fromkeys(key for key in saved if key in default))
    for i, key in enumerate(default):
        if key not in order:
            order.insert(next((order.index(prev) + 1 for prev in reversed(default[:i]) if prev in order), 0), key)
    return order


def set_menu_order(menu: str, keys: Iterable[str]) -> bool:
    """Set the order of the entries of the menu (only a change from the default order is stored)."""
    default = [entry.key for entry in entries_of(menu)]
    return config.set(f'{MENUS_CONFIG}/{escape_key(menu)}/order', list(keys), default=default)
