
from __future__ import annotations
from sys import version_info
from datetime import datetime, timedelta, timezone, tzinfo, date as dt_date, time as dt_time
from enum import Enum
from typing import overload
from typing_extensions import Literal
from ..sdk.dates import HAS_ISO, is_datetime_instance, fromisoformat  # noqa: F401  (the dates of FanFilm)
from ..kolang import L

#: Unix Epoch, timestamp zero.
unix_epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)

EPOCH = datetime(1, 1, 1, tzinfo=timezone.utc)
EPOCH_DATE = EPOCH.date()


def astimezone(self: datetime, tz: tzinfo | None = None) -> datetime:
    """
    Safe datetime.astimezone().

    A naive datetime (and `tz=None`) needs the local time of the C library, on Windows localtime() fails
    (OSError) for dates before the epoch. Then the conversion is done in the current year (with the same
    leap year status) and moved back, so the offset follows the current time zone rules (not historical).
    See: https://bugs.python.org/issue36759
    """
    try:
        return self.astimezone(tz)
    except OSError:
        pass
    old = self.year
    new = datetime.now().year & ~3 | old & 3  # current year, keep leap year status
    moved = self.replace(year=new).astimezone(tz)
    return moved.replace(year=moved.year - new + old)  # the year could change (e.g. new year's eve)


class Now(Enum):
    """The type of `NOW`."""
    NOW = 'now'


#: The default of `make_datetime()` / `make_date()` for no value: the current time / today (`None` there is no date).
NOW = Now.NOW


@overload
def make_datetime(date: str | datetime | dt_date | None, *, default: datetime | Literal[Now.NOW] = NOW) -> datetime: ...


@overload
def make_datetime(date: str | datetime | dt_date | None, *, default: None) -> datetime | None: ...


def make_datetime(date: str | datetime | dt_date | None, *, default: datetime | Literal[Now.NOW] | None = NOW) -> datetime | None:
    """Return `date` as datetime (a date at noon), `default` if it is None (`NOW`: the current time in UTC)."""
    if date is None:
        return datetime.now(timezone.utc) if default is NOW else default
    if isinstance(date, str):
        return fromisoformat(date)
    elif is_datetime_instance(date):
        return date
    elif isinstance(date, dt_date):
        # Combine should work event if is out of C time functions' range.
        return datetime.combine(date, dt_time(12, 0))
    else:
        raise ValueError(f'Unknown datetime format in {date!r}')


@overload
def make_date(date: str | datetime | dt_date | None, *, default: dt_date | Literal[Now.NOW] = NOW) -> dt_date: ...


@overload
def make_date(date: str | datetime | dt_date | None, *, default: None) -> dt_date | None: ...


def make_date(date: str | datetime | dt_date | None, *, default: dt_date | Literal[Now.NOW] | None = NOW) -> dt_date | None:
    """Return `date` as date (also of an ISO string with time), `default` if it is None (`NOW`: today)."""
    if date is None:
        return dt_date.today() if default is NOW else default
    if isinstance(date, str):
        return fromisoformat(date).date()
    elif is_datetime_instance(date):
        return date.date()
    elif isinstance(date, dt_date):
        return date
    else:
        raise ValueError(f'Unknown date format in {date!r}')


def utc_timestamp(date: str | float | datetime | dt_date | None = None) -> float:
    """Datetime (date or now) into utc-timestamp with timezone support."""
    if date is None:
        return datetime.now(timezone.utc).timestamp()  # for "now" we could use timestamp()
    if isinstance(date, (float, int)):
        return float(date)
    try:
        d = make_datetime(date)
    except ValueError:
        return float(date)  # type: ignore  # make_datetime() gurads type check
    # See: https://stackoverflow.com/a/41400321/9935708
    #   > If the timestamp is out of the range of values supported by the platform C
    #   > localtime() or gmtime() functions, datetime.fromtimestamp() may raise an exception OSError.
    #   > On Windows platform, this range can sometimes be restricted to years in 1970 through 2038.
    #   > I have never seen this problem on a Linux system.
    # Check on win, py3.8 & py3.12:
    #   - timestmap() could not be negative and must be < date(3001, 1, 20)
    # We use python timedalta to handle timestamp.
    # See: https://stackoverflow.com/a/65564765/9935708
    try:
        return (astimezone(d, timezone.utc) - unix_epoch).total_seconds()
    except OSError:
        from .logs import fflog, fflog_exc
        fflog(f'{d = }, {unix_epoch = }')
        fflog_exc()
        return 0


def timestamp(date: str | float | datetime | dt_date | None = None) -> float:
    """Datetime (date or now) into utc-timestamp with timezone support."""
    if date is None:
        return datetime.now().timestamp()  # for "now" we could use timestamp()
    if isinstance(date, (float, int)):
        return float(date)
    try:
        d = make_datetime(date)
    except ValueError:
        return float(date)  # type: ignore  # make_datetime() gurads type check
    # Avoid datetime.timestamp on some platforms, see comments in utc_timestamp().
    return (astimezone(d, timezone.utc) - unix_epoch).total_seconds()


def utc_from_timestamp(timestamp: float | None = None) -> datetime:
    """Safe datetime.fromtimestamp().astimezone(timezone.utc). Returns UTC datetime."""
    # Avoid datetime.fromtimestamp on some platforms, see comments in utc_timestamp().
    if timestamp is None or timestamp == '':
        return datetime.now(timezone.utc).replace(tzinfo=None)
    return (unix_epoch + timedelta(seconds=float(timestamp))).replace(tzinfo=None)


def from_timestamp(timestamp: float | datetime | None = None) -> datetime:
    """
    Safe datetime.fromtimestamp(): the local time of the utc-timestamp or of a UTC datetime (naive is UTC, as from
    `utc_from_timestamp()`), with the offset of its own moment (e.g. DST). Returns naive datetime.
    """
    # Avoid datetime.fromtimestamp on some platforms, see comments in utc_timestamp().
    if timestamp is None or timestamp == '':
        return datetime.now()
    if is_datetime_instance(timestamp):
        utc = timestamp if timestamp.tzinfo else timestamp.replace(tzinfo=timezone.utc)
    else:
        utc = unix_epoch + timedelta(seconds=float(timestamp))
    return astimezone(utc).replace(tzinfo=None)


def iso_2_utc(date_string: str) -> int:
    """Parse datetime string into utc-timestamp with timezone support."""
    return int(utc_timestamp(date_string))


def utc_2_iso(timestamp: float) -> str:
    """Return the ISO string of the utc-timestamp in UTC, as the APIs of the services write it (`2026-10-16T11:05:32.000Z`)."""
    return utc_from_timestamp(timestamp).strftime('%Y-%m-%dT%H:%M:%S.000Z')


def datestamp(date: str | float | datetime | dt_date | None = None) -> int:
    """Return date (or now) into (utc) datestamp (number of days)."""
    if date is None:
        date = dt_date.today()
    if isinstance(date, (float, int)):
        return int(date)
    if isinstance(date, str):
        try:
            date = dt_date.fromisoformat(date)
        except ValueError:
            if date.isdecimal():
                return int(date)
            raise
    if is_datetime_instance(date):
        date = date.date()
    return (date - EPOCH_DATE).days


def from_datestamp(datestamp: int | None = None) -> dt_date:
    """Safe date from date-stamp."""
    if datestamp is None or datestamp == '':
        return dt_date.today()
    return EPOCH_DATE + timedelta(days=int(datestamp))


def timezone_str(tz: timezone | tzinfo | datetime | None) -> str:
    """Timezone to string."""
    if is_datetime_instance(tz):
        if version_info >= (3, 12):
            return f'{tz:%:z}'
        tz = tz.tzinfo
    if tz is None or tz is timezone.utc:
        return '+00:00'
    offset = tz.utcoffset(None)
    if offset is None:
        return '+00:00'
    total_seconds = offset.total_seconds()
    hours, minutes = divmod(int(total_seconds), 3600)
    return f'{hours:+03d}:{minutes//60:02d}'


class Translations:
    """Some basic date phrases to translate."""

    today = L(30270, "Today")
    tomorrow = L(30271, "Tomorrow")
    yesterday = L(30272, "Yesterday")
    days = [L(30273, 'Monday'), L(30274, 'Tuesday'), L(30275, 'Wednesday'),
            L(30276, 'Thursday'), L(30277, 'Friday'), L(30278, 'Saturday'), L(30279, 'Sunday')]
    isodays = [L(30279, 'Sunday'), L(30273, 'Monday'), L(30274, 'Tuesday'), L(30275, 'Wednesday'),
               L(30276, 'Thursday'), L(30277, 'Friday'), L(30278, 'Saturday'), L(30279, 'Sunday')]
    months = [L(30280, 'January'), L(30281, 'February'), L(30282, 'March'),
              L(30283, 'April'), L(30284, 'May'), L(30285, 'June'),
              L(30286, 'July'), L(30287, 'August'), L(30288, 'September'),
              L(30289, 'October'), L(30290, 'November'), L(30291, 'December')]
    upcoming_week_day = '{weekday}'
    last_week_day = L(30292, 'Last {weekday}')


def day_label(dt: dt_date | datetime,
              *,
              now: dt_date | datetime | None = None,
              week_day: bool = True,
              week_without_date: bool = False,
              date_format: str | None = None,
              always_date: bool = False
              ) -> str:
    """Returns nice date label (today, Monday, 11.12.2013)."""
    if dt is None:
        return ''
    now = make_date(now)
    dt = make_date(dt)
    if not always_date:
        if now == dt:
            return L(30270, 'Today')
        if (now + timedelta(days=1)) == dt:
            return L(30271, 'Tomorrow')
        if (now - timedelta(days=1)) == dt:
            return L(30272, 'Yesterday')
    if week_without_date:
        dd = (dt - now).days
        if 0 < dd <= 7:
            return Translations.upcoming_week_day.format(weekday=Translations.days[dt.weekday()])
        if 0 > dd >= -7:
            return Translations.last_week_day.format(weekday=Translations.days[dt.weekday()])
    dt_str = f'{dt}' if date_format is None else f'{dt:{date_format}}'
    if week_day:
        return f'{Translations.days[dt.weekday()]}, {dt_str}'
    return dt_str


if __name__ == '__main__':
    print(repr(fromisoformat('2023-10-18T18:10:27.000')))
    print(repr(fromisoformat('2023-10-18T18:10:27.000Z')))
    print(repr(fromisoformat('2023-10-18T18:10:27.000+00:00')))
    print(repr(fromisoformat('2023-10-18T18:10:27.000+01:00')))
    print(repr(fromisoformat('2023-10-18T18:10:27.000-02:00')))
    print(repr(fromisoformat('2023-10-18T18:10:27.000-0200')))
    print(repr(fromisoformat('2011-W01-2T00:05:23.283')))

    # test from py 3.12 doc
    assert fromisoformat('2011-11-04') == datetime(2011, 11, 4, 0, 0)
    assert fromisoformat('20111104') == datetime(2011, 11, 4, 0, 0)
    assert fromisoformat('2011-11-04T00:05:23') == datetime(2011, 11, 4, 0, 5, 23)
    assert fromisoformat('2011-11-04T00:05:23Z') == datetime(2011, 11, 4, 0, 5, 23, tzinfo=timezone.utc)
    assert fromisoformat('20111104T000523') == datetime(2011, 11, 4, 0, 5, 23)
    assert fromisoformat('2011-W01-2T00:05:23.283') == datetime(2011, 1, 4, 0, 5, 23, 283000)
    assert fromisoformat('2011-11-04 00:05:23.283') == datetime(2011, 11, 4, 0, 5, 23, 283000)
    assert (fromisoformat('2011-11-04 00:05:23.283+00:00')
            == datetime(2011, 11, 4, 0, 5, 23, 283000, tzinfo=timezone.utc))
    assert (fromisoformat('2011-11-04T00:05:23+04:00')
            == datetime(2011, 11, 4, 0, 5, 23, tzinfo=timezone(timedelta(seconds=14400))))
