"""Simple locale tools."""

from __future__ import annotations
from pathlib import Path
import json
from threading import Lock
from time import monotonic
from typing import Optional, Dict
import requests
from const import const

import xbmc
import xbmcaddon
import xbmcvfs

from ..kolang import kodi_locale
from .logs import fflog_exc, fflog

#: Base URL for languages translate.
LANG_URL = 'https://raw.githubusercontent.com/umpirsky/locale-list/master/data/{lang}/locales.json'
# 'https://raw.githubusercontent.com/umpirsky/language-list/master/data/{lang}/language.json'
# 'https://raw.githubusercontent.com/ihmpavel/all-iso-language-codes/master/data/{lang}/639-1.json'
#: Base URL for countries translate.
COUNTRY_URL = 'https://raw.githubusercontent.com/umpirsky/country-list/master/data/{lang}/country.json'
# 'https://raw.githubusercontent.com/stefangabos/world_countries/master/data/countries/{lang}/world.json'
# 'https://raw.githubusercontent.com/stefangabos/world_countries/master/data/countries/{lang}/countries.json

# -- for stefangabos/world_countries
# jdata = requests.get(COUNTRY_URL.format(lang=lang), timeout=5).json()
# trans = {e['alpha2'].upper(): e['name'] for e in jdata}


TranslationTable = Dict[str, Dict[str, str]]

#: Already readed language translations to speed up.
_all_lang_translations: TranslationTable = {}

#: Already readed country translations to speed up.
_all_country_translations: TranslationTable = {}

#: When a locale file not got (its path) is tried again, `monotonic()`.
_retry_at: dict[Path, float] = {}

#: The fill of the translation tables, one at a time (the first calls of the threads wait for one download).
_lock: Lock = Lock()

#: Path to cached locale files.
locale_path = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'locale'

#: URL template for country flag image (use lower country code).
flag_url: str = 'https://raw.githubusercontent.com/hampusborgos/country-flags/ba2cf4101bf029d2ada26da2f95121de74581a4d/png250px/{lower}.png'

# --- TODO: use some data source ---
datetime_formats = {
    'en': {
        'date': '%Y-%m-%d',
        'iso_date': '%Y-%m-%d',
        'time': '%H:%M:%S',
        'datetime': '%Y-%m-%d %H:%M:%S',
        'day_and_month': '%m/%d',
    },
    'pl': {
        'date': '%d.%m.%Y',
        'iso_date': '%Y-%m-%d',
        'time': '%H:%M:%S',
        'datetime': '%Y-%m-%d %H:%M:%S',
        'day_and_month': '%d.%m',
    },
}


def _translations(table: TranslationTable, fname: str, url: str, *, lang: str | None = None) -> dict[str, str]:
    """
    Return translations dict [code]=name for given lang (`pl-PL`: `pl_PL`, then `pl`). Use kodi locale if None.

    A locale comes from the memory, its file in the profile or a download (stored to its file). One not got (no network, no such locale
    upstream, a bad answer) is tried again after `const.tune.locale.retry` only, the next locale meanwhile; none: an empty dict.
    """

    def read(path: Path) -> dict[str, str] | None:
        try:
            return json.loads(path.read_text())
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as exc:
            fflog.warning(f'Bad locale file {path}: {exc}')
            return None

    def download(loc: str, path: Path) -> dict[str, str] | None:
        fflog(f'Download {fname} for locale {loc}')
        try:
            resp = requests.get(url.format(lang=loc), timeout=5)
            resp.raise_for_status()
            trans = resp.json()
        except (OSError, ValueError) as exc:  # every requests exception is OSError, every JSON one ValueError
            fflog.warning(f'No {fname} for locale {loc} downloaded: {exc}')
            return None
        save(path, trans)
        return trans

    def save(path: Path, trans: dict[str, str]) -> None:
        tmp_path = path.with_suffix('.new.json')
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path.write_text(json.dumps(trans, indent=2))
            tmp_path.replace(path)
        except OSError:
            fflog_exc()

    if not lang:
        lang = kodi_locale()
    lang, _, lngcountry = lang.replace('-', '_').partition('_')
    lang = lang.lower()
    if lngcountry:
        locales = [f'{lang}_{lngcountry.upper()}', lang]
    else:
        locales = [lang]
    with _lock:
        for loc in locales:
            if (trans := table.get(loc)) is not None:
                return trans
            path = locale_path / loc / fname
            if monotonic() < _retry_at.get(path, 0):
                continue
            if (trans := read(path)) is None:
                trans = download(loc, path)
            if trans is not None:
                table[loc] = trans
                return trans
            _retry_at[path] = monotonic() + const.tune.locale.retry
    return {}  # every try warned already (once in a retry)


def language_translations(lang: Optional[str] = None) -> Dict[str, str]:
    """Return language translatrions dict [lang]=name for given lang. Use kodi locale if None."""
    return _translations(_all_lang_translations, 'languages.json', LANG_URL, lang=lang)


def country_translations(lang: Optional[str] = None) -> Dict[str, str]:
    """Return language translatrions dict [lang]=name for given lang. Use kodi locale if None."""
    return _translations(_all_country_translations, 'countries.json', COUNTRY_URL, lang=lang)


def datetime_format(fmt: str, lang: str | None = None) -> str:
    """Return datetime format for given lang. Use kodi locale if None."""
    if not lang:
        lang = kodi_locale()
    lang = lang.replace('-', '_').partition('_')[0]
    formats = datetime_formats.get(lang)
    if not formats:
        formats = datetime_formats['en']
    return formats.get(fmt, formats['datetime'])


if __name__ == '__main__':
    from .cmdline import DebugArgumentParser
    p = DebugArgumentParser()
    p.add_argument('code', help='lang (pl) or country (PL) code')
    p.add_argument('-L', '--lang', help='local language (pl_PL)')
    p.add_argument('-t', '--type', choices=('lang', 'country'), help='code type')
    a = p.parse_args()

    if not a.type:
        if a.code.islower():
            a.type = 'lang'
        elif a.code.isupper():
            a.type = 'country'
    if a.type == 'lang':
        print(f'Language {a.code!r}: {language_translations(lang=a.lang).get(a.code.lower())!r}')
    elif a.type == 'country':
        print(f'Country {a.code!r}: {country_translations(lang=a.lang).get(a.code.upper())!r}')
