"""
    FanFilm Add-on
    UpNext integration module

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired
import xbmc
from ..defs import MediaRef
from .logs import fflog
from .settings import settings
from .info import ffinfo
from .control import plugin_id
from .kotools import KodiRpc
from .threads import Timer
if TYPE_CHECKING:
    from .item import FFItem, ArtValues
    from .types import JsonData

UPNEXT_ADDON_ID = 'service.upnext'


class UpNextVideo(TypedDict):
    """Data structure representing the episode information sent to UpNext."""
    title: str
    plot: str
    rating: float
    playcount: int
    season: int
    episode: int
    showtitle: str
    runtime: int
    firstaired: str
    art: ArtValues
    episodeid: NotRequired[int]  # could be Kodi DB ID (used in the library)
    tvshowid: NotRequired[int]   # could be Kodi DB ID (used in the library)


class SkipSegment(TypedDict):
    """Intro or recap range of the playing file, in seconds (UpNext 1.3.0+)."""
    kind: str
    start: float
    end: float


class UpNextEvent(TypedDict):
    """Data structure for the UpNext event sent via JSONRPC.NotifyAll."""
    current_episode: UpNextVideo
    next_episode: UpNextVideo
    next_video: UpNextVideo
    play_url: str
    skip_segments: NotRequired[list[SkipSegment]]
    notification_offset: NotRequired[int]  # credits start, in seconds of the playing file


def is_available() -> bool:
    """Checks if the UpNext service add-on is available in the system."""
    try:
        return xbmc.getCondVisibility(f'System.AddonIsEnabled({UPNEXT_ADDON_ID})')
    except Exception:
        return False


def is_enabled() -> bool:
    """Checks if UpNext integration is enabled in settings and available in the system."""
    return settings.getBool('upnext.enabled') and is_available()


def _extract_episode_dict(ffitem: FFItem, ffid: int = 0) -> UpNextVideo:
    """Extracts the relevant episode information from an FFItem into a dict suitable for UpNext."""
    vtag = ffitem.vtag
    src = ffitem.getArt()
    art: ArtValues = {
        key: value
        for key in ('thumb', 'fanart', 'poster', 'landscape', 'clearart', 'clearlogo', 'tvshow.fanart')
        if (value := src.get(key))
    }
    if landscape := art.get('landscape'):
        art.setdefault('thumb', landscape)
    for key in ('fanart', 'landscape', 'poster', 'clearart', 'clearlogo'):
        if image := art.get(key):
            art.setdefault(f'tvshow.{key}', image)

    return {
        'episodeid': ffitem.episode or 0,
        'tvshowid': ffid,
        'title': ffitem.title,
        'plot': vtag.getPlot(),
        'rating': vtag.getRating(),
        'playcount': vtag.getPlayCount(),
        'season': ffitem.season or 0,
        'episode': ffitem.episode or 0,
        'showtitle': vtag.getTVShowTitle(),
        'runtime': ffitem.duration or 0,
        'firstaired': vtag.getFirstAiredAsW3C(),
        'art': art,
    }

# For testing - unnused 
# def _make_minimal_episode_dict(season: int, episode: int, showtitle: str, ffid: int = 0) -> UpNextVideo:
#    """Creates a minimal UpNextVideo dict when no full episode info is available."""
#    return {
#        # 'episodeid': episode,
#        # 'tvshowid': ffid,
#        'title': '',
#        'plot': '',
#        'rating': 0.0,
#        'playcount': 0,
#        'season': season,
#        'episode': episode,
#        'showtitle': showtitle,
#        'runtime': 0,
#        'firstaired': '',
#        'art': {},
#    }


def _send_signal(data: UpNextEvent) -> None:
    """Sends the UpNext data via JSONRPC.NotifyAll using the AddonSignals envelope."""
    try:
        KodiRpc().addon_signal('upnext_data', data)
        sz, ep = data['next_episode']['season'], data['next_episode']['episode']
        fflog(f'[UPNEXT] Sent S{sz:>02}E{ep:>02} via JSONRPC.NotifyAll')
    except Exception as e:
        fflog(f'[UPNEXT] Error: {e}')


def _aniskip_times(item: FFItem, duration: float) -> JsonData:
    """Returns intro/recap/credits times of an anime episode from AniSkip (MAL id of its cour), in TheIntroDB format."""
    from . import requests
    from ..api.kitsu import resolve_cour
    if item.anime_info is None:
        ffinfo.retreive_category_data(item)
    if not item.anime_info or not item.anime_info.cours:
        return {}
    cour, local_ep = resolve_cour(item.anime_info.cours, item)
    if not cour or not cour['mal_id'] or not local_ep:
        return {}
    # no 'mixed-ed': an ending over the story, the popup would cover it
    kinds: dict[str, str] = {'op': 'intro', 'mixed-op': 'intro', 'recap': 'recap', 'ed': 'credits'}
    # AniSkip returns only times submitted for a file of this length (about ±20 s)
    resp = requests.get(f'https://api.aniskip.com/v2/skip-times/{cour["mal_id"]}/{local_ep}', timeout=5,
                        params=[*(('types[]', kind) for kind in kinds), ('episodeLength', int(duration / 1000))])
    times: dict[str, list[JsonData]] = {}
    for result in resp.json().get('results') or ():
        interval = result['interval']
        times.setdefault(kinds[result['skipType']], []).append({'start_ms': interval['startTime'] * 1000, 'end_ms': interval['endTime'] * 1000})
    fflog(f'[UPNEXT] AniSkip mal={cour["mal_id"]} ep={local_ep}: {times}')
    return times


def _send_signal_with_intro_times(data: UpNextEvent, ref: MediaRef, item: FFItem, player: xbmc.Player) -> None:
    """
    Sends the UpNext data, with intro/recap ranges and the credits start from AniSkip (anime) or TheIntroDB (if enabled); the duration of
    the file from the `player` of the caller.
    """
    if settings.getBool('upnext.theintrodb') and ref.tmdb_id:
        from . import requests
        try:
            duration = player.getTotalTime() * 1000
            times: JsonData = {}
            if item.category == 'anime':
                try:
                    times = _aniskip_times(item, duration)
                except Exception as e:  # TheIntroDB still has a chance
                    fflog(f'[UPNEXT] AniSkip error: {e}')
            times = times or requests.get('https://api.theintrodb.org/v2/media',
                                          params={'tmdb_id': ref.tmdb_id, 'season': ref.season, 'episode': ref.episode}, timeout=5).json()
        except Exception as e:
            fflog(f'[UPNEXT] TheIntroDB error: {e}')
            times, duration = {}, 0
        # an error response has no segments; a range without start or end (None) is skipped
        segments: list[SkipSegment] = [{'kind': kind, 'start': seg['start_ms'] / 1000, 'end': seg['end_ms'] / 1000}
                                       for kind in ('intro', 'recap') for seg in times.get(kind, ())
                                       if None not in (seg.get('start_ms'), seg.get('end_ms')) and 0 <= seg['start_ms'] < seg['end_ms'] <= duration]
        if segments:
            data['skip_segments'] = segments
        # the end credits only (the last range, in the last 20% of the file), not the opening credits
        credits = max((seg['start_ms'] for seg in times.get('credits', ()) if seg.get('start_ms') is not None), default=0)
        if 0.8 * duration < credits < duration:
            data['notification_offset'] = credits // 1000
        fflog(f'[UPNEXT] intro times {ref:a}: segments={segments}, credits={data.get("notification_offset")}, duration={duration / 1000:.0f}')
    _send_signal(data)


def _get_play_url(ref: MediaRef) -> str:
    """Constructs a plugin URL for the given media reference."""
    # -- correct but imports heavy modules --
    # from .routing import url_for
    # from ..indexers.navigator import play
    # return str(url_for(play, ref=ref) or '')

    # -- lightweight but less correct (doesn't follow route changes, but should be fine for this use case) --
    return f'plugin://{plugin_id}/play/{ref}'


def signal_upnext(current_item: FFItem, ref: MediaRef, *, player: xbmc.Player) -> None:
    """
    Main function to signal UpNext with the current episode and the next episode information. `player`: the player object of the caller,
    living to its end (the service has one: Kodi queues the player events of every living xbmc.Player, never a temporary one there).
    """

    if not is_enabled():
        return

    assert ref is not None
    assert ref.ffid

    if ref.season is None or ref.episode is None:
        fflog.warning('[UPNEXT] Not an episode ref, skipping')
        return

    try:
        # the next aired episode of the show after the current one (its aired episodes: `ffinfo.aired_episode_refs()`, the aired map)
        episodes = ffinfo.aired_episode_refs(MediaRef.tvshow(ref.ffid))
        if ref not in episodes or episodes.index(ref) + 1 >= len(episodes):
            fflog('[UPNEXT] No next aired episode of the show, skipping UpNext signal')
            return
        next_ref = episodes[episodes.index(ref) + 1]
        if (next_item := ffinfo.find_item(next_ref, progress=ffinfo.Progress.NO)) is None:
            fflog(f'[UPNEXT] Next episode {next_ref:a} not found, skipping UpNext signal')
            return
        next_episode_data = _extract_episode_dict(next_item, ffid=ref.ffid)

        upnext_event: UpNextEvent = {
            'current_episode': _extract_episode_dict(current_item, ffid=ref.ffid),
            'next_episode': next_episode_data,
            'next_video': next_episode_data,
            'play_url': _get_play_url(next_ref),
        }
        # Defer the signal so UpNext's initial Player.OnAVStart self-check finishes
        # first — for plugin:// items not in Kodi's library it fails ("Skip video
        # check") and would reset the tracking our signal just installed.
        Timer(1.5, _send_signal_with_intro_times, args=[upnext_event, ref, current_item, player]).start()

    except Exception as e:
        fflog(f'[UPNEXT] Error: {e}')
