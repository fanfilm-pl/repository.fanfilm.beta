"""
The user selection of the sources: the filter and the sort (`lib.ff.source_keys`) of the user, in `source_filters.json`
(`filters_store`): the sets (`sets`: by their names), the current selection of the movies and - with
the setting `separate_shows` - of the shows (`current`, the set it comes from: `base`), the selection before it (`previous`:
one, as a backup `file~`).

The old settings of `settings.xml` (the quality and size ranges, the language, the file filters, the sort modes) are a
selection state (`state_from_settings()`: their values as texts, `LEGACY_SETTINGS` their defaults): the first version of the
file is made of them (`_migrate_1`), the settings are removed.
"""

from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias
from attrs import frozen
from .config import ConfigStore, escape_key, migrate_data
from .types import EllipsisType
from .source_keys import (KEY_LABELS, SOURCE_KEYS, SelectionState, FilterState, SortCriterion, Selection, compile_selection, criterion_paths, lang_bucket,
                          QUALITY_SCALE,
                          UNKNOWN, OTHER_LANGUAGE, SUBTITLES_WAY, TRUE, CINEMA_DUBBING, NO_POLISH_AUDIO)
from ..sdk.facts import Hdr, VideoCodec, ReleaseSource, Container, AudioRecording
from ..kolang import L
from const import const
if TYPE_CHECKING:
    from ..sources import Source
    from .item import FFItem


#: The old settings of the selection of the sources (`settings.xml`) and their defaults (texts, as in the user file).
LEGACY_SETTINGS: dict[str, str] = {
    'hosts.sort': '0',
    'hosts.sort.elem1': '0',
    'hosts.sort.elem2': '1',
    'hosts.sort.elem3': '2',
    'hosts.sort.elem4': '3',
    'hosts.quality.max': '3',
    'hosts.quality.min': '0',
    'source.size.max': '0',
    'source.size.min': '0',
    'source.sound.lang': '0',
    'source.premium.no_transfer': 'false',
    'SUBTITLES.disallowed': 'false',
    'LEKTORAI.disallowed': 'false',
    'HDR.allowed': 'true',
    'DV.mode': '0',
    'DV.allowed': 'true',
    'AV1.allowed': 'true',
    'HEVC.allowed': 'true',
    'F3D.allowed': 'true',
    'AVI.allowed': 'true',
    'CAM.disallowed': 'false',
    'MD.sound.disallowed': 'false',
    'H264.10bit.disallowed': 'false',
    'AI.video.disallowed': 'false',
}

#: The settings of the simple view which were not in `settings.xml` and their defaults (texts): the subtitles burned into the video allowed,
#: only the cached torrents.
SIMPLE_EXTRAS: dict[str, str] = {'subtitles.burned.allowed': 'true', 'cached.only': 'true'}
#: The value of `cached.only` which lets through the torrents no debrid has cached.
ANY_CACHE: str = 'false'

#: The qualities of the old settings `hosts.quality.min` / `max` (their values: SD, 720p, 1080p, 4K).
LEGACY_QUALITIES: tuple[str, ...] = ('SD', '720p', '1080p', '4K')

#: The criteria of the old sort modes before the ones of the mode: the origin (the downloaded, the library..., on the account).
ORIGIN_FIRST: tuple[SortCriterion, ...] = (SortCriterion(key='origin', desc=True),)
#: The provider priority after the origin (the old modes but the custom one).
PRIORITY: SortCriterion = SortCriterion(key='priority', desc=True)
#: The language alone (of the audio, the way does not count).
LANGUAGE: SortCriterion = SortCriterion(key='language')
#: The localization (the default order of the languages of the user and the ways): the way decides after the others of a mode.
LOCALIZATION: SortCriterion = SortCriterion(key='lang')
#: The quality, the best first; a season pack after the single episodes of its quality.
QUALITY: tuple[SortCriterion, ...] = (SortCriterion(key='quality', desc=True), SortCriterion(key='pack'))
#: The size, the biggest first.
SIZE: SortCriterion = SortCriterion(key='size', desc=True)

#: The criteria of the old sort modes (`hosts.sort`: by the provider, the hosting, the size; 3 - custom: `LEGACY_SORT_ELEMS`).
LEGACY_SORTS: dict[int, tuple[SortCriterion, ...]] = {
    0: (*ORIGIN_FIRST, PRIORITY, LANGUAGE, *QUALITY, SortCriterion(key='provider'), LOCALIZATION, SIZE),
    1: (*ORIGIN_FIRST, PRIORITY, LANGUAGE, *QUALITY, SortCriterion(key='hosting'), LOCALIZATION, SIZE),
    2: (*ORIGIN_FIRST, PRIORITY, SIZE, LOCALIZATION),
}
#: The criteria of the elements of the old custom sort (`hosts.sort.elem1` ... `elem4`: the provider priority, the language, the
#: quality, the size, none), the localization last.
LEGACY_SORT_ELEMS: dict[int, tuple[SortCriterion, ...]] = {
    0: (PRIORITY,),
    1: (LANGUAGE,),
    2: QUALITY,
    3: (SIZE,),
    4: (),
}
#: The old custom sort mode (`hosts.sort`).
LEGACY_CUSTOM_SORT: int = 3
#: The element of the old custom sort of no criterion.
LEGACY_NO_ELEM: int = 4
#: The number of the elements of the old custom sort.
LEGACY_SORT_ELEMENTS: int = 4

#: The languages of the old setting `source.sound.lang` (0: all): the language of the audio or the subtitles; `UNKNOWN` - of unknown
#: languages (MULTI).
LEGACY_LANGUAGES: dict[int, tuple[str, ...]] = {
    1: ('pl',),
    2: ('pl', UNKNOWN),
    3: ('en',),
    4: ('en', UNKNOWN),
}

@frozen(kw_only=True)
class LegacyCut:
    """An old file filter: the setting of it, its value which filters, the key and its values cut by it."""

    #: The old setting.
    setting: str
    #: The value of the setting which filters.
    value: str
    #: The key.
    key: str
    #: The values of the key cut.
    cut: tuple[str, ...]


#: The old file filters.
LEGACY_CUTS: tuple[LegacyCut, ...] = (
    LegacyCut(setting='HDR.allowed', value='false', key='video.hdr', cut=tuple(hdr.value for hdr in (Hdr.HDR, Hdr.HDR10, Hdr.HDR10_PLUS, Hdr.HLG))),
    LegacyCut(setting='DV.mode', value='1', key='video.hdr', cut=('dolby_vision_only',)),
    LegacyCut(setting='DV.mode', value='2', key='video.hdr', cut=(Hdr.DOLBY_VISION.value,)),
    LegacyCut(setting='AV1.allowed', value='false', key='video.codec', cut=(VideoCodec.AV1.value,)),
    LegacyCut(setting='HEVC.allowed', value='false', key='video.codec', cut=(VideoCodec.HEVC.value,)),
    LegacyCut(setting='H264.10bit.disallowed', value='true', key='video.codec', cut=('hi10p',)),
    LegacyCut(setting='F3D.allowed', value='false', key='video.three_d', cut=(TRUE,)),
    LegacyCut(setting='AI.video.disallowed', value='true', key='video.ai', cut=(TRUE,)),
    LegacyCut(setting='AVI.allowed', value='false', key='release.container', cut=(Container.AVI.value,)),
    LegacyCut(setting='CAM.disallowed', value='true', key='release.source',
              cut=tuple(src.value for src in (ReleaseSource.CAM, ReleaseSource.TELESYNC, ReleaseSource.TELECINE))),
    LegacyCut(setting='MD.sound.disallowed', value='true', key='audio.recording', cut=(AudioRecording.MIC.value, CINEMA_DUBBING)),
    LegacyCut(setting='SUBTITLES.disallowed', value='true', key='subtitles.kind', cut=(NO_POLISH_AUDIO,)),
    LegacyCut(setting='subtitles.burned.allowed', value='false', key='subtitles.burned', cut=(TRUE,)),
    LegacyCut(setting='LEKTORAI.disallowed', value='true', key='audio.ai', cut=(TRUE,)),
    LegacyCut(setting='source.premium.no_transfer', value='true', key='transfer_short', cut=(TRUE,)),
)


def _legacy_sort(get: Callable[[str], str]) -> list[SortCriterion]:
    """Return the sort of the old settings (`hosts.sort`, its custom elements; the localization last in a custom one)."""
    mode = int(get('hosts.sort') or 0)
    if (criteria := LEGACY_SORTS.get(mode)) is not None:
        return [SortCriterion(**crit) for crit in criteria]
    sort = [SortCriterion(**crit) for crit in ORIGIN_FIRST]
    for n in range(1, LEGACY_SORT_ELEMENTS + 1):
        for crit in LEGACY_SORT_ELEMS.get(int(get(f'hosts.sort.elem{n}') or 0), ()):
            if all(criterion_paths(item) != criterion_paths(crit) for item in sort):
                sort.append(SortCriterion(**crit))
    return [*sort, SortCriterion(**LOCALIZATION)]


def _legacy_size(text: str) -> int | float:
    """Return a size in GB of a text of a setting (old ones: whole numbers; the scale of the simple view: also a half)."""
    value = float(text or 0)
    return int(value) if value.is_integer() else value


def _legacy_lang(option: int, *, subtitles: bool, langs: Sequence[str]) -> dict[str, bool]:
    """Return the decisions of the localization of an option of `source.sound.lang` (`subtitles`: the subtitles count as a way)."""
    ways = [way for way in const.sources.filters.ways if way != SUBTITLES_WAY or subtitles]
    lang: dict[str, bool] = {}
    if allowed := LEGACY_LANGUAGES.get(option):
        lang.update({f'{lang_bucket(code, langs)}/{way}': True for code in allowed for way in ways})
        if 'en' not in allowed:
            lang[UNKNOWN] = False
        elif UNKNOWN not in allowed:  # only English: MULTI out, with an English track too
            lang.update({f'{UNKNOWN}/{way}': False for way in ways})
    return lang


def state_from_settings(values: Mapping[str, str], *, langs: Sequence[str]) -> SelectionState:
    """
    Return the selection state of the old settings (`values`: their texts, a missing one is its default `LEGACY_SETTINGS`) for the
    languages of the user (`providers_lang`: the languages of the ways).
    """
    def get(sid: str) -> str:
        """Return the text of an old setting."""
        return values[sid] if sid in values else LEGACY_SETTINGS[sid] if sid in LEGACY_SETTINGS else SIMPLE_EXTRAS[sid]

    if get('DV.allowed') == 'false' and get('DV.mode') == LEGACY_SETTINGS['DV.mode']:  # the older setting of Dolby Vision: hidden, not changed by the newer one
        values = {**values, 'DV.mode': '2'}
    keys: dict[str, dict[str, bool]] = {}
    for legacy in LEGACY_CUTS:
        if get(legacy.setting) == legacy.value:
            keys.setdefault(legacy.key, {}).update(dict.fromkeys(legacy.cut, False))

    # the quality range (an unknown quality was never shown), the lowest one: CAM and SCR (the release kinds) unless CAM is cut
    qmin = LEGACY_QUALITIES[int(get('hosts.quality.min') or 0)]
    qmax = LEGACY_QUALITIES[int(get('hosts.quality.max') or 0)]
    cam = get('CAM.disallowed') == 'true'
    low = (QUALITY_SCALE[QUALITY_SCALE.index('CAM') + 1] if cam else None) if qmin == LEGACY_QUALITIES[0] else qmin
    high = None if qmax == LEGACY_QUALITIES[-1] else qmax
    ranges: dict[str, list[Any]] = {'quality': [low, high]}
    keys.setdefault('quality', {})[UNKNOWN] = False
    # the size range (GB, 0: open)
    size_min, size_max = _legacy_size(get('source.size.min')), _legacy_size(get('source.size.max'))
    if size_min or size_max:
        ranges['size'] = [size_min or None, size_max or None]

    # the language of the audio or the subtitles (no language data: English); the sources with subtitles not shown: `LEGACY_CUTS`
    if lang := _legacy_lang(int(get('source.sound.lang') or 0), subtitles=get('SUBTITLES.disallowed') != 'true', langs=langs):
        keys['lang'] = lang

    return SelectionState(filter=FilterState(on=True, keys=keys, ranges=ranges), sort=_legacy_sort(get))


#: The most sources shown.
MAX_SOURCES: int = 2000


def selected_sources(sources: Iterable[Source], selection: Selection, *, filtered: bool = True) -> list[Source]:
    """
    Return the sources the selection lets through (all of them without `filtered`) in its order, at most `MAX_SOURCES`; the greyed-out
    ones (no way opens them: `const.sources.resolve.unresolvable` grey) at the end, their order kept.
    """
    sources = selection.select(sources, filtered=filtered)[:MAX_SOURCES]
    if const.sources.resolve.unresolvable == 'grey':
        sources.sort(key=lambda src: src.unresolvable)
    return sources


#: The version of the data of `source_filters.json` (a file of an older version is migrated, `MIGRATIONS`).
FILTERS_VERSION: int = 3

#: The media of a selection: the movies, the shows (the setting `separate_shows`, else the one of the movies).
SelectionMedia: TypeAlias = Literal['movie', 'show']


class CurrentSelection(SelectionState, total=False):
    """The current selection of a media (JSON): the filter, the sort and the set it comes from (None: none)."""

    #: The name of the set it was loaded from (or saved to).
    base: str | None


#: The cut of the default set: a torrent no debrid has cached (a debrid which tells it said so); one of an unknown state is shown (the
#: cached one must: an unknown passes - the same as a not cached one must not).
CACHED_CUT: dict[str, dict[str, bool]] = {'cached': {TRUE: True}}


def default_filter(state: SelectionState) -> SelectionState:
    """Return the state with the cuts of the default set (`CACHED_CUT`) added to its filter."""
    state = deepcopy(state)
    state.setdefault('filter', FilterState()).setdefault('keys', {}).update(deepcopy(CACHED_CUT))
    return state


def factory_filter(*, langs: Sequence[str]) -> FilterState:
    """Return the filter of a new installation: the defaults of the old settings with the cuts of the default set (not the set of the user)."""
    return default_filter(state_from_settings({}, langs=langs))['filter']


def same_filter(one: FilterState, other: FilterState) -> bool:
    """Check if two filters are the same one: on, the decisions, the ranges (an open range is none)."""
    def parts(state: FilterState) -> tuple[bool, dict[str, dict[str, bool]], dict[str, list[Any]]]:
        """Return what a filter decides."""
        return (state.get('on', True), {path: values for path, values in state.get('keys', {}).items() if values},
                {path: list(ends) for path, ends in state.get('ranges', {}).items() if any(end is not None for end in ends)})
    return parts(one) == parts(other)


def start_sets(*, langs: Sequence[str]) -> dict[str, SelectionState]:
    """
    Return the sets of a new file: the default one (the defaults of the old settings: by the provider, every quality), the old sort
    modes by the hosting and by the size with its filter.
    """
    default = default_filter(state_from_settings({}, langs=langs))
    by_hosting = default_filter(state_from_settings({'hosts.sort': '1'}, langs=langs))
    by_size = default_filter(state_from_settings({'hosts.sort': '2'}, langs=langs))
    return {name: SelectionState(**state) for name, state in ((L(30753, 'Default'), default), (L(30862, 'By hosting'), by_hosting),
                                                                                  (L(30863, 'By size'), by_size))}


def _migrate_1(data: dict[str, Any]) -> None:
    """
    Version 1: the sets and the current selection from the old settings of `settings.xml` (moved out: their definitions removed, read
    as texts) and the rule of `const` hiding a torrent not cached (`CACHED_CUT`); the old ones not the default: the set "Previous
    settings", the current one.
    """
    from .settings import settings
    langs = user_languages()
    values = settings.user_values()
    sets = start_sets(langs=langs)
    default_name = next(iter(sets))
    old = default_filter(state_from_settings(values, langs=langs))
    base = default_name
    if old != {key: value for key, value in sets[default_name].items() if key in old}:
        base = L(30864, 'Previous settings')
        sets[base] = SelectionState(**old)
    data.setdefault('sets', {}).update({name: entry for name, entry in sets.items() if name not in data.get('sets', {})})
    data.setdefault('current', {}).setdefault('movie', CurrentSelection(base=base, **deepcopy(old)))
    if moved := [sid for sid in LEGACY_SETTINGS if sid in values]:
        settings.clear_moved_settings(moved)


def simple_state(values: Mapping[str, str], *, langs: Sequence[str]) -> SelectionState:
    """Return the selection state of the values of the simple view (`state_from_settings()`, the torrents no debrid has cached cut unless let through)."""
    state = state_from_settings(values, langs=langs)
    return state if values.get('cached.only') == ANY_CACHE else default_filter(state)


def _simple_sort(sort: Sequence[SortCriterion]) -> dict[str, str]:
    """Return the values of the sort of the simple view of a sort of a state (one of no mode: the first mode, `representable()` tells it)."""
    for mode in LEGACY_SORTS:
        if list(sort) == _legacy_sort({'hosts.sort': str(mode)}.get):
            return {'hosts.sort': str(mode)}
    elems = list(sort[len(ORIGIN_FIRST):-1])
    values = {'hosts.sort': str(LEGACY_CUSTOM_SORT)}
    for n in range(1, LEGACY_SORT_ELEMENTS + 1):
        elem = next((code for code, crits in LEGACY_SORT_ELEMS.items() if crits and elems[:len(crits)] == list(crits)), LEGACY_NO_ELEM)
        values[f'hosts.sort.elem{n}'] = str(elem)
        elems = elems[len(LEGACY_SORT_ELEMS[elem]):]
    return values


def simple_values(state: SelectionState, *, langs: Sequence[str]) -> dict[str, str]:
    """Return the values of the simple view of a selection state (texts of the settings; what it can not show: `representable()`)."""
    state_filter = state.get('filter', {})
    keys, ranges = state_filter.get('keys', {}), state_filter.get('ranges', {})
    values = {legacy.setting: legacy.value for legacy in LEGACY_CUTS if all(keys.get(legacy.key, {}).get(cut) is False for cut in legacy.cut)}
    low, high = ranges.get('quality') or (None, None)
    values['hosts.quality.min'] = str(LEGACY_QUALITIES.index(low) if low in LEGACY_QUALITIES else 0)
    values['hosts.quality.max'] = str(LEGACY_QUALITIES.index(high) if high in LEGACY_QUALITIES else len(LEGACY_QUALITIES) - 1)
    size_min, size_max = ranges.get('size') or (None, None)
    values.update({'source.size.min': str(size_min or 0), 'source.size.max': str(size_max or 0)})
    subtitles = values.get('SUBTITLES.disallowed') != 'true'
    lang = keys.get('lang', {})
    values['source.sound.lang'] = str(next((option for option in LEGACY_LANGUAGES if _legacy_lang(option, subtitles=subtitles, langs=langs) == lang), 0))
    if keys.get('cached') != CACHED_CUT['cached']:
        values['cached.only'] = ANY_CACHE
    return {**values, **_simple_sort(state.get('sort', []))}


def representable(state: SelectionState, *, langs: Sequence[str]) -> bool:
    """Check if the simple view shows a selection state without a loss (the switch of the filter and the set it comes from do not count)."""
    simple = simple_state(simple_values(state, langs=langs), langs=langs)
    parts = (lambda item: (item.get('filter', {}).get('keys', {}), item.get('filter', {}).get('ranges', {}), item.get('sort', [])))
    return parts(simple) == parts(state)


def simple_view(media: SelectionMedia) -> bool:
    """Check if the simple view of a media is shown: the setting and a selection it shows without a loss (a filter never changes by itself)."""
    from ..sources.source_settings import SIMPLE_SETTING, source_setting
    return bool(source_setting(SIMPLE_SETTING)) and representable(current_state(media), langs=user_languages())


def selection_medias() -> tuple[SelectionMedia, ...]:
    """Return the media with a current selection of their own."""
    from ..sources.source_settings import SEPARATE_SETTING, source_setting
    return ('movie', 'show') if source_setting(SEPARATE_SETTING) else ('movie',)


def simple_loss(media: SelectionMedia) -> list[str]:
    """Return the labels of what the simple view would lose of the current selection of a media (the keys of the filter, the sort)."""
    langs = user_languages()
    state = current_state(media)
    simple = simple_state(simple_values(state, langs=langs), langs=langs)
    old, new = state.get('filter', {}), simple.get('filter', {})
    paths = [path for path in {**old.get('keys', {}), **new.get('keys', {})} if old.get('keys', {}).get(path) != new.get('keys', {}).get(path)]
    paths += [path for path in {**old.get('ranges', {}), **new.get('ranges', {})} if old.get('ranges', {}).get(path) != new.get('ranges', {}).get(path)]
    labels = sorted({KEY_LABELS[path].label if path in KEY_LABELS else path for path in paths})
    return labels + ([L(30891, 'Sort')] if state.get('sort', []) != simple.get('sort', []) else [])


def simplify(media: SelectionMedia, name: str) -> None:
    """Make the current selection of a media one the simple view shows, as it was kept in the set `name` (the switch of the filter stays)."""
    langs = user_languages()
    state = current_state(media)
    simple = simple_state(simple_values(state, langs=langs), langs=langs)
    simple['filter']['on'] = state.get('filter', {}).get('on', True)
    with filters_store.batch():
        save_set(media, name)
        set_current_state(media, simple, base=None)


def _migrate_2(data: dict[str, Any]) -> None:
    """
    Version 2: a criterion of the sort is one place of the sort key - the order of the values of a key (`order`, the unknown one in it)
    becomes as many criteria of one feature each (`any`) in that order (a value out of it: after them, equal to the unknown one); the
    last one of an order of all the values of the key (no unknown in it) is left out: it orders nothing; a flag is a number in its
    natural order (`desc`: set first).
    """
    def features(item: dict[str, Any]) -> list[SortCriterion]:
        """Return the criteria of one feature each of an order of the values of a key (a flag: one criterion of its direction)."""
        path, order = item.get('key', ''), list(item['order'])
        if (key := SOURCE_KEYS.get(path)) is not None and key.kind == 'flag':
            return [SortCriterion(key=path, desc=True)] if order[:1] == [TRUE] else [SortCriterion(key=path)]
        if key is not None and key.values and UNKNOWN not in order and set(key.values) <= set(order):
            order = order[:-1]
        return [SortCriterion(any={path: [value]}) for value in order]

    for group in ('sets', 'current'):
        for entry in (data.get(group) or {}).values():
            if isinstance(entry, dict) and isinstance(sort := entry.get('sort'), list):
                entry['sort'] = [crit for item in sort for crit in (features(item) if 'order' in item else [item])]


#: The old sort of the modes of the providers and the hostings (before the language alone: the localization in its place).
OLD_SORT_MODES: tuple[tuple[SortCriterion, ...], ...] = tuple((*ORIGIN_FIRST, PRIORITY, LOCALIZATION, *QUALITY, SortCriterion(key=key), SIZE)
                                                               for key in ('provider', 'hosting'))


def _new_sort(sort: list[SortCriterion]) -> list[SortCriterion]:
    """Return a sort of the old settings with the language alone in the place of the localization (one of other criteria: as it is)."""
    if tuple(sort) in OLD_SORT_MODES:
        return [SortCriterion(**crit) for crit in LEGACY_SORTS[OLD_SORT_MODES.index(tuple(sort))]]
    custom = [*(SortCriterion(**crit) for crit in (PRIORITY, LOCALIZATION, *QUALITY, SIZE))]
    if sort[:1] == list(ORIGIN_FIRST) and all(crit in custom for crit in sort[1:]) and LOCALIZATION in sort[:-1]:
        return [*(SortCriterion(**LANGUAGE) if crit == LOCALIZATION else crit for crit in sort), SortCriterion(**LOCALIZATION)]
    return sort


def _new_cuts(keys: dict[str, dict[str, bool]], langs: Sequence[str]) -> None:
    """Change the cuts of the old settings of a filter as they worked (`keys`, in place): the subtitles, the cinema sound, only Polish."""
    lang = keys.get('lang', {})
    subtitles = [f'{code}/{SUBTITLES_WAY}' for code in (*langs, OTHER_LANGUAGE, UNKNOWN)]
    if all(lang.get(way) is False for way in subtitles):
        for way in subtitles:
            del lang[way]
        keys.setdefault('subtitles.kind', {})[NO_POLISH_AUDIO] = False
    if keys.get('audio.recording', {}).get(AudioRecording.MIC.value) is False:
        keys['audio.recording'][CINEMA_DUBBING] = False
    for option in (1, 2):  # only Polish, Polish and MULTI (their old form: no language data let through)
        old = _legacy_lang(option, subtitles=NO_POLISH_AUDIO not in keys.get('subtitles.kind', {}), langs=langs)
        if lang == {path: on for path, on in old.items() if path != UNKNOWN}:
            lang[UNKNOWN] = False
    if not lang:
        keys.pop('lang', None)


def _migrate_3(data: dict[str, Any]) -> None:
    """
    Version 3: the states made of the old settings before their mapping was corrected (the language alone in the sort, the cuts); a current
    selection the simple view can not show: the advanced view chosen (never a filter changed by itself).
    """
    from .config import config
    from ..sources.source_settings import SOURCE_SETTINGS_CONFIG, SIMPLE_SETTING
    langs = user_languages()
    for group in ('sets', 'current', 'previous'):
        for entry in (data.get(group) or {}).values():
            if isinstance(entry, dict):
                entry['sort'] = _new_sort(list(entry.get('sort', [])))
                _new_cuts(entry.setdefault('filter', {}).setdefault('keys', {}), langs)
    if not all(representable(entry, langs=langs) for entry in (data.get('current') or {}).values()):
        config.set(f'{SOURCE_SETTINGS_CONFIG}/{SIMPLE_SETTING}', False)


#: Migrations of the data: the version -> the change of the data of the version before (in place).
MIGRATIONS: dict[int, Callable[[dict[str, Any]], None]] = {
    1: _migrate_1,
    2: _migrate_2,
    3: _migrate_3,
}


def migrate(data: dict[str, Any]) -> bool:
    """Migrate the data of `source_filters.json` (in place) to `FILTERS_VERSION` (no version: 0, a new file). Return True if changed."""
    return migrate_data(data, version=FILTERS_VERSION, migrations=MIGRATIONS, first=0)


def _filters_path() -> Path:
    """Return the path of `source_filters.json` (the add-on profile)."""
    from .control import dataPath
    return Path(dataPath) / 'source_filters.json'


#: The sets and the current selections of the sources of the user.
filters_store: ConfigStore = ConfigStore(_filters_path, migrate=migrate)


def filters_data() -> dict[str, Any]:
    """Return the data of the file (a new file made first: the migrations from the old settings run)."""
    if not (data := filters_store.data()) and filters_store.valid:
        filters_store.set('/version', FILTERS_VERSION)  # a new file: migrated first (version 0)
        data = filters_store.data()
    return data


def user_languages(*, default: str = 'pl') -> list[str]:
    """Return the languages of the user: the accepted languages of the providers (`providers_lang`, the codes joined by ",")."""
    from ..sources.source_settings import PROVIDERS_LANG_SETTING, source_setting
    return [lang for lang in (source_setting(PROVIDERS_LANG_SETTING) or default).split(',') if lang]


def item_media(ffitem: FFItem) -> SelectionMedia:
    """Return the media of the selection of the sources of an item: a movie, else a show (its episodes)."""
    return 'movie' if ffitem.ref.is_movie else 'show'


def selection_media(media: SelectionMedia) -> SelectionMedia:
    """Return the media of the current selection of a media: the shows have their own (the setting `separate_shows`), else the movies."""
    from ..sources.source_settings import SEPARATE_SETTING, source_setting
    return media if source_setting(SEPARATE_SETTING) else 'movie'


def current_state(media: SelectionMedia = 'movie') -> CurrentSelection:
    """Return the current selection of a media (the shows without their own: the movies; none: the default set)."""
    data = filters_data()
    current = data.get('current', {})
    if (state := current.get(selection_media(media))) is None:
        state = current.get('movie')
    if state is None:
        sets = data.get('sets') or start_sets(langs=user_languages())
        name, entry = next(iter(sets.items()))
        state = CurrentSelection(base=name, filter=entry.get('filter', {}), sort=entry.get('sort', []))
    return deepcopy(state)


def set_current_state(media: SelectionMedia, state: SelectionState, *, base: str | None | EllipsisType = ...) -> bool:
    """Set the current selection of a media (its base kept, `base`: a new one). Return True if written."""
    media = selection_media(media)
    if base is ...:
        base = current_state(media).get('base')
    return filters_store.set(f'/current/{media}', CurrentSelection(base=base, filter=state.get('filter', {}), sort=state.get('sort', [])))


def is_modified(media: SelectionMedia = 'movie', state: CurrentSelection | None = None) -> bool:
    """Check if the current selection of a media (`state`: a selection of a window, not stored) differs from its set (no set: modified)."""
    state = current_state(media) if state is None else state
    entry = filters_data().get('sets', {}).get(state.get('base') or '')
    return entry is None or not same_filter(entry.get('filter', {}), state.get('filter', {})) or entry.get('sort', []) != state.get('sort', [])


def set_names() -> list[str]:
    """Return the names of the sets in their order (the first one - the default one - can be overwritten, not deleted)."""
    return list(filters_data().get('sets') or ())


def previous_state(media: SelectionMedia = 'movie') -> CurrentSelection | None:
    """Return the selection before the current one of a media (one, as a backup `file~`), None: none yet."""
    return deepcopy(filters_data().get('previous', {}).get(selection_media(media)))


def remember_previous(media: SelectionMedia) -> bool:
    """Keep the current selection of a media as its previous one. Return True if written."""
    return filters_store.set(f'/previous/{selection_media(media)}', current_state(media))


def set_previous_state(media: SelectionMedia, state: CurrentSelection) -> bool:
    """Keep a selection of a window (not stored as the current one) as the previous one of a media. Return True if written."""
    return filters_store.set(f'/previous/{selection_media(media)}', state)


def set_state(name: str) -> SelectionState:
    """Return a set."""
    return deepcopy(filters_data()['sets'][name])


def load_set(media: SelectionMedia, name: str) -> None:
    """Make a set the current selection of a media, the one before it kept as the previous one."""
    entry = filters_data()['sets'][name]
    with filters_store.batch():
        remember_previous(media)
        set_current_state(media, entry, base=name)


def load_previous(media: SelectionMedia) -> None:
    """Swap the current selection of a media and its previous one (none: nothing)."""
    if (previous := previous_state(media)) is not None:
        with filters_store.batch():
            remember_previous(media)
            set_current_state(media, previous, base=previous.get('base'))


def save_set(media: SelectionMedia, name: str) -> None:
    """Save the current selection of a media as a set (an existing name: overwritten, in its place), the set it comes from now."""
    state = current_state(media)
    with filters_store.batch():
        filters_store.set(f'/sets/{escape_key(name)}', SelectionState(filter=state.get('filter', {}), sort=state.get('sort', [])))
        set_current_state(media, state, base=name)


def delete_set(name: str) -> bool:
    """Delete a set (not the first one; the selections from it stay, of no set). Return True if deleted."""
    if name not in set_names()[1:]:
        return False
    return filters_store.remove(f'/sets/{escape_key(name)}')


def current_selection(media: SelectionMedia = 'movie', *, langs: Sequence[str],
                      priority: Callable[[Source], int] = lambda src: 0) -> Selection:
    """Return the compiled current selection of a media."""
    return compile_selection(current_state(media), langs=langs, priority=priority)
