"""Main module."""

# parse command-line (debug) args on TOP, to set global options first
if __name__ == '__main__':
    try:
        from .dev.main import predefine as tui_predefine, parse_args as tui_parse_args
    except ModuleNotFoundError:
        import sys
        print('There is no module lib.dev, find a developer release.')
        sys.exit(0)
    cli_args, cli_argv = tui_predefine(args=tui_parse_args())
else:
    cli_args, cli_argv = None, []

import re
import sys  # for exit()
from typing import Optional, List, TYPE_CHECKING
from typing_extensions import Literal
from time import monotonic


from const import const
from .ff.settings import settings
from .ff.routing import URL, dispatch, main_router
from .ff import control
from .ff.control import Finally
from .ff.control import reset_all as reset  # noqa: F401  # the plugin start and the dev tools call `main.reset()`
from .ff.db import state
from .ff.db.playback import progress_timestamp
from .ff.logs import fflog, fflog_exc
from .ff.routing import route, PathArg
from .ff.calendar import utc_timestamp
from .ff.menu import KodiDirectory, directory
from .ff.info import ffinfo
from .service.client import service_client
# from .defs import VideoIds
from .indexers import play as _play_routes  # noqa: F401  # the first dispatch phase: the global play routes
from .kolang import L

if TYPE_CHECKING:
    from .ff.routing import RouteCall
    from .service.misc import PluginRequestInfo


main_router.url = URL(control.plugin_url)


def load_navigator() -> None:
    """Load the navigator: the routes of the menus and indexers (the second dispatch phase), it binds itself to the router."""
    from .indexers import navigator  # noqa: F401


def dispatch_url(url: URL) -> None:
    """
    Dispatch the plugin URL: the light global routes first (a play), the navigator is loaded only if they miss;
    an unknown URL (e.g. an old path in a widget or Kodi favourites) is an empty folder, Kodi waits for its answer.
    """
    if not dispatch(url, missing=...):
        load_navigator()
        dispatch(url, missing=unhandled_url)


def find_inner_call(url: 'URL | str') -> Optional['RouteCall']:
    """
    Find the call of an inner menu URL of a global route (a gallery of a folder, the page jump): the global routes are
    dispatched before the navigator is loaded, so load it first. Call it by `main_router.call()`.
    """
    load_navigator()
    return main_router.find_dispatch(url)


def unhandled_url(url: URL) -> None:
    """
    Answer an unknown URL by the no-content folder (`const.indexer.no_content`), a play URL of no item by a failed one.
    A call without a handle (RunPlugin, a script) is not awaited and has no folder: a notification only.
    """
    from .ff.menu import no_content
    from .indexers.play import is_play_url, no_play
    fflog.warning(f'Unhandled url {str(url)!r}')
    if control.current_call().handle < 0:
        if const.indexer.no_content.script_notification:
            control.infoDialog(L(32998, 'Unknown FanFilm link'), icon='WARNING')
        return
    if is_play_url(url):
        return no_play(url)
    no_content()


def answer_kodi(url: URL) -> None:
    """
    Answer Kodi at the end of a call with a handle that gave it neither a folder nor an item to play (e.g. an exception
    before the folder): a failed empty folder, else Kodi waits for ever. A call without a handle (RunPlugin) is not awaited.
    """
    call = control.current_call()
    if call.handle >= 0 and not call.answered:
        fflog.warning(f'[FF] {str(url)!r} did not answer Kodi (no folder, no resolved item): a failed empty folder')
        control.end_of_directory(call.handle, succeeded=False, cacheToDisc=False)


def bypass_scanning(info: 'PluginRequestInfo') -> bool:
    """
    List a folder of the Kodi scan of a show / season (Kodi marks it (un)watched natively folder by folder): return True if
    done. The scan announced by the FF menu: the folder has all its aired episodes (a show: no season folders). The scan of
    a show found by the service (the show and its 1st season listed already): the 2nd season folder has the aired episodes
    of the next seasons, the next season folders are empty.
    """
    from .defs import MediaRef
    media_path, path = info.media_url.path, info.url.path
    if not (media := MediaRef.from_slash_string(media_path.lstrip('/'))) or not media.is_container:
        return False
    if path == media_path and info.scan_started:
        episodes = ffinfo.aired_episode_refs(media, episode_group=info.url.args.get('episode_group') or None)
    elif media.is_show and re.fullmatch(rf'{media_path}/\d+', path):
        episodes = [ep for ep in ffinfo.aired_episode_refs(media) if (ep.season or 0) >= 2] if info.scan_started else []
    else:
        return False
    with directory() as kdir:
        # the same episodes as the FF menu marks (from the metadata), with their play counts from Kodi DB (not the FF
        # progress, the accounts have the change already): Kodi changes the items of the other state only
        if episodes:
            from .ff.kodidb import video_db
            from .ff.routing import url_for
            from .indexers.play import play
            plays = {pb.ref: pb.play_count for pb in video_db.get_plays(episodes)}
            for ref in episodes:
                kdir.play(f'{ref.season}x{ref.episode:02d}', url_for(play, ref=ref)).vtag.setPlaycount(plays.get(ref, 0))
    return True


def main(argv: List[str]) -> None:
    """The main FF entry."""

    if 0:  # DEBUG: measure settings load time
        with fflog_exc():
            from xbmcaddon import Addon
            from .ff.tricks import timeit
            from .ff.settings import SettingsManager
            t = timeit(lambda: Addon().getSetting('plugin.video.fanfilm'))
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (KODI)  !!!!! : {t:.6f} sec')
            t = timeit(settings.load_settings)
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (USER)  !!!!! : {t:.6f} sec')
            t = timeit(lambda: SettingsManager().load_settings())
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (ALL)   !!!!! : {t:.6f} sec')
            t = timeit(lambda: SettingsManager().load_defaults())
            fflog(f'|||||>>>>>>>>>>>>>>>>>>>>>>> SETTINGS (DEFS)  !!!!! : {t:.6f} sec')

    if 0:  # FFItem/ListItem tests
        from xbmcgui import ListItem
        it = ListItem()
        vtag = it.getVideoInfoTag()
        it.setDateTime('2025-12-31 11:22:33')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {it.getDateTime()=}')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {vtag.getFirstAiredAsW3C()=}')
        fflog(f'>>>>>>>>>>>>>>>>>>>>>>>>>>>> {it.getProperty("isPlayable")=}, {it.isFolder()=}')

    T = monotonic()
    http_count = None
    if const.debug.log_http:
        from .ff.requests import count_http
        http_count = count_http()
    url = URL(argv[0] + argv[2])
    Finally.clear()
    if control.is_plugin_folder():
        folder_info = service_client.plugin_request_enter(url, timestamp=utc_timestamp())
    else:
        from .service.misc import PluginRequestInfo
        folder_info = PluginRequestInfo()
    KodiDirectory.set_current_info(url, folder_info)
    master: bool = state.enter('plugin')
    state.delete_all(module='directory')
    state.multi_set((
        ('running', True),
        ('url', str(url)),
        ('path', url.path),
    ), module='directory')
    try:
        if folder_info.scan and bypass_scanning(folder_info):
            progress_timestamp_before = progress_timestamp()
        else:
            KodiDirectory.ready_for_data()
            progress_timestamp_before = progress_timestamp()
            dispatch_url(url)
    except Exception:
        fflog_exc()
        raise
    else:
        # handle queued jobs
        for job in state.jobs('plugin'):
            handle_job(job, argv)
        if KodiDirectory.state().info.refresh and control.is_plugin_folder():  # a widget is never refreshed (the skin reloads it)
            new_timestamp = progress_timestamp()
            fflog(f'Refresh? {progress_timestamp_before=}, {new_timestamp=}')
            if new_timestamp != progress_timestamp_before:
                control.refresh()
    finally:
        if control.is_plugin_folder():
            directory_state = KodiDirectory.state()
            service_client.plugin_request_exit(folder=directory_state.content if directory_state.created else None,
                                               focus=directory_state.focus_index, timestamp=utc_timestamp())
        state.set('running', False, module='directory', connect=False)
        state.exit('plugin')
        for fin in Finally.iter():
            fin()
        Finally.clear()
        answer_kodi(url)
        T = monotonic() - T
        fflog(f'[FF] main finished in {T:.3f} seconds')
        if http_count is not None:
            fflog(f'[FF] http requests: {sum(http_count.values())} {dict(http_count)}')


@route
def xplay(type: PathArg[Literal['movie', 'tvshow']], ffid: PathArg[int],
          season: Optional[PathArg[int]] = None, episode: Optional[PathArg[int]] = None) -> None:
    """Play video."""
    print(f'play({type=}, {ffid=}, {season=}, {episode=}) ...')


# XXX  ---( DEBUG )---   XXX
@route('/play430/movie')
def fake_play_movie(ffid: PathArg[int], *, edit: bool = False) -> None:
    from pathlib import Path
    from .defs import MediaRef
    from .ff import player
    from .ff.item import FFItem
    import sty
    item: Optional[FFItem] = ffinfo.find_item(MediaRef('movie', ffid))
    fflog(f'{sty.fg.cyan}######{sty.rs.all} {ffid=}, {item=}')
    if item and control.yesnoDialog('play fake video'):
        player.play(ffitem=item, url=str(Path('~/Videos/Agent 700 _ WYSOKA JAKOŚĆ -g-bbImiyuPQ.mkv').expanduser()))
    else:
        player.cancel(item)


@route
def crash() -> None:
    """Forces crash, raises en exception."""
    raise Exception('Devleper forced CRASH')


@route
def restart() -> None:
    """Restart the FF service in a fresh interpreter (as after a Kodi restart)."""
    from .service.client import service_client
    service_client.restart_service()


def handle_job(job: state.Job, argv: List[str]) -> None:
    """Handle pending job."""

    if const.debug.enabled:
        if const.debug.tty:
            fflog(f'[JOB] \033[96mjob\033[0m: {job}')
        else:
            fflog(f'[JOB] job: {job}')
    if job.command == 'update':
        if job.args and job.args[0]:
            path = job.args[0]
        else:
            path = ''  # f'{argv[0]}{argv[2]}'  # path to current plugin call
        control.update(path)
    elif job.command == 'refresh':
        control.refresh()
    elif job.command == 'builtin':
        control.execute(job.args[0])


# --- testy (konsola)  ---


if __name__ == '__main__':
    from .dev.main import main as tui
    tui(args=cli_args)
