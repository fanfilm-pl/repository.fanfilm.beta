"""
The thin plugin: a plugin call of a handle (a folder, a widget) runs in the FF service, warm (see `lib.service.remote`).

It imports only Kodi and the standard library, its cost is the gain: a cold interpreter of FanFilm takes 1-3 s (a Pi 3-10 s).
The service publishes its address (`REMOTE_PROPERTY`) when it runs the plugin calls (`const.tune.service.remote_plugin`);
no address, no service, a play, a call without a handle (RunPlugin): the call runs in the plugin (`launch()`).
"""

from __future__ import annotations
import json
import os
import sys
from http.client import HTTPConnection
from socket import SHUT_RDWR
from threading import Thread
from time import monotonic
from typing import Any, Dict
from urllib.parse import urlsplit

#: The Home window property of the running service: JSON {"url": ..., "abort_wait": ...}, {} if it runs no plugin calls,
#: `REMOTE_QUIT` while Kodi exits.
REMOTE_PROPERTY = 'fanfilm.service.remote'
#: `REMOTE_PROPERTY` at Kodi exit: a call ends at once without its answer (Kodi stops only after the plugin calls ended by
#: themselves, it does not abort them; the service of an exiting Kodi runs no call).
REMOTE_QUIT = '{"quit": true}'
#: The file of the service which runs the plugin calls (the FF profile folder): JSON {"startup_timeout": ...}. It lives
#: across Kodi runs: at Kodi start the thin plugin waits for the service (its property) up to the timeout.
REMOTE_FILE = 'remote.json'
#: The route of a plugin call in the service.
RUN_PATH = '/plugin/run'
#: The route of the abort of a plugin call.
ABORT_PATH = '/plugin/abort'
#: Kodi Home window (`control.HOME_WINDOW`, FanFilm is not imported here).
HOME_WINDOW = 10_000
#: How often the thin plugin looks for the Kodi abort of its call, seconds.
ABORT_STEP = .1


def remote_address(url: str | None, *, abort_wait: float) -> str:
    """Return the value of `REMOTE_PROPERTY` (the service): its server `url` (None: no plugin calls), the wait for an aborted call."""
    return json.dumps({'url': url, 'abort_wait': abort_wait} if url else {})


def _wait_for_service(addon_id: str) -> str:
    """Return the property of the service started meanwhile if it runs the plugin calls (its file), '' if none in time."""
    import xbmc
    import xbmcgui
    import xbmcvfs
    try:
        with open(xbmcvfs.translatePath(f'special://profile/addon_data/{addon_id}/{REMOTE_FILE}'), encoding='utf-8') as file:
            end = monotonic() + json.load(file)['startup_timeout']
    except (OSError, ValueError, KeyError, TypeError):
        return ''
    home, monitor = xbmcgui.Window(HOME_WINDOW), xbmc.Monitor()
    while not (address := home.getProperty(REMOTE_PROPERTY)) and monotonic() < end and not monitor.waitForAbort(ABORT_STEP):
        pass
    return address


def _post(url: str, path: str, data: Dict[str, Any], result: Dict[str, Any], *, timeout: float | None = None) -> None:
    """POST JSON `data` to the service, store its JSON answer (`sent`: the request reached the service) in `result`."""
    address = urlsplit(url)
    conn = HTTPConnection(address.hostname or '127.0.0.1', address.port, timeout=timeout)
    result['conn'] = conn  # the abort cuts it
    try:
        conn.request('POST', path, json.dumps(data), {'Content-Type': 'application/json'})
        result['sent'] = True
        resp = conn.getresponse()
        if resp.status == 200:
            result.update(json.loads(resp.read()))
        else:
            result['here'] = True  # refused: the call did not start (e.g. an old service)
    except Exception as exc:
        result['error'] = exc
    finally:
        conn.close()


def remote_launch() -> bool:
    """Run the plugin call (`sys.argv`) in the FF service; return False if it runs here (`launch()`)."""
    if len(sys.argv) < 3 or sys.argv[1] == '-1':  # no handle (RunPlugin, a script): Kodi does not wait for it
        return False
    import xbmc
    import xbmcgui
    import xbmcplugin
    addon_id = urlsplit(sys.argv[0]).netloc
    home = xbmcgui.Window(HOME_WINDOW)
    if not (address := home.getProperty(REMOTE_PROPERTY) or _wait_for_service(addon_id)):
        return False  # no service (Kodi start, a stop) and it runs no plugin calls
    if address == REMOTE_QUIT:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)  # Kodi exits: no call
        return True
    if not (remote := json.loads(address)).get('url'):
        return False  # the service runs no plugin calls
    monitor = xbmc.Monitor()  # first: Kodi aborts the call only to an existing monitor
    call_id = os.urandom(8).hex()
    folder = xbmc.getInfoLabel('Container.PluginName') == addon_id  # a FF folder or e.g. a widget
    result: Dict[str, Any] = {}
    thread = Thread(target=_post, args=(remote['url'], RUN_PATH, {'call': call_id, 'argv': sys.argv[:3], 'folder': folder}, result))
    thread.start()
    aborted = False
    while thread.is_alive():
        thread.join(ABORT_STEP)
        if thread.is_alive() and (monitor.abortRequested() or home.getProperty(REMOTE_PROPERTY) == REMOTE_QUIT):  # aborted, Kodi exits
            aborted = True
            _post(remote['url'], ABORT_PATH, {'call': call_id}, {}, timeout=remote['abort_wait'])
            thread.join(remote['abort_wait'])
            if thread.is_alive() and (conn := result.get('conn')) is not None and conn.sock is not None:
                try:
                    conn.sock.shutdown(SHUT_RDWR)  # the read ends (not on Windows: the stopped call answers soon)
                except OSError:
                    pass
            thread.join()
            break
    if not aborted and (result.get('here') or not result.get('sent')):  # not started there: run it here (e.g. no service)
        return False
    if not result.get('answered'):  # aborted, failed, the service stopped: Kodi waits for the answer (or hangs)
        if 'error' in result:
            xbmc.log(f'[FanFilm] plugin call in the service failed: {result["error"]!r}', xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    return True
