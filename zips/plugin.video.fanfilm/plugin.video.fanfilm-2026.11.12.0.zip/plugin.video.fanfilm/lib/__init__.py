import sys
from pathlib import Path
from typing import List

#: Debug leftover objects in memory on exit (for memory leak detection).
#: 0 - debug code removed,
#: 1 - stats only: the GC objects count in the "[FF] exit" log line (`gc.get_objects()`, 10-20 ms a call)
#: 2 - dump code left in
#: 3 - dump code left in + dump traceback of Kodi objects (now: Addons) and FFItems
DEBUG_LEFTOVER_OBJECTS: int = 0
#: Modules to remove on exit to free Kodi objects (Addons, ListItems, etc.) from memory.
MODULES_TO_REMOVE_ON_EXIT: 'set[str]' = set()  # {'resolveurl', 'inputstreamhelper'}


if DEBUG_LEFTOVER_OBJECTS >= 3:
    import traceback
    import xbmcaddon, xbmcgui
    class Addon(xbmcaddon.Addon):
        def __new__(cls, *args, **kwargs):
            obj = super().__new__(cls, *args, **kwargs)
            obj._traceback = ''.join(traceback.format_stack())
            return obj
    xbmcaddon.Addon = Addon
    # class ListItem(xbmcgui.ListItem):
    #     def __new__(cls, *args, **kwargs):
    #         obj = super().__new__(cls, *args, **kwargs)
    #         obj._traceback = ''.join(traceback.format_stack())
    #         return obj
    # xbmcgui.ListItem = ListItem


def run_by_kodi() -> bool:
    """
    Detect if our script is run by Kodi (in its subinterpreter) or not (command line, tests): Kodi builds
    its modules in (`xbmc`, `xbmcgui`, … in the inittab), fakes and stubs (`lib/fake`, Kodistubs) are files.
    """
    return 'xbmc' in sys.builtin_module_names


RUN_BY_KODI: bool = run_by_kodi()
cmdline_argv: List[str] = []
FAKE: bool = not RUN_BY_KODI
MOCK: bool = False

# Path to the top-level fanfilm folder.
top_ff_path = Path(__file__).parent
# Add paths to 3rd-party libs.
sys.path.insert(0, str(top_ff_path / '3rd'))

# Add fake xmbc modules (DEBUG & TESTS).
if FAKE:
    import os
    sys.path.insert(0, str(top_ff_path / 'fake'))
    if os.environ.get('XBMC_MOCK') == '1':
        sys.path.insert(0, str(top_ff_path / 'fake' / 'raw'))
        MOCK = True
    # Fake sys.argv for DEBUG & TESTS from command line
    cmdline_argv, sys.argv = sys.argv, ['plugin://fanfilm/', '0', '']
    from lib.fake.fake_api import auto
    auto(cmdline_argv)
    del auto


# Monkey-patching datetime.strptime
# see: https://forum.kodi.tv/showthread.php?tid=112916&pid=2953239
# see: https://bugs.python.org/issue27400
import datetime as datetime_module            # noqa: E402
from .sdk.dates import python_datetime as _datetime, strptime as _safe_strptime  # noqa: E402  (before any patch)


# Checked in real code, fixed in py3.13.
if sys.version_info >= (3, 11):
    datetime = _datetime
elif not getattr(datetime_module, '_datetime_is_patched', False):

    class datetime(_datetime):

        @classmethod
        def strptime(cls, date_string: str, format: str) -> _datetime:
            return _safe_strptime(date_string, format)

    datetime_module.datetime = datetime
    datetime_module._datetime = _datetime
    datetime_module._datetime_is_patched = True
