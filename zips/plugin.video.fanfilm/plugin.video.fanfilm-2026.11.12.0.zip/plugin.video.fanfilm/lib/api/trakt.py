
from __future__ import annotations
from urllib.parse import urljoin, urlparse, urlunparse
import json
from time import monotonic
from datetime import datetime, timedelta, date as dt_date
from contextlib import contextmanager
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from itertools import chain
from threading import Lock, RLock
from itertools import chain
from typing import Any, Sequence, Mapping, Iterable, Iterator, Callable, TypeVar
from typing import ClassVar, NamedTuple, TYPE_CHECKING
from typing_extensions import Literal, TypeAlias, get_args as get_typing_args, TypedDict, Unpack, NotRequired, cast
from attrs import define, frozen, field, fields, asdict
from wrapt import ObjectProxy  # wrapt 2.x: wrappers.ObjectProxy (BaseObjectProxy) has no __iter__
import requests
from requests.exceptions import JSONDecodeError

from . import ALL_PAGES
from ..ff.kotools import xsleep
from ..ff.tricks import join_items
from ..ff.logs import fflog, log
from ..ff.item import FFItem, ListEntry
from ..ff import apis
from ..ff.settings import settings
from ..ff.sync import cursor_time
from ..ff.db.playback import (
    MediaPlayInfo,
    get_playback, get_playback_item, update_track_watched_item,
    update_track_playback, update_track_watched_movies, update_track_watched_episodes,
    remove_account_rows,
)
from ..ff.db.accounts import reset_sync
from ..ff.listcache import FetchedList, cached_list, list_params, mark_stale, remove_scope
from ..ff.accounts import Account, AccountClient, all_found, failed_request
from ..ff.ratings import RatingScale, pick_ratings
from ..ff.calendar import fromisoformat, utc_timestamp, utc_2_iso
from ..ff.types import JsonData, JsonResult, KwArgs
from ..defs import MediaType, MainMediaType, MainMediaTypeList, MediaOrPersonType, MediaRef, VideoIds, ItemList, Pagina, RefType, FFRef
from ..defs import MediaProgress, MediaProgressItem
from ..defs import IdsDict as Ids
from cdefs import ListSection, ListType, const_value
from const import const, CONST_REF

if TYPE_CHECKING:
    from ..ff.sync import SyncBucket
    from typing import Generator
    from request.structures import CaseInsensitiveDict


T = TypeVar('T')

#: Trakt.tv objects to watch.
MainContentType: TypeAlias = Literal['movies', 'shows']
#: Any trakt.tv Standard Media Object.
AnyContentType: TypeAlias = Literal['movies', 'shows', 'seasons', 'episodes', 'persons', 'users', 'lists', 'comments']
#: Any trakt.tv Standard Media Object.
HistoryContentType: TypeAlias = Literal['movies', 'shows', 'seasons', 'episodes']
#: Trakt.tv objects to play.
PlayContentType: TypeAlias = Literal['movie', 'episode']
#: Trakt.tv objects to watch.
WatchContentType: TypeAlias = MainContentType
#: Scrobble action.
ScrobbleAction: TypeAlias = Literal['start', 'pause', 'stop']
#: Lookup ID services.
LookupService: TypeAlias = Literal['trakt', 'imdb', 'tmdb', 'tvdb']
#: Movie / tvshow list names.
ListName: TypeAlias = Literal['anticipated', 'collected', 'favorited', 'played', 'popular', 'trending', 'watched']
#: Movie / tvshow names of lists with period.
ListWithPeriod: TypeAlias = Literal['collected', 'favorited', 'played', 'watched']
#: User general list type.
UserListType: TypeAlias = Literal['likes', 'watchlist', 'favorites', 'history', 'watched']  # no: 'collection'
#: User general list type. List is writable, items can be added/removed.
UserListPostType: TypeAlias = Literal['watchlist', 'favorites', 'collection', 'history']  # no: 'ratings'
#: Users list, the most: UserListType, popular.
UserGeneralListType: TypeAlias = Literal['trending', 'popular']
#: Rating type on get.
UserRatingType: TypeAlias = Literal['all', 'movies', 'shows', 'seasons', 'episodes']
#: Like type. "" means all types.
LikeType: TypeAlias = Literal['list', 'comment', '']
#: Extended response info.
ExtendedInfo: TypeAlias = Literal['full', 'progress', 'metadata', 'noseasons', 'episodes', 'comments', 'guest_stars', 'vip', '']
#: Sort by, returned by trakt as 'X-sort-by' (user) and 'X-Applied-Sort-By' (response).
SortBy: TypeAlias = Literal['rank', 'added', 'title', 'released', 'runtime', 'popularity', 'percentage', 'votes',
                            'my_rating', 'random', 'watched', 'collected']
#: Sort type (by and how), returned by trakt as 'X-sort-by'.'X-Sort-How' (user) and 'X-Applied-Sort-By'.'X-Applied-Sort-How' (response).
SortType: TypeAlias = Literal[
    '',          # default sort (no sort)
    'trakt',     # trakt sort ('X-sort-by'.'X-Sort-How')
    'rank.asc', 'rank.desc',
    'added.asc', 'added.desc',
    'title.asc', 'title.desc',
    'released.asc', 'released.desc',
    'runtime.asc', 'runtime.desc',
    'popularity.asc', 'popularity.desc',
    'percentage.asc', 'percentage.desc',
    'votes.asc', 'votes.desc',
    'my_rating.asc', 'my_rating.desc',
    'random.asc', 'random.desc',
    'watched.asc', 'watched.desc',
    'collected.asc', 'collected.desc',
]


#: Filters for all supported endpoints.
class TraktFilters(TypedDict):
    query: NotRequired[str]                       # -  batman      - Search titles and descriptions.
    years: NotRequired[int]                       # -  2016        - 4 digit year or range of years.
    genres: NotRequired[str | Sequence[str]]      # ✓  action      - Genre slugs.
    subgenres: NotRequired[str | Sequence[str]]   # ✓  android     - Subgenre slugs.
    languages: NotRequired[str | Sequence[str]]   # ✓  en          - 2 character language code.
    countries: NotRequired[str | Sequence[str]]   # ✓  us          - 2 character country code.
    runtimes: NotRequired[int]                    # -  30-90       - Range in minutes.
    studio_ids: NotRequired[int | Sequence[int]]  # ✓  42          - Trakt studio ID.


class TraktExcepiton(Exception):
    """All exception from trakt.tv."""
    def __init__(self, *args,
                 code: int | None = None,
                 text: str | None = None,
                 url: str | None = None,
                 ) -> None:
        super().__init__(*args)
        #: HTTP status code.
        self.code: int | None = code
        #: HTTP response text.
        self.text: str | None = text
        #: URL.
        self.url: str | None = url

    @classmethod
    def from_response(cls, response: requests.Response, msg: str | None = None) -> 'TraktExcepiton':
        args = () if msg is None else (msg,)
        return cls(*args, code=response.status_code, text=response.text, url=response.request.url)


class TraktAuthError(TraktExcepiton):
    """Authentication exception."""


@frozen(kw_only=True)
class TraktCredentials:
    """Trakt.tv credentials."""

    #: Client ID
    client: str
    #: Client Secret
    secret: str
    #: Access token (`accounts.db`, the account `token`).
    access_token: str | None = None
    #: Refresh token (the account `token`).
    refresh_token: str | None = None
    #: Access token expire timestamp (the account `token`).
    expires_at: int = field(default=0, converter=int)

    def __bool__(self) -> bool:
        """Return True if credentials are defined (trakt.tv can be used)."""
        return bool(self.access_token)
        # return bool(self.refresh_token)


class TraktIds(TypedDict):
    """IDs of trakt item (media)."""

    trakt: int
    tmdb: NotRequired[int]
    imdb: NotRequired[str]
    tvdb: NotRequired[int]
    slug: NotRequired[str]


@frozen
class TraktUserProfile:
    """Trakt.tv user profile info."""

    #: User ID (slug).
    id: str
    #: User name (nick).
    username: str
    #: User full name.
    name: str
    #: True if profile is private.
    private: bool = False
    #: True if it's VIP profile.
    vip: bool = False
    #: Avatar URL.
    avatar: str | None = None
    #: Location country code (ex. "PL").
    location: str | None = None

    # rest: joined_at, about, gender, age


@frozen
class Pages:
    """Current Page info."""
    page: int
    page_size: int = field(default=0, kw_only=True)
    page_count: int = field(default=0, kw_only=True)
    item_count: int = field(default=0, kw_only=True)
    sort: SortType = field(default='', kw_only=True)
    response_sort: SortType = field(default='', kw_only=True)

    @classmethod
    def from_headers(cls, headers: dict[str, str] | CaseInsensitiveDict[str], page: int = 0) -> 'Pages':
        page = int(headers.get('X-Pagination-Page', page))
        page_size = int(headers.get('X-Pagination-Limit', 0))
        page_count = int(headers.get('X-Pagination-Page-Count', 0))
        item_count = int(headers.get('X-Pagination-Item-Count', 0))
        sort: SortType = ''
        if (sort_by := headers.get('X-Sort-By')) and (sort_ord := headers.get('X-Sort-How')):
            sort = f'{sort_by}.{sort_ord}'  # type: ignore
        reps_sort: SortType = ''
        if (sort_by := headers.get('X-Applied-Sort-By')) and (sort_ord := headers.get('X-Applied-Sort-How')):
            reps_sort = f'{sort_by}.{sort_ord}'  # type: ignore
        return Pages(page, page_size=page_size, page_count=page_count, item_count=item_count, sort=sort, response_sort=reps_sort)

    @classmethod
    def empty(cls) -> 'Pages':
        return Pages(0)

    @classmethod
    def single(cls, item_count: int = 1) -> 'Pages':
        return Pages(1, page_count=1, item_count=item_count)

    def list(self, items: Iterable[T]) -> ItemList[T]:
        return ItemList(items, page=self.page, total_pages=self.page_count, total_results=self.item_count)


class MultiShowId(NamedTuple):
    """Lookup show ID result, part of MultiId."""
    #: TVshow ID for show/season/episode.
    vid: VideoIds
    #: TVshow title.
    title: str | None = None


class MultiId(NamedTuple):
    """Lookup ID result."""

    #: Media type.
    type: str
    #: Media reference. If there is no TMDB data could be None.
    #: Ref is normalized (movie/show with season/episode numbers if needed).
    ref: MediaRef | None
    #: Media IDs (eg. TMDB & IMDB episode ID).
    vid: VideoIds
    #: TVshow for show/season/episode.
    show: MultiShowId | None
    #: Media title.
    title: str | None = None
    #: Media / tvshow year.
    year: int | None = None
    #: Trakt.tv slug ID.
    trakt_slug: str | None = None


#: Sync buckets (FF bucket -> groups and keys in `sync/last_activities`, the newest one is the cursor), see `lib.ff.sync`.
SYNC_BUCKETS: dict[SyncBucket, tuple[tuple[str, str], ...]] = {
    'progress.movie': (('movies', 'paused_at'),),
    'progress.episode': (('episodes', 'paused_at'),),
    'watched.movie': (('movies', 'watched_at'),),
    'watched.episode': (('episodes', 'watched_at'),),
    'lists.watchlist': (('watchlist', 'updated_at'),),
    'lists.favorites': (('favorites', 'updated_at'),),
    'lists.collection': (('movies', 'collected_at'), ('episodes', 'collected_at')),
    'lists.user': (('lists', 'updated_at'),),
    'ratings': (('movies', 'rated_at'), ('shows', 'rated_at'), ('seasons', 'rated_at'), ('episodes', 'rated_at')),
}

#: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
SYNC_LISTS: dict[SyncBucket, str] = {
    'lists.watchlist': 'watchlist',
    'lists.favorites': 'favorites',
    'lists.collection': 'collection',
    'lists.user': 'user',
    'ratings': 'rated',
}


class TraktRequestKwargs(TypedDict):
    params: NotRequired[KwArgs | None]
    page: NotRequired[int | None]
    limit: NotRequired[int | None]
    extended: NotRequired[ExtendedInfo | None]
    errors: NotRequired[str]
    login_required: NotRequired[bool]
    credentials: NotRequired[TraktCredentials | None]


@define
class TraktApiStats:
    request_count: int = 0


def item_watched_at(item: JsonData) -> int | None:
    watched_at: str | None = item.get('last_watched_at')
    return int(utc_timestamp(watched_at)) if watched_at else None


def item_paused_at(item: JsonData) -> int | None:
    paused_at: str | None = item.get('paused_at')
    return int(utc_timestamp(paused_at)) if paused_at else None


def filter_ids(ids: Mapping[str, int | str]) -> TraktIds:
    allowed = {'tmdb', 'imdb', 'trakt', 'tvdb', 'slug'}
    return cast(TraktIds, {k: v for k, v in ids.items() if k in allowed})


class TraktApi(AccountClient):
    """Trakt.tv API."""

    _main2type: ClassVar[dict[MainMediaType, MainContentType]] = {
        'movie': 'movies',
        'show': 'shows',
    }

    _ref2type: ClassVar[dict[RefType, AnyContentType]] = {
        'movie': 'movies',
        'show': 'shows',
        'season': 'seasons',
        'episode': 'episodes',
        'list': 'lists',
        'person': 'persons',
    }

    _ref2item: ClassVar[dict[RefType, str]] = {
        'movie': 'movie',
        'show': 'show',
        'season': 'season',
        'episode': 'episode',
        'list': 'list',
    }

    #: Sync buckets of the client (`lib.ff.sync`, `lib.ff.listcache`).
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = SYNC_BUCKETS
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = SYNC_LISTS
    #: Interval of the sync in the service (`lib.ff.sync.sync_alive()`).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.interval
    #: Items of a batch history write (no documented maximum: moderate).
    BATCH_LIMIT: ClassVar[int] = 500
    #: A history write ends the resume point of the media (measured 2026-10-23: also a watch older than the pause).
    HISTORY_ENDS_PLAYBACK: ClassVar[bool] = True
    #: Sections of lists of the account.
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'favorites': ListSection(types=ListType.MAIN),
        'watchlist': ListSection(types=ListType.MEDIA),
        'collection': ListSection(types=ListType.MEDIA),
        # No persons: Trakt does not keep them on lists any more (an added person is skipped, `items/person` is empty, 2026-10);
        # the client still reads and writes them (`people_enabled`, the `person` filter), add `ListType.PERSON` if they return.
        'user': ListSection(types=ListType.MEDIA, create={'public': True}, new_types=ListType.ALL_MEDIA),
    }
    #: Rating scale of the account.
    RATING: ClassVar[RatingScale | None] = RatingScale(type=int, min=1, max=10, step=1, media=('movie', 'show', 'season', 'episode'))

    #: Generic lists of the account in the list cache (whole lists; history, watched etc. are state, not lists).
    _CACHED_GENERIC_LISTS: ClassVar[frozenset[str]] = frozenset({'watchlist', 'favorites'})

    _def_list_media: ClassVar[dict[UserListType | Literal['collection'], RefType]] = {
        'likes': 'list',
        'collection': '',
        'watchlist': '',
        'favorites': '',
        'history': '',
    }

    _ref2rating: ClassVar[dict[MediaType | None, UserRatingType]] = {
        None: 'all',
        'movie': 'movies',
        'show': 'shows',
        'season': 'seasons',
        'episode': 'episodes',
    }

    _DEBUG_STATS: ClassVar[TraktApiStats] = TraktApiStats()
    _FAKE: ClassVar[bool] = False
    #: Auto auth (dialog) of every client of the process (False in the service: clients of all accounts).
    AUTO_AUTH: ClassVar[bool] = True

    def __init__(self, account: Account | None = None, *, alias: str = '', auto_auth: bool = True) -> None:
        # The account (its credentials and state): given, the first Trakt account (alias) or none (the application client).
        super().__init__(account, alias=alias)
        #: Trakt API url.
        self.base: str = 'https://api.trakt.tv'
        #: Connection session.
        self.sess: requests.Session = requests.Session()
        #: API token.
        self.token: str | None = None
        #: OAuth redirect URL - device.
        self.redirect_url: str = 'urn:ietf:wg:oauth:2.0:oob'
        #: Locker
        self.auth_lock = RLock()
        #: Auto auth (dialog) if not logged.
        self.auto_auth = auto_auth

    @contextmanager
    def depagination(self, *, scan_limit: int = CONST_REF.trakt.scan.page.limit) -> Generator[DePagination, None, None]:
        """Return single page. Handle Takt pages, read all pages at once and return it as one big page."""
        yield DePagination(self, scan_limit=scan_limit)

    def request(self,
                method: str,
                url: str,
                *,
                data: JsonData | None = None,
                params: KwArgs | None = None,
                page: int | None = None,
                limit: int | None = None,  # works only with `page`
                extended: ExtendedInfo | None = None,
                errors: str = 'ignore',
                login_required: bool = False,
                credentials: TraktCredentials | None = None,
                ) -> requests.Response | None:
        """Send request to trakt.tv and return JSON."""
        if self._FAKE:
            return None
        if credentials is None:
            cred = self.credentials()
        else:
            cred = credentials
        url = urljoin(self.base, url)
        headers = {
            # "Content-Type": "application/json",
            'trakt-api-version': '2',
        }
        headers['trakt-api-key'] = cred.client
        # Default params.
        params = dict(params or ())
        if page is not None:
            if params.get('page') is None:
                params['page'] = page
            if params.get('limit') is None:
                if limit is None:
                    params['limit'] = const.trakt.page.limit
                else:
                    params['limit'] = limit
        if extended:
            if params.get('extended') is None:
                params['extended'] = extended
        # if token expired / close to expire / has no known expiry, try to refresh it before request
        if login_required and cred and (not cred.expires_at or cred.expires_at - utc_timestamp() < const.trakt.connection.close_to_token_expire):
            if self.refresh():
                cred = self.credentials()  # use fresh token on the first attempt (avoid stale-cred 401)
        # For status codes see: https://trakt.docs.apiary.io/#introduction/status-codes
        status_code: int = 0
        resp = None
        # fflog(f'[TRAKT] {url=}, {params=}')
        conn = const.trakt.connection  # one read: one const for the whole request
        for i in range(conn.try_count):
            # get newest credentials (after token refresh too)
            if i:
                cred = self.credentials()
            if login_required and cred:
                headers['Authorization'] = f'bearer {cred.access_token}'
            # make the request
            resp_headers = {}
            try:
                resp = self.sess.request(method, url, json=data, params=params, headers=headers, timeout=conn.timeout)
                status_code = resp.status_code
                resp_headers = {k: v for k, v in resp.headers.items() if 'sort-' in k.lower() or 'x-' in k.lower()}
            except requests.ConnectionError:
                status_code = 0
            except requests.RequestException:
                if errors == 'ignore':
                    status_code = 0
                else:
                    raise
            finally:
                # fflog(f'[TRAKT] {method} {url} ? {params} < {data!r}  (try: {i+1}) → {status_code}\n  {cred}')
                fflog(f'[TRAKT] {method} {url} ? {params} < {data!r}  (try: {i+1}) → {status_code}, '
                      f'{"+" if login_required else "-"}cred:{bool(cred)}')
                fflog(f'[TRAKT]  …  {headers=}')
                fflog(f'[TRAKT]  …  {resp_headers=}')
            # analyze response
            try_delay = 0
            if status_code == 401:  # Unauthorized - OAuth must be provided
                # Handle other codes like 401 here (Token Refresh Logic)
                if login_required:
                    fflog(f'[TRAKT] Unauthorized {status_code} - try refresh or auth')
                    if not self.refresh():
                        break  # no new token, repeating the request makes no sense
            elif login_required and status_code == 403:  # Forbidden - invalid API key or unapproved app
                failed_request(status_code)
                return None
                # if const.trakt.auth.auto and cred:
                #     self.auth()
                # else:
                #     return None
            elif status_code in (0, 429):  # Connection Error | Rate Limit Exceeded
                # See: https://trakt.docs.apiary.io/#introduction/rate-limiting
                fflog(f'[TRAKT] Rate limit exceeded {status_code}')
                after = int(resp_headers.get('Retry-After') or conn.try_delay)
                try_delay = max(conn.try_delay, min(after, 5))
                # TODO, handle response headers
                # X-Ratelimit: {"name":"UNAUTHED_API_GET_LIMIT","period":300,"limit":1000,"remaining":0,
                #               "until":"2020-10-10T00:24:00Z"}
                # Retry-After: 10
            elif status_code == 420:  # If the user's list item limit is exceeded, a 420 HTTP error code is returned
                log('Trakt list limit exceeded')
                break
            elif status_code == 502:  # Gateway Error - trakt.tv is not avaliable
                try_delay = 3 * conn.try_delay
            else:
                # rest: success or error, stop repeating
                break
            if try_delay:
                xsleep(try_delay)

        if resp is None:
            failed_request(status_code)
            return None

        # 200: Success
        # 201: Success - new resource created (POST)
        # 204: Success - no content to return (DELETE)
        if 200 <= status_code <= 299:
            return resp

        if status_code >= 500:  # temporary
            fflog(f'[TRAKT] Temporary error {resp.status_code}')
            failed_request(status_code)
            return None
        if status_code >= 400:  # permanent
            fflog(f'[TRAKT] Error {resp.status_code}\n{resp.text}')
            failed_request(status_code)
            return None

    def get(self, url: str, *, empty: JsonResult | None = None, **kwargs: Unpack[TraktRequestKwargs]) -> JsonResult | None:
        """Send GET request to trakt.tv and return JSON."""
        resp: requests.Response | None = self.request('GET', url, data=None, **kwargs)
        if resp is None:
            return None
        try:
            return resp.json()
        except JSONDecodeError:
            if not resp.content:
                return empty
            fflog.warning(f'GET {url} response is not a JSON: {resp.text[:100]}')
            return None

    def post(self, url: str, data: JsonData, *, empty: JsonData | None = None, **kwargs: Unpack[TraktRequestKwargs]) -> JsonData | None:
        """Send POST request to trakt.tv and return JSON."""
        resp: requests.Response | None = self.request('POST', url, data=data, **kwargs)
        if resp is None:
            return None
        try:
            return resp.json()
        except JSONDecodeError:
            if not resp.content:
                return empty
            fflog.warning(f'POST {url} response is not a JSON: {resp.text[:100]}')
            return None

    def put(self, url: str, data: JsonData, *, empty: JsonData | None = None, **kwargs: Unpack[TraktRequestKwargs]) -> JsonData | None:
        """Send PUT request to trakt.tv and return JSON."""
        resp: requests.Response | None = self.request('PUT', url, data=data, **kwargs)
        if resp is None:
            return None
        try:
            return resp.json()
        except JSONDecodeError:
            if not resp.content:
                return empty
            fflog.warning(f'PUT {url} response is not a JSON: {resp.text[:100]}')
            return None

    def delete(self, url: str, **kwargs: Unpack[TraktRequestKwargs]) -> bool:
        """Send DELETE request to trakt.tv and return True if deleted."""
        resp: requests.Response | None = self.request('DELETE', url, data=None, **kwargs)
        return resp.status_code == 204 if resp else False

    def get_with_pages(self, url: str, **kwargs: Unpack[TraktRequestKwargs]) -> tuple[JsonResult | None, Pages]:
        """Send GET request to trakt.tv and return JSON and pages."""
        if kwargs.get('page') == ALL_PAGES:
            with self.depagination() as trakt:
                resp: requests.Response | None = trakt.request('GET', url, data=None, **kwargs)
        else:
            resp: requests.Response | None = self.request('GET', url, data=None, **kwargs)
        if resp is None:
            return None, Pages.empty()
        return resp.json(), Pages.from_headers(resp.headers)

    def auth(self) -> bool | None:
        """
        Device authentication: True if authorized, False if failed (e.g. expired), None if canceled by the user.
        See: https://trakt.docs.apiary.io/#reference/authentication-devices/exchange-code-for-access_token
        """

        if not self.auto_auth or not self.AUTO_AUTH:
            fflog('[TRAKT] Should authenticate but auto_auth is disabled')
            return False

        fflog('[TRAKT] Going to authentication')
        cred = self.credentials()
        resp = self.sess.post(urljoin(self.base, '/oauth/device/code'), json={'client_id': cred.client},
                              timeout=const.trakt.connection.timeout)
        if resp.status_code != 200:
            fflog(f'[TRAKT][AUTH] DEvice code failed {resp.status_code}: {resp.text}')
            raise TraktAuthError.from_response(resp, f'Can NOT get code for client {cred.client!r}')
        device_code_data: JsonData = resp.json()

        # How often we can ask about user auth.
        interval: int = device_code_data['interval']
        # When (in sec) auth process expires.
        expires_in: int = device_code_data['expires_in']
        # Timestamp of process start.
        start: float = monotonic()
        # Device code (used in oauth).
        device_code: str = device_code_data['device_code']

        # The link with the code (no typing), the code is shown too.
        user_code: str = device_code_data['user_code']
        url: str = device_code_data['verification_url']
        if user_code not in url:
            u = urlparse(url)
            url = urlunparse(u._replace(path=f'{u.path}/{user_code}'))
        # Continue as long as not expire or user authorized or user canceled.
        from ..ff.ui import ui
        from ..kolang import L
        access: JsonData | None = None
        canceled = False
        with ui.auth_session(title=L(30117, '[B]Authorize Trakt[/B]'), url=url, code=user_code, qrcode_scale=const.trakt.auth.qrcode.size) as session:
            try:
                while True:
                    #: Current timestamp.
                    now: float = monotonic()
                    # check in expires...
                    if start + expires_in < now:
                        break
                    # check if the user canceled
                    if canceled := session.is_canceled():
                        break
                    # check if user authorized this device
                    if access := self._get_access_token(device_code, cred):
                        break
                    session.update(100 * (now - start) / expires_in)
                    # sleep given interval
                    xsleep(interval)
            except KeyboardInterrupt:
                print('''\nCancelled. Enter '0'.\n''')
                canceled = True
        if access:
            self.set_access_token(access)
            return True
        return None if canceled else False

    def refresh(self) -> bool:
        """Refresh access token, fall back to device authentication only if `const.trakt.auth.auto` is set."""
        if self.refresh_token():
            return True
        if const.trakt.auth.auto:
            fflog('[TRAKT][AUTH] Force authorize...')
            return bool(self.auth())
        return False

    def refresh_token(self) -> bool:
        """Exchange refresh_token for access_token. Only the service does it, the plugin asks the service (one session owner)."""
        from ..service import SERVICE
        if not SERVICE and self.account is not None:
            from ..service.client import service_client
            refreshed = service_client.account_refresh(self.account.id)
            if refreshed is not None:  # no service, no race – refresh locally
                settings.reset()  # tokens are written by the service process, drop cached settings snapshot
                return refreshed
        return self._refresh_token()

    def _refresh_token(self) -> bool:
        """Exchange refresh_token for access_token (HTTP). Safe for concurrent callers (double-checked under auth_lock)."""
        with self.auth_lock:
            cred = self.credentials()
            # Another thread may have refreshed while we waited for the lock — token is fresh, nothing to do.
            if cred.access_token and cred.expires_at and cred.expires_at - utc_timestamp() >= const.trakt.connection.close_to_token_expire:
                return True
            if not cred.refresh_token:
                return False
            fflog('[TRAKT] Refresh token')
            headers = {
                # "Content-Type": "application/json",
                'trakt-api-key': cred.client,
                'trakt-api-version': '2',
                # 'Authorization': f'bearer {cred.access_token}',
            }
            resp: requests.Response | None = None
            for i in range(2):
                try:
                    resp = self.sess.post(urljoin(self.base, '/oauth/token'), json={
                        'refresh_token': cred.refresh_token,
                        'client_id': cred.client,
                        'client_secret': cred.secret,
                        'redirect_uri': self.redirect_url,
                        'grant_type': 'refresh_token',
                    }, headers=headers, timeout=const.trakt.connection.timeout)
                except requests.RequestException as exc:
                    fflog(f'[TRAKT][AUTH] Refresh token failed: {exc}')
                    return False
                if resp.status_code == 200:
                    self.set_access_token(resp.json())
                    return True
                # 401: If the refresh_token is invalid, you'll get a 401 error.
                # 403:  # Forbidden - invalid API key or unapproved app
                if resp.status_code in (401, 403):
                    # Defensive: another thread may have rotated the token — re-check before giving up.
                    fresh = self.credentials()
                    if fresh.refresh_token and fresh.refresh_token != cred.refresh_token:
                        return True
                    break
                if resp.status_code >= 429:
                    after = int(resp.headers.get('Retry-After') or 0)
                    fflog.debug(f'[TRAKT][AUTH] Refresh token rate limit {resp.status_code}, retry after {after}')
                    if after > 60:
                        break
                    xsleep(after or const.trakt.connection.try_delay)
                elif resp.status_code >= 400:
                    break
            if resp is not None:
                fflog(f'[TRAKT][AUTH] Refresh token failed {resp.status_code}: {resp.text}')
            return False

    def _get_access_token(self, device_code: str, cred: TraktCredentials) -> JsonData | None:
        """Poll for the access_token."""
        # see: https://trakt.docs.apiary.io/#reference/authentication-devices/get-token/poll-for-the-access_token
        resp = self.sess.post(urljoin(self.base, '/oauth/device/token'), json={
            'code': device_code,
            'client_id': cred.client,
            'client_secret': cred.secret,
        }, timeout=const.trakt.connection.timeout)
        if resp.status_code == 200:
            return resp.json()
        if resp.status_code == 400:  # Pending - waiting for the user to authorize your app
            return None
        if resp.status_code == 429:  # Slow Down - your app is polling too quickly
            xsleep(5)
            return None
        # rest - errors
        fflog(f'[TRAKT][AUTH] Pull access token failed {resp.status_code}: {resp.text}')
        raise TraktAuthError.from_response(resp, 'Can not pull access token')

    def revoke_session(self) -> bool:
        """Revoke current sesion."""
        cred = self.credentials()
        if not cred:
            return True  # no session, nothing to do
        self.remove_access_token()
        self.post('oauth/revoke', credentials=cred, login_required=True, empty={}, data={
            'token': cred.access_token,
            'client_id': cred.client,
            'client_secret': cred.secret,
        })
        return True

    def get_video_ids(self, kwargs: KwArgs) -> Ids:
        """
        Get trakt.tv `ids` dict from arguments.

        Support for "trakt", "imdb", "tmdb", "slug" trakt.tv ID.
        Support for "ffid" video ID, VideoIds or int got from VideoIds.make_video_id.
        """
        ffid = kwargs.pop('ffid', None)
        if isinstance(ffid, int):
            ffid = VideoIds.from_ffid(ffid)
        if ffid:
            kwargs = {**ffid.ids(), **kwargs}
        return {k: v for k in ('trakt', 'imdb', 'tmdb', 'slug') for v in (kwargs.pop(k, None),) if v}

    def scrobble(self,
                 action: ScrobbleAction,
                 type: PlayContentType,
                 progress: float = 0.0,
                 *,
                 errors: str = 'ignore',
                 ids: Ids,
                 # **kwargs,
                 ) -> bool:
        """Scrobble what a user is watching in a media center. For ID in kwargs see get_video_ids()."""
        # ids = self.get_video_ids(kwargs)
        # if kwargs:
        #     raise TypeError(f'TraktApi.scrobble_*() got an unexpected keyword arguments: {",".join(kwargs)}')
        if action not in get_typing_args(ScrobbleAction):
            raise ValueError(f'TraktApi.scrobble_*() got incorrect action {action!r}')
        if type not in get_typing_args(PlayContentType):
            raise ValueError(f'TraktApi.scrobble_*() got incorrect type {type!r}')
        data = {
            'progress': float(progress),
            type: {'ids': ids},
            # 'app_version': ...
        }
        fflog(f'[TRAKT][SCROBBLE] post /scrobble/{action}, data={data}')
        data = self.post(f'scrobble/{action}', data=data, errors=errors, login_required=True)
        return bool(data)

    def scrobble_start(self, type: PlayContentType, progress: float = 0.0, **kwargs) -> bool:
        """Start watching in a media center. For ID in kwargs see get_video_ids()."""
        return self.scrobble('start', type=type, progress=progress, **kwargs)

    def scrobble_pause(self, type: PlayContentType, progress: float, **kwargs) -> bool:
        """Pause watching in a media center. For ID in kwargs see get_video_ids()."""
        return self.scrobble('pause', type=type, progress=progress, **kwargs)

    def scrobble_stop(self, type: PlayContentType, progress: float, **kwargs) -> bool:
        """Stop or finish watching in a media center. For ID in kwargs see get_video_ids()."""
        return self.scrobble('stop', type=type, progress=progress, **kwargs)

    def _scrobble_ref(self,
                      action: ScrobbleAction,
                      ref: MediaRef,
                      progress: float = 0.0,
                      *,
                      errors: str = 'ignore',
                      ) -> bool:
        """Scrobble what a user is watching in a media center."""
        if action not in get_typing_args(ScrobbleAction):
            raise ValueError(f'TraktApi.scrobble_*() got incorrect action {action!r}')
        ids = self.get_video_ids({'ffid': ref.ffid})
        if ref.type in get_typing_args(PlayContentType):
            data = {
                'progress': float(progress),
                ref.type: {'ids': ids},
            }
        elif ref.is_episode:
            data = {
                'progress': float(progress),
                'show': {'ids': ids},
                'episode': {'season': ref.season, 'number': ref.episode},
            }
        else:
            fflog.error(f'[TRAKT][SCROBBLE] ERROR, nut supported type {ref}')
            return False
        fflog(f'[TRAKT][SCROBBLE] post /scrobble/{action}, data={data}')
        return bool(self.post(f'scrobble/{action}', data=data, errors=errors, login_required=True))

    def scrobble_ref(self, action: ScrobbleAction, ref: MediaRef, progress: float = 0.0) -> bool:
        """Scrobble what a user is watching in a media center."""
        return self._scrobble_ref(action=action, ref=ref, progress=progress)

    def get_watching(self, user: str = 'me') -> JsonData | None:
        """Get what a user is currently watching."""
        resp = self.get(f'users/{user}/watching', errors='ignore', login_required=True)
        if isinstance(resp, Mapping):
            return resp
        return None

    def get_playblack_list(self, *, extended: ExtendedInfo = '', type: PlayContentType | None = None,
                           errors: str = 'ignore') -> Sequence[JsonData] | None:
        """Get playback progress. Returns None on failure."""
        if type is None or type in get_typing_args(PlayContentType):
            ctype = f'{type}s' if type else ''
            resp = self.get(f'sync/playback/{ctype}', errors=errors, extended=extended, login_required=True)
        else:
            raise ValueError(f'TraktApi.get_playblack_list() got incorrect type {type!r}')
        return resp if isinstance(resp, Sequence) else None

    def remove_playback(self, playback_id: int, *, errors: str = 'ignore') -> bool:
        """Remove a playback item (progress) by trakt playback item ID."""
        return self.delete(f'sync/playback/{playback_id}', errors=errors, login_required=True)

    def get_watched_list(self,
                         type: WatchContentType,
                         *,
                         extended: ExtendedInfo = '',
                         errors: str = 'ignore',
                         page: int | None = None,
                         ) -> Sequence[JsonData] | None:
        """Get watched list. Returns None on failure."""
        if type not in get_typing_args(WatchContentType):
            raise ValueError(f'TraktApi.get_watched_list() got incorrect type {type!r}')
        if page is None:
            page = ALL_PAGES
        if page == ALL_PAGES:
            with self.depagination() as trakt:
                resp = trakt.get(f'sync/watched/{type}', errors=errors, extended=extended, login_required=True)
        else:
            resp = self.get(f'sync/watched/{type}', errors=errors, extended=extended, login_required=True, page=page)
        return resp if isinstance(resp, Sequence) else None

    def get_history_list(self, type: HistoryContentType, *, errors: str = 'ignore') -> Sequence[JsonData]:
        """Get history."""
        if type not in get_typing_args(HistoryContentType):
            raise ValueError(f'TraktApi.get_history_list() got incorrect type {type!r}')
        with self.depagination() as trakt:
            data = trakt.get(f'sync/history/{type}', errors=errors, login_required=True)
        if isinstance(data, Sequence):
            return data
        return []

    @staticmethod
    def _history_item(type: HistoryContentType, ids: Ids, season: int | None = None, episode: int | None = None,
                      watched_at: float | None = None) -> tuple[str, JsonData]:
        """Return the body key and the item of a history write (`watched_at` - utc-timestamp of the play, at the innermost object)."""
        if type and not type.endswith('s'):
            type = cast(HistoryContentType, f'{type}s')
        if type not in get_typing_args(HistoryContentType):
            raise ValueError(f'TraktApi.*_history_item() got incorrect type {type!r}')
        if not ids:
            raise ValueError('TraktApi.*_history_item() no ids.')
        item: dict[str, Any] = {'ids': {k: v for k, v in ids.items() if k and v}}
        if type in ('shows', 'seasons', 'episodes') and season is not None:
            item['seasons'] = [{'number': int(season)}]
            if type in ('shows', 'episodes') and episode is not None:
                item['seasons'][0]['episodes'] = [{'number': int(episode)}]
            type = 'shows'
        if watched_at:  # the time goes to the innermost object (the episode, the season, the media)
            inner = item['seasons'][0] if 'seasons' in item else item
            inner = inner['episodes'][0] if 'episodes' in inner else inner
            inner['watched_at'] = utc_2_iso(watched_at)
        return type, item

    def _op_history_item(self, url: str, type: HistoryContentType, ids: Ids,
                         season: int | None = None, episode: int | None = None, watched_at: float | None = None) -> JsonData | None:
        """Operate (add/remove) history item, +/- watched play_count; `watched_at` (utc-timestamp) - the time of the play (add)."""
        key, item = self._history_item(type, ids, season=season, episode=episode, watched_at=watched_at)
        return self.post(url, data={key: [item]}, login_required=True)

    def _op_history_refs(self, url: str, items: Iterable[tuple[MediaRef, float | None]]) -> JsonData | None:
        """Operate (add/remove) history of the media `(ref, watched_at)` in one write, None if no media has IDs (nothing sent)."""
        body: dict[str, list[JsonData]] = {}
        for ref, watched_at in items:
            mtype, ids = self._ref_to_trakt_hist(ref)
            if mtype and ids:
                key, item = self._history_item(mtype, ids, season=ref.season, episode=ref.episode, watched_at=watched_at)
                body.setdefault(key, []).append(item)
        return self.post(url, data=body, login_required=True) if body else None

    def add_history_item(self, type: HistoryContentType, ids: Ids,
                         season: int | None = None, episode: int | None = None) -> JsonData | None:
        """Add history item, increments watched play_count."""
        return self._op_history_item('sync/history/', type, ids, season=season, episode=episode)

    def remove_history_item(self, type: HistoryContentType, ids: Ids, *,
                            season: int | None = None, episode: int | None = None) -> JsonData | None:
        """Remove history item, decrements watched play_count."""
        return self._op_history_item('sync/history/remove', type, ids, season=season, episode=episode)

    def add_history_refs(self, items: Sequence[tuple[MediaRef, float | None]]) -> bool:
        """
        Add plays of the media `(ref, watched_at)` (default: now) in one write; the same play time again adds nothing.
        Return True if every media was found.
        """
        return all_found(self._op_history_refs('sync/history/', items))

    def add_history_ref(self, ref: MediaRef, *, watched_at: float | None = None) -> bool:
        """Add history item, increments watched play_count, see `add_history_refs()`."""
        return self.add_history_refs([(ref, watched_at)])

    def remove_history_refs(self, refs: Sequence[MediaRef]) -> bool:
        """Remove the history of the media (all plays) in one write. Return True if every media was found."""
        return all_found(self._op_history_refs('sync/history/remove', ((ref, None) for ref in refs)))

    def remove_history_ref(self, ref: MediaRef) -> bool:
        """Remove history item, reset watched play_count, see `remove_history_refs()`."""
        return self.remove_history_refs([ref])

    def _ref_to_trakt_hist(self, ref: MediaRef) -> tuple[HistoryContentType | None, Ids]:
        ids = cast(Ids, ref.video_ids.ids())  # it's OK, the same keys
        if ref.type in ('movie', 'show'):  # also seasons and episodes
            mtype = f'{ref.real_type}s'  # hack
            assert mtype in ('movies', 'shows', 'seasons', 'episodes')
            return mtype, ids
        fflog(f'WARNING: wrong ref {ref!r}', stack_depth=2)
        return None, ids

    def media(self, type: MainMediaType, id: str | int, *, errors: str = 'ignore') -> JsonData | None:
        """Get media item by type and ID."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TraktApi.media() got incorrect type {type!r}')
        mtype = self._main2type.get(type)
        data = self.get(f'{mtype}/{id}', errors=errors, login_required=False)
        if isinstance(data, Mapping):
            return data
        return None

    def id_lookup(self,
                  id: str | int,
                  *,
                  service: LookupService,
                  type: MediaType | None = None,
                  errors: str = 'ignore',
                  ) -> MultiId:
        if service not in get_typing_args(LookupService):
            raise ValueError(f'TraktApi.id_lookup() got incorrect service {service!r}')
        # if type == 'season':
        #     raise ValueError('Trakt.tv does not implement SEASON id lookup')
        params: dict[str, str] = {}
        if type:
            params['type'] = type
        data = self.get(f'search/{service}/{id}', params=params, errors=errors, login_required=False)
        if not data or isinstance(data, Mapping):
            return MultiId(type='', ref=None, vid=VideoIds(), show=None)

        item: JsonData = data[0]
        mtype: str = item['type']
        itself = item[mtype]
        vid = VideoIds.from_ids(itself['ids'])
        title = itself.get('title')
        if mtype == 'movie':
            ref = MediaRef.movie(vid.ffid)
            return MultiId(type=mtype, ref=ref, vid=vid, show=None, title=title, year=itself.get('year'), trakt_slug=itself['ids'].get('slug'))
        show_item = item['show']
        if mtype == 'show':
            show_vid = vid
        else:
            show_vid = VideoIds.from_ids(show_item['ids'])
        ref = MediaRef.tvshow(show_vid.ffid, itself.get('season'), itself.get('number'))
        show = MultiShowId(vid=show_vid, title=show_item.get('title'))
        return MultiId(type=mtype, ref=ref, vid=vid, show=show, title=title, year=show_item.get('year'), trakt_slug=show_item['ids'].get('slug'))

    def _get_ref(self, it: JsonData, ref_type: RefType | None = None) -> Iterator[MediaRef]:
        if 'movie' in it:
            yield VideoIds.from_ids(it['movie']['ids']).ref('movie')
        elif 'episode' in it:
            vid = VideoIds.from_ids(it['show']['ids'])
            d = it['episode']
            yield MediaRef('show', vid.ffid, season=d['season'], episode=d['number'])
        elif 'season' in it:
            vid = VideoIds.from_ids(it['show']['ids'])
            d = it['season']
            yield MediaRef('show', vid.ffid, season=d['number'])
        elif 'show' in it:
            yield VideoIds.from_ids(it['show']['ids']).ref('show')
        elif 'person' in it:
            yield VideoIds.from_ids(it['person']['ids']).ref('person')
        elif 'list' in it:
            yield VideoIds.from_ids(it['list']['ids']).ref('list')
        elif ref_type is not None:
            iid = it.get('ids', {}).get('trakt')
            if iid:
                yield MediaRef(ref_type, iid)

    def list_refs(self, items: Iterable[JsonData]) -> list[MediaRef]:
        """Get refs from media item list."""
        return list(ref for it in items for ref in self._get_ref(it))

    def _item_list(self,
                   data: JsonResult | None,
                   *,
                   pages: Pages | None,
                   ref_type: RefType | None = None,
                   sort: SortType | None = None,  # sort by X-Sort-By and X-Sort-How, has no sense with real pagination
                   ) -> ItemList[FFItem]:
        """Return item list with pagination."""

        def get_ff(it: JsonData) -> Iterator[FFItem]:
            for ref in self._get_ref(it, ref_type=ref_type):  # only single ref or None
                ff = FFItem(ref)
                vtag = ff.vtag
                info = it.get(ref.real_type, {})
                ff.label = ff.title = info.get('title') or info.get('name') or it.get('name') or ''
                year = info.get('year')
                if year:
                    vtag.setYear(int(year))
                ids = info.get('ids', {})
                for key in ('imdb', 'trakt'):
                    val = ids.get(key)
                    if val:
                        ff.vtag.setUniqueID(str(val), key)
                ffid = VideoIds.from_ids(ids).ffid
                if ffid and ffid in VideoIds.KODI:
                    ff.vtag.setDbId(ffid)  # Kodi DBID
                vtag.setPlot(info.get('description') or it.get('description') or '')
                if last_watched_at := it.get('last_watched_at', it.get('watched_at')):
                    ff.temp.watched = date = fromisoformat(last_watched_at)
                    vtag.setLastPlayed(str(date.astimezone().replace(tzinfo=None)))
                else:
                    ff.temp.watched = None
                if rating := it.get('rating'):
                    ff.setProperty('user_rating', str(rating))
                    ff.setProperty('trakt.user_rating', str(rating))
                    # vtag.setUserRating(int(rating))
                if ref.is_show and (seasons := it.get('seasons')):
                    try:
                        episodes = tuple(MediaProgressItem(MediaRef(ref.type, ref.ffid, sz['number'], ep['number']),
                                                           play_count=ep['plays'], last_watched_at=ep['last_watched_at'])
                                         for sz in seasons for ep in sz.get('episodes') or ())
                    except KeyError:
                        pass  # no progreass info, just skip it
                    else:
                        ff.progress = MediaProgress(ref, bar=episodes)
                # item_count = it.get('item_count')
                # if item_count:
                #     ff.children_count = item_count
                if show := it.get('show'):
                    if title := show.get('title'):
                        ff.vtag.setTvShowTitle(title)
                        ff.vtag.setEnglishTvShowTitle(title)
                        if year := show.get('year'):
                            ff.setProperty('show.year', str(year))
                if ref.type == 'list':
                    user_info = it.get('list', {}).get('user', {})
                    ff.role = user_info.get('name') or ''
                    vtag.setUniqueID(info.get('ids', {}).get('slug') or '', 'trakt.list')
                    vtag.setUniqueID(user_info.get('ids', {}).get('slug') or '', 'trakt.user')
                ff.source_data = it
                ff.list_entry = self._list_entry(it)
                yield ff

        # if type is not None and isinstance(data, Sequence):
        if data is None or isinstance(data, Mapping):
            return ItemList.empty()
        if pages is None:
            pages = Pages.empty()
        # sort by trakt user preferences (X-Sort-By and X-Sort-How)
        items: Sequence[JsonData] = self._sort_items_with_pages(data, sort=sort, pages=pages)
        # prase items and generate FFItems
        return pages.list(ff for it in items for ff in get_ff(it))

    @staticmethod
    def _list_entry(it: JsonData) -> ListEntry | None:
        """Return the data of the item in its list (watchlist, favorites, collection, a list), None if none (e.g. the history)."""
        return ListEntry.new(added_at=it.get('listed_at') or it.get('collected_at') or it.get('last_collected_at'), rank=it.get('rank'),
                             note=it.get('notes'))

    def _sort_items_with_pages(self, items: Sequence[JsonData], *, sort: SortType | None, pages: Pages | None) -> Sequence[JsonData]:
        """Item sorting using pages with X-Sort-By and X-Sort-How, ex. 'added.asc'."""
        if pages is None:
            return self._sort_items(items, sort=sort)
        return self._sort_items(items, sort=sort, trakt_sort=pages.sort, response_sort=pages.response_sort)

    def _sort_items(self,
                    # items to sort
                    items: Sequence[JsonData],
                    *,
                    # force sort (set by FF)
                    sort: SortType | None,
                    # trakt user list sort
                    trakt_sort: SortType = '',
                    # api reponse applied sort
                    response_sort: SortType = '',
                    ) -> Sequence[JsonData]:
        """Item sorting using X-Sort-By and X-Sort-How, ex. 'added.asc'."""
        # sort by trakt user preferences (X-Sort-By and X-Sort-How)
        if trakt_sort and sort in ('', 'trakt'):
            sort = trakt_sort
        # need to sort?
        if sort and sort != response_sort:
            from random import randint
            import re

            def define_exctract(default: Any, key: str, tv: Any = '', *, rx: re.Pattern | None = None) -> Any:
                def extract(it: JsonData):
                    value = it.get(key, default)
                    if obj := it.get('movie'):
                        value = obj.get(key, default)
                    else:
                        tv_key = tv or key
                        for name in ('episode', 'show'):
                            if obj := it.get(name):
                                value = obj.get(tv_key, default)
                                break
                    if rx:
                        value = rx.sub('', value)
                    return value
                return extract

            remove_prefix = re.compile(r'^(?:A|An|The)\s+', flags=re.IGNORECASE)
            sorting: dict[SortBy, Callable[[JsonData], Any]] = {
                'added':      lambda it: it.get('listed_at', ''),                                  # noqa: E272
                'collected':  lambda it: it.get('last_collected_at', it.get('collected_at', '')),  # noqa: E272
                'rank':       lambda it: it.get('rank', ''),                                       # noqa: E272
                'released':   define_exctract('', 'released', 'first_aired'),                      # noqa: E272
                'title':      define_exctract('', 'title', rx=remove_prefix),                      # noqa: E272
                'runtime':    define_exctract(0, 'runtime'),                                       # noqa: E272
                'votes':      define_exctract(0, 'votes'),                                         # noqa: E272
                'popularity': define_exctract(.0, 'rating'),                                       # noqa: E272   (it's not real popularity)
                'random':     lambda _: randint(1, 1_000_000),                                     # noqa: E272
                # rest are not supported now
            }

            by: SortBy
            by, _, order = sort.rpartition('.')  # type: ignore
            if key := sorting.get(cast(SortBy, by)):
                fflog(f'[TRAKT] sorting: {sort}')
                return sorted(items, key=key, reverse=(order == 'desc') ^ const.indexer.trakt.sort.reverse_order.get(by, False))

        return items

    def _cached_get(self, name: str, url: str, *, bucket: str, extended: ExtendedInfo | None = None) -> tuple[JsonResult | None, Pages]:
        """
        GET a whole list of the account (`users/me/...`, `sync/...`) through the list cache (`lib.ff.listcache`).

        Return the raw items and the list sort (other headers of a whole list make no sense). A client without an
        account (no user) gets the list directly.
        """
        def fetch() -> FetchedList | None:
            data, pages = self.get_with_pages(url, page=ALL_PAGES, extended=extended, login_required=True)
            if not isinstance(data, Sequence):
                return None
            sort = {'sort': pages.sort, 'response_sort': pages.response_sort}
            return FetchedList([(next(self._get_ref(it), None), it) for it in data], meta=sort)

        if self.account is None:
            fetched = fetch()
            return (None, Pages.empty()) if fetched is None else ([it for _, it in fetched.items], Pages(0, **fetched.meta))
        stored = cached_list(self.account.id, name, fetch, params=list_params(url=url, extended=extended), bucket=bucket)
        if stored is None:
            return None, Pages.empty()
        meta = stored.row.meta
        return stored.items, Pages(0, sort=meta.get('sort', ''), response_sort=meta.get('response_sort', ''))

    def _general_get(self, url: str, *, kind: str, page: int | None = None, params: KwArgs | None = None) -> tuple[JsonResult | None, Pages]:
        """
        GET a general list (no account, the scope is the type) through the list cache (`lib.ff.listcache`, the TTL of the
        `kind`): a page of the service, or the whole response if `page` is None. Return the raw items and the pages.
        """
        def fetch() -> FetchedList | None:
            data, pages = self.get_with_pages(url, page=page, params=params, login_required=False)
            if not isinstance(data, Sequence):
                return None
            return FetchedList([(None, it) for it in data], meta=asdict(pages))

        stored = cached_list('trakt', url, fetch, params=list_params(**(params or {})), kind=kind, page=page)
        if stored is None:
            return None, Pages.empty()
        return list(stored.items), Pages(**stored.row.meta)

    def _changed(self, name: str) -> None:
        """Mark the cached list `name` (with its sub-lists) of the account as changed (an own change)."""
        if self.account is not None:
            mark_stale(self.account.id, name)

    def general_list(self,
                     type: MainMediaType,
                     list: ListName,
                     period: int | Literal['weekly'] | None = None,
                     *,
                     page: int = 1,
                     **kwargs: Unpack[TraktFilters]
                     ) -> ItemList:
        """Get general list like popular or trading."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TraktApi.list() got incorrect content type {type!r}')
        if list not in get_typing_args(ListName):
            raise ValueError(f'TraktApi.list() got incorrect list name {list!r}')
        ctype = self._main2type[type]
        url = f'{ctype}/{list}'
        if period:
            if list not in get_typing_args(ListWithPeriod):
                raise ValueError(f'TraktApi.list(): list {list!r} could na be used period {period!r}')
            url = f'{url}/{period}'
        data, pages = self._general_get(url, kind='trending', page=page, params=dict(kwargs))
        if isinstance(data, Sequence):
            if list == 'popular':  # Special case! Only "popular" has item directly (w/o type objects).
                data = [{type: it} for it in data]
            return self._item_list(data, pages=pages)
        return ItemList.empty()

    def box_office(self) -> ItemList[FFItem]:
        """Returns the top 10 grossing movies in the U.S. box office last weekend."""
        data, _ = self._general_get('movies/boxoffice', kind='trending')
        if isinstance(data, Sequence):
            return self._item_list(data, pages=Pages.single(len(data)))
        return ItemList.empty()

    def user_general_lists(self, list: UserGeneralListType, *, page: int = 1) -> ItemList[FFItem]:
        """Returns user lists."""
        data, pages = self._general_get(f'lists/{list}', kind='lists', page=page)
        if isinstance(data, Sequence):
            return self._item_list(data, pages=pages, ref_type='list')
        return ItemList.empty()

    def user_profile(self, user: str = 'me', *, credentials: TraktCredentials | None = None) -> TraktUserProfile | None:
        """Returns user profile."""
        data = self.get(f'users/{user}', login_required=True, credentials=credentials)
        if isinstance(data, Mapping):
            data['id'] = data['ids']['slug']
            if avatar := data.get('images', {}).get('avatar'):
                data['avatar'] = avatar
            args = {f.name for f in fields(TraktUserProfile)}
            return TraktUserProfile(**{k: v for k, v in data.items() if k in args})
        return None

    def user_lists(self, user: str = 'me') -> ItemList[FFItem]:
        """Returns user lists (of the account: from the list cache)."""
        if user == 'me':
            data, _ = self._cached_get('user', 'users/me/lists', bucket='lists.user')
        else:
            data, _ = self._general_get(f'users/{user}/lists', kind='lists')  # public lists of another user
        if isinstance(data, Sequence):
            return self._item_list(data, pages=Pages.single(len(data)), ref_type='list')
        return ItemList.empty()

    def the_list(self,
                 list_id: int | str,
                 *,
                 page: int = 1,
                 media_type: MediaOrPersonType | None = None,
                 ) -> ItemList[FFItem]:
        """Returns user lists by ID only."""
        ctype: str = media_type or ''  # list items filter by a singular type (`persons` is unknown there: all items)
        data, pages = self._general_get(f'lists/{list_id}/items/{ctype}', kind='lists', page=page)
        if isinstance(data, Sequence):
            return self._item_list(data, pages=pages)
        return ItemList.empty()

    def user_list_items(self,
                        list_id: int | str,
                        user: str = 'me',
                        *,
                        page: int | None = None,
                        media_type: MediaOrPersonType | None = None,
                        sort: SortType | None = None,  # sort by X-Sort-By and X-Sort-How, has no sense if `page` is used
                        ) -> ItemList[FFItem]:
        """Returns user (private too) lists."""
        ctype: str = media_type or ''  # list items filter by a singular type (`persons` is unknown there: all items)
        extended = 'full' if sort is not None else None  # more datails are needed for sorting
        url = f'users/{user}/lists/{list_id}/items/{ctype}'
        if user == 'me' and page in (None, ALL_PAGES):  # the whole list (the library asks for all pages)
            data, pages = self._cached_get(f'user/{list_id}', url, bucket='lists.user', extended=extended)
        elif user != 'me' and page != ALL_PAGES:  # a public list of another user: a general list
            data, pages = self._general_get(url, kind='lists', page=page, params={'extended': extended})
        else:
            data, pages = self.get_with_pages(url, page=page, extended=extended, login_required=(user == 'me'))
        # with open('/tmp/disney.json', 'w') as f:  # XXX
        #     import json
        #     json.dump(data, f, indent=2)
        if isinstance(data, Sequence):
            return self._item_list(data, pages=pages, sort=sort)
        return ItemList.empty()

    def user_generic_list(self,
                          list_type: UserListType,
                          user: str = 'me',
                          *,
                          media_type: RefType | None = None,
                          page: int = ALL_PAGES,
                          sort: SortType | None = None,  # sort by X-Sort-By and X-Sort-How, has no sense if `page` is used
                          limit: int | None = None,
                          noseasons: bool = False,
                          # Hide shows with 100%
                          hide_100: bool = False,
                          ) -> ItemList[FFItem]:
        """Returns generic user list items (likes, watchlist, favorites, history, watched)."""
        # Likes: Comments has no media attached, we have to use "https://api.trakt.tv/comments/{id}/item"
        if media_type is None:
            media_type = self._def_list_media.get(list_type, '')
        path = ['users', user, list_type]
        if mtype := self._ref2type.get(media_type, ''):
            path.append(mtype)
        extended = None
        if sort is not None or hide_100:
            extended = 'progress'
        elif noseasons:
            extended = 'noseasons'
        login_required = user == 'me'
        if user == 'me' and list_type in self._CACHED_GENERIC_LISTS and not hide_100:
            # the whole list from the list cache, sorted whole, the page is cut here
            data, pages = self._cached_get(list_type, '/'.join(path), bucket=f'lists.{list_type}', extended=extended)
            if not isinstance(data, Sequence):
                return ItemList.empty()
            data = self._sort_items_with_pages(data, sort=sort, pages=pages)
            if page == ALL_PAGES:
                return self._item_list(data, pages=Pages.single(len(data)))
            size = limit or const.trakt.page.limit
            pages = Pages(page, page_size=size, page_count=(len(data) + size - 1) // size, item_count=len(data))
            return self._item_list(data[(page - 1) * size:page * size], pages=pages)
        # `page` (and optional `limit`) must go as top-level kwargs, not nested inside
        # `params` — get_with_pages() only detects ALL_PAGES via kwargs.get('page'),
        # and forwards page/limit to request()/DePagination.request() itself.
        data, pages = self.get_with_pages('/'.join(path), page=page, limit=limit, extended=extended, login_required=login_required)
        if isinstance(data, Sequence):
            if media_type == 'show' and hide_100:
                def in_progress(it: JsonData) -> bool:
                    if count := it.get('show', {}).get('aired_episodes'):
                        return 0 <= sum(1 for sz in it.get('seasons', []) for ep in sz.get('episodes', []) if ep.get('plays')) < count
                    return False
                data = [it for it in data if in_progress(it)]
            return self._item_list(data, pages=pages, sort=sort)
        return ItemList.empty()

    def _proc_list_items(self,
                         items: Iterable[FFRef],
                         *,
                         path: str,
                         remove: bool,
                         people_enabled: bool,
                         show_only: bool = False,  # only shows, no seasons or episodes
                         extra: Iterable[JsonData] = (),  # extra data for each item to set in trakt (like rating, ...)
                         ) -> tuple[bool, int]:
        """Proceed (add, remove) trakt user list items. Return True on success and number of proceeded items. Notes are not supported."""

        def ex_iter(items: Iterable[FFRef]) -> Iterable[tuple[FFRef, JsonData]]:
            xit = iter(extra)
            for it in items:
                yield it, next(xit, {})

        if not hasattr(items, '__len__'):
            items = tuple(items)
        if not hasattr(extra, '__len__'):
            extra = tuple(extra)
        if not items:
            return True, 0
        movies = tuple({'ids': ref.video_ids.ids(), **ex} for item, ex in ex_iter(items) if (ref := item.ref).is_movie)
        if show_only:
            shows = tuple({'ids': ref.video_ids.ids(), **ex} for item, ex in ex_iter(items) if (ref := item.ref).is_show)
        else:
            shows = tuple(chain(
                ({'ids': ref.video_ids.ids(), **ex}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_show),
                ({'ids': ref.video_ids.ids(), 'seasons': [{'number': ref.season, **ex}]}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_season),
                ({'ids': ref.video_ids.ids(), 'seasons': [{'number': ref.season, 'episodes': [{'number': ref.episode, **ex}]}]}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_episode),  # type: ignore[reportArgumentType]
            ))
        if people_enabled:
            people = tuple({'ids': ref.video_ids.ids(), **ex} for item, ex in ex_iter(items) if (ref := item.ref).type == 'person')
        else:
            people = ()
        if not movies and not shows and not people:
            return True, 0
        items_to_send = {
            'movies': movies,
            'shows': shows,
        }
        if people_enabled:
            items_to_send['people'] = people
        data = self.post(path, data=items_to_send, login_required=True)
        res_name = 'deleted' if remove else 'added'
        if isinstance(data, Mapping):
            added = sum(v for v in data.get(res_name, {}).values())
            # existing = sum(v for v in data.get('existing', {}).values())
            not_found = sum(len(v) for v in data.get('not_found', {}).values())
            return added > 0 and not_found == 0, added
        return False, 0

    def add_to_user_list(self,
                         list_id: int | str,
                         items: Iterable[FFRef],
                         *,
                         user: str = 'me',
                         ) -> tuple[bool, int]:
        """Add items to trakt user list. Return True on success and number of proceeded items. Notes are not supported."""
        try:
            return self._proc_list_items(items, path=f'users/{user}/lists/{list_id}/items', remove=False, people_enabled=True)
        finally:
            self._changed('user')  # after the change: a read meanwhile must not store the old list

    def remove_from_user_list(self,
                              list_id: int | str,
                              items: Iterable[FFRef],
                              *,
                              user: str = 'me',
                              ) -> tuple[bool, int]:
        """Remove items from trakt user list. Return True on success and number of proceeded items."""
        try:
            return self._proc_list_items(items, path=f'users/{user}/lists/{list_id}/items/remove', remove=True, people_enabled=True)
        finally:
            self._changed('user')  # after the change: a read meanwhile must not store the old list

    def add_to_generic_list(self,
                            list_type: UserListPostType,
                            items: Iterable[FFRef],
                            ) -> tuple[bool, int]:
        """Add items to trakt generic list (favorites, watchlist, collection, ...). Return True on success and number of proceeded items."""
        try:
            return self._proc_list_items(items, path=f'sync/{list_type}', remove=False, people_enabled=False, show_only=list_type == 'favorites')
        finally:
            self._changed(list_type)  # after the change: a read meanwhile must not store the old list

    def remove_from_generic_list(self,
                                 list_type: UserListPostType,
                                 items: Iterable[FFRef],
                                 ) -> tuple[bool, int]:
        """Remove items from trakt generic list (favorites, watchlist, collection, ...). Return True on success and number of proceeded items."""
        try:
            return self._proc_list_items(items, path=f'sync/{list_type}/remove', remove=True, people_enabled=False, show_only=list_type == 'favorites')
        finally:
            self._changed(list_type)  # after the change: a read meanwhile must not store the old list

    def create_user_list(self,
                         name: str,
                         *,
                         user: str = 'me',
                         display_numbers: bool = False,
                         allow_comments: bool = True,
                         privacy: Literal['private', 'link', 'friends', 'public'] = 'private',
                         description: str = '',
                         ) -> int | None:
        """Create a new user list and return its ID."""
        data = self.post(f'users/{user}/lists', login_required=True, data={
            'name': name,
            'description': description,
            'privacy': privacy,
            'display_numbers': display_numbers,
            'allow_comments': allow_comments,
        })
        self._changed('user')
        return data['ids']['trakt'] if isinstance(data, Mapping) and 'ids' in data else None

    def delete_user_list(self,
                         list_id: int | str,
                         *,
                         user: str = 'me',
                         ) -> bool:
        """Delete the new user list."""
        data = self.delete(f'users/{user}/lists/{list_id}', login_required=True)
        self._changed('user')
        return data is not False

    def _single_join(self,
                     call: Callable[..., Sequence[JsonData]],
                     args: Any,
                     *,
                     chunk: int = 0,
                     sort: SortType | None = None,
                     ref_type: RefType | None = None,
                     ) -> ItemList[FFItem]:
        if isinstance(args, str):
            args = args.split(',')
        if not args:
            return ItemList.empty()
        if len(args) == 1:
            items = call(args[0])
        else:
            with ThreadPoolExecutor() as pool:
                datas = pool.map(call, args)
            items = tuple(join_items(*datas, zip_chunk=chunk))
        items = self._sort_items(items, sort=sort)
        items = self._item_list(items, pages=Pages.single(len(items)), ref_type=ref_type)
        return ItemList.single(items)

    def user_collection(self,
                        type: MainMediaType | MainMediaTypeList | Sequence[MainMediaType],
                        user: str = 'me',
                        *,
                        chunk: int = 0,
                        sort: SortType | None = None,
                        ) -> ItemList[FFItem]:
        """Return user collection list items."""
        # def get(mtype: MainMediaType, limit: int = 0) -> list[FFItem]:
        def get(mtype: MainMediaType) -> Sequence[JsonData]:
            if mtype not in get_typing_args(MainMediaType):
                raise ValueError(f'TraktApi got incorrect content type {mtype!r}')
            ctype = self._main2type[mtype]
            extended = None if (sort in ('', 'trakt')) else 'full'  # more datails are needed for sorting
            # trakt paginates large collections (100 items/page) - fetch all pages, not just the first one
            data: JsonResult | None
            url = f'users/{user}/collection/{ctype}'
            if user == 'me':
                data, _pages = self._cached_get('collection', url, bucket='lists.collection', extended=extended)
            else:
                data, _pages = self.get_with_pages(url, page=ALL_PAGES, login_required=False, extended=extended)
            if isinstance(data, Sequence):
                return data
            return []

        return self._single_join(get, type, chunk=chunk, sort=sort)

    def recommendations(self,
                        type: MainMediaType | MainMediaTypeList | Sequence[MainMediaType],
                        *,
                        limit: int | None = None,
                        chunk: int = 0,
                        ) -> ItemList[FFItem]:
        """Return social recommendations. No media means mix movies and shows."""
        def get(mtype: MainMediaType) -> list[JsonData]:
            if mtype not in get_typing_args(MainMediaType):
                raise ValueError(f'TraktApi got incorrect content type {mtype!r}')
            ctype = self._main2type[mtype]
            itype = self._ref2item[mtype]
            params = {}
            if limit:
                params['limit'] = limit
            data = self.get(f'recommendations/{ctype}', params=params, login_required=True)
            if isinstance(data, Sequence):
                return [{itype: it} for it in data]
                return self._item_list(data, pages=Pages.single(len(data)), ref_type=mtype)
            return []

        return self._single_join(get, type, chunk=chunk)

    def calendarium(self,
                    type: MainMediaType | MainMediaTypeList | Sequence[MainMediaType],
                    *,
                    # limit: int | None = None,
                    chunk: int = 0,
                    ) -> ItemList[FFItem]:
        """Return callendar list items."""

        def get(mtype: MainMediaType) -> Sequence[JsonData]:
            if mtype not in get_typing_args(MainMediaType):
                raise ValueError(f'TraktApi got incorrect content type {mtype!r}')
            ctype = self._main2type[mtype]
            frm, to = const.indexer.tvshows.calendar_range
            start_date = dt_date.today() + timedelta(days=to)
            days = max(0, frm - to) + 1  # max(0) aby nie było odwróconych dni, +1 aby złapać start_date włącznie
            days = min(days, 33)  # API
            which = 'all' if ctype == 'movies' else 'my'
            data = self.get(f'calendars/{which}/{ctype}/{start_date}/{days}', login_required=True)
            if isinstance(data, Sequence):
                return tuple(reversed(data))
            return []

        return self._single_join(get, type, chunk=chunk)

    def aliases(self, mtype: MainMediaType, id: int | str) -> Sequence[JsonData]:
        """Get miedia aliases, `id` is trakt ID, trakt slug, or IMDB ID."""
        ctype = self._main2type[mtype]
        data = self.get(f'{ctype}/{id}/aliases', login_required=False)
        if isinstance(data, Sequence):
            return data
        fflog(f'TraktApi.aliases() got wrong response for {mtype} ({ctype}) {id!r}: {data!r}')
        return []

    def user_ratings(self, type: MediaType | None = None, *, rating: int | Iterable[int] | None = None) -> ItemList[FFItem]:
        """Get user media ratings."""
        ctype = self._ref2rating.get(type)
        if ctype is None:
            raise ValueError(f'TraktApi.user_ratings() got incorrect media type {type!r}')
        data, _ = self._cached_get(f'rated/{ctype}', f'sync/ratings/{ctype}', bucket='ratings')
        if isinstance(data, Sequence) and rating is not None:
            ratings = {rating} if isinstance(rating, int) else set(rating)
            data = [it for it in data if it.get('rating') in ratings]  # the whole list is cached, filtered here
        return self._item_list(data, pages=None)

    def add_user_ratings(self, items: Iterable[FFRef], *, rating: int | None) -> tuple[bool, int]:
        """Add (set) user ratings. If `rating` is None, get ratings from FFItems."""
        items = tuple(items)
        if rating is None:
            # no rating set, get form FFItems (there must be all set, MediaRef is not allowed here)
            ratings = [{'rating': ur} if ur else {} for it in items if isinstance(it, FFItem) and (ur := it.vtag.getUserRating()) is not ...]
            if len(ratings) != len(items):
                raise ValueError('TraktApi.add_user_ratings() got refs with missing ratings')
        else:
            # rating is set for all items (works with MediaRef too)
            if not (1 <= rating <= 10):
                raise ValueError(f'TraktApi.add_user_ratings() got incorrect rating {rating!r}')
            ratings = ({'rating': rating} for _ in items)
        try:
            return self._proc_list_items(items, path='sync/ratings', remove=False, people_enabled=False, extra=ratings)
        finally:
            self._changed('rated')

    def remove_user_ratings(self, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Remove user ratings."""
        try:
            return self._proc_list_items(items, path='sync/ratings/remove', remove=True, people_enabled=False)
        finally:
            self._changed('rated')

    # --- Lists and ratings of the account (`AccountClient` vocabulary) ---

    def watchlist(self, *, media: RefType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist of the account (the page, all items without `page`), sorted by `const.indexer.trakt.sort.watchlist`."""
        return self.user_generic_list('watchlist', media_type=media, page=page or ALL_PAGES, sort=const.indexer.trakt.sort.watchlist)

    def favorites(self, *, media: RefType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the favorites of the account (the page, all items without `page`)."""
        return self.user_generic_list('favorites', media_type=media, page=page or ALL_PAGES)

    def collection(self, *, media: MainMediaType | None = None, page: int | None = None) -> Sequence[FFItem]:
        """Return the collection of the account (the page cut here: the service has no pages, all items without `page`)."""
        items = self.user_collection(media or 'movie,show', chunk=const.trakt.page.limit // 2, sort=const.indexer.trakt.sort.collections)
        return Pagina(items, page=page, limit=const.trakt.page.limit) if page else items

    def list_items(self, list_id: int | str, *, media: MediaOrPersonType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the items of an own list of the account (the page, all items without `page`)."""
        return self.user_list_items(list_id, media_type=media, page=page)

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the watchlist or remove them, return the number of changed ones."""
        return (self.add_to_generic_list if state else self.remove_from_generic_list)('watchlist', items)[1]

    def set_favorites(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the favorites or remove them, return the number of changed ones."""
        return (self.add_to_generic_list if state else self.remove_from_generic_list)('favorites', items)[1]

    def set_collection(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the collection or remove them, return the number of changed ones."""
        return (self.add_to_generic_list if state else self.remove_from_generic_list)('collection', items)[1]

    def set_in_list(self, list_id: int | str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to an own list or remove them, return the number of changed ones."""
        return (self.add_to_user_list if state else self.remove_from_user_list)(list_id, items)[1]

    def create_list(self, name: str, *, public: bool = False) -> int | None:
        """Create an own list (private unless `public`), return its ID."""
        return self.create_user_list(name, privacy='public' if public else 'private')

    def delete_list(self, list_id: int | str) -> bool:
        """Delete an own list (with its items)."""
        return self.delete_user_list(list_id)

    def rename_list(self, list_id: int | str, name: str) -> str | None:
        """Rename an own list, return its ID (the same: the slug changes, FF uses the ID), None on failure."""
        data = self.put(f'users/me/lists/{list_id}', {'name': name}, login_required=True)
        self._changed('user')
        return str(list_id) if isinstance(data, Mapping) and data.get('ids') else None

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, int]:
        """Return the ratings of the account by media (from the list cache), only of the media `refs` if given."""
        return pick_ratings({it.ref: int(rating) for it in self.user_ratings() if (rating := it.getProperty('trakt.user_rating'))}, refs)

    def set_ratings(self, items: Iterable[FFRef], rating: int | None) -> int:
        """Rate (`rating`) the media or remove their ratings (None), return the number of changed ones."""
        if rating is None:
            return self.remove_user_ratings(items)[1]
        return self.add_user_ratings(items, rating=int(rating))[1]

    # --- Account and sync with the DB ---

    def _state_get(self, key: str) -> Any:
        """Return a state value of the account (`accounts.db`)."""
        if self.account is None:
            return None
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.account.id).get(key)

    def _state_set(self, key: str, value: Any) -> None:
        """Store (None: remove) a state value of the account (`accounts.db`)."""
        if self.account is not None:
            from ..ff.db.accounts import account_data_store
            store = account_data_store(self.account.id)
            if value is None:
                store.delete(key)
            else:
                store.set(key, value, ttl=None)

    def credentials(self) -> TraktCredentials:
        """Return current credentials: the application keys (the settings) and the token of the account (`accounts.db`)."""
        client = const.dev.trakt.client or settings.getString("trakt.client_key") or apis.trakt_API
        secret = const.dev.trakt.secret or settings.getString("trakt.secret_key") or apis.trakt_secret
        if self.account is None:
            return TraktCredentials(client=client, secret=secret)
        data = self._state_get('token') or {}
        access_token = data.get('access_token', '')
        return TraktCredentials(client=client, secret=secret, access_token=access_token,
                                refresh_token=data.get('refresh_token', ''), expires_at=data.get('expires_at', 0))

    def set_access_token(self, access: JsonData) -> TraktCredentials:
        """Save access token of the account and return new credentials. Another user drops the state of the account."""
        assert self.account is not None
        expires_at = int(utc_timestamp() + access['expires_in'])
        self._state_set('token', {'access_token': access['access_token'], 'refresh_token': access['refresh_token'], 'expires_at': expires_at})
        if profile := self.user_profile(credentials=self.credentials()):
            # Check if the new user differs from the old one.
            old_id = (self._state_get('profile') or {}).get('id')
            if old_id and old_id != profile.id:
                # New user: drop the state (profile, sync cursors) and the playback rows of the account.
                self._state_set('profile', None)
                reset_sync(self.account.id)
                remove_account_rows(self.account.id)
                remove_scope(self.account.id)
            self._state_set('profile', asdict(profile))
        else:
            self._state_set('profile', None)
        return self.credentials()

    def refresh_profile(self) -> JsonData | None:
        """Get the user profile of the account and keep it (`id`, `username`, ...), None on failure."""
        if self.account is None or not self.credentials() or (profile := self.user_profile(credentials=self.credentials())) is None:
            return None
        self._state_set('profile', data := asdict(profile))
        return data

    def unauth(self) -> bool:
        """Drop device authentication (revoke the token, remove it)."""
        return self.revoke_session()

    def remove_access_token(self) -> None:
        """Remove access token of the account."""
        if self.account is not None:
            self._state_set('token', None)

    def get_sync_progress(self, *, extended: ExtendedInfo = 'full', type: PlayContentType | None = None) -> Sequence[MediaPlayInfo] | None:
        """Get sync data from trakt.tv. Returns None on failure."""
        def parse(items: Sequence[JsonData]) -> Iterator[MediaPlayInfo]:
            for it in items:
                progress = it['progress']
                paused_at = item_paused_at(it) or 0
                playback_id = it['id']
                if 'movie' in it:
                    mv = it['movie']
                    ids = mv['ids']
                    ref = MediaRef.movie(VideoIds.from_ids(ids).ffid)
                    duration = 60 * runtime if (runtime := mv.get('runtime')) else None
                    yield MediaPlayInfo(ref=ref, progress=progress, paused_at=paused_at, duration=duration,
                                        **filter_ids(ids), playback_id=playback_id)
                if 'episode' in it:
                    ep = it['episode']
                    ids = ep['ids']
                    tv_ids = it['show']['ids']
                    ref = MediaRef.tvshow(VideoIds.from_ids(tv_ids).ffid, ep['season'], ep['number'])
                    duration = 60 * runtime if (runtime := ep.get('runtime')) else None
                    yield MediaPlayInfo(ref=ref, progress=progress, paused_at=paused_at, duration=duration,
                                        tv_slug=tv_ids.get('slug'), **filter_ids(ids), playback_id=playback_id)

        data = self.get_playblack_list(extended=extended, type=type)
        # with open('/tmp/trakt_sync_playback.json', 'w') as f:  json.dump(data, f, indent=2)  # XXX XXX XXX
        if isinstance(data, Sequence):
            return tuple(parse(data))
        return None

    def get_sync_watched_movies(self, *, extended: ExtendedInfo = '') -> Sequence[MediaPlayInfo] | None:
        """Get sync data from trakt.tv. Returns None on failure."""

        def parse(items: Sequence[JsonData]) -> Iterator[MediaPlayInfo]:
            for it in items:
                last_watched_at = item_watched_at(it) or 0
                mv = it['movie']
                ids = mv['ids']
                ref = MediaRef.movie(VideoIds.from_ids(ids).ffid)
                duration = 60 * runtime if (runtime := mv.get('runtime')) else None
                yield MediaPlayInfo(ref=ref, play_count=it['plays'], last_watched_at=last_watched_at, duration=duration,
                                    **filter_ids(ids), meta_updated_at=int(utc_timestamp(it['last_updated_at'])))

        data = self.get_watched_list('movies', extended=extended)
        # with open('/tmp/trakt_sync_movies.json', 'w') as f:  json.dump(data, f, indent=2)  # XXX XXX XXX
        if isinstance(data, Sequence):
            return tuple(parse(data))
        return None

    def get_sync_watched_shows(self, *, extended: ExtendedInfo = 'progress', parents: bool = False) -> Sequence[MediaPlayInfo] | None:
        """
        Get sync data from trakt.tv. Returns None on failure.

        Seasons (with episodes) are returned only with `extended=progress` (Trakt API change 2026-06-30, the default is w/o seasons).
        """

        def parse(items: Sequence[JsonData]) -> Iterator[MediaPlayInfo]:
            for it in items:
                tv_ids = it['show']['ids']
                tv_slug = tv_ids.get('slug')
                tv_ref = MediaRef.tvshow(VideoIds.from_ids(tv_ids).ffid)
                # `extended=progress` returns reduced show object, do not rely on optional fields
                updated_at = int(utc_timestamp(last_updated_at)) if (last_updated_at := it.get('last_updated_at')) else None
                for sz in it.get('seasons') or ():
                    sz_ref = tv_ref.with_season(sz['number'])
                    for ep in sz.get('episodes') or ():
                        ref = sz_ref.with_episode(ep['number'])
                        duration = 60 * runtime if (runtime := ep.get('runtime')) else None
                        # there is no episode ids in Trakt API
                        yield MediaPlayInfo(ref=ref, play_count=ep.get('plays', 1), tv_slug=tv_slug, duration=duration,
                                            last_watched_at=item_watched_at(ep) or 0, meta_updated_at=updated_at)
                    if parents:
                        yield MediaPlayInfo(ref=sz_ref, tv_slug=tv_slug)
                if parents:
                    yield MediaPlayInfo(ref=tv_ref, tv_slug=tv_slug, **filter_ids(tv_ids),
                                        last_watched_at=item_watched_at(it))

        data = self.get_watched_list('shows', extended=extended)
        # with open('/tmp/trakt_sync_shows.json', 'w') as f:  json.dump(data, f, indent=2)  # XXX XXX XXX
        if isinstance(data, Sequence):
            return tuple(parse(data))
        return None

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """Return cursors of the sync buckets of the account (`lib.ff.sync`), None on failure."""
        data = self.get('sync/last_activities', errors='ignore', login_required=True)
        if not isinstance(data, Mapping):
            return None
        cursors: dict[SyncBucket, str] = {bucket: max(values) for bucket, keys in SYNC_BUCKETS.items()
                                          if (values := [value for group, key in keys if (value := (data.get(group) or {}).get(key))])}
        return cursors

    def sync_bucket(self, bucket: SyncBucket, cursor: str | None = None) -> bool | None:
        """Get the bucket data (full lists) and store rows of the account (`lib.ff.sync`). Return True if changed, None on failure."""
        assert self.account is not None  # sync is login required
        account_id = self.account.id
        if bucket == 'progress.movie' or bucket == 'progress.episode':
            movie = bucket == 'progress.movie'
            if (rows := self.get_sync_progress(type='movie' if movie else 'episode')) is None:
                return None
            return update_track_playback(rows, account_id=account_id, media_type='movie' if movie else 'show',
                                         removed_at=cursor_time(cursor))
        if bucket == 'watched.movie':
            if (rows := self.get_sync_watched_movies()) is None:
                return None
            return update_track_watched_movies(rows, account_id=account_id, removed_at=cursor_time(cursor))
        if (rows := self.get_sync_watched_shows()) is None:
            return None
        return update_track_watched_episodes(rows, account_id=account_id, removed_at=cursor_time(cursor))

    def remove_playback_ref(self, ref: MediaRef) -> bool:
        """Remove a playback item (progress) by media ref (the playback ID from the DB or from Trakt)."""
        if (media_type := ref.real_type) not in ('movie', 'episode'):
            return False
        media = get_playback_item(ref, account_id=self.account.id) if self.account is not None else None
        if media is None or not media.playback_id:
            for media in self.get_sync_progress(type=media_type, extended='') or ():
                if media.ref == ref:
                    break
            else:
                return False
        if not media.playback_id:
            return False
        return self.remove_playback(media.playback_id)


if TYPE_CHECKING:
    class DePaginationBase(ObjectProxy, TraktApi):
        pass
    class DeResponseBase(ObjectProxy, requests.Response):
        pass
else:
    DePaginationBase = ObjectProxy
    DeResponseBase = ObjectProxy


class DeResponse(DeResponseBase):
    """Proxy to requests.Response, to override JSON."""

    def __init__(self, resp: requests.Response, *, json: JsonResult) -> None:
        super().__init__(resp)
        self._self_json = json

    def json(self, **kwargs) -> Any:
        return self._self_json


class DePagination(DePaginationBase):
    """Proxy to Traktapi using requests with depagination – all pages at once."""

    #: Run TraktApi.get() on the proxy, so self.request() is the depaginated one (ObjectProxy would bind it to the wrapped api).
    get = TraktApi.get

    def __init__(self, api: TraktApi, *, scan_limit: int = CONST_REF.trakt.page.limit) -> None:
        super().__init__(api)
        self._self_scan_limit: int = const_value(scan_limit)

    def request(self,
                method: str,
                url: str,
                *,
                data: JsonData | None = None,
                **kwargs: Unpack[TraktRequestKwargs],
                ) -> requests.Response | None:
        """Send requests to trakt.tv for all pages and return all response lists as single reponse."""

        def req(page: int) -> Sequence[JsonData] | None:
            pp = dict(params)
            pp['page'] = page
            resp = self.__wrapped__.request(method, url, params=pp, data=data, **kwargs)  # type: ignore[reportGeneralTypeIssues]  # params is popped from kwargs
            return part if resp and isinstance((part := resp.json()), Sequence) else None

        # 'X-Pagination-Page', 'X-Pagination-Limit', 'X-Pagination-Page-Count', 'X-Pagination-Item-Count'
        the_resp: requests.Response | None = None
        params = dict(kwargs.pop('params', None) or ())
        params.pop('page', None)
        kwargs.pop('page', None)
        limit: int = kwargs.pop('limit', params.pop('limit', 0)) or 0  # force limit for all items, NOT for single page scan
        page: int = 1
        params['limit'] = self._self_scan_limit
        # the fist page, get more info
        params['page'] = page
        the_resp = self.__wrapped__.request(method, url, params=params, data=data, **kwargs)
        if the_resp is None:
            return None
        page_count = int(the_resp.headers.get('X-Pagination-Page-Count', 1))
        part: JsonResult = the_resp.json()
        if page_count <= 1 or not isinstance(part, Sequence):
            # already single page or not sequence (we can not join pages)
            return the_resp
        page_size = int(the_resp.headers.get('X-Pagination-Limit', len(part)))
        result: list[JsonData] = [*part]
        # get rest of pages concurrent (in threads) — capped independently of the
        # general thread pool, to avoid bursting Trakt's rate limit on big accounts
        with ThreadPoolExecutor(const.trakt.scan.page.workers or None) as pool:
            if limit and page_size:
                # limit pages by item limit, it works good only if gages has the same number of items
                parts = pool.map(req, range(2, min(page_count, (limit + page_size - 1) // page_size) + 1))
            else:
                # all existing pages
                parts = pool.map(req, range(2, page_count + 1))
            parts = list(parts)
        # incomplete data looks like removed items (eg. unwatched), so a missing page fails the whole request
        if any(part is None for part in parts):
            fflog(f'[TRAKT] Incomplete pages of {url}, drop the whole response')
            return None
        result.extend(it for part in parts if part for it in part)
        # return all pageas as single response
        the_resp.headers['X-Pagination-Page'] = '1'
        the_resp.headers['X-Pagination-Limit'] = str(len(result))
        the_resp.headers['X-Pagination-Page-Count'] = '1'
        the_resp.headers['X-Pagination-Item-Count'] = str(len(result))
        return DeResponse(the_resp, json=result)


# --- DEBUG & TESTS ---

#: Global Trakt.tv support: the client of the type alias, the first Trakt account (an account: `lib.ff.accounts.account_client()`).
trakt: TraktApi = TraktApi(alias='trakt')
#: The application client (no user): the general lists of Trakt (trending / popular lists, ...).
trakt_app: TraktApi = TraktApi()


def make_client(account: Account | None) -> TraktApi:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return trakt if account is None else TraktApi(account)


# --- DEBUG & TESTS ---

if __name__ == '__main__':
    import re
    import sys
    from os import pathsep
    from pprint import pprint
    from typing_extensions import get_args as get_typing_args
    from datetime import timezone
    import json
    from argparse import ArgumentError, Action
    from ..ff.cmdline import DebugArgumentParser, RatingAction, parse_ref

    def print_plays(items: Iterable[MediaPlayInfo] | None, *, title: str = '', flt: int | None = None) -> None:
        if title:
            print(f'---[ {title} ] ---')
        for it in items or ():
            if not flt or it.ref.ffid == flt:
                prog = '----' if it.progress is None else f'{it.progress:3.0f}%'
                plays = '?' if it.play_count is None else str(it.play_count)
                slug = it.tv_slug or it.slug or '-'
                print(f' - {it.ref:16a} {prog} x{plays} {slug:<30.30} {it.account_id}')

    def jprint(data: JsonResult) -> None:
        print(json.dumps(data, indent=2))

    def raw_user_list_items(list_id: int | str,
                            user: str = 'me',
                            *,
                            page: int | None = None,
                            media_type: MediaOrPersonType | None = None,
                            sort: SortType | None = None,  # sort by X-Sort-By and X-Sort-How, has no sense if `page` is used
                            ) -> Sequence[JsonData]:
        """Return raw JSON of user (private too) lists."""
        ctype: str = media_type or ''  # list items filter by a singular type (`persons` is unknown there: all items)
        extended = 'full' if sort is not None else None  # more datails are needed for sorting
        data, pages = trakt.get_with_pages(f'users/{user}/lists/{list_id}/items/{ctype}', page=page, extended=extended)
        if isinstance(data, Sequence):
            return trakt._sort_items_with_pages(data, sort=sort, pages=pages)
        return ()

    sort_arg = ['', 'rank', 'added', 'title', 'released', 'runtime', 'popularity', 'percentage', 'votes', 'my_rating', 'random', 'watched', 'collected']
    sort_arg = [v for t in sort_arg for v in ((f'+{t}', f'-{t}') if t else ('',))]

    p = DebugArgumentParser(dest='cmd')
    p.add_argument('-K', '--kodi-path', metavar=f'PATH[{pathsep}PATH]...',
                   help='path to KODI user data and optional additional installation paths')
    with p.with_subparser('status') as pp:
        pass
    with p.with_subparser('sync'):
        pass
    with p.with_subparser('activities'):
        pass
    with p.with_subparser('watching') as pp:
        pass
    with p.with_subparser('watched') as pp:
        pp.add_argument('type', choices=('all', 'progress', 'history', 'movies', 'shows'))
        pp.add_argument('--filter', '-f', type=int, help='filter by movie/show id')
    with p.with_subparser('history') as pp:
        pp.add_argument('type', choices=get_typing_args(HistoryContentType))
        # pp.add_argument('--filter', '-f', type=int, help='filter by movie/show id')
    with p.with_subparser('list') as pp:
        pp.add_argument('list', choices=('likes', 'watchlist', 'favorites', 'history', 'watched'))
        pp.add_argument('type', nargs='?', choices=('movie', 'show', 'season', 'episode'))
        pp.add_argument('-s', '--sort', choices=get_typing_args(SortType), help='sort')
        # pp.add_argument('-f', '--filter', type=int, help='filter by movie/show id')
    with p.with_subparser('mine') as pp:
        pp.add_argument('list', nargs='?', help='own list name')
        pp.add_argument('type', nargs='?', choices=('movie', 'show', 'season', 'episode'))
        pp.add_argument('-s', '--sort', choices=get_typing_args(SortType), help='sort')
        pp.add_argument('-u', '--user', default='me', help='user name [me]')
        pp.add_argument('-L', '--list', dest='print_lists', action='store_true', help='print lists')
        pp.add_argument('-J', '--json', action='store_true', help='print raw JSON')
        pp.add_argument('-a', '--add', type=parse_ref, action='append', help='add to the list')
    with p.with_subparser('collection') as pp:
        pp.add_argument('type', choices=('movie', 'show'))
        pp.add_argument('-s', '--sort', default='', choices=sort_arg, help='sort')
        pp.add_argument('-u', '--user', default='me', help='user name [me]')
    with p.with_subparser('db', dest='cmd1') as pp:
        # g.add_argument('type', choices=('all', 'movies', 'shows'))
        with pp.with_subparser('all', aliases=('movies', 'shows')) as ppp:
            ppp.add_argument('-f', '--filter', type=int, help='filter by movie/show id')
        with pp.with_subparser('ref') as ppp:
            ppp.add_argument('ref', type=parse_ref, help='show only one ref')
        with pp.with_subparser('watch') as ppp:
            ppp.add_argument('ref', type=parse_ref, help='media ref: movie/ID, show/ID[/SEASON[/EPISODE]]')
        with pp.with_subparser('unwatch') as ppp:
            ppp.add_argument('ref', type=parse_ref, help='media ref: movie/ID, show/ID[/SEASON[/EPISODE]]')
    with p.with_subparser('profile'):
        pass
    with p.with_subparser('lookup') as pp:
        pp.add_argument('service', help='service to lookup id (tmdb, etc.)')
        pp.add_argument('id', help='id to lookup')
        pp.add_argument('type', nargs='?', help='media type (movie, show, episode, person)')
    with p.with_subparser('scrobble') as pp:
        pp.add_argument('action', choices=(*get_typing_args(ScrobbleAction), 'remove'), help='scrobble action')
        # pp.add_argument('type', choices=get_typing_args(PlayContentType), help='media type')
        pp.add_argument('ref', type=parse_ref, help='media ref: movie/ID, show/ID/SEASON/EPISODE')
        pp.add_argument('progress', nargs='?', type=float, help='scrobble action')
    with p.with_subparser('playback') as pp:
        pass
    with p.with_subparser('ratings') as pp:
        pp.add_argument('type', nargs='?', choices=('movie', 'show', 'season', 'episode', 'all'), default='all', help='get rating type')
        pp.add_argument('rating', nargs='*', type=int, action='extend', default=[], help='get rating value(s)')
        pp.add_argument('-s', '--set', action=RatingAction, nargs='+', metavar=('RATING', 'REF'), help='set rating for media ref')
        pp.add_argument('-r', '--remove', type=parse_ref, metavar='REF', help='remove rating for media ref')
    args = p.parse_args()
    from ..ff.ui import set_ui, TerminalUI
    set_ui(TerminalUI())
    from ..ff.info import ffinfo

    ref: MediaRef
    if args.kodi_path:
        from ..fake import fake_api
        fake_api.KODI_PATH = Path(args.kodi_path.partition(pathsep)[0]).expanduser().absolute()
    if args.cmd == 'sync':
        from ..ff.sync import sync_account
        if trakt.account is not None:
            print(sync_account(trakt.account))
    elif args.cmd == 'activities':
        print(trakt.sync_activities())
    elif args.cmd == 'watching':
        data = trakt.get_watching()
        if data:
            jprint(data)
            start = fromisoformat(data['started_at']).timestamp()
            duration = fromisoformat(data['expires_at']).timestamp() - start
            current = datetime.now(tz=timezone.utc).timestamp() - start
            print(f'Progress: {100 * current / duration:.1f}%')
    elif args.cmd == 'watched':
        if args.type in ('all', 'progress'):
            print_plays(trakt.get_sync_progress(), title='progress', flt=args.filter)
        if args.type in ('all', 'movies'):
            print_plays(trakt.get_sync_watched_movies(), title='movies', flt=args.filter)
        if args.type in ('all', 'shows'):
            print_plays(trakt.get_sync_watched_shows(), title='shows', flt=args.filter)
    elif args.cmd == 'history':
        jprint(trakt.get_history_list(args.type))
    elif args.cmd == 'list':
        items = trakt.user_generic_list(args.list, media_type=args.type, user='me', sort=args.sort)
        for it in items:
            print(it)
    elif args.cmd == 'mine':
        if args.add:
            trakt.add_to_user_list(args.list, args.add)
        elif args.print_lists:
            for it in trakt.user_lists(user=args.user):
                print(f'- {it.title}')
        elif args.json:
            data = raw_user_list_items(args.list, user=args.user, media_type=args.type, sort=args.sort)
            text = json.dumps(data, indent=2)
            rx = re.compile(r'\s+', flags=re.DOTALL)
            text = re.sub(r'(?<="languages": \[)[^]]*(?=\])', lambda m: rx.sub(' ', m[0]), text, flags=re.DOTALL)
            text = re.sub(r'(?<="available_translations": \[)[^]]*(?=\])', lambda m: rx.sub(' ', m[0]), text, flags=re.DOTALL)
            print(text)
        else:
            for it in trakt.user_list_items(args.list, user=args.user, media_type=args.type, sort=args.sort):
                print(it)
    elif args.cmd == 'collection':
        fflog('--- COLLECTION ---')
        if args.sort.startswith('+'):
            args.sort = f'{args.sort[1:]}.asc'
        elif args.sort.startswith('-'):
            args.sort = f'{args.sort[1:]}.desc'
        items = trakt.user_collection(args.type, user=args.user, sort=args.sort)
        print(f'Found: {len(items)} {args.type}s in collection of user {args.user!r}:')
        for it in items:
            print(f'- {it}')
    elif args.cmd == 'db':
        account_id = trakt.account.id if trakt.account else 'trakt'
        if args.cmd1 == 'all':
            print_plays(get_playback(account_id=account_id), flt=args.filter)
        elif args.cmd1 == 'movies':
            print_plays(get_playback('movie', account_id=account_id), flt=args.filter)
        elif args.cmd1 == 'shows':
            print_plays(get_playback('show', account_id=account_id), flt=args.filter)
        if args.cmd1 == 'ref':
            print_plays([pb for pb in [get_playback_item(args.ref, account_id=account_id)] if pb])
        elif args.cmd1 == 'watch':
            ref = args.ref
            m = get_playback_item(ref, account_id=account_id) or MediaPlayInfo.from_ffitem(ffinfo.find_item(ref))
            m.play_count = 1
            m.progress = None
            update_track_watched_item(m, account_id=account_id)
        elif args.cmd1 == 'unwatch':
            ref = args.ref
            m = get_playback_item(ref, account_id=account_id) or MediaPlayInfo.from_ffitem(ffinfo.find_item(ref))
            m.play_count = 0
            m.progress = None
            m.last_watched_at = None
            update_track_watched_item(m, account_id=account_id)
    elif args.cmd == 'status':
        print_plays(trakt.get_sync_progress(), title='progress')
        print_plays(trakt.get_sync_watched_movies(), title='movies')
        print_plays(trakt.get_sync_watched_shows(), title='shows')
    elif args.cmd == 'profile':
        print(trakt.user_profile())
    elif args.cmd == 'lookup':
        if args.service == 'trakt' and not args.id.isdecimal() and args.type in ('movie', 'show'):
            print(trakt.media(args.type, args.id))
        else:
            print(trakt.id_lookup(args.id, service=args.service, type=args.type))
    elif args.cmd == 'scrobble':
        if (ref := args.ref).real_type not in get_typing_args(PlayContentType):
            print('ERROR: `ref` must be movie or episode')
            ok = False
        elif args.action == 'remove':
            ok = trakt.remove_playback_ref(ref)
        else:
            progress = 50 if args.progress is None else args.progress
            ok = trakt.scrobble(args.action, ref.real_type, progress, ids=ref.video_ids.ids())
        print(f'Success: {ok}')
    elif args.cmd == 'playback':
        jprint(trakt.get('sync/playback/'))
    elif args.cmd == 'ratings':
        if args.type == 'all':
            args.type = None
        if args.set:
            print(trakt.add_user_ratings(args.set[1:], rating=args.set[0]))
        elif args.remove:
            print(trakt.remove_user_ratings(args.remove))
        else:
            for it in trakt.user_ratings(args.type, rating=args.rating):
                info = ''
                if it.season is not None and (title := it.vtag.getTvShowTitle()):
                    info = f'   [{title} ({it.getProperty("show.year")})]'
                print(f' - {it.ref:20a} {it.vtag.getUserRating():>2} {it.title} ({it.year or ""}){info}')
    # print(get_playback_item(MediaRef.movie(968051)))

    # --- FF2 trakt manager ---
    # items = [(control.lang(32516), "/sync/collection")]
    # items += [(control.lang(32517), "/sync/collection/remove")]
    # items += [(control.lang(32518), "/sync/watchlist")]
    # items += [(control.lang(32519), "/sync/watchlist/remove")]
    # items += [(control.lang(32520), "/users/me/lists/%s/items")]

