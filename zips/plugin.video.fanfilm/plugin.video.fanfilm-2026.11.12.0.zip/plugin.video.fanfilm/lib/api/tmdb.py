"""Tiny TheMovieDB.org API wrapper."""

from __future__ import annotations
from sys import version_info as python_version_info
import re
from datetime import datetime, date as dt_date, timedelta
from threading import Lock, Semaphore
from collections import UserDict
from itertools import chain
from queue import Queue
from urllib.parse import urljoin
from enum import Enum, Flag, auto as auto_enum
from time import monotonic
from typing import Optional, Union, Any, Tuple, List, Dict, Sequence, Iterable, Iterator, Mapping, Callable, ClassVar
from typing import Generic, Generator, ClassVar, Type, TypeVar, overload, TYPE_CHECKING
from typing_extensions import Literal, get_args as get_typing_args, TypedDict, Unpack, NotRequired, TypeAlias, Self, Pattern, cast
# from typing_extensions import Annotated
from attrs import define, frozen, field, evolve

from ..defs import VideoIds, MediaRef, MediaType
from ..defs import RefType, MainMediaType, MainMediaTypeList, ItemList, Pagina, SearchType, FFRef
from ..ff.db.playback import MediaPlayInfoDict
from ..ff.item import FFItem, EpisodeType, FFEpisodeGroup, FFEpisodeGroupType
from ..ff.types import JsonData, JsonResult, KwArgs, Params, Headers
from ..ff.calendar import fromisoformat
from ..ff.tricks import join_items, batched, jwt_decode
from ..ff.kotools import xsleep
from ..ff.logs import fflog
from ..ff.debug import logtime
from ..ff.requests import RequestsPoolExecutor
from ..ff.listcache import FetchedList, cached_list, list_params, mark_stale, remove_scope
from ..ff.accounts import Account, AccountClient
from ..ff.ratings import RatingScale, pick_ratings
from ..ff import requests
from ..ff import apis
from cdefs import InfoDetails, ListSection, ListType, const_value
from const import const, CONST_REF

if TYPE_CHECKING:
    from concurrent.futures import Future
    from ..ff.requests import Method
    from ..ff.art import ArtInfo
    from ..ff.sync import SyncBucket


if not TYPE_CHECKING:
    if python_version_info < (3, 9):
        class UserDict(UserDict, Generic[TypeVar('K'), TypeVar('V')]):
            """Backport of typing.Generic for UserDict."""
            pass


T = TypeVar('T')

ApiVer: TypeAlias = Literal[3, 4, None]

TmdbId: TypeAlias = int
MovieId: TypeAlias = TmdbId
ShowId: TypeAlias = TmdbId
SeasonId: TypeAlias = TmdbId
EpisodeId: TypeAlias = TmdbId
SeasonNumber: TypeAlias = int
EpisodeNumber: TypeAlias = int
# TmdbTvIdKey = Tuple[ShowId, Optional[SeasonId], Optional[EpisodeId]]
# TmdbTvIds = Dict[TmdbTvIdKey, TmdbId]

#: TMDB get info content type.
TmdbContentType: TypeAlias = Literal['movie', 'tv']
TmdbContentPluralType: TypeAlias = Literal['movies', 'tv']
TmdbContentRatingType: TypeAlias = Literal['movies', 'tv', 'episodes']
# : TMDB api type/paht with content details.
TmdbContentDetailsType: TypeAlias = Literal['account', 'collection', 'company', 'configuration', 'credit', 'keyword', 'list', 'movie',
                                            'network', 'person', 'review', 'tv', 'episode_group']
#: TMDB get info content type.
TmdbListType: TypeAlias = Literal[
    'top_rated',    # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200
    'popular',      # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc
    'now_playing',  # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}
    'upcoming',     # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}
]

TimeWindow: TypeAlias = Literal['week', 'day']

TmdbConfName: TypeAlias = Literal['countries', 'jobs', 'languages', 'primary_translations', 'timezones']

ExternalIdType: TypeAlias = Literal['imdb']

TmdbSearchType: TypeAlias = Literal['collection', 'company', 'keyword', 'movie', 'multi', 'person', 'tv']

PersonDataType: TypeAlias = Literal['combined_credits', 'movie_credits', 'tv_credits']

DetailsAllowed: TypeAlias = Literal['movie', 'show', 'person', 'collection', 'company', 'keyword', 'network']

MediaResource: TypeAlias = Literal['recommendations', 'similar']

AccountId: TypeAlias = Union[int, Literal['me']]

#: Users general list.
UserGeneralListType: TypeAlias = Literal['favorite', 'watchlist']
#: TMDB JSON item data.
TmdbItemJson: TypeAlias = Dict[str, Any]
#: Media JSON data.
TmdbMediaDataDict: TypeAlias = Dict[MediaRef, TmdbItemJson]
#: TMDB sort_by values (movie).
TmdbMovieSortBy: TypeAlias = Literal['original_title.asc', 'original_title.desc',
                                     'popularity.asc', 'popularity.desc',
                                     'revenue.asc', 'revenue.desc',
                                     'primary_release_date.asc', 'primary_release_date.desc',
                                     'title.asc', 'title.desc',
                                     'vote_average.asc', 'vote_average.desc',
                                     'vote_count.asc', 'vote_count.desc',
                                     ]
#: TMDB sort_by values (tv).
TmdbTvSortBy: TypeAlias = Literal['first_air_date.asc', 'first_air_date.desc',
                                  'name.asc', 'name.desc',
                                  'original_name.asc', 'original_name.desc',
                                  'popularity.asc', 'popularity.desc',
                                  'vote_average.asc', 'vote_average.desc',
                                  'vote_count.asc', 'vote_count.desc',
                                  ]
#: TMDB sort_by values.
TmdbSortBy: TypeAlias = Literal['original_title.asc', 'original_title.desc',              # movie only
                                'revenue.asc', 'revenue.desc',                            # movie only
                                'primary_release_date.asc', 'primary_release_date.desc',  # movie only
                                'title.asc', 'title.desc',                                # movie only
                                'first_air_date.asc', 'first_air_date.desc',              # tv-show only
                                'name.asc', 'name.desc',                                  # tv-show only
                                'original_name.asc', 'original_name.desc',                # tv-show only
                                'popularity.asc', 'popularity.desc',
                                'vote_average.asc', 'vote_average.desc',
                                'vote_count.asc', 'vote_count.desc',
                                ]


def _no_answer() -> TmdbItemJson:
    """Return the TMDB error shape of no usable answer (code 0 is not a TMDB code, e.g. not 34 "not found")."""
    return {'success': False, 'status_code': 0}


def _failed(data: Any) -> bool:
    """Return True if `data` is a TMDB error answer (also `_no_answer()`)."""
    return isinstance(data, Mapping) and data.get('success') is False


@frozen
class TmdbCredentials:
    """TMDB credentials."""

    #: Optional TMDB api-key for get more tv-show info.
    api_key: Optional[str] = None
    #: Optional TMDB v4 api bearer JWT token.
    bearer: Optional[str] = None
    #: User name.
    user: Optional[str] = None
    #: User password.
    password: Optional[str] = None
    #: User session.
    session_id: Optional[str] = None
    #: Access token (v4).
    access_token: Optional[str] = None

    def __bool__(self) -> bool:
        """Return True if credentials are defined (user is logged)."""
        return bool(self.session_id) or bool(self.access_token)

    @property
    def v3(self) -> bool:
        """Return True if credentials are defined (user is logged) in v3 API."""
        return bool(self.session_id)

    @property
    def v4(self) -> bool:
        """Return True if credentials are defined (user is logged) in v4 API."""
        return bool(self.access_token)

    @property
    def account_id(self) -> str:
        """Return account_id from v4 access_token."""
        if self.access_token:
            try:
                return jwt_decode(self.access_token).get('sub', '')
            except ValueError:  # not a JWT
                return ''
        return ''


class GetImageMode(Enum):
    """Mode of image getting."""
    #: append  - use `append_to_response=images` with fixed `include_image_language`, no poster at all often
    APPEND = 'append'
    #: append  - use `append_to_response=images` with fixed `include_image_language=en.
    APPEND_EN = 'append_en'
    #: append  - use `append_to_response=images` with fixed `include_image_language={lang}.
    APPEND_LANG = 'append_lang'
    #: pull    - like `append` but gen images in next request if fails (no images)
    PULL = 'pull'
    #: full    - always make two requests, support all services (it is forced for non-tmdb services, e.g. fanart.tv)
    FULL = 'full'
    #: all     - use /images to get all images in concurrent request
    ALL = 'all'


@frozen
class PersonCredits:
    """Person credits result."""

    cast: tuple[FFItem, ...] = ()
    crew: tuple[FFItem, ...] = ()


class Condition(Generic[T]):
    """TMDB discovery conditions."""

    RX_EXPR: ClassVar[Pattern[str]] = re.compile(r'^\s*(\w+)\s*([<>=]=?)\s*(.*\S)\s*$')

    def __init__(self, type: Type[T], *, cond: Optional[List[Tuple[str, str]]] = None) -> None:
        self.type: Type[T] = type
        self.cond: List[Tuple[str, str]] = [] if cond is None else cond

    def range(self, min: T, max: T) -> 'Condition':
        return Condition(self.type, cond=[('gte', str(min)), ('lte', str(max))])

    def _add(self, val: T, a: int) -> T:
        if isinstance(val, dt_date):
            return val + timedelta(days=a)
        if isinstance(val, int):
            return val + a
        if isinstance(float, int):
            return val + .001 * a
        return val

    def __repr__(self) -> str:
        return f'Conditional(type={self.type}, cond={self.cond})'

    def __str__(self) -> str:
        s = ' & '.join(f'{k}={v}' for k, v in self.cond)
        return f'Conditional({s})'

    def __le__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('lte', str(other))])

    def __ge__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('gte', str(other))])

    def __lt__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('lte', str(self._add(other, -1)))])

    def __gt__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('gte', str(self._add(other, 1)))])

    def __and__(self, other: 'Condition[T]') -> 'Condition':
        if isinstance(other, Condition):
            return Condition(self.type, cond=[*self.cond, *other.cond])
        return NotImplemented

    @classmethod
    def filter_from_str_expr(cls, expr: str) -> Tuple[str, Union[str, Self, None]]:
        """Return condition from expr. Try use numbers."""
        if mch := cls.RX_EXPR.fullmatch(expr):
            a, o, b = mch.groups()
            if o in ('=', '=='):
                return a, b
            if o == '<':
                return a, cls(str) < b  # type: ignore [reportOperatorIssue]
            if o == '<=':
                return a, cls(str) <= b  # type: ignore [reportOperatorIssue]
            if o == '>':
                return a, cls(str) > b  # type: ignore [reportOperatorIssue]
            if o == '>=':
                return a, cls(str) >= b  # type: ignore [reportOperatorIssue]
        return expr, None

    @classmethod
    def filters_from_str_expr_list(cls, expresions: Iterable[str]) -> 'DiscoveryFilters':
        allowed = TmdbApi.DISCOVER_FILTERS
        filters = {k: v for val in expresions
                   for k, v in (cls.filter_from_str_expr(val),) if k in allowed and v is not None}
        return cast('DiscoveryFilters', filters)


# RangeCondition: TypeAlias = Annotated[T, Condition]


class DiscoveryFilters(TypedDict):
    """Filter arguments for TMDB discovery."""

    air_date: NotRequired[Condition[dt_date]]
    first_air_date: NotRequired[Condition[dt_date]]
    first_air_year: NotRequired[int]
    include_null_first_air_dates: NotRequired[bool]
    screened_theatrically: NotRequired[bool]
    timezone: NotRequired[str]
    with_networks: NotRequired[int]
    with_status: NotRequired[Union[str, Literal[0, 1, 2, 3, 4, 5]]]  # Returning Series: 0 Planned: 1 In Production: 2 Ended: 3 Cancelled: 4 Pilot: 5
    with_type: NotRequired[Union[str, Literal[0, 1, 2, 3, 4, 5, 6]]]

    certification: NotRequired[Union[str, Condition[str]]]
    certification_country: NotRequired[str]
    include_adult: NotRequired[bool]
    include_video: NotRequired[bool]
    language: NotRequired[str]
    primary_release_year: NotRequired[int]
    primary_release_date: NotRequired[Condition[dt_date]]
    region: NotRequired[str]
    release_date: NotRequired[Condition[dt_date]]
    sort_by: NotRequired[TmdbSortBy]
    vote_average: NotRequired[Condition[float]]
    vote_count: NotRequired[Condition[int]]
    watch_region: NotRequired[str]
    with_cast: NotRequired[str]
    with_companies: NotRequired[str]
    with_crew: NotRequired[str]
    with_genres: NotRequired[str]
    with_keywords: NotRequired[str]
    with_origin_country: NotRequired[str]
    with_original_language: NotRequired[str]
    with_people: NotRequired[str]
    with_release_type: NotRequired[Union[str, Literal[1, 2, 3, 4, 5, 6]]]
    with_runtime: NotRequired[Condition[int]]
    with_text_query: NotRequired[str]
    with_watch_monetization_types: NotRequired[Union[str, Literal['flatrate', 'free', 'ads', 'rent', 'buy']]]
    with_watch_providers: NotRequired[str]
    without_companies: NotRequired[str]
    without_genres: NotRequired[str]
    without_keywords: NotRequired[Union[str, int, Sequence[int]]]
    without_watch_providers: NotRequired[str]
    year: NotRequired[int]


class SearchFilters(TypedDict):
    """Filter arguments for TMDB search."""

    include_adult: NotRequired[bool]
    primary_release_year: NotRequired[int]
    year: NotRequired[int]
    first_air_date_year: NotRequired[int]
    region: NotRequired[str]


class TmdbRequestKwargs(TypedDict):
    credentials: NotRequired[Optional[TmdbCredentials]]
    api_version: NotRequired[Literal[3, 4]]
    params: NotRequired[Optional[KwArgs]]
    append_to_response: NotRequired[Tuple[str, ...]]
    lang: NotRequired[Optional[str]]
    expected_errors: NotRequired[Sequence[int]]


@define
class TmdbApiStats:
    request_count: int = 0
    extra_seasons_count: int = 0
    multi_seasons_count: int = 0


@define
class TmdbProvider:
    id: int
    name: str
    logo: Optional[str] = None
    display_priority: int = 0


@frozen(kw_only=True)
class MediaVideo:
    lang: str
    name: str
    key: str
    site: str
    type: str
    official: bool
    published_at: datetime

    # @property
    # def locale(self) -> str:
    #     return f'{self.lang}-{self.country}'


class SkelOptions(Flag):
    """TMDB skeleton options."""

    NONE = 0
    #: Get translate info.
    #: Not need to set, ffinfo.get_en_skel_items() sets is if `locale` is used.
    TRANSLATIONS = auto_enum()
    #: Get info for first few seasons.
    #: It is useful only if show has up to 18 seasons but it do not any extra request.
    SHOW_FIRST_SEASONS = auto_enum()
    #: Get info for last few seasons.
    #: Seasons details depend on number of seasons. Skel try to get a few first seasons (more then 18) with main show request.
    #: If there is more seasons skel request a few last seasons (more then 18), because now skel knows number of seasons.
    SHOW_LAST_SEASONS = auto_enum()
    #: Get info for all seasons.
    #: Skel try to get a few first seasons (more then 18) with main show request then requests next season group one by one.
    SHOW_ALL_SEASONS = auto_enum()
    #: Approximate the episode air date as season air date.
    #: It is used only if there is no the season's details.
    SHOW_EPISODE_DATE_FIRST = auto_enum()
    #: Approximate the episode air date as last emitted episode or day before next season air date.
    #: It is used only if there is no the season's details.
    SHOW_EPISODE_DATE_LAST = auto_enum()
    #: Approximate the episode air date as linear date between SHOW_EPISODE_DATE_FIRST and SHOW_EPISODE_DATE_LAST.
    #: It is used only if there is no the season's details.
    SHOW_EPISODE_DATE_APPROXIMATE = auto_enum()


# MediaRequestKey: TypeAlias = Tuple[MediaRef, InfoDetails, str, Tuple[int, ...], Tuple[str, ...]]  # (ref, details, locale, seasons, append_to_response)
MediaRequestKey: TypeAlias = Tuple[MediaRef, str]  # (ref, locale)
LOCALE_EN = 'en-US'
LOCALE_ORIG = '_ORIG_'


@define(kw_only=True)
class MediaRequest:
    """Media request."""

    # --- input ---

    #: Media reference (or ffitem).
    item: FFRef = field(kw_only=False)
    #: Info details flags.
    details: InfoDetails = field(default=InfoDetails.DEFAULT, kw_only=False)
    #: Locale (language) for get info, e.g. 'pl-PL'. If empty, use default (API locale).
    locale: str = ''  # e.g. 'pl-PL'

    @property
    def ref(self) -> MediaRef:
        """Media item reference."""
        return self.item.ref

    @property
    def ffitem(self) -> FFItem | None:
        """Media item reference."""
        return self.item if isinstance(self.item, FFItem) else None

    # --- internal ---

    seasons: Iterable[int] | None = None
    # key: str = ''
    path: str = ''
    _append_to_response: list[str] | None = None
    params: Params = field(factory=dict)
    data: JsonData = field(factory=dict)
    _key: MediaRequestKey | None = field(default=None, init=False, repr=False, eq=False, hash=False)

    @classmethod
    def new(cls, item: FFRef | MediaRequest, *,
            details: InfoDetails | None = None, locale: str | None = None,
            default_details: InfoDetails = InfoDetails.DEFAULT, default_locale: str = '',
            ) -> MediaRequest:
        if isinstance(item, MediaRequest):
            if details is None:
                details = item.details
            if locale is None:
                locale = item.locale or ''
            return item.copy(details=details, locale=locale)
        if details is None:
            details = default_details
        if locale is None:
            locale = default_locale or ''
        return cls(item=item, details=details, locale=locale or '')

    def copy(self, *, item: FFRef | None = None, details: InfoDetails | None = None, locale: str | None = None) -> MediaRequest:
        """Duplicate object."""
        if item is None:
            item = self.item
        if details is None:
            details = self.details
        if locale is None:
            locale = self.locale or ''
        return evolve(self, item=item, details=details, locale=locale)

    @property
    def key(self) -> MediaRequestKey:
        """Unique request key."""
        if self._key is None:
            # self._key = (self.ref, self.details, self.locale or '', tuple(sorted(self.seasons)) if self.seasons else (),
            #              tuple(sorted(self.append_to_response)))
            self._key = (self.ref, self.locale or '')
        return self._key

    @property
    def append_to_response(self) -> list[str]:
        """Append to response values."""
        if self._append_to_response is None:
            self._append_to_response = self.create_append_to_response()
        return self._append_to_response

    @property
    def need_create_append_to_response(self) -> bool:
        """Return True if need to initialize append_to_response."""
        return self._append_to_response is None

    def create_append_to_response(self) -> list[str]:
        """Append items to `append_to_response` list with respect of limit."""
        details = self.details
        seasons = self.seasons
        tv_seasons = tuple(seasons or ())
        ref = self.ref
        rtype = ref.real_type
        imode = GetImageMode(const.tmdb.get_image_mode)

        respapp = []
        if details & InfoDetails.COMMON_DETAILS:
            respapp.extend(('external_ids',))
        if details & InfoDetails.MEDIA_DETAILS:
            respapp.extend(('release_dates', 'keywords'))
            if details & InfoDetails.AGGREGATE_CREDITS and ref.real_type in ('show', 'season'):
                respapp.append('aggregate_credits')
            elif ref.real_type in ('movie', 'show', 'season', 'episode'):
                respapp.append('credits')
            if const.media.aliases_service == 'tmdb':
                respapp.append('alternative_titles')
        elif details & InfoDetails.AGGREGATE_CREDITS:
            if ref.real_type in ('show', 'season') and 'aggregate_credits' not in respapp:
                respapp.append('aggregate_credits')
            elif ref.real_type in ('movie', 'episode') and 'credits' not in respapp:
                respapp.append('credits')
        if details & InfoDetails.IMAGES:
            if imode in (GetImageMode.APPEND, GetImageMode.APPEND_EN, GetImageMode.APPEND_LANG, GetImageMode.PULL):
                respapp.append('images')
        if details & InfoDetails.VIDEOS:
            respapp.append('videos')
        if details & InfoDetails.TRANSLATIONS:
            respapp.append('translations')
        if details & InfoDetails.EPISODE_GROUPS and rtype == 'show':
            respapp.append('episode_groups')
        # append a few seasons with episodes to single request (sic!)
        if details & InfoDetails.SHOW_SEASONS and rtype == 'show':  # append a few existing seasons with episodes to single request (sic!)
            # see: https://www.themoviedb.org/talk/63ee22b4699fb7009e3e5102
            scount = const.tmdb.append_to_response_limit - len(respapp)
            respapp.extend(f'season/{i+1}' for i in range(scount))
        if tv_seasons and rtype == 'show':  # append a few requestet seasons to single request (sic!)
            scount = const.tmdb.append_to_response_limit - len(respapp)
            respapp.extend(f'season/{i}' for i in tv_seasons[:scount])
        return respapp


class MediaRequestDict(UserDict[MediaRequestKey, MediaRequest]):
    """Dictionary of media requests."""

    data: Dict[MediaRef, Dict[str, MediaRequest]]  # type: ignore [reportIncompatibleVariableOverride]

    def __init__(self, _init: Iterable[tuple[MediaRequestKey, MediaRequest]] | Mapping[MediaRequestKey, MediaRequest] | None = None, /) -> None:
        """Initialize dictionary."""
        super().__init__()
        if _init is None:
            pass
        elif isinstance(_init, Mapping):
            for (ref, loc), val in _init.items():
                self.data.setdefault(ref, {})[loc] = val  # type: ignore [reportOptionalSubscript]
        else:
            for (ref, loc), val in _init:
                self.data.setdefault(ref, {})[loc] = val

    @overload
    def __getitem__(self, key: MediaRequestKey) -> MediaRequest: ...

    @overload
    def __getitem__(self, key: MediaRef) -> Dict[str, MediaRequest]: ...

    def __getitem__(self, key: MediaRequestKey | MediaRef) -> MediaRequest | Dict[str, MediaRequest]:
        """Get item by key or partial get (all locales for ref)."""
        if isinstance(key, MediaRef):
            return self.data[key]
        ref, loc = key
        reqs = self.data[ref]
        return reqs[loc]

    def __setitem__(self, key: MediaRequestKey, value: MediaRequest) -> None:
        """Set item by key."""
        ref, loc = key
        reqs = self.data.setdefault(ref, {})
        reqs[loc] = value

    def __delitem__(self, key: MediaRequestKey) -> None:
        """Delete item by key."""
        ref, loc = key
        reqs = self.data.get(ref)
        if reqs is None:
            raise KeyError(key)
        del reqs[loc]
        if not reqs:
            del self.data[ref]

    def keys(self) -> Iterator[MediaRequestKey]:
        """Generate all keys."""
        for ref, reqs in self.data.items():
            for loc in reqs.keys():
                yield (ref, loc)

    @overload
    def get(self, key: MediaRequestKey, default: T = None) -> MediaRequest | T: ...

    @overload
    def get(self, key: MediaRef, default: T = None) -> Dict[str, MediaRequest] | T: ...

    def get(self, key: MediaRequestKey | MediaRef, default: Any = None) -> Any:
        """Get item by key or partial get (all locales for ref)."""
        if isinstance(key, MediaRef):
            return self.data.get(key, default)
        ref, loc = key
        reqs = self.data.get(ref)
        if reqs is None:
            return default
        return reqs.get(loc, default)

    def all_values(self) -> Iterator[MediaRequest]:
        """Generate all requests."""
        for reqs in self.data.values():
            for req in reqs.values():
                yield req

    def setdefault(self, key: MediaRequestKey, req: MediaRequest) -> MediaRequest:
        """Set default request."""
        ref, loc = key
        reqs = self.data.setdefault(ref, {})
        return reqs.setdefault(loc, req)


class TmdbApi(AccountClient):
    """Base TBDB API."""

    #: The own API key (`tmdb.api_key`) TMDB rejected in this process: the application key is used instead.
    _own_key_rejected: ClassVar[str] = ''

    #: Sections of lists of the account.
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'favorites': ListSection(types=ListType.MAIN),
        'watchlist': ListSection(types=ListType.MAIN),
        'user': ListSection(types=ListType.MAIN, create={'public': True}),
    }
    #: Rating scale of the account (0.5 is needed for the first rating, then 0.25 could be used for updates).
    RATING: ClassVar[Optional[RatingScale]] = RatingScale(type=float, min=1.0, max=10.0, step=0.5, media=('movie', 'show', 'episode'))
    #: Sync buckets (`lib.ff.sync`): fingerprints of the lists (TMDB has no activities), see `sync_activities()`.
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = dict.fromkeys(('lists.watchlist', 'lists.favorites', 'lists.user', 'ratings'))
    #: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale (the ratings are fetched
    #: by `sync_activities()` itself).
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = {'lists.watchlist': 'watchlist', 'lists.favorites': 'favorite', 'lists.user': 'user'}
    #: Interval of the sync in the service (fingerprints cost more than activities).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.fingerprint_interval
    #: Sync buckets of the lists of the account by the name of the list (`user_general_lists()`).
    _LIST_BUCKETS: ClassVar[Mapping[str, SyncBucket]] = {'watchlist': 'lists.watchlist', 'favorite': 'lists.favorites'}

    # 2015:
    #   Movies - alternative_titles, changes, credits, images, keywords, lists, releases, reviews, similar, translations, videos
    #   TV - alternative_titles, changes, content_ratings, credits, external_ids, images, keywords, similar, translations, videos
    #   People - changes, combined_credits, external_ids, images, movie_credits, tagged_images, tv_credits
    # + (2015):
    #   genre_ids, original_language and overview

    DISCOVER_FILTERS = {
        'air_date.gte': dt_date,
        'air_date.lte': dt_date,
        'first_air_year': int,
        'first_air_date.gte': dt_date,
        'first_air_date.lte': dt_date,
        'include_null_first_air_dates': bool,
        'screened_theatrically': bool,
        'timezone': str,
        'with_networks': int,
        'with_status': Union[str, Literal[0, 1, 2, 3, 4, 5]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region
        'with_type': Union[str, Literal[0, 1, 2, 3, 4, 5, 6]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region

        'certification': str,
        'certification.gte': str,
        'certification.lte': str,
        'certification_country': str,
        'include_adult': bool,
        'include_video': bool,
        'language': str,
        'primary_release_year': int,
        'primary_release_date.gte': dt_date,
        'primary_release_date.lte': dt_date,
        'region': str,
        'release_date.gte': dt_date,
        'release_date.lte': dt_date,
        'sort_by': TmdbSortBy,
        'vote_average.gte': float,
        'vote_average.lte': float,
        'vote_count.gte': float,
        'vote_count.lte': float,
        'watch_region': str,
        'with_cast': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_companies': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_crew': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_genres': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_keywords': str,   # can be a comma (AND) or pipe (OR) separated query
        'with_origin_country': str,
        'with_original_language': str,
        'with_people': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_release_type': Union[str, Literal[1, 2, 3, 4, 5, 6]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region
        'with_runtime.gte': int,
        'with_runtime.lte': int,
        'with_text_query': str,
        'with_watch_monetization_types': Union[str, Literal['flatrate', 'free', 'ads', 'rent', 'buy']],  # use in conjunction with watch_region, can be a comma (AND) or pipe (OR) separated query
        'with_watch_providers': str,  # use in conjunction with watch_region, can be a comma (AND) or pipe (OR) separated query
        'without_companies': str,
        'without_genres': str,
        'without_keywords': Union[str, int, Sequence[int]],
        'without_watch_providers': str,
        'year': int,
        # --- conditional keywords ---
        'air_date': dt_date,
        'first_air_date': dt_date,
        'primary_release_date': Condition[str],
        'release_date': Condition[dt_date],
        'vote_average': Condition[float],
        'vote_count': Condition[float],
        'with_runtime': Condition[int],
    }

    # --- some dicovery conditions ---

    Date = Condition(dt_date)
    Int = Condition(int)
    Float = Condition(float)
    VoteCount = Int
    VoteAverage = Float
    Vote = VoteAverage
    Today = dt_date.today()
    Now = Today
    WeekAgo = Today - timedelta(days=7)

    # --- others ---

    EPISODE_TYPE_TO_FF: ClassVar[dict[Optional[str], EpisodeType]] = {
        'finale': 'season_finale',  # of 'series_finale' for some tvshow statuses, see get_episode_type()
        'mid_season': 'mid_season_finale',
    }

    # --- internal ---

    _main2tmdb_type: ClassVar[dict[MainMediaType, TmdbContentType]] = {
        'movie': 'movie',
        'show': 'tv',
    }

    _ref2tmdb_type: ClassVar[dict[RefType, TmdbContentDetailsType]] = {
        **_main2tmdb_type,
        'person': 'person',
        'collection': 'collection',
        'company': 'company',
        'network': 'network',
    }

    _main2tmdb_type2: ClassVar[dict[MainMediaType, TmdbContentPluralType]] = {
        'movie': 'movies',
        'show': 'tv',
    }

    _ref2rating: ClassVar[dict[MediaType, TmdbContentRatingType]] = {
        'movie': 'movies',
        'show': 'tv',
        'episode': 'tv/episodes',
    }

    _ext_id_results: ClassVar[dict[RefType, str]] = {
        'movie': 'movie_results',
        'show': 'tv_results',
        'season': 'tv_season_results',
        'episode': 'tv_episode_results',
        'person': 'person_results',
    }

    _search2tmdb: ClassVar[dict[SearchType, Optional[TmdbSearchType]]] = {
        'all': 'multi',
        'multi': 'multi',
        'movie': 'movie',
        'show': 'tv',
        'person': 'person',
        'collection': 'collection',
        'company': 'company',
        'keyword': 'keyword',
    }

    _person2ref: ClassVar[dict[PersonDataType, RefType]] = {
        'combined_credits': '',
        'movie_credits': 'movie',
        'tv_credits': 'show',
    }

    # NOT USED yet, got from https://developer.themoviedb.org/reference/movie-now-playing-list
    predef_lists = {
        'now_playing': 'include_adult=false&include_video=false&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}',
        'popular': 'include_adult=false&include_video=false&sort_by=popularity.desc',
        'top_rated': 'include_adult=false&include_video=false&sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200',
        'upcoming': 'include_adult=false&include_video=false&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}',
    }

    Skel = SkelOptions

    # Media (like images) EN locales
    EN_LOCALES: ClassVar[Sequence[str]] = ('en-US', 'en-GB', 'en')
    # Media (like image) non-locales
    NON_LOCALES: ClassVar[Sequence[str]] = ('xx-XX', 'xx', 'null')

    #: TMDB API page, it's not possibl to change it, but it is used in some calculations.
    PAGE_SIZE: ClassVar[int] = 20
    #: The last page TMDB API gives (discover, search, lists: a higher one is 400 "Invalid page").
    MAX_PAGE: ClassVar[int] = 500

    _DEBUG_STATS: ClassVar[TmdbApiStats] = TmdbApiStats()
    _FAKE: ClassVar[bool] = False

    def __init__(self, account: Account | None = None, *, alias: str = '', api_key: Optional[str] = None, lang: Optional[str] = None,
                 auth_api_version: ApiVer = CONST_REF.tmdb.auth.api, bearer: Optional[str] = None) -> None:
        # The account of the client: given, the first TMDB account (alias) or none (the application client, e.g. ffinfo).
        super().__init__(account, alias=alias)
        if api_key is None:
            api_key = const.dev.tmdb.api_key or apis.tmdb_API
        if bearer is None:
            bearer = const.dev.tmdb.v4.bearer or apis.tmdb_bearer
        #: TMDB base URL.
        self.base: str = 'https://api.themoviedb.org/'
        #: Base API version (`CONST_REF`: read at a request, a long living client follows a reload of `const`).
        self.auth_api_version: ApiVer = auth_api_version
        #: TMDB base URL for v3.
        self.base3: str = f'{self.base}3'
        #: TMDB base URL for v4.
        self.base4: str = f'{self.base}4'
        #: URL to image profile image.
        self.art_image_url: str = 'https://image.tmdb.org/t/p/w780'
        #: URL to image profile image.
        self.art_landscape_url: str = 'https://image.tmdb.org/t/p/w1280'
        #: URL to art image with formating.
        self.art_image_url_fmt: str = 'https://image.tmdb.org/t/p/{width}{path}'
        #: URL to person profile image.
        self.person_image_url: str = 'https://image.tmdb.org/t/p/w300_and_h450_bestv2'
        #: TMDB API key for direct use. If None, credentials() must be overloaded.
        self.api_key: Optional[str] = api_key
        #: TMDB API v4 auth bearer for direct use. If None, credentials() must be overloaded.
        self.bearer: Optional[str] = bearer
        #: TMDB response locale (e.g. pl-PL).
        self.lang: Optional[str] = lang  # or 'pl-PL'
        #: Timestamp to hold requests until rate is enabled.
        self.hold_until: float = 0
        #: Internal lock to protect common data (like `hold_until`).
        self.lock = Lock()
        #: The number of the connections of the semaphore and of the HTTP pool (`const.tmdb.connection.max` when they were made).
        self._conn_limit: int = 0
        #: Semaphore to limit connections number.
        self._conn_semaphore: Semaphore = Semaphore()
        #: HTTP session (`const.tmdb.connection.common_session`).
        self._session: requests.Session | None = None

    def _update_locale(self, lang: str | None = None) -> str:
        """Update locale (from settings), e.g. 'pl-PL'."""
        if lang is None:
            if self.lang is None:
                from ..ff.control import apiLanguage
                self.lang = apiLanguage().get('tmdb', 'pl-PL')
            lang = self.lang
        return lang

    @property
    def locale(self) -> str:
        """Return locale (language) for API requests, e.g. 'pl-PL'."""
        return self._update_locale()

    def _prepare_credentials(self, *, params: Optional[Params] = None, credentials: Optional[TmdbCredentials] = None) -> Tuple[Params, Headers]:
        """Helper. Prepare creadentials, params and headers."""
        if credentials is None:
            credentials = self.credentials()
        if params is None:
            params = {}
        headers = {
            'Accept': 'application/json',
        }
        # The user v4 token, else a bearer: given, or of the application - not with the own key of the user (TMDB takes the
        # bearer over `api_key`, the own key would be sent for nothing).
        if credentials.v4:
            headers['Authorization'] = f'Bearer {credentials.access_token}'
        elif v4_bearer := credentials.bearer or (None if credentials.api_key else self.bearer or const.dev.tmdb.v4.bearer or apis.tmdb_bearer):
            headers['Authorization'] = f'Bearer {v4_bearer}'
        if api_key := credentials.api_key or self.api_key or apis.tmdb_API:
            params.setdefault('api_key', api_key)
            if credentials.v3:
                params.setdefault('session_id', credentials.session_id)
        return params, headers

    def _honorate_rate_limit(self) -> None:
        """Honorate TMDB max rate limit. Sleep if limit is exceeded."""
        with self.lock:
            now = monotonic()
            delay = max(0, self.hold_until - now)
        if delay:
            xsleep(delay)

    def _process_status_code(self, status_code: int) -> bool:
        """Process REST status code and return True if got response, False if should repeat."""
        if status_code == 0:
            xsleep(const.tmdb.connection.try_delay)
            return False
        # Connection Error | Rate Limit Exceeded
        elif status_code == 429:
            # See: https://developer.themoviedb.org/docs/rate-limiting
            fflog(f'[TMDB] Rate limit exceeded {status_code}')
            with self.lock:
                if not self.hold_until:
                    self.hold_until = monotonic() + const.tmdb.connection.try_delay
            return False
        # Gateway Error - site is not avaliable
        elif status_code == 502:
            xsleep(5 * const.tmdb.connection.try_delay)
            return False
        with self.lock:
            self.hold_until = 0
        return True

    @staticmethod
    def connections() -> int:
        """Return the number of the concurrent connections to TMDB (`const.tmdb.connection.max`): the semaphore, the HTTP pool, the threads of a map."""
        return max(1, const.tmdb.connection.max)

    def executor(self) -> RequestsPoolExecutor:
        """Return a pool of threads of TMDB requests (a map of many): as many threads as the connections."""
        return RequestsPoolExecutor(self.connections())

    @property
    def conn_semaphore(self) -> Semaphore:
        """Return the semaphore of the connections, a new one with a new HTTP pool when `const.tmdb.connection.max` changed (a reload of const)."""
        with self.lock:
            if (limit := self.connections()) != self._conn_limit:
                self._conn_limit, self._conn_semaphore, self._session = limit, Semaphore(limit), None
            return self._conn_semaphore

    def session(self) -> requests.Session:
        """Return the HTTP session: the common one of the client, a new one if `const.tmdb.connection.common_session` is off."""
        if not const.tmdb.connection.common_session:
            return requests.Session()
        if self._session is None:
            self._session = sess = requests.Session()
            sess.mount(self.base, requests._requests.adapters.HTTPAdapter(pool_maxsize=self.connections()))
        return self._session

    def _get_json(self, path: str, params: Params, headers: Headers) -> JsonData:
        """
        GET `/3/<path>` with retries, return its JSON. No usable answer (no connection, timeout, a not JSON or an error
        answer without the TMDB error JSON) is the TMDB error shape `{'success': False, 'status_code': 0}` (0 is not
        a TMDB code, e.g. not 34 "not found"): nothing to parse nor to cache, asked again next time.
        """
        self._DEBUG_STATS.request_count += 1
        status_code = 0
        resp: requests.Response | None = None
        for _ in range(const.tmdb.connection.try_count or 1):
            self._honorate_rate_limit()
            status_code = 0
            resp = None
            start = monotonic()
            try:
                with self.conn_semaphore:  # the connections of the client, its common session
                    resp = self.session().get(f'{self.base3}/{path}', params=params, headers=headers, timeout=const.tmdb.connection.timeout)
                status_code = resp.status_code
            except (requests.ConnectionError, requests.RequestException):
                pass
            except Exception as exc:
                fflog(f'TMDB get failed: {exc}, url={self.base3}/{path}, params={params}')
                raise
            finally:
                T = monotonic() - start  # a failed request too
                params_str = repr(params)
                if session_id := params.get('session_id'):
                    params_str = params_str.replace(session_id, '...')
                S = len(resp.content) / 1_048_576 if resp else 0
                if const.debug.tty:
                    import sty
                    log_label = f'[FF][TMDB]{sty.bg.da_green}[API]{sty.rs.bg}'
                else:
                    log_label = '[FF][TMDB][API]'
                fflog(f'{log_label} {status_code:03d} ({T:.3f}s, {S:.2f}MB) /3/{path} params={params_str}')
            if self._process_status_code(status_code):
                break
        if resp is None:
            fflog(f'[FF][TMDB] connection FAILED for {path}')
            return _no_answer()
        try:
            data = resp.json()
        except ValueError:
            data = None
        if status_code >= 400:
            fflog(f'[FF][TMDB] ERROR {status_code} for {path}')
            if not _failed(data):
                return _no_answer()  # e.g. 502 HTML
        elif not isinstance(data, Mapping):
            return _no_answer()
        return data

    # @logtime
    def request(self,
                method: Method,
                url: str,
                *,
                credentials: Optional[TmdbCredentials] = None,
                api_version: Literal[3, 4] = 3,
                data: Optional[JsonData] = None,
                params: Optional[KwArgs] = None,
                append_to_response: Sequence[str] = (),
                lang: Optional[str] = None,
                errors: Literal['strict', 'ignore'] = 'ignore',
                expected_errors: Sequence[int] = (),
                ) -> Optional[requests.Response]:
        """Request to API."""

        def cond_params(params: KwArgs) -> Generator[Tuple[str, Any], None, None]:
            for k, v in params.items():
                if isinstance(v, Condition):
                    for cmp, val in v.cond:
                        # if val is True:
                        #     val = 'true'
                        # elif val is False:
                        #     val = 'false'
                        yield f'{k}.{cmp}', val
                else:
                    # if v is True:
                    #     v = 'true'
                    # elif v is False:
                    #     v = 'false'
                    yield k, v

        if self._FAKE:
            return None
        url = urljoin(f'{self.base}/{api_version}/', url)
        # headers = {
        #     'Accept': 'application/json',
        # }
        # if credentials is None:
        #     credentials = self.credentials()

        # append_to_response = ['external_ids', 'release_dates', 'translations']  # 'images', 'original_language'
        request_params = params
        params = dict(cond_params(params or {}))
        if credentials is None:
            credentials = self.credentials()
        if credentials.api_key and credentials.api_key == TmdbApi._own_key_rejected:
            credentials = evolve(credentials, api_key=None)  # rejected in this process: the application key
        # if v4_bearer := credentials.bearer or self.bearer or const.dev.tmdb.v4.bearer or apis.tmdb_bearer:
        #     headers['Authorization'] = f'Bearer {v4_bearer}'
        #     if credentials.v4:
        #         headers['Authorization'] = f'Bearer {credentials.access_token}'
        # if api_key := credentials.api_key or self.api_key or apis.tmdb_API:
        #     params.setdefault('api_key', api_key)
        #     if credentials.v3:
        #         params.setdefault('session_id', credentials.session_id)
        params, headers = self._prepare_credentials(credentials=credentials, params=params)
        if params.get('page') == 0:
            params['page'] = 1
        if append_to_response:
            params.setdefault('append_to_response', ','.join(append_to_response))
        lang = self._update_locale(lang)
        if lang:
            params['language'] = lang
        # fflog(f'[FF][TMDB] {url=}, {params=}')

        resp = None
        status_code: int = 0
        T = monotonic()
        try:
            for _ in range(const.tmdb.connection.try_count or 1):
                self._DEBUG_STATS.request_count += 1
                self._honorate_rate_limit()
                try:
                    # resp = requests.request(method, url, json=data, params=params, headers=headers,
                    #                         timeout=const.tmdb.connection.timeout)
                    with self.conn_semaphore:
                        resp = self.session().request(method, url, json=data, params=params, headers=headers, timeout=const.tmdb.connection.timeout)
                    status_code = resp.status_code
                except requests.ConnectionError:
                    status_code = 0
                except requests.RequestException:
                    if errors != 'ignore':
                        raise
                    status_code = 0
                if self._process_status_code(status_code):
                    break
            T = monotonic() - T
        except Exception as exc:
            fflog(f'TMDB get failed: {exc}, url={url}, params={params}')
            raise
        finally:
            from ..ff.tricks import str_removeprefix
            params_str = repr(params)
            if session_id := params.get('session_id'):
                params_str = params_str.replace(session_id, '...')
            S = len(resp.content) / 1_048_576 if resp else 0
            if const.debug.tty:
                import sty
                log_label = f'[FF][TMDB]{sty.bg.da_green}[API]{sty.rs.bg}'
            else:
                log_label = '[FF][TMDB][API]'
            fflog(f'{log_label} {status_code:03d} ({T:.3f}s, {S:.2f}MB) /{str_removeprefix(url, self.base)} params={params_str}')

        if resp is None:
            return None

        # Success
        if 100 <= status_code <= 299:
            return resp

        if status_code >= 500:  # temporary
            if status_code not in expected_errors:
                fflog(f'[TMDB] Temporary error {status_code}')
            return None
        if status_code >= 400:  # permanent
            if status_code in expected_errors:
                return resp  # the caller checks it (e.g. 404: a removed entry)
            fflog(f'[TMDB] Error {status_code}\n{resp.text}')
            if status_code == 401 and credentials.api_key and not credentials.v3 and not credentials.v4:
                # the own key of the user is rejected (no user session to blame): the application key from now on, told once
                self._reject_own_key(credentials.api_key)
                return self.request(method, url, credentials=evolve(credentials, api_key=None), api_version=api_version, data=data,
                                    params=request_params, append_to_response=append_to_response, lang=lang, errors=errors,
                                    expected_errors=expected_errors)
            if status_code == 401:  # Authentication failed
                self.auth_failed()
            return None

    def get(self, url: str, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonResult]:
        """Send GET request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('GET', url, data=None, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def post(self, url: str, data: JsonData | None, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonData]:
        """Send POST request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('POST', url, data=data, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def delete(self, url: str, data: JsonData | None = None, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonData]:
        """Send POST request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('DELETE', url, data=data, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def auth(self, *, credentials: Optional[TmdbCredentials] = None, force: bool = False) -> bool | None:
        """Authorize user and create new session / token: True if authorized, False if failed, None if canceled by the user."""
        if const_value(self.auth_api_version) == 3:
            return self.auth_v3(credentials=credentials, force=force)
        return self.auth_v4(credentials=credentials, force=force)

    def auth_v3(self, *, credentials: Optional[TmdbCredentials] = None, force: bool = False) -> bool | None:
        """Authorize user and create new v3 session (login and password of the account, e.g. migrated from the settings; else v4)."""
        if credentials is None:
            credentials = self.credentials()
        if self.account is None or not credentials.user:
            return self.auth_v4(credentials=credentials, force=force)
        if not force and credentials:
            return True  # already authorized
        credentials = evolve(credentials, session_id=None)
        if not credentials.user or not credentials.password:
            return False
        data = self.get('authentication/token/new', credentials=credentials)
        if not isinstance(data, Mapping):
            return False
        token = data.get('request_token')
        if not token:
            return False
        data = self.post('authentication/token/validate_with_login', credentials=credentials, data={
            'username': credentials.user,
            'password': credentials.password,
            'request_token': token,
        })
        if not data:
            return False
        data = self.post('authentication/session/new', credentials=credentials, data={'request_token': token})
        if not isinstance(data, Mapping) or not data.get('success'):
            return False
        self.save_session(session_id=data['session_id'])
        return True

    def auth_v4(self, *, credentials: Optional[TmdbCredentials] = None, force: bool = False) -> bool | None:
        """Authorize user and create new v4 access token and v3 session: True / False (failed) / None (canceled by the user)."""
        if credentials is None:
            credentials = self.credentials()
        if not force and credentials.v3 and credentials.v4:
            return True  # already authorized
        if force:
            credentials = evolve(credentials, access_token=None, session_id=None)

        if not credentials.v4:
            start = monotonic()
            data = self.post('auth/request_token', data={}, api_version=4, credentials=credentials)
            if not isinstance(data, Mapping) or not data.get('success') or not (request_token := data.get('request_token')):
                fflog.info(f'TMDB auth (v4) FAILED: no request token')
                return False
            # Create (progress-bar) dialog.
            # print(f'https://www.themoviedb.org/auth/access?request_token={request_token}')
            expires_in = const.tmdb.auth.dialog_expire  # max 15 min
            interval = const.tmdb.auth.dialog_interval
            # Continue as long as not expire or user authorized or user canceled.
            from ..ff.ui import ui
            from ..kolang import L
            access_token: str = ''
            url = f'https://www.themoviedb.org/auth/access?request_token={request_token}'
            with ui.auth_session(title=L(30364, '[B]Authorize TMDB[/B]'), url=url) as session:
                try:
                    while True:
                        #: Current timestamp.
                        now: float = monotonic()
                        # check in expires...
                        if start + expires_in < now:
                            fflog.info(f'TMDB auth (v4) FAILED: no access token in {expires_in} seconds')
                            return False
                        # check if the user canceled
                        if session.is_canceled():
                            return None
                        if access_token := self._get_access_token(request_token, credentials=credentials):
                            break
                        session.update(100 * (now - start) / expires_in)
                        # sleep given interval
                        xsleep(interval)
                except KeyboardInterrupt:
                    print('''\nCancelled. Enter '0'.\n''')
                    return None
            if not access_token:
                return False
            credentials = evolve(credentials, access_token=access_token)

        if not credentials.v3:
            data = self.post('authentication/session/convert/4', data={'access_token': credentials.access_token}, credentials=credentials)
            if not isinstance(data, Mapping) or not data.get('success') or not (session_id := data.get('session_id')):
                fflog.info(f'TMDB auth (v4) FAILED: no v3 session id')
                return False
            credentials = evolve(credentials, session_id=session_id)

        self.save_session(access_token=credentials.access_token, session_id=credentials.session_id)
        return True

    def _get_access_token(self, request_token: str, *, credentials: Optional[TmdbCredentials] = None) -> str:
        """Retrive access_token if request_token is accepted by user (on web site)."""
        data = self.post('auth/access_token', data={}, params={'request_token': request_token}, api_version=4,
                         credentials=credentials, expected_errors=[422])
        # access_token, account_id (can be obtain from access_token)
        if isinstance(data, Mapping) and data.get('success') and (access_token := data.get('access_token')):
            return access_token
        return ''

    def revoke_session(self, *, credentials: Optional[TmdbCredentials] = None) -> bool:
        """Revoke the session (logout user)."""
        if credentials is None:
            credentials = self.credentials()
        if not credentials:
            return True  # no session, already done
        success = True
        if credentials.v4:
            data = self.delete('auth/access_token', data={'access_token': credentials.access_token}, api_version=4)
            if not isinstance(data, Mapping) or not data.get('success'):
                success = False
        if credentials.v3:
            data = self.delete('authentication/session', credentials=credentials, data={'session_id': credentials.session_id})
            if not isinstance(data, Mapping) or not data.get('success'):
                success = False
        self.save_session(session_id=None, access_token=None)  # forgot session_id (v3) and access_token (v4)
        return success

    unauth = revoke_session

    def _ref_id_to_tmdb(self, ref_id: T, /) -> T:
        if isinstance(ref_id, int) and ref_id in VideoIds.TMDB:
            ref_id = VideoIds.TMDB.index(ref_id)
        return ref_id

    def _parse_art(self, *, item: JsonData, translation_order: Sequence[str], skip_fanart: bool) -> Dict[str, str]:
        """Pre-parse art images. Much simpler version of Art.parse_art()."""
        from ..ff.art import TmbdArtService
        images = item.get('images') or {}
        art_langs = (*dict.fromkeys(loc.partition('-')[0] for loc in translation_order), *(None,))
        no_langs = ('00', 'xx', 'null', None)
        art: Dict[str, str] = {}
        for aname, artdef in TmbdArtService.art_names.items():
            for src in artdef.sources:
                ilist = images.get(src.key)
                if ilist:
                    for lng in artdef.langs(yes=art_langs, no=no_langs, skip_fanart=skip_fanart):
                        for ielem in ilist:
                            if ielem.get('iso_639_1') == lng and (path := ielem['file_path']):
                                art[aname] = f'{self.art_image_url}{path}'
                                break
                        else:
                            continue
                        break
                    else:
                        continue
                    break
        return art

    def get_media_by_ref(self,
                         req: MediaRequest,
                         *,
                         credentials: Optional[TmdbCredentials] = None,
                         # --- for internal use only ---
                         queue: Queue | None = None,
                         ) -> TmdbItemJson:
        """Get single media by reference."""
        def get(path: str, params: dict[str, Any]) -> JsonData:
            """GET the TMDB path (the failure shape on no answer, see `_get_json()`)."""
            return self._get_json(path, params, headers)

        details = req.details
        seasons = req.seasons
        ref = req.ref
        rtype = ref.real_type
        cred_params, headers = self._prepare_credentials(credentials=credentials)
        params = dict(cred_params)
        imode = GetImageMode(const.tmdb.get_image_mode)
        respapp = req.append_to_response
        tv_seasons = req.seasons

        data: JsonData = {}
        if details & (InfoDetails.INFO_LANG | InfoDetails.INFO_ORIG):
            locale = req.locale or self._update_locale()
        elif details & InfoDetails.INFO_EN:
            locale = 'en-US'
        else:
            fflog.error(f'No InfoDetails.INFO_* locale set for {ref}, skipped')
            return _no_answer()
        lang = locale.partition('-')[0] if locale else 'en'

        # prepare request
        params['append_to_response'] = ','.join(respapp)
        if locale:
            params['language'] = locale
        if 'images' in respapp:
            lang = locale.partition('-')[0] if locale else 'en'
            if imode is GetImageMode.APPEND_EN:
                params['include_image_language'] = 'en'
            elif imode is GetImageMode.APPEND_LANG:
                params['include_image_language'] = lang
            else:
                params['include_image_language'] = ','.join(dict.fromkeys((lang, 'en', 'xx', 'null')))
        if 'videos' in respapp:
            lang = locale.partition('-')[0] if locale else 'en'
            params['include_video_language'] = ','.join(dict.fromkeys((lang, 'en', 'xx', 'null')))
        if ref.type == 'movie':
            path = f'movie/{ref.tmdb_id}'
        elif ref.type == 'show':
            tmdb_tv_tuple = ref.tmdb_tv_tuple
            if (details & InfoDetails.EPISODE_SKIP) and ref.episode is not None:
                fflog.warning(f'Ignoring episode number for show ref {ref}  ({details=}:{details.value:03x})')
            path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], tmdb_tv_tuple))
        elif ref.type in get_typing_args(DetailsAllowed):
            path = f'{ref.type}/{ref.tmdb_id}'
        else:
            # non DetailsAllowed type
            raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')

        # receive tmdb data with images
        if imode is GetImageMode.ALL:
            with RequestsPoolExecutor() as ex:
                obj = ex.submit(get, path, params)
                if details & InfoDetails.IMAGES:
                    img = ex.submit(get, f'{path}/images', cred_params)
            data = obj.result()
            if details & InfoDetails.IMAGES and not _failed(data):
                data['images'] = img.result()  # type: ignore[reportPossiblyUnboundVariable]
        else:
            data = get(path, params)
            if details & InfoDetails.IMAGES and imode is GetImageMode.PULL and not _failed(data):
                orig_lang: str = data.get('original_language', 'en')
                trans_order = tuple(dict.fromkeys((locale, lang, *self.EN_LOCALES, *self.NON_LOCALES,
                                                   *(f'{orig_lang}-{c}' for c in data.get('origin_country', ())), orig_lang)))
                art = self._parse_art(item=data, translation_order=trans_order, skip_fanart=ref.is_episode)
                if not all(art.get(a) for a in ('fanart', 'landscape', 'poster', 'clearlogo')):
                    data['images'] = get(f'{path}/images', cred_params)
        # an incomplete answer is no answer: the node (its fingerprint is of the request) would be cached without a part
        if _failed(data):
            return data
        if _failed(data.get('images')):
            return data['images']

        # fix up extra seasons and theirs episodes
        if (details & InfoDetails.SHOW_SEASONS or tv_seasons) and rtype == 'show':
            # get missing seasons (if more then const.tmdb.append_to_response_limit)
            if details & InfoDetails.SHOW_SEASONS:
                seasons_need = {sz['season_number'] for sz in data.get('seasons', ())}
            else:
                seasons_need = set(tv_seasons)
            seasons_got = {int(sznum) for asz in data if asz.startswith('season/') if (sznum := asz.partition('/')[2]).isdigit()}
            missing_seasons = seasons_need - seasons_got
            if missing_seasons:
                data2: JsonData
                self._DEBUG_STATS.extra_seasons_count += 1
                scount = const.tmdb.append_to_response_limit
                if len(missing_seasons) > scount:
                    def get_seasons(nums):
                        sz_params = {**params, 'append_to_response': ','.join(f'season/{sz}' for sz in nums)}
                        return get(path, sz_params)

                    self._DEBUG_STATS.multi_seasons_count += 1
                    with RequestsPoolExecutor() as ex:
                        for data2 in ex.map(get_seasons, batched(missing_seasons, scount)):
                            if _failed(data2):
                                return data2
                            data.update(data2)
                else:
                    # get extra info about missing show seasons
                    params['append_to_response'] = ','.join(f'season/{sz}' for sz in missing_seasons)
                    data2 = get(path, params)
                    if _failed(data2):
                        return data2
                    data.update(data2)

        # udpate main season list
        if rtype == 'show':
            for sz in data.get('seasons') or ():
                num: int = sz['season_number']
                sz['_ref'] = ref.with_season(num)
                sz['_type'] = 'season'
                if ex := data.get(f'season/{num}'):
                    sz.update(ex)

        # merge received data
        # for req in media_requests:
        #     if req.key:
        #         data[req.key] = req.data
        #     else:
        #         data.update(req.data)

        data['_ref'] = ref
        data['_type'] = rtype
        data['_request'] = req
        if rtype == 'episode':
            if tv_vid := VideoIds.from_ffid(ref.ffid):
                data.setdefault('show_id', tv_vid.tmdb)
        return data

    # @logtime
    def get_media_list_by_ref(self, refs: Sequence[MediaRef], *, details: InfoDetails = InfoDetails.DEFAULT,
                              credentials: Optional[TmdbCredentials] = None) -> List[TmdbItemJson]:
        """Get list of media by theris references."""
        raise AssertionError('DEPRECATED')

    @logtime(name='[FF][TMDB] get_media_dict_by_ref')
    def get_media_dict_by_ref(self,
                              refs: Iterable[FFRef | MediaRequest],
                              *,
                              details: InfoDetails = InfoDetails.DEFAULT,
                              credentials: Optional[TmdbCredentials] = None,
                              ) -> Dict[MediaRef, TmdbItemJson]:
        """Get dict of media by theirs references."""
        def get(req: MediaRequest) -> TmdbItemJson:
            data: TmdbItemJson = {}
            try:
                data = self.get_media_by_ref(req, credentials=credentials, queue=queue)
                return data
            finally:
                ref = req.ref
                signal = (ref, None)  # signal end of movie, show to cancel original request
                # if ref.season is None and req.details & InfoDetails.INFO_ORIG:
                if ref.season is None:
                    orign_lang = data.get('original_language')
                    origin_country = next(iter(data.get('origin_country') or ()), None)
                    if orign_lang and origin_country:
                        orig_locale = f'{orign_lang.lower()}-{origin_country.upper()}'
                        if orig_locale not in (LOCALE_EN, locale):
                            signal = (ref, orig_locale)  # signal end of movie, show to submit original request
                fflog.debug(f'[FF][TMDB] Signal request {signal[0]:a}: {signal[1]!r}')
                queue.put(signal)  # signal end of movie, show ...

        def create_requests(ref: FFRef | MediaRequest) -> Iterator[MediaRequest]:
            """Split request by locales if needed."""
            if isinstance(ref, MediaRequest):
                req_details = details if ref.details == InfoDetails.NOT_DEFINED else ref.details
                req_locale = ref.locale
                item = ref.item
                seasons = ref.seasons
            else:
                req_details = details
                req_locale = ''
                item = ref
                seasons = None
            det = req_details
            if det & InfoDetails.INFO_LANG:
                det &= ~InfoDetails.INFO_EN
                yield MediaRequest(item, details=det, locale=req_locale or locale, seasons=seasons)
            det = req_details
            if det & InfoDetails.INFO_EN:
                if det & InfoDetails.INFO_LANG:
                    det &= ~(InfoDetails.DETAILS | InfoDetails.AGGREGATE_CREDITS)  # all details are in INFO_EN request
                det &= ~InfoDetails.INFO_LANG
                yield MediaRequest(item, details=det, locale=req_locale or LOCALE_EN, seasons=seasons)

        optimize = not details & InfoDetails.NO_OPTIMIZE
        locale = self._update_locale()

        # convert to MediaRequest
        requesting = MediaRequestDict((req.key, req) for ref in refs for req in create_requests(ref))

        # collapse requests (same ref and locale)
        for req in tuple(requesting.all_values()):
            ref, loc = req.ref, req.locale
            if req.details & (InfoDetails.INFO_EN | InfoDetails.INFO_ORIG):
                for req2 in requesting[ref].values():
                    if req2 is not req and req2.ref == ref and req2.details & InfoDetails.TRANSLATIONS:
                        if ref.is_show and req.details & (InfoDetails.SEASON_EN | InfoDetails.SEASON_ORIG):
                            break  # keep both requests, need more languages for seasons
                        if ref.is_season and req.details & InfoDetails.SKIP_EPISODES:
                            if req.details & InfoDetails.INFO_LANG:
                                req2.details &= ~(InfoDetails.DETAILS | InfoDetails.AGGREGATE_CREDITS | InfoDetails.SHOW_DETAILS)
                            else:
                                req.details &= ~(InfoDetails.DETAILS | InfoDetails.AGGREGATE_CREDITS | InfoDetails.SHOW_DETAILS)
                            break  # keep both requests, need more languages for episodes
                        # remove en or original lang request, they are in translations
                        if req.details & InfoDetails.INFO_LANG:
                            del requesting[req2.key]
                        else:
                            del requesting[req.key]
                        break

        # support seasons languages (from shows)
        for req in tuple(requesting.all_values()):
            ref = req.ref
            if ref.is_show and req.details & (InfoDetails.SEASON_EN | InfoDetails.SEASON_ORIG):
                if req.details & InfoDetails.SEASON_EN:
                    xreq = requesting.setdefault((ref, LOCALE_EN), MediaRequest(ref, details=InfoDetails.NONE, locale=LOCALE_EN))
                    xreq.details |= InfoDetails.INFO_EN
                if req.details & InfoDetails.SEASON_ORIG:
                    xreq = requesting.setdefault((ref, LOCALE_ORIG), MediaRequest(ref, details=InfoDetails.NONE, locale=LOCALE_ORIG))
                    xreq.details |= InfoDetails.INFO_ORIG

        # expand seasons (from episodes)
        for req in tuple(requesting.all_values()):
            ref, loc = req.ref, req.locale
            # season with all episodes
            if ref.is_season and req.details & InfoDetails.SEASON_EPISODES:
                if req.details & InfoDetails.SKIP_EPISODES:
                    if req.details & InfoDetails.EPISODE_EN:
                        xreq = requesting.setdefault((ref, LOCALE_EN), MediaRequest(ref, details=InfoDetails.NONE, locale=LOCALE_EN))
                        xreq.details |= InfoDetails.INFO_EN | InfoDetails.SEASON_EN
                else:
                    ...  # add all episodes ???

        # append seasons (from episodes)
        for req in tuple(requesting.all_values()):
            ref, loc = req.ref, req.locale
            # episode from season
            if ref.is_episode and req.details & (InfoDetails._GET_SEASON | InfoDetails.SKIP_EPISODES):
                if xref := req.ref.season_ref:
                    xreq = requesting.setdefault((xref, loc), MediaRequest(xref, details=InfoDetails.NONE, locale=loc))
                    xreq.details |= req.details.season()
                    if req.details & InfoDetails.EPISODE_EN:
                        xreq = requesting.setdefault((xref, LOCALE_EN), MediaRequest(xref, details=InfoDetails.NONE, locale=LOCALE_EN))
                        xreq.details |= InfoDetails.INFO_EN

        # append shows (from seasons and episodes)
        for req in tuple(requesting.all_values()):
            ref, loc = req.ref, req.locale
            if ref.season is not None and req.details & InfoDetails._GET_SHOW:
                if xref := req.ref.show_ref:
                    xreq = requesting.setdefault((xref, loc), MediaRequest(xref, details=InfoDetails.NONE, locale=loc))
                    xreq.details |= req.details.show(seasons=True)

        # remove episodes and force more season details (more locales)
        for req in tuple(requesting.all_values()):
            ref, loc = req.ref, req.locale
            if ref.is_episode and req.details & InfoDetails.SKIP_EPISODES:
                if xref := req.ref.season_ref:
                    if req.details & InfoDetails.EPISODE_EN:
                        xreq = MediaRequest(xref, details=InfoDetails.INFO_EN, locale=LOCALE_EN)
                        requesting.setdefault(xreq.key, xreq)
                    if (req.details & InfoDetails.EPISODE_ORIG) and (xreq := requesting.get((xref, loc))):
                        xreq.details |= InfoDetails.INFO_ORIG
                del requesting[ref, loc]  # remove episode

        # add seasons languages (from shows with seasons with episodes: SHOW_SEASONS or requested seasons), the episodes come with them
        for req in tuple(requesting.all_values()):
            ref = req.ref
            if ref.is_show and (req.details & InfoDetails.SHOW_SEASONS or req.seasons):
                for flags, info, loc in ((InfoDetails.SEASON_EN | InfoDetails.EPISODE_EN, InfoDetails.INFO_EN, LOCALE_EN),
                                         (InfoDetails.SEASON_ORIG | InfoDetails.EPISODE_ORIG, InfoDetails.INFO_ORIG, LOCALE_ORIG)):
                    if req.details & flags:
                        xreq = MediaRequest(ref, details=InfoDetails.NONE, locale=loc)
                        xreq = requesting.setdefault(xreq.key, xreq)
                        xreq.details |= info | (req.details & InfoDetails.SHOW_SEASONS)
                        if req.seasons:
                            xreq.seasons = sorted({*(xreq.seasons or ()), *req.seasons})

        # update append_to_response for all shows
        for req in requesting.all_values():
            if req.ref.is_show:
                req.append_to_response  # update append_to_response

        # optimize seasons (with show request)
        if optimize:
            def append_to_show(xref: MediaRef, loc: str, key: str, details: InfoDetails) -> bool:
                xreq = requesting.setdefault((xref, loc), MediaRequest(xref, details=details, locale=loc))
                # a show with all seasons gets every season (over the append limit by extra requests, see `get_media_by_ref()`)
                if key in xreq.append_to_response or xreq.details & InfoDetails.SHOW_SEASONS:
                    return True
                if len(xreq.append_to_response) < limit:
                    xreq.append_to_response.append(key)
                    return True
                return False

            limit = const.tmdb.append_to_response_limit
            for req in tuple(requesting.all_values()):
                ref, loc = req.ref, req.locale
                if ref.is_season and not req.details & InfoDetails.NO_OPTIMIZE and (xref := ref.show_ref):
                    key = f'season/{ref.season}'
                    delete = True
                    if not append_to_show(xref, loc, key, InfoDetails.INFO_LANG):
                        delete = False
                    if req.details & (InfoDetails.INFO_EN | InfoDetails.SEASON_EN):
                        if not append_to_show(xref, LOCALE_EN, key, InfoDetails.INFO_EN):
                            delete = False
                    if req.details & (InfoDetails.INFO_ORIG | InfoDetails.SEASON_ORIG):
                        if not append_to_show(xref, LOCALE_ORIG, key, InfoDetails.INFO_ORIG):
                            delete = False
                    if delete:
                        del requesting[req.key]  # remove season request, it is just append in show request

        requests = [req for req in requesting.all_values() if req.details & (InfoDetails.INFO_LANG | InfoDetails.INFO_EN)]
        postponed = [req for req in requesting.all_values() if req.details & InfoDetails.INFO_ORIG]

        # debug...
        if 1:
            fflog.debug('[FF][TMDB] --- Requests:')
            for req in requests:
                fflog.debug(f' - {req}')
            fflog.debug('[FF][TMDB] --- Postponed:')
            for req in postponed:
                fflog.debug(f' - {req}')
            # raise SystemExit(0)
            fflog.debug('[FF][TMDB] ---')

        # postponed requests by original language
        orig_requests: dict[MediaRef, list[MediaRequest]] = {}
        for req in postponed:
            ref = req.ref
            if ref.type == 'show':
                ref = ref.show_ref or ref
            orig_requests.setdefault(ref, []).append(req)

        # get items
        if credentials is None:
            credentials = self.credentials()
        queue: Queue[tuple[MediaRef, str | None]] = Queue()
        postponed_jobs: list[tuple[MediaRequest, TmdbItemJson]] = []
        if len(requests) == 1 and not postponed:
            jobs = [get(next(iter(requests)))]
        else:
            with self.executor() as ex:
                jobs = ex.map(get, requests)
                if orig_requests:
                    if unsupported := {req.ref.main_ref for req in requests} - orig_requests.keys():
                        fflog.error(f'No original language info for {", ".join(f"{ref!a}" for ref in unsupported)}')
                        raise AssertionError(f'No original language info for {", ".join(f"{ref!a}" for ref in unsupported)}')
                postponed_futures: list[tuple[MediaRequest, Future[TmdbItemJson]]] = []
                while orig_requests:
                    ref, loc = queue.get()
                    for req in orig_requests.pop(ref, None) or ():  # remove all postponed requests for ref
                        if loc:  # locale is given - get original language info
                            if requesting.get((req.ref, loc)):
                                fflog(f'[FF][TMDB] Postponed request for {ref} locale={loc} canceled, already requested')
                            else:
                                fflog(f'[FF][TMDB] Postponed request for {ref} locale={loc}')
                                req.locale = loc
                                fut = ex.submit(get, req)
                                postponed_futures.append((req, fut))
                        else:
                            fflog(f'[FF][TMDB] No postponed request for {ref}')
                    postponed_jobs = [(req, fut.result()) for req, fut in postponed_futures]
        # raise SystemExit(0)

        # split merged sub-requests (e.g. season/N in show), ref could be many times
        items: list[tuple[MediaRequest, TmdbItemJson]] = []
        rx_subitem = re.compile(r'(season|episode)/(\d+)')
        for req, item in chain(zip(requests, jobs), postponed_jobs):
            items.append((req, item))
            for key, mch in [(key, mch) for key, val in item.items() if (mch := rx_subitem.fullmatch(key))]:
                name, num = mch[1], int(mch[2])
                if name == 'season':
                    xref = req.ref.with_season(num)
                    items.append((evolve(req, item=xref), item.pop(key)))
                elif name == 'episode':
                    xref = req.ref.with_episode(num)
                    items.append((evolve(req, item=xref), item.pop(key)))

        # generate item by ref (api lang)
        result: dict[MediaRef, TmdbItemJson] = {}
        for lang_flag_hit in (True, False):
            for req, item in items:
                item['_ref'] = req.ref
                item['_request'] = req
                item.setdefault('_type', req.ref.real_type)
                item.setdefault('id', 0)
                if bool(req.details & InfoDetails.INFO_LANG) ^ lang_flag_hit == 0:
                    data = result.setdefault(req.ref, item)
                    if data is not item:
                        locales = data.setdefault('_locales', {})
                        if locales.setdefault(req.locale, item) is not item:
                            print(f'[FF][TMDB] WARNING: Duplicate item for {req.ref:a} ({req.locale}), merged')
                        if req.details & InfoDetails.INFO_ORIG:
                            locales[LOCALE_ORIG] = item
        # a ref with a failed request (of any language) is no answer: it would be cached without that language
        result.update((req.ref, item) for req, item in items if _failed(item))
        # raise SystemExit(0)
        return result

    def list_refs(self, type: RefType, items: Sequence[Union[JsonData, FFItem]]) -> List[MediaRef]:
        """Get refs from media item list."""
        if items:
            elem = items[0]
            if isinstance(elem, (FFItem, MediaRef)):
                return [it.ref for it in cast(Sequence[FFItem], items)]
            if isinstance(elem, Mapping):
                return [MediaRef.from_tmdb(type, it.get('id', 0), season=None, episode=None) for it in items]
        return []

    def get_skel_en_media(self,
                          refs: Sequence[MediaRef],
                          *,
                          options: SkelOptions = SkelOptions.SHOW_LAST_SEASONS,
                          credentials: Optional[TmdbCredentials] = None,
                          ) -> Dict[MediaRef, TmdbItemJson]:
        """Load skeleton media info."""

        def req(path: str, *, params: Params, append: Sequence[str] = ()) -> JsonData:
            """GET the TMDB path with appended parts (the failure shape on no answer, see `_get_json()`)."""
            return self._get_json(path, {**params, 'append_to_response': ','.join(append)}, headers)

        def get(ref: MediaRef, par: Optional[Dict[str, Any]] = None) -> TmdbItemJson:
            if par is None:
                par = params
            rtype = ref.real_type
            r_append = list(append_to_response)

            append_season_number = 0
            if ref.type == 'movie':
                path = f'movie/{ref.tmdb_id}'
            elif ref.type == 'show':
                # path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
                path = f'tv/{ref.tmdb_id}'
                if ref.season:  # season and episode
                    r_append.append(f'season/{ref.season}')
                elif options & APPEND_SEASONS:
                    # try to match first 10 seasons, hope that it will be all seasons (then the last too)
                    if len(r_append) < const.tmdb.append_to_response_limit:
                        append_season_number = const.tmdb.append_to_response_limit - len(r_append)
                        r_append.extend(f'season/{i}' for i in range(1, append_season_number + 1))
            elif ref.type in ('person', 'collection'):
                path = f'{ref.type}/{ref.tmdb_id}'
            else:
                # non DetailsAllowed type
                raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')
            data = req(path, params=par, append=r_append)
            data['_ref'] = ref
            data['_type'] = rtype
            if _failed(data):
                return data  # parse_tmdb_skel_item() skips it
            last_season_number = max((z['season_number'] for z in data.get('seasons', ())), default=0) if ref.is_show else 0
            # obtain all seasons
            if last_season_number and options & SkelOptions.SHOW_ALL_SEASONS:
                for s_nums in batched(range(append_season_number, last_season_number), const.tmdb.append_to_response_limit):
                    r_append = [f'season/{i+1}' for i in s_nums]
                    s_data = req(path, params=par, append=r_append)
                    if _failed(s_data):
                        return {**s_data, '_ref': ref}  # an incomplete answer is no answer
                    for key in r_append:
                        data[key] = s_data[key]
            # obtain a last few seasons (if not received already)
            elif last_season_number and options & SkelOptions.SHOW_LAST_SEASONS and last_season_number > append_season_number:
                r_append = [f'season/{i+1}'
                            for i in range(max(append_season_number, last_season_number - const.tmdb.append_to_response_limit), last_season_number)]
                s_data = req(path, params=par, append=r_append)
                if _failed(s_data):
                    return {**s_data, '_ref': ref}
                for key in r_append:
                    data[key] = s_data[key]
            if rtype == 'episode':
                if tv_vid := VideoIds.from_ffid(ref.ffid):
                    data.setdefault('show_id', tv_vid.tmdb)
            return data

        APPEND_SEASONS = SkelOptions.SHOW_FIRST_SEASONS | SkelOptions.SHOW_LAST_SEASONS | SkelOptions.SHOW_ALL_SEASONS;
        if credentials is None:
            credentials = self.credentials()
        cred_params, headers = self._prepare_credentials(credentials=credentials)
        append_to_response = ['external_ids']
        params = {
            **cred_params,
            # 'language': 'en-US',
        }
        if options & SkelOptions.TRANSLATIONS:
            append_to_response.append('translations')

        if not refs:
            return {}
        if len(refs) == 1:
            ref = refs[0]
            return {ref: get(ref)}
        with RequestsPoolExecutor(min(self.connections(), const.tmdb.skel_max_threads)) as ex:
            jobs = ex.map(get, refs)
        return {ref: item for ref, item in zip(refs, jobs)}

    def parse_episode_type(self, item: JsonData, *, tvshow_status: str = '') -> EpisodeType:
        """Determine episode type."""
        if etype := item.get('episode_type'):
            if etype == 'finale':  # season or tvshow
                if tvshow_status.lower() in ('ended', 'canceled', 'canceled'):
                    return 'series_finale'
        return self.EPISODE_TYPE_TO_FF.get(etype, '')

    def _item_list(self, type: RefType | SearchType, data: JsonResult | None, *,
                   key: str = 'results', out_type: RefType | None = None, locale: str | None = None) -> ItemList[FFItem]:
        """Return item list with pagination."""

        def parse(it: JsonData) -> FFItem:
            def set_if(setter: Callable, key: Union[str, Sequence[str]]) -> None:
                if isinstance(key, str):
                    key = (key,)
                for k in key:
                    val = it.get(k)
                    if val is not None and val != '':
                        setter(val)
                        return

            mtype: RefType = it.get('media_type', out_type)
            if mtype == 'tv':
                mtype = 'show'
            if out_type == 'movie' and 'media_type' not in it and 'genre_ids' not in it and 'popularity' not in it:
                mtype = 'collection'  # hack, searching movies returns collections
            ref = MediaRef.from_tmdb(mtype, it.get('id') or 0)
            ffid = ref.ffid
            if out_type == 'show' and type in ('season', 'episode') and (show_id := it.get('show_id')) and (sz_num := it.get('season_number')):
                ref = MediaRef.from_tmdb('show', show_id, season=sz_num, episode=it.get('episode_number'))
            it['_ref'] = ref
            ff = FFItem(ref)
            if ffid:
                ff.ffid = ffid
            ff.source_data = it
            vtag = ff.vtag
            ff.label = ff.title = it.get('title', it.get('name')) or ''
            if locale and locale.partition('-')[0] == 'en':
                vtag.setEnglishTitle(ff.label)
            set_if(vtag.setOriginalTitle, 'original_name')
            set_if(vtag.setPlot, 'description')
            set_if(vtag.setPlot, 'overview')
            set_if(vtag.setPremiered, ('release_date', 'created_at'))
            set_if(vtag.setFirstAired, 'air_date')
            set_if(vtag.setFirstAired, 'first_air_date')
            if date := ff.date:
                vtag.setYear(date.year)
            # set_if(vtag.set..., 'popularity')
            vtag.setRatings({'tmdb': (it.get('vote_average', 0.0), it.get('vote_count', 0))}, 'tmdb')
            if ref.is_show:
                set_if(vtag.setSeriesStatus, 'status')
            if episode_type := self.parse_episode_type(it):
                vtag.setEpisodeType(episode_type)
            ff.role = it.get('character', it.get('job', ''))
            if rating := it.get('rating'):
                ff.setProperty('user_rating', str(rating))
                ff.setProperty('tmdb.user_rating', str(rating))
                # vtag.setUserRating(rating)
            art = {}
            if logo := it.get('logo_path'):
                art['clearlogo'] = f'{self.art_image_url}{logo}'
                if ref.type == 'person':
                    art['poster'] = art['clearlogo']
            if poster := it.get('poster_path'):
                art['poster'] = f'{self.person_image_url}{poster}'
            if landscape := it.get('still_path'):
                art['landscape'] = f'{self.art_landscape_url}{landscape}'
            if fanart := it.get('backdrop_path'):
                fanart = f'{self.art_landscape_url}{fanart}'
                art['fanart'] = fanart
                art.setdefault('landscape', fanart)
            if not art.get('thumb') and (thumb := art.get('landscape' if ref.is_episode else 'poster', art.get('clearlogo'))):
                art['thumb'] = thumb
            if art:
                ff.setArt(art)
            if count := it.get('number_of_items'):
                ff._children_count = count
            if (val := it.get('public')) is not None:
                ff.temp.public = val
            return ff

        if out_type is None:
            out_type = type

        if isinstance(data, Mapping):
            total_pages = data.get('total_pages', 0)
            total_results = data.get('total_results', 0)
            page_size = 0
            # make sure that page size is correct
            if total_pages and total_results and (total_results + self.PAGE_SIZE - 1) // self.PAGE_SIZE == total_pages:
                page_size = self.PAGE_SIZE
            return ItemList([parse(it) for it in data.get(key, ())], page=data.get('page', 0),
                            # TMDB counts more pages than it gives
                            total_pages=min(total_pages, self.MAX_PAGE), total_results=total_results, page_size=page_size)

        if isinstance(data, Sequence) and not isinstance(data, str):
            return ItemList([parse(it) for it in data], page=1, total_pages=1, total_results=len(data), page_size=len(data))

        return ItemList.empty()

    def get_videos(self, ref: MediaRef) -> ...:
        if ref.type == 'movie':
            path = f'movie/{ref.tmdb_id}'
        elif ref.type == 'show':
            path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
        else:
            raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')
        lang = self._update_locale()
        trailers_lang_priority = {lang.partition('-')[0]: 0, 'en': 1}
        result = self.get(f'{path}', append_to_response=('videos',), params={'include_video_language': f'{lang},en-US,en-GB'})
        if not isinstance(result, Mapping):
            return []
        items = sorted(
            result['videos']['results'],
            key=lambda t: (not t.get('official', False), t['type'] != 'Trailer', trailers_lang_priority.get(t['iso_639_1']), t.get('published_at', ''))
        )
        return [MediaVideo(lang=it['iso_639_1'], name=it['name'], key=it['key'], site=it['site'], type=it['type'], official=it['official'],
                           published_at=fromisoformat(it['published_at'])) for it in items]

    def get_alternative_titles(self, ref: MediaRef) -> Sequence[JsonData]:
        """Get alternative titles for movie or show."""
        if (rtype := ref.real_type) not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.get_alternative_titles() got incorrect type {rtype!r} only movie or show allowed')
        assert rtype in ('movie', 'show')
        mtype = self._main2tmdb_type.get(rtype)
        result = self.get(f'{mtype}/{ref.tmdb_id}/alternative_titles')
        if isinstance(result, Mapping):
            return result.get('results', ())
        return ()

    # --- General API ---

    def discover(self,
                 type: MainMediaType,
                 *,
                 page: int = 1,
                 # all filter paramaters from https://developer.themoviedb.org/reference/discover-movie
                 **kwargs: Unpack[DiscoveryFilters],
                 ) -> ItemList[FFItem]:
        """Discover media."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.discover() got incorrect type {type!r}')
        try:
            ctype = self._main2tmdb_type[type]
        except KeyError:
            return ItemList.empty()

        allowed = set(self.DISCOVER_FILTERS)
        if kwargs.keys() - allowed:
            wrong = ', '.join(kwargs.keys() - allowed)
            raise TypeError(f'TmdbApi.discover() unknown filter params: {wrong}')

        params = {}
        if const.tmdb.avoid_keywords:
            kwargs.setdefault('without_keywords', const.tmdb.avoid_keywords)
        for k, v in kwargs.items():
            if v is not None:
                if not isinstance(v, str) and isinstance(v, Sequence):
                    v = '|'.join(map(str, v))
                params[k] = v
        return self._item_list(type, self._general_page(f'discover/{ctype}', kind='discover', page=page, params=params))

    def discover_list(self,
                      type: MainMediaType,
                      list: TmdbListType,
                      *,
                      page: int = 1,
                      region: Optional[str] = None,
                      ) -> ItemList:
        """Discover media list (tweaked discover)."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.discover() got incorrect type {type!r}')
        if list not in get_typing_args(TmdbListType):
            raise ValueError(f'TmdbApi.discover() got incorrect list {list!r}')
        try:
            ctype = self._main2tmdb_type[type]
        except KeyError:
            return ItemList.empty()

        params: Dict[str, Any] = {'region': region} if region else {}
        return self._item_list(type, self._general_page(f'{ctype}/{list}', kind='discover', page=page, params=params))

    def trending(self,
                 type: MainMediaType,
                 time: TimeWindow = 'week',
                 *,
                 page: int = 1,
                 ) -> ItemList:
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.trending() got incorrect type {type!r}')
        if time not in get_typing_args(TimeWindow):
            raise ValueError(f'TmdbApi.trending() got incorrect time window {time!r}')
        ctype = self._main2tmdb_type[type]

        return self._item_list(type, self._general_page(f'trending/{ctype}/{time}', kind='trending', page=page))
        # Daily Trending
        # https://api.themoviedb.org/3/trending/movie/day?api_key=###
        # https://api.themoviedb.org/3/trending/tv/day?api_key=###
        # https://api.themoviedb.org/3/trending/person/day?api_key=###
        # https://api.themoviedb.org/3/trending/all/day?api_key=###
        # Weekly Trending
        # https://api.themoviedb.org/3/trending/movie/week?api_key=###
        # https://api.themoviedb.org/3/trending/tv/week?api_key=###
        # https://api.themoviedb.org/3/trending/person/week?api_key=###
        # https://api.themoviedb.org/3/trending/all/weekly?api_key=###

    def configuration(self, name: TmdbConfName) -> Sequence[JsonData]:
        """Get configuration lists like countries, languages etc."""
        data = self._general_get(f'configuration/{name}', kind='art')
        if isinstance(data, Sequence):
            return data
        return []

    def genres(self, type: MainMediaType) -> List[JsonData]:
        """Get genres lists."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.genres() got incorrect type {type!r}')
        ctype = self._main2tmdb_type[type]

        data = self._general_get(f'genre/{ctype}/list', kind='art')
        if isinstance(data, Mapping):
            return data['genres']
        return []

    def find_id(self, source: ExternalIdType, id: int | str) -> MediaRef | None:
        """Find external id."""
        data = self.get(f'find/{id}', params={'external_source': f'{source}_id'})
        # with open(f'/tmp/find_{source}_{id}.json', 'w') as f:
        #     import json
        #     json.dump(data, f, indent=2)
        if not isinstance(data, Mapping):
            return None
        for mtype, key in self._ext_id_results.items():
            if data.get(key):
                data = data[key][0]
                return MediaRef.from_tmdb(mtype, data['id'], data.get('season_number'), data.get('episode_number'))
        return None

    def changed_ids(self, type: MainMediaType, *, start: dt_date) -> Optional[List[int]]:
        """
        Return TMDB IDs of the type changed since `start` (TMDB keeps 14 days of changes), None on failure.
        The pages one by one (a background work: a hundred pages at once would be a hundred threads).
        """
        ctype = self._main2tmdb_type[type]
        params = {'start_date': start.isoformat(), 'end_date': dt_date.today().isoformat()}

        def get(page: int) -> JsonResult | None:
            return self.get(f'{ctype}/changes', params={**params, 'page': page})

        if not isinstance(first := get(1), Mapping):
            return None
        datas: List[JsonResult | None] = [first]
        for page in range(2, int(first.get('total_pages') or 1) + 1):
            if not isinstance(data := get(page), Mapping):
                return None
            datas.append(data)
        return [it['id'] for data in datas if isinstance(data, Mapping) for it in data.get('results') or () if it.get('id')]

    def external_ids(self, type: MainMediaType, tmdb_id: int) -> JsonData | bool | None:
        """Return external IDs of the TMDB entry, False if the entry is removed (404), None on failure."""
        resp = self.request('GET', f'{self._main2tmdb_type[type]}/{tmdb_id}/external_ids', data=None, expected_errors=[404])
        if resp is None:
            return None
        if resp.status_code == 404:
            return False
        data = resp.json()
        return cast(JsonData, data) if isinstance(data, Mapping) else None

    def find_ids(self, source: ExternalIdType, ids: Iterable[int | str]) -> Sequence[MediaRef | None]:
        """Find list of external id."""
        def get(id: int | str) -> MediaRef | None:
            return self.find_id(source, id)

        with self.executor() as ex:
            jobs = ex.map(get, ids)
        return list(jobs)

    def find_mixed_ids(self, ids: Iterable[tuple[ExternalIdType, int | str]]) -> Sequence[MediaRef | None]:
        """Find list of external id as list of (source, id)."""
        def get(args: tuple[ExternalIdType, int | str]) -> MediaRef | None:
            src, id = args
            return self.find_id(src, id)

        with self.executor() as ex:
            jobs = ex.map(get, ids)
        return list(jobs)

    def search(self,
               type: SearchType,
               query: str,
               *,
               page: int = 1,
               **kwargs: Unpack[SearchFilters],
               ) -> ItemList[FFItem]:
        """Search items with /search endpoint."""
        stype = self._search2tmdb.get(type)
        if not stype:
            return ItemList.empty()
        params = {'query': query, **kwargs}
        return self._item_list(type, self._general_page(f'search/{stype}', kind='search', page=page, params=params))

    def person_credits(self, person_id: int, type: PersonDataType) -> PersonCredits:
        """Get person credits (the whole response from the list cache, the language in the key)."""
        mtype = self._person2ref[type]
        person_id = self._ref_id_to_tmdb(person_id)
        data = self._general_get(f'person/{person_id}/{type}', kind='credits')
        if isinstance(data, Mapping):
            return PersonCredits(cast=tuple(self._item_list(mtype, data.get('cast', ()))),
                                 crew=tuple(self._item_list(mtype, data.get('crew', ()))))
        return PersonCredits()

    def media_images(self, ref: FFRef, *, locale: str | Sequence[str] | None = None) -> ArtInfo:
        """Generic function to get images for movies, shows, seasons, episodes, collections or persons."""
        if ref.type not in ('movie', 'show', 'person', 'collection', 'company', 'network'):
            # raise ValueError(f'TmdbApi.media_images() got incorrect type {type!r}')
            return ArtInfo()  # just return empty, do not raise, it is not critical error

        default = ('en', 'xx', 'null')
        if locale is None:
            locale = default
        elif isinstance(locale, str):
            locale = (locale, *default)
        locale = tuple(dict.fromkeys(loc.partition('-')[0] for loc in locale))  # remove duplicates, keep order

        ref = ref.ref
        url = '/'.join(f'{n}/{v}' for n, v in zip((self._ref2tmdb_type[ref.type], 'season', 'episode'), ref.tmdb_id_tuple))
        params = {'include_image_language': ','.join(locale)}
        data = self._general_get(f'{url}/images', kind='art', params=params)

        from ..ff.art import Art
        art = Art()
        if isinstance(data, Mapping):
            return art.parse_arts(images=data, translation_order=locale, ref=ref)
        return ArtInfo()

    def collection_items(self, collection_id: int) -> Sequence[FFItem]:
        """Get collection's items."""

        def parse(it: JsonData) -> FFItem:
            mtype = it.get('media_type', 'movie')
            if mtype == 'tv':
                mtype = 'show'
            ref = MediaRef.from_tmdb(mtype, it['id'])
            ff = FFItem(ref)
            ff.title = it.get('title') or ''
            ff.vtag.setOriginalTitle(it.get('original_title') or '')
            art = {}
            if poster := it.get('poster_path'):
                art['poster'] = f'{self.art_image_url}{poster}'
            if landscape := it.get('still_path'):
                art['landscape'] = f'{self.art_landscape_url}{landscape}'
            if art:
                ff.setArt(art)
            return ff

        collection_id = self._ref_id_to_tmdb(collection_id)
        data = self.get(f'collection/{collection_id}')
        if isinstance(data, Mapping):
            return [parse(it) for it in data.get('parts', ())]
        return []

    def media_resource(self, ref: MediaRef, resource: MediaResource, *, page: int = 1) -> List[FFItem]:
        """Get media (movie, show) resource."""
        if ref.type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.media_resource() got incorrect type {ref.type!r}')
        if resource not in get_typing_args(MediaResource):
            raise ValueError(f'TmdbApi.media_resource() got incorrect resource {resource!r}')
        try:
            mtype = cast(MainMediaType, ref.type)
            ctype = self._main2tmdb_type[mtype]
        except KeyError:
            return ItemList.empty()

        params = {'page': page}
        return self._item_list(mtype, self.get(f'{ctype}/{ref.tmdb_id}/{resource}', params=params))

    def media_keywords(self, ref: MediaRef) -> List[FFItem]:
        """Get media (movie, show) resource."""
        if ref.type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.media_resource() got incorrect type {ref.type!r}')
        try:
            mtype = cast(MainMediaType, ref.type)
            ctype = self._main2tmdb_type[mtype]
        except KeyError:
            return ItemList.empty()

        return self._item_list(mtype, self.get(f'{ctype}/{ref.tmdb_id}/keywords'), key='keywords', out_type='keyword')

    #: Items of a TMDB list page.
    PAGE_SIZE: ClassVar[int] = 20

    def _cached_pages(self,
                      name: str,
                      url: str,
                      *,
                      page: int = 1,
                      params: Optional[KwArgs] = None,
                      api_version: Literal[3, 4] = 3,
                      key: str = 'results',
                      type: RefType | SearchType = '',
                      out_type: RefType | None = None,
                      bucket: str = '',
                      ) -> JsonData | None:
        """
        GET all pages of a list of the account through the list cache (`lib.ff.listcache`), return the response of `page`
        (0: all items) cut locally, None on failure. `bucket` - the sync bucket watching the list ('' - none).
        """
        params = dict(params or ())

        def get(pg: int) -> JsonResult | None:
            return self.get(url, params={**params, 'page': pg}, api_version=api_version)

        def fetch() -> FetchedList | None:
            if not isinstance(first := get(1), Mapping):
                return None
            datas: list[JsonResult | None] = [first]
            if (pages := min(int(first.get('total_pages') or 1), const.lists.cache.limit // self.PAGE_SIZE + 1)) > 1:
                with self.executor() as ex:
                    datas.extend(ex.map(get, range(2, pages + 1)))
            if not all(isinstance(data, Mapping) for data in datas):
                return None  # incomplete data looks like removed items
            items = [it for data in datas if isinstance(data, Mapping) for it in data.get(key) or ()]
            refs = [ff.ref for ff in self._item_list(type, {key: items}, key=key, out_type=out_type)]
            meta = {k: v for k, v in first.items() if k not in (key, 'page', 'total_pages', 'total_results')}
            return FetchedList(list(zip(refs, items)) if len(refs) == len(items) else [(None, it) for it in items], meta=meta)

        stored = cached_list(self.scope, name, fetch, params=list_params(url=url, api=api_version, **params), bucket=bucket)
        if stored is None:
            return None
        items = stored.items
        total = len(items)
        if page:
            items = items[(page - 1) * self.PAGE_SIZE:page * self.PAGE_SIZE]
        return {**stored.row.meta, key: items, 'page': page or 1, 'total_results': total,
                'total_pages': max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE) if page else 1}

    def _general_page(self, url: str, *, kind: str, page: int = 1, params: Optional[KwArgs] = None) -> JsonData | None:
        """
        GET a page of a general list (no account, the scope is the type) through the list cache (`lib.ff.listcache`, the
        TTL of the `kind`), return the response as is (the language of the client in the key), None on failure.
        """
        page = max(1, page)
        params = dict(params or ())

        def fetch() -> FetchedList | None:
            if not isinstance(data := self.get(url, params={**params, 'page': page}), Mapping):
                return None
            return FetchedList([(None, it) for it in data.get('results') or ()], meta={k: v for k, v in data.items() if k != 'results'})

        stored = cached_list('tmdb', url, fetch, params=list_params(lang=self.locale, **params), kind=kind, page=page)
        return None if stored is None else {**stored.row.meta, 'results': list(stored.items)}

    def _general_get(self, url: str, *, kind: str, params: Optional[KwArgs] = None) -> JsonResult | None:
        """
        GET a whole small response of the type (configuration, genres, images: no account) through the list cache (one item,
        the TTL of the `kind`, the language of the client in the key), None on failure.
        """
        def fetch() -> FetchedList | None:
            return None if (data := self.get(url, params=params)) is None else FetchedList([(None, data)])

        stored = cached_list('tmdb', url, fetch, params=list_params(lang=self.locale, **(params or {})), kind=kind)
        return stored.items[0] if stored is not None and stored.items else None

    def _changed(self, name: str) -> None:
        """Mark the cached list `name` (with its sub-lists) of the account as changed (an own change)."""
        mark_stale(self.scope, name)

    def user_lists(self, account_id: AccountId = 'me', *, page: int = 0, api: ApiVer = None) -> List[FFItem]:
        """Get user lists (of the account: from the list cache; all of them with `page` 0)."""
        account_id = self._ref_id_to_tmdb(account_id)
        if (credentials := self.credentials()).v4 and api != 3 and account_id == 'me':
            url, version = f'account/{credentials.account_id}/lists', cast('Literal[3, 4]', 4)
        elif credentials.v3 and api != 4:
            url, version = f'account/{account_id}/lists', cast('Literal[3, 4]', 3)
        else:
            return ItemList.empty()
        if account_id == 'me':
            data = self._cached_pages('user', url, page=page, api_version=version, type='list', bucket='lists.user')
        else:
            data = self.get(url, params={'page': page or 1}, api_version=version)
        return self._item_list('list', data)

    def user_list_items(self, list_id: int, *, page: int = 1, api: ApiVer = None) -> ItemList[FFItem]:
        """Get user list items (from the list cache, a list of the account or a public one)."""
        list_id = self._ref_id_to_tmdb(list_id)
        bucket = 'lists.user' if self._own_list(list_id) else ''
        if (credentials := self.credentials()).v4 and api != 3:
            data = self._cached_pages(f'user/{list_id}', f'list/{list_id}', page=page, api_version=4, bucket=bucket)
            return self._item_list('', data)
        if credentials.v3 and api != 4:
            data = self._cached_pages(f'user/{list_id}', f'list/{list_id}', page=page, api_version=3, key='items', bucket=bucket)
            return self._item_list('', data, key='items')
        return ItemList.empty()

    def _own_list(self, list_id: int | str) -> bool:
        """Return True if the list is an own list of the account (its lists from the list cache)."""
        if self.account is None or not self.credentials().v3 and not self.credentials().v4:
            return False
        return any(self._ref_id_to_tmdb(it.ffid) == list_id for it in self.user_lists())

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """
        Return cursors of the sync buckets (`lib.ff.sync`), None on failure. TMDB has no activities: fingerprints of the
        lists - the count and the newest item of the watchlist and the favorites (movies, shows), the change time and the
        count of each own list (v4; v3: the count), the ratings fetched whole (a changed rating does not move in TMDB) - they
        are stored in the list cache at once, the cursor tells the sync they changed.
        """
        import hashlib
        cursors: dict[SyncBucket, str] = {}
        for list_type, bucket in self._LIST_BUCKETS.items():
            parts = []
            for ctype in self._main2tmdb_type2.values():
                data = self.get(f'account/me/{list_type}/{ctype}', params={'page': 1, 'sort_by': 'created_at.desc'})
                if not isinstance(data, Mapping):
                    return None
                first = next(iter(data.get('results') or ()), {})
                parts.append(f'{data.get("total_results") or 0}:{first.get("id") or ""}')
            cursors[bucket] = '|'.join(parts)
        credentials = self.credentials()
        if credentials.v4:
            lists = self.get(f'account/{credentials.account_id}/lists', params={'page': 1}, api_version=4)
        else:
            lists = self.get('account/me/lists', params={'page': 1})
        if not isinstance(lists, Mapping):
            return None
        cursors['lists.user'] = '|'.join([str(lists.get('total_results') or 0),
                                          *(f'{it.get("id")}:{it.get("updated_at") or ""}:{it.get("number_of_items", it.get("item_count"))}'
                                            for it in lists.get('results') or ())])
        rated = []
        for media, ctype in self._ref2rating.items():
            mark_stale(self.scope, f'rated/{ctype}')  # fetched whole now (as `user_ratings()`): the cache is fresh, the bucket needs no fetch
            if (data := self._cached_pages(f'rated/{ctype}', f'account/me/rated/{ctype}', page=0, type=media,
                                           out_type='show' if media == 'episode' else media, bucket='ratings')) is None:
                return None
            rated.extend(f'{ctype}:{it.get("id")}:{it.get("rating")}' for it in data.get('results') or ())
        cursors['ratings'] = f'{len(rated)}|{hashlib.md5(",".join(rated).encode()).hexdigest()}'
        return cursors

    def sync_bucket(self, bucket: SyncBucket, cursor: str | None = None) -> bool | None:
        """Sync a bucket out of `SYNC_LISTS`: the ratings are fetched by `sync_activities()` already. Return False (no rows changed)."""
        return False

    def _user_list_items_param(self, items: Iterable[FFRef]) -> list[dict[str, str | int]]:
        """Prepare items for user list API."""
        m2t = {
            **self._main2tmdb_type,
            # 'season': 'tv',   # add season's show
            # 'episode': 'tv',  # add epsiode's show
        }
        param = [{
            'media_type': media,
            'media_id': tmdb_id,
        } for it in items if (tmdb_id := (ref := it.ref).tmdb_id) and (media := m2t.get(ref.real_type))]
        return param

    def add_to_user_list(self, list_id: int, items: Iterable[FFRef]) -> int:
        """Add items to the list and return number of added items. Support only v4."""
        list_id = self._ref_id_to_tmdb(list_id)
        if not isinstance(items, Sequence):
            items = tuple(items)
        if not items:
            return True
        to_add = self._user_list_items_param(items)
        if not to_add:
            return False
        data = self.post(f'list/{list_id}/items', data={'items': to_add}, api_version=4)
        self._changed('user')
        if not isinstance(data, Mapping) or not data.get('success'):
            return False
        return sum(res['success'] for res in data['results'])

    def remove_from_user_list(self, list_id: int, items: Iterable[FFRef]) -> int:
        """Remove items tfrom the list and return number of removed items. Support only v4."""
        list_id = self._ref_id_to_tmdb(list_id)
        if not isinstance(items, Sequence):
            items = tuple(items)
        if not items:
            return True
        to_remove = self._user_list_items_param(items)
        if not to_remove:
            return False
        data = self.delete(f'list/{list_id}/items', data={'items': to_remove}, api_version=4)
        self._changed('user')
        if not isinstance(data, Mapping) or not data.get('success'):
            return False
        return sum(res['success'] for res in data['results'])

    def create_user_list(self, name: str, *, descr: str = '', public: bool = True, locale: Optional[str] = None, api: ApiVer = None) -> Optional[int]:
        """Create user list and return its ID."""
        # XXX XXX XXX   ----   TMDB (v4) ignores "public": false !!!!  ----   XXX XXX XXX
        if not name:
            raise ValueError('TmdbApi.create_user_list() requires name')
        if locale is None:
            locale = self.lang or 'pl-PL'
        country, _, lang = locale.partition('-')
        if (credentials := self.credentials()).v4 and api != 3:
            d = {'name': name, 'description': descr, 'public': public, 'iso_3166_1': country, 'iso_639_1': lang}
            fflog(f'new list data: {d}')
            data = self.post('list', data={'name': name, 'description': descr, 'public': public,
                                           'iso_3166_1': country, 'iso_639_1': lang}, api_version=4)
        elif credentials.v3 and api != 4:
            data = self.post('list', data={'name': name, 'description': descr, 'language': lang}, api_version=3)
        else:
            return None
        self._changed('user')
        if isinstance(data, Mapping) and data.get('success'):
            return data.get('id')
        fflog(f'[FF][TMDB] Failed to create list {name!r}, data={data!r}')
        return None

    def delete_user_list(self, list_id: int) -> bool:
        """Delete the list (and its content). Return true on success. Support only v4."""
        list_id = self._ref_id_to_tmdb(list_id)
        data = self.delete(f'list/{list_id}', data=None, api_version=4)
        self._changed('user')
        return isinstance(data, Mapping) and bool(data.get('success'))

    def user_general_lists(self,
                           list_type: UserGeneralListType,
                           type: Union[MainMediaType, MainMediaTypeList],
                           account_id: AccountId = 'me',
                           *,
                           page: int = 1,
                           chunk: int = 0,
                           sort: str = 'created_at.desc',
                           ) -> ItemList[FFItem]:
        """Get user lists."""
        def get(mtype: MainMediaType) -> ItemList[FFItem]:
            if mtype not in get_typing_args(MainMediaType):
                raise ValueError(f'TmdbApi got incorrect type {mtype!r}')
            ctype = self._main2tmdb_type2[mtype]
            url = f'account/{account_id}/{list_type}/{ctype}'
            if account_id == 'me':
                data = self._cached_pages(list_type, url, page=page, params={'sort_by': sort}, type=mtype, out_type=mtype,
                                          bucket=self._LIST_BUCKETS.get(list_type, ''))
            else:
                data = self.get(url, params={'page': page, 'sort_by': sort})
            return self._item_list(mtype, data)

        if isinstance(type, str):
            type = cast(MainMediaType, type.split(','))
        if not type:
            return ItemList.empty()
        if len(type) == 1:
            return get(type[0])
        with RequestsPoolExecutor() as pool:
            datas: Sequence[ItemList[FFItem]] = tuple(pool.map(get, type))
        return ItemList(join_items(*datas, zip_chunk=chunk), page=page, total_pages=max((d.total_pages for d in datas), default=1))

    def _set_general_list_items(self,
                                list_type: UserGeneralListType,
                                items: Iterable[FFRef],
                                *,
                                add: bool,
                                account: AccountId = 'me',
                                ) -> int:
        """Add or remove items to/from the general list (favorites, watchlist) and return number of proceeded items. Support only v3."""
        def update(it: JsonData) -> bool:
            data = self.post(f'account/{account}/{list_type}', data=it, api_version=3)
            return bool(isinstance(data, Mapping) and data.get('success'))

        if not isinstance(items, Sequence):
            items = tuple(items)
        if not items:
            return 0
        m2t = {**self._main2tmdb_type}
        to_update = [{
            'media_type': media,
            'media_id': tmdb_id,
            list_type: add,  # add to the list type
        } for it in items if (tmdb_id := (ref := it.ref).tmdb_id) and (media := m2t.get(ref.real_type))]
        if not to_update:
            return 0
        with self.executor() as ex:
            results = list(ex.map(update, to_update))
        self._changed(list_type)
        return sum(results)

    def add_items_to_general_list(self,
                                  list_type: UserGeneralListType,
                                  items: Iterable[FFRef],
                                  *,
                                  account: AccountId = 'me',
                                  ) -> int:
        return self._set_general_list_items(list_type, items, add=True, account=account)

    def remove_items_from_general_list(self,
                                       list_type: UserGeneralListType,
                                       items: Iterable[FFRef],
                                       *,
                                       account: AccountId = 'me',
                                       ) -> int:
        return self._set_general_list_items(list_type, items, add=False, account=account)

    # --- Lists and ratings of the account (`AccountClient` vocabulary) ---

    def _general_list(self, list_type: UserGeneralListType, media: MainMediaType | MainMediaTypeList | None, page: int | None) -> ItemList[FFItem]:
        """Return the page of the favorites / watchlist of the account; all pages without `page` or for mixed media (an API page joins pages of each type)."""
        media = media or 'movie,show'
        if page is None or ',' in media:
            from . import depaginate
            with depaginate(self) as api:
                items = api.user_general_lists(list_type, media, chunk=10)
            return Pagina(items, page=page, limit=self.PAGE_SIZE) if page else items
        return self.user_general_lists(list_type, media, page=page)

    def watchlist(self, *, media: MainMediaType | MainMediaTypeList | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist of the account (the page, all items without `page`)."""
        return self._general_list('watchlist', media, page)

    def favorites(self, *, media: MainMediaType | MainMediaTypeList | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the favorites of the account (the page, all items without `page`)."""
        return self._general_list('favorite', media, page)

    def list_items(self, list_id: int | str, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the items of a list (the page, all items without `page`), only the `media` if given (all filtered, pages cut here)."""
        if not media:
            return self.user_list_items(int(list_id), page=page or 0)
        items = [it for it in self.user_list_items(int(list_id), page=0) if it.type == media]
        return Pagina(items, page=page, limit=self.PAGE_SIZE) if page else ItemList.single(items)

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the watchlist or remove them, return the number of changed ones."""
        return self._set_general_list_items('watchlist', items, add=state)

    def set_favorites(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the favorites or remove them, return the number of changed ones."""
        return self._set_general_list_items('favorite', items, add=state)

    def set_in_list(self, list_id: int | str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to an own list or remove them, return the number of changed ones."""
        return int((self.add_to_user_list if state else self.remove_from_user_list)(int(list_id), items))

    def create_list(self, name: str, *, public: bool = False) -> Optional[int]:
        """Create an own list, return its ID (TMDB v4 ignores `public` false)."""
        return self.create_user_list(name, public=public)

    def delete_list(self, list_id: int | str) -> bool:
        """Delete an own list (with its items)."""
        return self.delete_user_list(int(list_id))

    def rename_list(self, list_id: int | str, name: str) -> str | None:
        """Rename an own list (v4 only, like the delete), return its ID, None on failure."""
        resp = self.request('PUT', f'list/{self._ref_id_to_tmdb(int(list_id))}', data={'name': name}, api_version=4)
        self._changed('user')
        return str(list_id) if resp is not None and resp.json().get('success') else None

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, float]:
        """Return the ratings of the account by media (from the list cache), only of the media `refs` if given."""
        if refs is not None:
            refs = list(refs)
        rated: Sequence[str] = ('movie', 'show', 'episode')
        types = rated if refs is None else sorted({ref.ref.real_type for ref in refs} & set(rated))  # only the rated lists needed
        return pick_ratings({it.ref: float(rating) for typ in types for it in self.user_ratings(cast('Literal["movie", "show", "episode"]', typ), page=0)
                             if (rating := it.getProperty('tmdb.user_rating'))}, refs)

    def rating(self, ref: FFRef) -> float | None:
        """Return the rating of the media asked now (the account state of the media), None if not rated."""
        rating = self.user_ref_rating(ref)
        return None if rating is None else float(rating)

    def set_ratings(self, items: Iterable[FFRef], rating: float | None) -> int:
        """Rate (`rating`) the media or remove their ratings (None), return the number of changed ones."""
        if rating is None:
            return sum(self.remove_user_rating(it) for it in items)
        return sum(self.add_user_rating(it, rating=float(rating)) for it in items)

    def web_url(self, ref: MediaRef) -> str:
        """Return link to media for humans."""
        if not ref.tmdb_id:
            return ''
        if ref.type == 'show':
            path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
        elif ref.type in ('movie', 'person', 'collection'):
            path = f'{ref.type}/{ref.tmdb_id}'
        else:
            return ''  # unspotted media type
        return f'https://www.themoviedb.org/{path}'

    def providers(self, type: MainMediaType, region: str) -> Sequence[TmdbProvider]:
        """Return list of providers."""

        def parse(it: JsonData) -> TmdbProvider:
            if logo_path := it['logo_path']:
                logo = f'{self.art_image_url}{logo_path}'
            else:
                logo = None
            return TmdbProvider(id=it['provider_id'], name=it['provider_name'], logo=logo, display_priority=it['display_priority'])

        ctype = self._main2tmdb_type[type]  # konersja typu FF na TMDB
        result = self._general_get(f'watch/providers/{ctype}', kind='art', params={'watch_region': region})
        if isinstance(result, Mapping):
            return [parse(it) for it in result.get('results', ())]
        return ()

    def popular_people(self, *, page: int = 1) -> Sequence[FFItem]:
        """Return popular people."""
        return self._item_list('person', self._general_page('person/popular', kind='trending', page=page))

    def aliases(self, type: MainMediaType, id: int) -> Sequence[JsonData]:
        """Get media (movie, show) aliases."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.aliases() got incorrect type {type!r}')
        try:
            ctype = self._main2tmdb_type[type]
        except KeyError:
            return []

        data = self.get(f'{ctype}/{id}/alternative_titles')
        if isinstance(data, Mapping):
            return data.get('results', ())
        return []

    def episode_groups(self, show: FFRef | int) -> list[FFEpisodeGroup]:
        """Get episode groups for the show."""
        if isinstance(show, int):
            show_id = show
        else:
            show_id = show.ref.tmdb_id
        data = self.get(f'tv/{show_id}/episode_groups')
        if isinstance(data, Mapping):
            return [FFEpisodeGroup(tmdb_id=it['id'], name=it['name'], description=it.get('description', ''),
                    episode_count=it.get('episode_count', ()), group_count=it.get('group_count', ()),
                    type=FFEpisodeGroupType(it.get('type', 0)))
                    for it in data.get('results', ())]
        return []

    def episode_group(self, group: str, *, show: FFRef | int | None = None) -> FFEpisodeGroup | None:
        """Get given episode group items by group hex ID. Return "seasons" (groups) with episodes."""
        data = self.get(f'tv/episode_group/{group}', lang='')  # "language" is not allowed here (in tmdb api)
        if isinstance(data, Mapping) and data.get('id'):
            # import json
            # with open('/tmp/e.json', 'w') as f:  json.dump(data, f, indent=2)  # XXX, TODO: remove it
            result = FFEpisodeGroup(tmdb_id=data['id'], name=data['name'], type=FFEpisodeGroupType.from_tmdb(data['type']),
                                    description=data['description'], network=data['network'],
                                    episode_count=data['episode_count'], group_count=data['group_count'])
            if show is None:
                any_episode = next(iter(ep for gr in data.get('groups', ()) for ep in gr.get('episodes', ())), None)
                if any_episode is None:
                    return result
                show = MediaRef.tvshow(any_episode['show_id'])
            elif isinstance(show, int):
                show = MediaRef.from_tmdb('show', show)
            else:
                show = show.ref
            seasons = []
            for group_item in sorted(data.get('groups', ()), key=lambda it: it.get('order', 0)):
                sz = FFItem(ref=show.with_season(group_item['order']), type='season')
                # sz.season = sz.ref.season
                sz.title = group_item['name']
                sz.vtag.setUniqueID(group_item['id'], 'tmdb_episode_group_id')
                episodes: list[TmdbItemJson] = sorted(group_item.get('episodes', ()), key=lambda it: it.get('order', 0))
                sz.children_items = self._item_list('episode', episodes, out_type='show', locale=LOCALE_EN)
                for i, ep in enumerate(sz.children_items, 1):
                    ep.season = sz.season
                    ep.episode = i
                if sz.children_items:
                    sz.vtag.setFirstAired(sz.children_items[0].date)
                seasons.append(sz)
            result.items = seasons
            return result
        return None

    def episode_group_list(self, group: str, *, show: FFRef | int | None = None) -> ItemList[FFItem]:
        gr = self.episode_group(group=group, show=show)
        return ItemList.empty() if gr is None or gr.items is None else ItemList.single(gr.items)

    def episode_group_mapping(self, *, show: FFRef | int | None = None, group: str) -> dict[MediaRef, MediaRef]:
        """Get given episode group items by group hex ID, Return dict [main_order] = group_order."""
        data = self.get(f'tv/episode_group/{group}', lang='')  # "language" is not allowed here (in tmdb api)
        if isinstance(data, Mapping):
            if not show:
                show = MediaRef.tvshow(0)
            elif isinstance(show, int):
                show = MediaRef.tvshow(show)
            else:
                show = show.ref
            group_item: JsonData
            refs: dict[MediaRef, MediaRef] = {}
            for group_item in sorted(data.get('groups', ()), key=lambda it: it['order']):
                sn = group_item['order']  # XXX  Czy to na pewno jest numer "sezonu" ???
                episodes: list[TmdbItemJson] = group_item.get('episodes', [])
                episodes.sort(key=lambda it: it.get('order', 0))
                refs.update((show.with_season_episode(ep['season_number'], ep['episode_number']), show.with_season_episode(sn, en))
                            for en, ep in enumerate(episodes, 1))
            return refs
        return {}

    def user_ref_rating(self, ref: FFRef) -> float | None:
        """"Get user media rating."""
        # movie/{movie_id}/account_states
        ref = ref.ref
        if (rtype := ref.real_type) not in ('movie', 'show', 'episode'):
            return None
        assert ref.type in ('movie', 'show')
        ctype = self._main2tmdb_type[ref.type]
        path = '/'.join(f'{k}{v}' for k, v in zip([f'{ctype}/', 'season/', 'episode/'], ref.tmdb_id_tuple))
        data = self.get(f'{path}/account_states', api_version=3)
        if isinstance(data, Mapping):
            rated_data = data.get('rated')
            if isinstance(rated_data, dict):
                return rated_data.get('value') or None
            return None

        return None

    def user_ratings(self, type: Literal['movie', 'show', 'episode'] | None, page: int = 1) -> ItemList[FFItem]:
        """Get user media ratings."""
        if type is None:
            with RequestsPoolExecutor() as ex:
                movie = ex.submit(self.user_ratings, 'movie', page)
                show = ex.submit(self.user_ratings, 'show', page)
                episode = ex.submit(self.user_ratings, 'episode', page)
                return ItemList.single((*movie.result(), *show.result(), *episode.result()))

        ctype = self._ref2rating[type]
        out_type = 'show' if type == 'episode' else type
        data = self._cached_pages(f'rated/{ctype}', f'account/me/rated/{ctype}', page=page, type=type, out_type=out_type, bucket='ratings')
        return self._item_list(type, data, out_type=out_type)

    def add_user_rating(self, item: FFRef, *, rating: float | None) -> bool:
        """Add (set) single media user rating. If `rating` is None, get ratings from FFItem."""
        if rating is None:
            if not isinstance(item, FFItem):
                raise ValueError('TmdbApi.add_user_rating() got ref with missing ratings')
            rating = item.vtag.getUserRating()
        ref = item.ref
        if (rtype := ref.real_type) not in ('movie', 'show', 'episode'):
            raise ValueError(f'TmdbApi.add_user_rating() got incorrect type {rtype!r} only movie, show or episode allowed')
        assert ref.type in ('movie', 'show')
        ctype = self._main2tmdb_type[ref.type]
        path = '/'.join(f'{k}{v}' for k, v in zip([f'{ctype}/', 'season/', 'episode/'], ref.tmdb_id_tuple))
        data = self.post(f'{path}/rating', data={'value': rating}, api_version=3)
        self._changed('rated')
        return bool(isinstance(data, Mapping) and data.get('success'))

    def remove_user_rating(self, item: FFRef) -> bool:
        ref = item.ref
        if (rtype := ref.real_type) not in ('movie', 'show', 'episode'):
            raise ValueError(f'TmdbApi.add_user_rating() got incorrect type {rtype!r} only movie, show or episode allowed')
        assert ref.type in ('movie', 'show')
        ctype = self._main2tmdb_type[ref.type]
        path = '/'.join(f'{k}{v}' for k, v in zip([f'{ctype}/', 'season/', 'episode/'], ref.tmdb_id_tuple))
        data = self.delete(f'{path}/rating', api_version=3)
        self._changed('rated')
        return bool(isinstance(data, Mapping) and data.get('success'))

    # --- Following methods MUST be overridden ---

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists: the account ID (`lib.ff.listcache`)."""
        return self.account.id if self.account is not None else 'tmdb'

    def credentials(self) -> TmdbCredentials:
        """
        Return current credentials: the own API key (the settings, for every client), the user of the account (`accounts.db`:
        the session / token, the v3 login if any); the application client has no user.
        """
        from ..ff.settings import settings
        api_key = const.dev.tmdb.api_key or settings.getString('tmdb.api_key')  # own key, the default one is `self.api_key`
        if self.account is None:
            return TmdbCredentials(api_key=api_key)
        from ..ff.db.accounts import account_data_store
        store = account_data_store(self.account.id)
        token = store.get('token') or {}
        login = store.get('login') or {}
        return TmdbCredentials(api_key=api_key, user=login.get('user'), password=login.get('password'),
                               session_id=token.get('session_id'), access_token=token.get('access_token'))

    def refresh_profile(self) -> Optional[JsonData]:
        """Get the user of the account and keep it as the account profile (`id`, `username`), None on failure."""
        if self.account is None or not self.credentials():
            return None
        data = self.get('account', api_version=3)
        if not isinstance(data, Mapping) or not data.get('username'):
            return None
        from ..ff.db.accounts import account_data_store
        profile = {'id': data.get('id'), 'username': data['username']}
        account_data_store(self.account.id).set('profile', profile, ttl=None)
        return profile

    def save_session(self, *, session_id: Optional[str], access_token: Optional[str] = None) -> None:
        """Save the session of the account (None: remove). Another TMDB user drops the cached lists of the account."""
        if self.account is None:
            return
        old = self.credentials().account_id
        from ..ff.db.accounts import account_data_store
        store = account_data_store(self.account.id)
        if session_id or access_token:
            store.set('token', {'session_id': session_id, 'access_token': access_token}, ttl=None)
        else:
            store.delete('token')
        if old and old != self.credentials().account_id:
            remove_scope(self.account.id)

    @classmethod
    def _reject_own_key(cls, api_key: str) -> None:
        """Use the application key instead of the rejected own key (`tmdb.api_key`) in this process; tell the user once (silent)."""
        if cls._own_key_rejected == api_key:
            return
        cls._own_key_rejected = api_key
        from ..ff.kotools import Notification
        from ..kolang import L
        fflog('[TMDB] the own API key (tmdb.api_key) is rejected (401), the application key is used')
        Notification('FanFilm', L(30694, 'Own TMDB API key rejected - the FanFilm key is used'), sound=False).show()

    def auth_failed(self) -> None:
        """401 - auth error, should inform user or force auth again."""
        if self.account is None:
            return
        from ..ff.control import notification, addonName
        from ..kolang import L
        notification(f'{addonName()} – {self.account.label}', L(30365, 'TMDB has no authorization')).show()


def seasons_iter(*data: JsonData | Sequence[JsonData], common: bool = False) -> Iterator[tuple[JsonData, ...]]:
    """Iterate over season lists (TMDB JSON)."""
    if not data:
        return
    seasons = [{it['season_number']: it for it in (dt if isinstance(dt, Sequence) else dt.get('seasons', ()))}
               for dt in data]
    common_keys = seasons[0].keys()
    for i in range(1, len(seasons)):
        common_keys &= seasons[i].keys()
    if not common:
        common_keys |= seasons[0].keys()
    common_keys = sorted(common_keys)
    for key in common_keys:
        yield tuple(it.get(key, {}) for it in seasons)


def episodes_iter(*data: JsonData | Sequence[JsonData], common: bool = False) -> Iterator[tuple[JsonData, ...]]:
    """Iterate over season lists (TMDB JSON)."""
    if not data:
        return
    episodes = [{(it['season_number'], it['episode_number']): it for it in (dt if isinstance(dt, Sequence) else dt.get('episodes', ()))}
                for dt in data]
    common_keys = episodes[0].keys()
    for i in range(1, len(episodes)):
        common_keys &= episodes[i].keys()
    if not common:
        common_keys |= episodes[0].keys()
    common_keys = sorted(common_keys)
    for key in common_keys:
        yield tuple(it.get(key, {}) for it in episodes)


# --- DEBUG & TESTS ---


#: Client of the settings TMDB account (lists, ratings; also general requests of indexers).
tmdb: TmdbApi = TmdbApi(alias='tmdb')
#: Application client: no user (media for ffinfo).
tmdb_app: TmdbApi = TmdbApi()


def make_client(account: Account | None) -> TmdbApi:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return tmdb if account is None else TmdbApi(account)


if __name__ == '__main__':
    import json
    import sty
    # from pprint import pprint
    from ..ff.cmdline import DebugArgumentParser, parse_ref, parse_movie_ref, parse_show_ref
    from ..ff.settings import settings
    # from ..ff.settings import settings
    code_color: str = f'{sty.fg.red}{sty.ef.bold}'


    def parse_request(s: str) -> MediaRequest:
        """Parse request (ref, details, lang) string."""
        vv = s.split(':', 2)
        ref = parse_ref(vv[0])
        try:
            details = InfoDetails.new(vv[1]) if len(vv) > 1 else InfoDetails.NOT_DEFINED
        except KeyError as e:
            fflog.error(f'{code_color}Unknown InfoDetails flag {e.args[0]!r}{sty.rs.all}')
            raise ValueError(s)
        lang = vv[2] if len(vv) > 2 else ''
        return MediaRequest(ref, details=details, locale=lang)

    def jprint(data: JsonData) -> None:
        print(json.dumps(data, indent=2))

    def mprint(info: MediaPlayInfoDict) -> None:
        print('{')
        for k, v in info.items():
            # x = str(v).replace(', item_count', ',\n                  item_count')
            x = str(v).replace(', duration', ',\n                  duration')
            print(f'  {k}:\n    {x},')
        print('}')

    def add_common(pp: DebugArgumentParser) -> None:
        pp.add_argument('-d', '--details', metavar='FLAG[,FLAG]…', type=InfoDetails.new, default=InfoDetails.DEFAULT,
                        help='set media detail flags (see InfoDetails)')
        # pp.add_argument('-c', '--aggregate-credits', action='store_true', help='get aggregate credits')
        pp.add_argument('--req-locale', default='', help='language (e.g. pl-PL) for InfoDetails.INFO_ORIG')
        pp.add_argument('--append-seasons', default=[], type=lambda s: [int(v) for v in s.split(',')], help='extra seasons for show')

    p = DebugArgumentParser(dest='cmd')
    p.add_argument('--tmdb-api-key', help='TMDB API key, for get extra info')
    with p.with_subparser('get', help='get any media') as pp:
        pp.add_argument('id', type=parse_ref, help='tmdb movie/show/person id')
        add_common(pp)
    with p.with_subparser('movie') as pp:
        pp.add_argument('id', type=parse_movie_ref, help='tmdb movie id')
        add_common(pp)
    with p.with_subparser('tv') as pp:
        pp.add_argument('id', type=parse_show_ref, help='tmdb tv-show id')
        pp.add_argument('season', type=int, nargs='?', help='optional season number')
        pp.add_argument('episode', type=int, nargs='?', help='optional episode number')
        add_common(pp)
    with p.with_subparser('info') as pp:
        pp.add_argument('ids', type=parse_request, nargs='+', help='tmdb refs (m123, s123, s123/4, s123/4/5)')
        add_common(pp)
    with p.with_subparser('videos') as pp:
        pp.add_argument('ids', type=parse_ref, nargs='+', help='tmdb refs (m123, s123, s123/4, s123/4/5)')
    with p.with_subparser('discover') as pp:
        pp.add_argument('type', choices=('movie', 'tv', 'show'), help='media type')
        pp.add_argument('filter', nargs='*', help='filter (from DiscoveryFilters, ex: with_runtime<=90)')
        pp.add_argument('-p', '--page', type=int, default=1, help='page number (1..500)')
    with p.with_subparser('list') as pp:
        pp.add_argument('list', nargs='?', help='list ID')
        pp.add_argument('-A', '--api', choices=(3, 4), type=int, help='API version')
        pp.add_argument('-p', '--page', type=int, help='page number')
        pp.add_argument('-a', '--add', action='append', type=parse_ref, help='add media to the list')
    with p.with_subparser('auth') as pp:
        pp.add_argument('-A', '--api', choices=(3, 4), type=int, default=3, help='API version')
        pp.add_argument('-U', '--user', help='username (v3)')
        pp.add_argument('-P', '--pass', dest='password', help='password (v3)')
        pp.add_argument('-R', '--revoke', '--deauth', action='store_true', help='revoke authorization')
        pp.add_argument('-f', '--force', action='store_true', help='force auth')
    with p.with_subparser('skel') as pp:
        pp.add_argument('ids', type=parse_ref, nargs='+', help='tmdb refs (m123, s123, s123/4, s123/4/5)')
        pp.add_argument('-s', '--show', choices=('last', 'all', 'none'), default='last', help='show seasons options')
        pp.add_argument('-t', '--translations', action='store_true', help='append translations')
    with p.with_subparser('xxx') as pp:
        pass
    args = p.parse_args()
    # print(args); raise SystemExit(0)  # DEBUG

    from ..ff.ui import set_ui, TerminalUI
    set_ui(TerminalUI())
    tmdb = TmdbApi(alias='tmdb')

    if ids := getattr(args, 'ids', None):
        for req in ids:
            if not req.locale:
                req.locale = getattr(args, 'req_locale', '')
            if req.details == InfoDetails.NOT_DEFINED:
                req.details = getattr(args, 'details', InfoDetails.DEFAULT)

    if args.cmd == 'xxx':
        def get(ref: FFRef):
            tmdb.get_media_by_ref(ref.ref)
        # tmdb.get_media_by_ref(MediaRef('movie', 100950387))
        # exit()
        from . import depaginate
        with depaginate(tmdb, limit=1000) as api:
            items = api.trending('movie')
        print(len(items))
        print(items[0])
        with RequestsPoolExecutor(max_workers=1000) as pool:
            full = list(pool.map(get, items))
        print(len(items), len(full))

    if args.cmd == 'get':
        req = MediaRequest(args.id, details=args.details, locale=args.req_locale, seasons=args.append_seasons)
        jprint(tmdb.get_media_by_ref(req))
    elif args.cmd == 'movie':
        req = MediaRequest(args.id, details=args.details, locale=args.req_locale, seasons=args.append_seasons)
        jprint(tmdb.get_media_by_ref(req))
    elif args.cmd == 'tv':
        ref = args.id._replace(season=args.season, episode=args.episode)
        req = MediaRequest(ref, details=args.details, locale=args.req_locale, seasons=args.append_seasons)
        jprint(tmdb.get_media_by_ref(req))
    elif args.cmd == 'info':
        # pprint(list(tmdb.x_media_play_dict(args.ids, details=args.details, aggregate_credits=args.aggregate_credits).keys()))
        res = tmdb.get_media_dict_by_ref(args.ids, details=args.details)
        for data in res.values():
            jprint(data)
        # mprint(res)
    elif args.cmd == 'videos':
        # pprint(list(tmdb.x_media_play_dict(args.ids, details=args.details, aggregate_credits=args.aggregate_credits).keys()))
        for ref in args.ids:
            # TODO: merge with master
            jprint(tmdb.get_videos(ref))
    elif args.cmd == 'discover':
        if args.type == 'tv':
            args.type = 'show'
        for it in tmdb.discover(args.type, page=args.page, **Condition.filters_from_str_expr_list(args.filter)):
            print(f'{it.ref:a} :  {it}')
    elif args.cmd == 'list':
        if args.list:
            if args.add:
                tmdb.add_to_user_list(args.list, args.add)
                items = args.add
            else:
                items = tmdb.user_list_items(args.list, page=args.page, api=args.api)
        else:
            items = tmdb.user_lists(page=args.page, api=args.api)
        print(f'{len(items)} item(s)')
        print(items)
    elif args.cmd == 'auth':
        if args.revoke:
            tmdb.revoke_session()
        elif args.user and args.password:
            tmdb.auth_v3(force=args.force)
        else:
            tmdb.auth_v4(force=args.force)
    elif args.cmd == 'skel':
        opts = {
            'none': SkelOptions.NONE,
            'first': SkelOptions.SHOW_LAST_SEASONS,
            'last': SkelOptions.SHOW_LAST_SEASONS,
            'all': SkelOptions.SHOW_ALL_SEASONS,
        }
        opt = opts[args.show]
        if args.translations:
            opt |= SkelOptions.TRANSLATIONS
        tmdb.get_skel_en_media(args.ids, options=opt)
