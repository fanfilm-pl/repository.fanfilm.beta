"""
Floppy API (self-hosted tracker, https://github.com/dannyvfilms/Floppy): accounts on any server - the device flow,
progress, watched, ratings, the watchlist (titles `Planning`), the collection and the own lists (a server which offers
their scopes to the device flow, Floppy v26.10.29+). Notes: `notes/services/floppy.md`.

The server of an account is asked at its sign-in and kept in its entry of `/accounts` (configuration, `server`); the client
ID registered there (a public OAuth client, one per server) is in the account data. The access token lives 1 hour, the
refresh token rotates: only the service refreshes it. The change feeds of Floppy are written only for users with a sync
binding on the server side (a token has none), so the sync compares fingerprints of the lists (the count and the newest
row). Only titles of TMDB are read, the other sources (MAL anime, games, books, ...) are skipped. Writes carry their own `Idempotency-Key`.
"""

from __future__ import annotations
from typing import Any, Callable, ClassVar, Iterable, Mapping, Sequence, TYPE_CHECKING
from datetime import date as dt_date, datetime, timedelta
from urllib.parse import urlsplit, urlunsplit
from uuid import uuid4
from attrs import frozen, field
from typing_extensions import Literal
from ..ff import requests
from ..ff.accounts import Account, AccountClient, DeviceAuth, failed_request
from ..ff.ratings import RatingScale, pick_ratings
from ..ff.calendar import utc_timestamp, utc_2_iso
from ..ff.db.playback import MediaPlayInfo, get_playback_rows, update_track_playback, update_track_watched_movies, update_track_watched_episodes
from ..ff.kotools import xsleep
from ..ff.listcache import mark_stale
from ..ff.logs import fflog
from ..ff.settings import advanced_settings
from ..defs import MediaRef, VideoIds
from ..kolang import L
from cdefs import ListSection, ListType
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.types import JsonData, JsonResult, KwArgs
    from ..ff.sync import SyncBucket
    from ..ff.db.kvstore import KeyValueStore
    from ..ff.item import FFItem
    from ..defs import FFRef, ItemList, MainMediaType


#: Scrobble action (`scrobble` `action`).
ScrobbleAction = Literal['start', 'pause', 'stop']

#: The scopes of the device flow: the tracking preset (every server).
SCOPES: str = 'scrobble:write progress:read progress:write watchlist:read watchlist:write catalog:read sync:read'
#: The scopes of the own lists, asked too if the server offers them (`scopes_supported`, Floppy v26.10.29+).
LIST_SCOPES: tuple[str, ...] = ('lists:read', 'lists:write')
#: Rows of a page (the server takes up to 200).
PAGE_LIMIT: int = 200
#: Fields of a row telling its version (the fingerprint of a list: the count and these fields of its first row).
MARK_KEYS: tuple[str, ...] = ('item_id', 'media_id', 'season_number', 'episode_number', 'entry_key', 'id', 'score', 'scored_at',
                              'updated_at', 'end_date', 'collected_at')
#: Status of a completed entry (a watch) in Floppy (`status` of a media row / a consumption).
COMPLETED: int = 3
#: Fields of a row of a list of lists telling its version (the fingerprint of the own lists: every list of the first page).
LIST_MARK_KEYS: tuple[str, ...] = ('id', 'name', 'items_count', 'latest_update')
#: Media types of Floppy of the media of FanFilm (`media_type` of a row / an item).
MOVIE_TYPES: frozenset[str] = frozenset(('movie',))
#: Media types of Floppy of the shows, seasons and episodes.
SHOW_TYPES: frozenset[str] = frozenset(('tv', 'season', 'episode'))


@frozen
class ListQuery:
    """A list of the server (an API path with its query), read for a fingerprint (its first rows) or whole (pages)."""

    #: API path (under `/api/v1/`).
    path: str
    #: Query parameters.
    params: dict[str, Any] = field(factory=dict)
    #: Rows of the fingerprint: 1 - the newest one, more - all of a short list (a change of any row, e.g. the own lists).
    rows: int = 1
    #: Fields of a row in the fingerprint.
    marks: tuple[str, ...] = MARK_KEYS
    #: The scope the list needs besides the tracking preset ('' - none): an account without it does not read it.
    scope: str = ''


#: Sync buckets (`lib.ff.sync`): the lists of their fingerprints (the newest row first), the whole lists of the read buckets.
SYNC_BUCKETS: dict[SyncBucket, tuple[ListQuery, ...]] = {
    'progress.movie': (ListQuery('playback/progress/', {'media_type': 'movie', 'completed': 'false'}),),
    'progress.episode': (ListQuery('playback/progress/', {'media_type': 'episode', 'completed': 'false'}),),
    'watched.movie': (ListQuery('history/', {'flat': 1, 'media_type': 'movie'}),),
    'watched.episode': (ListQuery('history/', {'flat': 1, 'media_type': 'tv'}),),  # the plays of episodes are of `tv`
    'lists.watchlist': (ListQuery('media/', {'status': 0, 'sort': 'date_added', 'direction': 'desc'}),),
    'lists.collection': (ListQuery('collection/'),),
    'ratings': (ListQuery('media/', {'rating': 'rated', 'sort': 'updated'}), ListQuery('media/episode/', {'rating': 'rated', 'sort': 'updated'})),
    'lists.user': (ListQuery('lists/', rows=PAGE_LIMIT, marks=LIST_MARK_KEYS, scope='lists:read'),),
}

#: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
SYNC_LISTS: dict[SyncBucket, str] = {
    'lists.watchlist': 'watchlist',
    'lists.collection': 'collection',
    'ratings': 'rated',
    'lists.user': 'user',  # the lists and their items (`user/<id>`)
}


def iso_timestamp(value: str | None) -> int | None:
    """Return the unix timestamp of an ISO time of Floppy, None if not given."""
    return int(utc_timestamp(value)) if value else None


def item_ref(item: JsonData) -> MediaRef | None:
    """
    Return the reference of an item of Floppy (a row of the progress, an `item` of a media / history / calendar row): `media_type`,
    `source`, `media_id` (an episode / a season: of its show, with its numbers), None if not of TMDB or not a movie / a show.
    """
    typ, media_id = item.get('media_type'), item.get('media_id')
    if item.get('source') != 'tmdb' or not media_id or not str(media_id).isdecimal():
        return None
    ffid = VideoIds.ffid_from_tmdb_id(int(media_id))
    if typ in MOVIE_TYPES:
        return MediaRef.movie(ffid)
    if typ not in SHOW_TYPES:
        return None
    season, episode = item.get('season_number'), item.get('episode_number')
    if typ == 'tv' or season is None:
        return MediaRef.tvshow(ffid)
    if typ == 'season' or episode is None:
        return MediaRef.tvshow(ffid, int(season))
    return MediaRef.tvshow(ffid, int(season), int(episode))


def row_ref(row: JsonData) -> MediaRef | None:
    """Return the reference of a row: its `item` (media, history, collection, calendar) or the row itself (progress, discover)."""
    item = row.get('item')
    return item_ref(item if isinstance(item, dict) else row)


def media_type(ref: MediaRef) -> str:
    """Return the media type of Floppy of a movie / a show (`movie`, `tv`)."""
    return 'movie' if ref.is_movie else 'tv'


def media_path(ref: MediaRef) -> str | None:
    """
    Return the path of a movie / a show / an episode in Floppy (`media/movie/tmdb/<id>/`, `media/tv/tmdb/<id>/`, an episode
    `media/tv/tmdb/<show>/<s>/episodes/<e>/`), None without TMDB or for a season.
    """
    if not (tmdb := ref.video_ids.tmdb) or not (ref.is_movie or ref.type == 'show') or ref.is_season:
        return None
    if ref.is_episode:
        return f'media/tv/tmdb/{tmdb}/{ref.season}/episodes/{ref.episode}/'
    return f'media/{media_type(ref)}/tmdb/{tmdb}/'


def media_body(ref: MediaRef) -> JsonData | None:
    """Return the identity of a movie / an episode in a scrobble / progress body (`media_type`, `ids`, numbers), None if not playable."""
    if not (ids := {key: str(value) for key, value in ref.video_ids.ids().items() if key in ('tmdb', 'imdb', 'tvdb')}):
        return None
    if ref.is_movie:
        return {'media_type': 'movie', 'ids': ids}
    if ref.is_episode:
        return {'media_type': 'episode', 'ids': ids, 'season_number': ref.season, 'episode_number': ref.episode}
    return None


def server_url(text: str) -> str:
    """Return the base URL of a server typed by the user (`https://` if no scheme, no path, no slash at the end), '' if not one."""
    text = text.strip()
    if text and '://' not in text:
        text = f'https://{text}'
    parts = urlsplit(text)
    if parts.scheme not in ('http', 'https') or not parts.netloc:
        return ''
    return urlunsplit((parts.scheme, parts.netloc, parts.path.rstrip('/'), '', ''))


def tmdb_rows(rows: Sequence[JsonData], name: str) -> list[JsonData]:
    """Return the rows of TMDB titles (logging how many of other sources are skipped)."""
    taken = [row for row in rows if row_ref(row) is not None]
    if skipped := len(rows) - len(taken):
        fflog(f'[FLOPPY] {name}: {skipped} rows not of TMDB titles skipped')
    return taken


class FloppyApi(DeviceAuth, AccountClient):
    """Floppy API client of an account (its server in its entry of `/accounts`)."""

    #: Sync buckets of the client (`lib.ff.sync`, `lib.ff.listcache`).
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = SYNC_BUCKETS
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = SYNC_LISTS
    #: Sync interval: fingerprints (no activities of the service for a token).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.fingerprint_interval
    #: Sections of lists of the account: the watchlist (`Planning`), the collection and the own lists (movies and shows; the
    #: own lists need the scopes of lists - an account signed in without them has none).
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'watchlist': ListSection(types=ListType.MAIN),
        'collection': ListSection(types=ListType.MAIN),
        'user': ListSection(types=ListType.MAIN, create={'public': True}),
    }
    #: Rating scale of the account: 0-10 with one decimal, FF writes whole points; seasons have no ratings.
    RATING: ClassVar[RatingScale | None] = RatingScale(type=float, min=1.0, max=10.0, step=1.0, media=('movie', 'show', 'episode'))
    #: A history write keeps the resume point of the media (measured 2026-10-27: a manual stop does not clear it).
    HISTORY_ENDS_PLAYBACK: ClassVar[bool] = False
    #: Data keys of the account forgotten on sign out (the server and its client ID stay: offered at the next sign-in).
    SIGN_OUT_KEYS: ClassVar[tuple[str, ...]] = ('token', 'profile')
    #: Plays of one media removed at most (an unwatch removes them one by one, the newest first).
    MAX_PLAYS: ClassVar[int] = 100

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        super().__init__(account, alias=alias)
        #: Connection session.
        self.sess: requests.Session = requests.Session()

    # --- Account data ---

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists and of the account data: the account ID ('floppy' for none)."""
        return 'floppy' if (account := self.account) is None else account.id

    @property
    def _store(self) -> KeyValueStore:
        """Return the data of the account (`accounts.db`)."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.scope)

    @property
    def server(self) -> str:
        """
        Return the base URL of the server of the account ('' - not signed in yet): its entry of `/accounts`, else the account
        data (where it was kept before; an account recovered from `accounts.db` has no entry field).
        """
        if (account := self.account) is None:
            return ''
        return str(account.config.get('server') or self._store.get('server') or '')

    def credentials(self) -> str:
        """Return the credentials of the account (the refresh token, '' - none or switched off), see `AccountStore.auth_state()`."""
        from ..ff.accounts import type_enabled
        return str(self._token().get('refresh_token') or '') if type_enabled('floppy') and self.server else ''

    def is_enabled(self) -> bool:
        """Return True if the client can ask the service (the type is on and the account has a server and a token)."""
        return bool(self.credentials())

    def granted(self, scope: str) -> bool:
        """Return True if the token of the account has the scope (told by the server at the sign-in)."""
        return scope in str(self._token().get('scope') or '').split()

    # --- HTTP ---

    def _headers(self, *, auth: bool) -> dict[str, str] | None:
        """Return the request headers, None if a token is needed and there is none."""
        from ..ff.control import addonInfo
        headers = {'User-Agent': f'FanFilm/{addonInfo("version")} (Kodi)'}
        if auth:
            if not (token := self._access_token()):
                return None
            headers['Authorization'] = f'Bearer {token}'
        return headers

    def request(self, method: str, path: str, *, params: KwArgs | None = None, json: JsonResult | None = None, auth: bool = True,
                server: str = '', headers: Mapping[str, str] | None = None) -> requests.Response | None:
        """
        Send a request to the server (the account one unless `server`; the account token unless `auth` is false), return the
        response (None: no server / token / connection). A write has its own `Idempotency-Key`: a retry is not run twice.
        A path under `/api/v1/` is given without it, the others (`/oauth/…`, `/apis/…`) with the leading slash.
        """
        if not (base := server or self.server) or (hdrs := self._headers(auth=auth)) is None:
            return None
        hdrs.update(headers or {})
        if method != 'GET':
            hdrs['Idempotency-Key'] = str(uuid4())
        url = f'{base}{path}' if path.startswith('/') else f'{base}/api/v1/{path}'
        resp: requests.Response | None = None
        refreshed = False
        conn = const.floppy.connection
        for _ in range(conn.try_count):
            try:
                resp = self.sess.request(method, url, params=params, json=json, headers=hdrs, timeout=conn.timeout)
            except requests.RequestException as exc:
                fflog(f'[FLOPPY] {method} {path}: {exc}')
                resp = None
                xsleep(conn.try_delay)
                continue
            fflog(f'[FLOPPY] {method} {path} → {resp.status_code}')
            if resp.status_code == 401 and auth and not refreshed and self.refresh_token():
                refreshed = True  # an access token revoked / expired before its time: one more try with a new one
                if (new := self._headers(auth=True)) is None:
                    return resp
                hdrs.update(new)
                continue
            if resp.status_code == 429 or resp.status_code >= 500:
                xsleep(min(60.0, float(resp.headers.get('Retry-After') or conn.try_delay)))
                continue
            return resp
        return resp

    def get(self, path: str, *, params: KwArgs | None = None) -> JsonResult | None:
        """GET JSON (None on failure)."""
        return self._json(self.request('GET', path, params=params))

    def send(self, method: str, path: str, data: JsonResult | None = None) -> JsonResult | None:
        """Send a write (POST / PUT / PATCH / DELETE) with a JSON body, the JSON of the answer (None on failure)."""
        return self._json(self.request(method, path, json=data))

    @staticmethod
    def _json(resp: requests.Response | None) -> JsonResult | None:
        """Return the JSON of a successful answer ({} if empty), None on failure (the error is logged)."""
        if resp is None:
            failed_request(0)
            return None
        try:
            data = resp.json()
        except ValueError:
            data = None
        if resp.status_code >= 400:
            message = data.get('detail') or data.get('error_description') or data.get('error') if isinstance(data, dict) else resp.text[:200]
            fflog(f'[FLOPPY] error {resp.status_code}: {message}')
            failed_request(resp.status_code)
            return None
        return data if data is not None else {}

    def _found(self, method: str, path: str, data: JsonResult | None = None) -> bool:
        """Send a write of one media: True if done, False if the server does not know the media (404); other failures as `_json()`."""
        resp = self.request(method, path, json=data)
        if resp is not None and resp.status_code == 404:
            fflog(f'[FLOPPY] {method} {path}: not found')
            return False
        return self._json(resp) is not None

    def pages(self, query: ListQuery) -> list[JsonData] | None:
        """Return all rows of a list (pages walked by `offset`), None on failure."""
        rows: list[JsonData] = []
        while True:
            data = self.get(query.path, params={**query.params, 'limit': PAGE_LIMIT, 'offset': len(rows)})
            if not isinstance(data, dict) or not isinstance(results := data.get('results'), list):
                return None
            rows.extend(row for row in results if isinstance(row, dict))
            if not results or not (data.get('pagination') or {}).get('next'):
                return rows

    def fingerprint(self, query: ListQuery) -> str | None:
        """Return the fingerprint of a list: its count and the version of its first rows (`query.rows`), None on failure."""
        data = self.get(query.path, params={**query.params, 'limit': query.rows})
        if not isinstance(data, dict) or not isinstance(results := data.get('results'), list):
            return None
        rows = [row for row in results[:query.rows] if isinstance(row, dict)] or [{}]
        mark = ';'.join('|'.join(str(row.get(key) or '') for key in query.marks) for row in rows)
        return f'{(data.get("pagination") or {}).get("total", len(results))}:{mark}'

    # --- Authorization (`DeviceAuth`) ---

    def auth(self, *, force: bool = False) -> bool | None:
        """
        Sign in the account: the server (asked, the last one offered; checked by `/api/v1/info`), its client ID (registered
        once per server) and the device code. Another server is another user (its data dropped). True on success, False on
        failure, None if canceled by the user.
        """
        from ..ff.ui import ui
        if self.account is None:
            return False
        old = self.server
        if (text := ui.input(L(30251, 'Floppy server address'), old or 'https://')) is None:
            return None
        if not (url := server_url(text)) or not isinstance(info := self._json(self.request('GET', 'info/', auth=False, server=url)), dict) \
                or 'version' not in info:
            ui.notify(self.account.label, L(30294, 'No Floppy server at {url}').format(url=text.strip()), error=True)
            return False
        if url != old:
            if old:
                self.unauth()  # the token of the old server
                self._drop_user_data()
            from ..ff.account_admin import set_entry_field
            if (new := set_entry_field(self.account, 'server', url)) is None:
                return False
            if self._account is not None:
                self._account = new
            self._store.delete('server')
            self._store.delete('client')
            force = True
        if not self._client_id():
            return False
        return super().auth(force=force)

    def _client_id(self, *, again: bool = False) -> str:
        """Return the client ID of FanFilm on the server of the account: registered at the first use (or `again`), '' on failure."""
        if not again and (client := self._store.get('client') or {}).get('url') == self.server and client.get('client_id'):
            return str(client['client_id'])
        from ..ff.control import addonInfo
        data = self._json(self.request('POST', '/oauth/register', json={'client_name': f'FanFilm {addonInfo("version")} (Kodi)'}, auth=False))
        if not isinstance(data, dict) or not data.get('client_id'):
            return ''
        self._store.set('client', {'url': self.server, 'client_id': data['client_id']}, ttl=None)
        return str(data['client_id'])

    def _scopes(self) -> str:
        """Return the scopes asked at the sign-in: the tracking preset and the own lists if the server offers them."""
        meta = self._json(self.request('GET', '/.well-known/oauth-authorization-server', auth=False))
        offered = set(meta.get('scopes_supported') or ()) if isinstance(meta, dict) else set()
        return ' '.join((SCOPES, *(scope for scope in LIST_SCOPES if scope in offered)))

    def _device_code(self) -> requests.Response | None:
        """
        Ask for a device code. An unknown client (a registration not used for a day is dropped by the server) or one registered
        before the server offered the scopes of lists (`invalid_scope`) is registered again.
        """
        scope = self._scopes()
        resp = self.request('POST', '/oauth/device/authorization', json={'client_id': self._client_id(), 'scope': scope}, auth=False)
        if resp is not None and resp.status_code in (400, 401) and self._error(resp) in ('invalid_client', 'invalid_scope') \
                and self._client_id(again=True):
            resp = self.request('POST', '/oauth/device/authorization', json={'client_id': self._client_id(), 'scope': scope}, auth=False)
        return resp

    def _poll_token(self, device_code: str) -> requests.Response | None:
        """Ask for the token of the device code."""
        return self.request('POST', '/oauth/token', auth=False, json={'client_id': self._client_id(), 'device_code': device_code,
                                                                        'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'})

    def _refresh_request(self, refresh: str) -> requests.Response | None:
        """Exchange the refresh token for a new pair (the old one is dead then: a reuse revokes the whole sign-in)."""
        return self.request('POST', '/oauth/token', auth=False, json={'client_id': self._client_id(), 'grant_type': 'refresh_token',
                                                                        'refresh_token': refresh})

    def _revoke_token(self, token: Mapping[str, Any]) -> None:
        """Revoke the sign-in in Floppy (the refresh token: its whole rotation)."""
        self.request('POST', '/oauth/revoke', auth=False, json={'client_id': self._client_id(), 'token': token['refresh_token']})

    def _verification_url(self, code: Mapping[str, Any]) -> str:
        """
        Return the link with the code (`verification_uri_complete`) on the address of the account server: a server behind a
        proxy may give its own scheme / host (`http://`).
        """
        link = urlsplit(str(code.get('verification_uri_complete') or f'{self.server}/oauth/device?user_code={code["user_code"]}'))
        base = urlsplit(self.server)
        return urlunsplit((base.scheme, base.netloc, link.path, link.query, ''))

    @staticmethod
    def _auth_title() -> str:
        """Return the title of the sign-in window."""
        return L(30297, '[B]Authorize Floppy[/B]')

    @staticmethod
    def _refresh_before() -> float:
        """Return the seconds before the end of the access token when it is refreshed."""
        return const.floppy.auth.refresh_before

    def refresh_profile(self) -> JsonData | None:
        """
        Get the user of the account and keep it as the account profile (`id`: the server and the user, `username`), None on
        failure. The user name is told by the token check of the ListenBrainz API (any scope; `Token`, not `Bearer`).
        """
        if self.account is None or not (token := self._access_token()):
            return None
        data = self._json(self.request('GET', '/apis/listenbrainz/1/validate-token', auth=False, headers={'Authorization': f'Token {token}'}))
        if not isinstance(data, dict) or not data.get('valid') or not (user := data.get('user_name')):
            return None
        profile = {'id': f'{self.server}#{user}', 'username': str(user), 'server': self.server}
        self._store.set('profile', profile, ttl=None)
        return profile

    # --- Progress and watched (`lib.service` senders) ---

    def scrobble_ref(self, action: ScrobbleAction, ref: MediaRef, progress: float = 0.0) -> bool:
        """
        Scrobble the playback (`start` / `pause`: the Now Playing card only, `stop`: the resume point, a play from Kodi's
        threshold, sent as `completed`). The position is a percent (Floppy takes it of the runtime it knows).
        """
        if (body := media_body(ref)) is None:
            return False
        body = {**body, 'action': action, 'progress_percent': round(min(100.0, max(0.0, float(progress))), 2)}
        if action == 'stop':
            body['completed'] = progress >= advanced_settings.watched_percent()
        return self.send('POST', 'scrobble/', body) is not None

    def _episodes(self, ref: MediaRef) -> list[MediaRef]:
        """Return the movie / the episode itself, the aired episodes of a show / a season (FanFilm metadata)."""
        if not ref.is_container:
            return [ref]
        from ..ff.info import ffinfo
        return ffinfo.aired_episode_refs(ref)

    def add_history_refs(self, items: Sequence[tuple[MediaRef, float | None]]) -> bool:
        """
        Mark the media watched (each now or at its time; a show / a season: its aired episodes), one manual stop each: a title
        watched already stays as it is (one play), a new one is added. Return True if every media was found.
        """
        found = True
        for ref, at in items:
            for episode in self._episodes(ref):
                if (body := media_body(episode)) is None:
                    found = False
                    continue
                body = {**body, 'action': 'stop', 'completed': True, 'manual': True, **({'played_at': utc_2_iso(at)} if at else {})}
                found = self._found('POST', 'scrobble/', body) and found
        return found

    def add_history_ref(self, ref: MediaRef, *, watched_at: float | None = None) -> bool:
        """Mark the media watched (now or at `watched_at`), see `add_history_refs()`."""
        return self.add_history_refs([(ref, watched_at)])

    def _watched_episodes(self, ref: MediaRef) -> list[MediaRef] | None:
        """Return the episodes of the show / the season `ref` with plays in Floppy (its history), None on failure."""
        params: dict[str, Any] = {'flat': 1, 'media_type': 'tv', 'source': 'tmdb', 'media_id': ref.video_ids.tmdb}
        if ref.season is not None:
            params['season_number'] = ref.season
        if (rows := self.pages(ListQuery('history/', params))) is None:
            return None
        return list(dict.fromkeys(ep for row in rows if (ep := row_ref(row)) is not None and ep.is_episode))

    def remove_history_refs(self, refs: Sequence[MediaRef]) -> bool:
        """
        Mark the media unwatched: all their plays (rewatches too) leave the history, one by one; a movie entry completed by
        itself (a manual mark, a scrobble) goes back to `In progress` like an unplayed mark of Floppy (its rating stays).
        Return True if done.
        """
        for ref in refs:
            targets = self._watched_episodes(ref) if ref.is_container else [ref]
            if targets is None:
                return False
            for target in targets:
                if (path := media_path(target)) is None:
                    continue
                for _ in range(self.MAX_PLAYS):  # the newest play each time, 404 - none left (or the media is not tracked)
                    if not self._found('DELETE', f'{path}watch/'):
                        break
                if target.is_movie and not self._revert_completed(path):
                    return False
        return True

    def _revert_completed(self, path: str) -> bool:
        """Move the completed entries of the movie (`path`) back to `In progress` (out of the history), False on failure."""
        resp = self.request('GET', path)
        if resp is not None and resp.status_code == 404:
            return True  # not tracked: nothing watched
        if not isinstance(data := self._json(resp), dict):
            return False
        return all(self._found('PATCH', f'{path}history/{row["consumption_id"]}/', {'status': 'In progress', 'end_date': None})
                   for row in data.get('consumptions') or () if isinstance(row, dict) and row.get('status') == COMPLETED and row.get('consumption_id'))

    def remove_history_ref(self, ref: MediaRef) -> bool:
        """Mark the media unwatched, see `remove_history_refs()`."""
        return self.remove_history_refs([ref])

    def _duration(self, ref: MediaRef) -> int | None:
        """Return the duration (seconds) of the media known to FanFilm (the rows of the account and of the local Kodi), None if none."""
        assert self.account is not None
        return next((pb.duration for pb in get_playback_rows([ref], accounts=(self.account.id, 'kodi')) if pb.duration), None)

    def set_playback_refs(self, items: Sequence[tuple[MediaRef, float, float]]) -> bool:
        """
        Set the resume points of the media `(ref, progress, paused_at)`; Floppy keeps them in seconds, the duration is the one
        FanFilm knows (a media without it is skipped, logged). Return True if every media was found.
        """
        found = True
        for ref, progress, _at in items:
            if (body := media_body(ref)) is None:
                found = False
                continue
            if not (duration := self._duration(ref)):
                fflog(f'[FLOPPY] resume point of {ref} not sent: no duration known')
                continue
            body = {**body, 'position_seconds': int(duration * float(progress) / 100), 'duration_seconds': duration}
            found = self._found('PUT', 'playback/progress/', body) and found
        return found

    def set_playback_ref(self, ref: MediaRef, progress: float, *, paused_at: float) -> bool:
        """Set the resume point of the media paused at `paused_at`, see `set_playback_refs()`."""
        return self.set_playback_refs([(ref, progress, paused_at)])

    def remove_playback_ref(self, ref: MediaRef) -> bool:
        """Remove the resume point of the media (no play is logged)."""
        if (body := media_body(ref)) is None:
            return False
        return self.send('DELETE', 'playback/progress/', body) is not None

    # --- Sync (`lib.ff.sync`) ---

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """Return cursors of the sync buckets of the account (`lib.ff.sync`): fingerprints of their lists, None on failure."""
        cursors: dict[SyncBucket, str] = {}
        for bucket, queries in SYNC_BUCKETS.items():
            if any(query.scope and not self.granted(query.scope) for query in queries):
                continue  # e.g. the own lists of an account signed in without their scopes
            marks = [self.fingerprint(query) for query in queries]
            if any(mark is None for mark in marks):
                return None
            cursors[bucket] = ';'.join(str(mark) for mark in marks)
        return cursors

    def sync_bucket(self, bucket: SyncBucket, cursor: str | None = None) -> bool | None:
        """Get the bucket data (the whole lists) and store rows of the account. Return True if changed, None on failure."""
        assert self.account is not None  # sync is login required
        account_id = self.account.id
        movie = bucket.endswith('.movie')
        if (rows := self.pages(SYNC_BUCKETS[bucket][0])) is None:
            return None
        rows = tmdb_rows(rows, bucket)
        if bucket.startswith('progress.'):
            plays = [pb for row in rows if (pb := self._playback_row(row))]
            return update_track_playback(plays, account_id=account_id, media_type='movie' if movie else 'show')
        watched: dict[MediaRef, MediaPlayInfo] = {}
        for row in rows:  # a row a play (a movie row may count more)
            if (ref := row_ref(row)) is None or (ref.is_movie != movie) or not (ref.is_movie or ref.is_episode):
                continue
            at = iso_timestamp(row.get('end_date') or row.get('created_at')) or 0
            old = watched.get(ref)
            count = int(row.get('play_count') or 1)
            watched[ref] = MediaPlayInfo(ref=ref, play_count=count + (old.play_count or 0 if old else 0),
                                         last_watched_at=max(at, old.last_watched_at or 0) if old else at)
        if movie:
            return update_track_watched_movies(list(watched.values()), account_id=account_id)
        return update_track_watched_episodes(list(watched.values()), account_id=account_id)

    @staticmethod
    def _playback_row(row: JsonData) -> MediaPlayInfo | None:
        """Return the playback row of a resume point (its percent and time), None without a reference or a position."""
        position, duration = row.get('position_seconds'), row.get('duration_seconds')
        if (ref := row_ref(row)) is None or not position or not duration or row.get('completed'):
            return None
        return MediaPlayInfo(ref=ref, progress=min(100.0, 100 * float(position) / float(duration)),
                             paused_at=iso_timestamp(row.get('updated_at')), duration=int(duration))

    def _changed(self, name: str) -> None:
        """Mark the cached list `name` of the account as changed (an own change)."""
        mark_stale(self.scope, name)

    # --- Lists of the account: watchlist (`Planning`), collection ---

    def _cached_rows(self, name: str, query: ListQuery | Sequence[ListQuery], *, bucket: str) -> list[tuple[MediaRef, JsonData]]:
        """Return the rows of TMDB titles of the list `name` of the account (the list cache), with their references."""
        from ..ff.listcache import FetchedList, cached_list
        queries = (query,) if isinstance(query, ListQuery) else query

        def fetch() -> FetchedList | None:
            rows: list[JsonData] = []
            for one in queries:
                if (part := self.pages(one)) is None:
                    return None
                rows.extend(part)
            return FetchedList([(row_ref(row), row) for row in tmdb_rows(rows, name)])

        stored = cached_list(self.scope, name, fetch, bucket=bucket)
        return [] if stored is None else [(ref, row) for row in stored.items if (ref := row_ref(row)) is not None]

    def _titles(self, name: str, query: ListQuery | Sequence[ListQuery] | None = None, *, bucket: str = '', media: MainMediaType | None,
                page: int | None) -> ItemList[FFItem]:
        """
        Return the page of the list `name` of the account (all items without `page`), only the `media` if given; the list of a
        section (`watchlist`, `collection`) by default, else of the `query` in the sync `bucket`.
        """
        from ..ff.item import FFItem, ListEntry
        from ..defs import ItemList
        if query is None:
            query, bucket = SYNC_BUCKETS[f'lists.{name}'], f'lists.{name}'
        rows = [(ref, row) for ref, row in self._cached_rows(name, query, bucket=bucket)
                if ref.is_movie or (ref.type == 'show' and ref.season is None)]
        items: list[FFItem] = []
        for ref, row in rows:
            if not media or ref.type == media:
                it = FFItem(ref)
                it.list_entry = ListEntry.new(added_at=row.get('collected_at') or row.get('created_at'))
                items.append(it)
        if not page:
            return ItemList.single(items)
        size = const.indexer.floppy.page_size
        return ItemList(items[(page - 1) * size:page * size], page=page, page_size=size, total_pages=(len(items) + size - 1) // size,
                        total_results=len(items))

    def watchlist(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist (`Planning`) of the account: movies and shows, newest first."""
        return self._titles('watchlist', media=media, page=page)

    def collection(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the collection (owned copies) of the account: movies and shows."""
        return self._titles('collection', media=media, page=page)

    @staticmethod
    def _titles_of(items: Iterable[FFRef]) -> list[MediaRef]:
        """Return the movies and the shows of the items (other media are skipped)."""
        return [ref for it in items if (ref := it.ref).is_movie or (ref.type == 'show' and ref.season is None)]

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """
        Add (`state`) movies / shows to the watchlist (a `Planning` entry) or remove them (only their `Planning` entries: the
        title with its history stays), return the number of changed ones.
        """
        planned = {ref: row for ref, row in self._cached_rows('watchlist', SYNC_BUCKETS['lists.watchlist'], bucket='lists.watchlist')}
        count = 0
        for ref in self._titles_of(items):
            if (path := media_path(ref)) is None:
                continue
            if state:
                if ref not in planned and self.send('POST', f'media/{media_type(ref)}/',
                                                    {'source': 'tmdb', 'media_id': str(ref.video_ids.tmdb), 'status': 'Planning'}) is not None:
                    count += 1
            elif (row := planned.get(ref)) is not None and row.get('consumption_id') and self._found('DELETE', f'{path}history/{row["consumption_id"]}/'):
                count += 1
        self._changed('watchlist')
        return count

    def set_collection(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) movies / shows to the collection or remove them, return the number of changed ones."""
        count = 0
        for ref in self._titles_of(items):
            if (path := media_path(ref)) is not None and self._found('PUT' if state else 'DELETE', f'{path}collection/', {} if state else None):
                count += 1
        self._changed('collection')
        return count

    # --- Own lists (`lists:*`: an account signed in with them, a server of Floppy v26.10.29+) ---

    def user_lists(self) -> list[FFItem]:
        """
        Return the own lists of the account (folders with `list_id`, read by `ListTarget.from_ffitem()`), none without the scope
        of lists. A smart list (its items come from its rules) or a list the user may not change is read only (`list_readonly`).
        """
        from ..ff.listcache import FetchedList, cached_list
        if not self.granted('lists:read'):
            return []

        def fetch() -> FetchedList | None:
            if (rows := self.pages(ListQuery('lists/'))) is None:
                return None
            for row in rows:  # `is_smart` only in the rules of the list (403: not editable by the user)
                rules = self.request('GET', f'lists/{row.get("id")}/smart-rules/')
                data = self._json(rules) if rules is not None and rules.status_code != 403 else None
                row['readonly'] = not isinstance(data, dict) or bool(data.get('is_smart'))
            return FetchedList([(None, row) for row in rows if row.get('id')])

        stored = cached_list(self.scope, 'user', fetch, bucket='lists.user')
        user = str((self._store.get('profile') or {}).get('username') or '')
        return [] if stored is None else [self._list_folder(row, user) for row in stored.items]

    @staticmethod
    def _list_folder(row: JsonData, user: str) -> FFItem:
        """Return the folder of a list row (`list_id`); its owner in the plot if not the user, a read only one marked."""
        from ..ff.item import FFItem
        name = str(row.get('name') or row['id'])
        it = FFItem(name, mode=FFItem.Mode.Folder)
        it.title = name
        it.setProperty('list_id', str(row['id']))
        plot = [L(32932, 'by {user}').format(user=owner)] if (owner := (row.get('owner') or {}).get('username')) and owner != user else []
        if descr := row.get('description'):
            plot.append(str(descr))
        if plot:
            it.vtag.setPlot('\n\n'.join(plot))
        if (total := row.get('items_count')) is not None:
            it._children_count = int(total)
            it.role = L(30331, '{n} title|||{n} titles', n=int(total))
        if row.get('readonly'):
            it.setProperty('list_readonly', 'true')
        if str(image := row.get('image') or '').startswith(('http://', 'https://')):  # not the placeholder of an empty list (data:)
            it.setArt({'thumb': image, 'fanart': image})
        return it

    def list_items(self, list_id: int | str, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the movies and the shows of an own list of the account (its order), none without the scope of lists."""
        from ..defs import ItemList
        if not self.granted('lists:read'):
            return ItemList.single([])
        return self._titles(f'user/{list_id}', ListQuery(f'lists/{list_id}/items/'), bucket='lists.user', media=media, page=page)

    def set_in_list(self, list_id: int | str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) movies / shows to an own list or remove them, return the number of changed ones (one in it / not in it: unchanged)."""
        count = 0
        for ref in self._titles_of(items):
            if not (tmdb := ref.video_ids.tmdb):
                continue
            resp = self.request('PUT' if state else 'DELETE', f'media/{media_type(ref)}/tmdb/{tmdb}/lists/{list_id}/', json={} if state else None)
            if resp is not None and resp.status_code in (404, 409):  # not in the list / in it already
                continue
            if self._json(resp) is not None:
                count += 1
        self._changed(f'user/{list_id}')
        self._changed('user')  # the item counts
        return count

    def create_list(self, name: str, *, public: bool = False) -> int | None:
        """Create an own list (private unless `public`), return its ID, None on failure."""
        data = self.send('POST', 'lists/', {'name': name, 'is_public': public})
        self._changed('user')
        return int(data['id']) if isinstance(data, dict) and data.get('id') else None

    def delete_list(self, list_id: int | str) -> bool:
        """Delete an own list (with its items)."""
        ok = self._found('DELETE', f'lists/{list_id}/')
        self._changed(f'user/{list_id}')
        self._changed('user')
        return ok

    def rename_list(self, list_id: int | str, name: str) -> str | None:
        """Rename an own list, return its ID, None on failure."""
        data = self.send('PATCH', f'lists/{list_id}/', {'name': name})
        self._changed('user')
        return str(list_id) if isinstance(data, dict) and data.get('id') else None

    # --- Ratings: 0-10 with one decimal ---

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, float]:
        """Return the ratings of the account by media (movies, shows, episodes; from the list cache), only of the media `refs` if given."""
        rows = self._cached_rows('rated', SYNC_BUCKETS['ratings'], bucket='ratings')
        return pick_ratings({ref: float(row['score']) for ref, row in rows if row.get('score') is not None}, refs)

    def set_ratings(self, items: Iterable[FFRef], rating: float | None) -> int:
        """
        Rate (`rating`) the media or remove their ratings (None), return the number of changed ones. Floppy rates only the
        titles it tracks: another one is not found (rating it would make a `Planning` entry - the watchlist).
        """
        score = None if rating is None else round(float(rating), 1)
        count = 0
        for it in items:
            ref = it.ref
            if (path := media_path(ref)) is None:
                continue
            if self._found('PATCH', f'{path}score/' if ref.is_episode else path, {'score': score}):
                count += 1
        self._changed('rated')
        return count

    # --- Floppy itself: the calendar, Discover, Home ---

    def _catalog(self, name: str, path: str, params: KwArgs, fetch_rows: Callable[[JsonData], list[JsonData]]) -> list[JsonData]:
        """Return the rows of a catalog answer of the account (`catalog:read`) through the list cache (a TTL list)."""
        from ..ff.listcache import FetchedList, cached_list, list_params

        def fetch() -> FetchedList | None:
            if not isinstance(data := self.get(path, params=params), dict):
                return None
            return FetchedList([(None, row) for row in fetch_rows(data)])

        stored = cached_list(self.scope, name, fetch, params=list_params(**params), kind='trending')
        return [] if stored is None else list(stored.items)

    def calendar(self, media: MainMediaType) -> list[tuple[MediaRef, dt_date]]:
        """
        Return the calendar of the tracked titles (`const.indexer.tvshows.calendar_range`) as the titles and their local days, the
        newest first, once each: movies released or episodes aired.
        """
        today = dt_date.today()
        start, end = (today + timedelta(days=days) for days in sorted(const.indexer.tvshows.calendar_range))
        params = {'start_date': str(start), 'end_date': str(end)}
        rows = self._catalog('calendar', 'calendar/', params, lambda data: [row for row in data.get('results') or () if isinstance(row, dict)])
        days: dict[MediaRef, dt_date] = {}
        for row in sorted(rows, key=lambda row: str(row.get('datetime') or ''), reverse=True):
            if (ref := row_ref(row)) is None or ref.is_movie != (media == 'movie') or not (ref.is_movie or ref.is_episode):
                continue
            try:
                day = datetime.fromisoformat(str(row['datetime']).replace('Z', '+00:00')).astimezone().date()
            except (KeyError, ValueError):
                continue
            days.setdefault(ref, day)
        return list(days.items())

    def discover_rows(self, media: MainMediaType) -> list[JsonData]:
        """Return the Discover rows of the account of the media (`title`, `refs` of TMDB titles of the media), the empty ones skipped."""
        typ = 'movie' if media == 'movie' else 'tv'
        rows = self._catalog('discover', 'discover/', {'media_type': typ}, lambda data: [row for row in data.get('rows') or () if isinstance(row, dict)])
        return self._media_rows(rows, typ)

    def home_rows(self, media: MainMediaType) -> list[JsonData]:
        """Return the Home rows of the account (set by the user in Floppy) of the media, the empty ones skipped."""
        types = MOVIE_TYPES if media == 'movie' else SHOW_TYPES
        rows = self._catalog('home', 'home/', {}, lambda data: [{**row, 'media_type': group.get('media_type')}
                                                               for group in data.get('groups') or () if isinstance(group, dict)
                                                               for row in group.get('rows') or () if isinstance(row, dict)])
        return self._media_rows([row for row in rows if row.get('media_type') in types], 'movie' if media == 'movie' else 'tv')

    @staticmethod
    def _media_rows(rows: Iterable[JsonData], typ: str) -> list[JsonData]:
        """Return the rows with only their items of TMDB titles of the media type (a season / an episode: its show), the empty ones skipped."""
        result = []
        for row in rows:
            refs = [ref for it in row.get('items') or () if isinstance(it, dict) and (ref := row_ref(it)) is not None
                    and ref.is_movie == (typ == 'movie')]
            if refs := list(dict.fromkeys(MediaRef.tvshow(ref.ffid) if ref.type == 'show' else ref for ref in refs)):
                result.append({'title': str(row.get('title') or ''), 'refs': refs})
        return result

    @staticmethod
    def _error(resp: requests.Response) -> str:
        """Return the OAuth error code of an answer (`error`), '' if none."""
        try:
            data = resp.json()
        except ValueError:
            return ''
        return str(data.get('error') or '') if isinstance(data, dict) else ''


#: Client of the type alias (the first Floppy account).
floppy: FloppyApi = FloppyApi(alias='floppy')


def make_client(account: Account | None) -> FloppyApi:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return floppy if account is None else FloppyApi(account)
