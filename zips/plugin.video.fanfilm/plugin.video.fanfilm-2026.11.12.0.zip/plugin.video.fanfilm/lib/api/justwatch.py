
from __future__ import annotations

import re
import unicodedata
from datetime import date as dt_date, timedelta
from typing import Any, Callable, Collection, Iterable, TypeVar, TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired

from ..ff import cleantitle
from ..ff.accounts import AccountClient
from ..kolang import L
from ..ff.logs import fflog
from cdefs import ListSection, ListType
from const import const, CONST_REF

if TYPE_CHECKING:
    from typing import ClassVar, Mapping
    from ..ff.sync import SyncBucket
    from ..defs import MainMediaType, MediaRef, FFRef, ItemList
    from ..ff.item import FFItem
    from ..ff.accounts import Account
    from ..ff.db.kvstore import KeyValueStore
    from ..ff.listcache import FetchedList
    from ..ff.types import JsonData


#: JustWatch full path, e.g. "/us/film/inception".
JWPath = str
#: Opaque JustWatch node ID.
JWNodeId = str
#: Content type: "movie" or "show".
ContentType = str
#: An item of a list of titles (`JustWatchAccount._titles()`).
T = TypeVar('T')
#: The service of JustWatch nodes in the ID map of `media.db`.
JW_ID_SERVICE: str = 'justwatch'
#: FanFilm media types of JustWatch object types (lists of users: movies and shows only).
JW_MEDIA_TYPES: dict[str, MainMediaType] = {'MOVIE': 'movie', 'SHOW': 'show'}


class JWExternalIds(TypedDict):
    imdbId: str | None
    tmdbId: NotRequired[str | None]


class JWContent(TypedDict):
    title: str
    originalReleaseYear: int
    externalIds: JWExternalIds | None
    fullPath: JWPath
    seasonNumber: NotRequired[int]
    episodeNumber: NotRequired[int]


class JWSearchNode(TypedDict):
    content: JWContent


class JWSearchEdge(TypedDict):
    node: JWSearchNode


class JWSeason(TypedDict):
    id: JWNodeId
    content: JWContent


class JWEpisode(TypedDict):
    id: JWNodeId
    content: JWContent


class JWPackage(TypedDict):
    clearName: NotRequired[str]
    shortName: str


class JWOffer(TypedDict):
    package: JWPackage
    standardWebURL: NotRequired[str]
    deeplinkRoku: NotRequired[str]
    audioLanguages: NotRequired[list[str]]
    subtitleLanguages: NotRequired[list[str]]


class JWOffers(TypedDict):
    flatrate: NotRequired[list[JWOffer]]
    buy: NotRequired[list[JWOffer]]
    rent: NotRequired[list[JWOffer]]
    free: NotRequired[list[JWOffer]]


class JWNewTitle(TypedDict):
    type: MainMediaType       # 'movie' or 'show'
    imdb_id: str              # IMDB id (e.g. 'tt1234567'), empty string if missing
    tmdb_id: str              # TMDB id (e.g. '79461'), empty string if missing; JustWatch IMDb IDs are wrong sometimes
    services: dict[str, str]  # [shortNames] = clearNames for display (e.g. ['nfx'] = 'Netflix')
    season: int | None        # the newest new season of a show (0: specials), None for movies / unknown
    date: dt_date | None      # YYYY-MM-DD


# --- TypedDicts for newTitleBuckets response ---

class JWShowContent(TypedDict):
    showExternalIds: JWExternalIds | None


class JWShowRef(TypedDict):
    showObjectId: int
    showContent: NotRequired[JWShowContent]


class JWSeasonContent(TypedDict):
    seasonNumber: int


class JWNewTitleNode(TypedDict):
    objectId: int
    content: NotRequired[JWContent]
    objectType: NotRequired[str]
    show: NotRequired[JWShowRef]
    seasonContent: NotRequired[JWSeasonContent]


class JWNewOffer(TypedDict):
    package: NotRequired[JWPackage]


class JWNewTitleEdge(TypedDict):
    node: JWNewTitleNode
    newOffer: NotRequired[JWNewOffer]


class JWBucketKey(TypedDict):
    date: str
    package: NotRequired[JWPackage]


class JWBucketNode(TypedDict):
    edges: list[JWNewTitleEdge]


class JWBucketEdge(TypedDict):
    key: JWBucketKey
    node: NotRequired[JWBucketNode]


class JWPageInfo(TypedDict):
    hasNextPage: bool
    endCursor: str


class JWNewTitleBuckets(TypedDict):
    edges: list[JWBucketEdge]
    pageInfo: JWPageInfo


class JustWatchError(Exception):
    """JustWatch API returned an error or something that is not a GraphQL result."""

    def __init__(self, message: str, *, codes: Collection[str] = ()) -> None:
        super().__init__(message)
        #: Codes of the GraphQL errors (`extensions.code`, e.g. `AUTHORIZATION_REQUIRED`).
        self.codes: frozenset[str] = frozenset(codes)


class JustWatchGraphQL:
    """Low-level JustWatch GraphQL API client."""

    def __init__(self, country: str = '', language: str = '') -> None:
        self.base_url: str = 'https://apis.justwatch.com/graphql'
        self.retries: int = 3
        self.country: str = country if country else 'US'
        self.language: str = language if language else 'en'

    def execute(self, query: str, params: dict[str, Any], *, headers: dict[str, str] | None = None) -> Any:
        """Send a GraphQL query and return its data. It is a plain JSON POST, no GraphQL library is needed."""
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        with requests.Session() as session:
            retry = Retry(total=self.retries, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504], allowed_methods=None)
            session.mount('https://', HTTPAdapter(max_retries=retry))
            # JustWatch rejects (403) the default `requests` user agent
            response = session.post(self.base_url, json={'query': query, 'variables': params},
                                    headers={'User-Agent': 'python-httpx/0.27.0', **(headers or {})}, verify=True,
                                    timeout=const.justwatch.connection.timeout)
        try:
            result = response.json()
        except ValueError:
            response.raise_for_status()
            raise
        if not isinstance(result, dict) or ('errors' not in result and 'data' not in result):
            response.raise_for_status()
            raise JustWatchError(f'JustWatch did not return a GraphQL result: {str(result)[:300]}')
        if errors := result.get('errors'):
            codes = [code for err in errors if isinstance(err, dict) and (code := (err.get('extensions') or {}).get('code'))]
            raise JustWatchError(f'JustWatch GraphQL error: {str(errors)[:300]}', codes=codes)
        return result.get('data')

    def search_item(self, title: str):
        from .justwatch_queries import SUGGESTED_TITLES
        params = {
            "country": self.country,
            "language": self.language,
            "first": 4,
            "filter": {
                "searchQuery": title
            }
        }
        return self.execute(SUGGESTED_TITLES, params)

    def get_providers(self, node_id: str):
        from .justwatch_queries import TITLE_OFFERS
        params = {
            "platform": "WEB",
            "nodeId": node_id,
            "country": self.country,
            "language": self.language,
            "filterBuy": {
                "monetizationTypes": [
                    "BUY"
                ],
                "bestOnly": True
            },
            "filterFlatrate": {
                "monetizationTypes": [
                    "FLATRATE",
                    "FLATRATE_AND_BUY",
                    "ADS",
                    "FREE"
                ],
                "bestOnly": True
            },
            "filterRent": {
                "monetizationTypes": [
                    "RENT"
                ],
                "bestOnly": True
            },
            "filterFree": {
                "monetizationTypes": [
                    "ADS",
                    "FREE"
                ],
                "bestOnly": True
            }
        }
        return self.execute(TITLE_OFFERS, params)

    def get_title(self, full_path: str):
        from .justwatch_queries import URL_TITLE_DETAILS
        params = {
            "platform": "WEB",
            "fullPath": full_path,
            "language": self.language,
            "country": self.country,
            "episodeMaxLimit": const.justwatch.episode_max_limit,
        }
        return self.execute(URL_TITLE_DETAILS, params)

    def new_titles(self, after: str = '', *, object_types: Iterable[str] = ('MOVIE',)):
        from .justwatch_queries import NEW_TITLE_BUCKETS
        params = {
                "allowSponsoredRecommendations": {
                  "country": "PL",
                  "platform": "ANDROID"
                },
                "country": self.country,
                "filter": {
                  "excludeIrrelevantTitles": False,
                  "objectTypes": list(object_types),
                  "packages": []
                },
                "first": 5,
                "imageFormat": "WEBP",
                "language": self.language,
                "packages": [],
                "pageType": "NEW",
                "platform": "ANDROID",
                "priceDrops": False
              }
        if after:
            params['after'] = after
        return self.execute(NEW_TITLE_BUCKETS, params)


class JustWatchClient:
    """
    Typed wrapper around JustWatchGraphQL for FanFilm use.

    Provides high-level operations:
      - find_title()           – search + match + slug fallback → JWPath
      - title_node()           – a movie / show → JWNodeId (the ID map, else found and checked by its IDs)
      - episode_node()         – an episode → JWNodeId (the ID map, else by the show path; kept for a while)
      - find_episode_node_id() – JWPath + S/E → JWNodeId (episodes)
      - get_offers()           – JWNodeId → JWOffers (streaming providers)
    """

    def __init__(self, country: str = 'US', language: str = 'en') -> None:
        #: The country ('' - the `external.country` setting at use, `PL` without it).
        self._country: str = country
        self.language = language
        self._api_en: JustWatchGraphQL | None = None
        self._api_local: JustWatchGraphQL | None = None

    @property
    def country(self) -> str:
        """Return the country of the client (the setting `external.country` if not given)."""
        if self._country:
            return self._country
        from ..sources.natives import provider_value
        return provider_value('external', 'country') or 'PL'

    def _get_api_en(self) -> JustWatchGraphQL:
        if self._api_en is None:
            self._api_en = JustWatchGraphQL(country=self.country)
        return self._api_en

    def _get_api_local(self) -> JustWatchGraphQL:
        if self._api_local is None:
            self._api_local = JustWatchGraphQL(country=self.country, language=self.language)
        return self._api_local

    def packages(self) -> list[tuple[str, str]]:
        """Return the VOD services of the country (short name, name) in the order of JustWatch. Raise JustWatchError on an error."""
        from .justwatch_queries import PACKAGES
        data = self._get_api_local().execute(PACKAGES, {'country': self.country, 'platform': 'WEB'}) or {}
        return [(pkg['shortName'], pkg.get('clearName') or pkg['shortName']) for pkg in data.get('packages') or () if pkg.get('shortName')]

    def find_title(
        self,
        title: str,
        localtitle: str,
        year: int,
        imdb_id: str = '',
        *,
        content_type: ContentType = 'movie',
    ) -> JWPath | None:
        """
        Return JustWatch full path for the best-matching title, or None.

        Match priority:
          1. IMDB ID (strongest – skips all further checks).
          2. Normalized title + exact year.
          3. Normalized title + year ±1 (fuzzy).
          4. Direct slug-based lookup (fallback for unpopular titles).

        Local-language titles are searched with the local-language API instance
        so JustWatch returns results in the configured language.
        """
        norm_title = cleantitle.normalize(cleantitle.query(title)).lower()
        norm_local = cleantitle.normalize(cleantitle.query(localtitle)).lower()

        search_terms = [title.lower()]
        if localtitle and localtitle.lower() != title.lower():
            search_terms.append(localtitle.lower())

        edges: list[JWSearchEdge] = []
        for term in search_terms:
            try:
                api = self._get_api_local() if term == localtitle.lower() else self._get_api_en()
                resp = api.search_item(term)
                edges.extend(resp['popularTitles']['edges'])
            except Exception:
                continue

        exact: JWPath | None = None
        fuzzy: JWPath | None = None

        for edge in edges:
            try:
                content = edge.get('node', {}).get('content', {})
                if not content:
                    continue
                content_title = cleantitle.normalize(cleantitle.query(content.get('title', ''))).lower()
                release_year = int(content.get('originalReleaseYear', 0))
                cand_imdb = (content.get('externalIds') or {}).get('imdbId', '')
                title_match = content_title in (norm_title, norm_local)

                if imdb_id and cand_imdb and cand_imdb == imdb_id:
                    fflog(f'JW IMDB match: {content.get("fullPath")} imdb={cand_imdb}')
                    return content.get('fullPath')
                if title_match and release_year == year:
                    exact = content.get('fullPath')
                    break
                if title_match and abs(release_year - year) <= 1 and not fuzzy:
                    fuzzy = content.get('fullPath')
            except (KeyError, ValueError, TypeError):
                continue

        return exact or fuzzy or self._find_by_slug(title, localtitle, year, imdb_id, content_type)

    def node_ids(self, items: Iterable[FFRef]) -> dict[MediaRef, JWNodeId]:
        """Return the checked JustWatch nodes of movies / shows: writes to lists use only them."""
        from ..ff.db import media
        from ..ff.info import ffinfo, Progress
        refs: list[MediaRef] = list(dict.fromkeys(it.ref for it in items))
        known = media.ids_of(refs, {JW_ID_SERVICE})
        nodes: dict[MediaRef, JWNodeId] = {ref: links[JW_ID_SERVICE][0] for ref, links in known.items() if (links.get(JW_ID_SERVICE) or [''])[0]}
        missing: list[MediaRef] = [ref for ref in refs if not known.get(ref, {}).get(JW_ID_SERVICE)]  # no node and no "not found" marker
        for ffitem in ffinfo.get_items(missing, progress=Progress.NO) if missing else ():  # titles only
            vtag = ffitem.vtag
            node, checked = self.title_node(ffitem.ref, vtag.getOriginalTitle() or vtag.getTitle(), vtag.getTitle(), vtag.getYear(),
                                            vtag.getIMDBNumber())
            if node and checked:
                nodes[ffitem.ref] = node
            elif node:
                fflog(f'[JW] skipped {ffitem.ref:a} {vtag.getTitle()!r}: its JustWatch node {node} is not checked by IDs')
        return nodes

    def title_node(self, ref: MediaRef, title: str, localtitle: str, year: int, imdb: str = '') -> tuple[JWNodeId | None, bool]:
        """
        Return the JustWatch node of a movie / show and True if it is checked: from the ID map, else found by the
        title and checked by its external IDs (TMDB, else IMDb) - only a checked node is kept (permanently); a node not
        checked is for this request only; no node: asked again after `const.media.ids.missing_ttl`.
        """
        from ..ff.db import media
        if links := media.ids_of([ref], {JW_ID_SERVICE}).get(ref, {}).get(JW_ID_SERVICE):
            return links[0] or None, bool(links[0])
        path = self.find_title(title, localtitle, year, imdb, content_type='show' if ref.type == 'show' else 'movie')
        if (found := self.node_by_path(path) if path else None) is None:
            media.store_ids([(ref, JW_ID_SERVICE, '')], source=JW_ID_SERVICE, ttl=const.media.ids.missing_ttl)
            return None, False
        node, ids = found
        if not self.matches(ref, imdb, ids):
            fflog(f'[JW] {path} ({node}) is not {ref:a} by IDs {ids}')
            return node, False
        self.store_nodes([(ref, node)])
        return node, True

    @staticmethod
    def matches(ref: MediaRef, imdb: str, ids: JWExternalIds) -> bool:
        """Return True if the external IDs of a JustWatch node are of the title: TMDB (if both have), else IMDb."""
        if (tmdb := ids.get('tmdbId')) and ref.tmdb_id:
            return str(tmdb) == str(ref.tmdb_id)
        return bool(imdb and ids.get('imdbId') == imdb)

    def node_by_path(self, path: JWPath) -> tuple[JWNodeId, JWExternalIds] | None:
        """Return the node of a movie / show path and its external IDs (a light query), None if not found."""
        from .justwatch_queries import NODE_BY_PATH
        try:
            data = self._get_api_en().execute(NODE_BY_PATH, {'path': path, 'c': self.country, 'lang': 'en'})
        except Exception as exc:
            fflog(f'[JW] {path}: {exc}')
            return None
        node = ((data or {}).get('url') or {}).get('node') or {}
        if not node.get('id'):
            return None
        return node['id'], (node.get('content') or {}).get('externalIds') or {}

    def episode_node(self, item: FFItem, title: str, localtitle: str, year: int, imdb: str = '', *,
                     season: int, episode: int, absolute: int | None = None) -> JWNodeId | None:
        """
        Return the JustWatch node of an episode: from the ID map, else by the show path (its season / episode, or
        the absolute number if given, e.g. anime). An episode has no external IDs in JustWatch: its node is kept only
        under a checked show, and only as long as the episode node in the media cache (`compute_expires_at()`: an episode
        on air a few hours, an old one a month) - TMDB and JustWatch may number episodes differently.
        """
        from time import time
        from ..ff.db import media
        from ..ff.db.freshness import compute_expires_at
        ref = item.ref
        if links := media.ids_of([ref], {JW_ID_SERVICE}).get(ref, {}).get(JW_ID_SERVICE):
            return links[0] or None
        if not (path := self.find_title(title, localtitle, year, imdb, content_type='show')):
            return None
        show = self.node_by_path(path)
        checked = show is not None and self.matches(ref.main_ref, imdb, show[1])
        if checked and show is not None:
            self.store_nodes([(ref.main_ref, show[0])])
        node = self.find_episode_node_id_by_absolute(path, absolute) if absolute else self.find_episode_node_id(path, season, episode)
        if checked:
            now = int(time())
            media.store_ids([(ref, JW_ID_SERVICE, node or '')], source=JW_ID_SERVICE, ttl=compute_expires_at(item, now) - now, replace=True)
        return node

    @staticmethod
    def store_nodes(nodes: Iterable[tuple[MediaRef, JWNodeId]]) -> None:
        """Keep the JustWatch nodes of movies / shows in the ID map of `media.db` (a node belongs to one title)."""
        from ..ff.db import media
        media.store_ids([(ref, JW_ID_SERVICE, node) for ref, node in nodes], source=JW_ID_SERVICE, replace=True, unique=(JW_ID_SERVICE,))

    def find_episode_node_id(
        self,
        show_path: JWPath,
        season: int,
        episode: int,
    ) -> JWNodeId | None:
        """Return the JustWatch node ID for S{season}E{episode} of the show at *show_path*."""
        try:
            api = self._get_api_en()
            show_resp = api.get_title(show_path)
            seasons: list[JWSeason] = show_resp['url']['node']['seasons']
            season_item = next(
                (s for s in seasons if s.get('content', {}).get('seasonNumber') == season),
                None,
            )
            if not season_item:
                return None
            season_path: JWPath = season_item['content']['fullPath']
            season_resp = api.get_title(season_path)
            episodes: list[JWEpisode] = season_resp['url']['node']['episodes']
            ep = next(
                (e for e in episodes if e.get('content', {}).get('episodeNumber') == episode),
                None,
            )
            return ep['id'] if ep else None
        except (KeyError, TypeError, StopIteration):
            return None

    def find_episode_node_id_by_absolute(
        self,
        show_path: JWPath,
        abs_episode: int,
    ) -> JWNodeId | None:
        """
        Return the JustWatch node ID for the *abs_episode*-th episode overall,
        walking JustWatch's own seasons in order and cumulatively subtracting
        each season's episode count.

        Use this instead of find_episode_node_id() when the caller's season
        numbering isn't guaranteed to match JustWatch's own season split —
        e.g. anime where TMDB groups every cour into one continuous season
        but JustWatch (mirroring Crunchyroll-style cour splits) lists them as
        several separate seasons. abs_episode should be the show's absolute
        episode number (FFItem.absolute_episode_number()), which is already
        cumulative across TMDB's own seasons the same way — so as long as
        both sides agree on the underlying episode order (just grouped into
        seasons differently), this lands on the right episode either way.
        """
        try:
            api = self._get_api_en()
            show_resp = api.get_title(show_path)
            seasons: list[JWSeason] = show_resp['url']['node']['seasons']
            seasons = sorted(
                (s for s in seasons if s.get('content', {}).get('seasonNumber') is not None),
                key=lambda s: s['content']['seasonNumber'],
            )
            remaining = abs_episode
            for season_item in seasons:
                season_path: JWPath = season_item['content']['fullPath']
                season_resp = api.get_title(season_path)
                episodes: list[JWEpisode] = season_resp['url']['node']['episodes']
                if remaining <= len(episodes):
                    ep = next(
                        (e for e in episodes if e.get('content', {}).get('episodeNumber') == remaining),
                        None,
                    )
                    return ep['id'] if ep else None
                remaining -= len(episodes)
            return None
        except (KeyError, TypeError, StopIteration):
            return None

    def get_offers(self, node_id: JWNodeId) -> JWOffers | None:
        """Return streaming offers for *node_id*, or None on failure."""
        try:
            resp = self._get_api_en().get_providers(node_id)
            return resp.get('node')
        except Exception:
            return None

    # def new_titles(self, days: int = 3, *, max_pages: int = 20,
    #                allowed_short_names: Collection[str] | None = None) -> list[JWNewTitle]:
    #     """Movies added to VOD within the last *days* days, deduplicated by JW objectId."""

    # def new_shows(self, days: int = 3, *, max_pages: int = 20,
    #               allowed_short_names: Collection[str] | None = None) -> list[JWNewTitle]:
    #     """TV shows added to VOD within the last *days* days, deduplicated by JW showObjectId."""

    def new_items(self,
                  media_type: MainMediaType | None,
                  days: int = 3,
                  *,
                  max_pages: int = 20,
                  allowed_short_names: Collection[str] | None = None,
                  limit: int | None = None,
                  ids_only: bool = False,
                  ) -> list[JWNewTitle]:
        """
        Movies/TV-shows added to VOD within the last *days* days, deduplicated by JW objectId/showObjectId.
        `ids_only` skips titles with neither IMDb nor TMDB ID.
        """
        if media_type is None:
            # No media means both movies and shows, so fetch them concurrently and merge results by date.
            def get(media: MainMediaType) -> list[JWNewTitle]:
                jw = JustWatchClient(country=self.country, language=self.language)
                return jw.new_items(media, days, max_pages=max_pages, allowed_short_names=allowed_short_names,
                                    limit=limit, ids_only=ids_only)

            from ..ff.requests import RequestsPoolExecutor
            # raise NotImplementedError('media_type=None is not supported yet')  # TODO: make concurrent requests
            with RequestsPoolExecutor() as ex:
                item_lists = ex.map(get, ['movie', 'show'])
                return sorted((it for lst in item_lists for it in lst), key=lambda t: t['date'] or dt_date.max, reverse=True)

        cutoff = dt_date.today() - timedelta(days=days)
        by_id: dict[int, JWNewTitle] = {}
        cursor = ''

        if media_type == 'show':
            object_types = ('SHOW',)
            extid_key = 'showExternalIds'
        else:
            object_types = ('MOVIE',)
            extid_key = 'externalIds'

        for _ in range(max_pages):
            resp = self._get_api_local().new_titles(after=cursor, object_types=object_types)
            buckets = resp.get('newTitleBuckets', {})
            stop = False

            for edge in buckets.get('edges', []):
                key = edge.get('key', {})
                bucket_date = key.get('date') or None
                if bucket_date is not None:
                    bucket_date = dt_date.fromisoformat(bucket_date)
                    if bucket_date < cutoff:
                        stop = True
                        break

                for title_edge in (edge.get('node') or {}).get('edges', []):
                    node = title_edge.get('node', {})
                    if media_type == 'show':
                        if node.get('objectType') != 'SHOW_SEASON':
                            continue
                        show = node.get('show', {})
                        jw_id = show.get('showObjectId', 0)
                        content = show.get('showContent') or {}
                    else:
                        jw_id = node.get('objectId', 0)
                        content = node.get('content') or {}
                    if not jw_id:
                        continue
                    offer_pkg = (title_edge.get('newOffer') or {}).get('package') or {}
                    key_pkg = key.get('package') or {}
                    pkg_short = (offer_pkg or key_pkg).get('shortName', '')
                    pkg_clear = offer_pkg.get('clearName', '') or pkg_short
                    imdb_id = (content.get(extid_key) or {}).get('imdbId') or ''
                    tmdb_id = (content.get(extid_key) or {}).get('tmdbId') or ''
                    # a season of a show only (0 is specials), None if not given
                    season_num = (node.get('seasonContent') or {}).get('seasonNumber') if media_type == 'show' else None

                    if ids_only and not imdb_id and not tmdb_id:
                        continue
                    if allowed_short_names and pkg_short not in allowed_short_names:
                        continue

                    jw_title = by_id.setdefault(jw_id, {
                        'type': media_type,
                        'imdb_id': imdb_id,
                        'tmdb_id': tmdb_id,
                        'services': {},
                        'season': season_num,
                        'date': bucket_date,
                    })
                    jw_title['services'][pkg_short] = pkg_clear
                    if season_num is not None and (jw_title['season'] is None or season_num > jw_title['season']):
                        jw_title['season'] = season_num

                    if limit and sum(1 for t in by_id.values() if t['imdb_id'] or t['tmdb_id']) >= limit:
                        stop = True
                        break

            if stop:
                break
            page_info = buckets.get('pageInfo', {})
            if not page_info.get('hasNextPage'):
                break
            cursor = page_info.get('endCursor', '')
            if not cursor:
                break

        result = list(by_id.values())
        fflog(f'JW {media_type}s: {len(result)} movies, cutoff={cutoff}')
        return result

    def new_ffitems(self,
                    media_type: MainMediaType | None,
                    days: int = 3,
                    *,
                    max_pages: int = 20,
                    allowed_short_names: Collection[str] | None = None,
                    limit: int | None = None,
                    ) -> Iterable[FFItem]:
        """New titles on VOD as FFItems (the date and the services in the role), the whole result in the list cache."""
        from ..defs import MediaRef, VideoIds
        from ..ff.item import FFItem
        from ..ff.listcache import FetchedList, cached_list, list_params, mark_stale

        def ref(it: JWNewTitle) -> MediaRef:
            # TMDB ID of JustWatch first (its IMDb ID is wrong sometimes), IMDb ID if not given
            if (tmdb := it.get('tmdb_id')) and str(tmdb).isdecimal():
                return MediaRef.from_tmdb(it['type'], int(tmdb), it.get('season'))
            return MediaRef(it['type'], VideoIds.make_ffid(imdb=it['imdb_id']), it.get('season'))

        def fetch() -> FetchedList | None:
            data = self.new_items(media_type=media_type, days=days, max_pages=max_pages, allowed_short_names=allowed_short_names,
                                  limit=limit, ids_only=True)
            return FetchedList([(ref(it), {**it, 'date': it['date'] and it['date'].isoformat()}) for it in data], meta={'limit': limit or 0})

        name = f'vod_new/{media_type or "all"}'
        params = list_params(days=days, services=allowed_short_names and ','.join(sorted(allowed_short_names)), country=self.country,
                             lang=self.language)
        stored = cached_list('justwatch', name, fetch, params=params, kind='vod')
        if stored is not None and limit and 0 < stored.row.meta.get('limit', 0) < limit:  # cut by a smaller limit: more is needed
            mark_stale('justwatch', name)
            stored = cached_list('justwatch', name, fetch, params=params, kind='vod')
        if stored is None:
            return
        date_fmt = const.folder.role_date_format
        for it in stored.items:
            ffitem = FFItem(ref=ref(it))
            date = it['date'] and dt_date.fromisoformat(it['date'])
            date_str = f'{date:{date_fmt}}' if date else ''
            ffitem.role = ' | '.join(p for p in (date_str, *it['services'].values()) if p)
            yield ffitem

    # private helpers

    def _find_by_slug(
        self,
        title: str,
        localtitle: str,
        year: int,
        imdb_id: str,
        content_type: ContentType,
    ) -> JWPath | None:
        """
        Fallback: construct a slug from the title and call get_title() directly.
        JustWatch popularTitles only returns popular content; this covers the rest.
        """
        country_code = self.country.lower()
        type_path = 'film' if content_type == 'movie' else 'serial'
        api = self._get_api_en()

        for cand_title in dict.fromkeys(t for t in [localtitle, title] if t):
            try:
                slug = re.sub(
                    r'[^a-z0-9]+',
                    '-',
                    unicodedata.normalize('NFKD', cand_title.lower())
                    .encode('ascii', 'ignore')
                    .decode(),
                ).strip('-')
                if not slug:
                    continue
                path = f'/{country_code}/{type_path}/{slug}'
                resp = api.get_title(path)
                if not (resp and resp.get('url') and resp['url'].get('node')):
                    continue
                node_content: JWContent = resp['url']['node'].get('content') or {}
                cand_imdb = (node_content.get('externalIds') or {}).get('imdbId', '')
                if imdb_id and cand_imdb:
                    if cand_imdb == imdb_id:
                        fflog(f'JW slug fallback (IMDB match): {path} imdb={cand_imdb}')
                        return path
                else:
                    rel_year = int(node_content.get('originalReleaseYear', 0))
                    if abs(rel_year - year) <= 1:
                        fflog(f'JW slug fallback (year): {path} year={rel_year}')
                        return path
            except Exception:
                continue

        return None
class JustWatchAccount(AccountClient):
    """
    JustWatch client of an account: the watchlist, the liked titles (the favorites) and the own lists of the user, read
    and write; the seen titles (the history) and the next episodes of the tracked shows read only.

    Sign-in by e-mail and password (Firebase Authentication of the JustWatch site; the password is not kept): the refresh
    token, the ID token (1 h, kept with its lifetime) and the device ID are in the account data (`accounts.db`). Lists are
    in the list cache whole (read in parts of `LIST_LIMIT`), pages are cut here; JustWatch has no activities, the sync
    (`lib.ff.sync`) compares fingerprints of the lists (`sync_activities()`), the next episodes live their TTL.
    """

    #: Sections of lists of the account: the watchlist, the liked titles and own lists (movies and shows).
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'watchlist': ListSection(types=ListType.MAIN),
        'favorites': ListSection(types=ListType.MAIN),
        'user': ListSection(types=ListType.MAIN, create={}),
    }
    #: Firebase REST: sign-in by e-mail and password.
    SIGN_IN_URL: ClassVar[str] = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword'
    #: Firebase REST: a new ID token by the refresh token.
    REFRESH_URL: ClassVar[str] = 'https://securetoken.googleapis.com/v1/token'
    #: The site page with the Firebase web key (the key repair).
    SITE_URL: ClassVar[str] = 'https://www.justwatch.com/{country}'
    #: The Firebase web key in the HTML of the site.
    KEY_RX: ClassVar[re.Pattern[str]] = re.compile(r'FIREBASE_API_KEY:"(AIza[\w-]+)"')
    #: Firebase errors of a wrong sign-in.
    BAD_LOGIN: ClassVar[frozenset[str]] = frozenset({'INVALID_LOGIN_CREDENTIALS', 'INVALID_PASSWORD', 'EMAIL_NOT_FOUND', 'INVALID_EMAIL'})
    #: GraphQL error codes of a missing / expired authorization (a new ID token and one more try).
    AUTH_ERRORS: ClassVar[frozenset[str]] = frozenset({'AUTHORIZATION_REQUIRED', 'UNAUTHENTICATED'})
    #: Items of a list in one request (the service takes up to 1000, a longer list is read in parts).
    LIST_LIMIT: ClassVar[int] = 1000
    #: Sync buckets (`lib.ff.sync`): fingerprints of the lists, see `sync_activities()`.
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = dict.fromkeys(('lists.watchlist', 'lists.favorites', 'lists.user', 'lists.seen'))
    #: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = {'lists.watchlist': 'watchlist', 'lists.favorites': 'favorites', 'lists.user': 'user',
                                                      'lists.seen': 'history'}
    #: Interval of the sync in the service (fingerprints cost more than activities).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.fingerprint_interval

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        super().__init__(account, alias=alias)
        #: The anonymous client: search of titles (JustWatch nodes for writes), the country from the settings.
        self.app: JustWatchClient = JustWatchClient(country='', language='en')

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists and of the account data: the account ID."""
        return JW_ID_SERVICE if (account := self.account) is None else account.id

    @property
    def _store(self) -> KeyValueStore:
        """Return the data of the account (`accounts.db`)."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.scope)

    def credentials(self) -> str:
        """Return the credentials of the account (the refresh token, '' - none), see `AccountStore.auth_state()`."""
        return '' if self.account is None else str(self._store.get('refresh_token') or '')

    # --- Firebase ---

    @staticmethod
    def _type_store() -> KeyValueStore:
        """Return the data of the type (not of an account): the repaired Firebase web key."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(JW_ID_SERVICE)

    def _web_key(self) -> str:
        """Return the Firebase web key: a repaired one (the site changed it), else the one of `apis`."""
        from ..ff import apis
        return str(self._type_store().get('firebase_key') or apis.justwatch_firebase)  # type: ignore[attr-defined]  # decoded at import

    def _repair_key(self) -> bool:
        """Read the Firebase web key from the site HTML and keep it, return True if it is another one."""
        from ..ff import requests
        try:
            resp = requests.get(self.SITE_URL.format(country=self.app.country.lower()), headers={'User-Agent': 'Mozilla/5.0'},
                                timeout=const.justwatch.connection.timeout)
        except Exception as exc:
            fflog(f'[JW] the site page failed: {exc}')
            return False
        if not (mch := self.KEY_RX.search(resp.text)) or mch[1] == self._web_key():
            fflog('[JW] no other Firebase key on the site')
            return False
        self._type_store().set('firebase_key', mch[1], ttl=None)
        fflog('[JW] the Firebase key of the site is used')
        return True

    def _firebase(self, url: str, *, json: JsonData | None = None, data: dict[str, str] | None = None) -> JsonData:
        """POST to Firebase REST with the web key (repaired once if it is not valid), return the response JSON (`error` on failure)."""
        from ..ff import requests
        for _ in range(2):
            try:
                resp = requests.post(url, json=json, data=data, params={'key': self._web_key()}, timeout=const.justwatch.connection.timeout)
                result = resp.json()
            except Exception as exc:
                return {'error': {'message': str(exc)}}
            message = str((result.get('error') or {}).get('message') or '') if isinstance(result, dict) else 'no JSON object'
            if 'API key not valid' in message and self._repair_key():
                continue
            return result if isinstance(result, dict) else {'error': {'message': message}}
        return {'error': {'message': 'API key not valid'}}

    def _keep_tokens(self, *, id_token: str, refresh_token: str, expires_in: Any) -> None:
        """Keep the tokens of the account (the ID token a minute shorter than it lives)."""
        store = self._store
        store.set('refresh_token', refresh_token, ttl=None)
        store.set('id_token', id_token, ttl=max(60, int(expires_in or 3600) - 60))

    def _id_token(self) -> str:
        """Return a valid ID token of the account ('' - not signed in or the refresh failed)."""
        if not (refresh := self.credentials()):
            return ''
        if token := self._store.get('id_token'):
            return str(token)
        result = self._firebase(self.REFRESH_URL, data={'grant_type': 'refresh_token', 'refresh_token': refresh})
        if error := result.get('error'):
            fflog(f'[JW] {self.scope}: the token refresh failed: {error.get("message")}')
            if str(error.get('message')).partition(' ')[0] in ('TOKEN_EXPIRED', 'USER_DISABLED', 'USER_NOT_FOUND', 'INVALID_REFRESH_TOKEN'):
                self._store.delete('refresh_token')  # the account needs a sign-in again
            return ''
        self._keep_tokens(id_token=result['id_token'], refresh_token=result['refresh_token'], expires_in=result.get('expires_in'))
        return str(result['id_token'])

    def auth(self, *, force: bool = False) -> bool | None:
        """
        Sign in the account by e-mail and password (asked): True on success, False on failure, None if canceled by the user.
        Another user drops the cached lists.
        """
        from ..ff.ui import ui
        from ..ff.listcache import remove_scope
        if self.account is None:
            return False
        if not force and self.credentials():
            return True
        store = self._store
        profile = store.get('profile') or {}
        if not (email := ui.input(L(32937, 'E-mail'), str(profile.get('email') or ''))):
            return None
        store.set('profile', {**profile, 'email': email.strip()}, ttl=None)  # offered again after a failed sign-in
        if not (password := ui.input(L(32648, 'Password'), hidden=True)):
            return None
        result = self._firebase(self.SIGN_IN_URL, json={'email': email.strip(), 'password': password, 'returnSecureToken': True})
        if error := result.get('error'):
            message = str(error.get('message') or '')
            fflog(f'[JW] {self.scope}: the sign-in failed: {message}')
            ui.notify(self.account.label, L(32938, 'Incorrect e-mail or password') if message.partition(' ')[0] in self.BAD_LOGIN else message, error=True)
            return False
        if profile.get('id') and profile['id'] != result.get('localId'):
            remove_scope(self.scope)
        self._keep_tokens(id_token=result['idToken'], refresh_token=result['refreshToken'], expires_in=result.get('expiresIn'))
        store.set('profile', {'id': result.get('localId'), 'username': result.get('displayName') or result.get('email') or email,
                              'email': result.get('email') or email}, ttl=None)
        self.refresh_profile()
        return True

    def unauth(self) -> bool:
        """Forget the authorization of the account (Firebase REST has no revoke of a refresh token)."""
        if self.account is None:
            return False
        store = self._store
        for key in ('refresh_token', 'id_token', 'profile'):
            store.delete(key)
        return True

    def refresh_profile(self) -> JsonData | None:
        """Get the limits of own lists of the account and keep them in its profile, None on failure."""
        from .justwatch_queries import USER_STATS
        if self.account is None or not self.credentials():
            return None
        try:
            stats = self._gql(USER_STATS, {}).get('stats') or {}
        except JustWatchError:
            return None
        profile = {**(self._store.get('profile') or {}), 'pro': bool(stats.get('hasJWProSubscription')),
                   'max_lists': stats.get('maxCustomListsPro' if stats.get('hasJWProSubscription') else 'maxCustomListsDefault')}
        self._store.set('profile', profile, ttl=None)
        return profile

    # --- GraphQL ---

    def _device_id(self) -> str:
        """Return the device ID of the account (a new one from the service on the first use)."""
        from .justwatch_queries import NEW_DEVICE_ID
        if device := self._store.get('device_id'):
            return str(device)
        data = JustWatchGraphQL(country=self.app.country).execute(NEW_DEVICE_ID, {'i': {'doNotTrack': True, 'ids': []}})
        device = str(((data or {}).get('getNewDeviceId') or {}).get('deviceId') or '')
        if device:
            self._store.set('device_id', device, ttl=None)
        return device

    def _gql(self, query: str, variables: dict[str, Any]) -> JsonData:
        """Run a GraphQL query of the user (a new ID token and one more try on an authorization error)."""
        api = JustWatchGraphQL(country=self.app.country)
        variables = {'c': self.app.country, 'lang': 'en', **variables} if '$c:' in query else variables
        for retry in (True, False):
            if not (token := self._id_token()):
                raise JustWatchError(f'{self.scope}: not signed in', codes=('AUTHORIZATION_REQUIRED',))
            try:
                return api.execute(query, variables, headers={'Authorization': f'Bearer {token}', 'Device-Id': self._device_id()}) or {}
            except JustWatchError as exc:
                if not retry or not exc.codes & self.AUTH_ERRORS:
                    raise
                self._store.delete('id_token')
        return {}

    # --- Lists ---

    @staticmethod
    def _title_ref(node: JsonData, media: MainMediaType | None = None) -> MediaRef | None:
        """Return the reference of a title node (TMDB, else IMDb mapped later), None if unknown or not of the `media`."""
        from ..defs import MediaRef, VideoIds
        if not (typ := JW_MEDIA_TYPES.get(node.get('objectType') or '')) or (media and media != typ):
            return None
        ids = (node.get('content') or {}).get('externalIds') or {}
        if tmdb := ids.get('tmdbId'):
            return MediaRef.from_tmdb(typ, int(tmdb))
        if imdb := ids.get('imdbId'):
            return MediaRef(typ, VideoIds.make_ffid(imdb=imdb))
        return None

    def _fetch_titles(self, query: str, variables: dict[str, Any], key: str) -> FetchedList | None:
        """Fetch a whole list of titles (in parts of `LIST_LIMIT`); its TMDB titles fill the map of JustWatch nodes."""
        from ..ff.listcache import FetchedList
        nodes: list[JsonData] = []
        after: str | None = None
        while True:
            container = self._gql(query, {**variables, 'first': self.LIST_LIMIT, 'after': after}).get(key)
            if not isinstance(container, dict):
                return None  # an error is not an empty (or a cut) list
            nodes.extend(node for edge in container.get('edges') or () if (node := edge.get('node')))
            info = container.get('pageInfo') or {}
            if not info.get('hasNextPage') or not (after := info.get('endCursor')):
                break
        items = [(self._title_ref(node), node) for node in nodes]
        self.app.store_nodes((ref, node['id']) for ref, node in items if ref is not None and ref.tmdb_id)
        return FetchedList(items, total=container.get('totalCount'))

    def _titles(self, name: str, query: str, variables: dict[str, Any], key: str, *, media: MainMediaType | None = None,
                page: int | None = None, make: Callable[[MediaRef, JsonData], T | None] | None = None, bucket: str = '') -> ItemList[T]:
        """
        Return the page of the list `name` (all items without `page`) from the list cache, only the `media` if given;
        an item is the title with its data in the list (`list_entry`), or `make(ref, node)` (None skips the title).
        `bucket` - the sync bucket watching the list ('' - none).
        """
        from ..ff.listcache import cached_list
        from ..defs import ItemList
        if make is None:
            make = self._list_item
        stored = cached_list(self.scope, name, lambda: self._fetch_titles(query, variables, key), bucket=bucket)
        # ponytail: an item is made for every title of the list, then the page is cut (`make` may skip titles); cut first if big lists cost
        items = [] if stored is None else [it for node in stored.items if (ref := self._title_ref(node, media)) if (it := make(ref, node)) is not None]
        if not page:
            return ItemList.single(items)
        size = const.indexer.justwatch.page_size
        return ItemList(items[(page - 1) * size:page * size], page=page, page_size=size, total_pages=(len(items) + size - 1) // size,
                        total_results=len(items))

    @staticmethod
    def _list_item(ref: MediaRef, node: JsonData, list_id: str = '') -> FFItem:
        """
        Return the title of a list with its data in the list (`list_entry`): the added date of the watchlist, the liked
        titles or the own list `list_id`.
        """
        from ..ff.item import FFItem, ListEntry
        entries = (node.get('watchlistEntryV2'), node.get('likelistEntry'),
                   *(entry for entry in node.get('customlistEntries') or () if (entry.get('genericTitleList') or {}).get('id') == list_id))
        it = FFItem(ref)
        it.list_entry = ListEntry.new(added_at=next((entry.get('createdAt') for entry in entries if entry), None))
        return it

    def watchlist(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist of the account (movies and shows, newest first)."""
        from .justwatch_queries import WATCHLIST
        return self._titles('watchlist', WATCHLIST, {}, 'titleListV2', media=media, page=page, bucket='lists.watchlist')

    def favorites(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the liked titles of the account (movies and shows, newest first)."""
        from .justwatch_queries import LIKELIST
        return self._titles('favorites', LIKELIST, {}, 'titleListV2', media=media, page=page, bucket='lists.favorites')

    def history(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """
        Return the seen titles of the account, the latest marked first: movies with the date they were marked
        (`const.indexer.history.role`), shows with all episodes seen (no date).
        """
        from datetime import datetime
        from ..ff.calendar import utc_timestamp
        from ..ff.item import FFItem
        from ..ff.progress import played_role
        from .justwatch_queries import SEENLIST

        def make(ref: MediaRef, node: JsonData) -> FFItem:
            it = FFItem(ref)
            if created := (node.get('seenlistEntry') or {}).get('createdAt'):
                it.role = played_role(datetime.fromtimestamp(utc_timestamp(created)))  # local, as in the history of the synced rows
            return it

        return self._titles('history', SEENLIST, {}, 'titleListV2', media=media, page=page, make=make, bucket='lists.seen')

    def upnext(self, *, page: int | None = None) -> ItemList[MediaRef]:
        """
        Return the next released episodes of the tracked shows in progress (`TRACKING`), the latest tracked first;
        JustWatch counts them from its seen episodes, not from the watched state of FanFilm.
        """
        from ..defs import MediaRef
        from .justwatch_queries import TRACKING

        def make(ref: MediaRef, node: JsonData) -> MediaRef | None:
            ep = ((node.get('watchNextEpisode') or {}).get('content')) or {}
            if ep.get('seasonNumber') is None or ep.get('episodeNumber') is None:
                return None
            return MediaRef('show', ref.ffid, season=ep['seasonNumber'], episode=ep['episodeNumber'])

        return self._titles('upnext', TRACKING, {}, 'tvShowTracking', media='show', page=page, make=make)

    def list_items(self, list_id: str, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the titles of an own list of the account."""
        from .justwatch_queries import CUSTOM_LIST
        return self._titles(f'user/{list_id}', CUSTOM_LIST, {'l': list_id}, 'genericTitleList', media=media, page=page,
                            make=lambda ref, node: self._list_item(ref, node, list_id), bucket='lists.user')

    def user_lists(self) -> list[FFItem]:
        """Return the own lists of the account (folders with `list_id`, read by `ListTarget.from_ffitem()`)."""
        from ..ff.listcache import FetchedList, cached_list
        from ..ff.item import FFItem
        from .justwatch_queries import CUSTOM_LISTS

        def fetch() -> FetchedList | None:
            container = self._gql(CUSTOM_LISTS, {'first': self.LIST_LIMIT}).get('genericTitleLists')
            if not isinstance(container, dict):
                return None
            return FetchedList([(None, node) for edge in container.get('edges') or () if (node := edge.get('node'))])

        def make_item(node: JsonData) -> FFItem:
            name = (node.get('content') or {}).get('name') or node['id']
            ffitem = FFItem(name, mode=FFItem.Mode.Folder)
            ffitem.title = name
            ffitem.setProperty('list_id', node['id'])
            if (total := (node.get('titles') or {}).get('totalCount')) is not None:
                ffitem._children_count = total
                ffitem.role = L(30331, '{n} title|||{n} titles', n=total)
            return ffitem

        stored = cached_list(self.scope, 'user', fetch, bucket='lists.user')
        return [] if stored is None else [make_item(node) for node in stored.items if node.get('id')]

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """
        Return cursors of the sync buckets (`lib.ff.sync`), None on failure. JustWatch has no activities: fingerprints - the
        count and the newest title (with its added date) of the watchlist, the liked and the seen titles (a seen show has no
        date: the count), the count and the newest title of each own list (one request).
        """
        from .justwatch_queries import SYNC

        def newest(container: JsonData, entry: str, list_id: str = '') -> str:
            """Return the count, the newest title and its added date of the list."""
            node = next(((edge.get('node') or {}) for edge in container.get('edges') or ()), {})
            entries = node.get(entry) or {}
            if isinstance(entries, list):  # the entries of the title in the own lists
                entries = next((it for it in entries if (it.get('genericTitleList') or {}).get('id') == list_id), {})
            return f'{container.get("totalCount") or 0}:{node.get("id") or ""}:{entries.get("createdAt") or ""}'

        data = self._gql(SYNC, {})
        lists = data.get('lists')
        if not all(isinstance(data.get(key), dict) for key in ('watchlist', 'liked', 'seen', 'lists')) or not isinstance(lists, dict):
            return None  # an error is not "no change"
        nodes = [node for edge in lists.get('edges') or () if (node := edge.get('node'))]
        return {
            'lists.watchlist': newest(data['watchlist'], 'watchlistEntryV2'),
            'lists.favorites': newest(data['liked'], 'likelistEntry'),
            'lists.seen': newest(data['seen'], 'seenlistEntry'),
            'lists.user': '|'.join([str(lists.get('totalCount') or 0),
                                    *(f'{node["id"]}={newest(node.get("titles") or {}, "customlistEntries", node["id"])}'
                                      for node in nodes if node.get('id'))]),
        }

    def _set(self, query: str, inputs: Iterable[dict[str, Any]], *, stale: Iterable[str]) -> int:
        """Run a mutation for every input (a title), mark the lists `stale`, return the number of done ones."""
        from ..ff.listcache import mark_stale
        count = 0
        for i in inputs:
            try:
                self._gql(query, {'i': i})
                count += 1
            except JustWatchError as exc:
                fflog(f'[JW] {self.scope}: {exc}')
        for name in stale:
            mark_stale(self.scope, name)
        return count

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the watchlist or remove them, return the number of done ones."""
        from .justwatch_queries import SET_IN_WATCHLIST
        nodes = self.app.node_ids(items)
        return self._set(SET_IN_WATCHLIST, ({'id': node, 'state': state} for node in nodes.values()), stale=('watchlist',))

    def set_favorites(self, items: Iterable[FFRef], state: bool) -> int:
        """Like (`state`) items or no more, return the number of done ones."""
        from .justwatch_queries import SET_IN_LIKELIST
        nodes = self.app.node_ids(items)
        return self._set(SET_IN_LIKELIST, ({'id': node, 'state': state} for node in nodes.values()), stale=('favorites',))

    def set_in_list(self, list_id: str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to an own list or remove them, return the number of done ones."""
        from .justwatch_queries import SET_IN_CUSTOM_LIST
        nodes = self.app.node_ids(items)
        return self._set(SET_IN_CUSTOM_LIST, ({'id': node, 'state': state, 'listId': list_id} for node in nodes.values()),
                         stale=(f'user/{list_id}', 'user'))

    def create_list(self, name: str, *, public: bool = False) -> str | None:
        """Create an own list (the service has only unlisted ones: `public` is ignored), return its ID; over the limit of lists: a message, None."""
        from ..ff.listcache import mark_stale
        from .justwatch_queries import CREATE_CUSTOM_LIST
        limit = (self._store.get('profile') or {}).get('max_lists') or 0
        if limit and len(self.user_lists()) >= limit:
            from ..ff.ui import ui
            ui.notify(self.account.label if self.account else 'JustWatch', L(32939, 'JustWatch: the limit of own lists ({n}) is reached').format(n=limit), error=True)
            return None
        try:
            data = self._gql(CREATE_CUSTOM_LIST, {'i': {'name': name, 'visibility': 'UNLISTED'}})
        except JustWatchError as exc:
            fflog(f'[JW] {self.scope}: {exc}')
            return None
        mark_stale(self.scope, 'user')
        return ((data.get('createCustomlist') or {}).get('titleList') or {}).get('id')

    def delete_list(self, list_id: str) -> bool:
        """Delete an own list (with its titles)."""
        from .justwatch_queries import DELETE_CUSTOM_LIST
        return bool(self._set(DELETE_CUSTOM_LIST, [{'id': list_id}], stale=(f'user/{list_id}', 'user')))

    def rename_list(self, list_id: str, name: str) -> str | None:
        """Rename an own list, return its ID (the same), None on failure."""
        from .justwatch_queries import UPDATE_CUSTOM_LIST
        return list_id if self._set(UPDATE_CUSTOM_LIST, [{'id': list_id, 'name': name}], stale=('user',)) else None


#: The application client (anonymous): the general lists (new VOD) of the type JustWatch, the country from the settings.
justwatch_app: JustWatchClient = JustWatchClient(country='', language='en')
#: Client of the type alias (the first JustWatch account).
justwatch: JustWatchAccount = JustWatchAccount(alias=JW_ID_SERVICE)


def make_client(account: Account | None) -> JustWatchAccount:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return justwatch if account is None else JustWatchAccount(account)

