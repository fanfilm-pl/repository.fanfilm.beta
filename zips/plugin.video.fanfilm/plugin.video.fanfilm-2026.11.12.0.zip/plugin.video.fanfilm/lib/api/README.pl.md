# Serwisy (typy kont)

Deklaracje: `SERVICE_TYPES` w `lib/ff/accounts.py` (kolejność typów = kolejność kont, menu list, serwisów ocen, grup
Add-to), klienci: `lib/api/<typ>.py` (konto FanFilm: `lib/ff/ownlists.py`). Sekcje list Add-to deklaruje klient
(`AccountClient.LISTS`), `LIST_POINTERS` w `lib/ff/lists.py` to już tylko usługi bez kont (biblioteka, logi).
Zdolności: postęp (punkt wznowienia), obejrzane, oceny, listy; R — odczyt, W — zapis.

| Typ       | Konta | Postęp | Obejrzane | Oceny       | Listy (sekcje)                                  | Publiczne    | Listy ogólne                                   |
|-----------|-------|--------|-----------|-------------|-------------------------------------------------|--------------|------------------------------------------------|
| tmdb      | wiele | —      | —         | RW (0,5)    | ulubione, watchlista, własne                    | —            | — (discover w menu filmów / seriali)           |
| wetrakr   | wiele | RW     | RW        | RW (1)²     | watchlista (`planning`), ulubione³, własne³     | listy, oceny | filmy / seriale (discover, rankingi), listy    |
| mdblist   | wiele | RW¹    | RW¹       | RW          | watchlista, kolekcja, własne (nowe statyczne)   | —            | popularne listy, szukanie list                 |
| floppy    | wiele | RW     | RW        | RW (1)²     | watchlista (`Planning`), kolekcja, własne⁴      | —            | —                                              |
| justwatch | wiele | —      | —         | —           | watchlista, ulubione, własne (2 na darmowym)⁵   | —            | nowe w VOD                                     |
| imdb      | wiele | —      | —         | RW          | watchlista, własne (tytuły / osoby)             | listy        | —                                              |
| trakt     | wiele | RW     | RW        | RW          | ulubione, watchlista, kolekcja, własne          | —            | trendujące / popularne listy                   |
| own       | jedno | —      | —         | —           | ulubione, watchlista, własne (lokalne)          | —            | —                                              |
| kodi      | jedno | R      | RW        | —           | — (baza wideo Kodi, lokalnie)                   | —            | —                                              |

¹ domyślnie wyłączone przełącznikami konta (logowanie do list / ocen nie włącza scrobble).
² serwis ma skalę 0–10 z jednym miejscem po przecinku, FF zapisuje całe punkty.
³ także osoby.
⁴ serwer musi oferować zakresy list w logowaniu urządzenia (Floppy v26.10.29+), bez nich konto nie ma list własnych.
⁵ obejrzane tytuły (historia) i kolejne odcinki śledzonych seriali — tylko odczyt list, bez zdolności „obejrzane”.

- Logowanie: Trakt, WeTrakr, MDBList, Floppy — kod urządzenia (Floppy: adres serwera podany przy logowaniu, konto
  na dowolnym serwerze); TMDB — zatwierdzenie w przeglądarce; IMDb — ciasteczko `at-main` (wklejone / ze skryptu
  przeglądarki) albo użytkownik publiczny; JustWatch — e-mail + hasło.
- Wykrywanie zmian (`lib/ff/sync.py`): aktywności serwisu (`const.accounts.sync.interval`) — Trakt, MDBList, WeTrakr;
  odciski list (liczba i najnowsza pozycja, rzadziej: `const.accounts.sync.fingerprint_interval`) — TMDB, IMDb,
  JustWatch, Floppy.
- Bramki: `const.accounts.<typ>.enabled` — konta typu (wyłączone są ukryte, dane zostają);
  `const.indexer.<typ>.enabled` — tylko listy ogólne. Gdzie lista ogólna się pokazuje (menu, usługa, lista, miejsce)
  — ustawienia użytkownika `config.json` `/lists` (`lib/ff/lists_config.py`), okno konfiguracji (`tools/config?tab=`),
  karty „Konta”, „Listy ogólne”, „Dostawcy treści”.
- Menu seriali: „Shows in progress” (`/tvshow/progress`) — postęp scalony ze wszystkich kont z odczytem obejrzanych /
  postępu i lokalnego Kodi; postęp konta — w menu konta. „People Watching” — dostawca wybrany przez użytkownika
  (`lists_config.FEEDS`: Trakt — domyślnie, WeTrakr, TMDB), a gdy niedostępny (WeTrakr wymaga konta) — TMDB.
- Listy ogólne idą przez klienta aplikacyjnego (`ServiceType.general`; bez konta albo token pierwszego konta:
  MDBList, WeTrakr). WeTrakr: klucz produkcyjny aplikacji, limit dzienny `max(2000, 300 · użytkownicy)`, 300 zapytań
  na konto.
