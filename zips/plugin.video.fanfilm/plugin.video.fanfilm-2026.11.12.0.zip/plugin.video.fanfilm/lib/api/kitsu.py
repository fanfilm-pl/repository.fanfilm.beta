# -*- coding: utf-8 -*-
"""
FanFilm ‑ moduł: kitsu
Mapowanie TMDB ID → cour structure + Kitsu API.

Mapowanie ID anime (TMDB → Kitsu/MAL/AniList) pobierane jest z serwera ARM,
a gdy ten jest niedostępny — ze statycznych list Fribb (anime-lists) jako
fallback. Po powrocie ARM jest znów używany (przy następnej sesji).

Copyright (C) 2025 :)
Dystrybuowane na licencji MIT <https://mit-license.org>
many thx for idea and code to skoruppa: https://github.com/skoruppa/
"""

from __future__ import annotations
from datetime import date, datetime
import re
from typing import NamedTuple, TypedDict, TYPE_CHECKING
from attrs import frozen
from ..ff import requests
from ..ff.requests import RequestsPoolExecutor
from ..ff.db.sources import ProviderStore, provider_store
from ..defs import MediaRef
from ..ff.logs import fflog, fflog_exc
from ..ff.source_utils import DEFAULT_UA, roman_to_int
from const import const
if TYPE_CHECKING:
    from typing import Callable, Sequence, Collection, Literal
    from typing_extensions import TypeAlias
    from ..ff.types import JsonData
    from ..ff.item import FFItem


# ---------------------------------------------------------------------------
# Typy publiczne
# ---------------------------------------------------------------------------

@frozen(kw_only=True)
class AnimeIds:
    """Set of ID for single entry for TMDB ID: (kitsu_id, mal_id, anilist_id)."""
    kitsu: int
    myanimelist: int | None = None
    anilist: int | None = None

    # name alias
    @property
    def mal(self) -> int | None:
        return self.myanimelist


#: TMDB media type (TMDB IDs of movies and shows are separate spaces).
TmdbMediaType: TypeAlias = "Literal['tv', 'movie']"


# Jeden cour (sezon Kitsu) — element listy zwracanej przez get_cour_structure.
class CourInfo(TypedDict):
    """Single cour (Kitsu season) info."""
    kitsu_id:   int
    mal_id:     int | None   # MyAnimeList ID (do docchi)
    anilist_id: int | None   # AniList ID (do animerealms)
    title:      str             # en_jp — do wyszukiwania na animezone/shinden
    ep_count:   int             # liczba odcinków w tym cour, 0 jeśli film
    start_date: date | None
    end_date:   date | None
    subtype:    str             # 'TV' / 'OVA' / 'movie' / ...


@frozen(kw_only=True)
class AnimeInfo:
    """Anime set of data to allow matching with anime on animezone/shinden for all providers."""
    cours: Sequence[CourInfo] | None = None

    @property
    def movie(self) -> CourInfo | None:
        """Returns CourInfo for movie (subtype=movie) if present, else None. Assumes movie is the first cour in the list obtained by get_movie_info()."""
        return self.cours[0] if self.cours else None

    def __to_json__(self) -> JsonData:
        """Dump to JSON data (dates as ISO strings)."""
        if self.cours is None:
            return {'cours': None}
        return {'cours': [{**cour, **{key: cour[key] and cour[key].isoformat() for key in _COUR_DATE_KEYS}} for cour in self.cours]}

    @classmethod
    def __from_json__(cls, data: JsonData) -> AnimeInfo:
        """Load from JSON data (see __to_json__)."""
        cours = data.get('cours')
        if cours is None:
            return cls()
        return cls(cours=[CourInfo(**{**cour, **{key: cour.get(key) and date.fromisoformat(cour[key]) for key in _COUR_DATE_KEYS}})
                          for cour in cours])


#: CourInfo date keys (JSON needs conversion).
_COUR_DATE_KEYS: tuple[str, ...] = ('start_date', 'end_date')


# ---------------------------------------------------------------------------
# Stałe i cache
# ---------------------------------------------------------------------------

# Maps macron vowels (Hepburn romanization) → double vowels
_MACRON_MAP = str.maketrans('āīūēō', 'aiueo')

ARM_URL   = "https://arm.haglund.dev/api/v2/themoviedb?id={tmdb}&include=kitsu,myanimelist,anilist"
FRIBB_URL = "https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-mini.json"
KITSU_URL = "https://kitsu.io/api/edge/anime/{kitsu}"

#: HTTP headers — browser User-Agent (some servers reject other ones).
_HEADERS: dict[str, str] = {'User-Agent': DEFAULT_UA}
#: Persistent cache key of the Fribb index (v2: movie TMDB IDs are lists in Fribb, v1 index has broken keys).
_FRIBB_CACHE_KEY: str = 'kitsu_fribb_index.v2'

#: Persistent store (sources.db): the Fribb index, the anime IDs of TMDB IDs (`ids.<type>:<tmdb>`) and the Kitsu data
#: of anime (`meta.<kitsu_id>`), lifetimes in `const.sources.kitsu`.
_store: ProviderStore = provider_store('ff/kitsu')

#: Fribb index: 'media_type:tmdb_id' → [[kitsu_id, mal_id, anilist_id], ...].
_fribb_index: dict[str, list[list[int | None]]] | None = None
#: ARM failed in this session → skip it, use the fallback.
_arm_down:    bool = False


# ---------------------------------------------------------------------------
# API publiczne
# ---------------------------------------------------------------------------

_RE_SEASON_SUFFIX = re.compile(
    r'\s+(?:(\d+)(?:st|nd|rd|th)\s+Season|Season\s+(\d+))$', re.IGNORECASE
)


def strip_season_suffix(title: str) -> tuple[str, int | None]:
    """Zwraca (base_title, season_number) po odcięciu angielskiego sufiksu sezonu.

    Przykłady: "Frieren 2nd Season" → ("Frieren", 2)
               "Attack on Titan Season 4" → ("Attack on Titan", 4)
               "Frieren" → ("Frieren", None)
    """
    if mch := _RE_SEASON_SUFFIX.search(title):
        num = int(mch.group(1) or mch.group(2))
        return title[:mch.start()].strip(), num
    return title, None


def normalize_romaji(text: str) -> str:
    """Normalizuje tytuł romaji — macron vowels → double vowels, lowercase, strip interpunkcji."""
    # ā→aa, ī→ii, ū→uu, ē→ee, ō→oo
    result = []
    for ch in text.lower():
        base = ch.translate(_MACRON_MAP)
        if base != ch:
            result.append(base * 2)  # ū → uu
        else:
            result.append(ch)
    text = ''.join(result)
    text = re.sub(r'[^\w\s]', ' ', text)
    # Normalizuj warianty numeracji sezonów: "2nd season" → "season 2", "3rd season" → "season 3"
    text = re.sub(r'(\d+)(?:st|nd|rd|th)\s+season', r'season \1', text)
    return re.sub(r'\s+', ' ', text).strip()


def normalize_series_title(text: str) -> str:
    """normalize_romaji + końcowy numer sezonu → "season N" (do porównań tytułów serii).

    Kitsu: "... Odekakechuu 2nd Season", animezone/shinden: "... Odekakechuu II" → oba "... season 2".
    Strony: "Slime Datta Ken 3" → "... season 3", "JoJo ... Part 3: Stardust Crusaders" → "jojo ... stardust crusaders".
    """
    text = re.sub(r' part \d+ (?=\w)', ' ', normalize_romaji(text))
    return re.sub(r'(?<! part)(?: season)? (ii|iii|iv|vi{0,3}|ix|x|[2-9])$',
                  lambda m: f' season {m.group(1) if m.group(1).isdigit() else roman_to_int(m.group(1))}', text)


def series_season(norm_title: str) -> int | None:
    """Numer sezonu z tytułu po normalize_series_title ("... season 3" → 3), None gdy brak."""
    match = re.search(r' season (\d+)', norm_title)
    return int(match.group(1)) if match else None


def get_cour_structure(tmdb_id: int | None,
                       *,
                       media_type: TmdbMediaType = 'tv',
                       match: Collection[str] = (),
                       skip: Collection[str] = ('movie', 'special'),
                       ) -> list[CourInfo] | None:
    """
    Zwraca listę WSZYSTKICH courów dla danego serialu (wszystkie sezony TMDB łącznie),
    posortowanych chronologicznie. Filmy i speciale (subtype=movie/special) są pomijane.

    Zwraca None jeśli ARM/Fribb/Kitsu niedostępne lub brak danych.

    UWAGA: scraper używa abs_ep względnego do sezonu TMDB
    (ffitem.absolute_episode_number() liczy od 1 per season),
    więc musi przekazać tylko cours należące do danego sezonu.
    Nie potrafimy tego rozróżnić bez TMDB API — scraperowi zwracamy
    WSZYSTKIE cours i pozwalamy mu działać metodą cumulative fallback
    (patrz map_episode_in_season).
    """
    if not tmdb_id:
        return None
    tmdb_id = int(tmdb_id)

    entries = _get_kitsu_ids(tmdb_id, media_type)
    if not entries:
        return None

    cours: list[CourInfo] = []
    for cour in _get_kitsu_cours(entries):
        if cour is None:
            continue
        subtype = cour['subtype'].lower()
        if subtype in skip:
            fflog(f'kitsu: pominięto kitsu_id={cour["kitsu_id"]} ({cour["subtype"]}): {cour["title"]}')
            continue
        if match and subtype not in match:
            # no log?  used in get_movie_info()
            continue
        cours.append(cour)
    # if not cours:
    #     return None

    cours.sort(key=lambda x: x['start_date'] or date.max)

    fflog(f'kitsu: {len(cours)} cours dla tmdb={tmdb_id}')
    for c in cours:
        fflog(f'  kitsu_id={c["kitsu_id"]} ep={c["ep_count"]} start={c["start_date"]} end={c["end_date"]} "{c["title"]}"')

    return cours


def find_cour_by_date(cours: Sequence[CourInfo], episode_date: date | None) -> tuple[CourInfo | None, int]:
    """
    Dopasowuje cour na podstawie daty odcinka/sezonu.
    Szuka coura, którego zakres dat (start_date..end_date) obejmuje episode_date.
    Zwraca (cour, offset) lub (None, 0).
    offset = suma ep_count courów PRZED znalezionym (do obliczenia local_ep).
    """
    if not cours or not episode_date:
        return None, 0

    offset = 0
    for i, cour in enumerate(cours):
        start = cour['start_date']
        end   = cour['end_date']
        if not start:
            offset += cour['ep_count'] or 0
            continue

        # Sprawdź czy data mieści się w zakresie tego coura
        if end and start <= episode_date <= end:
            fflog(f'kitsu: find_cour_by_date: date={episode_date} pasuje do cour "{cour["title"]}" ({start}..{end})')
            return cour, offset

        # Jeśli nie ma end_date, sprawdź czy data >= start i < start następnego coura
        if not end and episode_date >= start:
            next_start = cours[i + 1]['start_date'] if i + 1 < len(cours) else None
            if not next_start or episode_date < next_start:
                fflog(f'kitsu: find_cour_by_date: date={episode_date} pasuje do cour "{cour["title"]}" (start={start}, no end)')
                return cour, offset

        offset += cour['ep_count'] or 0

    fflog(f'kitsu: find_cour_by_date: date={episode_date} nie pasuje do żadnego coura')
    return None, 0


def get_movie_cours(tmdb_id: int) -> list[CourInfo] | None:
    """Return list of CourInfo for movies (subtype=movie) for given TMDB ID, or None if not found or error. Sould be only one entry."""
    return get_cour_structure(tmdb_id, media_type='movie', match=('movie',), skip=())


def get_movie_info(tmdb_id: int) -> CourInfo | None:
    """
    Zwraca info o filmie anime z Kitsu: CourInfo lub None.
    Używane przez movie() w scraperach — nie filtruje subtype=movie.
    """
    cours = get_movie_cours(tmdb_id)
    # return cours[0] if cours else None  # it's enough but no logs
    if not cours:
        return None
    movie = cours[0]
    fflog(f'kitsu/movie: tmdb={tmdb_id} → "{movie["title"]}" mal_id={movie["mal_id"]} anilist_id={movie["anilist_id"]}')
    return movie


def resolve_cour(cours: Sequence[CourInfo], ffitem: FFItem) -> tuple[CourInfo | None, int | None]:
    """
    Na podstawie ffitem (abs_ep + data odcinka) wybiera właściwy cour i oblicza lokalny numer odcinka.
    Zwraca (cour, local_ep) lub (None, None).
    """
    abs_ep = ffitem.absolute_episode_number()
    if not abs_ep:
        return None, None

    ep_date = ffitem.date
    if not ep_date and ffitem.season_item:
        ep_date = ffitem.season_item.date

    cour: CourInfo | None = None
    local_ep: int | None = None

    if ep_date:
        cour, offset = find_cour_by_date(cours, ep_date)
        if cour:
            # Gdy TMDB sezon startuje >= start Kitsu coura (tzn. cour należy do tego sezonu),
            # używamy tmdb_ep zamiast abs_ep, żeby uniknąć rozbieżności ep_count między TMDB a Kitsu
            # (np. OPM: Kitsu S1=13 odcinków, TMDB S01=12 → abs_ep byłby o 1 za duży).
            # Gdy season_start > cour.start (np. DBZ Kai: kilka sezonów TMDB = 1 Kitsu cour),
            # wracamy do podejścia abs_ep - offset.
            tmdb_ep = ffitem.episode
            season_start = ffitem.season_item.date if ffitem.season_item else None
            is_continuous = ffitem.show_item.continuous_episode_number if ffitem.show_item else False
            if (not is_continuous and tmdb_ep and season_start and cour['start_date']
                    and season_start <= cour['start_date']):
                season_offset = sum(
                    c['ep_count'] for c in cours
                    if c['start_date'] and c['ep_count']
                    and season_start <= c['start_date'] < cour['start_date']
                )
                local_ep = tmdb_ep - season_offset
                fflog(f'kitsu: resolve_cour: date-based (tmdb_ep={tmdb_ep}, season_start={season_start}, season_offset={season_offset}, local_ep={local_ep}, ep_count={cour["ep_count"]})')
            else:
                local_ep = abs_ep - offset
                fflog(f'kitsu: resolve_cour: date-based (abs_ep={abs_ep}, offset={offset}, local_ep={local_ep}, ep_count={cour["ep_count"]})')
            if local_ep < 1 or (cour['ep_count'] and local_ep > cour['ep_count']):
                fflog('kitsu: resolve_cour: local_ep out of bounds, falling back to map_episode')
                cour = None

    if not cour:
        fflog(f'kitsu: resolve_cour: using map_episode fallback with abs_ep={abs_ep}')
        cour, local_ep = map_episode(cours, abs_ep)

    return cour, local_ep


class RomajiEpisode(NamedTuple):
    """Romaji titles of an anime episode and its number in the cour, to find fansub files."""

    #: The cour title, then the show without its arc / season part (normalized, see normalize_romaji()).
    titles: list[str]
    #: The episode number in the cour.
    episode: int

    @property
    def season(self) -> int | None:
        """The season number of a later cour from its title ("2nd Season", "Season 2"), None for the first one or without it."""
        season = strip_season_suffix(self.titles[0])[1]
        return season if season and season > 1 else None


def romaji_episode(ffitem: FFItem) -> RomajiEpisode | None:
    """
    Tytuły romaji odcinka anime i jego numer w courze — do wyszukiwania plików z fansubów
    ("Shingeki.no.Kyojin.The.Final.Season.07", "Naruto.Shippuuden.414").
    Zwraca ([tytuł coura, tytuł serii bez łuku/sezonu], local_ep) lub None.
    Cours z ffitem.anime_info (patrz ffinfo.retreive_category_data).
    """
    cours = ffitem.anime_info.cours if ffitem.anime_info else None
    if not cours:
        return None
    cour, local_ep = resolve_cour(cours, ffitem)
    if not cour or not local_ep:
        return None
    title = normalize_romaji(cour['title'])
    # seria bez łuku/sezonu: "Kimetsu no Yaiba: Hashira Geiko-hen" → "kimetsu no yaiba"
    base = normalize_romaji(re.sub(r'\s*:[^:]*-hen$', '', strip_season_suffix(cour['title'])[0]))
    base = re.sub(r' (?:(?:the )?final season|season \d+|part \d+|tv)\b.*$', '', base).strip() or title
    return RomajiEpisode(list(dict.fromkeys([title, base])), local_ep)


def cour_episode_finder(romaji: RomajiEpisode) -> Callable[[str], set[int]]:
    """
    Return a function giving the cour episode numbers found in a file name: "<cour title> [e|ep|odcinek] NN"
    ("Shingeki.no.Kyojin.The.Final.Season.07", "Sousou no Frieren - 05", "(Sousou no Frieren) ep.05"); for a later cour
    also "<show> S2 NN", "<show> Season 2 NN" and "<show> … S02ENN" ("Sousou no Frieren S2 - 02", "2nd Season - S02E01"),
    the show title with a bare number is the first cour then. An empty set: no such title with a number.
    Every pattern has a romaji title, so a later cour match is a title match too.
    """
    season = romaji.season
    names = '|'.join(map(re.escape, romaji.titles if season is None else romaji.titles[:1]))
    episode = r'(?:(?:e|ep|odcinek) ?)?(?!(?:19|20)\d\d\b)0*(\d{1,4})(?:v\d)?\b'
    patterns = [rf'\b(?:{names}) {episode}']
    if season is not None:
        patterns.append(rf'\b{re.escape(romaji.titles[-1])} (?:s|season )0*{season} {episode}')
        patterns.append(rf'\b{re.escape(romaji.titles[-1])}\b.*?\bs0*{season} ?e0*(\d{{1,4}})\b')
    rx = re.compile('|'.join(patterns))

    def find(file_name: str) -> set[int]:
        """Return the cour episode numbers in the file name (normalized like the titles)."""
        return {int(num) for mch in rx.finditer(normalize_romaji(file_name.replace('_', ' '))) for num in mch.groups() if num}

    return find


def map_episode(cours: Sequence[CourInfo], abs_ep: int) -> tuple[CourInfo | None, int | None]:
    """
    Mapuje absolutny numer odcinka na (cour, local_ep_number).

    abs_ep: liczony od 1 w ramach listy cours którą przekazujesz.
            Scraper odpowiada za przekazanie właściwego podzbioru courów
            (np. tylko courów danego TMDB season) lub pełnej listy
            z właściwym abs_ep liczonym globalnie.

    Zwraca (None, None) jeśli abs_ep wykracza poza sumę ep_count.
    """
    cumulative = 0
    for cour in cours:
        ep_count = cour['ep_count'] or 0
        if cumulative < abs_ep <= cumulative + ep_count:
            return cour, abs_ep - cumulative
        cumulative += ep_count

    fflog(f'kitsu: map_episode abs_ep={abs_ep} wykracza poza {cumulative} odcinków łącznie')
    return None, None


# ---------------------------------------------------------------------------
# Wewnętrzne helpery
# ---------------------------------------------------------------------------


def _get_kitsu_ids(tmdb_id: int, media_type: TmdbMediaType) -> list[AnimeIds] | None:
    """Zwraca listę ID anime dla TMDB ID danego typu (z cache jeśli jest).

    Najpierw próbuje serwera ARM, a gdy ten zawiedzie — list Fribb (fallback).
    media_type: 'tv' lub 'movie' (przestrzenie ID TMDB są rozłączne).
    """
    # The anime IDs are external IDs of the media, kept in the ID map of `media.db` (service `anime`, a value per
    # entry `kitsu/mal/anilist`: one TMDB title has more entries - cours; '' - no entry); they grow, so with a deadline
    from ..ff.db import media
    ref = MediaRef.from_tmdb('movie' if media_type == 'movie' else 'show', tmdb_id)
    if (cached := media.ids_of([ref], {ANIME_ID_SERVICE}).get(ref, {}).get(ANIME_ID_SERVICE)) is not None:
        return [_anime_ids(value) for value in cached if value] or None

    ids = _ids_from_arm(tmdb_id)
    if ids is None:
        ids = _ids_from_fribb(tmdb_id, media_type)
    if ids:
        media.store_ids([(ref, ANIME_ID_SERVICE, f'{it.kitsu}/{it.myanimelist or ""}/{it.anilist or ""}') for it in ids],
                        source='arm' if not _arm_down else 'fribb', ttl=const.sources.kitsu.ids_ttl, replace=True)
    elif not _arm_down or _fribb_index:
        # no anime IDs from a source which answered (not a network error)
        media.store_ids([(ref, ANIME_ID_SERVICE, '')], source='arm', ttl=const.sources.kitsu.ids_empty_ttl, replace=True)
    return ids


#: Service of anime IDs in the ID map: a value is `kitsu/mal/anilist` of one entry.
ANIME_ID_SERVICE: str = 'anime'


def _anime_ids(value: str) -> AnimeIds:
    """Return anime IDs of a value of the ID map (`kitsu/mal/anilist`)."""
    kitsu, _, rest = value.partition('/')
    mal, _, anilist = rest.partition('/')
    return AnimeIds(kitsu=int(kitsu), myanimelist=int(mal) if mal else None, anilist=int(anilist) if anilist else None)


def _ids_from_arm(tmdb_id: int) -> list[AnimeIds] | None:
    """Mapowanie z serwera ARM. None gdy ARM niedostępny lub brak danych."""
    global _arm_down
    if _arm_down:
        return None
    try:
        resp = requests.get(ARM_URL.format(tmdb=tmdb_id), headers=_HEADERS, timeout=8)
        if not resp or resp.status_code != 200:
            fflog(f'kitsu/ARM: status={getattr(resp, "status_code", "?")} — przełączam na fallback (Fribb)')
            _arm_down = True
            return None
        # ARM zwraca listę: [{kitsu: 123, myanimelist: 456, anilist: 789}, ...]
        ids = [AnimeIds(kitsu=kitsu_id, myanimelist=entry.get('myanimelist'), anilist=entry.get('anilist'))
               for entry in resp.json() if (kitsu_id := entry.get('kitsu'))]
        if ids:
            fflog(f'kitsu/ARM: tmdb={tmdb_id} → {ids}')
            return ids
        return None  # ARM zdrowy, ale brak wpisu — spróbuj jeszcze Fribb
    except Exception:
        fflog('kitsu/ARM: serwer niedostępny — przełączam na fallback (Fribb)')
        _arm_down = True
        return None


def _ids_from_fribb(tmdb_id: int, media_type: TmdbMediaType) -> list[AnimeIds] | None:
    """Mapowanie ze statycznych list Fribb (fallback gdy ARM padł)."""
    entries = _get_fribb_index().get(f'{media_type}:{tmdb_id}')
    if entries:
        fflog(f'kitsu/Fribb: tmdb={media_type}:{tmdb_id} → {entries}')
        return [AnimeIds(kitsu=kitsu_id, myanimelist=mal_id, anilist=anilist_id) for kitsu_id, mal_id, anilist_id in entries]
    return None


def _get_fribb_index() -> dict[str, list[list[int | None]]]:
    """Indeks 'typ:tmdb_id' → [[kitsu_id, mal_id, anilist_id], ...] z list Fribb.

    Listy Fribb pobierane są raz i trzymane w trwałym cache (7 dni).
    """
    global _fribb_index
    if _fribb_index is not None:
        return _fribb_index

    # 1) trwały cache (świeży: młodszy niż const.sources.kitsu.fribb_ttl)
    fresh = _store.get(_FRIBB_CACHE_KEY, max_age=const.sources.kitsu.fribb_ttl)
    if isinstance(fresh, dict):
        _fribb_index = fresh
        return _fribb_index

    # 2) pobierz listę i zbuduj indeks (TMDB ma rozłączne ID dla tv i movie)
    index: dict[str, list[list[int | None]]] = {}
    try:
        resp = requests.get(FRIBB_URL, headers=_HEADERS, timeout=30)
        if resp and resp.status_code == 200:
            for entry in resp.json():
                kitsu_id = entry.get('kitsu_id')
                if not kitsu_id:
                    continue
                tmdb = entry.get('themoviedb_id')
                if isinstance(tmdb, dict):
                    # {'tv': 123} or {'movie': [456, 789]}
                    pairs = [(t, tid) for t, v in tmdb.items() for tid in (v if isinstance(v, list) else (v,)) if tid]
                elif tmdb:
                    pairs = [('tv', tmdb), ('movie', tmdb)]  # typ nieznany
                else:
                    continue
                row = [kitsu_id, entry.get('mal_id'), entry.get('anilist_id')]
                for media_type, tid in pairs:
                    index.setdefault(f'{media_type}:{tid}', []).append(row)
            _store.set(_FRIBB_CACHE_KEY, index, ttl=const.sources.kitsu.fribb_keep)
            fflog(f'kitsu/Fribb: zbudowano indeks ({len(index)} pozycji)')
        else:
            fflog(f'kitsu/Fribb: błąd pobrania, status={getattr(resp, "status_code", "?")}')
    except Exception:
        fflog_exc()

    # 3) pobranie padło — użyj nieświeżego cache, jeśli istnieje
    if not index and isinstance(stale := _store.get(_FRIBB_CACHE_KEY), dict) and stale:
        index = stale
        fflog('kitsu/Fribb: używam nieświeżego indeksu')

    _fribb_index = index
    return index


def _get_kitsu_cours(entries: Sequence[AnimeIds]) -> list[CourInfo | None]:
    """Return cours of the anime entries (in order, None if no data): Kitsu data from the cache, the missing ones from Kitsu API in parallel."""
    metas: dict[int, JsonData | None] = {ids.kitsu: _store.get(f'meta.{ids.kitsu}') for ids in entries}
    if missing := [kitsu_id for kitsu_id, meta in metas.items() if not isinstance(meta, dict)]:
        with RequestsPoolExecutor(min(len(missing), const.sources.kitsu.workers)) as ex:
            metas.update(zip(missing, ex.map(_fetch_kitsu_meta, missing)))
    return [None if (meta := metas[ids.kitsu]) is None else
            CourInfo(kitsu_id=ids.kitsu, mal_id=ids.myanimelist, anilist_id=ids.anilist,
                     **{**meta, **{key: meta[key] and date.fromisoformat(meta[key]) for key in _COUR_DATE_KEYS}})
            for ids in entries]


def _fetch_kitsu_meta(kitsu_id: int) -> JsonData | None:
    """Return Kitsu data of the anime (CourInfo without IDs, dates as ISO strings) from Kitsu API and store it, None on error."""
    try:
        resp = requests.get(KITSU_URL.format(kitsu=kitsu_id), headers=_HEADERS, timeout=10)
        if not resp or resp.status_code != 200:
            fflog(f'kitsu: błąd dla kitsu_id={kitsu_id} status={getattr(resp, "status_code", "?")}')
            return None

        data = resp.json().get('data', {})
        if not data:
            return None
        attrs = data.get('attributes', {})

        # Preferuj en_jp (romaji) — to czego używają polskie strony animezone/shinden
        titles = attrs.get('titles', {})
        title: str = (titles.get('en_jp')
                      or titles.get('en')
                      or attrs.get('canonicalTitle')
                      or '')

        def iso_date(key: str) -> str | None:
            """Return the date of the attribute as ISO string (None if missing or invalid)."""
            try:
                return datetime.strptime(attrs.get(key) or '', '%Y-%m-%d').date().isoformat()
            except ValueError:
                return None

        meta: JsonData = {
            'title': title,
            'ep_count': attrs.get('episodeCount') or 0,
            'start_date': iso_date('startDate'),
            'end_date': iso_date('endDate'),
            'subtype': attrs.get('subtype', ''),
        }
        ended = bool(meta['end_date']) and meta['end_date'] < date.today().isoformat()
        _store.set(f'meta.{kitsu_id}', meta, ttl=const.sources.kitsu.meta_ended_ttl if ended else const.sources.kitsu.meta_ttl)
        return meta

    except Exception:
        fflog_exc()
        return None
