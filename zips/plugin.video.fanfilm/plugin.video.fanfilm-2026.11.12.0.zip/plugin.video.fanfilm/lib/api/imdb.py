from __future__ import annotations
import json
import base64
import random
from typing import Any, Callable, Iterable, Mapping, Sequence, Collection, Generic, ClassVar, TypeVar, cast, TYPE_CHECKING
from functools import wraps
from typing_extensions import TypeAlias, Literal, get_args as get_typing_args
from concurrent.futures import ThreadPoolExecutor
from attrs import define, frozen

# --- FanFilm imports ---
from ..ff import requests
from ..ff.listcache import FetchedList, cached_list, list_params, mark_stale
from ..ff.accounts import Account, AccountClient
from ..ff.ratings import RatingScale

F = TypeVar('F', bound=Callable[..., Any])
from ..ff.logs import fflog
from ..ff.item import FFItem, ListEntry
from ..ff.types import JsonData
from ..ff.source_utils import DEFAULT_UA
from ..defs import MediaRef, VideoIds, RefType, ItemList, FFRef, T
from ..kolang import L
from cdefs import ListSection, ListType
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.sync import SyncBucket


def _rand_digits(n: int) -> str:
    """Random N-digit string used to fabricate Amazon-style session IDs (ubid-main, x-amzn-sessionid)."""
    return ''.join(random.choices('0123456789', k=n))


ImdbTitleType = Literal['movie', 'tvSeries', 'short', 'tvEpisode', 'tvMiniSeries',
                        'tvMovie', 'tvSpecial', 'tvShort', 'videoGame', 'video',
                        'musicVideo', 'podcastSeries', 'podcastEpisode']

ImdbListType = Literal['TITLES', 'PEOPLE', 'VIDEOS', 'IMAGES']

ListVisibility = Literal['PUBLIC', 'PRIVATE']


AnyListType: TypeAlias = 'ImdbListType | RefType | ListType'


class ImdbItemList(ItemList[T], Generic[T]):

    def __init__(self, *args, page: int, page_size: int = 0, total_pages: int, total_results: int = 0,
                 user_id: str | None = None, user_name: str | None = None, mine: bool = False,
                 ratings: dict[str, int | None] | None = None) -> None:
        super().__init__(*args, page=page, page_size=page_size, total_pages=total_pages, total_results=total_results)
        self.ratings = ratings  # parallel ffid->rating dict, populated only when authenticated
        self.user_id = user_id
        self.user_name = user_name
        self.mine = mine


@define
class ImdbApiStats:
    request_count: int = 0


@frozen
class UserRating:
    """The authenticated user's rating for one title. `value` is 1..10, `date` is ISO 8601 string."""
    value: int
    date: str


#: Supported award group names for last_oscars_refs; these are legacy IMDB UI group names that we map to AwardEventNominationSearchInput parameters.
AwardNames = Literal['oscar_winner', 'oscar_nominee',
                     'best_picture_winner', 'oscar_best_picture_nominees',
                     'best_director_winner', 'oscar_best_director_nominees',
                     'golden_globe_winner', 'golden_globe_nominee',
                     'razzie_winner', 'razzie_nominee',
                     'emmy_winner', 'emmy_nominee']


# Legacy IMDB UI group-name -> AwardEventNominationSearchInput (eventId, optional category, optional winner-filter).
# Omitted winnerFilter means "any nomination" (winners + non-winners), matching the legacy `_nominee` semantics.
_AWARD_GROUPS: dict[AwardNames, dict[str, Any]] = {
    'oscar_winner':                 {'eventId': 'ev0000003', 'winnerFilter': 'WINNER_ONLY'},
    'oscar_nominee':                {'eventId': 'ev0000003'},
    'best_picture_winner':          {'eventId': 'ev0000003', 'searchAwardCategoryId': 'bestPicture',  'winnerFilter': 'WINNER_ONLY'},
    'oscar_best_picture_nominees':  {'eventId': 'ev0000003', 'searchAwardCategoryId': 'bestPicture'},
    'best_director_winner':         {'eventId': 'ev0000003', 'searchAwardCategoryId': 'bestDirector', 'winnerFilter': 'WINNER_ONLY'},
    'oscar_best_director_nominees': {'eventId': 'ev0000003', 'searchAwardCategoryId': 'bestDirector'},
    'golden_globe_winner':          {'eventId': 'ev0000292', 'winnerFilter': 'WINNER_ONLY'},
    'golden_globe_nominee':         {'eventId': 'ev0000292'},
    'razzie_winner':                {'eventId': 'ev0000558', 'winnerFilter': 'WINNER_ONLY'},
    'razzie_nominee':               {'eventId': 'ev0000558'},
    'emmy_winner':                  {'eventId': 'ev0000223', 'winnerFilter': 'WINNER_ONLY'},
    'emmy_nominee':                 {'eventId': 'ev0000223'},
}


_Q_LIST = '''query L($id: ID!, $first: Int!, $after: ID) {
  list(id: $id) {
    author { userId nickName }
    items(first: $first, after: $after) {
      total
      edges { node { createdDate description { originalText { plainText } } item {
        __typename
        ... on Title {
          id titleType { id } __USER_RATING__
          series { series { id } episodeNumber { episodeNumber seasonNumber } }
        }
        ... on Name { id }
      } } }
      pageInfo { hasNextPage endCursor }
    }
  }
  user {
    profile { userId nickName }
  }
}'''


_Q_WATCHLIST = '''query W($user: ID, $first: Int!, $after: ID) {
  predefinedList(classType: WATCH_LIST, userId: $user) {
    items(first: $first, after: $after) {
      total
      edges { node { createdDate description { originalText { plainText } } item {
        __typename
        ... on Title {
          id titleType { id } __USER_RATING__
          series { series { id } episodeNumber { episodeNumber seasonNumber } }
        }
      } } }
      pageInfo { hasNextPage endCursor }
    }
  }
}'''


_Q_USER_LISTS = '''query U($user: ID, $first: Int!, $after: ID, $listTypes: [ListTypeId!]!) {
  userListSearch(first: $first, after: $after, listOwnerUserId: $user, filter: { anyListTypes: $listTypes }) {
    total
    edges {
      node {
        id
        name { originalText }
        description { originalText { plainText } }
        primaryImage { image { url } }
        items(first: 0) { total }
        author { userId nickName }
        listType { id }
      }
    }
    pageInfo { hasNextPage endCursor }
  }
}'''


_Q_USER_INFO = '''query I($user: ID!) {
  userListSearch(first: 1, listOwnerUserId: $user) {
    total
    edges {
      node {
        author {
          userId
          nickName
          bio { text { plainText } }
          primaryImage { image { url } }
        }
      }
    }
  }
}'''


_Q_SEARCH = '''query S($first: Int!, $after: String, $award: AwardSearchConstraint, $types: [String!]) {
  advancedTitleSearch(
    first: $first
    after: $after
    sort: { sortBy: YEAR, sortOrder: DESC }
    constraints: { awardConstraint: $award, titleTypeConstraint: { anyTitleTypeIds: $types } }
  ) {
    total
    edges { node { title { id titleType { id } __USER_RATING__ } } }
    pageInfo { hasNextPage endCursor }
  }
}'''


_Q_TITLE_RATING = '''query TR($id: ID!) {
  title(id: $id) { userRating { value date } }
}'''


_Q_USER_RATINGS_SEARCH = '''query UR($first: Int!, $after: String, $minR: Int, $maxR: Int, $types: [String!]) {
  advancedTitleSearch(
    first: $first
    after: $after
    sort: { sortBy: MY_RATING_DATE, sortOrder: DESC }
    constraints: {
      myRatingConstraint: { filterType: INCLUDE, ratingRange: { min: $minR, max: $maxR } }
      titleTypeConstraint: { anyTitleTypeIds: $types }
    }
  ) {
    total
    edges { node { title {
      id titleType { id } titleText { text }
      userRating { value date }
      series { series { id } episodeNumber { episodeNumber seasonNumber } }
    } } }
    pageInfo { hasNextPage endCursor }
  }
}'''


#: Fingerprints of the lists of the account (`sync_activities()`): the watchlist, the own lists, the ratings - in one request.
_Q_SYNC = '''query Sync {
  watchlist: predefinedList(classType: WATCH_LIST, userId: null) { lastModifiedDate }
  lists: userListSearch(first: 250, listOwnerUserId: null, filter: { anyListTypes: [TITLES, PEOPLE] }) {
    total
    edges { node { id name { originalText } lastModifiedDate } }
  }
  rated: advancedTitleSearch(
    first: 1
    sort: { sortBy: MY_RATING_DATE, sortOrder: DESC }
    constraints: { myRatingConstraint: { filterType: INCLUDE, ratingRange: { min: null, max: null } } }
  ) {
    total
    edges { node { title { id userRating { date } } } }
  }
}'''


_Q_WHOAMI = '''query Whoami {
  user {
    fullName
    profile {
      userId
      nickName
      bio { text { plainText } }
      primaryImage { image { url } }
    }
  }
  userListSearch(first: 1) { total }
}'''


# Mutations require an `at-main` cookie; itemElementId is the regular tt-id for title list items.
_M_RATE = '''mutation Rate($id: ID!, $rating: Int!) {
  rateTitle(input: { titleId: $id, rating: $rating }) { rating { value } }
}'''

_M_UNRATE = '''mutation Unrate($id: ID!) {
  deleteTitleRating(input: { titleId: $id }) { date }
}'''

_M_ADD_WATCHLIST = '''mutation AddWatchlist($id: ID!) {
  addItemToPredefinedList(input: { classType: WATCH_LIST, item: { itemElementId: $id } }) { listId }
}'''

_M_REMOVE_WATCHLIST = '''mutation RemoveWatchlist($id: ID!) {
  removeElementFromPredefinedList(input: { classType: WATCH_LIST, itemElementId: $id }) { listId }
}'''

_M_ADD_LIST = '''mutation AddList($list: ID!, $id: ID!) {
  addItemToList(input: { listId: $list, item: { itemElementId: $id } }) { listId }
}'''

_M_REMOVE_LIST = '''mutation RemoveList($list: ID!, $id: ID!) {
  removeElementFromList(input: { listId: $list, itemElementId: $id }) { listId }
}'''

_M_CREATE_LIST = '''mutation Create($name: String!, $desc: String, $type: ListTypeId!, $vis: ListVisibilityId!, $dup: Boolean!) {
  createList(input: { name: $name, listDescription: $desc, listType: $type, visibility: $vis, allowDuplicates: $dup }) { listId }
}'''

_M_DELETE_LIST = '''mutation Delete($list: ID!) {
  deleteList(input: { listId: $list }) { listId }
}'''

_M_RENAME_LIST = '''mutation Rename($list: ID!, $name: String!) {
  editListName(input: { listId: $list, listName: $name }) { listId }
}'''


def _changes(name: str) -> Callable[[F], F]:
    """Decorate a change of the account lists: the cached list `name` is marked stale after the request."""
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(self: ImdbScraper, *args: Any, **kwargs: Any) -> Any:
            try:
                return func(self, *args, **kwargs)
            finally:
                mark_stale(self.scope, name)
        return cast(F, wrapper)
    return decorator


class ImdbScraper(AccountClient):
    """Scrape IMDB lists and watchlists via their GraphQL API."""

    MEDIA_TYPES: ClassVar[dict[str | None, RefType]] = {
        'movie': 'movie',
        'short': 'movie',
        'tvMovie': 'movie',
        'tvShort': 'movie',
        'tvSpecial': 'movie',
        'video': 'movie',
        'videoGame': 'movie',
        'musicVideo': 'movie',
        'tvSeries': 'show',
        'tvMiniSeries': 'show',
        'podcastSeries': 'show',
        'tvEpisode': 'episode',
        'podcastEpisode': 'episode',
    }

    TITLE_TYPES: ClassVar[dict[RefType, Collection[ImdbTitleType]]] = {
        'movie':   ('movie', 'short', 'tvMovie', 'tvShort', 'tvSpecial'),
        'show':    ('tvSeries', 'tvMiniSeries'),
        'episode': ('tvEpisode',),
    }

    LIST_TYPES: ClassVar[dict[str | ListType, ImdbListType]] = {
        'TITLES': 'TITLES',
        'PEOPLE': 'PEOPLE',
        'VIDEOS': 'VIDEOS',
        'IMAGES': 'IMAGES',
        'movie': 'TITLES',
        'show': 'TITLES',
        'person': 'PEOPLE',
        ListType.MOVIE: 'TITLES',
        ListType.SHOW: 'TITLES',
        ListType.MAIN: 'TITLES',
        ListType.EPISODE: 'TITLES',
        ListType.MAIN | ListType.EPISODE: 'TITLES',
        ListType.SHOW | ListType.EPISODE: 'TITLES',
        ListType.PERSON: 'PEOPLE',
    }

    ME: ClassVar[str] = 'me'  # special user ID for viewer-mode (cookie owner's watchlist)

    # IMDB silently caps `first` per query: userListSearch at 250 edges, advancedTitleSearch at 1000.
    # Both have HMAC-signed cursors -> only sequential chain via endCursor is possible (no random-access by forge).
    USER_LISTS_BATCH: ClassVar[int] = 250
    SEARCH_BATCH: ClassVar[int] = 1000
    # Max aliased mutations per HTTP request for any bulk operation (rate/unrate, list add/remove, watchlist add/remove).
    # Tested up to 1000 aliases / 80 KB body; 250 is conservative default.
    MUTATION_BATCH: ClassVar[int] = 250

    #: Seconds a new list may be missing in the lists of the account (IMDb is slow to show it), see `create_list()`.
    NEW_LIST_DELAY: ClassVar[float] = 5.0
    #: Sections of lists of the account.
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'watchlist': ListSection(types=ListType.MAIN),
        'user': ListSection(types=ListType.MOVIE | ListType.SHOW | ListType.EPISODE | ListType.PERSON, create={'public': True},
                         type_choices={L(30632, 'Titles'): ListType.MAIN | ListType.EPISODE, L(30633, 'People'): ListType.PERSON}),
    }
    #: Rating scale of the account.
    RATING: ClassVar[RatingScale | None] = RatingScale(type=int, min=1, max=10, step=1, media=('movie', 'show', 'episode'))
    #: Sync buckets (`lib.ff.sync`): fingerprints of the lists (IMDb has no activities), see `sync_activities()`.
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = dict.fromkeys(('lists.watchlist', 'lists.user', 'ratings'))
    #: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = {'lists.watchlist': 'watchlist', 'lists.user': 'user', 'ratings': 'rated'}
    #: Interval of the sync in the service (fingerprints cost more than activities).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.fingerprint_interval

    _DEBUG_STATS: ClassVar[ImdbApiStats] = ImdbApiStats()
    _FAKE: ClassVar[bool] = False

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        # The account of the client: its cookie or its public user; given, the first IMDb account (alias) or none (public).
        super().__init__(account, alias=alias)
        self._cache_url: str = 'https://caching.graphql.imdb.com/'   # public read-side, cached
        self._auth_url: str = 'https://graphql.imdb.com/'            # write-side; also returns private data when authenticated
        self._ubid: str = f'{_rand_digits(3)}-{_rand_digits(7)}-{_rand_digits(7)}'  # stable per-instance fake ubid-main
        self.headers: dict[str, str] = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            # required: IMDB rejects GraphQL requests without a matching Origin/Referer (403), UA alone isn't enough
            'Origin': 'https://www.imdb.com',
            'Referer': 'https://www.imdb.com/',
        }

    def _account_value(self, key: str) -> str:
        """Return a value of the account state (`at-main`, `user_agent`, `accounts.db`), '' if none."""
        if self.account is None:
            return ''
        from ..ff.db.accounts import account_data_store
        return str(account_data_store(self.account.id).get(key) or '')

    def refresh_profile(self) -> JsonData | None:
        """Get the cookie owner and keep it as the account profile (`id`, `username`), None on failure."""
        if self.account is None or (me := self.whoami()) is None:
            return None
        from ..ff.db.accounts import account_data_store
        profile = {'id': me.vtag.getIMDBNumber(), 'username': me.title}
        account_data_store(self.account.id).set('profile', profile, ttl=None)
        return profile

    def credentials(self) -> str:
        """Return the `at-main` cookie of the account ('' - none), see `AccountStore.auth_state()`."""
        return self._account_value('at-main')

    @property
    def authenticated(self) -> bool:
        """True when the account has an `at-main` cookie (does not verify token validity)."""
        return bool(self.credentials())

    @property
    def public_user(self) -> str | None:
        """Return the public user (`ur…`) of the account (a public account), None if not given."""
        if self.account is None or not (user := str(self.account.config.get('user') or '').strip()):
            return None
        return f'ur{user}' if user.isdecimal() else user

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists: the account ID."""
        return self.account.id if self.account is not None else 'imdb'

    def _gql(self, query: str, variables: dict[str, Any] | None = None) -> JsonData:
        op = query.split('{', 1)[0].strip().replace('\n', ' ')
        fflog.debug(f'GraphQL post: {op} variables={variables}')
        at_main = self.credentials()
        # Inject auth-only Title fields when authenticated; placeholder is a no-op otherwise.
        query = query.replace('__USER_RATING__', 'userRating { value }' if at_main else '')
        headers = dict(self.headers)
        cookies: dict[str, str] = {}
        if at_main:
            url = self._auth_url
            headers['x-amzn-sessionid'] = f'{_rand_digits(3)}-{_rand_digits(7)}-{_rand_digits(7)}'
            headers['x-imdb-client-name'] = 'imdb-web-next'
            headers['x-imdb-user-language'] = 'en-US'
            headers['x-imdb-user-country'] = 'US'
            cookies['at-main'] = at_main
            cookies['ubid-main'] = self._ubid
        else:
            url = self._cache_url
        try:
            # imdb.user_agent (captured by the browser userscript) is preferred; DEFAULT_UA is a
            # fallback so requests still look browser-like when the userscript never ran.
            headers['User-Agent'] = self._account_value('user_agent') or DEFAULT_UA
        except (RuntimeError, KeyError):
            pass
        fflog(f'GraphQL post: {op} variables={variables} auth={bool(at_main)}')
        self._DEBUG_STATS.request_count += 1
        if self._FAKE:
            return {}
        req = requests.post(url, json={'query': query, 'variables': variables or {}}, headers=headers, cookies=cookies or None)
        if req.status_code != 200:
            fflog(f'GraphQL HTTP {req.status_code} for {op}: {req.text[:200]}')
            return {}
        resp = req.json()
        if errors := resp.get('errors'):
            fflog(f'GraphQL error for {op}: {errors[0].get("message", "")[:200]} ({len(errors)} total)')
            # NOTE: do not drop data — aliased bulk mutations return partial data alongside per-alias errors,
            # and single-query consumers already access via `.get(...) or {}` so partial / null is safe.
        return resp.get('data') or {}

    def _mutate(self, query: str, variables: dict[str, Any], result_key: str) -> bool:
        """Run an authenticated mutation; returns True iff response contains a non-null `result_key`."""
        if not self.authenticated:
            fflog(f'IMDB: not authenticated, skipping mutation ({result_key})')
            return False
        data = self._gql(query, variables)
        return data.get(result_key) is not None

    @staticmethod
    def page_size() -> int:
        """Return the size of a page (`const.dev.imdb.api_page_size`, read at use): read it once for one list, its pages agree."""
        return max(1, const.dev.imdb.api_page_size)

    @staticmethod
    def _list_cursor(page: int | None, size: int) -> str | None:
        """Synthesize an `after` cursor for direct random-access to `page` of `size` on list.items (unsigned cursor)."""
        if not page or page <= 1:
            return None
        offset = (page - 1) * size - 1
        payload = {'sort': {'by': 'LIST_ORDER', 'order': 'ASC'}, 'offset': offset}
        return base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()

    def _user(self, user: str | Sequence[str | None] | None) -> Sequence[str | None]:
        if user is None or user == self.ME:
            if not self.authenticated and (public := self.public_user):
                return [public]  # the user of a public account
            return [None]       # viewer-mode: cookie owner's watchlist
        if isinstance(user, str):
            user = user.split(',')
        return [None if usr == self.ME else f'ur{usr}' if usr.isdecimal() else usr
                for name in user if (usr := None if name is None else name.strip())]

    def _make_list(self,items: Iterable[T], *, page: int, size: int, total: int,
                   ratings: dict[str, int | None] | None = None,
                   user_id: str | None = None, user_name: str | None = None, mine: bool = False,
                   ) -> ImdbItemList[T]:
        """Return the page `page` (of `size` items) of a list of `total` items."""
        items = ImdbItemList(items, page=page or 1, page_size=size, total_pages=(total + size - 1) // size, total_results=total,
                             user_id=user_id, user_name=user_name, mine=mine, ratings=ratings)
        return items

    def _get_list(self,
                  query: str,
                  variables: dict[str, Any],
                  *,
                  data_key: str,
                  name: str,
                  media_type: RefType | None = None,
                  page: int | None = 0,
                  bucket: str = '',
                  ) -> ImdbItemList[FFItem]:
        """
        Return the page of the list `name` of the account from the list cache (the whole list is fetched once); `bucket` - the
        sync bucket watching it ('' - none: a list of another user).
        """
        page = max(1, page or 1)
        size = self.page_size()

        def get(pg: int) -> JsonData:
            return self._gql(query, {**variables, 'first': size, 'after': self._list_cursor(pg, size)})

        def fetch() -> FetchedList | None:
            # the whole list: the first page gives the total, other pages by synthesized cursors (random access)
            data = get(1)
            container = data.get(data_key)
            if not isinstance(container, dict) or not isinstance(items_data := container.get('items'), dict):
                return None  # an error (e.g. no authorization: partial data without the list) is not an empty list
            total = items_data.get('total') or 0
            edges = list(items_data.get('edges') or [])
            if (pages := min((total + size - 1) // size, const.lists.cache.limit // size + 1)) > 1:
                with ThreadPoolExecutor(4) as ex:
                    for more in ex.map(get, range(2, pages + 1)):
                        if not isinstance(more_items := (more.get(data_key) or {}).get('items'), dict):
                            return None  # incomplete data looks like removed items
                        edges.extend(more_items.get('edges') or ())
            nodes = [node for edge in edges if (node := edge.get('node')) and node.get('item')]  # the item with its data in the list
            meta = {'author': container.get('author') if isinstance(container, dict) else None,
                    'profile': (data.get('user') or {}).get('profile')}
            return FetchedList([(self._item_to_ref(node['item']), node) for node in nodes], total=total, meta=meta)

        stored = cached_list(self.scope, name, fetch, params=list_params(auth=self.authenticated, **variables), bucket=bucket)
        if stored is None:
            return ImdbItemList.empty()
        meta = stored.row.meta
        user_id = user_name = None
        mine = False
        if author := meta.get('author'):
            user_id = author.get('userId')
            user_name = author.get('nickName')
            if profile := meta.get('profile'):
                mine = profile.get('userId') == user_id
        # a stored node: the item with its data in the list (a list stored before: the item only, kept on a failed fetch)
        nodes = [(node, item, ref) for node in stored.items if (ref := self._item_to_ref(item := node.get('item', node), media_type))]  # the media filter
        total = len(nodes)
        nodes = nodes[(page - 1) * size:page * size]
        ratings: dict[str, int | None] | None = None
        if self.authenticated:
            ratings = {item['id']: ((item.get('userRating') or {}).get('value')) for _, item, _ in nodes if item.get('id')}
        return self._make_list([self._list_item(ref, node) for node, _, ref in nodes], page=page, size=size, total=total, user_id=user_id, user_name=user_name,
                               mine=mine, ratings=ratings)

    @staticmethod
    def _list_item(ref: MediaRef, node: JsonData) -> FFItem:
        """Return the item of a list with its data in the list (`list_entry`: the added date, the note of the user)."""
        it = FFItem(ref)
        it.list_entry = ListEntry.new(added_at=node.get('createdDate'), note=((node.get('description') or {}).get('originalText') or {}).get('plainText'))
        return it

    @classmethod
    def _item_to_ref(cls, item: JsonData, media_filter: RefType | None = None) -> MediaRef | None:
        """Polymorphic dispatch by `__typename` for items pulled via the union-typed `list.items.edges.node.item`.
        Returns None when `media_filter` is set and the item does not match. Title -> _title_to_ref; Name -> person."""
        typename = item.get('__typename')
        if typename == 'Title':
            type_id = (item.get('titleType') or {}).get('id')
            media = cls.MEDIA_TYPES.get(type_id) if type_id else None
            if not media or (media_filter and media_filter != media):
                return None
            return cls._title_to_ref(item, media)
        if typename == 'Name':
            if media_filter and media_filter != 'person':
                return None
            return MediaRef(type='person', ffid=VideoIds.make_ffid(imdb=item['id']))
        return None

    @staticmethod
    def _title_to_ref(title: JsonData, media: RefType) -> MediaRef:
        """Build a MediaRef from a Title node. For tvEpisode with `series` populated, produces canonical
        FanFilm episode form (type='show', ffid=series, season=N, episode=M); otherwise plain (type=media, ffid=title)."""
        type_id = (title.get('titleType') or {}).get('id')
        series = title.get('series') or {}
        if type_id == 'tvEpisode' and series:
            parent = series.get('series') or {}
            ep = series.get('episodeNumber') or {}
            series_id = parent.get('id')
            season_num = ep.get('seasonNumber')
            ep_num = ep.get('episodeNumber')
            if series_id and season_num and ep_num:
                return MediaRef(type='show', ffid=VideoIds.make_ffid(imdb=series_id), season=season_num, episode=ep_num)
        return MediaRef(type=media, ffid=VideoIds.make_ffid(imdb=title['id']))

    def imdb_id(self, ref: str | FFRef | None, /) -> str:
        """Get the IMDB id (tt...) for a given FFRef or string. Returns empty str if no IMDB id is found."""
        if not ref:
            return ''
        if isinstance(ref, str):
            if ref.isdecimal():
                return f'tt{ref}'
            return ref
        if isinstance(ref, FFItem):
            ffitem: FFItem = ref
            if imdb := ffitem.vtag.getIMDBNumber():
                return imdb
        return ref.ref.video_ids.imdb or ''

    def watch_list(self, user: str | None = None, *,
                   media_type: RefType | None = None, page: int | None = None) -> ImdbItemList[FFItem]:
        """Get a user's watchlist items as a paginated list of FFItems (with their data in the list). `user=None` (default) selects viewer-mode
        (returns cookie owner's watchlist via `userId: null`; requires auth). `user=''` returns empty list. Non-empty
        `user` (or CSV — first ID used) fetches that user's watchlist (must be public if not your own)."""
        users = self._user(user)
        if not users:
            return ItemList.empty()
        user_id = users[0]
        return self._get_list(_Q_WATCHLIST, {'user': user_id}, data_key='predefinedList', name='watchlist', media_type=media_type, page=page,
                              bucket='' if user_id else 'lists.watchlist')

    def list(self, list_id: str, *, media_type: RefType | None = None, page: int | None = None) -> ImdbItemList[FFItem]:
        """Get a list's items as a paginated list of FFItems (with their data in the list). List ID can be with or without ls prefix."""
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        return self._get_list(_Q_LIST, {'id': list_id}, data_key='list', name=f'user/{list_id}', media_type=media_type, page=page,
                              bucket='lists.user' if self._own_list(list_id) else '')

    def _own_list(self, list_id: str) -> bool:
        """Return True if the list is an own list of the signed-in account (its lists from the list cache)."""
        return self.authenticated and any(it.getProperty('list_id') == list_id for it in self.user_lists())

    def last_oscars_refs(self,
                         name: AwardNames = 'oscar_winner',
                         *,
                         title_type: ImdbTitleType | Collection[ImdbTitleType] | None = None,
                         page: int | None = None,
                         ) -> ItemList[MediaRef]:
        """Get last Oscar winners/nominees as a paginated list of MediaRefs. `name` is a legacy IMDB UI group name like 'oscar_winner' or 'emmy_winner'."""
        award = _AWARD_GROUPS.get(name)
        if not award:
            fflog(f'IMDB: unknown award group {name!r}')
            return []
        if title_type is None:
            types: list[str] | None = None
        elif isinstance(title_type, str):
            types = [title_type]
        else:
            types = list(title_type)
        # advancedTitleSearch caps `first` at 1000 edges and the cursor is HMAC-signed -> chain-from-start through
        # SEARCH_BATCH-sized batches until we have enough nodes to slice page N; a page is in the list cache (general).
        page = max(1, page or 1)
        size = self.page_size()
        start = (page - 1) * size
        end = start + size

        def ref(title: JsonData) -> MediaRef | None:
            media = self.MEDIA_TYPES.get((title.get('titleType') or {}).get('id'))
            return MediaRef(media, VideoIds.make_ffid(imdb=title['id'])) if media and title.get('id') else None

        def fetch() -> FetchedList | None:
            titles: list[JsonData] = []
            after: str | None = None
            total = 0
            while len(titles) < end:
                batch = min(self.SEARCH_BATCH, end - len(titles))
                data = self._gql(_Q_SEARCH, {'first': batch, 'after': after,
                                             'award': {'allEventNominations': [award]}, 'types': types})
                if not isinstance(search := data.get('advancedTitleSearch'), dict):
                    return None  # an error is not an empty list
                edges = search.get('edges') or []
                total = search.get('total') or total
                if not edges:
                    break
                titles.extend(t for edge in edges if (t := (edge.get('node') or {}).get('title')))
                info = search.get('pageInfo') or {}
                if not info.get('hasNextPage') or not (after := info.get('endCursor')):
                    break
            return FetchedList([(ref(t), t) for t in titles[start:end]], total=total)

        stored = cached_list('imdb', f'awards/{name}', fetch, params=list_params(types=types and ','.join(types), limit=size), kind='discover', page=page)
        if stored is None:
            return ItemList.empty()
        total = stored.row.total
        items = [r for t in stored.items if (r := ref(t)) is not None]
        ratings: dict[str, int | None] | None = None
        # if self.authenticated:
        #     ratings = {t['id']: ((t.get('userRating') or {}).get('value')) for t in page_titles if t.get('id')}
        return self._make_list(items, page=page, size=size, total=total, ratings=ratings)

    def user_lists(self,
                   user: str | None = None,
                   *,
                   list_type: AnyListType | Sequence[AnyListType] | None = None,
                   page: int | None = None,
                   ) -> ItemList[FFItem]:
        """Get a single user's lists as a paginated ItemList of FFItems. `list_type` selects which kind of list
        to return (TITLES, PEOPLE, VIDEOS, IMAGES) — server-side filter via userListSearch.filter.anyListTypes.

        `user=None` (default) selects viewer-mode: returns lists of the authenticated cookie owner, **including
        private ones**. `user=''` is treated as "no user" (returns empty list, preserves prior empty-input behavior).
        Non-empty `user` (e.g. 'urXXX' or CSV) takes only the first ID and returns **only public lists** of that
        user — IMDB does not expose private lists through the explicit-listOwnerUserId path, even for your own ID.

        userListSearch caps `first` at 250 and its cursor is HMAC-signed, so we walk a chain-from-start of cap-250
        batches; the whole result is in the list cache (`lib.ff.listcache`), pages are cut from it.
        """
        from ..ff.art import list_art

        def make_item(node: JsonData) -> FFItem:
            def var(*keys: str) -> Any:
                val: Any = node
                for key in keys:
                    if not isinstance(val, dict):
                        return None
                    val = val.get(key)
                return val
            name = (node.get('name') or {}).get('originalText') or ''
            ffitem = FFItem(name, mode=FFItem.Mode.Folder)
            ffitem.title = name
            ffitem.vtag.setUniqueID(node['id'], 'imdb')
            ffitem.vtag.setIMDBNumber(node['id'])
            ffitem.setProperty('list_id', node['id'])  # read by ListTarget.from_ffitem() in the "Add to..." picker
            if descr := var('description', 'originalText', 'plainText'):
                ffitem.vtag.setPlot(descr)
            if url := var('primaryImage', 'image', 'url'):
                ffitem.setArt(list_art({'poster': url}))
            if (count := node.get('items')) and (total := count.get('total')) is not None:
                ffitem._children_count = total
                ffitem.role = L(30331, '{n} title|||{n} titles', n=total)
            ffitem.setProperty('list_type', people_type if (node.get('listType') or {}).get('id') == 'PEOPLE' else titles_type)
            return ffitem

        if list_type is None:
            list_type = ['TITLES', 'PEOPLE']
        elif isinstance(list_type, str) or not isinstance(list_type, Sequence):
            list_type = [list_type]
        list_type = [t2 for t1 in list_type if (t2 := self.LIST_TYPES.get(t1))]
        if not list_type:
            fflog('IMDB: unknown list type(s)')
            return ItemList.empty()
        users = self._user(user)
        if not users:
            return ItemList.empty()
        user_id = users[0]

        titles_type = str(ListType.MAIN | ListType.EPISODE)
        people_type = str(ListType.PERSON)

        def fetch() -> FetchedList | None:
            # all lists (the signed cursor allows only a chain from the start), cut to pages here
            nodes: list[JsonData] = []
            after: str | None = None
            filtered_watchlist = False  # IMDB also returns the Watchlist as a plain list - it already has its own menu
            while len(nodes) < const.lists.cache.limit:
                data = self._gql(_Q_USER_LISTS, {'user': user_id, 'first': self.USER_LISTS_BATCH, 'after': after, 'listTypes': list_type})
                if not isinstance(search := data.get('userListSearch'), dict):
                    return None  # an error is not an empty list
                edges = search.get('edges') or []
                if not edges:
                    break
                for edge in edges:
                    if not (node := edge.get('node')):
                        continue
                    if not filtered_watchlist and (node.get('name') or {}).get('originalText') == 'WATCHLIST':
                        filtered_watchlist = True
                        continue
                    nodes.append(node)
                info = search.get('pageInfo') or {}
                if not info.get('hasNextPage') or not (after := info.get('endCursor')):
                    break
            return FetchedList([(None, node) for node in nodes])

        stored = cached_list(self.scope, 'user', fetch, params=list_params(user=user_id, types=','.join(list_type), auth=self.authenticated),
                             bucket='' if user_id else 'lists.user')
        if self._list_created():
            mark_stale(self.scope, 'user')  # a new list can be missing yet: fetched again next time
        if stored is None:
            return ItemList.empty()
        if not page:
            nodes = list(stored.items)
            if user is None and isinstance(created := self._list_created(), dict) and all(n.get('id') != created.get('id') for n in nodes):
                # a new list is missing yet (IMDb is slow to show it): its node from the create
                nodes.append({'id': created['id'], 'name': {'originalText': created.get('name') or ''}, 'listType': {'id': created.get('type')}})
            return ItemList.single([make_item(n) for n in nodes])
        size = self.page_size()
        start = (page - 1) * size
        items = (make_item(n) for n in stored.items[start:start + size])
        return self._make_list(items, page=page, size=size, total=len(stored.items))

    def _list_created(self) -> dict[str, str] | None:
        """Return the list created recently (in any process: `id`, `name`, `type`), the lists of the account may miss it yet."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.scope).get('lists.created')

    @staticmethod
    def _make_user_item(info: JsonData, *, fullname: str = '', total: int | None = None, me: bool = False) -> FFItem | None:
        """Build a FFItem from a user info dict. Both `User.profile` (whoami) and `userListSearch.edges.node.author`
        (user_info_list) have an identical shape — `userId`, `nickName`, `bio.text.plainText`, `primaryImage.image.url`
        — so this single helper covers both. `fullname` is used as nickName fallback (whoami-only field, passed
        separately); `total` (when set) populates `role` with the user's total list count. Returns None when no
        `userId` is present (treated as "no user data")."""
        imdb = info.get('userId') or ''
        if not imdb:
            return None
        nick = info.get('nickName') or fullname or imdb
        ffitem = FFItem(nick, mode=FFItem.Mode.Folder)
        ffitem.title = nick
        ffitem.vtag.setUniqueID(imdb, 'imdb')
        ffitem.vtag.setIMDBNumber(imdb)
        if url := ((info.get('primaryImage') or {}).get('image') or {}).get('url'):
            ffitem.setArt({'poster': url})
        if plain := ((info.get('bio') or {}).get('text') or {}).get('plainText'):
            ffitem.vtag.setPlot(plain)
        if total is not None:
            # -1: userListSearch's total includes the Watchlist, which has its own separate menu entry
            ffitem.role = L(30393, '{n} list|||{n} lists', n=max(0, total - 1))
        ffitem.setProperty('imdb.access', 'private' if me else 'public')
        return ffitem

    def user_info_list(self, user: str | Sequence[str | None] | None) -> list[FFItem | None]:
        """Get a single user's info as a list of FFItems (one per user if `user` is a CSV of IDs)."""
        def get(user: str | None) -> FFItem | None:
            # TODO: check user = None
            if not user:
                return self.whoami()
            data = self._gql(_Q_USER_INFO, {'user': user})
            search = data.get('userListSearch') or {}
            edges = search.get('edges') or []
            if not edges:
                return None
            author: JsonData = (edges[0].get('node') or {}).get('author') or {}
            author.setdefault('userId', user)   # preserve original `userId or user` fallback semantics
            return self._make_user_item(author, total=search.get('total'))

        users = self._user(user)
        with ThreadPoolExecutor() as executor:
            results = list(executor.map(get, users))
        return [it for it in results if it]

    def user_info(self, user: str) -> FFItem | None:
        """Get user info as FFItem (first user if user is comma separated list)."""
        items = self.user_info_list(user)
        return items[0] if items else None

    def whoami(self) -> FFItem | None:
        """Return the currently authenticated user as FFItem, or None if no `at-main` cookie or token expired.
        FFItem.role carries the total count of the user's lists (across all types, including private)."""
        if not self.authenticated:
            return None
        data = self._gql(_Q_WHOAMI)
        user = data.get('user') or {}
        total = (data.get('userListSearch') or {}).get('total')
        return self._make_user_item(user.get('profile') or {}, fullname=user.get('fullName') or '', total=total, me=True)

    @_changes('watchlist')
    def add_to_watchlist(self, imdb_id: str | FFRef) -> bool:
        """Add a title to the authenticated user's watchlist."""
        if not (imdb_id := self.imdb_id(imdb_id)):
            return False
        return self._mutate(_M_ADD_WATCHLIST, {'id': imdb_id}, 'addItemToPredefinedList')

    @_changes('watchlist')
    def remove_from_watchlist(self, imdb_id: str | FFRef) -> bool:
        """Remove a title from the authenticated user's watchlist."""
        if not (imdb_id := self.imdb_id(imdb_id)):
            return False
        return self._mutate(_M_REMOVE_WATCHLIST, {'id': imdb_id}, 'removeElementFromPredefinedList')

    @_changes('user')
    def add_to_list(self, list_id: str, imdb_id: str) -> bool:
        """Add a title to one of the authenticated user's lists. List ID can be with or without `ls` prefix."""
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        return self._mutate(_M_ADD_LIST, {'list': list_id, 'id': imdb_id}, 'addItemToList')

    @_changes('user')
    def remove_from_list(self, list_id: str, imdb_id: str) -> bool:
        """Remove a title from one of the authenticated user's lists. List ID can be with or without `ls` prefix."""
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        return self._mutate(_M_REMOVE_LIST, {'list': list_id, 'id': imdb_id}, 'removeElementFromList')

    @_changes('user')
    def create_list(self,
                    name: str,
                    description: str = '',
                    *,
                    list_type: ImdbListType | RefType | ListType | None = 'TITLES',
                    public: bool = True,
                    allow_duplicates: bool = False,
                    ) -> str | None:
        """Create a new list. Returns the new list's `ls...` id on success, None on failure or if not authenticated."""
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping mutation (createList)')
            return None
        if list_type is None:
            list_type = 'TITLES'
        elif not (list_type := self.LIST_TYPES.get(list_type)):
            return None
        data = self._gql(_M_CREATE_LIST, {
            'name': name,
            'desc': description or None,
            'type': list_type,
            'vis': 'PUBLIC' if public else 'PRIVATE',
            'dup': allow_duplicates,
        })
        if list_id := (data.get('createList') or {}).get('listId'):
            from ..ff.db.accounts import account_data_store
            account_data_store(self.scope).set('lists.created', {'id': list_id, 'name': name, 'type': list_type}, ttl=self.NEW_LIST_DELAY)
        return list_id

    @_changes('user')
    def delete_list(self, list_id: str) -> bool:
        """Delete one of the authenticated user's lists. List ID can be with or without `ls` prefix."""
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        return self._mutate(_M_DELETE_LIST, {'list': list_id}, 'deleteList')

    @_changes('user')
    def rename_list(self, list_id: str, name: str) -> str | None:
        """Rename one of the authenticated user's lists, return its ID (the same), None on failure."""
        lid = f'ls{list_id}' if list_id.isdecimal() else list_id
        return list_id if self._mutate(_M_RENAME_LIST, {'list': lid, 'name': name}, 'editListName') else None

    @_changes('rated')
    def rate_title(self, imdb_id: str | FFRef, rating: int) -> bool:
        """Rate a title (1..10). Returns False if not authenticated or rejected."""
        if not (imdb_id := self.imdb_id(imdb_id)):
            return False
        return self._mutate(_M_RATE, {'id': imdb_id, 'rating': rating}, 'rateTitle')

    @_changes('rated')
    def delete_rating(self, imdb_id: str | FFRef) -> bool:
        """Remove your rating for a title."""
        if not (imdb_id := self.imdb_id(imdb_id)):
            return False
        return self._mutate(_M_UNRATE, {'id': imdb_id}, 'deleteTitleRating')

    def _aliased_batch(self, items: list[tuple[str, str, dict[str, Any], str]]) -> dict[str, bool]:
        """Execute aliased GraphQL mutations in MUTATION_BATCH-sized chunks. Each item is a 4-tuple:
        `(response_key, body_line, vars_dict, decls_str)`. `body_line` is the mutation content placed after
        the alias prefix; may reference variables declared in `decls_str` (e.g. '$r0: Int!'). Per-chunk vars
        and decls are aggregated from member items. Returns `{response_key: success-bool}` across all chunks."""
        results: dict[str, bool] = {}
        for chunk_start in range(0, len(items), self.MUTATION_BATCH):
            chunk = items[chunk_start:chunk_start + self.MUTATION_BATCH]
            body_lines: list[str] = []
            variables: dict[str, Any] = {}
            decls: list[str] = []
            for i, (_, line, item_vars, item_decls) in enumerate(chunk):
                body_lines.append(f'  a{i}: {line}')
                variables.update(item_vars)
                if item_decls:
                    decls.append(item_decls)
            header = f'mutation Batch({", ".join(decls)})' if decls else 'mutation Batch'
            data = self._gql('\n'.join([header + ' {', *body_lines, '}']), variables)
            for i, (key, *_) in enumerate(chunk):
                results[key] = data.get(f'a{i}') is not None
        return results

    @_changes('rated')
    def rate_titles(self, items: Mapping[str | FFRef, int | None]) -> dict[str, bool]:
        """Bulk-rate/unrate titles via aliased GraphQL mutations. Value 1..10 rates, None deletes the rating.
        Returns {tt-id: success}; per-title failures are isolated. Auto-chunked at MUTATION_BATCH aliases each."""
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping bulk rate (rate_titles)')
            return {tt: False for ref, _ in items.items() if (tt := self.imdb_id(ref))}
        bulk: list[tuple[str, str, dict[str, Any], str]] = []
        for i, (ref, value) in enumerate(items.items()):
            tt = self.imdb_id(ref)
            if not tt:
                fflog(f'IMDB: rate_titles skipping unresolvable ref {ref!r}')
                continue
            if value is None:
                bulk.append((tt, f'deleteTitleRating(input: {{ titleId: "{tt}" }}) {{ date }}', {}, ''))
            else:
                var = f'r{i}'
                line = f'rateTitle(input: {{ titleId: "{tt}", rating: ${var} }}) {{ rating {{ value }} }}'
                bulk.append((tt, line, {var: int(value)}, f'${var}: Int!'))
        return self._aliased_batch(bulk)

    def delete_ratings(self, items: Iterable[str | FFRef]) -> dict[str, bool]:
        """Bulk-delete ratings for a sequence of titles. Returns {tt-id: success}."""
        return self.rate_titles(dict.fromkeys(items, None))

    @_changes('user')
    def add_to_list_bulk(self, list_id: str, items: Iterable[str | FFRef]) -> dict[str, bool]:
        """Bulk add titles to a list via aliased GraphQL. Returns {tt-id: success}. List ID can be with or
        without `ls` prefix; per-title failures are isolated; auto-chunked at MUTATION_BATCH."""
        items = list(items)
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping bulk add (add_to_list_bulk)')
            return {tt: False for ref in items if (tt := self.imdb_id(ref))}
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        bulk: list[tuple[str, str, dict[str, Any], str]] = []
        for ref in items:
            tt = self.imdb_id(ref)
            if not tt:
                fflog(f'IMDB: add_to_list_bulk skipping unresolvable ref {ref!r}')
                continue
            line = f'addItemToList(input: {{ listId: "{list_id}", item: {{ itemElementId: "{tt}" }} }}) {{ listId }}'
            bulk.append((tt, line, {}, ''))
        return self._aliased_batch(bulk)

    @_changes('user')
    def remove_from_list_bulk(self, list_id: str, items: Iterable[str | FFRef]) -> dict[str, bool]:
        """Bulk remove titles from a list via aliased GraphQL. Returns {tt-id: success}."""
        items = list(items)
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping bulk remove (remove_from_list_bulk)')
            return {tt: False for ref in items if (tt := self.imdb_id(ref))}
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        bulk: list[tuple[str, str, dict[str, Any], str]] = []
        for ref in items:
            tt = self.imdb_id(ref)
            if not tt:
                fflog(f'IMDB: remove_from_list_bulk skipping unresolvable ref {ref!r}')
                continue
            line = f'removeElementFromList(input: {{ listId: "{list_id}", itemElementId: "{tt}" }}) {{ listId }}'
            bulk.append((tt, line, {}, ''))
        return self._aliased_batch(bulk)

    @_changes('watchlist')
    def add_to_watchlist_bulk(self, items: Iterable[str | FFRef]) -> dict[str, bool]:
        """Bulk add titles to the authenticated user's watchlist. Returns {tt-id: success}."""
        items = list(items)
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping bulk add (add_to_watchlist_bulk)')
            return {tt: False for ref in items if (tt := self.imdb_id(ref))}
        bulk: list[tuple[str, str, dict[str, Any], str]] = []
        for ref in items:
            tt = self.imdb_id(ref)
            if not tt:
                fflog(f'IMDB: add_to_watchlist_bulk skipping unresolvable ref {ref!r}')
                continue
            line = f'addItemToPredefinedList(input: {{ classType: WATCH_LIST, item: {{ itemElementId: "{tt}" }} }}) {{ listId }}'
            bulk.append((tt, line, {}, ''))
        return self._aliased_batch(bulk)

    @_changes('watchlist')
    def remove_from_watchlist_bulk(self, items: Iterable[str | FFRef]) -> dict[str, bool]:
        """Bulk remove titles from the authenticated user's watchlist. Returns {tt-id: success}."""
        items = list(items)
        if not self.authenticated:
            fflog('IMDB: not authenticated, skipping bulk remove (remove_from_watchlist_bulk)')
            return {tt: False for ref in items if (tt := self.imdb_id(ref))}
        bulk: list[tuple[str, str, dict[str, Any], str]] = []
        for ref in items:
            tt = self.imdb_id(ref)
            if not tt:
                fflog(f'IMDB: remove_from_watchlist_bulk skipping unresolvable ref {ref!r}')
                continue
            line = f'removeElementFromPredefinedList(input: {{ classType: WATCH_LIST, itemElementId: "{tt}" }}) {{ listId }}'
            bulk.append((tt, line, {}, ''))
        return self._aliased_batch(bulk)

    def user_rating(self, ref: str | FFRef) -> UserRating | None:
        """Get the authenticated user's rating for a single title. Returns UserRating(value, date) or None if not rated,
        not authenticated, or the ref has no IMDB id. Accepts MediaRef or FFItem (both expose `.ref`)."""
        if not self.authenticated:
            return None
        imdb = self.imdb_id(ref)
        if not imdb:
            return None
        data = self._gql(_Q_TITLE_RATING, {'id': imdb})
        rating = ((data.get('title') or {}).get('userRating') or {})
        value = rating.get('value')
        if value is None:
            return None
        return UserRating(value=int(value), date=rating.get('date') or '')

    def user_ratings(self,
                     *,
                     media_type: RefType | None = None,
                     min_rating: int | None = None,
                     max_rating: int | None = None,
                     page: int | None = None,
                     ) -> ItemList[FFItem]:
        """Get the authenticated user's rated titles, paginated, sorted by rating-date desc. Filters are server-side:
        `media_type` ('movie'/'show'/'episode'), `min_rating`/`max_rating` (1..10 inclusive). Each FFItem carries
        properties 'imdb.user_rating' (str of int) and 'imdb.user_rating.date' (ISO 8601 string)."""
        if not self.authenticated:
            return ItemList.empty()
        types: set[str] | None = set(self.TITLE_TYPES[media_type]) if media_type in self.TITLE_TYPES else None
        page = max(1, page or 1)
        size = self.page_size()
        start = (page - 1) * size
        end = start + size
        # the whole rated list once (all types and ratings), the filters and the page here
        titles = [title for title in self._rated_titles()
                  if (types is None or (title.get('titleType') or {}).get('id') in types)
                  and (min_rating is None or ((title.get('userRating') or {}).get('value') or 0) >= min_rating)
                  and (max_rating is None or ((title.get('userRating') or {}).get('value') or 0) <= max_rating)]
        total = len(titles)

        items: list[FFItem] = []
        for title in titles[start:end]:
            type_id = (title.get('titleType') or {}).get('id')
            media = self.MEDIA_TYPES.get(type_id) if type_id else None
            if not media:
                continue
            rating = title.get('userRating') or {}
            value = rating.get('value')
            if value is None:
                continue
            ref = self._title_to_ref(title, media)
            tt = title['id']
            name = (title.get('titleText') or {}).get('text') or ''
            ffitem = FFItem(ref=ref, mode=FFItem.Mode.Folder)
            ffitem.title = name
            ffitem.vtag.setUniqueID(tt, 'imdb')
            ffitem.vtag.setIMDBNumber(tt)
            ffitem.setProperty('imdb.user_rating', str(int(value)))
            ffitem.setProperty('imdb.user_rating.date', rating.get('date') or '')
            items.append(ffitem)
        return self._make_list(items, page=page, size=size, total=total)

    def _rated_titles(self) -> Sequence[JsonData]:
        """Return all rated titles of the account (sorted by rating date desc) from the list cache."""
        def fetch() -> FetchedList | None:
            titles: list[JsonData] = []
            after: str | None = None
            while len(titles) < const.lists.cache.limit:
                data = self._gql(_Q_USER_RATINGS_SEARCH, {'first': self.SEARCH_BATCH, 'after': after, 'minR': None, 'maxR': None, 'types': None})
                if not isinstance(search := data.get('advancedTitleSearch'), dict):
                    return None  # an error is not an empty list
                edges = search.get('edges') or []
                titles.extend(t for edge in edges if (t := (edge.get('node') or {}).get('title')))
                info = search.get('pageInfo') or {}
                if not edges or not info.get('hasNextPage') or not (after := info.get('endCursor')):
                    break
            return FetchedList([(None, title) for title in titles])

        stored = cached_list(self.scope, 'rated', fetch, bucket='ratings')
        return () if stored is None else stored.items

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """
        Return cursors of the sync buckets (`lib.ff.sync`), None on failure. IMDb has no activities: the watchlist gives the
        time of its last change (also of a removal), the own lists the newest one and their count (a removed list), the
        ratings the newest one (a changed rating moves up) and their count - fingerprints.
        """
        data = self._gql(_Q_SYNC)
        watchlist, lists, rated = data.get('watchlist'), data.get('lists'), data.get('rated')
        if not isinstance(watchlist, dict) or not isinstance(lists, dict) or not isinstance(rated, dict):
            return None  # an error (e.g. an expired cookie) is not "no change"
        nodes = [node for edge in lists.get('edges') or () if (node := edge.get('node'))
                 and (node.get('name') or {}).get('originalText') != 'WATCHLIST']  # the watchlist as a plain list: its own bucket
        newest = max((str(node.get('lastModifiedDate') or '') for node in nodes), default='')
        title = next((edge.get('node') or {}).get('title') or {} for edge in rated.get('edges') or [{}])
        return {
            'lists.watchlist': str(watchlist.get('lastModifiedDate') or ''),
            'lists.user': f'{len(nodes)}|{newest}',
            'ratings': f'{rated.get("total") or 0}|{title.get("id") or ""}|{(title.get("userRating") or {}).get("date") or ""}',
        }

    def rated_titles(self) -> dict[str, int]:
        """Return ratings of all rated titles of the account (IMDb ID -> rating), from the list cache."""
        if not self.authenticated:
            return {}
        return {title['id']: int(value) for title in self._rated_titles() if title.get('id') and (value := (title.get('userRating') or {}).get('value'))}

    # --- Lists and ratings of the account (`AccountClient` vocabulary) ---

    def watchlist(self, *, media: RefType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist of the account (the page, all items without `page`)."""
        if page is None:
            from . import depaginate
            with depaginate(self) as api:
                return ItemList.single(list(api.watch_list(None, media_type=media)))
        return self.watch_list(None, media_type=media, page=page)

    def list_items(self, list_id: str, *, media: RefType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the items of a list (the page, all items without `page`)."""
        if page is None:
            from . import depaginate
            with depaginate(self) as api:
                return ItemList.single(list(api.list(list_id, media_type=media)))
        return self.list(list_id, media_type=media, page=page)

    @staticmethod
    def _imdb_ids(items: Iterable[FFRef]) -> list[str]:
        """Return the IMDb IDs of the media (looked up: a media of another service has no IMDb ID in its ref)."""
        from ..ff.info import ffinfo
        return [imdb for it in ffinfo.lookup_ids(items, {'imdb'}).values() if (imdb := it.get('imdb'))]

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the watchlist or remove them, return the number of changed ones."""
        bulk = self.add_to_watchlist_bulk if state else self.remove_from_watchlist_bulk
        return sum(bulk(self._imdb_ids(items)).values())

    def set_in_list(self, list_id: str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to an own list or remove them, return the number of changed ones."""
        bulk = self.add_to_list_bulk if state else self.remove_from_list_bulk
        return sum(bulk(list_id, self._imdb_ids(items)).values())

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, int]:
        """
        Return the ratings of the account by media (from the list cache): all by the IMDb refs, or of the media `refs`
        (by their IMDb IDs, looked up).
        """
        if not self.authenticated:
            return {}
        if refs is None:
            return {self._title_to_ref(title, media): int(value) for title in self._rated_titles()
                    if (media := self.MEDIA_TYPES.get((title.get('titleType') or {}).get('id')))
                    and (value := (title.get('userRating') or {}).get('value'))}
        if not (rated := self.rated_titles()):
            return {}
        from ..ff.info import ffinfo
        return {ref: rated[imdb] for ref, it in ffinfo.lookup_ids([ref.ref for ref in refs], {'imdb'}).items() if (imdb := it.get('imdb')) and imdb in rated}

    def rating(self, ref: FFRef) -> int | None:
        """Return the rating of the media asked now (by its IMDb ID, looked up), None if not rated (or not signed in)."""
        if not self.authenticated or not (ids := self._imdb_ids([ref])):
            return None
        rating = self.user_rating(ids[0])
        return None if rating is None else int(rating.value)

    def set_ratings(self, items: Iterable[FFRef], rating: int | None) -> int:
        """Rate (`rating`) the media or remove their ratings (None), return the number of changed ones."""
        ids = self._imdb_ids(items)
        return sum(self.rate_titles({imdb: None if rating is None else int(rating) for imdb in ids}).values())


#: Default global IMDB scraper instance.
imdb_api: ImdbScraper = ImdbScraper(alias='imdb')


def make_client(account: Account | None) -> ImdbScraper:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return imdb_api if account is None else ImdbScraper(account)


if __name__ == '__main__':
    from math import log10
    from contextlib import contextmanager
    from typing import TypeVar, Generator, TYPE_CHECKING
    from time import sleep
    from wrapt import ObjectProxy
    from ..ff.cmdline import DebugArgumentParser
    from ..service.web_server import WebServer

    T = TypeVar('T')

    if TYPE_CHECKING:
        ItemProxyBase = (ObjectProxy, T)
    else:
        ItemProxyBase = (ObjectProxy,)

    class ItemProxy(*ItemProxyBase):
        def __init__(self, item: T, *, index: int, width: int = 0) -> None:
            super().__init__(item)
            self._self_index = index
            self._self_width = width

        @property
        def num(self) -> str:
            return f'{self._self_index:{self._self_width}d}'

    awards = ('oscar_winner', 'oscar_nominee', 'best_picture_winner', 'oscar_best_picture_nominees', 'best_director_winner', 'oscar_best_director_nominees',
              'golden_globe_winner', 'golden_globe_nominee', 'razzie_winner', 'razzie_nominee',
              'emmy_winner', 'emmy_nominee', 'golden_globe_winner', 'golden_globe_nominee',
              )
    p = DebugArgumentParser(dest='op')
    p.add_argument('-p', '--page', type=int, help='page number')
    p.add_argument('-P', '--page-size', type=int, help='page size (default 20)')
    p.add_argument('-S', '--cookie-server', action='store_true', help='run a local server to set the at-main cookie from browser session')
    with p.with_subparser('me', help='show info about me (authenticated user)') as pp:
        pass
    with p.with_subparser('watchlist', aliases=['watch'], help='user watchlist') as pp:
        pp.add_argument('user', nargs='?', default='me', help='IMDB user ID like ur23892615')
        pp.add_argument('-a', '--add', metavar='IMDB_ID', help='add to watchlist')
        pp.add_argument('-r', '--remove', metavar='IMDB_ID', help='remove from watchlist')
    with p.with_subparser('user', help='user lists') as pp:
        pp.add_argument('user', nargs='?', default='me', help='IMDB user ID like ur23892615')
        pp.add_argument('-i', '--info', action='store_true', help='get info for: user')
        pp.add_argument('-t', '--type', choices=get_typing_args(ImdbListType), help='get info for: user')
    with p.with_subparser('list', help='list items') as pp:
        pp.add_argument('list', help='IMDB list ID like ls005762314')
        pp.add_argument('-a', '--add', metavar='IMDB_ID', help='add to list')
        pp.add_argument('-r', '--remove', metavar='IMDB_ID', help='remove from list')
        pp.add_argument('-d', '--depaginate', action='store_true', help='depaginate list')
    with p.with_subparser('awards', help='get last awards winners/nominees for given award group') as pp:
        pp.add_argument('awards', choices=awards, nargs='?', default='oscar_winner', help='awards type')
    args = p.parse_args()

    cookie_server: WebServer | None = None
    if args.cookie_server:
        cookie_server = WebServer(works=None)
        cookie_server.start()
        for i in range(100):  # 10 s
            if imdb_api.credentials():
                break
            if not i:
                fflog('Waiting for at-main cookie to be set via cookie server...')
            sleep(.1)
        fflog(f'at-main cookie: {bool(imdb_api.credentials())}')

    # ur23892615  - 1967 title lists (3719 all types)
    # ls005762314 - 519 items, 3 pages

    from cdefs import constdef
    constdef._locked = False  # type: ignore[reportFunctionMemberAccess]
    const.dev.imdb.api_page_size = max(1, args.page_size or 20)
    constdef._locked = True  # type: ignore[reportFunctionMemberAccess]
    imdb = ImdbScraper(alias='imdb')

    @contextmanager
    def enum(items: Sequence[T], *, offset: int = 0, page: int | None = None, page_size: int | None = None) -> Generator[Sequence[T], None, None]:
        if page_size is None:
            page_size = ImdbScraper.page_size()
        if not offset and page is None and page_size and (pg := getattr(items, 'page', None)):
            page = pg
        if not offset and page and page_size:
            offset = (page - 1) * page_size
        total = getattr(items, 'total_results', None)
        all_pages = getattr(items, 'total_pages', None)
        if not all_pages and page and total is not None and page_size:
            all_pages = (total + page_size - 1) // page_size
        w = int(1 + log10(offset + len(items) or 1))
        items = [ItemProxy(it, index=i, width=w) for i, it in enumerate(items, offset + 1)]
        fflog(f'Page {page} / {all_pages or "?"}, items {offset + 1}-{offset + len(items)} / {total or "?"}')
        yield items

    @contextmanager
    def modify(name: str) -> Generator[ImdbScraper, None, None]:  # type: ignore[no-untyped-def]
        class Modifier:
            def __getattr__(self, attr: str) -> Any:
                if not hasattr(imdb, attr):
                    raise AttributeError(f'{type(imdb).__name__!r} object has no attribute {attr!r}')
                if not callable(method := getattr(imdb, attr)):
                    return method
                def wrapper(*args: Any, **kwargs: Any) -> Any:
                    result = method(*args, **kwargs)
                    aa = ', '.join(repr(v) for v in args)
                    kw = ', '.join(f'{k}={v!r}' for k, v in kwargs.items())
                    aa = ', '.join(part for part in (aa, kw) if part)
                    print(f'{name}: {"success" if result else "FAILED"} {method.__name__}({aa})')
                    return result
                return wrapper
        yield Modifier()  # type: ignore

    def print_ref_list(items: Sequence[MediaRef]) -> None:
        with enum(items) as items:
            for ref in items:
                print(f'{ref.num}. {ref}  ({ref.video_ids.imdb or ""})')

    try:
        if args.op == 'me':
            me = imdb.whoami()
            if me:
                print(f'Me[{me.vtag.getIMDBNumber()}]: {me}')
            else:
                print(f'Me: (not authenticated), has at-main cookie: {bool(imdb.credentials())}')
        elif args.op == 'watchlist':
            if args.add:
                if args.user == 'me':
                    with modify('Add') as api:
                        api.add_to_watchlist(args.add)
                else:
                    print('Adding to other users\' watchlists is not supported by the API')
            elif args.remove:
                if args.user == 'me':
                    with modify('Remove') as api:
                        api.remove_from_watchlist(args.remove)
                else:
                    print('Removing from other users\' watchlists is not supported by the API')
            else:
                if args.user == 'me':
                    args.user = None
                items = imdb.watch_list(args.user, page=args.page)
                print_ref_list(items)
        elif args.op == 'user':
            if args.user == 'me':
                args.user = None
            if args.info:
                items = imdb.user_info_list(args.user)
                with enum(items) as items:
                    for it in items:
                        if it:
                            print(f'{it.num}. {it.vtag.getIMDBNumber():12}: {it.label} [{it.role}]')
                        else:
                            print('(none)')
            else:
                items = imdb.user_lists(args.user, page=args.page, list_type=args.type or ('TITLES', 'PEOPLE'))
                with enum(items) as items:
                    for it in items:
                        print(f'{it.num}. {it.vtag.getIMDBNumber():12} [{it.role}] {it}')
        elif args.op == 'list':
            if args.depaginate:
                from . import depaginate
                with depaginate(imdb) as api:
                    items = api.list(args.list)
                    print_ref_list(items)
            elif args.add:
                with modify('Add') as api:
                    api.add_to_list(args.list, args.add)
            elif args.remove:
                with modify('Remove') as api:
                    api.remove_from_list(args.list, args.remove)
            else:
                items = imdb.list(args.list, page=args.page)
                print_ref_list(items)
        elif args.op == 'awards':
            items = imdb.last_oscars_refs(args.awards, page=args.page)
            print_ref_list(items)
        elif args.op:
            print(f'Unknown operation {args.op!r}')
        else:
            print('Missing operation, see --help')
    finally:
        if cookie_server:
            cookie_server.stop()
