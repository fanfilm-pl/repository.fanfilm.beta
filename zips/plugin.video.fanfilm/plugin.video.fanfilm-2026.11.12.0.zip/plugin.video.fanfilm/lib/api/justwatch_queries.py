SUGGESTED_TITLES = """
query GetSuggestedTitles($country: Country!, $language: Language!, $first: Int!, $filter: TitleFilter) {
  popularTitles(country: $country, first: $first, filter: $filter) {
    edges {
      node {
        ...SuggestedTitle
        __typename
      }
      __typename
    }
    __typename
  }
}

fragment SuggestedTitle on MovieOrShow {
  id
  objectType
  objectId
  content(country: $country, language: $language) {
    externalIds {
      imdbId
    }
    fullPath
    title
    originalReleaseYear
    posterUrl
    __typename
  }
  __typename
}
"""

TITLE_OFFERS = """
query GetTitleOffers($nodeId: ID!, $country: Country!, $language: Language!, $filterFlatrate: OfferFilter!, $filterBuy: OfferFilter!, $filterRent: OfferFilter!, $filterFree: OfferFilter!, $platform: Platform! = WEB) {
  node(id: $nodeId) {
    id
    ... on MovieOrShowOrSeasonOrEpisode {
      offerCount(country: $country, platform: $platform)
      flatrate: offers(
        country: $country
        platform: $platform
        filter: $filterFlatrate
      ) {
        ...TitleOffer
        __typename
      }
      buy: offers(country: $country, platform: $platform, filter: $filterBuy) {
        ...TitleOffer
        __typename
      }
      rent: offers(country: $country, platform: $platform, filter: $filterRent) {
        ...TitleOffer
        __typename
      }
      free: offers(country: $country, platform: $platform, filter: $filterFree) {
        ...TitleOffer
        __typename
      }
      __typename
    }
    __typename
  }
}

fragment TitleOffer on Offer {
  id
  presentationType
  monetizationType
  retailPrice(language: $language)
  retailPriceValue
  currency
  lastChangeRetailPriceValue
  type
  package {
    id
    packageId
    clearName
    __typename
  }
  standardWebURL
  elementCount
  availableTo
  deeplinkRoku: deeplinkURL(platform: ROKU_OS)
  audioLanguages
  subtitleLanguages
  __typename
}
"""


URL_TITLE_DETAILS = """
query GetUrlTitleDetails($fullPath: String!, $country: Country!, $language: Language!, $episodeMaxLimit: Int, $platform: Platform! = WEB) {
  url(fullPath: $fullPath) {
    id
    metaDescription
    metaKeywords
    metaRobots
    metaTitle
    heading1
    heading2
    htmlContent
    node {
      id
      ... on MovieOrShowOrSeason {
        objectType
        objectId
        offerCount(country: $country, platform: $platform)
        offers(country: $country, platform: $platform) {
          monetizationType
          package {
            id
            packageId
            __typename
          }
          __typename
        }
        promotedBundles(country: $country, platform: $platform) {
          promotionUrl
          __typename
        }
        availableTo(country: $country, platform: $platform) {
          availableCountDown(country: $country)
          availableToDate
          package {
            id
            shortName
            __typename
          }
          __typename
        }
        fallBackClips: content(country: "US", language: "en") {
          videobusterClips: clips(providers: [VIDEOBUSTER]) {
            externalId
            provider
            __typename
          }
          dailymotionClips: clips(providers: [DAILYMOTION]) {
            externalId
            provider
            __typename
          }
          __typename
        }
        content(country: $country, language: $language) {
          backdrops {
            backdropUrl
            __typename
          }
          clips {
            externalId
            provider
            __typename
          }
          videobusterClips: clips(providers: [VIDEOBUSTER]) {
            externalId
            provider
            __typename
          }
          dailymotionClips: clips(providers: [DAILYMOTION]) {
            externalId
            provider
            __typename
          }
          videobusterClips: clips(providers: [VIDEOBUSTER]) {
            externalId
            __typename
          }
          externalIds {
            imdbId
            __typename
          }
          fullPath
          genres {
            shortName
            __typename
          }
          posterUrl
          runtime
          isReleased
          scoring {
            imdbScore
            imdbVotes
            tmdbPopularity
            tmdbScore
            __typename
          }
          shortDescription
          title
          originalReleaseYear
          originalReleaseDate
          upcomingReleases(releaseTypes: DIGITAL) {
            releaseCountDown(country: $country)
            releaseDate
            label
            package {
              id
              packageId
              shortName
              __typename
            }
            __typename
          }
          ... on MovieOrShowContent {
            originalTitle
            ageCertification
            credits {
              role
              name
              characterName
              personId
              __typename
            }
            productionCountries
            __typename
          }
          ... on SeasonContent {
            seasonNumber
            __typename
          }
          __typename
        }
        __typename
      }
      ... on MovieOrShow {
        watchlistEntry {
          createdAt
          __typename
        }
        likelistEntry {
          createdAt
          __typename
        }
        dislikelistEntry {
          createdAt
          __typename
        }
        customlistEntries {
          createdAt
          genericTitleList {
            id
            __typename
          }
          __typename
        }
        __typename
      }
      ... on Movie {
        permanentAudiences
        seenlistEntry {
          createdAt
          __typename
        }
        __typename
      }
      ... on Show {
        permanentAudiences
        totalSeasonCount
        seenState(country: $country) {
          progress
          seenEpisodeCount
          __typename
        }
        seasons(sortDirection: DESC) {
          id
          objectId
          objectType
          availableTo(country: $country, platform: $platform) {
            availableToDate
            availableCountDown(country: $country)
            package {
              id
              shortName
              __typename
            }
            __typename
          }
          content(country: $country, language: $language) {
            posterUrl
            seasonNumber
            fullPath
            upcomingReleases(releaseTypes: DIGITAL) {
              releaseDate
              releaseCountDown(country: $country)
              package {
                id
                shortName
                __typename
              }
              __typename
            }
            isReleased
            __typename
          }
          show {
            id
            objectId
            objectType
            watchlistEntry {
              createdAt
              __typename
            }
            content(country: $country, language: $language) {
              title
              __typename
            }
            __typename
          }
          __typename
        }
        recentEpisodes: episodes(
          sortDirection: DESC
          limit: 3
          releasedInCountry: $country
        ) {
          id
          objectId
          content(country: $country, language: $language) {
            title
            shortDescription
            episodeNumber
            seasonNumber
            isReleased
            upcomingReleases {
              releaseDate
              label
              __typename
            }
            __typename
          }
          seenlistEntry {
            createdAt
            __typename
          }
          __typename
        }
        __typename
      }
      ... on Season {
        totalEpisodeCount
        episodes(limit: $episodeMaxLimit) {
          id
          objectType
          objectId
          seenlistEntry {
            createdAt
            __typename
          }
          content(country: $country, language: $language) {
            title
            shortDescription
            episodeNumber
            seasonNumber
            isReleased
            upcomingReleases(releaseTypes: DIGITAL) {
              releaseDate
              label
              package {
                id
                packageId
                __typename
              }
              __typename
            }
            __typename
          }
          __typename
        }
        show {
          id
          objectId
          objectType
          totalSeasonCount
          customlistEntries {
            createdAt
            genericTitleList {
              id
              __typename
            }
            __typename
          }
          fallBackClips: content(country: "US", language: "en") {
            videobusterClips: clips(providers: [VIDEOBUSTER]) {
              externalId
              provider
              __typename
            }
            dailymotionClips: clips(providers: [DAILYMOTION]) {
              externalId
              provider
              __typename
            }
            __typename
          }
          content(country: $country, language: $language) {
            title
            ageCertification
            fullPath
            credits {
              role
              name
              characterName
              personId
              __typename
            }
            productionCountries
            externalIds {
              imdbId
              __typename
            }
            upcomingReleases(releaseTypes: DIGITAL) {
              releaseDate
              __typename
            }
            backdrops {
              backdropUrl
              __typename
            }
            posterUrl
            isReleased
            videobusterClips: clips(providers: [VIDEOBUSTER]) {
              externalId
              provider
              __typename
            }
            dailymotionClips: clips(providers: [DAILYMOTION]) {
              externalId
              provider
              __typename
            }
            __typename
          }
          seenState(country: $country) {
            progress
            __typename
          }
          watchlistEntry {
            createdAt
            __typename
          }
          dislikelistEntry {
            createdAt
            __typename
          }
          likelistEntry {
            createdAt
            __typename
          }
          __typename
        }
        seenState(country: $country) {
          progress
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
}
"""

NEW_TITLE_BUCKETS = """
query NewContentVerticalPaginationQuery(
  $after: String
  $allowSponsoredRecommendations: SponsoredRecommendationsInput
  $country: Country!
  $filter: TitleFilter
  $first: Int = 5
  $imageFormat: ImageFormat
  $language: Language!
  $packages: [String!]
  $pageType: NewPageType!
  $platform: Platform!
  $priceDrops: Boolean!
) {
  ...NewContentFragment_2HEEH6
}
fragment NewContentFragment_2HEEH6 on Query {
  newTitleBuckets(after: $after, allowSponsoredRecommendations: $allowSponsoredRecommendations, country: $country, filter: $filter, first: $first, groupBy: DATE_PACKAGE, pageType: $pageType, priceDrops: $priceDrops) {
    edges {
      key {
        __typename
        ... on DatePackageAggregationKey {
          date
          package {
            icon(format: $imageFormat, profile: S50)
            packageId
            shortName
            id
          }
        }
        ... on BucketPackageAggregationKey {
          bucketType
          package {
            icon(format: $imageFormat, profile: S50)
            packageId
            shortName
            id
          }
        }
      }
      node {
        activeCampaign {
          node {
            __typename
            id
            ... on MovieOrShow {
              __isMovieOrShow: __typename
              content(country: $country, language: $language) {
                __typename
                backdrops(format: $imageFormat) {
                  backdropBlurHash
                  backdropUrl
                }
                externalIds {
                  imdbId
                  tmdbId
                }
                fullPath
                originalReleaseYear
                originalTitle
                posterUrl(format: $imageFormat)
                posterBlurHash
                runtime
                scoring {
                  imdbScore
                  imdbVotes
                }
                shortDescription
                title
              }
              dislikelistEntry {
                createdAt
              }
              likelistEntry {
                createdAt
              }
              objectId
              objectType
              watchlistEntry {
                createdAt
              }
            }
          }
          promotionalImageUrl
          watchNowLabel
          watchNowOffer {
            id
            currency
            deeplinkURL(platform: $platform)
            lastChangeRetailPriceValue
            monetizationType
            package {
              icon(format: $imageFormat, profile: S100)
              id
              clearName
              packageId
              shortName
            }
            presentationType
            retailPriceValue
            standardWebURL
          }
        }
        edges {
          newOffer(platform: $platform) {
            currency
            deeplinkURL(platform: $platform)
            lastChangePercent
            lastChangeRetailPrice(language: $language)
            lastChangeRetailPriceValue
            monetizationType
            newElementCount
            package {
              icon(format: $imageFormat, profile: S50)
              clearName
              packageId
              shortName
              id
            }
            presentationType
            retailPrice(language: $language)
            retailPriceValue
            standardWebURL
            id
          }
          node {
            __typename
            availableTo(country: $country, platform: $platform, packages: $packages) {
              availableCountDown(country: $country)
              availableToDate
            }
            content(country: $country, language: $language) {
              __typename
              backdrops(format: $imageFormat) {
                backdropBlurHash
                backdropUrl
              }
              externalIds {
                imdbId
                tmdbId
              }
              fullPath
              originalReleaseYear
              posterBlurHash
              posterUrl(format: $imageFormat)
              runtime
              scoring {
                imdbScore
                imdbVotes
              }
              shortDescription
              title
              upcomingReleases {
                releaseDate
                releaseType
                releaseCountDown(country: $country)
              }
            }
            id
            objectId
            objectType
            ... on Season {
              seasonContent: content(country: $country, language: $language) {
                seasonNumber
                title
              }
              seenState(country: $country) {
                caughtUp
                progress
              }
              show {
                dislikelistEntry {
                  createdAt
                }
                likelistEntry {
                  createdAt
                }
                showContent: content(country: $country, language: $language) {
                  showAgeCertification: ageCertification
                  showBackdrops: backdrops(format: $imageFormat) {
                    backdropBlurHash
                    backdropUrl
                  }
                  showDescription: shortDescription
                  showExternalIds: externalIds {
                    imdbId
                    tmdbId
                  }
                  showOriginalTitle: originalTitle
                  showTitle: title
                }
                showId: id
                showObjectId: objectId
                showObjectType: objectType
                watchlistEntry {
                  createdAt
                }
                id
              }
            }
            ... on Movie {
              titleContent: content(country: $country, language: $language) {
                ageCertification
                originalTitle
              }
              dislikelistEntry {
                createdAt
              }
              likelistEntry {
                createdAt
              }
              seenlistEntry {
                createdAt
              }
              watchlistEntry {
                createdAt
              }
            }
          }
        }
        pageInfo {
          endCursor
          hasNextPage
        }
        totalCount
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
"""

# --- The lists of the user, checked on the test account 2026-10-12 (`notes/services/justwatch.md`) ---

#: A new device ID (no authorization), required with the login ID.
NEW_DEVICE_ID = """
mutation GetNewDeviceId($i: GetNewDeviceIdInput!) {
  getNewDeviceId(input: $i) { deviceId }
}
"""

#: The account: its role and the limits of own lists.
USER_STATS = """
query Stats {
  stats { userRole hasJWProSubscription maxCustomListsDefault maxCustomListsPro }
}
"""

#: The fields of a title on a list (its node and the external IDs).
_LIST_TITLE = """
        id objectType objectId
        content(country: $c, language: $lang) { title originalReleaseYear externalIds { imdbId tmdbId } }
"""

#: The next part of a list (the cursor of `after`).
_PAGE_INFO = """
    pageInfo { hasNextPage endCursor }
"""


def _title_list(list_type: str, entry: str) -> str:
    """Return the query of a system list of the user (`TitleListTypeV2`), newest first, with its `entry` field of a title."""
    return """
query TitleList($c: Country!, $lang: Language!, $first: Int!, $after: String) {
  titleListV2(country: $c, titleListType: """ + list_type + """, first: $first, after: $after, sortBy: LAST_ADDED) {
    totalCount""" + _PAGE_INFO + """    edges { node {""" + _LIST_TITLE + """        """ + entry + """
    } }
  }
}
"""


#: The watchlist (movies and shows).
WATCHLIST = _title_list('WATCHLIST', 'watchlistEntryV2 { createdAt }')

#: The liked titles (movies and shows), the favorites of FanFilm.
LIKELIST = _title_list('LIKELIST', 'likelistEntry { createdAt }')

#: The seen titles: movies (with the date they were marked) and shows with all episodes seen (no date).
SEENLIST = _title_list('SEENLIST', '... on Movie { seenlistEntry { createdAt } }')

#: The tracked shows in progress (`CONTINUE_WATCHING`: some episodes seen) with their next released episode, the latest
#: tracked first (the service does not sort by the last seen). Tracking is a list of its own (`setInTvShowTracking`, not
#: the watchlist). The other views are not read: `NOT_STARTED` (tracked, nothing seen: no progress) and `CAUGHT_UP`
#: (all released episodes seen: no next episode); a show fully seen and ended is in no view.
TRACKING = """
query Tracking($c: Country!, $lang: Language!, $first: Int!, $after: String) {
  tvShowTracking(country: $c, viewType: CONTINUE_WATCHING, first: $first, after: $after, sortBy: LAST_ADDED) {
    totalCount""" + _PAGE_INFO + """    edges { node {""" + _LIST_TITLE + """        ... on Show { watchNextEpisode(country: $c) { content(country: $c, language: $lang) { seasonNumber episodeNumber } } }
    } }
  }
}
"""

#: Add to / remove from the watchlist: `$i = {id, state}`.
SET_IN_WATCHLIST = """
mutation SetInWatchlist($i: SetInTitleListInput!) {
  setInWatchlistV2(input: $i) { title { id } }
}
"""

#: Like / no more like a title (the favorites): `$i = {id, state}`.
SET_IN_LIKELIST = """
mutation SetInLikelist($i: SetInTitleListInput!) {
  setInLikelist(input: $i) { title { id } }
}
"""

#: Own lists of the user.
CUSTOM_LISTS = """
query CustomLists($c: Country!, $lang: Language!, $first: Int!, $after: String) {
  genericTitleLists(type: CUSTOM_LISTS, first: $first, after: $after) {
    totalCount
    edges { node { id type visibility content(country: $c, language: $lang) { name ownedByUser } titles(country: $c) { totalCount } } }
  }
}
"""

#: The titles of an own list.
CUSTOM_LIST = """
query CustomList($l: ID!, $c: Country!, $lang: Language!, $first: Int!, $after: String) {
  genericTitleList(id: $l, country: $c, first: $first, after: $after, sortBy: POPULAR) {
    totalCount""" + _PAGE_INFO + """    edges { node {""" + _LIST_TITLE + """
        ... on MovieOrShow { customlistEntries { createdAt genericTitleList { id } } }
    } }
  }
}
"""

#: Fingerprints of the lists of the account (`JustWatchAccount.sync_activities()`, no activities in JustWatch): the count
#: and the newest title of the watchlist, the liked and the seen titles, each own list - in one request.
SYNC = """
query Sync($c: Country!) {
  watchlist: titleListV2(country: $c, titleListType: WATCHLIST, first: 1, sortBy: LAST_ADDED) {
    totalCount edges { node { id ... on MovieOrShow { watchlistEntryV2 { createdAt } } } }
  }
  liked: titleListV2(country: $c, titleListType: LIKELIST, first: 1, sortBy: LAST_ADDED) {
    totalCount edges { node { id ... on MovieOrShow { likelistEntry { createdAt } } } }
  }
  seen: titleListV2(country: $c, titleListType: SEENLIST, first: 1, sortBy: LAST_ADDED) {
    totalCount edges { node { id ... on Movie { seenlistEntry { createdAt } } } }
  }
  lists: genericTitleLists(type: CUSTOM_LISTS, first: 100) {
    totalCount
    edges { node { id titles(country: $c, first: 1, sortBy: LAST_ADDED) {
      totalCount edges { node { id ... on MovieOrShow { customlistEntries { createdAt genericTitleList { id } } } } }
    } } }
  }
}
"""

#: A new own list: `$i = {name, visibility: UNLISTED}` (the only visibility the service supports).
CREATE_CUSTOM_LIST = """
mutation CreateCustomlist($i: CreateCustomlistInput!) {
  createCustomlist(input: $i) { titleList { id } }
}
"""

#: Rename an own list: `$i = {id, name}`.
UPDATE_CUSTOM_LIST = """
mutation UpdateCustomlist($i: UpdateCustomlistInput!) {
  updateCustomlist(input: $i) { titleList { id } }
}
"""

#: Delete an own list (with its titles): `$i = {id}`.
DELETE_CUSTOM_LIST = """
mutation DeleteCustomlist($i: DeleteCustomlistInput!) {
  deleteCustomlist(input: $i) { id }
}
"""

#: Add to / remove from an own list: `$i = {id, state, listId}`.
SET_IN_CUSTOM_LIST = """
mutation SetInCustomlist($i: SetInCustomlistInput!) {
  setInCustomlist(input: $i) { title { id } }
}
"""

#: The node of a movie / show by its path, with its external IDs (the check of a found title, light).
NODE_BY_PATH = """
query NodeByPath($path: String!, $c: Country!, $lang: Language!) {
  url(fullPath: $path) { node { id ... on MovieOrShow { objectType content(country: $c, language: $lang) { externalIds { imdbId tmdbId } } } } }
}
"""

# The VOD services (packages) of a country (the choice of the VOD services of the user).
PACKAGES = """
query GetPackages($country: Country!, $platform: Platform!) {
  packages(country: $country, platform: $platform, includeAddons: false) { shortName clearName }
}
"""
