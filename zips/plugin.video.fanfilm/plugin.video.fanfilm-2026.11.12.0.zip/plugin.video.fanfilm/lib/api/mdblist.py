
from __future__ import annotations
from typing import Sequence, TypeVar, TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired, Literal
from itertools import chain
from wrapt import ObjectProxy  # wrapt 2.x: wrappers.ObjectProxy (BaseObjectProxy) has no __iter__
from . import ALL_PAGES
from ..ff import requests
from ..ff import apis
from ..ff.types import JsonResult, JsonData, SequenceProto
from ..defs import MediaRef, VideoIds, MainMediaType, MediaType, RefType, ItemList, Pagina
from ..ff.item import FFItem, ListEntry
from ..ff.kotools import xsleep
from ..ff.listcache import FetchedList, cached_list, list_params, mark_stale
from ..ff.sync import cursor_time
from ..ff.db.playback import MediaPlayInfo, update_track_playback, update_track_watched_movies, update_track_watched_episodes
from ..ff.calendar import utc_timestamp, utc_2_iso
from ..ff.accounts import Account, AccountClient, DeviceAuth, NotDelivered, all_found, failed_request, limited_until, set_limited
from ..ff.ratings import RatingScale, pick_ratings
from ..ff.logs import fflog, log
from ..ff.url import URL
from ..kolang import L
from cdefs import ListSection, ListType
from const import const, CONST_REF
if TYPE_CHECKING:
    from typing import Any, Iterator, Iterable, ClassVar, Mapping
    from typing_extensions import Unpack
    from ..ff.types import KwArgs, PagedItems
    from ..ff.sync import SyncBucket
    from ..defs import FFRef


#: MdbList list ID, direct if int ot user/name if str (for user lists).
LIST_ID = TypeVar('LIST_ID', bound='int | str')

MediaProvider = Literal['tmdb', 'trakt', 'mdblist', 'imdb', 'mal', 'tvdb']
#: Scrobble action (`scrobble/<action>`).
ScrobbleAction = Literal['start', 'pause', 'stop']

#: Sync buckets (FF bucket -> keys of `sync/last_activities`, the newest one is the cursor), see `lib.ff.sync`.
#: A watched item or a rating removed on mdblist.com changes only `journal_at`, so the watched and rating buckets watch it too.
SYNC_BUCKETS: dict[SyncBucket, tuple[str, ...]] = {
    'progress.movie': ('paused_at',),
    'progress.episode': ('episode_paused_at',),
    'watched.movie': ('watched_at', 'journal_at'),
    'watched.episode': ('episode_watched_at', 'season_watched_at', 'journal_at'),
    'lists.watchlist': ('watchlisted_at',),
    'lists.collection': ('collected_at',),
    'lists.user': ('list_updated_at',),
    'ratings': ('rated_at', 'journal_at'),
}

#: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
SYNC_LISTS: dict[SyncBucket, str] = {
    'lists.watchlist': 'watchlist',
    'lists.collection': 'collection',
    'lists.user': 'user',
    'ratings': 'rated',
}

#: IDs kept in the playback rows.
PLAY_IDS: tuple[str, ...] = ('tmdb', 'imdb', 'trakt', 'tvdb')

#: The parameters of the requests of lists of lists: the posters of their first items (the image of a list).
LISTS_PARAMS: KwArgs = {'append_to_response': 'poster'}


def iso_timestamp(value: str | None) -> int | None:
    """Return the unix timestamp of an ISO time of mdblist.com, None if not given."""
    return int(utc_timestamp(value)) if value else None


def play_info(it: JsonData, **kwargs: Any) -> MediaPlayInfo | None:
    """Return the playback row of a sync item of mdblist.com (`movie` or `episode` with its `show`), None without IDs."""
    if (movie := it.get('movie')) is not None:
        ids = movie.get('ids') or {}
        if not (ffid := VideoIds.from_ids(ids).ffid):
            return None
        ref = MediaRef.movie(ffid)
    elif (ep := it.get('episode')) is not None:
        ids = (it.get('show') or ep.get('show') or {}).get('ids') or {}  # sync/playback: a sibling, sync/watched: nested
        if not (ffid := VideoIds.from_ids(ids).ffid):
            return None
        ref = MediaRef.tvshow(ffid, ep['season'], ep['number'])
        ids = {}  # the IDs of the show are not the episode ones
    else:
        return None
    runtime = it.get('runtime') or (movie or {}).get('runtime')
    return MediaPlayInfo(ref=ref, duration=60 * int(runtime) if runtime else None, **{k: v for k in PLAY_IDS if (v := ids.get(k))}, **kwargs)


class MdblistIds(TypedDict):
    imdb: str
    tmdb: int
    trakt: int
    tvdb: int | None
    mal: int | None
    mdblist: str


class MdblistRequestKwargs(TypedDict):
    params: NotRequired[KwArgs | None]
    page: NotRequired[int | None]  # it is translated to `offset`, used if offset is not set
    offset: NotRequired[int | None]
    limit: NotRequired[int | None]
    errors: NotRequired[str]
    login_required: NotRequired[bool]


class MdblistRespPagination(TypedDict):
    page: int
    limit: int
    total_movies: int
    total_shows: int
    has_more: bool


if TYPE_CHECKING:
    # class PagesBase(ObjectProxy, JsonData, Sequence[JsonData]):
    from typing_extensions import Generic
    B = TypeVar('B', bound=JsonData | Sequence[JsonData])

    class PagesBase(ObjectProxy, Generic[B]):
        pass
else:
    PagesBase = ObjectProxy


class Pages(PagesBase):
    """A proxy class to handle pagination for mdblist.com API responses."""

    limit: int
    total_movies: int
    total_shows: int

    def __init__(self,
                 obj: JsonResult,
                 /, *,
                 total_items: int = 0,
                 has_more: bool | None = None,
                 limit: int | None = None,
                 offset: int | None = None,
                 results: str | None = None,
                 status_code: int = 200,
                 ) -> None:
        data = obj.get(results) if results and isinstance(obj, dict) else obj
        super().__init__(data)
        self._self_pagination: MdblistRespPagination | None
        if isinstance(obj, dict) and (pagination := obj.get('pagination')):
            self._self_pagination = pagination
        else:
            self._self_pagination = None
        if not limit and isinstance(obj, Sequence):
            end = (offset or 0) + len(obj)
            # has more items, then current page is full, so limit is page size
            if has_more or end < total_items:
                limit = len(obj)
            else:
                limit = 100  # default page size for mdblist.com API
        self._self_total_items = total_items
        self._self_has_more = has_more
        self._self_limit = limit
        self._self_offset = offset
        self._self_status_code = status_code

    def __repr__(self) -> str:
        return f'Pages({self.__wrapped__!r}, total_items={self._self_total_items})'

    @property
    def status_code(self) -> int:
        """HTTP status code of the response."""
        return self._self_status_code

    @property
    def total_items(self) -> int:
        """Total number of items in the response."""
        return self._self_total_items

    @property
    def has_more(self) -> bool:
        """Has more pages."""
        if self._self_has_more is not None:
            return self._self_has_more
        if self._self_pagination:
            return bool(self._self_pagination.get('has_more', False))
        if self._self_total_items and isinstance(self.__wrapped__, Sequence):
            return (self._self_offset or 0) + len(self.__wrapped__) < self._self_total_items
        return False

    @property
    def page(self) -> int:
        """Current page number (1-based)."""
        if self._self_pagination is not None:
            return self._self_pagination.get('page', 0)
        if self._self_limit:
            return (self._self_offset or 0) // self._self_limit + 1
        return 1

    @property
    def total_pages(self) -> int:
        """Total number of pages."""
        if self._self_pagination is not None:
            total_items = self._self_pagination.get('total_movies', 0) + self._self_pagination.get('total_shows', 0)
            limit = self._self_pagination.get('limit', 0)
            if limit:
                return (total_items + limit - 1) // limit
        if self._self_limit:
            return (self._self_total_items + self._self_limit - 1) // self._self_limit
        return 1

    def __getattr__(self, key: str) -> int:
        if key == 'limit' and self._self_limit is not None:
            return self._self_limit
        if key == 'offset' and self._self_offset is not None:
            return self._self_offset
        if self._self_pagination:
            if key in ('has_more',):
                return bool(self._self_pagination.get(key, False))
            try:
                return self._self_pagination[key]
            except KeyError:
                if key in ('page', 'total_movies', 'total_shows'):
                    return 0
        try:
            return super().__getattr__(key)
        except AttributeError:
            raise AttributeError(f'Pages (type of {type(self.__wrapped__)}) object has no attribute {key!r}') from None

    @classmethod
    def empty(cls) -> Pages:
        """Create an empty Pages object."""
        return cls([], total_items=0, has_more=False, limit=0, offset=0)


class MdbList(DeviceAuth, AccountClient):
    """A class to handle the mdblist.com API."""

    # TODO: add general pagination support for mdblist. Now limit is 1000 items.

    #: Maximum number of items to return in a single request (mdblist.com API limit).
    LIMIT: ClassVar[int] = 1000
    #: Sync buckets of the account (`lib.ff.sync`).
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = SYNC_BUCKETS
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = SYNC_LISTS
    #: Sync interval (the common one of the service loop).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.interval
    #: Items of a batch history write (the service takes up to 200 shows a call).
    BATCH_LIMIT: ClassVar[int] = 200
    #: Sections of lists of the account (the collection: movies and shows; new lists: static ones).
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'watchlist': ListSection(types=ListType.MAIN),
        'collection': ListSection(types=ListType.MAIN),
        'user': ListSection(types=ListType.MEDIA, create={'public': True}),
    }
    #: Rating scale of the account.
    RATING: ClassVar[RatingScale | None] = RatingScale(type=int, min=1, max=10, step=1, media=('movie', 'show', 'season', 'episode'))

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        # The account of the client: given, the first MDBList account (alias), or the application client (none):
        # the first active signed in account.
        super().__init__(account, alias=alias)
        self.url = 'https://api.mdblist.com/'
        #: Connection session.
        self.sess: requests.Session = requests.Session()
    @staticmethod
    def signed_in(account: Account) -> str:
        """Return the credentials of the account: the API key of the developers (`const.dev.mdblist.api_key`) or the refresh token ('' - none)."""
        from ..ff.db.accounts import account_data_store
        return const.dev.mdblist.api_key or str((account_data_store(account.id).get('token') or {}).get('refresh_token') or '')

    @property
    def account(self) -> Account | None:
        """Return the account of the client (the application client: the first active signed in account, now)."""
        if self._account is not None or self._alias:
            return super().account
        from ..ff.accounts import accounts
        return next((acc for acc in accounts() if acc.type.name == 'mdblist' and acc.active and self.signed_in(acc)), None)

    @property
    def api_key(self) -> str:
        """Return the API key of the developers (`const.dev.mdblist.api_key`, read at use), '' - none (a token is used)."""
        return const.dev.mdblist.api_key or ''

    def credentials(self) -> str:
        """Return the credentials of the account (see `signed_in()`, '' - none), see `AccountStore.auth_state()`."""
        from ..ff.accounts import type_enabled
        return self.signed_in(account) if (account := self.account) is not None and type_enabled('mdblist') else ''

    @property
    def _store(self) -> Any:
        """Return the data of the account (`accounts.db`)."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.scope)

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists and of the account state: the account ID."""
        return 'mdblist' if (account := self.account) is None else account.id

    def is_enabled(self) -> bool:
        """Check if the mdblist.com API is enabled."""
        return const.indexer.mdblist.enabled and bool(self.credentials())

    @staticmethod
    def _list_id(list_id: LIST_ID) -> LIST_ID:
        if isinstance(list_id, str) and list_id.isdecimal():
            list_id = int(list_id)  # type: ignore[assignment]  # an ID from a route
        if isinstance(list_id, int) and list_id in VideoIds.MDBLIST:
            list_id = VideoIds.MDBLIST.index(list_id)  # convert to real list ID
        return list_id

    def request(self,
                method: str,
                url: str,
                *,
                data: JsonData | None = None,
                params: KwArgs | None = None,
                page: int | None = None,  # not API parameter, is translated to `offset`, used if offset is not set
                offset: int | None = None,
                limit: int | None = None,
                errors: str = 'ignore',
                login_required: bool = True,
                ) -> requests.Response | None:
        """Make a request to the mdblist.com API."""
        if '://' not in url:
            url = f'{self.url}{url.lstrip("/")}'
        headers: dict[str, str] | None = None
        params = dict(params or ())
        api_key = self.api_key
        if login_required:
            if api_key:  # the developers
                params['apikey'] = api_key
            elif token := self._access_token():
                headers = {'Authorization': f'Bearer {token}'}
        if limit is not None:
            params['limit'] = limit
        if offset is not None:
            params['offset'] = offset
        elif page is not None:
            params['offset'] = (page - 1) * (limit or self.LIMIT)
        if login_required and (until := limited_until(self.scope)):
            fflog(f'[MDBLIST] {method} {url}: the daily request limit is reached until {until}, not sent')
            failed_request(429)
            return None
        status_code: int = 0
        resp = None
        refreshed = False
        conn = const.mdblist.connection  # one read: one const for the whole request
        for i in range(conn.try_count):
            # make the request
            resp_headers = {}
            try:
                resp = self.sess.request(method, url, json=data, params=params, headers=headers, timeout=conn.timeout)
                status_code = resp.status_code
                resp_headers = {k: v for k, v in resp.headers.items()}# if 'sort-' in k.lower()}
            except requests.ConnectionError:
                status_code = 0
            except requests.RequestException:
                if errors == 'ignore':
                    status_code = 0
                else:
                    raise
            finally:
                # fflog(f'[MDBLIST] {method} {url} ? {params} < {data!r}  (try: {i+1}) → {status_code}\n  {cred}')
                fflog(f'[MDBLIST] {method} {url} ? {params} < {data!r}  (try: {i+1}) → {status_code}, cred:{bool(api_key or headers)}')
                fflog(f'[MDBLIST]  …  {resp_headers=}')
                self._note_budget(resp_headers)

            # analyze response
            try_delay = 0
            # with self.auth_lock:
            if 1:
                if status_code == 401 and headers and not refreshed and self.refresh_token():
                    refreshed = True  # an access token revoked / expired before its time: one more try with a new one
                    headers = {'Authorization': f'Bearer {self._access_token()}'}
                    continue
                if status_code == 429 and login_required and resp_headers.get('x-ratelimit-remaining') == '0':
                    # the daily budget of the account is used up: no retry until its reset
                    from time import time
                    set_limited(self.scope, int(resp_headers.get('x-ratelimit-reset') or 0) or int(time()) + 86400,
                                label=self.account.label if self.account is not None else 'MDBList')
                    break
                if status_code in (0, 429):  # Connection Error | Rate Limit Exceeded
                    # See: https://trakt.docs.apiary.io/#introduction/rate-limiting
                    fflog(f'[MDBLIST] Rate limit exceeded {status_code}')
                    try_delay = conn.try_delay
                    # TODO, handle response headers
                    # X-Ratelimit: {"name":"UNAUTHED_API_GET_LIMIT","period":300,"limit":1000,"remaining":0,
                    #               "until":"2020-10-10T00:24:00Z"}
                    # Retry-After: 10
                    # x-ratelimit-reset: 1773705600
                    # x-ratelimit-remaining: 99992
                elif status_code == 420:  # If the user's list item limit is exceeded, a 420 HTTP error code is returned
                    log('MdbList list limit exceeded')
                    break
                elif status_code == 502:  # Gateway Error - mdblist.com is not avaliable
                    try_delay = 3 * conn.try_delay
                else:
                    # rest: success or error, stop repeating
                    break
            if try_delay:
                xsleep(try_delay)

        if resp is None:
            failed_request(status_code)
            return None

        # 200: Success
        # 201: Success - new resource created (POST)
        # 204: Success - no content to return (DELETE)
        if 200 <= status_code <= 299:
            return resp

        if status_code >= 500:  # temporary
            fflog(f'[MDBLIST] Temporary error {resp.status_code}')
            failed_request(status_code)
            return None
        if status_code >= 400:  # permanent
            fflog(f'[MDBLIST] Error {resp.status_code}\n{resp.text}')
            failed_request(status_code)
            return None

    # --- Authorization (`DeviceAuth`; the OAuth paths need the trailing slash) ---

    def _oauth(self, path: str, form: dict[str, str]) -> requests.Response | None:
        """Post a form to an OAuth endpoint (no credentials, no retry), None on no connection."""
        try:
            return self.sess.post(f'{self.url}oauth/{path}', data={'client_id': apis.mdblist_API, **form}, timeout=const.mdblist.connection.timeout)  # type: ignore[attr-defined]
        except requests.RequestException as exc:
            fflog(f'[MDBLIST] oauth/{path}: {exc}')
            return None

    def _device_code(self) -> requests.Response | None:
        """Ask for a device code."""
        return self._oauth('device-authorization/', {'scope': 'write'})

    def _poll_token(self, device_code: str) -> requests.Response | None:
        """Ask for the token of the device code."""
        return self._oauth('token/', {'grant_type': 'urn:ietf:params:oauth:grant-type:device_code', 'device_code': device_code})

    def _refresh_request(self, refresh: str) -> requests.Response | None:
        """Exchange the refresh token for a new pair."""
        return self._oauth('token/', {'grant_type': 'refresh_token', 'refresh_token': refresh})

    def _revoke_token(self, token: Mapping[str, Any]) -> None:
        """Revoke the token in mdblist.com."""
        self._oauth('revoke_token/', {'token': token['refresh_token'], 'token_type_hint': 'refresh_token'})

    @staticmethod
    def _verification_url(code: Mapping[str, Any]) -> str:
        """Return the link of the device code with the code filled in (the user only confirms)."""
        return str(code.get('verification_uri_complete') or f"{code.get('verification_uri') or 'https://mdblist.com/oauth/device/'}?user_code={code['user_code']}")

    @staticmethod
    def _auth_title() -> str:
        """Return the title of the sign-in window."""
        return L(30330, '[B]Authorize MDBList[/B]')

    @staticmethod
    def _refresh_before() -> float:
        """Return the seconds before the end of the access token when it is refreshed."""
        return const.mdblist.auth.refresh_before

    def _note_budget(self, headers: dict[str, str]) -> None:
        """Keep the daily request budget of the account from `x-ratelimit-*` (the account state, until the reset), log it."""
        if (remaining := headers.get('x-ratelimit-remaining')) is None:
            return
        from time import time
        from ..ff.db.accounts import account_data_store
        try:
            budget = {'limit': int(headers.get('x-ratelimit-limit') or 0), 'remaining': int(remaining),
                      'reset': int(headers.get('x-ratelimit-reset') or 0)}
        except ValueError:
            return
        ttl = max(60, budget['reset'] - int(time())) if budget['reset'] else 86400
        account_data_store(self.scope).set('budget', budget, ttl=ttl)
        fflog(f'[MDBLIST] {self.scope}: budget {budget["remaining"]} / {budget["limit"]}')

    def _response(self, resp: requests.Response | None, *, results: str | None = None) -> Pages | None:
        """Process the response from the mdblist.com API."""
        if resp is None:
            return None
        url = URL(resp.request.url) if resp.request.url else None
        data = resp.json()
        # x-has-more: true
        # x-total-items: 3
        # x-matched-items: 1
        # x-ratelimit-limit: 100000
        # x-ratelimit-remaining: 99992
        # x-ratelimit-reset: 1773705600

        def req_int_param(name: str) -> int | None:
            if url is not None and url.args.get(name):
                try:
                    return int(url.args[name])
                except ValueError:
                    pass
            return None

        limit = req_int_param('limit')
        offset = req_int_param('offset')
        total_items = int(resp.headers.get('X-Total-Items') or 0)
        # the header is 'true' / 'false', none: `total_items` decides
        has_more = None if (more := resp.headers.get('X-Has-More')) is None else more.lower() == 'true'
        return Pages(data, results=results, total_items=total_items, has_more=has_more, limit=limit, offset=offset,
                     status_code=resp.status_code)

    def get(self, url: str, *, results: str | None = None, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:
        """Send GET request to mdblist.com and return JSON."""
        resp = self.request('GET', url, data=None, **kwargs)
        return self._response(resp, results=results)

    # def post(self, url: str, data: JsonData, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:
    #     """Send POST request to mdblist.com and return JSON."""
    #     resp = self.request('POST', url, data=data, **kwargs)
    #     return self._response(resp)

    # def put(self, url: str, data: JsonData, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:
    #     """Send PUT request to mdblist.com and return JSON."""
    #     resp = self.request('PUT', url, data=data, **kwargs)
    #     return self._response(resp)

    def post(self, url: str, data: JsonData | None, *, results: str | None = None, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:
        """Send POST request to mdblist.com and return JSON."""
        resp = self.request('POST', url, data=data, **kwargs)
        return self._response(resp, results=results)

    def put(self, url: str, data: JsonData | None, *, results: str | None = None, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:
        """Send PUT request to mdblist.com and return JSON."""
        resp = self.request('PUT', url, data=data, **kwargs)
        return self._response(resp, results=results)

    def delete(self, url: str, *, results: str | None = None, **kwargs: Unpack[MdblistRequestKwargs]) -> Pages | None:  # -> bool:
        """Send DELETE request to mdblist.com and return True if deleted."""
        resp = self.request('DELETE', url, data=None, **kwargs)
        # return resp.status_code == 204 if resp else False
        return self._response(resp, results=results)

    def _parse_lists(self, data: Pages | None, *, media: MainMediaType | None = None, static: bool = False) -> ItemList[FFItem]:
        """Parse list of the list from JSON data."""
        from ..ff.theme import art
        from ..ff.art import tmdb_list_art

        def parse(it: JsonData) -> Iterator[FFItem]:
            """Parse a single item."""
            # NOTE: 'mediatype' is always null for static lists (see: https://discord.com/channels/907169977159786516/1377060272698560662)
            media_type = it.get('mediatype')
            if media and media_type and media_type != media:
                return
            if static and it.get('dynamic'):
                return
            ref = MediaRef('list', it['id'] + VideoIds.MDBLIST.start)
            ff = FFItem(ref)
            ff.source_data = it
            ff.label = ff.title = it['name']
            if descr := it.get('description'):
                # ff.vtag.setTagLine(descr)
                ff.vtag.setPlot(descr)
            ff._children_count = it['items']
            if it.get('dynamic'):  # items of a dynamic list come from its filters
                ff.setProperty('list_readonly', 'true')
            # 'dynamic'
            # 'private'
            role = []
            info = []
            if item_count := it.get('items'):
                if media != media_type and media_type == 'movie':
                    info.append(L(30888, '{n} movie|||{n} movies', n=item_count))
                    ff.setArt({'icon': art('movies/main.png')})
                elif media != media_type and media_type == 'show':
                    info.append(L(30389, '{n} show|||{n} shows', n=item_count))
                    ff.setArt({'icon': art('tvshows/main.png')})
                else:
                    info.append(L(30695, '{n} item|||{n} items', n=item_count))
                role.append(f'{item_count}')
            if (posters := it.get('poster')) and isinstance(posters, list) and isinstance(poster := posters[0], str):
                # the TMDB posters of its first items (`…/t/p/w200/<file>`): the first one in the size of a poster
                ff.setArt({**ff.getArt(), **tmdb_list_art({'poster_path': '/' + poster.rpartition('/')[2]})})
            if user_name := it.get('user_name'):
                info.append(L(32932, 'by {user}').format(user=user_name))
            if likes := it.get('likes'):
                info.append(L(30696, '{n} like|||{n} likes', n=likes))
                ff.setRating('likes', likes, likes, True)
            if it.get('dynamic'):
                info.append(L(30697, 'Dynamic List'))
            if role:
                ff.role = ', '.join(role)
            if info:
                ff.vtag.setTagLine(', '.join(info))
                # ff.vtag.setTagLine('[CR]\n'.join(s for s in [', '.join(info), ff.vtag.getTagLine()] if s))
            # ff.vtag.setPlot(ff.vtag.getTagLine())
            if val := it.get('user_id'):
                ff.setProperty('mdblist.user_id', val)
            if val := it.get('user_name'):
                ff.setProperty('mdblist.user_name', val)
            if (val := it.get('liked')) is not None:
                ff.setProperty('mdblist.liked', str(bool(val)).lower())
                if val:
                    ff.setProperty('mdblist.liked_at', str(it.get('liked_at') or ''))
            yield ff

        # if not isinstance(data, Sequence):
        if not isinstance(data, list):
            return ItemList[FFItem].empty()
        return ItemList((ff for it in data for ff in parse(it)), page=data.page, page_size=data.limit,
                        total_pages=data.total_pages, total_results=data.total_items)

    def _get_ref(self, it: JsonData, ref_type: RefType | None = None) -> Iterator[MediaRef]:
        if 'movie' in it:
            yield VideoIds.from_ids(it['movie']['ids']).ref('movie')
        elif 'episode' in it:
            d = it['episode']
            vid = VideoIds.from_ids(d['show']['ids'])
            yield MediaRef('show', vid.ffid, season=d['season'], episode=d['number'])
        elif 'season' in it:
            d = it['season']
            vid = VideoIds.from_ids(d['show']['ids'])
            yield MediaRef('show', vid.ffid, season=d['number'])
        elif 'show' in it:
            yield VideoIds.from_ids(it['show']['ids']).ref('show')
        elif 'list' in it:
            yield VideoIds.from_ids(it['list']['ids']).ref('list')
        elif ref_type is not None:
            iid = it.get('ids', {}).get('trakt')
            if iid:
                yield MediaRef(ref_type, iid)

    def _parse_items(self, data: Pages | None, *, media: MediaType | None = None, page: int = 1, page_size: int | None = None) -> ItemList[FFItem]:
        """Parse list items from JSON data."""
        def parse(it: JsonData) -> FFItem | None:
            """Parse a single item."""
            season = episode = None
            if iid := it.get('id'):
                media: Literal['movie', 'show', 'season', 'episode'] = it['mediatype']
                if media == 'season':
                    iid = it['show_id']
                    season = it['season_number']
                    media = 'show'
                elif media == 'episode':
                    iid = it['show_id']
                    season = it['season_number']
                    episode = it['episode_number']
                    media = 'show'
                ref = MediaRef.from_tmdb(media, iid, season=season, episode=episode)
                ff = FFItem(ref)
                ff.source_data = it
                ff.label = ff.title = it['title']
                if year := it.get('release_year'):
                    ff.vtag.setYear(year)
                for uid in ('tmdb', 'tvdb'):
                    if val := it.get(f'{uid}_id'):
                        ff.vtag.setUniqueID(str(val), uid)
                ff.list_entry = self._list_entry(it)
                return ff
            else:
                for ref in self._get_ref(it):
                    ff = FFItem(ref)
                    vtag = ff.vtag
                    info = it.get(ref.real_type, {})
                    ids = info.get('ids', {})
                    for key in ('tmdb', 'imdb', 'trakt', 'mdblist'):
                        if val := ids.get(key):
                            ff.vtag.setUniqueID(str(val), key)
                    if title := info.get('title'):
                        ff.label = ff.title = title
                    if year := info.get('year'):
                        vtag.setYear(year)
                    if show_info := info.get('show'):
                        if title := show_info.get('title'):
                            vtag.setTvShowTitle(title)
                        if year := show_info.get('year'):
                            ff.setProperty('show.year', str(year))
                    if rating := it.get('rating'):
                        ff.setProperty('user_rating', str(rating))
                        ff.setProperty('mdblist.user_rating', str(rating))
                    ff.list_entry = self._list_entry(it)
                    return ff
                return None

        def rank(it: FFItem) -> int:
            """Return the rank of the item in its list (0 if none: the order of the service)."""
            return (it.list_entry.rank or 0) if it.list_entry else 0

        if data is None:
            return ItemList.empty()
        if not page_size:
            page_size = data.limit or const.indexer.mdblist.page_size
        if isinstance(data, dict):  # Mapping
            items = []
            for mtype in ('movie', 'show', 'season', 'episode'):
                if not media or media == mtype:
                    items.extend((ff for it in data.get(f'{mtype}s', ()) if (ff := parse(it)) is not None))
            items.sort(key=rank)
            total = data.total_items
            return ItemList(items, page=page, page_size=page_size, total_pages=(total + page_size - 1) // page_size, total_results=total)
        elif isinstance(data, list):  # Sequence
            items = sorted((ff for it in data if (not media or it['mediatype'] == media) and (ff := parse(it)) is not None), key=rank)
            total = data.total_items
            return ItemList(items, page=page, page_size=page_size, total_pages=(total + page_size - 1) // page_size, total_results=total)
        return ItemList.empty()

    @staticmethod
    def _list_entry(it: JsonData) -> ListEntry | None:
        """Return the data of the item in its list (a list: added, rank; the watchlist; the collection), None if none."""
        return ListEntry.new(added_at=it.get('added_at') or it.get('watchlist_at') or it.get('collected_at') or it.get('last_collected_at'),
                             rank=it.get('rank'))

    def _get_list(self, url: str, *, results: str | None = None, page: int = 1, page_size: int | None = None, params: KwArgs | None = None,
                  failed: list[int] | None = None) -> Pages:
        """Receive lists from `url` without parsing. Offsets of failed requests go to `failed` (an empty page is returned for them)."""
        if params is None:
            params = {}
        if page_size is None:
            page_size = const.indexer.mdblist.lists_page_size

        def get(offset: int) -> Pages:
            page_params = dict(params)
            if offset > 1:
                page_params['offset'] = offset
            if page_size:
                page_params['limit'] = page_size
            pg = self.get(url, params=page_params, results=results)
            # if not offset:  print(json.dumps(pg and pg[0], indent=2))  # DEBUG
            if pg is None and failed is not None:
                failed.append(offset)
            return Pages.empty() if pg is None or not isinstance(pg, list) else pg

        # known page size, get single page
        if page and page_size:
            offset = (page - 1) * page_size
            return get(max(0, offset)) or Pages.empty()

        # depagination: page == 0 or unknown page size, get all items
        first = get(0)
        if not first.has_more:
            return first
        page_size, total_pages = first.limit, first.total_pages
        with requests.RequestsPoolExecutor() as ex:
            pages: Iterator[Pages] = ex.map(get, (i * page_size for i in range(1, total_pages)))
        items: list[JsonData] = list(chain(first, *(pg for pg in pages if pg is not None)))
        return Pages(items, total_items=len(items), has_more=False, limit=len(items), offset=0)

    def _cached_items(self, name: str, url: str, *, bucket: str = '', kind: str | None = None, params: KwArgs | None = None,
                      results: str | None = None) -> list[JsonData] | None:
        """
        Return all items of a list of the account (`lib.ff.listcache`, `bucket` of the sync, '' - none), or of a general
        list of the kind `kind` (no account: the scope is the type), None on failure.
        """
        def fetch() -> FetchedList | None:
            failed: list[int] = []
            data = self._get_list(url, page=ALL_PAGES, page_size=self.LIMIT, params=params, results=results, failed=failed)
            return None if failed else FetchedList([(None, it) for it in data])

        stored = cached_list('mdblist' if kind else self.scope, name, fetch, params=list_params(url=url, **(params or {})), bucket=bucket, kind=kind)
        return None if stored is None else list(stored.items)

    def _general_page(self, url: str, *, kind: str, page: int = 1, page_size: int | None = None, params: KwArgs | None = None) -> Pages:
        """Return a page of a general list (no account: the scope is the type) through the list cache (the TTL of the `kind`)."""
        page_size = page_size or const.indexer.mdblist.lists_page_size

        def fetch() -> FetchedList | None:
            failed: list[int] = []
            data = self._get_list(url, page=page, page_size=page_size, params=params, failed=failed)
            if failed:
                return None
            return FetchedList([(None, it) for it in data], meta={'total_items': data.total_items, 'has_more': data.has_more, 'limit': page_size})

        stored = cached_list('mdblist', url, fetch, params=list_params(limit=page_size, **(params or {})), kind=kind, page=page)
        if stored is None:
            return Pages.empty()
        return Pages(list(stored.items), offset=max(0, page - 1) * page_size, **stored.row.meta)

    @staticmethod
    def _page(items: Sequence[JsonData], *, page: int, page_size: int) -> Pages:
        """Return the page of all items (0: all) as a response page."""
        if not page:
            return Pages(list(items), total_items=len(items), has_more=False, limit=len(items), offset=0)
        offset = (page - 1) * page_size
        return Pages(list(items[offset:offset + page_size]), total_items=len(items), has_more=offset + page_size < len(items),
                     limit=page_size, offset=offset)

    def _cached_response(self, name: str, url: str, *, bucket: str, params: KwArgs | None = None, login_required: bool = True) -> Pages | None:
        """Return the whole response of a list of the account (a single request, e.g. the watchlist) from the list cache (`bucket` of the sync)."""
        def fetch() -> FetchedList | None:
            resp = self.request('GET', url, data=None, params=params, login_required=login_required)
            if resp is None:
                return None
            return FetchedList([(None, resp.json())], meta={'total': int(resp.headers.get('X-Total-Items') or 0)})

        stored = cached_list(self.scope, name, fetch, params=list_params(url=url, **(params or {})), bucket=bucket)
        if stored is None or not stored.items:
            return None
        return Pages(stored.items[0], total_items=stored.row.meta.get('total', 0))

    def _own_list(self, list_id: int | str) -> bool:
        """
        Return True if the list is a static list of the account (its lists from the list cache; `user/name` IDs are not
        matched); a dynamic one changes by its rules, not by the user (no sync stamp): a general list with its TTL.
        """
        if not isinstance(list_id, int) or self.account is None:
            return False
        lists = self._cached_items('user', 'lists/user/', bucket='lists.user', params=LISTS_PARAMS) or ()
        return any(it.get('id') == list_id and not it.get('dynamic') for it in lists)

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """Return cursors of the sync buckets of the account (`lib.ff.sync`), None on failure."""
        data = self.get('sync/last_activities')
        if not isinstance(data, dict):
            return None
        return {bucket: max(values) for bucket, keys in SYNC_BUCKETS.items() if (values := [str(value) for key in keys if (value := data.get(key))])}

    def sync_bucket(self, bucket: SyncBucket, cursor: str | None = None) -> bool | None:
        """Get the bucket data (full lists) and store rows of the account (`lib.ff.sync`). Return True if changed, None on failure."""
        assert self.account is not None  # sync is login required
        account_id = self.account.id
        movie = bucket.endswith('.movie')
        if bucket.startswith('progress.'):
            if not isinstance(data := self.get('sync/playback'), list):
                return None
            # a zero resume point is none (a removal between its `scrobble/stop` at 0 % and `scrobble/clear`, other apps)
            rows = [pb for it in data if (pb := play_info(it, progress=float(it.get('progress') or 0), paused_at=iso_timestamp(it.get('paused_at')),
                                                          playback_id=it.get('id'))) and pb.progress and pb.ref.is_movie == movie]
            return update_track_playback(rows, account_id=account_id, media_type='movie' if movie else 'show',
                                         removed_at=cursor_time(cursor))
        if (items := self._sync_items('sync/watched', 'movie' if movie else 'episode')) is None:
            return None
        # the list has no play count (only `plays=all`: a row a play, also of the items unwatched by other apps): watched or not
        rows = [pb for it in items if (pb := play_info(it, play_count=1, last_watched_at=iso_timestamp(it.get('last_watched_at')) or 0))]
        if movie:
            return update_track_watched_movies(rows, account_id=account_id, removed_at=cursor_time(cursor))
        return update_track_watched_episodes(rows, account_id=account_id, removed_at=cursor_time(cursor))

    def _sync_items(self, url: str, mediatype: str) -> list[JsonData] | None:
        """Return all items of the media type of a sync list (`movies` / `episodes`, the cursor pages), None on failure."""
        key = f'{mediatype}s'
        items: list[JsonData] = []
        cursor: str | None = None
        seen: set[str] = set()
        while True:
            params: KwArgs = {'mediatype': mediatype, 'limit': self.LIMIT, **({'cursor': cursor} if cursor else {})}
            if not isinstance(data := self.get(url, params=params), dict):
                return None
            items.extend(data.get(key) or ())
            pagination = data.get('pagination') or {}
            if not pagination.get('has_more') or not (cursor := pagination.get('next_cursor')) or cursor in seen:
                return items
            seen.add(cursor)

    @staticmethod
    def _history_item(ref: MediaRef) -> tuple[str, JsonData] | None:
        """Return the payload key and item of `sync/watched[/remove]` (a season / an episode nested in its show), None if not supported."""
        if not (ids := dict(ref.video_ids.ids())):
            return None
        if ref.is_movie:
            return 'movies', {'ids': ids}
        if ref.type != 'show':
            return None
        item: JsonData = {'ids': ids}  # the server expands a show / a season to its episodes
        if ref.season is not None:
            item['seasons'] = [{'number': ref.season, **({'episodes': [{'number': ref.episode}]} if ref.episode is not None else {})}]
        return 'shows', item

    @staticmethod
    def _scrobble_target(ref: MediaRef) -> JsonData | None:
        """Return the target of a scrobble of the media (a movie or an episode), None without IDs or of another type."""
        if not (ids := dict(ref.video_ids.ids())):
            return None
        if ref.is_movie:
            return {'movie': {'ids': ids}}
        if ref.is_episode:
            return {'show': {'ids': ids, 'season': {'number': ref.season, 'episode': {'number': ref.episode}}}}
        return None

    def scrobble_ref(self, action: ScrobbleAction, ref: MediaRef, progress: float = 0.0) -> bool:
        """Scrobble the playback (`scrobble/start|pause|stop`; the server marks it watched at stop >= 80 %)."""
        if (data := self._scrobble_target(ref)) is None:
            return False
        # mdblist.com takes at most 5 digits (`100.00`)
        return self.post(f'scrobble/{action}', {**data, 'progress': round(float(progress), 2)}) is not None

    def _history_body(self, items: Iterable[tuple[MediaRef, float | None]]) -> dict[str, list[JsonData]]:
        """Return the body of `sync/watched[/remove]` of the media `(ref, watched_at)` (the time at the innermost object, as Trakt)."""
        body: dict[str, list[JsonData]] = {}
        for ref, watched_at in items:
            if (payload := self._history_item(ref)) is None:
                continue
            key, item = payload
            if watched_at:
                inner = item['seasons'][0] if 'seasons' in item else item
                inner = inner['episodes'][0] if 'episodes' in inner else inner
                inner['watched_at'] = utc_2_iso(watched_at)
            body.setdefault(key, []).append(item)
        return body

    def add_history_refs(self, items: Sequence[tuple[MediaRef, float | None]]) -> bool:
        """
        Mark the media watched in one write (a show / a season: all its episodes; each at its time). Return True if every
        media was found. The service applies it a while later (asynchronously).
        """
        return bool(body := self._history_body(items)) and all_found(self.post('sync/watched', body))

    def add_history_ref(self, ref: MediaRef, *, watched_at: float | None = None) -> bool:
        """Mark the media watched, see `add_history_refs()`."""
        return self.add_history_refs([(ref, watched_at)])

    def remove_history_refs(self, refs: Sequence[MediaRef]) -> bool:
        """
        Mark the media unwatched in one write (a show / a season: all its episodes), their plays removed too (the status
        alone keeps the history). Return True if every media was found.
        """
        if not (body := self._history_body((ref, None) for ref in refs)):
            return False
        found = all_found(self.post('sync/watched/remove', body))
        self._clear_plays(refs)
        return found

    def _clear_plays(self, refs: Sequence[MediaRef]) -> None:
        """
        Remove all plays of the media: a movie, a show or a season by its scope (`history/clear`), episodes by the plays
        of their show (`sync/history/show`) in one `plays/remove`. None there (404) is done; a media without TMDB id is skipped.
        """
        episodes: dict[int, set[tuple[int, int]]] = {}
        for ref in refs:
            if not (tmdb := dict(ref.video_ids.ids()).get('tmdb')):
                fflog(f'[MDBLIST] no TMDB id, plays of {ref} kept')
            elif ref.is_episode:
                episodes.setdefault(int(tmdb), set()).add((int(ref.season or 0), int(ref.episode or 0)))
            elif ref.is_movie or ref.type == 'show':
                scope: JsonData = {'mediatype': 'movie' if ref.is_movie else 'season' if ref.season is not None else 'show', 'provider': 'tmdb', 'id': tmdb}
                if ref.season is not None:
                    scope['season'] = ref.season
                try:
                    self.post('sync/watched/history/clear', scope)
                except NotDelivered as exc:
                    if exc.status != 404:
                        raise
        play_ids: list[int] = []
        for show, numbers in episodes.items():
            try:
                history = self.get(f'sync/history/show/tmdb/{show}')
            except NotDelivered as exc:
                if exc.status != 404:
                    raise
                continue
            play_ids.extend(play['play_id'] for play in (history or {}).get('plays') or ()
                            if (play.get('season_num'), play.get('episode_num')) in numbers and play.get('play_id'))
        if play_ids:
            self.post('sync/watched/plays/remove', {'play_ids': play_ids})

    def remove_history_ref(self, ref: MediaRef) -> bool:
        """Mark the media unwatched, see `remove_history_refs()`."""
        return self.remove_history_refs([ref])

    def remove_playback_ref(self, ref: MediaRef) -> bool:
        """
        Remove the resume point and the playing session of the media: `scrobble/stop` at 0 % ends a playing session as
        a paused one (a play to the end leaves it playing: FF tells the end by the history; the server pauses it at its
        estimated progress when another title starts), `scrobble/clear` removes the paused one (none: 404).
        """
        if (data := self._scrobble_target(ref)) is None:
            return False
        return self.post('scrobble/stop', {**data, 'progress': 0}) is not None and self.post('scrobble/clear', data) is not None

    def _changed(self, name: str) -> None:
        """Mark the cached list `name` (with its sub-lists) of the account as changed (an own change)."""
        mark_stale(self.scope, name)

    def user_profile(self) -> JsonData:
        """Get user profile."""
        data = self.get('user')
        if isinstance(data, dict):  # Mapping
            return data
        return {}

    def refresh_profile(self) -> JsonData | None:
        """Get the user of the account and keep it as the account profile (`id`, `username`), None on failure."""
        if (account := self.account) is None or not (data := self.user_profile()).get('username'):
            return None
        from ..ff.db.accounts import account_data_store
        profile = {'id': data.get('user_id'), 'username': data['username']}
        account_data_store(account.id).set('profile', profile, ttl=None)
        return profile

    def user_lists(self, *,
                   user: str | int | None = None,
                   media: MainMediaType | None = None,
                   page: int = 0,
                   page_size: int | None = None,
                   static: bool = False,
                   ) -> ItemList[FFItem]:
        """Get user lists (of the account: from the list cache; all of them with `page` 0), a dynamic one is read only (`list_readonly`)."""
        if user:  # public lists of another user: a general list
            items = self._cached_items(f'lists/{user}', f'lists/user/{user}', kind='lists', params=LISTS_PARAMS)
        else:
            items = self._cached_items('user', 'lists/user/', bucket='lists.user', params=LISTS_PARAMS)
        if items is None:
            return ItemList.empty()
        data = self._page(items, page=page, page_size=page_size or const.indexer.mdblist.lists_page_size)
        return self._parse_lists(data, media=media, static=static)

    def user_list_by_name(self, *, user: str | int, list: str | int, static: bool = False) -> ItemList[FFItem]:
        """Get user list by name."""
        list = self._list_id(list)
        return self._parse_lists(self.get(f'lists/{user}/{list}', params=LISTS_PARAMS), static=static)

    def watchlist_items(self, *, media: MainMediaType | None = None, page: int = 1, limit: int = LIMIT) -> Sequence[FFItem]:
        """Get watchlist items (from the list cache)."""
        data = self._cached_response('watchlist', 'watchlist/items', bucket='lists.watchlist', params={'unified': 'true'})
        if data is None:
            return ItemList.empty()
        return ItemList.single(self._parse_items(data, media=media, page=page, page_size=limit))

    def top_lists(self, *, media: MainMediaType | None = None, page: int = 1, page_size: int | None = None) -> ItemList[FFItem]:
        """Get top lists."""
        return self._parse_lists(self._general_page('lists/top', kind='lists', page=page, page_size=page_size, params=LISTS_PARAMS), media=media)

    def list_items(self, list_id: int | str, *, page: int | None = None, page_size: int | None = None, media: MediaType | None = None) -> Sequence[FFItem]:
        """Get list items. list_id: ID or user/name. Without `page` (or ALL_PAGES, 0) all items."""
        list_id = self._list_id(list_id)
        if not page_size:
            page_size = const.indexer.mdblist.page_size
        # all items in the biggest pages (every request counts to the daily limit) through the list cache, a page cut here;
        # a public list of another user is a general list (no account, its TTL)
        if self._own_list(list_id):
            items = self._cached_items(f'user/{list_id}', f'lists/{list_id}/items', bucket='lists.user', params={'unified': 'true'})
        else:
            items = self._cached_items(f'list/{list_id}', f'lists/{list_id}/items', kind='lists', params={'unified': 'true'})
        if items is None:
            return ItemList.empty()
        if not page:
            return self._parse_items(self._page(items, page=0, page_size=page_size), media=media)
        return self._parse_items(self._page(items, page=page, page_size=page_size), media=media, page=page, page_size=page_size)

    def list_search(self, query: str, *, page: int = 1, page_size: int | None = None) -> ItemList[FFItem]:
        """Search public lists by title."""
        return self._parse_lists(self._general_page('lists/search', kind='search', page=page, page_size=page_size, params={**LISTS_PARAMS, 'query': query}))

    def liked_list(self, *, page: int = 1, page_size: int | None = None) -> ItemList[FFItem]:
        """List of user liked lists."""
        return self._parse_lists(self._get_list('lists/liked', results='lists', page=page, page_size=page_size, params=LISTS_PARAMS))

    def like_list(self, list_id: int | str) -> bool:
        """Like a list."""
        list_id = self._list_id(list_id)
        data = self.put(f'lists/{list_id}/like', data=None, login_required=True)
        mark_stale('mdblist')  # the `liked` flag of the general list pages (no sync stamp of likes)
        return isinstance(data, dict) and data.get('status') == 'liked'

    def unlike_list(self, list_id: int | str) -> bool:
        """Unlike a list."""
        list_id = self._list_id(list_id)
        data = self.delete(f'lists/{list_id}/like', login_required=True)
        mark_stale('mdblist')  # the `liked` flag of the general list pages (no sync stamp of likes)
        return isinstance(data, dict) and data.get('status') == 'unliked'

    def _modify_items(self, url: str, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Add items to any list."""
        remove = url.endswith('/remove')
        items = tuple(items)
        to_modify = {
            'movies': [{'tmdb': ref.tmdb_id} for it in items if (ref := it.ref) and ref.is_movie],
            'shows': [{'tmdb': ref.tmdb_id} for it in items if (ref := it.ref) and ref.is_show],
            'seasons': [{'tmdb': ref.tmdb_id, 'season_number': ref.season} for it in items if (ref := it.ref) and ref.is_season],
            'episodes': [{'tmdb': ref.tmdb_id, 'season_number': ref.season, 'episode_number': ref.episode} for it in items if (ref := it.ref) and ref.is_episode],
        }
        data = self.post(url, data=to_modify)
        fflog(f'[MDBLIST] {"Remove" if remove else "Add"} items to {items} → {data!r}')
        if isinstance(data, dict):  # Mapping
            res_name = 'removed' if remove else 'added'
            added = sum(v for v in data.get(res_name, {}).values())
            # existing = sum(v for v in data.get('existing', {}).values())
            not_found = sum(v for v in data.get('not_found', {}).values())
            return added > 0 and not_found == 0, added
        return False, 0

    def _proc_list_items(self,
                         items: Iterable[FFRef],
                         *,
                         path: str,
                         remove: bool,
                         show_only: bool = False,  # only shows, no seasons or episodes
                         extra: Iterable[JsonData] = (),  # extra data for each item to set in mdblist (like rating, ...)
                         ) -> tuple[bool, int]:
        def ex_iter(items: Iterable[FFRef]) -> Iterable[tuple[FFRef, JsonData]]:
            xit = iter(extra)
            for it in items:
                yield it, next(xit, {})

        if not hasattr(items, '__len__'):
            items = tuple(items)
        if not hasattr(extra, '__len__'):
            extra = tuple(extra)
        if not items:
            return True, 0
        movies = tuple({'ids': ref.video_ids.ids(), **ex} for item, ex in ex_iter(items) if (ref := item.ref).is_movie)
        if show_only:
            shows = tuple({'ids': ref.video_ids.ids(), **ex} for item, ex in ex_iter(items) if (ref := item.ref).is_show)
        else:
            shows = tuple(chain(
                ({'ids': ref.video_ids.ids(), **ex}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_show),
                ({'ids': ref.video_ids.ids(), 'seasons': [{'number': ref.season, **ex}]}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_season),
                ({'ids': ref.video_ids.ids(), 'seasons': [{'number': ref.season, 'episodes': [{'number': ref.episode, **ex}]}]}
                 for item, ex in ex_iter(items) if (ref := item.ref).is_episode),  # type: ignore[reportArgumentType]
            ))
        if not movies and not shows:  # no persons: MDBList knows movies and shows only
            return True, 0
        items_to_send = {
            'movies': movies,
            'shows': shows,
        }
        data = self.post(path, data=items_to_send, login_required=True)
        # import json; print(json.dumps(items_to_send, indent=2)); print(json.dumps(data, indent=2))
        res_name = 'removed' if remove else 'updated'
        if isinstance(data, dict):  # Mapping
            updated = sum(v for v in data.get(res_name, {}).values())
            not_found = sum(len(v) for v in data.get('not_found', {}).values())
            return updated > 0 and not_found == 0, updated
        return False, 0

    def add_to_watchlist(self, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Add items to watchlist."""
        try:
            return self._modify_items('watchlist/items/add', items)
        finally:
            self._changed('watchlist')

    def add_to_user_list(self, list_id: int | str, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Add items to user list."""
        list_id = self._list_id(list_id)
        try:
            return self._modify_items(f'lists/{list_id}/items/add', items)
        finally:
            self._changed('user')
            mark_stale('mdblist', f'list/{list_id}')  # addressed as `user/name`: a general list

    def remove_from_watchlist(self, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Remove items from watchlist."""
        try:
            return self._modify_items('watchlist/items/remove', items)
        finally:
            self._changed('watchlist')

    def remove_from_user_list(self, list_id: int | str, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Remove items from user list."""
        list_id = self._list_id(list_id)
        try:
            return self._modify_items(f'lists/{list_id}/items/remove', items)
        finally:
            self._changed('user')
            mark_stale('mdblist', f'list/{list_id}')  # addressed as `user/name`: a general list

    # --- Lists and ratings of the account (`AccountClient` vocabulary) ---

    def watchlist(self, *, media: MainMediaType | None = None, page: int | None = None) -> Sequence[FFItem]:
        """Return the watchlist of the account (the page of `const.indexer.mdblist.page_size`, all items without `page`)."""
        from . import depaginate
        with depaginate(self) as api:
            items = api.watchlist_items(media=media)
        return Pagina(items, page=page, limit=const.indexer.mdblist.page_size) if page else items

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the watchlist or remove them, return the number of changed ones."""
        return (self.add_to_watchlist if state else self.remove_from_watchlist)(items)[1]

    def collection(self, *, media: MainMediaType | None = None, page: int | None = None) -> Sequence[FFItem]:
        """Return the collection of the account (movies and shows, from the list cache), the page cut here (all without `page`)."""
        # ponytail: one page of the sync (5000 items), more pages when a collection is that big
        data = self._cached_response('collection', 'sync/collection', bucket='lists.collection', params={'limit': 5000})
        if data is None:
            return ItemList.empty()
        items = self._parse_items(Pages(data.__wrapped__), media=media)
        return Pagina(items, page=page, limit=const.indexer.mdblist.page_size) if page else items

    def upnext(self, *, page: int | None = None) -> ItemList[MediaRef]:
        """
        Return the next episodes of the shows in progress of the account (MDBList `upnext`: the last watched show first), a page of
        the service (`const.indexer.mdblist.page_size`, at most 100; the first page without `page`).
        """
        page = max(page or 1, 1)
        size = min(100, const.indexer.mdblist.page_size)
        data = self.get('upnext', params={'limit': size, 'offset': (page - 1) * size})
        data = getattr(data, '__wrapped__', data)
        if not isinstance(data, dict):
            return ItemList.empty()
        refs = [MediaRef('show', VideoIds.from_ids(ids).ffid, season=ep['season'], episode=ep['episode'])
                for it in data.get('items') or () if isinstance(it, dict) and (ids := (it.get('show') or {}).get('ids'))
                and isinstance(ep := it.get('next_episode'), dict) and ep.get('season') is not None and ep.get('episode') is not None]
        return ItemList(refs, page=page, page_size=size, total_pages=page + 1 if data.get('has_more') else page)

    def set_collection(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to the collection or remove them (a show with its seasons and episodes), return the number of changed ones."""
        try:
            return self._proc_list_items(items, path='sync/collection' if state else 'sync/collection/remove', remove=not state)[1]
        finally:
            self._changed('collection')

    def create_list(self, name: str, *, public: bool = False) -> int | None:
        """Create a static list (private unless `public`), return its ID; None on failure (e.g. the limit of static lists of the plan)."""
        data = self.post('lists/user/add', data={'name': name, 'private': not public})
        self._changed('user')
        return data.get('id') if isinstance(data, dict) else None

    def delete_list(self, list_id: int | str) -> bool:
        """Delete a static list (with its items)."""
        list_id = self._list_id(list_id)
        data = self.delete(f'lists/{list_id}')
        self._changed('user')
        return isinstance(data, dict) and bool(data.get('success'))

    def rename_list(self, list_id: int | str, name: str) -> str | None:
        """Rename an own list (a static or a dynamic one), return its ID, None on failure."""
        data = self.put(f'lists/{self._list_id(list_id)}', data={'name': name})
        self._changed('user')
        return str(list_id) if isinstance(data, dict) and data.get('success') else None

    def set_in_list(self, list_id: int | str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) items to an own (static) list or remove them, return the number of changed ones."""
        return (self.add_to_user_list if state else self.remove_from_user_list)(list_id, items)[1]

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, int]:
        """Return the ratings of the account by media (from the list cache), only of the media `refs` if given."""
        return pick_ratings({it.ref: int(rating) for it in self.user_ratings() if (rating := it.getProperty('mdblist.user_rating'))}, refs)

    def set_ratings(self, items: Iterable[FFRef], rating: int | None) -> int:
        """Rate (`rating`) the media or remove their ratings (None), return the number of changed ones."""
        if rating is None:
            return self.remove_user_ratings(items)[1]
        return self.add_user_ratings(items, rating=int(rating))[1]

    # https://api.mdblist.com/rating/media_type/return_rating?apikey=abc123
    # movie , show
    # trakt , imdb , tmdb , letterboxd , tomatoes , audience , metacritic , rogerebert , mal , score , score_average

    def user_ratings(self, *, media: MediaType | None = None) -> ItemList[FFItem]:
        """Get user media ratings (from the list cache)."""
        data = self._cached_response('rated', 'sync/ratings', bucket='ratings')
        if data is None:
            return ItemList.empty()
        data = data.__wrapped__
        if isinstance(data, dict) and (pagination := data.get('pagination')):
            total_items = sum(count for k in ('movie', 'show', 'season', 'episode')
                              if (media is None or media == k) and (count := pagination.get(f'total_{k}s')))
        else:
            total_items = 0
        pages = Pages(data, total_items=total_items)
        items = self._parse_items(pages, media=media)
        # data = self.get(f'sync/ratings', login_required=True)
        # return self._item_list(data, pages=None)
        return items

    def add_user_ratings(self, items: Iterable[FFRef], *, rating: int | None) -> tuple[bool, int]:
        """Add (set) user ratings. If `rating` is None, get ratings from FFItems."""
        items = tuple(items)
        if rating is None:
            # no rating set, get form FFItems (there must be all set, MediaRef is not allowed here)
            ratings = [{'rating': ur} if ur else {} for it in items if isinstance(it, FFItem) and (ur := it.vtag.getUserRating()) is not ...]
            if len(ratings) != len(items):
                raise ValueError('MdbList.add_user_ratings() got refs with missing ratings')
        else:
            # rating is set for all items (works with MediaRef too)
            if not (1 <= rating <= 10):
                raise ValueError(f'MdbList.add_user_ratings() got incorrect rating {rating!r}')
            ratings = ({'rating': rating} for _ in items)
        try:
            return self._proc_list_items(items, path='sync/ratings', remove=False, extra=ratings)
        finally:
            self._changed('rated')

    def remove_user_ratings(self, items: Iterable[FFRef]) -> tuple[bool, int]:
        """Remove user ratings."""
        try:
            return self._proc_list_items(items, path='sync/ratings/remove', remove=True)
        finally:
            self._changed('rated')

    def ref_ids(self, ref: FFRef) -> VideoIds | None:
        """Get media IDs from mdblist.com for a given media reference."""
        ref = ref.ref
        if not ref.is_movie and not ref.is_show:
            return None
        srv, mid = ref.video_ids.service_and_value()
        if srv not in ('imdb', 'tmdb', 'trakt', 'tvdb', 'mal', 'mdblist'):
            return None
        data = self.get(f'{srv}/{ref.type}/{mid}')
        if isinstance(data, dict):  # Mapping
            ids = data.get('ids', {})
            return VideoIds.from_ids(ids)
        return None

    # def get_media(self, media_provider: MediaProvider, media_type: MainMediaType, media_id: int | str) -> FFItem | None:

    def get_full_ids(self, media_provider: MediaProvider, media_type: MainMediaType, media_id: SequenceProto[int | str]) -> list[MdblistIds]:
        """Get media IDs for a given media provider and media type."""
        chain = 200  # mdblist.com API limit for POST /{media_provider}/{media_type} endpoint
        url = f'{media_provider}/{media_type}'
        if len(media_id) > chain:
            def get(offset: int) -> list[JsonData]:
                d = self.post(url, data={'ids': media_id[offset:offset + chain]})
                return d if isinstance(d, list) else []
            with requests.RequestsPoolExecutor() as ex:
                data = [it for d in ex.map(get, range(0, len(media_id), chain)) for it in d]
        else:
            data = self.post(url, data={'ids': media_id})
        if isinstance(data, list):
            return [MdblistIds(
                imdb=ids.get('imdb', ''),
                tmdb=ids.get('tmdb', 0),
                trakt=ids.get('trakt', 0),
                tvdb=ids.get('tvdb'),
                mal=ids.get('mal'),
                mdblist=ids.get('mdblist', ''),
            ) for item in data if (ids := item.get('ids'))]
        return []


#: Client of the settings MDBList account.
mdblist: MdbList = MdbList(alias='mdblist')
#: Application client (ffinfo: ID lookups): the first active MDBList account with a key (its budget).
mdblist_app: MdbList = MdbList()


def make_client(account: Account | None) -> MdbList:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return mdblist if account is None else MdbList(account)


if __name__ == '__main__':
    from typing import get_args as get_type_args, Generator
    from contextlib import contextmanager
    import json
    from ..ff.cmdline import DebugArgumentParser, enumerate_items, parse_ref

    def print_ffitems(items: SequenceProto[FFItem]) -> None:
        if isinstance(items, ItemList):
            print(f'Page {items.page} of {items.total_pages}, {len(items)} items, total: {items.total_results}')
        with enumerate_items(items) as items:
            for it in items:
                row = [f'{it.num}. {it.ref:16a}: {it.title} ({it.year})']
                if it.children_count:
                    row.append(f'[#{it.children_count}]')
                if rating := it.getProperty('mdblist.user_rating'):
                    row.append(f'{rating}★')
                print(' '.join(row))

    def parse_list_id(v: str) -> int | str:
        if '/' in v:
            if v.partition('/')[0].isdecimal():
                raise ValueError()
            return v
        return int(v)

    @contextmanager
    def list_subparser(name: str, *, dest: str | None = None) -> Generator[DebugArgumentParser, None, None]:
        with p.with_subparser(name, dest=dest) as pp:
            yield pp
            pp.add_argument('-p', '--page', default=1, type=int, help='page number (start from 1)')
            pp.add_argument('-P', '-s', '--page-size', '--limit', type=int, help='page size')

    p = DebugArgumentParser(dest='op', description='Test script for mdblist.com')
    p.add_argument('-p', '--page', type=int, default=1, help='page number for paginated results')
    p.add_argument('-P', '--page-size', type=int, default=const.indexer.mdblist.page_size, help='page size for list items')
    with p.with_subparser('profile') as pp:
        pass
    with p.with_subparser('watchlist') as pp:
        pp.add_argument('-t', '--type', choices=('movie', 'show'), help='filter items by media type')
    with list_subparser('lists') as pp:
        pp.add_argument('-u', '--user', help='user name to get lists for')
        pp.add_argument('-l', '--list', help='name of user list')
        pp.add_argument('-S', '--static', action='store_true', help='only static lists')
    with p.with_subparser('items') as pp:
        pp.add_argument('list', type=parse_list_id, help='list ID to get items for')
        pp.add_argument('-t', '--type', choices=('movie', 'show'), help='filter items by media type')
    with list_subparser('liked') as pp:
        pp.add_argument('-t', '--type', choices=('movie', 'show'), help='media type')
        pp.add_argument('-a', '--add', '--like', help='like a list by ID')
        pp.add_argument('-r', '--remove', '--unlike', help='unlike a list by ID')
    with list_subparser('top') as pp:
        pp.add_argument('-t', '--type', choices=('movie', 'show'), help='media type')
    with list_subparser('list_search') as pp:
        pp.add_argument('query', help='list name query')
    with list_subparser('rating', dest='action') as pp:
        pp.add_argument('-t', '--type', choices=get_type_args(MediaType), help='filter items by media type')
        with pp.with_subparser('add') as ppp:
            ppp.add_argument('rating', type=int, help='rating to set (1-10)')
            ppp.add_argument('refs', type=parse_ref, nargs='+', help='add (set) user ratings for items by ref (media_type/id…)…')
        with pp.with_subparser('remove') as ppp:
            ppp.add_argument('refs', type=parse_ref, nargs='+', help='remove (delete) user ratings for items by ref (media_type/id…)…')
    args = p.parse_args()

    mdb = MdbList()
    if args.op == 'lists':
        # print(json.dumps(mdb.user_lists(user='garycrawfordgc'), indent=2))
        # print(json.dumps(mdb.user_lists(user=args.user), indent=2))
        if args.list:
            if not args.user:
                args.user = mdb.user_profile()['username']
            print_ffitems(mdb.user_list_by_name(user=args.user, list=args.list, static=args.static))
        else:
            print_ffitems(mdb.user_lists(user=args.user, static=args.static, page=args.page, page_size=args.page_size))
    elif args.op == 'items':
        # print(json.dumps(mdb.list_items(args.list), indent=2))
        print_ffitems(mdb.list_items(args.list, page=args.page, page_size=args.page_size, media=args.type))
    elif args.op == 'watchlist':
        print_ffitems(mdb.watchlist_items(page=args.page, limit=args.page_size, media=args.type))
    elif args.op == 'liked':
        if args.add:
            print(f'Liked: {mdb.like_list(args.add)}')
        elif args.remove:
            print(f'Unliked: {mdb.unlike_list(args.remove)}')
        else:
            print_ffitems(mdb.liked_list(page=args.page, page_size=args.page_size))
    elif args.op == 'top':
        print_ffitems(mdb.top_lists(media=args.type, page=args.page, page_size=args.page_size))
    elif args.op == 'list_search':
        print_ffitems(mdb.list_search(args.query, page=args.page, page_size=args.page_size))
    elif args.op == 'rating':
        if args.action == 'add':
            success, count = mdb.add_user_ratings(args.refs, rating=args.rating)
            print(f'Added ratings: {success}, count: {count}')
        elif args.action == 'remove':
            success, count = mdb.remove_user_ratings(args.refs)
            print(f'Removed ratings: {success}, count: {count}')
        else:
            print_ffitems(mdb.user_ratings(media=args.type))
    else:
        print(json.dumps(mdb.user_profile(), indent=2))
