"""
WeTrakr API (https://api.wetrakr.com): a tracker like Trakt - device flow accounts, progress, watched, ratings,
lists. Notes: `notes/services/wetrakr.md`.

The key of the app is `apis.wetrakr_API` (`client_id`; the `client_secret` is never in the add-on). The access token
lives 7 days, the refresh token 180 days and rotates: only the service refreshes it (`/account/refresh`, one session
owner), else an old refresh token in the grace window forks the session. Requests at once are limited per account
(`const.wetrakr.concurrency`), writes are sent by `ids` only (a title would match by name).
"""

from __future__ import annotations
from typing import Any, Callable, ClassVar, Iterable, Mapping, Sequence, TYPE_CHECKING
from datetime import date as dt_date, datetime, timedelta
from email.utils import parsedate_to_datetime
from time import time
from threading import BoundedSemaphore, RLock
from uuid import uuid4
from urllib.parse import quote
from typing_extensions import Literal
from ..ff import requests
from ..ff import apis
from ..ff.accounts import Account, AccountClient, DeviceAuth, all_found, failed_request, limited_until, next_utc_midnight, set_limited
from ..ff.ratings import RatingScale, pick_ratings
from ..ff.calendar import utc_timestamp, utc_2_iso
from ..ff.sync import cursor_time
from ..ff.db.playback import MediaPlayInfo, update_track_playback, update_track_watched_movies, update_track_watched_episodes
from ..ff.kotools import xsleep
from ..ff.listcache import mark_stale
from ..ff.logs import fflog
from ..ff.settings import advanced_settings
from ..defs import MediaRef, VideoIds
from ..kolang import L
from cdefs import ListSection, ListType
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..ff.types import JsonData, JsonResult, KwArgs
    from ..ff.sync import SyncBucket
    from ..ff.db.kvstore import KeyValueStore
    from ..ff.item import FFItem, ListEntry
    from ..defs import FFRef, ItemList, MainMediaType, MediaOrPersonType, MediaType


#: Scrobble action (`scrobble/<action>`).
ScrobbleAction = Literal['start', 'pause', 'stop']

#: Sync buckets (FF bucket -> (section, key) of `sync/last_activities`, the newest one is the cursor), see `lib.ff.sync`.
#: `last_playback_at` moves on every change of the `playing` list (a pause, the end of a session, a cancel), not on
#: ratings / lists; a title leaving the watchlist moves `last_tracking_removed_at`, but `scrobble/start` of a movie
#: takes it out of `planning` moving `last_playback_at` only (measured live, see `notes/services/wetrakr.md`).
SYNC_BUCKETS: dict[SyncBucket, tuple[tuple[str, str], ...]] = {
    'progress.movie': (('movies', 'last_playback_at'),),
    'progress.episode': (('episodes', 'last_playback_at'),),
    'watched.movie': (('movies', 'last_tracking_watched_at'), ('movies', 'last_tracking_removed_at')),
    'watched.episode': (('episodes', 'last_tracking_watched_at'), ('episodes', 'last_tracking_removed_at'),
                        ('seasons', 'last_tracking_watched_at'), ('seasons', 'last_tracking_removed_at'),  # a whole season
                        ('shows', 'last_tracking_watched_at'), ('shows', 'last_tracking_removed_at')),
    'lists.watchlist': (('movies', 'last_tracking_planning_at'), ('movies', 'last_tracking_removed_at'),
                        ('movies', 'last_playback_at'),  # scrobble/start takes a movie off the watchlist
                        ('shows', 'last_tracking_planning_at'), ('shows', 'last_tracking_removed_at')),
    'lists.favorites': (('favorites', 'all'),),
    'lists.user': (('lists', 'all'), ('likes', 'all')),  # own lists and the liked ones
    'ratings': (('ratings', 'all'),),
}

#: Cached lists (`lib.ff.listcache` names) of the list buckets: a change only marks them stale.
SYNC_LISTS: dict[SyncBucket, str] = {
    'lists.watchlist': 'watchlist',
    'lists.favorites': 'favorites',
    'lists.user': 'user',
    'ratings': 'rated',
}


#: Codes of 429 for a daily limit (reset at midnight UTC, no retry): the plan of the user, the user in the app, the app.
DAILY_LIMITS: frozenset[str] = frozenset({'QUOTA_EXCEEDED', 'APP_USER_QUOTA_EXCEEDED', 'APP_QUOTA_EXCEEDED'})

#: Scope of the application (the client without an account, the daily limit of the app key).
APP_SCOPE: str = 'wetrakr'

#: The parameters of the requests of lists of lists: their first items (the image of a list).
LISTS_PARAMS: KwArgs = {'extended': 'preview'}


def iso_timestamp(value: str | None) -> int | None:
    """Return the unix timestamp of an ISO time of WeTrakr, None if not given."""
    return int(utc_timestamp(value)) if value else None


def row_ref(row: JsonData) -> MediaRef | None:
    """Return the reference of a row (`type`, `ids`; an episode: `show_ids`, `season_number`, `number`; a person), None if unknown."""
    typ = row.get('type')
    if typ == 'season':
        show = row.get('show_ids') or (row.get('show') or {}).get('ids') or {}
        if (ffid := VideoIds.from_ids(show).ffid) and (number := row.get('number', row.get('season_number'))) is not None:
            return MediaRef.tvshow(ffid, int(number))
        return None
    if typ == 'episode':
        show = row.get('show_ids') or (row.get('show') or {}).get('ids') or {}
        if (ffid := VideoIds.from_ids(show).ffid) and row.get('season_number') is not None and row.get('number') is not None:
            return MediaRef.tvshow(ffid, int(row['season_number']), int(row['number']))
        return None
    if typ in ('movie', 'show', 'person') and (ffid := VideoIds.from_ids(row.get('ids') or {}).ffid):
        return MediaRef(typ, ffid)
    return None


def ranked(rows: Iterable[JsonData]) -> list[JsonData]:
    """Return the compact rows of a list (newest first) in the order of the list: the pinned first, then by `list_item_rank`."""
    return sorted(rows, key=lambda row: (not row.get('list_item_pinned'), row.get('list_item_rank') or float('inf')))


def calendar_day(row: JsonData) -> dt_date | None:
    """Return the local day of a calendar row: an episode by its airing instant (UTC), a movie by its release date."""
    try:
        if when := row.get('air_datetime'):
            return datetime.fromisoformat(str(when).replace('Z', '+00:00')).astimezone().date()
        if day := row.get('release_date') or row.get('air_date'):
            return dt_date.fromisoformat(str(day)[:10])
    except ValueError:
        pass
    return None


def list_item(it: JsonData) -> FFItem:
    """Return the folder of a list (`list_id`, read by `ListTarget.from_ffitem()`), its owner in the plot; a locked one is marked."""
    from ..ff.item import FFItem
    name = str(it.get('name') or it['id'])
    ffitem = FFItem(name, mode=FFItem.Mode.Folder)
    ffitem.title = name
    ffitem.setProperty('list_id', str(it['id']))
    owner = ((it.get('owner') or {}).get('info') or {})
    plot = [L(32932, 'by {user}').format(user=user)] if (user := owner.get('display_name') or owner.get('username')) else []
    if descr := it.get('description'):
        plot.append(descr)
    if plot:
        ffitem.vtag.setPlot('\n\n'.join(plot))
    total = it.get('items_count', it.get('total_items'))
    if total is not None:
        ffitem._children_count = int(total)
        ffitem.role = L(30331, '{n} title|||{n} titles', n=int(total))
    if it.get('locked'):  # over the plan quota (free: 5 lists x 250 items): its items are not served
        ffitem.role = L(32933, 'Locked by the plan of the account')
    if first := next((row for row in it.get('preview') or () if isinstance(row, dict) and row.get('poster_path')), None):
        from ..ff.art import tmdb_list_art
        ffitem.setArt(tmdb_list_art(first))  # the image of the list: its first item (`extended=preview`)
    return ffitem


def media_body(ref: MediaRef, **extra: Any) -> tuple[str, JsonData] | None:
    """
    Return the key and the item of a sync body for the media (`movies` / `shows` / `people`; a season / an episode nested
    in its show by numbers), `extra` goes to the item of the media itself; None without external IDs.
    """
    if not (ids := dict(ref.video_ids.ids())):
        return None
    if ref.is_movie:
        return 'movies', {'ids': ids, **extra}
    if ref.type == 'person':
        return 'people', {'ids': ids, **extra}
    if ref.type != 'show':
        return None
    if ref.season is None:
        return 'shows', {'ids': ids, **extra}
    season: JsonData = {'number': ref.season}
    if ref.episode is None:
        season.update(extra)
    else:
        season['episodes'] = [{'number': ref.episode, **extra}]
    return 'shows', {'ids': ids, 'seasons': [season]}


def scrobble_body(ref: MediaRef) -> JsonData | None:
    """Return the media block of `scrobble/*` (only `ids`: with a title an unknown id matches by the title), None if not playable."""
    if not (ids := dict(ref.video_ids.ids())):
        return None
    if ref.is_movie:
        return {'movie': {'ids': ids}}
    if ref.is_episode:
        return {'show': {'ids': ids}, 'episode': {'season': ref.season, 'number': ref.episode}}
    return None


class WeTrakrApi(DeviceAuth, AccountClient):
    """WeTrakr API client of an account (or the application client of the general lists, see `wetrakr_app`)."""

    #: API root (the version is a header).
    URL: ClassVar[str] = 'https://api.wetrakr.com/'
    #: Sync buckets of the client (`lib.ff.sync`, `lib.ff.listcache`).
    SYNC_BUCKETS: ClassVar[Mapping[SyncBucket, object]] = SYNC_BUCKETS
    SYNC_LISTS: ClassVar[Mapping[SyncBucket, str]] = SYNC_LISTS
    #: Sync interval (the common one of the service loop).
    SYNC_INTERVAL: ClassVar[int] = CONST_REF.accounts.sync.interval
    #: Sections of lists of the account: the watchlist (`planning`), favorites and own lists (movies and shows; persons in favorites and lists).
    LISTS: ClassVar[Mapping[str, ListSection]] = {
        'watchlist': ListSection(types=ListType.MAIN),
        'favorites': ListSection(types=ListType.MAIN | ListType.PERSON),
        'user': ListSection(types=ListType.MAIN | ListType.PERSON, create={'public': True}),
    }
    #: Rating scale of the account: 0-10 with one decimal, FF writes whole points.
    RATING: ClassVar[RatingScale | None] = RatingScale(type=float, min=1.0, max=10.0, step=1.0, media=('movie', 'show', 'season', 'episode'))
    #: Rows of a compact page (the service takes up to 5 000).
    COMPACT_LIMIT: ClassVar[int] = 5000
    #: Items of a batch write (the service takes up to 5 000 a call).
    BATCH_LIMIT: ClassVar[int] = 5000
    #: A history write ends the resume point of the media (measured 2026-10-23: also a watch older than the pause).
    HISTORY_ENDS_PLAYBACK: ClassVar[bool] = True
    #: Requests at once per account / the application (reads, writes) - shared by the clients of the process.
    _gates: ClassVar[dict[tuple[str, bool], BoundedSemaphore]] = {}
    #: Data keys of the account forgotten on sign out.
    SIGN_OUT_KEYS: ClassVar[tuple[str, ...]] = ('token', 'profile', 'quota')
    _gates_lock: ClassVar[RLock] = RLock()

    def __init__(self, account: Account | None = None, *, alias: str = '') -> None:
        super().__init__(account, alias=alias)
        #: Connection session.
        self.sess: requests.Session = requests.Session()
        #: Seconds the clock of the service is ahead of the local one (the `Date` of the last response): its times of
        #: the sync are moved to the local clock, the one of the waiting changes (`_pending_guard()`).
        self._clock_skew: float = 0.0

    # --- Account data ---

    @property
    def account(self) -> Account | None:
        """Return the account of the client (the application client: the first active WeTrakr account with a token, now)."""
        if self._account is not None or self._alias:
            return super().account
        from ..ff.accounts import accounts
        from ..ff.db.accounts import account_data_store
        return next((acc for acc in accounts() if acc.type.name == 'wetrakr' and acc.active
                     and (account_data_store(acc.id).get('token') or {}).get('refresh_token')), None)

    @property
    def public_user(self) -> str:
        """Return the user of a public account (`config.user`, read without a token), '' for a signed in one or none."""
        from ..ff.accounts import type_enabled
        if (account := self.account) is None or self.credentials() or not type_enabled('wetrakr'):
            return ''
        return str(account.config.get('user') or '')

    def _base(self) -> tuple[str, bool]:
        """Return the path base of the reads of the account and if they need the token: `sync` or `users/<user>` (public)."""
        if user := self.public_user:
            return f'users/{user}', False
        return 'sync', True

    @property
    def scope(self) -> str:
        """Return the scope of the cached lists and of the account data: the account ID."""
        return APP_SCOPE if (account := self.account) is None else account.id

    @property
    def _store(self) -> KeyValueStore:
        """Return the data of the account (`accounts.db`)."""
        from ..ff.db.accounts import account_data_store
        return account_data_store(self.scope)

    def credentials(self) -> str:
        """Return the credentials of the account (the refresh token, '' - none or switched off), see `AccountStore.auth_state()`."""
        from ..ff.accounts import type_enabled
        return str(self._token().get('refresh_token') or '') if type_enabled('wetrakr') else ''

    def is_enabled(self) -> bool:
        """Return True if the client can ask the service (the type is on and the client has an account with a token)."""
        return bool(self.credentials())

    # --- HTTP ---

    def _gate(self, write: bool) -> BoundedSemaphore:
        """Return the semaphore of requests at once of the account (the application without a token)."""
        key = (self.scope, write)
        with self._gates_lock:
            if (gate := self._gates.get(key)) is None:
                gate = self._gates[key] = BoundedSemaphore(const.wetrakr.concurrency.write if write else const.wetrakr.concurrency.read)
            return gate

    def _headers(self, *, auth: bool) -> dict[str, str] | None:
        """Return the request headers, None if a token is needed and there is none."""
        from ..ff.control import addonInfo
        # no language header: FF shows titles and plots of TMDB (ffinfo), WeTrakr gives IDs
        headers = {'wetrakr-api-key': apis.wetrakr_API,  # type: ignore[attr-defined]  # decoded at import
                   'wetrakr-api-version': '1', 'User-Agent': f'FanFilm/{addonInfo("version")} (Kodi)'}
        if auth:
            if not (token := self._access_token()):
                return None
            headers['Authorization'] = f'Bearer {token}'
        return headers

    def request(self, method: str, path: str, *, params: KwArgs | None = None, json: JsonResult | None = None,
                auth: bool = True, idempotent: bool = False) -> requests.Response | None:
        """
        Send a request (the account token unless `auth` is false), return the response (None: no token / no connection).
        An `idempotent` write has its own key (`Idempotency-Key`): a retry of it is not run twice by the service.
        """
        if (headers := self._headers(auth=auth)) is None:
            return None
        if idempotent:
            headers['Idempotency-Key'] = str(uuid4())
        if until := limited_until(APP_SCOPE) or ('Authorization' in headers and limited_until(self.scope)):
            fflog(f'[WETRAKR] {method} {path}: the daily request limit is reached until {until}, not sent')
            failed_request(429)
            return None
        resp: requests.Response | None = None
        refreshed = False
        conn = const.wetrakr.connection
        for i in range(conn.try_count):
            try:
                sent = time()
                with self._gate(method != 'GET'):
                    resp = self.sess.request(method, f'{self.URL}{path}', params=params, json=json, headers=headers, timeout=conn.timeout)
            except requests.RequestException as exc:
                fflog(f'[WETRAKR] {method} {path}: {exc}')
                resp = None
                xsleep(conn.try_delay)
                continue
            fflog(f'[WETRAKR] {method} {path} → {resp.status_code} (quota {resp.headers.get("X-Quota-Remaining", "?")})')
            self._note_quota(resp.headers)
            self._note_clock(resp.headers, sent)
            if resp.status_code == 401 and auth and not refreshed and self.refresh_token():
                refreshed = True  # an access token revoked / expired before its time: one more try with a new one
                if (headers := self._headers(auth=True)) is None:
                    return resp
                continue
            if resp.status_code == 429 and (code := self._error_code(resp)) in DAILY_LIMITS:  # until midnight UTC: no retry
                app = code == 'APP_QUOTA_EXCEEDED' or 'Authorization' not in headers  # the app key counts a request without a token
                set_limited(APP_SCOPE if app else self.scope, next_utc_midnight(),
                            label='WeTrakr' if app or self.account is None else self.account.label)
                return resp
            if resp.status_code == 429 or resp.status_code >= 500:
                xsleep(min(60.0, float(resp.headers.get('Retry-After') or conn.try_delay)))
                continue
            return resp
        return resp

    def _note_quota(self, headers: Mapping[str, str]) -> None:
        """Keep the daily quota of the account (its state; `X-Quota-*`), see `notes/services/wetrakr.md` § Limity."""
        if self.account is None or (remaining := headers.get('X-Quota-Remaining')) is None:
            return
        try:
            quota = {'remaining': int(remaining), 'limit': int(headers.get('X-Quota-Limit') or 0)}
            self._store.set('quota', quota, ttl=int(headers.get('X-Quota-Reset') or 86400))
        except ValueError:
            pass

    def _note_clock(self, headers: Mapping[str, str], sent: float) -> None:
        """Keep the offset of the clock of the service: its `Date` (whole seconds, so its middle) to the middle of the request."""
        if not isinstance(value := headers.get('Date'), str):
            return
        try:
            server = parsedate_to_datetime(value).timestamp() + 0.5
        except (TypeError, ValueError, IndexError):
            return
        self._clock_skew = server - (sent + time()) / 2

    def _local_time(self, at: int | None) -> int | None:
        """Return a time of the service (unix seconds) on the local clock (`_clock_skew`), None if not given."""
        return None if at is None else int(at - self._clock_skew)

    def get(self, path: str, *, params: KwArgs | None = None, auth: bool = True) -> JsonResult | None:
        """GET JSON (None on failure)."""
        return self._json(self.request('GET', path, params=params, auth=auth))

    def post(self, path: str, data: JsonResult | None = None, *, params: KwArgs | None = None, auth: bool = True,
             idempotent: bool = False) -> JsonResult | None:
        """POST JSON (None on failure), see `request()`."""
        return self._json(self.request('POST', path, params=params, json=data, auth=auth, idempotent=idempotent))

    def delete(self, path: str, data: JsonResult | None = None) -> JsonResult | None:
        """DELETE (with an optional JSON body), JSON of the answer (None on failure)."""
        return self._json(self.request('DELETE', path, json=data))

    @staticmethod
    def _error_code(resp: requests.Response) -> str:
        """Return the code of an error answer (`error`: a text or `{code, message}`), '' if none."""
        try:
            data = resp.json()
        except ValueError:
            return ''
        error = data.get('error') if isinstance(data, dict) else None
        if isinstance(error, dict):
            error = error.get('code')
        return str(error or '')

    @staticmethod
    def _json(resp: requests.Response | None) -> JsonResult | None:
        """Return the JSON of a successful answer, None on failure (the error is logged)."""
        if resp is None:
            failed_request(0)
            return None
        try:
            data = resp.json()
        except ValueError:
            data = None
        if resp.status_code >= 400:
            message = (data.get('message') or data.get('error')) if isinstance(data, dict) else resp.text[:200]
            fflog(f'[WETRAKR] error {resp.status_code}: {message}')
            failed_request(resp.status_code)
            return None
        return data if data is not None else {}

    def compact(self, path: str, *, params: KwArgs | None = None, auth: bool = True) -> list[JsonData] | None:
        """Return all rows of a compact list (pages walked by the `X-Pagination-Next` cursor), None on failure."""
        rows: list[JsonData] = []
        after: str | None = None
        seen: set[str] = set()
        while True:
            resp = self.request('GET', path, params={**(params or {}), 'compact': 'true', 'limit': self.COMPACT_LIMIT, **({'after': after} if after else {})},
                                auth=auth)
            if not isinstance(data := self._json(resp), list):
                return None
            rows.extend(data)
            if resp is None or not (after := resp.headers.get('X-Pagination-Next')) or after in seen:
                return rows
            seen.add(after)

    # --- Authorization (`DeviceAuth`) ---

    def _device_code(self) -> requests.Response | None:
        """Ask for a device code."""
        return self.request('POST', 'oauth/device/code', json={'client_id': apis.wetrakr_API}, auth=False)  # type: ignore[attr-defined]

    def _poll_token(self, device_code: str) -> requests.Response | None:
        """Ask for the token of the device code."""
        return self.request('POST', 'oauth/device/token', json={'code': device_code, 'client_id': apis.wetrakr_API}, auth=False)  # type: ignore[attr-defined]

    def _refresh_request(self, refresh: str) -> requests.Response | None:
        """Exchange the refresh token for a new pair."""
        return self.request('POST', 'oauth/token/refresh', json={'refresh_token': refresh}, auth=False)

    def _revoke_token(self, token: Mapping[str, Any]) -> None:
        """Revoke the session in WeTrakr (`oauth/logout`, terms § 5)."""
        self.post('oauth/logout', {'refresh_token': token['refresh_token']})

    @staticmethod
    def _verification_url(code: Mapping[str, Any]) -> str:
        """Return the link of the device code: the code is filled in the page by `?code=` (checked by the owner), the QR code needs no typing."""
        return f"{str(code.get('verification_url') or 'https://wetrakr.com/activate').rstrip('/')}?code={quote(str(code['user_code']))}"

    @staticmethod
    def _auth_title() -> str:
        """Return the title of the sign-in window."""
        return L(32935, '[B]Authorize WeTrakr[/B]')

    @staticmethod
    def _refresh_before() -> float:
        """Return the seconds before the end of the access token when it is refreshed."""
        return const.wetrakr.auth.refresh_before

    def refresh_profile(self) -> JsonData | None:
        """Get the user of the account and keep it as the account profile (`id`, `username`), None on failure."""
        if self.account is None or not isinstance(data := self.get('account/settings'), dict) or not data.get('id'):
            return None
        info = data.get('info') or {}
        profile = {'id': data['id'], 'username': info.get('username') or info.get('display_name') or str(data['id']),
                   'plan': data.get('plan')}
        self._store.set('profile', profile, ttl=None)
        return profile

    # --- Progress and watched (`lib.service` senders) ---

    def scrobble_ref(self, action: ScrobbleAction, ref: MediaRef, progress: float = 0.0) -> bool:
        """
        Scrobble the playback (`scrobble/start|pause|stop`). The service marks it watched from `min_progress` at stop and
        at the start of another title (a playing session also at its end by the clock): Kodi's threshold on every call
        (start keeps it with the session).
        """
        if (body := scrobble_body(ref)) is None:
            return False
        return self.post(f'scrobble/{action}', {**body, 'progress': round(float(progress), 2)},
                         params={'min_progress': advanced_settings.watched_percent()}) is not None

    @staticmethod
    def _batch_body(items: Iterable[tuple[MediaRef, JsonData]]) -> dict[str, list[JsonData]]:
        """Return a sync body of the media with the fields of each (`media_body()`; media without external IDs are skipped)."""
        body: dict[str, list[JsonData]] = {}
        for ref, extra in items:
            if (item := media_body(ref, **extra)) is not None:
                body.setdefault(item[0], []).append(item[1])
        return body

    def add_history_refs(self, items: Sequence[tuple[MediaRef, float | None]]) -> bool:
        """
        Mark the media watched (each now or at its time; a show / a season: its aired episodes not watched yet) in one
        write: a watched movie / episode gets one more play (FF sends only the watches of now), one within an hour of a
        stored play is that play ("Already added!": a delivery sent again adds nothing). Return True if every media was found.
        """
        body = self._batch_body((ref, {'status': 'watched', **({'tracked_at': utc_2_iso(at)} if at else {})}) for ref, at in items)
        return bool(body) and all_found(self.post('sync/tracking', {**body, 'allow_rewatch': True}, idempotent=True), 'notFound')

    def add_history_ref(self, ref: MediaRef, *, watched_at: float | None = None) -> bool:
        """Mark the media watched (now or at `watched_at`), see `add_history_refs()`."""
        return self.add_history_refs([(ref, watched_at)])

    def remove_history_refs(self, refs: Sequence[MediaRef]) -> bool:
        """Mark the media unwatched in one write: all their plays (rewatches too) leave the history. Return True if every media was found."""
        body = self._batch_body((ref, {'status': 'watched'}) for ref in refs)
        return bool(body) and all_found(self.post('sync/tracking/remove/all', body, idempotent=True), 'notFound')

    def remove_history_ref(self, ref: MediaRef) -> bool:
        """Mark the media unwatched, see `remove_history_refs()`."""
        return self.remove_history_refs([ref])

    def set_playback_refs(self, items: Sequence[tuple[MediaRef, float, float]]) -> bool:
        """
        Set the resume points of the media `(ref, progress, paused_at)` in one write (waiting changes: their own time, not
        the delivery one). The service keeps a newer pause (`existing`) and never changes a running session by this write
        (`errored`): after a stop in the player the session of the last `scrobble/start` still plays, a scrobble pause ends
        it. An errored episode comes back with the WeTrakr ID only: it is matched by the fields it echoes (progress, time).
        Return True if every media was found and paused.
        """
        fields = {ref: {'status': 'paused', 'progress': round(float(progress), 2), 'paused_at': utc_2_iso(at)} for ref, progress, at in items}
        if not (body := self._batch_body(fields.items())):
            return False
        if (res := self.post('sync/tracking', body, idempotent=True)) is None:
            return False
        ok = all_found(res, 'notFound')
        errored = [entry for entries in (res.get('errored') or {}).values() if isinstance(entries, list) for entry in entries if isinstance(entry, dict)]

        def echoes(entry: JsonData, ref: MediaRef, sent: JsonData) -> bool:
            """Return True if the errored entry is the media: its echoed fields (and IDs, if any) are the sent ones."""
            ids = dict(ref.video_ids.ids())
            return all(entry.get(key) == value for key, value in sent.items()) and entry.get('ids', ids) == ids

        for ref, sent in fields.items():
            if any(echoes(entry, ref, sent) for entry in errored):
                ok = self.scrobble_ref('pause', ref, sent['progress']) and ok
        return ok

    def set_playback_ref(self, ref: MediaRef, progress: float, *, paused_at: float) -> bool:
        """Set the resume point of the media paused at `paused_at`, see `set_playback_refs()`."""
        return self.set_playback_refs([(ref, progress, paused_at)])

    def remove_playback_ref(self, ref: MediaRef) -> bool:
        """Remove the resume point: cancel the playback session of the media (no play is logged)."""
        if (body := scrobble_body(ref)) is None:
            return False
        return self.delete('scrobble/playing', body) is not None

    # --- Sync (`lib.ff.sync`) ---

    def sync_activities(self) -> dict[SyncBucket, str] | None:
        """Return cursors of the sync buckets of the account (`lib.ff.sync`), None on failure."""
        if not isinstance(data := self.get('sync/last_activities'), dict):
            return None
        return {bucket: max(values) for bucket, keys in SYNC_BUCKETS.items()
                if (values := [str(value) for section, key in keys if (value := (data.get(section) or {}).get(key))])}

    def sync_bucket(self, bucket: SyncBucket, cursor: str | None = None) -> bool | None:
        """Get the bucket data (whole compact lists) and store rows of the account. Return True if changed, None on failure."""
        assert self.account is not None  # sync is login required
        account_id = self.account.id
        movie = bucket.endswith('.movie')
        target = 'movies' if movie else 'episodes'
        if bucket.startswith('progress.'):
            if (rows := self.compact(f'sync/tracking/playing/{target}')) is None:
                return None
            plays = [pb for row in rows if (pb := self._playback_row(row))]
            return update_track_playback(plays, account_id=account_id, media_type='movie' if movie else 'show',
                                         removed_at=self._local_time(cursor_time(cursor)))
        if (rows := self.compact(f'sync/tracking/watched/{target}')) is None:
            return None
        plays = [MediaPlayInfo(ref=ref, play_count=int(row.get('plays') or 1),
                               last_watched_at=iso_timestamp(row.get('last_watched_at') or row.get('watched_at')) or 0)
                 for row in rows if (ref := row_ref(row)) is not None]
        if movie:
            return update_track_watched_movies(plays, account_id=account_id, removed_at=cursor_time(cursor))
        return update_track_watched_episodes(plays, account_id=account_id, removed_at=cursor_time(cursor))

    def _playback_row(self, row: JsonData) -> MediaPlayInfo | None:
        """Return the playback row of a `playing` list row (its progress and pause time), None without a reference or a progress."""
        playback = row.get('playback') or row
        if (ref := row_ref(row)) is None or not (progress := float(playback.get('progress_percent') or 0)):
            return None
        runtime = playback.get('runtime_seconds')
        return MediaPlayInfo(ref=ref, progress=progress, paused_at=self._local_time(iso_timestamp(playback.get('tracked_at') or row.get('tracked_at'))),
                             duration=int(runtime) if runtime else None)

    def _changed(self, name: str) -> None:
        """Mark the cached list `name` (with its sub-lists) of the account as changed (an own change)."""
        mark_stale(self.scope, name)

    # --- Lists of the account: watchlist (`planning`), favorites, own lists ---

    def _titles(self, name: str, fetch: Callable[[], list[JsonData] | None], *, bucket: str = '', kind: str | None = None,
                media: MediaOrPersonType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """
        Return the page of the list `name` (all items without `page`) from the list cache, only the `media` if given;
        the items carry their data in the list (`list_entry`). A `kind` makes it a general list (the scope is the type).
        """
        from ..ff.listcache import FetchedList, cached_list
        from ..defs import ItemList

        def fetched() -> FetchedList | None:
            if (rows := fetch()) is None:
                return None
            return FetchedList([(row_ref(row), row) for row in rows])

        stored = cached_list('wetrakr' if kind else self.scope, name, fetched, bucket=bucket, kind=kind)
        rows = [] if stored is None else [(ref, row) for row in stored.items if (ref := row_ref(row)) and (not media or ref.type == media)]
        if not page:
            return ItemList.single([self._list_item(row, ref) for ref, row in rows])
        size = const.indexer.wetrakr.page_size
        return ItemList([self._list_item(row, ref) for ref, row in rows[(page - 1) * size:page * size]], page=page, page_size=size,
                        total_pages=(len(rows) + size - 1) // size, total_results=len(rows))

    @classmethod
    def _list_item(cls, row: JsonData, ref: MediaRef | None = None) -> FFItem | None:
        """Return the item of a list row with its data in the list (`list_entry`), None without a reference."""
        from ..ff.item import FFItem
        if ref is None and (ref := row_ref(row)) is None:
            return None
        it = FFItem(ref)
        it.list_entry = cls._list_entry(row)
        return it

    @staticmethod
    def _list_entry(row: JsonData) -> ListEntry | None:
        """Return the data of the item in its list (a list: added, rank; the watchlist `planning`: tracked; favorites), None if none."""
        from ..ff.item import ListEntry
        # a list row has `list_item_created_at` (the docs: `list_item_added_at`)
        return ListEntry.new(added_at=row.get('list_item_created_at') or row.get('list_item_added_at') or row.get('tracked_at') or row.get('favorited_at'),
                             rank=row.get('list_item_rank', row.get('rank')))

    def _compact_titles(self, path: str, *, extra: Sequence[str] = ()) -> list[JsonData] | None:
        """
        Return the movies and the shows of a compact list of the account (`<base>/<path>/movies` + `…/shows`; the base: its own
        `sync` or `users/<user>` of a public account), newest first, None on failure. The `extra` targets (e.g. `people`) are
        added if they can be read, their failure does not drop the titles.
        """
        base, auth = self._base()
        rows: list[JsonData] = []
        for target in ('movies', 'shows', *extra):
            if (part := self.compact(f'{base}/{path}/{target}', auth=auth)) is None:
                if target in extra:
                    continue
                return None
            rows.extend(part)
        return sorted(rows, key=lambda row: str(row.get('tracked_at') or row.get('favorited_at') or ''), reverse=True)

    def watchlist(self, *, media: MainMediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the watchlist (`planning`) of the account: movies and shows, newest first."""
        return self._titles('watchlist', lambda: self._compact_titles('tracking/planning'), bucket='lists.watchlist', media=media, page=page)

    def favorites(self, *, media: MediaOrPersonType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the favorites of the account (movies, shows and persons)."""
        return self._titles('favorites', lambda: self._compact_titles('favorites', extra=('people',)), bucket='lists.favorites', media=media, page=page)

    def list_items(self, list_id: int | str, *, media: MediaOrPersonType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the titles (and persons) of an own list of the account (its order)."""
        if self.public_user:  # a list of another user: the public items
            return self._titles(f'user/{list_id}', lambda: self._list_rows(f'lists/{list_id}/items/all', auth=False), media=media, page=page)
        return self._titles(f'user/{list_id}', lambda: self._list_rows(f'sync/lists/{list_id}/items'), bucket='lists.user', media=media, page=page)

    def _list_rows(self, path: str, *, auth: bool = True) -> list[JsonData] | None:
        """Return all compact rows of a list in its order, None on failure."""
        return None if (rows := self.compact(path, auth=auth)) is None else ranked(rows)

    def user_lists(self) -> list[FFItem]:
        """Return the own lists of the account (folders with `list_id`, read by `ListTarget.from_ffitem()`); a locked one is marked."""
        from ..ff.listcache import FetchedList, cached_list

        def fetch() -> FetchedList | None:
            base, auth = self._base()
            if not isinstance(data := self.get(f'{base}/lists', params=LISTS_PARAMS, auth=auth), list):
                return None
            return FetchedList([(None, it) for it in data if isinstance(it, dict) and it.get('id')])

        stored = cached_list(self.scope, 'user', fetch, bucket='' if self.public_user else 'lists.user')
        return [] if stored is None else [list_item(it) for it in stored.items]

    def liked_lists(self) -> list[FFItem]:
        """Return the public lists the user liked (folders with `list_id`), newest first."""
        from ..ff.listcache import FetchedList, cached_list

        def fetch() -> FetchedList | None:
            if not isinstance(data := self.get('sync/likes/lists', params=LISTS_PARAMS), list):
                return None
            return FetchedList([(None, it['list']) for it in data if isinstance(it, dict) and isinstance(it.get('list'), dict)])

        stored = cached_list(self.scope, 'user/likes', fetch, bucket='lists.user')  # a like moves `lists.user`
        return [] if stored is None else [list_item(it) for it in stored.items]

    @staticmethod
    def _body(items: Iterable[FFRef], *, people: bool = False, **extra: Any) -> JsonData:
        """Return the sync body of movies and shows (`movies`, `shows`), persons too if `people`; other media are skipped, `extra` to every item."""
        body: dict[str, list[JsonData]] = {}
        for it in items:
            ref = it.ref
            if ((ref.is_movie or (ref.type == 'show' and ref.season is None) or (people and ref.type == 'person'))
                    and (part := media_body(ref, **extra))):
                key, item = part
                body.setdefault(key, []).append(item)
        return body

    @staticmethod
    def _count(res: JsonResult | None, key: str) -> int:
        """Return the number of changed items of a sync answer (`added` / `removed` totals or counts per target)."""
        if not isinstance(res, dict) or not isinstance(counts := res.get(key), dict):
            return 0
        if isinstance(total := counts.get('total'), int):
            return total
        return sum(n for value in counts.values() for n in (value.values() if isinstance(value, dict) else [value]) if isinstance(n, int))

    def set_watchlist(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) movies / shows to the watchlist (`planning`) or remove them, return the number of changed ones."""
        if not (body := self._body(items, status='planning')):
            return 0
        res = self.post('sync/tracking' if state else 'sync/tracking/remove', body)
        self._changed('watchlist')
        return self._count(res, 'added' if state else 'removed')

    def set_favorites(self, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) movies / shows / persons to the favorites or remove them, return the number of changed ones."""
        if not (body := self._body(items, people=True)):
            return 0
        res = self.post('sync/favorites' if state else 'sync/favorites/remove', body)
        self._changed('favorites')
        return self._count(res, 'added' if state else 'removed')

    def set_in_list(self, list_id: int | str, items: Iterable[FFRef], state: bool) -> int:
        """Add (`state`) movies / shows / persons to an own list or remove them, return the number of changed ones."""
        if not (body := self._body(items, people=True)):
            return 0
        res = self.post(f'sync/lists/{list_id}/items' if state else f'sync/lists/{list_id}/items/remove', body)
        self._changed(f'user/{list_id}')
        self._changed('user')  # the item counts
        return self._count(res, 'added' if state else 'removed')

    def create_list(self, name: str, *, public: bool = False) -> int | None:
        """Create an own list (private unless `public`), return its ID; over the plan quota: a message, None."""
        resp = self.request('POST', 'sync/lists', json={'name': name, 'privacy': 'public' if public else 'private'})
        if resp is not None and resp.status_code == 420:  # the plan quota (free: 5 lists)
            from ..ff.ui import ui
            message = str((self._error(resp) or {}).get('message') or L(32936, 'WeTrakr: the limit of lists of the plan is reached'))
            ui.notify(self.account.label if self.account else 'WeTrakr', message, error=True)
            return None
        if not isinstance(data := self._json(resp), dict) or not data.get('id'):
            return None
        self._changed('user')
        return int(data['id'])

    def delete_list(self, list_id: int | str) -> bool:
        """Delete an own list (with its items)."""
        ok = self.delete(f'sync/lists/{list_id}') is not None
        self._changed(f'user/{list_id}')
        self._changed('user')
        return ok

    def rename_list(self, list_id: int | str, name: str) -> str | None:
        """Rename an own list, return its ID, None on failure (e.g. a name over 100 characters)."""
        data = self._json(self.request('PUT', f'sync/lists/{list_id}', json={'name': name}))
        self._changed('user')
        return str(list_id) if isinstance(data, dict) and data.get('id') else None

    # --- Ratings: 0-10 with one decimal ---

    def ratings(self, refs: Iterable[FFRef] | None = None) -> Mapping[MediaRef, float]:
        """Return the ratings of the account by media (movies, shows, seasons, episodes; from the list cache), only of the media `refs` if given."""
        from ..ff.listcache import FetchedList, cached_list

        def fetch() -> FetchedList | None:
            base, auth = self._base()
            if (rows := self.compact(f'{base}/ratings/all', auth=auth)) is None:
                return None
            return FetchedList([(row_ref(row), row) for row in rows])

        def rating(row: JsonData) -> float | None:
            value = row.get('rating', (row.get('user_rating') or {}).get('rating'))  # own compact rows / rows of another user
            return None if value is None else float(value)

        stored = cached_list(self.scope, 'rated', fetch, bucket='' if self.public_user else 'ratings')
        if stored is None:
            return {}
        return pick_ratings({ref: value for row in stored.items if (ref := row_ref(row)) is not None and (value := rating(row)) is not None}, refs)

    def rated(self, *, media: MediaType | None = None, page: int | None = None) -> ItemList[FFItem]:
        """Return the rated media of the account (FF items with the user rating), newest first."""
        from ..ff.item import FFItem
        from ..defs import ItemList
        assert self.RATING is not None
        items = []
        for ref, rating in self.ratings().items():
            if not media or ref.real_type == media:
                it = FFItem(ref)
                it.vtag.setUserRating(self.RATING.from_service_rating(rating))
                items.append(it)
        if not page:
            return ItemList.single(items)
        size = const.indexer.wetrakr.page_size
        return ItemList(items[(page - 1) * size:page * size], page=page, page_size=size, total_pages=(len(items) + size - 1) // size,
                        total_results=len(items))

    def _rating_body(self, items: Iterable[FFRef], **extra: Any) -> JsonData:
        """Return the body of `sync/ratings[/remove]`: every media type, seasons / episodes nested in their shows by numbers."""
        body: dict[str, list[JsonData]] = {}
        for it in items:
            if part := media_body(it.ref, **extra):
                key, item = part
                body.setdefault(key, []).append(item)
        return body

    def set_ratings(self, items: Iterable[FFRef], rating: float | None) -> int:
        """Rate (`rating`) the media or remove their ratings (None), return the number of changed ones."""
        body = self._rating_body(items, **({} if rating is None else {'rating': round(float(rating), 1)}))
        if not body:
            return 0
        res = self.post('sync/ratings' if rating is not None else 'sync/ratings/remove', body)
        self._changed('rated')
        return self._count(res, 'added' if rating is not None else 'removed')

    # --- General lists: community data, with the token of the first account (limits per user) ---

    #: General lists: name -> (endpoint, the TTL kind of the list cache). The counted ones are of the last 7 days, rankings
    #: (`discover/ranks/…`, recomputed daily) of all time; `{media}` / `{medias}` in the endpoint: `movie` / `movies`.
    GENERAL: ClassVar[Mapping[str, tuple[str, str]]] = {
        'trending': ('discover/trending', 'trending'),
        'popular': ('discover/popular', 'trending'),
        'watched': ('discover/watched', 'trending'),
        'planning': ('discover/planning', 'trending'),
        'favorited': ('discover/favorited', 'trending'),
        'listed': ('discover/listed', 'trending'),
        'toprated': ('discover/toprated', 'discover'),
        'last': ('discover/last', 'trending'),
        'rank-best': ('discover/ranks/best-{media}', 'discover'),
        'rank-top-rated': ('discover/ranks/top-rated-{medias}', 'discover'),
        'rank-most-rated': ('discover/ranks/most-rated-{medias}', 'discover'),
        'rank-most-watched': ('discover/ranks/most-watched-{medias}', 'discover'),
        'rank-most-planned': ('discover/ranks/most-planned-{medias}', 'discover'),
    }

    def general_list(self, name: str, *, media: MainMediaType, page: int = 1) -> ItemList[MediaRef]:
        """Return a page of a general list of WeTrakr (movies or shows), through the list cache (the scope is the type)."""
        path, kind = self.GENERAL[name]
        return self._general_page(path.format(media=media, medias=f'{media}s'), {'filter_type': media}, kind=kind, page=page, make=row_ref)

    def general_lists(self, name: str, *, page: int = 1) -> ItemList[FFItem]:
        """Return a page of public lists of a general list (`trending`, `popular`, `last` of `GENERAL`) as folders."""
        return self._general_page(self.GENERAL[name][0], {'filter_type': 'list', **LISTS_PARAMS}, kind='lists', page=page, make=list_item)

    def search_lists(self, query: str, *, page: int = 1) -> ItemList[FFItem]:
        """Return a page of public lists found by the text as folders."""
        return self._general_page('search', {'filter_type': 'list', 'q': query, **LISTS_PARAMS}, kind='search', page=page, make=list_item)

    def public_list(self, list_id: int | str, *, media: MediaOrPersonType | None = None, page: int = 1) -> ItemList[FFItem]:
        """Return a page of the titles of a public list (of any user, its order, with their data in the list), only the `media` if given."""
        return self._titles(f'list/{list_id}', lambda: self._list_rows(f'lists/{list_id}/items/all', auth=False), kind='lists', media=media, page=page)

    def calendar(self, media: MainMediaType, *, mode: Literal['discover', 'following'] = 'discover', milestone: str = '',
                 ) -> list[tuple[MediaRef, dt_date]]:
        """
        Return the calendar (`const.indexer.tvshows.calendar_range`, at most 31 days) as the titles and their local days,
        the newest first, once each: movies released or episodes aired; `following` - of the titles the user tracks (the token),
        `milestone` - only these episodes (`premiere`, `finale`, …).
        """
        from ..ff.listcache import FetchedList, cached_list, list_params
        today = dt_date.today()
        start, end = (today + timedelta(days=days) for days in sorted(const.indexer.tvshows.calendar_range))
        params = {'start': str(start), 'end': str(min(end, start + timedelta(days=30))), 'mode': mode}
        if milestone:
            params['milestone_in'] = milestone
        path = f'calendar/{media}s'

        def fetch() -> FetchedList | None:
            if not isinstance(data := self.get(path, params=params), dict) or not isinstance(days := data.get('days'), dict):
                return None
            rows = [{'type': 'episode', **row} if media == 'show' else row for day in days.values() for row in day if isinstance(row, dict)]
            return FetchedList([(row_ref(row), row) for row in rows])

        stored = cached_list(self.scope if mode == 'following' else 'wetrakr', path, fetch, params=list_params(**params), kind='trending')
        items = [] if stored is None else [(ref, day) for row in stored.items if (ref := row_ref(row)) and (day := calendar_day(row))]
        days: dict[MediaRef, dt_date] = {}
        for ref, day in sorted(items, key=lambda item: item[1], reverse=True):
            days.setdefault(ref, day)  # a movie of more releases (premiere, digital, ...): its newest day
        return list(days.items())

    def _general_page(self, path: str, params: KwArgs, *, kind: str, page: int, make: Callable[[JsonData], Any]) -> ItemList[Any]:
        """Return a page of the service of a general list (the scope is the type) through the list cache, rows made by `make`."""
        from ..ff.listcache import FetchedList, cached_list, list_params
        from ..defs import ItemList
        size = const.indexer.wetrakr.page_size

        def fetch() -> FetchedList | None:
            resp = self.request('GET', path, params={**params, 'page': page, 'limit': size})
            if not isinstance(data := self._json(resp), list) or resp is None:
                return None
            meta = {'pages': int(resp.headers.get('X-Pagination-Page-Count') or 1), 'total': int(resp.headers.get('X-Pagination-Item-Count') or len(data))}
            return FetchedList([(row_ref(row), row) for row in data if isinstance(row, dict)], meta=meta)

        stored = cached_list('wetrakr', path, fetch, params=list_params(**params), kind=kind, page=page)
        if stored is None:
            return ItemList.empty()
        meta = stored.row.meta
        items = [it for row in stored.items if (it := make(row)) is not None]
        return ItemList(items, page=page, page_size=size, total_pages=int(meta.get('pages') or 1), total_results=int(meta.get('total') or len(items)))

    @staticmethod
    def _error(resp: requests.Response) -> JsonData | None:
        """Return the JSON error of an answer, None if it is not one."""
        try:
            data = resp.json()
        except ValueError:
            return None
        return data if isinstance(data, dict) else None


#: Client of the type alias (the first WeTrakr account).
wetrakr: WeTrakrApi = WeTrakrApi(alias='wetrakr')
#: Application client (general lists): the first active WeTrakr account with a token (its limits, not the app key ones).
wetrakr_app: WeTrakrApi = WeTrakrApi()


def make_client(account: Account | None) -> WeTrakrApi:
    """Return the client of the account (`ServiceType.client`), the module client (the type alias) for None."""
    return wetrakr if account is None else WeTrakrApi(account)

