"""Some stuff to do berfore main() is called."""

import atexit
import gc
from const import const


if const.debug.autoreload:
    from .service.reload import ReloadMonitor
    reload_monitor = ReloadMonitor()  # the sources of FanFilm (`source_files()`), as the service watches them
else:
    reload_monitor = None


def cleanup():
    gc.unfreeze()  # first: the objects frozen by collect_garbage() are collected at the interpreter end
    import xbmc
    from lib.ff import settings as settings_module
    from lib.ff.menu import KodiDirectory
    xbmc.log('------- FF3: cleanup()', xbmc.LOGDEBUG)
    KodiDirectory.set_current_info(None, None)  # force clean
    if settings_module.settings:
        settings_module.settings._addon = None
    settings_module.settings = None


atexit.register(cleanup)  # once per interpreter (the module stays imported in a reused interpreter)


def preinit():
    """Run on begeining, before run count: a changed source ends the interpreter, a changed `local.py` is loaded again."""
    if reload_monitor:
        reload_monitor.check()
    from lib.ff.control import reload_local
    reload_local()  # a reused interpreter (no call runs now) follows `local.py` as the service does


def premain():
    """Run just before main: the style of the windows checked again at its first use in the call (not imported yet: nothing to check)."""
    import sys
    if (style := sys.modules.get('lib.windows.style')) is not None:
        style.recheck_style()
