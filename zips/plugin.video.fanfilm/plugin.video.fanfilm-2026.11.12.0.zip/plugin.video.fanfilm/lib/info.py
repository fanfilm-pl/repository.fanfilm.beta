"""
Simple base info module.

Keep it simple, no global imports, no dependencies.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from xbmc import Monitor


#: Number of plugin calls
run_count: int = 0


def new_run() -> int:
    """Report new call. Return current call count."""
    # zliczaj liczbę wywołań FF
    global run_count
    # if not run_count:
    #     from .ff.control import pretty_log_info
    #     pretty_log_info()
    if run_count is not False:
        run_count += 1
    return run_count


def exec_id(*, highlight: str = '') -> str:
    """Return execute id."""
    import sys
    import os
    import threading
    iid = id(sys.implementation)
    iid = ((iid >> 48) ^ (iid >> 32) ^ (iid >> 16) ^ iid) & 0xffff
    pid = os.getpid()
    tid = threading.get_ident()
    if run_count is None or run_count is False:
        return f'{iid:04x}:{pid}:{tid}'
    off = '\033[0m' if highlight else ''
    return f'{iid:04x}:{pid}:{tid}:{highlight}{run_count}{off}'


#: Kodi monitor of the current plugin call, see watch_abort().
script_monitor: Monitor | None = None


def watch_abort() -> None:
    """
    Start watching Kodi abort of the current plugin call. Call it as early as possible.

    Kodi (K21, K22) aborts a plugin call (e.g. Back on its busy dialog while it resolves a play) only by notifying
    the monitors which exist at that moment (CPythonInvoker::stop -> AbortNotification), a monitor created later
    never sees it. There is no other signal for the script.
    """
    global script_monitor
    from xbmc import Monitor
    script_monitor = Monitor()  # first, before the imports below
    from .sdk.threads import inherit_thread_scopes, watch_sockets
    from .sdk.net import share_tls_contexts
    inherit_thread_scopes()
    watch_sockets()
    share_tls_contexts()  # one TLS context of the interpreter, not one with the CA bundle loaded for every connection


def unwatch_abort() -> None:
    """Release the monitor, a Kodi object must not be kept between calls or left at the interpreter exit."""
    global script_monitor
    script_monitor = None


def script_aborted() -> bool:
    """Return True if Kodi aborted the current plugin call, then it does not wait for its result any more."""
    if script_monitor is not None and script_monitor.abortRequested():
        return True
    from .ff.control import current_call
    return current_call().is_set()  # a call in the service: its thin plugin got the abort
