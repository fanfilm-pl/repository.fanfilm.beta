
#: Service flag
#: - True if service process (sets at beginning of service.py)
#: - False if plugin process
SERVICE: bool = False
