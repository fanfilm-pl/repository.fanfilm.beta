# -*- coding: utf-8 -*-
"""
FanFilm - źródło: streamimdb.me / cloudnestra (PlayIMDB)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Flow:
  movie/tvshow  → IMDB ID (str)
  episode()     → playimdb://{imdb}/{season}/{episode}
  sources()     → wewnętrzny URL, bez HTTP, jakość zakładana 1080p
  resolve()     → 3 HTTP: embed → /rcp/ → /prorcp/ → m3u8 + napisy
                  pobiera pliki napisów, ustawia 'source.subtitles' w Kodi
"""

from __future__ import annotations

import json
import re
import socket
import tempfile
import threading
from typing import ClassVar, List, TYPE_CHECKING
from typing_extensions import TypedDict
from urllib.parse import urlparse

from lib.ff import requests, control
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sources import SourceItem, SourceTitleAlias


class SubtitleItem(TypedDict):
    """Subtitle track from cloudnestra /prorcp/ page."""
    label: str
    src: str


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    priority: ClassVar[int] = 100
    language: ClassVar[List[str]] = ['en', 'pl']

    ffitem: FFItem

    _MOVIE_URL  = 'https://streamimdb.me/embed/{imdb}'
    _TV_URL     = 'https://streamimdb.me/embed/tv?imdb={imdb}&season={season}&episode={episode}&color=e600e6'
    _RCP_URL    = 'https://cloudnestra.com/rcp/{hash}'
    _PRORCP_URL = 'https://cloudnestra.com/prorcp/{hash}'
    _CDN_DOMAIN = 'cloudnestra.com'

    _BASE_HEADERS: dict[str, str] = {
        'User-Agent': DEFAULT_UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    def __init__(self):
        self._session: requests.Session | None = None

    @property
    def session(self) -> requests.Session:
        if self._session is None:
            self._session = requests.Session()
            self._session.headers.update(self._BASE_HEADERS)
        return self._session

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> str | None:
        return imdb or None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: list[SourceTitleAlias], year: str) -> str | None:
        return imdb or None

    def episode(self, url: str | None, imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> str | None:
        if not url:
            return None
        return f'playimdb://{url}/{season}/{episode}'

    def sources(self, url: str | None, hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        if not url:
            return []
        return [{
            'source': 'cloudnestra',
            'quality': '1080p',
            'language': 'en',
            'url': url,
            'info': 'NAPISY',
            'direct': False,
            'debridonly': False,
        }]

    def resolve(self, url: str) -> str | None:
        try:
            imdb, season, episode = self._parse_url(url)
            video_urls, subtitles = self._get_full_source_data(imdb, season, episode)

            reachable = [v for v in video_urls if self._is_dns_ok(v)]
            if not reachable:
                fflog(f'no reachable CDN URL for {imdb!r}')
                return None

            final_url = reachable[0]

            if subtitles:
                self._download_and_set_subtitles(subtitles)

            fflog(f'resolved: {final_url[:80]} ({len(subtitles)} sub track(s))')
            return final_url
        except Exception:
            fflog_exc()
            return None

    # ── helpers ────────────────────────────────────────────────────────────

    def _parse_url(self, url: str) -> tuple[str, int | None, int | None]:
        """Parse playimdb://{imdb}/{season}/{episode} or bare IMDB ID."""
        if url.startswith('playimdb://'):
            url = url[len('playimdb://'):]
        parts = url.split('/')
        if len(parts) == 3:
            return parts[0], int(parts[1]), int(parts[2])
        return parts[0], None, None

    def _fetch_data_hash(self, imdb: str, season: int | None, episode: int | None) -> str:
        """GET embed page → return data-hash attribute."""
        if season is not None:
            url = self._TV_URL.format(imdb=imdb, season=season, episode=episode)
            extra = {
                'Referer': f'https://streamimdb.me/embed/{imdb}',
                'Sec-Fetch-Dest': 'iframe',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
            }
        else:
            url = self._MOVIE_URL.format(imdb=imdb)
            extra = {
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
            }
        r = self.session.get(url, headers=extra)
        r.raise_for_status()
        m = re.search(r'data-hash="([^"]+)"', r.text)
        if not m:
            raise ValueError(f'No data-hash on embed page for {imdb!r}')
        return m.group(1)

    def _fetch_prorcp_hash(self, data_hash: str) -> str:
        """GET cloudnestra /rcp/ → return embedded /prorcp/ hash."""
        r = self.session.get(self._RCP_URL.format(hash=data_hash), headers={
            'Referer': 'https://streamimdb.me/',
            'Sec-Fetch-Dest': 'iframe',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'cross-site',
        })
        r.raise_for_status()
        m = re.search(r"src:\s*'/prorcp/([^']+)'", r.text)
        if not m:
            raise ValueError('No /prorcp/ hash in cloudnestra /rcp/ response')
        return m.group(1)

    def _fetch_player_file(self, prorcp_hash: str) -> tuple[str, list[SubtitleItem]]:
        """GET cloudnestra /prorcp/ → return (Playerjs file string, subtitle list)."""
        r = self.session.get(self._PRORCP_URL.format(hash=prorcp_hash), headers={
            'Referer': 'https://cloudnestra.com/',
            'Sec-Fetch-Dest': 'iframe',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
        })
        r.raise_for_status()
        m = re.search(r'file:\s*"([^"]+)"', r.text)
        if not m:
            raise ValueError('No Playerjs file string in cloudnestra /prorcp/ response')
        file_str = m.group(1)

        subtitles: list[SubtitleItem] = []
        sub_m = re.search(r'var sub_langs\s*=\s*(\[[^\]]*\])', r.text)
        if sub_m:
            for item_m in re.finditer(r'\{([^}]+)\}', sub_m.group(1)):
                lm = re.search(r'label\s*:\s*["\']([^"\']*)["\']', item_m.group(1))
                sm = re.search(r'src\s*:\s*["\']([^"\']*)["\']', item_m.group(1))
                if lm and sm:
                    subtitles.append({'label': lm.group(1), 'src': sm.group(1)})
        return file_str, subtitles

    def _extract_video_urls(self, file_str: str) -> list[str]:
        """Resolve {v1}…{v5} CDN placeholders, return deduplicated URLs."""
        seen: set[str] = set()
        urls: list[str] = []
        for template in file_str.split(' or '):
            url = re.sub(r'\{v\d+\}', self._CDN_DOMAIN, template.strip())
            if url not in seen:
                seen.add(url)
                urls.append(url)
        return urls

    def _get_full_source_data(self, imdb: str, season: int | None,
                              episode: int | None) -> tuple[list[str], list[SubtitleItem]]:
        """3-step chain: embed → /rcp/ → /prorcp/. Returns (urls, subtitles)."""
        try:
            data_hash = self._fetch_data_hash(imdb, season, episode)
            prorcp_hash = self._fetch_prorcp_hash(data_hash)
            file_str, subtitles = self._fetch_player_file(prorcp_hash)
            return self._extract_video_urls(file_str), subtitles
        except requests.HTTPError as e:
            fflog(f'HTTP error for {imdb!r}: {e}')
            return [], []

    @staticmethod
    def _is_dns_ok(url: str) -> bool:
        """Return True if the URL's hostname resolves to an IPv4 address."""
        try:
            hostname = urlparse(url).hostname or ''
            for r in socket.getaddrinfo(hostname, None, socket.AF_UNSPEC):
                if r[0] == socket.AF_INET:
                    return True
        except socket.gaierror:
            pass
        return False

    def _download_and_set_subtitles(self, subtitles: list[SubtitleItem]) -> None:
        """Download SRT subtitle files in parallel, set 'source.subtitles' window property."""
        temp_dir = tempfile.mkdtemp(prefix='playimdb_subs_')
        results: list[str] = []
        lock = threading.Lock()

        def _dl(sub: SubtitleItem) -> None:
            try:
                r = self.session.get(sub['src'], timeout=8)
                if r.status_code == 200 and r.text.strip():
                    label = re.sub(r'[^\w\-]', '_', sub.get('label', 'sub'))
                    path = f'{temp_dir}/{label}.srt'
                    with open(path, 'w', encoding='utf-8') as fh:
                        fh.write(r.text)
                    with lock:
                        results.append(path)
            except Exception:
                pass

        threads = [threading.Thread(target=_dl, args=(s,), daemon=True) for s in subtitles]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=12)

        if results:
            try:
                control.window().setProperty('source.subtitles', json.dumps(results))
                fflog(f'{len(results)} subtitle(s) set for player')
            except Exception as e:
                fflog(f'subtitles property error: {e}')


if __name__ == '__main__':
    try:
        from lib.ff.cmdline import DebugArgumentParser as ArgumentParser
    except ImportError:
        from argparse import ArgumentParser
    parser = ArgumentParser(description='Test PlayIMDB source provider')
    parser.add_argument('imdb_id', help='IMDB ID, e.g. tt1392214 or tt1392214/1/3')
    args = parser.parse_args()
    src = source()
    try:
        from pprint import pprint
        sources = src.sources(args.imdb_id, [], [])
        result = src.resolve(sources[0]['url']) if sources else None
        pprint({'sources': sources, 'resolved': result})
    except Exception as e:
        print(f'Error: {e}')
