# -*- coding: utf-8 -*-
"""
FanFilm - źródło: kinoteka.cc
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
from typing import Any, Optional, List, Dict, TYPE_CHECKING, ClassVar
from typing_extensions import TypedDict
import re
import urllib.parse
import json

from attrs import frozen, asdict
from lib.ff import requests
from lib.ff import source_utils
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA, get_original_title, prepare_alias_search_list
from lib.ff.log_utils import fflog

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias


@frozen
# ─── _ShowData ───────────────────────────────────────────────────────────────────
class _ShowData:
    title: str
    local_title: str
    aliases: list
    year: int
    show_url: str  # URL znaleziony w tvshow(), używany w episode()


class _KinotekaShowDict(TypedDict):
    """Serialised _ShowData dict passed between tvshow() and episode()."""
    title: str
    local_title: str
    aliases: list[SourceTitleAlias]
    year: int
    show_url: str


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self):
        self.base_url = 'https://kinoteka.cc'

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        titles = [localtitle, get_original_title(aliases), title]
        results, session = self._search('movie', titles, prepare_alias_search_list(aliases, year), year)

        if not results:
            # fflog('no results')
            return None

        video_url = results[0]['link']
        # fflog(f'movie found: {video_url}')

        video_sources = self._get_video_sources(session, video_url)

        if not video_sources:
            # fflog('no video sources')
            return None

        return video_sources

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> _KinotekaShowDict | None:
        titles = [localtvshowtitle, get_original_title(aliases), tvshowtitle]
        results, session = self._search('tvshow', titles, prepare_alias_search_list(aliases, year), year)

        if not results:
            # fflog('no results for tvshow')
            return None

        show_url = results[0]['link']
        # fflog(f'tvshow found: {show_url}')

        return asdict(_ShowData(
            title=tvshowtitle,
            local_title=localtvshowtitle,
            aliases=aliases,
            year=year,
            show_url=show_url
        ))

    def episode(self, url: _KinotekaShowDict | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[list[SourceItem]]:
        # fflog(f'received URL in episode: {url}')
        if not isinstance(url, dict) or 'show_url' not in url:
            # fflog('invalid URL format for episode')
            return None

        show_url = url['show_url']
        # fflog(f'fetching tvshow page: {show_url}')

        session = requests.Session()
        session.headers.update({
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': DEFAULT_UA
        })

        response = session.get(show_url)
        if not response:
            # fflog(f'failed to fetch tvshow page: {show_url}, {response=}')
            return None

        html_content = response.text

        # Pattern to find episode data JSON
        episodes_json_pattern = re.compile(r'const episodes = (?P<json_data>{.+?});', re.DOTALL)
        json_match = episodes_json_pattern.search(html_content)

        if not json_match:
            # fflog('episode JSON data not found')
            return None

        episodes_data_str = json_match.group('json_data')
        try:
            all_episodes_data = json.loads(episodes_data_str)
        except json.JSONDecodeError:  # as e:
            # fflog(f'episode JSON decode error: {e}')
            return None

        # Season and episode must be strings for JSON dict keys
        season_str = str(season)
        episode_str = str(episode)

        if season_str not in all_episodes_data or episode_str not in all_episodes_data[season_str]:
            # fflog(f'episode S{season_str}E{episode_str} not found in JSON data')
            return None

        episode_sources_data = all_episodes_data[season_str][episode_str]

        sources = []
        for src_data in episode_sources_data:
            sources.append({
                'source': src_data['host_name'],
                'quality': 'SD' if src_data['quality'] == '480p' else src_data['quality'],
                'language': 'pl',
                'url': src_data['embed_code'],
                'info': src_data.get('version', ''),
                'direct': False,
                'debridonly': False,
                'premium': False,
            })
        # fflog(f'found {len(sources)} sources for S{season_str}E{episode_str}')
        return sources

    def sources(self, url: Optional[list[SourceItem]], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        sources = []
        if not url:
            # fflog(f'no sources')
            return sources

        for u in url:
            # Skip gdrive sources
            if u.get('source', '').lower() == 'gdrive':
                continue

            info = u.get('info', '')
            info = re.sub(r'lektor pl', 'lektor', info, flags=re.IGNORECASE)

            sources.append({
                'source': u['source'],
                'quality': u['quality'],
                'language': 'pl',
                'url': u['url'],
                'info': info,
                'direct': False,
                'debridonly': False,
                'premium': False,
            })

        # fflog(f'sources: {len(sources)}')
        return sources

    def resolve(self, url: str) -> Optional[str]:
        # URL already contains the full iframe address
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _search(self, content_type, titles, aliases=None, year=''):
        """Search for items by the given phrase."""
        if aliases is None:
            aliases = []

        if isinstance(titles, str):
            titles = [titles]

        titles = list(dict.fromkeys(titles))

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': DEFAULT_UA
        }

        with requests.Session() as session:
            session.headers.update(headers)

            # Pattern for movie-card
            pattern = re.compile(
                r'<div class="movie-card" onclick="window\.location\.href=\'(?P<link>watch\.php\?film=[^\']+)\'">.*?'
                r'<div class="quality-badge quality-(?P<quality>[\w-]+)">(?P<quality_val>[^<]+)</div>.*?'
                r'<div class="movie-title">(?P<title>[^<]+)</div>.*?'
                r'<div class="movie-meta">\s*<span>(?P<year>\d{4})</span>',
                re.DOTALL
            )

            query_titles = []
            for title in titles:
                if not title:
                    continue

                query = title
                query = str.lower(urllib.parse.quote_plus(query))

                if query in query_titles:
                    fflog(f'skip (duplicate): {query=}')
                    continue
                query_titles.append(query)

                fflog(f'query: {query!r}')
                url = f'{self.base_url}/search.php?q={query}'

                response = session.get(url)
                if not response:
                    return [], session

                html_content = response.text
                matches = pattern.finditer(html_content)

                results = [
                    {
                        'title': match.group('title').strip(),
                        'year': match.group('year'),
                        'quality': match.group('quality_val'),
                        'link': f"{self.base_url}/{match.group('link')}",
                    }
                    for match in matches
                ]
                fflog(f'search: {len(results)} results')

                if year:
                    results = [r for r in results if r['year'] == year]

                # Title verification
                results = [
                    r for r in results
                    if r['title'] in titles + aliases
                ]

                if not results:
                    fflog(f'no match for {title=}')

                if results:
                    break

            return results, session

    def _get_video_sources(self, session, video_url):
        """Fetch sources from the film page."""
        response = session.get(video_url)
        if not response:
            # fflog(f'{response=}')
            return []

        html_content = response.text

        sources = []

        # Pattern for film iframes
        iframe_pattern = re.compile(
            r'<div id="player-(\d+)"[^>]*>.*?'
            r'<iframe src=[\'"]([^\'"]+)[\'"]',
            re.DOTALL
        )

        # Pattern for source buttons
        button_pattern = re.compile(
            r'<button onclick="switchSource\((\d+)\)"[^>]*>.*?'
            r'<span class="src-host-name">\s*<i class="fas fa-play"></i>\s*([^<]+?)\s*</span>\s*'
            r'<span class="src-meta-info">\s*([^<]+?)\s*</span>',
            re.DOTALL
        )

        # Pattern for quality
        quality_pattern = re.compile(
            r'<span style="color:#aaa;">Jakość</span> <span[^>]+>(?P<quality>[^<]+)</span>'
        )

        quality_match = quality_pattern.search(html_content)
        quality = quality_match.group('quality') if quality_match else 'SD'
        if quality == '480p':
            quality = 'SD'

        iframes = {match.group(1): match.group(2) for match in iframe_pattern.finditer(html_content)}
        buttons = {
            match.group(1): (match.group(2).strip(), match.group(3).strip())
            for match in button_pattern.finditer(html_content)
        }

        for idx, url in iframes.items():
            host, meta = buttons.get(idx, (f'Source {idx}', ''))
            # Extract version from meta (e.g. "480p • Napisy PL" -> "Napisy PL")
            info = meta.split('•', 1)[1].strip() if '•' in meta else meta
            sources.append({
                'source': host,
                'quality': quality,
                'url': url,
                'info': info
            })

        return sources
