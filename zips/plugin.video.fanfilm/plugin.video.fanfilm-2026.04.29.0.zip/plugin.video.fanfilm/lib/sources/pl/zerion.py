# -*- coding: utf-8 -*-
"""
FanFilm - źródło: zeriun.cc
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
from typing import Any, Optional, List, Dict, TYPE_CHECKING, ClassVar
from typing_extensions import TypedDict
import re
import urllib.parse

from lib.ff import requests
from lib.ff import cache, cleantitle, control
from lib.ff.item import FFItem
from lib.ff.source_utils import year_matches as _year_matches, ShowDataDict
from lib.ff.source_utils import DEFAULT_UA, ShowData, show_data_asdict
from lib.ff.source_utils import get_original_title, prepare_alias_search_list
from lib.ff.log_utils import fflog
# from lib.ff.debug import log_exception

class _ZerionSource(TypedDict, total=False):
    """Intermediate source dict from zerion scraping (episode/movie → sources)."""
    lang: str
    host: str
    quality: str
    data_id: str
    content_type: str
    title: str


if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self):
        self.base_link = 'https://zeriun.cc'

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> list[_ZerionSource] | None:
        # fflog(f'{title=} {localtitle=} {year=} {aliases=}')
        titles = [localtitle, get_original_title(aliases), title]  # this variant may work better
        results, session = self._search('movie', titles, prepare_alias_search_list(aliases, year), year)
        # fflog(f'{results=}')
        return self._get_sources(results, session, 'movie')

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict | None:
        # fflog(f'{tvshowtitle=} {localtvshowtitle=} {aliases=} {year=} {imdb=}')
        # could search for the show title here, but session/cookie handling would be tricky
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, year))

    def episode(self, url: ShowDataDict | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> list[_ZerionSource] | None:
        # first search for the show
        data = ShowData(**url)

        year = data.year
        # year = ""

        tvshowtitle = data.title
        localtvshowtitle = data.local_title
        aliases = data.aliases
        originaltvshowtitle = get_original_title(aliases)
        titles = [localtvshowtitle, originaltvshowtitle, tvshowtitle]  # local title first; original is usually present

        results, session = self._search(
            'series', titles, prepare_alias_search_list(aliases, year), year)  # find the show
        # fflog(f'{results=}')
        # fflog(f'{session=}')  # object

        # now find the season and episode
        if results:
            url = results[0]['link']
            # fflog(f'{url=}')

            video_results = []
            epNo = 's' + season.zfill(2) + 'e' + episode.zfill(2)

            # control.sleep(0.6 * 1000)

            response = session.get(url)
            if not response:
                fflog(f'{response=}')
                return
            html_content = response.text

            pattern = re.compile(r'\s*href="(?P<href>[^"]+)"', re.DOTALL)
            matches = pattern.finditer(html_content)

            for match in matches:
                if epNo in match.group('href'):
                    # fflog(match.group("href"))
                    video_results = [{'link': match.group('href')}]
                    break

            # control.sleep(0.6 * 1000)

            return self._get_sources(video_results, session, 'series')

    def sources(self, url: list[_ZerionSource] | None, hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        # fflog(f'{url}')
        sources = []
        if not url:
            fflog('no sources')
            return sources
        for u in url:
            sources.append({
                'source': u['host'],
                'quality': u['quality'].split('/ ')[-1],
                'language': 'pl' if 'pl' in u['lang'].lower() else '',
                'url': u['data_id'],
                'info': 'lektor' if u['lang'].lower() == 'pl' else 'napisy' if 'sub' in u['lang'].lower() else 'dubbing' if 'dubb' in u['lang'].lower() else '',
                'filename': u.get('title') or '',
                'direct': False,
                'debridonly': False,
                'for_resolve': {'content_type': u['content_type']},
                'premium': False,
            })
        fflog(f'sources: {len(sources)}')
        return sources

    def resolve(self, url: str, content_type: str = '') -> Optional[str]:
        # fflog(f'{url=}')
        # fflog(f'{content_type=}')
        from ast import literal_eval

        some_data = cache.cache_get('zerion', control.providercacheFile)
        some_data = some_data['value']
        some_data = literal_eval(some_data)

        csrf_token = some_data['csrf_token']
        if not content_type:
            content_type = some_data['content_type']

        cookies = cache.cache_value('zerion_cookie', control.providercacheFile, default='')

        session = None
        if not session:
            session = requests.Session()
            pass

        if not cookies:
            response = session.get(self.base_link)
            if not response:
                fflog(f'{response=}')
                return
            html_content = response.text
            csrf_token = re.search(r"var _csrf = '(.*?)';", html_content).group(1)
            cookies = ''

        embed_url = self._get_embed_url(session, url, csrf_token, content_type, cookies)

        # fflog(f'{embed_url=}')
        return embed_url

    # ── helpers ────────────────────────────────────────────────────────────

    def _search(self, content_type, titles, aliases=None, year=''):
        """ search for items by the given phrase """
        # fflog(f'{titles=} {content_type=} {year=}')
        # fflog(f'{aliases=}')
        if aliases is None:
            aliases = []

        if isinstance(titles, str):
            titles = [titles]  # normalise to list for iteration

        # query_titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in query_titles]
        titles = list(dict.fromkeys(titles))  # deduplicate (case-sensitive)
        # fflog(f'{titles=}')

        # Reduced Headers
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': DEFAULT_UA
        }

        with requests.Session() as session:
            # put headers for session
            session.headers.update(headers)

            # Regular expression pattern based on content type (defined before the loop)
            if content_type == 'movie':
                pattern = re.compile(r'<div class="info">.*?<a href="(?P<link>https://zeriun\.cc/film/[^"]+)">.*?<h2 class="title">(?P<title>[^<]+)</h2>'
                                     r'(?:.*?<h3 class="title-original">(?P<title2>[^<]+)</h3>)?', re.DOTALL)
            elif content_type == 'series':
                pattern = re.compile(r'<div class="info">.*?<a href="(?P<link>https://zeriun\.cc/serial/[^"]+)">.*?<h2 class="title">(?P<title>[^<]+)</h2>'
                                     r'(?:.*?<h3 class="title-original">(?P<title2>[^<]+)</h3>)?', re.DOTALL)

            # all_results = []  # probably not needed after all
            query_titles = []
            for title in titles:
                # fflog(f'{title=}')
                if not title:
                    continue

                # encode title
                query = title
                query = cleantitle.normalize(cleantitle.getsearch(query))
                query = str.lower(urllib.parse.quote_plus(query))
                if query in query_titles:
                    fflog(f'skip (duplicate): {query=}')
                    continue
                query_titles.append(query)

                # Base URL
                url = f'{self.base_link}/szukaj?query={query}'
                # fflog(f'{url=}')

                fflog(f'query: {query!r}')
                # Sending the request
                response = session.get(url)
                if not response:
                    fflog(f'{response=}')
                    return [], session
                html_content = response.text

                # fflog(f'{pattern.findall(html_content)=}')  # for debug
                matches = pattern.finditer(html_content)

                # Collecting results
                results = [
                           {
                            'title': match.group('title'),
                            # may be in format "La chica de nieve / The Snow Girl"
                            'title2': (titl2 := (tit2 := match.group('title2') or '').split(' / '))[0],
                            'title3': titl2[1] if len(titl2) > 1 else '',
                            'year': match.group('link').split('/')[-1].split('?')[0][-4:],
                            'link': match.group('link'),
                           }
                           for match in matches]
                fflog(f'search: {len(results)} results')
                # fflog(f'{len(results)=}  {results=}')
                # fflog(f'{(titles + aliases)=}')

                if year:
                    results = [r for r in results if _year_matches(r['year'], int(year), tolerance=1)]
                # fflog(f'{len(results)=}  {results=}')

                # title verification would be useful here
                # fflog( [any(t for t in [r["title"], r["title2"], r["title3"]] if t in titles + aliases) for r in results] )
                results = [r for r in results if (
                                                   any(t for t in [r['title'], r['title2'],
                                                       r['title3']] if t in titles + aliases)
                                                 )]
                # fflog(f'{len(results)=}  {results=}')
                if not results:
                    fflog(f'no match for {title=}')
                    pass

                # all_results += results
                if results:
                    break  # we need exactly 1 result but with a specific link
                    pass

            """
            fflog(f'{len(all_results)=}  {all_results=}')
            if not all_results:
                # fflog(f'nothing found (matching?)')
                pass
            """

            # needed by resolve()
            cookies = session.cookies
            cookies = '; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
            cache.cache_insert('zerion_cookie', cookies, control.providercacheFile)

            return results, session

    def _get_sources(self, video_results, session, content_type):
        # video_sources = None
        if video_results:
            video_url = video_results[0]['link']  # take the first match
            # control.sleep(0.6 * 1000)
            # fetch source list page (actual stream URLs are retrieved via separate API)
            fflog('fetching source list')
            video_sources, csrf_token = self._get_video_sources(session, video_url)
            # fflog(f'{len(video_sources)=}  {video_sources=}')

            # if csrf_token:
            cache.cache_insert('zerion', repr(
                {'csrf_token': csrf_token, 'content_type': content_type}), control.providercacheFile)
            # control.sleep(0.6 * 1000)

            # Updating sources with embed URLs or handling captcha
            # fflog('attempting to "discover" sources')
            for source in video_sources:
                source['content_type'] = content_type
                if content_type == 'series':
                    source['title'] = video_url.split('serial/')[-1].split('/s')[0]
                else:
                    source['title'] = video_url.split('/')[-1].split('?')[0]

        else:
            fflog('no match')
            video_sources = None
        return video_sources

    def _get_video_sources(self, session, video_url):
        # Sending the request
        # fflog(f'{video_url=}')
        response = session.get(video_url)
        if not response:
            fflog(f'{response=}')
            return [], ''
        html_content = response.text
        # fflog(f'{html_content=}')

        # Extract CSRF token from HTML
        csrf_token = re.search(r"var _csrf = '(.*?)';", html_content).group(1)

        sources = []
        # Extracting lang using regular expressions
        pattern_l = re.compile(r'<table data-key="(?P<lang>[^"]+)".+?</table>', re.DOTALL)
        matches_l = pattern_l.finditer(html_content)

        # Extracting sources using regular expressions
        pattern = re.compile(r'<tr>\s*<td>(?P<host>[^<]+)</td>\s*<td>(?P<quality>[^<]+)</td>\s*<td>\s*'
                            r'<div class="btn no-select watch-btn" data-id="(?P<id>[^"]+)">', re.DOTALL)
        # matches = pattern.finditer(html_content)
        for m_l in matches_l:  # for each language separately
            matches = pattern.finditer(m_l[0])
            # Collecting results
            sources += [{'lang': m_l.group('lang'), 'host': match.group('host').strip(), 'quality': match.group(
                'quality').strip(), 'data_id': match.group('id').strip()} for match in matches]

        return sources, csrf_token

    def _get_embed_url(self, session, data_id, csrf_token, content_type, cookies=''):
        if not content_type:
            fflog(f'missing {content_type=}')
            return
        # API URL
        api_url = f'{self.base_link}/api/{content_type}/get-embed'

        # Headers for API request
        headers = {
            'accept': '*/*',
            'accept-language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': self.base_link,
            'user-agent': DEFAULT_UA,
            'x-csrf-token': csrf_token,
        }
        # cookies
        headers.update({'Cookie': cookies})
        # fflog(f'{headers=}')

        # Data payload
        data = {
            'id': data_id
        }

        # Sending the request
        # fflog(f'{api_url=}')
        # if not session:
            # session = requests.Session()
        response = session.post(api_url, headers=headers, data=data)
        if not response:
            fflog(f'{response=}')
            return
        response_json = response.json()
        # fflog(f'{response_json=}')

        # Extracting the URL
        if response_json.get('err') == False:
            if response_json['data'].get('captcha', False):
                fflog(f'{response_json=} !')
                return 'captcha'
            return response_json['data']['url']
        else:
            fflog(f'{response_json=}')
