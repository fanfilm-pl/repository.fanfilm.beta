# -*- coding: utf-8 -*-
"""
FanFilm - źródło: tb7.pl / xt7.pl
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
from typing import Any, Sequence, ClassVar, TYPE_CHECKING
import re
import time
import sys
import hashlib
import json
from html import unescape
from urllib.parse import unquote, quote
from difflib import SequenceMatcher
from datetime import datetime, timedelta
from threading import current_thread, Thread
from concurrent.futures import ThreadPoolExecutor, wait

from lib.sources import IncompleteResult, ProviderModule, Source
from lib.api import kitsu as kitsu_api
from lib.ff import requests
from lib.ff import (
    cleantitle,
    client,
    control,
    source_utils,
)
from lib.ff.source_utils import CHROME_UA, ShowData, ShowDataDict, show_data_asdict, strip_diacritics
from lib.ff.logs import fflog, fflog_exc
from lib.ff.threads import xsleep
from lib.kolang import L
from lib.sources.natives import LOGIN, ProviderSetting, provider_value
from const import const
if TYPE_CHECKING:
    from datetime import date
    from lib.ff.db.sources import ProviderStore
    from lib.ff.item import FFItem
    from lib.sdk.protocol import ResolveResult
    from lib.sources import SourceItem, SourceTitleAlias, SourceSearchOverride


# Constants
COOKIE_EXPIRATION_HOURS = 14 * 24   # each re-login leaves a new live server session (its cookie lives 30 days)
NOTES_MAX_SIZE = 4800

# Markers that appear only on a logged-in page (never on the public/login pages).
# 'yloguj' is the "Wyloguj" (logout) link stem - matched loosely so link format /
# casing / attribute order doesn't matter; 'textPremium' (the account box in the
# page header) is a second independent signal. Either one is proof of a session.
RE_LOGGED_IN = re.compile(r'yloguj|textPremium', re.I)


def _is_logged_in_page(html: str) -> bool:
    """True when *html* is a logged-in tb7/xt7 page."""
    return bool(RE_LOGGED_IN.search(html or ''))


# ─── WebClient ───────────────────────────────────────────────────────────────────

class WebClient:
    """Handles all HTTP communication with tb7/xt7 services"""

    def __init__(self, provider_name, base_url):
        self.provider = provider_name
        self.base_url = base_url
        self.session = requests.ProviderSession()

        self.session.headers.update({
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': CHROME_UA,
            'DNT': '1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
        })

    def set_cookies(self, cookies):
        self.session.cookies.clear()
        for cookie_str in cookies.split('; '):
            if '=' in cookie_str:
                name, value = cookie_str.split('=', 1)
                self.session.cookies.set(name, value)

    def get_cookies(self):
        """Get cookies as string from session"""
        return '; '.join([f"{name}={value}" for name, value in self.session.cookies.items()])

    def login(self, username, password):
        """Login to service"""
        self.session.post(
            self.base_url + 'login',
            verify=False,
            allow_redirects=False,
            data={'login': username, 'password': password},
        )
        # Checked on the account page: a redirect does not tell (a wrong password, another domain).
        return _is_logged_in_page(self.session.get(self.base_url).text)

    def search(self, query):
        """Search for files"""
        return self.session.post(
            self.base_url + 'mojekonto/szukaj',
            data={'search': query, 'type': '1'},
            timeout=45,
        ).text

    def get_search_page(self, page_num):
        """Get specific page of search results"""
        return self.session.get(
            self.base_url + f"mojekonto/szukaj/{page_num}"
        ).text

    def get_library(self):
        """Get user's library/account files"""
        return self.session.get(
            self.base_url + 'mojekonto/pliki'
        ).text

    def get_notepad(self):
        """Get notepad content"""
        return self.session.get(
            self.base_url + 'mojekonto/notes'
        ).text

    def save_notepad(self, content):
        """Save notepad content"""
        return self.session.post(
            self.base_url + 'mojekonto/notes',
            data={'content': content}
        ).status_code == 200

    def get_account_info(self):
        """Get account info page (includes transfer limit)"""
        return self.session.get(self.base_url).text

    def post_download_step(self, step, content=None):
        """Post to download endpoint for file purchase"""
        data = {'step': str(step)}
        if content:
            data['content'] = content
        elif step == 2:
            data['0'] = 'on'

        return self.session.post(
            self.base_url + 'mojekonto/sciagaj',
            data=data
        ).text

    def safe_head(self, url, allow_redirects=False):
        """HEAD request; returns (status, location, content_type)."""
        response = None
        try:
            response = self.session.head(url, verify=False, allow_redirects=allow_redirects)
            status = response.status_code
            location = response.headers.get('Location')
            content_type = response.headers.get('Content-Type')
            return status, location, content_type
        except Exception:
            return None, None, None
        finally:
            if response is not None:
                response.close()

    def safe_get(self, url, allow_redirects=False):
        """GET request; returns (status, location, text)."""
        response = None
        try:
            response = self.session.get(url, verify=False, allow_redirects=allow_redirects)
            status = response.status_code
            location = response.headers.get('Location')
            text = response.text if response.status_code == 200 else None
            return status, location, text
        except Exception:
            return None, None, None
        finally:
            if response is not None:
                response.close()


# ─── _source ─────────────────────────────────────────────────────────────────────

class _source:
    """Base scraper for sites like tb7, xt7"""
    PREMIUM: ClassVar[bool] = True

    ffitem: FFItem
    #: The provider data store (set by the framework).
    store: ProviderStore

    PROVIDER: ClassVar[str]
    URL: ClassVar[str]
    priority: ClassVar[int] = 1
    language: ClassVar[Sequence[str]] = ['pl']

    has_library_color_identify2: bool = True

    SETTINGS: ClassVar[tuple[ProviderSetting, ...]] = (
        *LOGIN,
        ProviderSetting(key='auto', kind='bool', label=L(32742, 'Automatic use of transfer'), default=False),
        ProviderSetting(key='use_web_notebook_for_history', kind='bool', label=L(32749, 'Use Notes on the account to store information about downloaded files'),
                        help=L(32825, 'Notepad on account'), default=True),
    )

    def __init__(self):
        self.VIDEO_EXTENSIONS = ('avi', 'mkv', 'mp4', 'mpg', 'mov', '.ts', 'mts', '2ts')
        self.results = []
        self._results_set = set()
        self.titles = []
        self.pages = []
        #: The queries of the search whose fetch failed (the result is incomplete).
        self._failed_queries: list[str] = []
        #: The query the filtering state (self.titles) was prepared for.
        self._titles_query: tuple[str, str, str, str | None, str | None] | None = None
        self.additional_filter = None
        self.additional_filter2 = None
        self._filter_cache_key = None
        self._relevant_franchises = {}
        self._alias_cleans: set = set()
        self.remaining_limit_mb = -1
        #: The account page of the last session check in login() (it has the transfer limit), '' if none.
        self._account_page: str = ''
        self._limit_thread: Thread | None = None
        self.domains = [f"{self.PROVIDER}.pl"]
        self.base_link = f"{self.URL}/"

        self.user_name = provider_value(self.PROVIDER, 'username')
        self.user_pass = provider_value(self.PROVIDER, 'password')
        self.debug = const.sources.xtb7.debug
        self.last_sources: list[Any] = []
        #: The account library fetch started by the search: (thread, [result]).
        self._library_prefetch: tuple[Thread, list] | None = None

        # Initialize web clients
        # web          – main session (login, downloads, library, etc.)
        # web_parallel – extra sessions, used only to run search queries in parallel
        self.web = WebClient(self.PROVIDER, self.base_link)
        self.web_parallel: list[WebClient] = [WebClient(self.PROVIDER, self.base_link)
                                              for _ in range(const.sources.xtb7.search_sessions - 1)]

        # Compiled regex patterns
        self.RE_CRC32 = re.compile(r'\b[0-9a-f]{8}\b', re.I)

        # Pre-compute extension pattern for filename matching
        self.ext_pattern = f"({'|'.join(self.VIDEO_EXTENSIONS)})".replace('.', '')

        # Twojplik specific regex for filename normalization
        self.RE_TWOJPLIK_CRC = re.compile(r'\.[0-9A-F]{3}(\.(?:avi|mkv|mp4|mpg|mov|ts|mts|2ts))$', re.I)

    # ── public api ─────────────────────────────────────────────────────────

    def _reset_search(self) -> None:
        """Reset the state of the previous search (a rescan reuses the instance)."""
        self.results = []
        self._results_set = set()
        self.pages = []
        self._failed_queries = []

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> list[str]:
        fflog('searching: movie', 0)
        self._reset_search()
        return self._search(title, localtitle, year, aliases=aliases)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> ShowDataDict:
        """Helper method before searching for episode"""
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, year))

    def episode(self, url: ShowDataDict | None, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> list[str]:
        self._reset_search()
        data = ShowData(**url)
        return self._search(
            data.title,
            data.local_title,
            year=data.year,
            season=season,
            episode=episode,
            aliases=data.aliases,
            premiered=premiered
        )

    def sources(self, rows: list[str] | None, hostDict: list[str], hostprDict: list[str]) -> list[SourceItem]:
        """Return the static source items of the search rows (the account state is applied by apply_dynamic())."""
        if not rows:
            fflog('no sources')
            if self.results:
                rows = self.results
            else:
                return []
        sources = self._parse_rows(rows, [])
        fflog(f'sources: {len(sources)}')
        if self._failed_queries:
            raise IncompleteResult(sources, f'{len(self._failed_queries)} queries failed: {self._failed_queries}')
        return sources

    def _parse_rows(self, rows: list[str], sources: list[Any], library: tuple[dict, list] | None = None) -> list[SourceItem]:
        """
        Parse the result rows into source items appended to `sources` (also returned, only the new ones).

        `sources` are the items already on the list (dicts with 'hosting', 'info', 'quality', 'filename',
        'on_account_link') for the similarity check and the library duplicates. With `library`
        (library_cache, library_links) the account state is set (`library_links` entries are consumed).
        """
        new_items: list[SourceItem] = []
        for row in rows:
            try:
                filename = client.parseDOM(row, 'label')[0]
                if '<a ' in filename.lower():
                    filename = client.parseDOM(filename, 'a')[0]

                link = client.parseDOM(row, 'input', ret='value')[0]

                on_account, on_account_link, case, on_account_expires = False, '', '', ''
                if library is not None:
                    # Check if selected item is already in user account
                    library_cache, library_links = library
                    on_account, on_account_link, case, on_account_expires = self.check_if_file_is_on_user_account(
                        library_links, link, filename, library_cache
                    )

                # Avoid duplicates for items added from library
                if 'added_from_library' in row:
                    # the row link itself may be a listed source's on-account link (a notepad one: no filename part)
                    row_links = {on_account_link, link, link.rpartition('/')[0] if re.search(r'/sciagaj/[^/]+/', link) else link} - {''}
                    if any(listed['on_account_link'] in row_links for listed in sources):
                        continue

                hosting = client.parseDOM(row, 'td')[1]
                size = client.parseDOM(row, 'td')[3]

                quality, language, info = source_utils.parse_source_quality_lang(filename)

                reject = False

                if const.sources.xtb7.similarity_check:
                    # Check if it's a duplicate source (similar to existing)
                    for listed in reversed(sources):
                        if hosting in listed['hosting'] and info == listed['info'] and quality == listed['quality']:
                            similarity = self._filename_similarity(
                                self._decode_url_text(filename),
                                self._decode_url_text(listed['filename']),
                            )
                            if similarity > const.sources.xtb7.similarity_threshold:
                                reject = True
                                break

                if reject:
                    continue

                hosting += case
                item: SourceItem = {
                    'hosting': hosting,
                    'quality': quality,
                    'language': language,
                    'url': link,
                    'info': info,
                    'size': size,
                    'direct': True,
                    'debridonly': False,
                    'filename': filename,
                    'premium': True,
                }
                if library is not None:
                    item.update({
                        'on_account': on_account,
                        'on_account_expires': on_account_expires,
                        'on_account_link': on_account_link,
                        'no_transfer': self._no_transfer(size),
                    })
                sources.append({**item, 'on_account_link': on_account_link})
                new_items.append(item)
            except Exception:
                fflog_exc()
                continue
        return new_items

    def _no_transfer(self, size: str) -> bool:
        """Return True if the file of `size` is bigger than the remaining transfer limit."""
        source_size_mb = int(source_utils.convert_size_to_bytes(size) / (1024 * 1024))
        return bool(
            const.sources.premium.no_transfer
            and self.remaining_limit_mb >= 0
            and source_size_mb > 0
            and source_size_mb > self.remaining_limit_mb
        )

    def _prefetch_library(self) -> None:
        """Start the account library fetch in background (apply_dynamic() takes its result)."""
        lib_web = self._make_temp_webclient()
        result: list = [None]

        def fetch() -> None:
            try:
                result[0] = self._fetch_files_on_user_account(web=lib_web)
            except Exception:
                fflog_exc('background library fetch failed')

        thread = Thread(target=fetch, daemon=True)
        thread.start()
        self._library_prefetch = (thread, result)

    def _account_library(self) -> tuple[dict, list]:
        """Return the account library (library_cache, library_links): the prefetched one or fetched now."""
        if self._library_prefetch:
            thread, result = self._library_prefetch
            self._library_prefetch = None
            thread.join()  # the search deadline cuts its sockets
            if result[0]:
                return result[0][0], list(result[0][1])
            fflog('library prefetch failed, fetching now', 0)
        library_cache, library_links = self.files_on_user_account()[:2]
        return library_cache, list(library_links)

    def apply_dynamic(self, *, ffitem: FFItem, override: SourceSearchOverride, sources: list[Source]) -> list[Source | SourceItem]:
        """Apply the account state: mark the sources on the account, add the matching account library files."""
        self.ffitem = ffitem
        try:
            if not self.login():
                self.last_sources = list(sources)
                return self.last_sources
            if self._limit_thread:
                self._limit_thread.join(timeout=5)
                self._limit_thread = None
            if self.remaining_limit_mb < 0:
                self._fetch_remaining_limit()
            library_cache, library_links = self._account_library()
        except Exception:
            fflog_exc('account state failed')
            self.last_sources = list(sources)
            return self.last_sources

        # files of the library and the notepad, before the search results consume them (as the search sweep did)
        lib_rows = [
            f'<td></td><td></td><td></td><td></td>'
            f'<label>{self._decode_url_text(self._extract_filename_from_url(url))}</label>'
            f'<input value="{url}"/>added_from_library'
            for url, _expiry in library_links
        ] + [
            f"<td></td><td>{data['hosting']}</td><td></td><td>{data.get('size') or ''}</td>"
            f"<label>{data['filename']}</label>"
            f'<input value="{data["on_account_link"]}"/>added_from_library'
            for data in library_cache.values()
        ]

        # the search results (static sources) on the account
        listed: list[dict[str, Any]] = []
        for src in sources:
            try:
                on_account, on_account_link, case, on_account_expires = self.check_if_file_is_on_user_account(
                    library_links, src.url, src.get('filename', ''), library_cache)
                if on_account:
                    src.update({'on_account': True, 'on_account_link': on_account_link, 'on_account_expires': on_account_expires})
                    src.hosting += case
                src.update({'no_transfer': self._no_transfer(src.get('size', ''))})
            except Exception:
                fflog_exc()
            listed.append({'hosting': src.hosting, 'info': src.get('info'), 'quality': src.get('quality'),
                           'filename': src.get('filename', ''), 'on_account_link': src.get('on_account_link', '')})

        # the account library files missed by the search (filtered by the query like the search results)
        result: list[Source | SourceItem] = list(sources)
        if lib_rows:
            try:
                year = str(override['year'] or '')
                season = None if override['season'] is None else str(override['season'])
                episode = None if override['episode'] is None else str(override['episode'])
                if self._titles_query != (override['english_title'], override['local_title'], year, season, episode):
                    # a cached search or another query: the search did not prepare this filter
                    self._search_titles(override['english_title'], override['local_title'], year, season, episode,
                                        list(override.get('aliases') or ()))
                fflog(f'library: checking {len(lib_rows)} files', 0)
                done = len(self.results)
                self.get_pages_content(page=None, rows=lib_rows, year=year, title=override['english_title'],
                                       season=season, episode=episode, premiered=str(override['premiered'] or ''))
                result += self._parse_rows(self.results[done:], listed, library=(library_cache, library_links))
            except Exception:
                fflog_exc('library sweep failed')

        # resolve() needs the final list (filename, on-account link), also after a cache hit
        self.last_sources = result
        return result

    def resolve(self, url: str, buy_anyway: bool = False) -> str | ResolveResult | None:
        """Returns link to player"""
        original_url = url
        specific_source_data = {}
        try:
            if hasattr(self, 'last_sources') and self.last_sources:
                fflog('resolve: looking up source in last_sources')
                source_data = next((src for src in self.last_sources if src.get('url') == url), None)
                if source_data:
                    specific_source_data = source_data
                    fflog(f'resolve: source found in last_sources: {specific_source_data!r}')
                else:
                    fflog('resolve: source not found in last_sources')
            else:
                fflog('resolve: last_sources is empty')
        except Exception as exc:
            fflog(f'resolve: error looking up last_sources: {exc!r}')

        player_link_after_redirection = True
        force_confirm = False
        PROCEED_TO_PURCHASE = object()

        def _check_on_account_link_before_play(on_account_link, allow_repurchase=False):
            """Test and possibly repair inactive link.

            When ``allow_repurchase`` is set and the on-account link turns out to be
            dead (the file expired / is no longer on the account), return
            ``PROCEED_TO_PURCHASE`` so the caller falls through to a fresh paid download.
            """
            link = on_account_link

            # Only sciagaj links
            if '/sciagaj/' in link:
                status, location, text = self.web.safe_get(link, allow_redirects=False)

                # 200 — link dead (file expired / no longer on the account)
                if status == 200:
                    control.execute('Dialog.Close(notification,true)')
                    if allow_repurchase:
                        fflog('on-account link dead, re-downloading from source')
                        return PROCEED_TO_PURCHASE
                    control.dialog().ok(f'{self.PROVIDER}', 'Link wygasł.')
                    return None

                # 302 — follow redirect
                if status == 302 and location:
                    link = location
                    status2, loc2, ctype2 = self.web.safe_head(link, allow_redirects=False)

                    if ctype2 and 'text' in ctype2:
                        # 302 → follow redirect further
                        if status2 == 302 and loc2:
                            link = loc2
                            # final HEAD — check only
                            self.web.safe_head(link, allow_redirects=False)

                # 403 — forbidden
                if status == 403:
                    control.execute('Dialog.Close(notification,true)')
                    control.dialog().ok('Dostęp zabroniony', ' [CR] - sprawdź powód na stronie')
                    return None

                # other errors
                if status and status >= 400:
                    control.infoDialog(f'Server zwrócił błąd {status}', f'{self.PROVIDER}', 'ERROR', 4000)
                    control.sleep(4000)
                    return None

                fflog(f'status code: {status}', 0)

            if player_link_after_redirection:
                on_account_link = link

            fflog(f'resolved: {on_account_link=}', 0)
            return self._format_player_url(on_account_link)

        if not buy_anyway and specific_source_data:
            on_account = specific_source_data.get('on_account', False)
            if on_account:
                on_account_link = specific_source_data.get('on_account_link', '')
                if on_account_link:
                    on_account_link = on_account_link.replace('%2F', '-')
                    result = _check_on_account_link_before_play(on_account_link, allow_repurchase=True)
                    if result is not PROCEED_TO_PURCHASE:
                        return result
                    force_confirm = True

        if not self.login():
            # not a dead link: the account (the message instead of "the link is not working")
            return {'error': {'kind': 'account', 'message': L(32849, 'Login failed')}}

        filename = specific_source_data.get('filename', '')
        fflog(f'resolve: {filename=}')

        auto_purchase = provider_value(self.PROVIDER, 'auto')
        remaining_limit = ''  # read only for the confirmation (not with the automatic transfer)
        if force_confirm or not auto_purchase:
            limit_info = self.web.get_account_info()
            limit_info = client.parseDOM(limit_info, 'div', attrs={'class': 'textPremium'})
            remaining_limit = str(client.parseDOM(limit_info, 'b')[-1])
            remaining_limit = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", '', remaining_limit)
            remaining_limit = re.sub('<[^>]+>', '', remaining_limit)

            if not filename:
                filename = url
            filename = unquote(filename)
            filename = unescape(filename)
            filename = self.prepare_filename_to_display(filename)
            filename = f"[LIGHT]{filename}[/LIGHT]"

            size_info = specific_source_data.get('meta', {}).get('size', '') or specific_source_data.get('size', '')
            if not source_utils.confirm_transfer_dialog(
                filename=filename,
                charge=size_info,
                remaining=remaining_limit,
                note='Link wygasł — konieczne ponowne pobranie.' if force_confirm else '',
            ):
                return False

        links = [original_url]
        links = list(dict.fromkeys(links))

        for link in links:
            # Step 1 - send address to check if active
            response = self.web.post_download_step(1, link)

            # Check if active
            if ' value="Wgraj linki"' not in response:
                fflog(f'inactive link: {link=}')
                xsleep(0.1)
                continue
            else:
                break

        if 'ymagane dodatkowe' in response:
            remaining_info = f' \n[COLOR gray](aktualnie posiadasz [B]{remaining_limit}[/B])[/COLOR]' if remaining_limit else ''
            control.dialog().ok('Brak środków', f'Brak wystarczającego transferu.{remaining_info}')
            fflog('insufficient transfer')
            return None

        if ' value="Wgraj linki"' not in response:
            plural = len(links) > 1
            control.infoDialog(
                (f"Wystąpił błąd. \nTa pozycja ma nieaktywn{'e' if plural else 'y'} link{'i' if plural else ''}."), f'{self.PROVIDER}', 'ERROR')
            fflog('no active links for this item')
            return None

        # Step 2 - attempt to add source to library
        response = self.web.post_download_step(2)

        div = client.parseDOM(response, 'div', attrs={'class': 'download'})
        try:
            link = client.parseDOM(div, 'a', ret='href')[1]
            size = div[1].split('|')[-1].strip()
        except Exception:
            fflog_exc()
            if 'Nieaktywne linki' in response:
                control.dialog().notification(f"{self.PROVIDER}", 'Link okazał się nieaktywny')
                fflog(f'link is inactive after all: {link=}')
            else:
                control.infoDialog('Wystąpił błąd. \nMoże brak wystarczającego transferu?', f"{self.PROVIDER}", 'ERROR')
            return None

        # Save information in notepad
        if provider_value(self.PROVIDER, 'use_web_notebook_for_history'):
            notes_list = []
            notepad_html = self.web.get_notepad()
            notes_value = client.parseDOM(notepad_html, 'textarea', attrs={'class': 'notepad'})
            if notes_value:
                notes_value = notes_value[0].strip()
                if notes_value and notes_value.startswith('[') and notes_value.endswith(']'):
                    try:
                        notes_list = json.loads(notes_value)
                    except (json.JSONDecodeError, ValueError):
                        notes_list = []

            filename_for_notes = specific_source_data.get('filename')
            if not filename_for_notes:
                filename_for_notes = original_url.split('/')[-1]
                if '.' not in filename_for_notes or len(filename_for_notes.split('.')[-1]) > 5:
                    filename_for_notes = ''
            filename_for_notes = self._decode_url_text(filename_for_notes or '')

            link1 = link.rpartition('/')[0] if '/sciagaj/' in link else link

            generation_date = datetime.now()
            generation_date_str = generation_date.strftime('%H:%M %d.%m.%Y')

            # NEW STRUCTURE: [original_url, download_link, filename, size, generation_date]
            new_entry = [original_url, link1, filename_for_notes, size, generation_date_str]
            # drop any earlier entry for the same source so a re-download replaces it
            # instead of piling up stale (dead-link) duplicates
            notes_list = [new_entry] + [
                note for note in notes_list
                if not (isinstance(note, list) and note and note[0] == original_url)
            ]

            # Control size via JSON
            while len(json.dumps(notes_list)) >= NOTES_MAX_SIZE:
                notes_list.pop()

            self.web.save_notepad(json.dumps(notes_list))

        # Return link to player
        link = link.replace('%2F', '-')
        if player_link_after_redirection:
            return _check_on_account_link_before_play(link)
        else:
            return self._format_player_url(link)

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _decode_url_text(text):
        """Decode URL-encoded and HTML-escaped text"""
        return unescape(unquote(text))

    @staticmethod
    def _extract_filename_from_url(url):
        """Extract filename from URL path"""
        return url.rstrip('/').split('/')[-1]

    def _normalize_twojplik_filename(self, text, link):
        """Normalize TwojPlik filenames by replacing CRC with placeholder"""
        if '/twojplik.pl/' in link.lower():
            return self.RE_TWOJPLIK_CRC.sub(r'.ZZZ\1', text)
        return text

    def _format_player_url(self, url):
        """Format URL with User-Agent for player"""
        user_agent = quote(self.web.session.headers.get('User-Agent', ''))
        return f"{url}|User-Agent={user_agent}&Connection=close&verifypeer=false"

    def _kitsu_queries(self, episode_str):
        """The queries and the romaji titles with the cour episode number (Kitsu) of an anime episode, or None."""
        try:
            romaji = kitsu_api.romaji_episode(self.ffitem)
        except Exception:
            fflog_exc()
            self._failed_queries.append('kitsu romaji')  # searched without them: the result is incomplete
            return None
        if not romaji:
            return None
        title, base = romaji.titles[0], romaji.titles[-1]  # cour title, the show without its arc/season part
        if romaji.season:
            # a later cour is named by its own season ("Sousou no Frieren S2 - 02", "S02E01"), not the TMDB one
            queries = [f'{base} s{romaji.season} {romaji.episode:02d}', f'{base} s{romaji.season:02d}e{romaji.episode:02d}']
        else:
            queries = [f'{title} {romaji.episode:02d}', f'{base} {episode_str}']
        queries = list(dict.fromkeys(queries))
        fflog(f'kitsu: {romaji} queries={queries}')
        return queries, romaji

    @staticmethod
    def _format_episode(season, episode):
        """Format season and episode numbers (s01e05)"""
        season_num = str(season).zfill(2)
        episode_num = str(episode).zfill(2)
        return season_num, episode_num, f"s{season_num}", f"s{season_num}e{episode_num}"

    def _search_titles(self, title: str, localtitle: str, year: str, season: str | None, episode: str | None,
                       aliases: list[SourceTitleAlias]) -> list[str]:
        """Prepare the search titles (returned) and the filtering state (self.titles, anime episode numbers)."""
        aliases2 = source_utils.prepare_alias_search_list(aliases, year)

        all_titles_for_filtering = []
        search_titles = []
        titles_to_use = [title.lower()]
        if localtitle.lower() != title.lower():
            titles_to_use.append(localtitle.lower())

        # Anime detection for special search handling
        is_anime = hasattr(self, 'ffitem') and source_utils.is_anime(self.ffitem)
        self._absolute_episode = None
        self._kitsu_episode = None
        if is_anime and season and episode:
            try:
                self._absolute_episode = self.ffitem.absolute_episode_number()
            except Exception:
                fflog_exc()
                self._failed_queries.append('absolute episode')  # searched without it: the result is incomplete
            if self._absolute_episode:
                fflog(f'anime detected, absolute episode: {self._absolute_episode}')

        if season and episode:
            season_num, episode_num, season_str, episode_str = self._format_episode(season, episode)

            has_local = not is_anime and localtitle.lower() != title.lower()
            # (title, marker) pairs; a query is "title<separator>marker"
            episode_pairs = []
            if is_anime and self._absolute_episode:
                episode_pairs.append((title.lower(), f"e{str(self._absolute_episode).zfill(2)}"))
            episode_pairs.append((title.lower(), episode_str))
            if has_local:
                episode_pairs.append((localtitle.lower(), episode_str))
            season_pairs = [] if is_anime else [(title.lower(), season_str)] + ([(localtitle.lower(), season_str)] if has_local else [])

            # Candidates in priority order (measured: each next one adds fewer files):
            # episode queries with the first separator, the bare local title, episode
            # queries with the next separator(s), the bare original title, season queries.
            # The first max_show_search_queries of them become HTTP queries, so a slot not
            # taken by a local title (PL == EN) goes to the next separator variant.
            separators = const.sources.xtb7.episode_separators or ('.',)
            first_separator, *other_separators = separators
            candidates = [f"{name}{first_separator}{marker}" for name, marker in episode_pairs]
            candidates += [localtitle.lower()] if has_local else []
            candidates += [f"{name}{separator}{marker}" for separator in other_separators for name, marker in episode_pairs]
            candidates += [title.lower()]
            candidates += [f"{name}{separator}{marker}" for separator in separators for name, marker in season_pairs]
            candidates = source_utils.deduplicate_list_ci(candidates)
            budget = const.sources.xtb7.max_show_search_queries
            kitsu_queries, kitsu_titles = [], []
            if is_anime and (kitsu := self._kitsu_queries(episode_str)):
                # Kitsu romaji title + cour episode ("Shingeki.no.Kyojin.The.Final.Season.07", "Naruto.Shippuuden.414")
                # finds fansub files, TMDB titles find the streaming ones, so both go; "title e{abs}" added
                # nothing next to "title.e{abs}" (48 anime episodes), so it makes room: 4 queries, one round
                kitsu_queries, self._kitsu_episode = kitsu
                kitsu_titles = self._kitsu_episode.titles
                if self._absolute_episode:
                    candidates = [cand for cand in candidates if cand != f"{title.lower()}{first_separator}e{str(self._absolute_episode).zfill(2)}"]
                budget = 4 - len(kitsu_queries)
            search_titles.extend(candidates[:budget] + kitsu_queries)

            # The query budget must NOT cap what counts as a "known" title for filtering
            # already-fetched rows, which is a free, local check - the bare title/localtitle
            # (usually cut off) must still be there, e.g. "Breaking Bad" S01E01 files.
            filtering_titles = list(candidates) + kitsu_titles

        else:
            if is_anime:
                movie_info = self.ffitem.anime_info.movie if self.ffitem.anime_info else None
                if movie_info:
                    titles_to_use.append(kitsu_api.normalize_romaji(movie_info['title']))
            search_titles.extend(titles_to_use)
            filtering_titles = search_titles

        # Remove duplicates from search titles
        unique_search_titles = source_utils.deduplicate_list_ci(search_titles)

        # Prepare ALL titles for filtering (main + aliases)
        aliases_lower = [alias.lower() for alias in aliases2]
        all_titles_for_filtering = filtering_titles + aliases_lower
        self.titles = source_utils.deduplicate_list_ci(all_titles_for_filtering)
        self._titles_query = (title, localtitle, year, season, episode)
        return unique_search_titles

    # Search requests of one search (tb7, xt7, gb7; the replay test test_pl_search_replay keeps the queries):
    #
    # | Media         | Queries | Worst | Queries made of                                                                              |
    # |---------------|---------|-------|----------------------------------------------------------------------------------------------|
    # | movie         | 3-4     | ~10   | title, local title, anime romaji title, first US alias, "title year"; a lone word (+1/title) |
    # | episode       | 3       | 4     | const.sources.xtb7.max_show_search_queries; nothing found in S01: +1 last-chance query       |
    # | anime episode | 4       | 5     | the same with the Kitsu queries (4 in all); nothing found in S01: +1 last-chance query      |
    #
    # A query is 1 POST, a next result page 1 GET (up to 200 rows came on one page so far). Around them: the session check
    # GET in login() (cached cookies, its page has the transfer limit; the login POST once in COOKIE_EXPIRATION_HOURS and
    # for each parallel session, then the limit GET), the account library GET (+ the notepad GET with
    # use_web_notebook_for_history). Another episode of the same show costs the same.
    def _search(self, title: str, localtitle: str, year: str = '', season: str | None = None, episode: str | None = None, aliases: list[SourceTitleAlias] | None = None, premiered: str = '') -> list[str]:
        if not title:
            fflog(f'search error: title is empty: {title=}')
            return []
        # The search of a logged-out session finds nothing (a redirect to the login page): no queries,
        # and the empty result is not cached (a corrected password searches again at once).
        if not self.login():
            raise IncompleteResult([], 'not logged in')
        if const.sources.premium.no_transfer:
            # the limit is needed only in sources() - fetch it alongside the search queries
            self._limit_thread = Thread(target=self._fetch_remaining_limit, args=(self._make_temp_webclient(),), daemon=True)
            self._limit_thread.start()
        results = []

        if aliases is None:
            aliases = []

        year = str(year)

        unique_search_titles = self._search_titles(title, localtitle, year, season, episode, aliases)

        # For movies: add the first English alias as an extra query
        # (+1 sequential HTTP request) — catches files indexed under a
        # shorter title, e.g. "Jack Ryan: Ghost War" without "Tom Clancy's".
        if not (season and episode):
            existing = {st.lower() for st in unique_search_titles}
            for alias in aliases:
                if alias.get('country') != 'us':
                    continue
                alias_val = alias.get('title') or alias.get('originalname') or ''
                if alias_val and alias_val.lower() not in existing:
                    unique_search_titles.append(alias_val)
                    existing.add(alias_val.lower())
                    if self.debug:
                        fflog(f'extra query from alias: {alias_val!r}')
                    break

            # Always add a plain "title + year" query too, regardless of alias
            # availability (+1 sequential HTTP request) — some releases only
            # surface in xt7's search when the year is part of the query text,
            # even with no alias data at all (e.g. a movie with zero TMDB aliases
            # never finds "The.Fall.2006..." via the bare title alone).
            if year:
                year_query = f'{title} {year}'
                if year_query.lower() not in existing:
                    unique_search_titles.append(year_query)
                    existing.add(year_query.lower())
                    if self.debug:
                        fflog(f'extra query from title+year: {year_query!r}')

        # Prepare only main titles for searching
        final_search_titles = []
        for search_title in unique_search_titles:
            # an apostrophe inside a word is a word break as in filenames ("World.s.End", "Tom.Clancy.s"),
            # "10,000" stays one number ("10000.BC") and a superscript is a separate one ("Accountant.2")
            search_title = re.sub(r"(?<!\w)'|'(?!\w)|(?<=\d),(?=\d{3}\b)", '', search_title.replace('’', "'")).replace('²', ' 2').replace('³', ' 3')
            cleaned = cleantitle.normalize(cleantitle.getsearch(search_title))
            final_search_titles.append(cleaned)

        final_search_titles = source_utils.deduplicate_list_ci(final_search_titles)
        final_search_titles = [
            const.sources.xtb7.title_replacements.get(search_title.lower(), search_title)
            for search_title in final_search_titles
        ]
        # queries are built from the cleaned titles too
        unique_search_titles = final_search_titles
        lone_word_queries = []

        def prepare_search_query(title):
            """Prepare title for search engine"""
            title = strip_diacritics(title)
            # before spaces become '_': "Tom & Jerry" -> "tom_and_jerry", not "tom__and__jerry" (each '_' = one char)
            title = re.sub(r'\s*&\s*', ' and ', title)
            title = title.replace('–', '-').replace('—', '-')  # en-dash/em-dash -> hyphen (handled below)
            # Colons never appear in filenames (illegal on Windows); left unhandled, finalize_query()
            # sees \W and skips the '%' wildcard. ": " first to avoid a doubled separator.
            title = title.replace(': ', ' ').replace(':', ' ')
            title = title.replace(' - ', ' ')
            title = title.replace('-', '_')
            title = title.replace('. ', '.')
            title = title.replace(' ', '_')
            title = title.replace(',', '')
            title = title.replace('#', '')
            title = re.sub(r'_?(\d)/', r'_\1_', title)  # e.g., 1½ -> _1_
            return title

        def finalize_query(title_r):
            """Add padding and wildcards to query"""
            if not customTitles:
                title_r = re.sub(r'^(the|an?)[ _]', '', title_r, count=1, flags=re.IGNORECASE)
                # xt7 searches a phrase starting with a 1-2 char word very slowly (5-30 s). It matches words inside
                # the filename too, but which 150-200 rows it returns depends on every word, so the leading 1-char
                # words (then 2-char ones and a common word):
                # - are dropped when several words are left: "2_broke_girls" -> "broke_girls",
                #   "e.t.the_extra_terrestrial" -> "extra_terrestrial", "i_am_legend_2007" -> "legend_2007"
                # - go to the end when one word is left or a number goes: "x_men" -> "men_x",
                #   "9_1_1_lone_star_s01e02" -> "lone_star_s01e02_9_1_1"; after a common word the lone word is also
                #   queried on its own, as "vendetta" finds files "vendetta_v_for" misses (0 gain after a letter only)
                # - stay when only a year, an episode or a number would lead: "x_2022", "9_1_1_s01e05", "8_mila"
                shortened = re.sub(r'^(?:[^\W_][._])+(?:[^\W_]{2}[._])*(?:(?:and|for|the|jak|nie|czy)[._])?', '', title_r, flags=re.IGNORECASE)
                prefix = re.sub(r'[._]+', '_', title_r[:len(title_r) - len(shortened)]).strip('_')
                first_word = re.split(r'[._]', shortened)[0]
                several_words = bool(re.search(r'[._].', shortened))
                if len(first_word) >= 3 and several_words and not re.search(r'\d', prefix):
                    title_r = shortened
                elif (prefix and len(first_word) >= 2 and (several_words or not re.search(r'\d', prefix))
                      and not re.fullmatch(r's\d+e\d+|(?:19|20)\d\d', first_word, flags=re.IGNORECASE)):
                    if not several_words and re.search(r'_(?:and|for|the|jak|nie|czy)$', prefix, flags=re.IGNORECASE):
                        lone_word_queries.append(f'{shortened}%')
                    title_r = f'{shortened}_{prefix}'
            if len(title_r) < 3:
                if season and episode:
                    title_r += f' s{str(season).zfill(2)}e{str(episode).zfill(2)}'
                else:
                    title_r += f' {year}'
            if not re.search(r'\W', title_r.rstrip('%')) and not title_r.endswith('%'):
                title_r += '%'
            return title_r

        if self.debug:
            fflog(f'search titles: {final_search_titles}')
            fflog(f'all titles for filtering: {self.titles}')

        # Start the account library fetch in background so it overlaps with search queries,
        # apply_dynamic() takes its result. Uses a temp session — self.web stays free for EN search.
        self._prefetch_library()

        customTitles = len(sys.argv) > 2 and 'customTitles' in sys.argv[2]

        # Build finalized queries upfront
        finalized_queries: list[tuple[str, str]] = []
        for search_title in unique_search_titles:
            title_to_search = prepare_search_query(search_title) if not customTitles else search_title
            title_r = finalize_query(title_to_search)
            finalized_queries.append((search_title, title_r))
        finalized_queries += [(query, query) for query in lone_word_queries]

        if self.debug:
            fflog(f'search queries: {[tr for _, tr in finalized_queries]}')

        # Phase 1: Fetch all queries
        all_raw_rows = self._fetch_all_rows(finalized_queries)

        # Phase 2: Single filter pass over all collected rows
        if all_raw_rows:
            self.get_pages_content(
                page=None, rows=all_raw_rows, year=year, title=title,
                season=season, episode=episode, premiered=premiered,
            )
        elif self.debug:
            fflog('no match')

        # Phase 3: Last-chance fallback (sequential, only when Phase 1+2 yielded nothing)
        if not self.results and season and episode:
            season_num, episode_num, _, _ = self._format_episode(season, episode)
            extra_titles: list[str] = []
            # 3b. Episode-only variant for s01
            if season_num == '01':
                for page in self.pages:
                    page_title = list(page)[0]
                    if re.search(r's[0o]1(e\d+)?', page_title, flags=re.I):
                        base_title = re.sub(r'[\W_]s[0o]1(e\d+)?', '', page_title, flags=re.I)
                        ep_only = f"e{episode_num}"
                        sep = ' ' if ' ' in base_title else '.'
                        new_variant = f"{base_title}{sep}{ep_only}"
                        if new_variant not in final_search_titles:
                            extra_titles.append(new_variant)
                            fflog(f'last-chance variant: {new_variant!r}')
                        break

            for lc_title in extra_titles:
                if getattr(current_thread(), 'stop_event', None) and current_thread().stop_event.is_set():
                    break
                title_r = finalize_query(prepare_search_query(lc_title) if not customTitles else lc_title)
                if self.debug:
                    fflog(f'last-chance query: {title_r!r}')
                lc_rows = self._fetch_query_rows(title_r)
                if lc_rows:
                    self.get_pages_content(
                        page=None, rows=lc_rows, year=year, title=title,
                        season=season, episode=episode, premiered=premiered,
                    )
                    if self.results:
                        break

        results = self.results
        if results:
            fflog(f'approved: {len(results)}')
        else:
            fflog('no sources')
        return results


    def _fetch_raw_rows(self, title_r: str, web=None) -> tuple[str, int, list[str]]:
        """Fetch all raw table rows for a search query without any filtering."""
        web = web or self.web
        fflog(f'query: {title_r!r}')
        pre_res = web.search(title_r)
        pre_res = pre_res.replace('\r', '').replace('\n', '')

        if self.debug:
            fflog(f'response length for {title_r!r}: {len(pre_res)} chars')

        page_block = re.search('class="page-list"(.+?)</div>', pre_res, re.IGNORECASE)
        if page_block is None:
            if not _is_logged_in_page(pre_res):
                raise ConnectionError(f'{title_r!r}: logged out (the login page came)')
            fflog(f'search: 0 results (response length: {len(pre_res)})')
            return title_r, 0, []

        pages = len(re.findall('href=', page_block.group()))
        self.pages.append({title_r: pages})

        # Page 1 is already in the POST response — no extra GET needed
        rows = client.parseDOM(pre_res, 'tr')[1:]
        fflog(f'search: {len(rows)} results')

        for page_num in range(2, pages + 1):
            if hasattr(current_thread(), 'stop_event') and current_thread().stop_event.is_set():
                break
            res = web.get_search_page(page_num)
            page_rows = client.parseDOM(res, 'tr')[1:]
            fflog(f'search: {len(page_rows)} results (page {page_num})')
            rows.extend(page_rows)

        return title_r, pages, rows

    def _fetch_query_rows(self, title_r: str, web: WebClient | None = None) -> list[str]:
        """Return the raw rows of a query, [] if its fetch failed (logged, the result is incomplete then)."""
        try:
            return self._fetch_raw_rows(title_r, web)[2]
        except Exception:
            fflog_exc(f'fetch failed for {title_r!r}')
            self._failed_queries.append(title_r)
            return []

    def _fetch_all_rows(self, queries: list[tuple[str, str]]) -> list[str]:
        """Fetch raw rows for all queries, in parallel lanes (one per session).

        No own time budget: the search deadline stops the provider thread (and cuts its sockets).
        """
        start_time = time.time()
        all_rows: list[str] = []

        def _is_cancelled():
            return getattr(current_thread(), 'stop_event', None) and current_thread().stop_event.is_set()

        if _is_cancelled() or not queries:
            return all_rows

        # Deduplicate by final query string — avoids duplicate HTTP requests when
        # EN and PL titles normalise to the same search term (e.g. "Batman").
        seen_query_strs: set = set()
        deduped: list[tuple[str, str]] = []
        for orig_title, title_r in queries:
            if title_r not in seen_query_strs:
                seen_query_strs.add(title_r)
                deduped.append((orig_title, title_r))
        if len(deduped) < len(queries):
            fflog(f'deduplicated {len(queries)} queries → {len(deduped)} (identical strings removed)', 0)
        queries = deduped

        # ── Sequential path: single query or a single session ───────────────────
        if len(queries) == 1 or not self.web_parallel:
            for _, title_r in queries:
                if _is_cancelled():
                    break
                all_rows.extend(self._fetch_query_rows(title_r, self.web))
            return list(dict.fromkeys(all_rows))

        # ── Parallel path: one lane per session ─────────────────────────────────
        # With N sessions lane i gets queries[i], [i + N], ... Each lane runs its queries
        # one by one - the server queues requests of one session anyway.
        fflog(f'parallel fetch: {[title_r for _, title_r in queries]}', 0)

        rows_by_query: dict[str, list[str]] = {}

        def _run_lane(lane: list[tuple[str, str]], web: WebClient) -> None:
            for _, title_r in lane:
                if _is_cancelled():
                    return
                rows_by_query[title_r] = rows = self._fetch_query_rows(title_r, web)
                fflog(f'{title_r!r} done: {len(rows)} rows (t+{time.time() - start_time:.1f}s)', 0)

        sessions = [self.web] + self.web_parallel
        executor = ThreadPoolExecutor(max_workers=len(sessions))
        try:
            lanes = [executor.submit(_run_lane, queries[index::len(sessions)], session)
                     for index, session in enumerate(sessions)]
            wait(lanes)
        finally:
            executor.shutdown(wait=False)

        # assemble in query order (EN first)
        for _, title_r in queries:
            all_rows.extend(rows_by_query.get(title_r, []))
        return list(dict.fromkeys(all_rows))  # deduplicate, preserve order

    def get_pages_content(self, page, year, title='', season=None, episode=None, premiered='', aliases=None, rows: list[str] | None = None):
        """Filter search result rows by title, year, and episode number."""
        if self.debug:
            if season and episode:
                _, _, _, episode_str = self._format_episode(season, episode)
            else:
                episode_str = ''
            fflog(f'{title=} {year=} {episode_str=} {page=} {premiered=}')

        if not rows:
            if page:
                if isinstance(page, range):
                    pages = page
                else:
                    pages = [page-1]
                rows = []
                for page in pages:
                    if hasattr(current_thread(), 'stop_event') and current_thread().stop_event.is_set():
                        fflog('scraper thread cancelled, exiting page loop')
                        break
                    page += 1
                    res = self.web.get_search_page(page)
                    row = client.parseDOM(res, 'tr')[1:]
                    fflog(f'[page {page}]: {len(row)} results')
                    rows += row
                fflog(f'to analyze: {len(rows)}') if isinstance(pages, range) and page > 1 else ''
                res = row = None

        if season and episode:
            # Remove potential episode number from query title
            title = re.sub(r'(s[0o]?\d{1,2})?[ _.]?(e[\do]{2,4})?$', '', title).rstrip('._ ')
        if year:
            # Remove potential year from query title
            title = ''.join(title.rsplit(year, 1)).rstrip('._ ')
        title = title.rstrip('%')
        title = title.replace('.', ' ')

        # Phrase boundaries (alternative to \b)
        boundary_start = r'(?:^|(?<=[([ _.-]))'
        boundary_end = r'(?=[)\] _.-]|$)'

        if year:
            year_pat = f"{boundary_start}{year}{boundary_end}".replace('0', '[0Oo]')

        # Variables to remember created filter
        additional_filter = self.additional_filter
        additional_filter2 = self.additional_filter2

        _filter_key = (tuple(self.titles), title, bool(season and episode))
        if self._filter_cache_key != _filter_key:
            # Franchise filter (static; depends only on self.titles)
            self._relevant_franchises = source_utils.build_relevant_franchises(
                self.titles, const.sources.franchise_names, const.sources.franchise_names_sep
            )

            additional_filter, additional_filter2 = source_utils.build_title_filters(
                self.titles, title, is_episode=bool(season and episode), ext_pat=self.ext_pattern)
            self.additional_filter = additional_filter
            self.additional_filter2 = additional_filter2

            self._alias_cleans = source_utils.build_alias_cleans(self.titles)
            self._filter_cache_key = _filter_key

        relevant_franchises = self._relevant_franchises

        # Check if TV show title contains a year
        year_in_title = re.search(r'\b\d{4}\b', title)
        year_in_title = year_in_title[0] if year_in_title else ''

        # Get current year
        current_year = int(time.strftime('%Y'))
        episode_date: date | None = self.ffitem.date if hasattr(self, 'ffitem') else None
        episode_year: int = episode_date.year if episode_date else 0

        year_universal_re = source_utils.RE_YEAR_FILENAME
        year_re = re.compile(year_pat) if year else None
        episode_universal_re = source_utils.RE_EPISODE_FILENAME

        abs_ep_val = getattr(self, '_absolute_episode', None)

        # Pre-compute per-search constants (avoid repeated work inside row loop)
        year_minus_1_re = re.compile(str(int(year) - 1)) if year else None
        premiered_years = ''.join(re.findall(r'\d{4}', premiered)) if premiered else ''
        # Pre-select year/episode check as a closure — avoids evaluating constants per row
        # an anime fansub file has the Kitsu cour episode right after the romaji title ("Sousou.no.Frieren.02")
        kitsu_episode = getattr(self, '_kitsu_episode', None)
        find_cour_episodes = kitsu_api.cour_episode_finder(kitsu_episode) if kitsu_episode else None
        if season and episode:
            def _passes_year_episode(fn):
                return source_utils.filename_passes_episode(fn, season, episode, abs_ep_val)
        elif not year and not season and not episode:
            def _passes_year_episode(fn):
                return True
        else:
            def _passes_year_episode(fn):
                return (
                    (year_re and year_re.search(fn))
                    or (year_minus_1_re and year_minus_1_re.search(fn))
                    or (premiered_years and re.search(premiered_years, fn))
                    or (year and not year_universal_re.search(fn) and not episode_universal_re.search(fn))
                )

        for row in rows:
            if row in self._results_set:
                continue

            filename0 = ''.join(client.parseDOM(row, 'a') or client.parseDOM(row, 'label'))

            # Reject non-video file extensions
            if filename0[-3:] not in self.VIDEO_EXTENSIONS:
                continue

            filename = filename0
            filename = unquote(filename)
            filename = unescape(filename)
            filename = filename.replace('_', ' ')
            filename = self.RE_CRC32.sub('', filename)  # Remove CRC32 from filename

            cour_match = bool(find_cour_episodes and kitsu_episode.episode in find_cour_episodes(filename))
            if cour_match or _passes_year_episode(filename):
                # Check if filename matches searched title
                if season and episode:
                    if premiered and year_universal_re.search(filename):
                        if source_utils.check_year_in_filename(filename, year, premiered, year_in_title, current_year, episode_year) is False:
                            continue

                if (
                    not additional_filter
                    # a later cour file has its season between the title and the number ("Sousou no Frieren S2 - 02"),
                    # the romaji title with the cour episode is the title match
                    or (cour_match and kitsu_episode.season)
                    or additional_filter.search(filename)
                    or (additional_filter2 and additional_filter2.search(filename))
                    or source_utils.match_filename_title_parsed(filename, self._alias_cleans)
                    or any(
                        re.search(pat, filename, re.I)
                        for pat_list in relevant_franchises.values()
                        for pat in pat_list
                    )
                ):
                    if season and episode:
                        normalized_words = filename.replace('.', ' ').replace('_', ' ').lower().split()
                        conflict_cc = source_utils.detect_country_variant_conflict(
                            normalized_words, list(self.titles)
                        )
                    else:
                        conflict_cc = None
                    if conflict_cc:
                        if self.debug:
                            fflog(f'skip (country variant {conflict_cc}): {self._decode_url_text(filename0)}')
                    else:
                        if self.debug:
                            fflog(f'match: {self._decode_url_text(filename0)}')
                        self.results.append(row)
                        self._results_set.add(row)
                else:
                    if self.debug:
                        fflog(f'skip (title mismatch): {self._decode_url_text(filename0)}')
            else:
                if self.debug:
                    fflog(f'skip (year/episode mismatch): {self._decode_url_text(filename0)}')

    @staticmethod
    def _filename_similarity(name1, name2):
        """Compare filename similarity on scale 0.0 - 1.0"""
        return SequenceMatcher(None, name1.lower(), name2.lower()).ratio()

    def prepare_filename_to_display(self, filename):
        """Prepare filename for display (allow text wrapping)"""
        filename = filename[:-4].replace('.', ' ').replace('_', ' ') + filename[-4:]
        # Remove last dash - usually followed by file "author" name
        filename = re.sub(r'-(?=\w+( \(\d\))?( [0-9A-F]{3})?\.\w{2,4}$)', ' ', filename, flags=re.I)
        filename = self.replace_audio_format_in_filename(filename)
        return filename

    def replace_audio_format_in_filename(self, filename):
        """Restore necessary dots and dashes for certain phrases"""
        replacements = [
            (r'(?<!\d)([57261]) ([10])\b', r'\1.\2'),  # Channel count: 5.1, 2.0
            (r'\b([hx]) (26[45])\b', r'\1.\2', re.I),  # h264, x264, x265, h265
            (r'\b(DDP?) (EX)\b', r'\1-\2', re.I),  # DD-EX
            (r'\b(DTS) (HD(?!-?(?:TS|cam|TV))|ES|EX|X(?![ .]26))\b', r'\1-\2', re.I),  # DTS
            (r'\b(AAC) (LC)\b', r'\1-\2', re.I),  # AAC-LC
            (r'\b(AC) (3)\b', r'\1-\2', re.I),  # AC-3
            (r'\b(HE) (AAC)\b', r'\1-\2', re.I),  # HE-AAC
            (r'\b(WEB|Blu|DVD|DCP|B[DR]|HD) (DL|Ray|RIP|Rip|TS)\b', r'\1-\2', re.I),
        ]
        for pattern in replacements:
            if len(pattern) == 3:
                old, new, flags = pattern
                filename = re.sub(old, new, filename, flags=flags)
            else:
                old, new = pattern
                filename = re.sub(old, new, filename)
        return filename

    def _make_temp_webclient(self) -> 'WebClient':
        """Temporary WebClient with cookies copied from the main session."""
        web = WebClient(self.PROVIDER, self.base_link)
        web.set_cookies(self.web.get_cookies())
        return web

    def _sync_notepad_with_library(self, notes_list, library_links2, library_links, web=None):
        """Remove notepad entries that no longer exist in library history"""
        history_filenames = set()
        for library_link, _ in library_links2:
            filename = self._extract_filename_from_url(library_link)
            history_filenames.add(self._decode_url_text(filename))
        for library_link in library_links:
            filename = self._extract_filename_from_url(library_link)
            history_filenames.add(self._decode_url_text(filename))
        # notes store sciagaj links without the filename part, i.e. .../sciagaj/<hash>
        history_hash_links = {library_link.rpartition('/')[0] for library_link in library_links}

        notes_list_cleaned = []
        removed_count = 0

        for note_item in notes_list:
            should_keep = False
            try:
                note_link = note_item[1]
                note_filename = note_item[2]
                link_filename = self._decode_url_text(self._extract_filename_from_url(note_link))

                if (note_filename and any(note_filename in hf for hf in history_filenames)) or \
                        (link_filename and link_filename in history_filenames) or \
                        note_link in history_hash_links:
                    should_keep = True
            except (IndexError, KeyError):
                should_keep = True

            if should_keep:
                notes_list_cleaned.append(note_item)
            else:
                removed_count += 1

        if removed_count > 0:
            try:
                (web or self.web).save_notepad(json.dumps(notes_list_cleaned))
            except Exception:
                fflog_exc('Error during automatic notepad cleaning')
            return notes_list_cleaned
        return notes_list

    def files_on_user_account(self):
        library_cache, library_links2, notes_list = self._fetch_files_on_user_account()
        return library_cache, list(library_links2), notes_list

    def _fetch_files_on_user_account(self, web=None):
        web = web or self.web
        notes_list = []
        library_cache = {}

        # Get user notes
        if provider_value(self.PROVIDER, 'use_web_notebook_for_history'):
            notes_page_content = web.get_notepad()
            notes_value = client.parseDOM(notes_page_content, 'textarea', attrs={'class': 'notepad'})

            if notes_value:
                notes_value = notes_value[0].strip()
                if notes_value and notes_value.startswith('[') and notes_value.endswith(']'):
                    try:
                        notes_list = json.loads(notes_value)
                        for entry in notes_list:
                            if isinstance(entry, list) and len(entry) >= 5:
                                original_url, download_link, filename, size, expires = entry[:5]
                                # notes_list is newest-first (resolve prepends); keep the first
                                # hit so a stale older re-download doesn't overwrite the live link
                                if original_url in library_cache:
                                    continue
                                library_cache[original_url] = {
                                    'filename': filename,
                                    'size': size,
                                    'url': original_url,
                                    'on_account_link': download_link,
                                    'on_account_expires': expires,
                                    'hosting': re.sub(r'https?://(?:www\.)?([^.]+)\..+', r'\1', original_url, flags=re.I).upper(),
                                }
                    except (json.JSONDecodeError, ValueError):
                        fflog('notepad parse error: unsupported format, data ignored')
                        notes_list = []
                elif notes_value:
                    fflog('notepad parse error: not a JSON list')

        # Get library history
        html = web.get_library()
        table = client.parseDOM(html, 'table', attrs={'class': 'list'})
        library_links = client.parseDOM(table, 'input', ret='value') or []
        rows = client.parseDOM(table, 'tr')[1:] if library_links else []
        library_links_exp = [client.parseDOM(row, 'td')[3] for row in rows]
        library_links2 = list(zip(library_links, library_links_exp))

        # Sync notepad with library
        if provider_value(self.PROVIDER, 'use_web_notebook_for_history') and notes_list:
            notes_list = self._sync_notepad_with_library(notes_list, library_links2, library_links, web=web)
            if notes_list:
                notepad_links = {note[1] for note in notes_list if note and len(note) > 1}
                library_links2 = [link for link in library_links2 if link[0].rpartition('/')[0] not in notepad_links]

        return library_cache, library_links2, notes_list

    def check_if_file_is_on_user_account(self, library_links, links, filenames, library_cache=None):
        match_quality = ''
        on_account = False
        on_account_expires = ''
        on_account_link = ''
        last_checked_link = None  # Track last link for Method 3

        filename = filenames
        if isinstance(links, str):
            links = [links]

        for link in links:
            last_checked_link = link  # Remember for Method 3

            # Method 1: Check via cache (notepad data) - based on original_url
            if library_cache:
                # Compare link with original_url (the KEY in library_cache)
                if link in library_cache:
                    cached_data = library_cache[link]
                    on_account = True
                    on_account_link = cached_data['on_account_link']
                    on_account_expires = cached_data['on_account_expires']
                    match_quality = ' ***'  # Perfect match from notepad
                    break

            # Method 2: Check via link comparison (older method - library history)
            if not on_account:
                for index in range(len(library_links) - 1, -1, -1):
                    item_org = library_links[index]
                    item_filename = self._extract_filename_from_url(item_org[0])
                    item = self._decode_url_text(item_filename).replace('_', ' ').replace('.', ' ')
                    url = self._decode_url_text(link).replace('_', ' ').replace('.', ' ')

                    item = self._normalize_twojplik_filename(item, link)
                    url = self._normalize_twojplik_filename(url, link)

                    if item in url:
                        on_account_link = item_org[0]
                        on_account_expires = item_org[1]
                        on_account = True
                        if on_account_link != link:
                            match_quality = ' **'  # Two stars - good match
                        else:
                            match_quality = ' ***'  # Three stars - perfect match
                        del library_links[index]
                        break

            if on_account:
                break

        # Method 3: Check via filename (uses last checked link)
        if not on_account and filenames and last_checked_link:
            filenames = [filenames] if isinstance(filenames, str) else filenames

            for index in range(len(library_links) - 1, -1, -1):
                item_org = library_links[index]
                item = item_org[0]
                item = self._normalize_twojplik_filename(item, last_checked_link)

                for filename in filenames:
                    if not filename:
                        continue
                    fn = self._normalize_twojplik_filename(filename, last_checked_link)

                    if self._decode_url_text(fn) in self._decode_url_text(item):
                        on_account_link = item_org[0]
                        on_account_expires = item_org[1]
                        on_account = True
                        match_quality = ' *'  # Worst match (by filename)
                        del library_links[index]
                        break
                if on_account:
                    break

        # Format expiration date
        if on_account_expires:
            try:
                expires_dt = datetime.strptime(on_account_expires, '%H:%M %d.%m.%Y') + timedelta(hours=24)
                on_account_expires = expires_dt.strftime('%d.%m %H:%M')
            except ValueError:  # Date is already formatted in notes
                pass
            except Exception:
                fflog_exc()
                pass

        return on_account, on_account_link, match_quality, on_account_expires

    def login(self) -> bool:
        """Log in (the stored session or a new one), return True if logged in."""
        fflog('login: checking session', 0)

        pass_hash = hashlib.md5(self.user_pass.encode()).hexdigest()[:8]
        cache_key = f"cookie_{self.user_name}_{pass_hash}"
        cookie_ttl = COOKIE_EXPIRATION_HOURS * 60 * 60
        cookies = self.store.get(cache_key) or ''   # expired cookies are not there

        def _setup_parallel_session():
            if not (self.user_name and self.user_pass):
                return
            for index, web in enumerate(self.web_parallel):
                parallel_cache_key = f"cookie_parallel{index + 1}_{self.user_name}_{pass_hash}"
                if p_cookies := self.store.get(parallel_cache_key):
                    web.set_cookies(p_cookies)
                    fflog(f'login: web_parallel[{index}] ok (cached)', 0)
                elif web.login(self.user_name, self.user_pass):
                    self.store.set(parallel_cache_key, web.get_cookies(), ttl=cookie_ttl)
                    fflog(f'login: web_parallel[{index}] ok', 0)
                else:
                    # Its own login POST failed - reuse the (working) primary session
                    # cookies so the parallel search doesn't run logged out.
                    web.set_cookies(self.web.get_cookies())
                    fflog(f'login: web_parallel[{index}] reusing primary session cookies', 0)

        # Use the stored (current) cookies
        self._account_page = ''
        if cookies:
            self.web.set_cookies(cookies)
            if self.user_name and _is_logged_in_page(page := self.web.get_account_info()):
                self._account_page = page   # the transfer limit is there (_fetch_remaining_limit())
                fflog('login: ok (cached session)', 0)
                _setup_parallel_session()
                return True
            fflog('login: cached session rejected by server, re-logging in', 0)
            # The parallel sessions are not checked, so drop them too - most likely dead as well.
            self.store.delete(cache_key)
            for index in range(len(self.web_parallel)):
                self.store.delete(f"cookie_parallel{index + 1}_{self.user_name}_{pass_hash}")

        # Login user
        if self.user_name and self.user_pass:
            if self.store.login_refused(self.user_name, self.user_pass):
                fflog('login: failed lately, not tried again with the same credentials')
            elif self.web.login(self.user_name, self.user_pass):
                fflog('login: ok', 0)
                self.store.set(cache_key, self.web.get_cookies(), ttl=cookie_ttl)
                _setup_parallel_session()
                return True
            else:
                fflog('login: failed')
                self.store.refuse_login(self.user_name, self.user_pass, ttl=const.sources.providers.login_retry)
            # also while a failed login is remembered: the user should know why nothing is found
            control.groupedInfoDialog(f'{self.PROVIDER}_login_failed', L(32849, 'Login failed'), heading=self.PROVIDER, icon='ERROR')
        else:
            fflog('login: no credentials')
            control.groupedInfoDialog(f'{self.PROVIDER}_no_credentials', L(30314, 'No login credentials - check settings'), heading=self.PROVIDER, icon='ERROR')
        return False

    def _fetch_remaining_limit(self, web: WebClient | None = None) -> None:
        try:
            # the account page of the session check if there was one (no request)
            limit_info_html = self._account_page or (web or self.web).get_account_info()
            limit_info_div = client.parseDOM(limit_info_html, 'div', attrs={'class': 'textPremium'})
            limit_info_b = client.parseDOM(limit_info_div, 'b')
            if limit_info_b:
                remaining_limit_str = str(limit_info_b[-1])
                remaining_limit_str = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", '', remaining_limit_str)
                remaining_limit_str = re.sub('<[^>]+>', '', remaining_limit_str)
                remaining_limit_str = remaining_limit_str.replace(',', '.')
                self.remaining_limit_mb = int(source_utils.convert_size_to_bytes(remaining_limit_str) / (1024 * 1024))
                fflog(f"available limit: {self.remaining_limit_mb} MB")
        except Exception:
            fflog_exc('Failed to fetch limit information')
# ─── Tb7 ─────────────────────────────────────────────────────────────────────────


class Tb7(_source):
    """Scraper for tb7."""
    PROVIDER: ClassVar[str] = 'tb7'
    LABEL: ClassVar[str] = 'TB7'
    URL: ClassVar[str] = 'https://tb7.pl'


# ─── Xt7 ─────────────────────────────────────────────────────────────────────────

class Xt7(_source):
    """Scraper for xt7."""
    PROVIDER: ClassVar[str] = 'xt7'
    LABEL: ClassVar[str] = 'XT7'
    URL: ClassVar[str] = 'https://xt7.pl'


# ─── Gb7 ─────────────────────────────────────────────────────────────────────────

class Gb7(_source):
    """Scraper for gb7."""
    PROVIDER: ClassVar[str] = 'gb7'
    LABEL: ClassVar[str] = 'GB7'
    URL: ClassVar[str] = 'https://gb7.pl'


def register(sources: list[ProviderModule], group: str) -> None:
    """Register all scrapers."""
    from lib.sources import ProviderModule
    for src in (Tb7, Xt7, Gb7):
        sources.append(ProviderModule(name=src.PROVIDER, provider=src(), group=group))
