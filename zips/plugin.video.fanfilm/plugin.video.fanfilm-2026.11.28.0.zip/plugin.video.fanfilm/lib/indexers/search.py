
from typing import Any, Optional, Union, Tuple, Sequence, TYPE_CHECKING
from typing_extensions import Protocol
import json
import re
from attrs import define, field
from xbmcgui import Dialog, INPUT_ALPHANUM, INPUT_NUMERIC

from ..ff.routing import RouteObject, route, url_for, route_redirect, PathArg
from ..ff.menu import CMenu
from ..ff.item import FFItem
from ..ff.discover import filters_from_text, filters_text, filter_pairs, describe, discover_url, media_fields
from ..ff.db.search import get_search_history, get_search_item, set_search_item, touch_search_item, SearchEntry
from ..ff.db.search import remove_search_item, remove_search_history
from ..ff import control
from ..ff.control import refresh, update, close_busy_dialog, busy_section
from ..ff.logs import fflog
from ..kolang import L
from .core import Indexer, no_content
from .folder import item_folder_route, pagination, list_directory
from const import const, CONST_REF
if TYPE_CHECKING:
    from ..api.tmdb import SearchFilters


class SearchCallback(Protocol):

    # `type` is usual SearchType for any TMDB-based search,
    # but can be also used for other purposes (like "anime", "mdblist.list", etc.) to separate search history in DB.
    def __call__(self, query: str, *, page: int = 1, type: Optional[str] = None, **filters) -> None: ...


class SearchIndexerProtocol(Protocol):

    # see: SearchCallback for details on parameters
    def search_items(self, query: str, *, page: int = 1, type: Optional[str] = None, **filters) -> None: ...


class SearchFoundIndexerProtocol(SearchIndexerProtocol, Protocol):

    # the found items (a folder: Add to..., the library, the filter of watching), see: SearchCallback for details on parameters
    def search_found(self, query: str, *, page: int = 1, type: Optional[str] = None, **filters) -> Sequence[FFItem]: ...


class SearchFullIndexerProtocol(SearchIndexerProtocol, Protocol):
    TYPE: str  # was SearchType
    SEARCH_NAME: Optional[str]
    SEARCH_ITEM_ICON: Optional[str]
    SEARCH_ICON: Optional[str]
    const: Any

    def search(self) -> None: ...


@define
class SearchIndexer:
    """Search indexer definition for add-on."""

    search_items: SearchCallback
    type: Optional[str] = None
    name: Optional[str] = None
    label: Optional[str] = None
    item_icon: Optional[str] = field(default=None, kw_only=True)
    search_icon: Optional[str] = field(default=None, kw_only=True)
    const: Any = field(default=None, kw_only=True)

    @property
    def TYPE(self) -> Optional[str]:
        return self.type

    @property
    def SEARCH_NAME(self) -> Optional[str]:
        return self.name

    @property
    def SEARCH_ITEM_ICON(self) -> Optional[str]:
        return self.item_icon

    @property
    def SEARCH_ICON(self) -> Optional[str]:
        return self.search_icon


class Search(RouteObject):
    """General media searching."""

    def __init__(self,
                 indexer: Union[SearchIndexerProtocol, SearchCallback],
                 *,
                 type: Optional[str] = None,  # was SearchType
                 name: Optional[str] = None,
                 label: Optional[str] = None,
                 item_icon: Optional[str] = None,
                 search_icon: Optional[str] = None,
                 ) -> None:
        if callable(indexer):
            indexer = SearchIndexer(search_items=indexer, type=type, name=name, item_icon=item_icon, search_icon=search_icon)
        else:
            indexer = indexer
        if not type:
            type = getattr(indexer, 'TYPE', None)
            if not type:
                type = indexer.__qualname__.lower()
        if item_icon is None:
            item_icon = getattr(indexer, 'SEARCH_ITEM_ICON', None)
        if search_icon is None:
            search_icon = getattr(indexer, 'SEARCH_ICON', item_icon)
        if item_icon is None:
            item_icon = getattr(indexer, 'IMAGE', None)
        if search_icon is None:
            search_icon = 'common/search.png'
        #: Search for this indexer.
        self.indexer: SearchIndexerProtocol = indexer
        #: Type of search items.
        self.type: str = type
        #: Name of search items (type or other – like anime). Used to separate history in DB.
        self.name: str = name if name else (getattr(indexer, 'SEARCH_NAME', None) or self.type)
        #: Label for search menu. If not set, indexer name or type will be used.
        self.label = label
        #: Icon for search items in history list (elements).
        self.item_icon = item_icon
        #: Icon for "New search" entry.
        self.search_icon = search_icon

    @route('/')
    def home(self) -> None:
        """Search main menu."""
        if not self.indexer:
            return no_content('addons')
        item_icon = self.item_icon
        search_icon = self.search_icon
        if search_icon is None:
            search_icon = 'common/search.png'
        history = get_search_history(self.name)
        with list_directory(view=const.indexer.search.view, thumb=item_icon) as kdir:
            year_dialog = const.indexer.search.year_dialog
            if not getattr(getattr(self.indexer, 'const', None), 'search', None):
                year_dialog = 'never'
            always_year = year_dialog == 'always'
            new = kdir.action(L(32603, 'New search...'), url_for(self.new, year=always_year), style='[B]{}[/B]', thumb=search_icon, menu=[
                CMenu(L(30411, 'New search with year...'), url_for(self.new, year=True), visible=(year_dialog == 'context-menu')),
            ])
            new.position = 'top'
            if year_dialog == 'entry':
                new = kdir.action(L(30411, 'New search with year...'), url_for(self.new, year=True), style='[B]{}[/B]', thumb=search_icon)
                new.position = 'top'
            if advanced := self.advanced_supported:
                new = kdir.action(L(31399, 'Advanced search...'), url_for(self.advanced), style='[B]{}[/B]', thumb=search_icon)
                new.position = 'top'
            memo: 'dict[str, dict[str, str]]' = {}  # the choices of the descriptions of the entries read once
            for it in history:
                query, _ = self._query_options(it, colorize=True, memo=memo)
                discovered = advanced and 'discover' in json.loads(it.options or '{}')
                kdir.folder(query, self.entry_url(it.id), menu=(
                    (L(30180, 'Remove item'), url_for(self.remove, id=it.id)),
                    (L(30181, 'Delete history'), self.clear),
                    (L(30182, 'Edit item'), url_for(self.advanced if discovered else self.edit, id=it.id)),
                    CMenu(L(31400, 'Refine...'), url_for(self.advanced, id=it.id), visible=advanced and not discovered),
                    CMenu(L(31401, 'Save as a FanFilm list...'), url_for(self.save_list, id=it.id), visible=advanced),
                ))

    @route
    def new(self, query: Optional[str] = None, *, year: bool = False) -> None:
        """Create new search."""
        if not self.indexer:
            return no_content('addons')
        with busy_section():  # until Kodi shows its own busy dialog of the found items (it waits for their folder) or they are shown
            if not query:
                # xbmc.Keyboard(text, title)  ...doModal()
                query = Dialog().input(self.label or L(32010, 'Search'), type=INPUT_ALPHANUM)
            query = re.sub(r'\s+', ' ', query).strip()
            if query:
                options = {}
                if year and (value := Dialog().input(L(30412, 'Year (optional)'), type=INPUT_NUMERIC)) and value.isdecimal():
                    options['year'] = int(value)
                else:
                    xquery, xopt = self._query_options(SearchEntry(search_name=self.name, search_type=self.type, query=query, updated_at=0))
                    if xyear := xopt.get('year'):
                        query = xquery
                        options['year'] = xyear
                sid = set_search_item(name=self.name, type=self.type, query=query, options=options)
                route_redirect(self.entry, id=sid)
                url = str(self.entry_url(sid) or '')
                update(url)
                if url:
                    control.wait_for_folder(url, const.indexer.search.busy_handover, busy=True)
            else:
                update(str(url_for(self.home) or ''))

    @property
    def advanced_supported(self) -> bool:
        """Return True if the indexer has the advanced search (a discovery of TMDB of movies / shows: the found items, the final filters)."""
        return self.found_supported and hasattr(self.indexer, 'discover_filters')

    @property
    def found_supported(self) -> bool:
        """
        Return True if the found items of the search are a folder (`found()`: a discovery of TMDB of movies / shows - Add to..., the
        library); the other searches (people, collections, multi, the lists) show their found items themselves (`search_items()`).
        """
        return self.type in ('movie', 'show') and hasattr(self.indexer, 'search_found')

    @route
    def advanced(self, id: Optional[PathArg[int]] = None) -> None:
        """
        The advanced search (its window): a new one (the least votes and the order of the settings), of the entry `id` (its filters; a
        simple one: the order of its found items); the choice is a new entry, its found items shown.
        """
        from ..windows.discover import DiscoverDialog
        if not self.advanced_supported:
            return no_content('addons')
        indexer: Any = self.indexer
        close_busy_dialog()
        defaults = dict(filter_pairs({key: value for key, value in indexer.discover_filters().items() if key in ('vote_count', 'sort_by')}))
        sit = get_search_item(id, name=self.name) if id else None
        query, filters, names = ('', defaults, {}) if sit is None else self.entry_filters(sit)

        def count(text: str, found_filters: 'Any') -> Optional[int]:
            """Return the number of the found items of the text and the filters."""
            items = indexer.search_found(text, page=1, type=self.type, **found_filters)
            return getattr(items, 'total_results', None)

        result = DiscoverDialog(media=self.type, query=query, filters=filters, names=names, defaults=defaults, count=count,
                                choices=DiscoverDialog.grid_choices(self.type)).doModal()  # the grids as large as their choices
        if result is None:
            return
        options: 'dict[str, Any]' = {'discover': filters_text(result.filters)}
        if result.names:
            options['names'] = result.names
        sid = set_search_item(name=self.name, type=self.type, query=result.query, options=options)
        update(str(self.entry_url(sid) or ''))

    def entry_filters(self, sit: 'SearchEntry') -> 'Tuple[str, dict[str, Any], dict[str, str]]':
        """
        Return the text, the filters (the keys of TMDB) and the names of the found choices of the search entry: a simple search with the
        year - the range of the years of the media, the order of its found items (none: the popular first).
        """
        query, found = self._query_options(sit)
        filters = dict(filter_pairs(found))
        if year := filters.pop('year', None):  # a simple search with the year: the range of the years of the media
            filters.update(next(field for field in media_fields(self.type) if field.years).write((int(year), int(year))))  # type: ignore[arg-type]
        filters.setdefault('sort_by', 'popularity.desc')  # the order of the found items of the entry
        return query, filters, json.loads(sit.options or '{}').get('names') or {}

    @route
    def save_list(self, id: PathArg[int]) -> None:
        """
        Save the search entry `id` as a dynamic list of FanFilm (its name asked): the address of its discovery with all its filters (the
        ones of the indexer too, e.g. anime) - its media come from it, no items can be added.
        """
        from ..ff.ui import ui
        from ..ff.ownlists import own_db
        sit = get_search_item(id, name=self.name)
        if not self.advanced_supported or sit is None:
            return
        query, filters = self._query_options(sit)
        names = json.loads(sit.options or '{}').get('names')
        name = ui.input(L(31402, 'Name of the list'), ' '.join(filter(None, (query, describe(self.type, filters_from_text(filters_text(filters)), names)))))
        if not name or not (name := name.strip()):
            return
        if own_db.folder(name) is not None:
            ui.notify(L(31401, 'Save as a FanFilm list...'), L(31403, 'The list exists already'), error=True)
        elif self.create_list(name, query, filters):
            ui.notify(L(31401, 'Save as a FanFilm list...'), name)
        else:
            ui.notify(L(31401, 'Save as a FanFilm list...'), L(31421, 'The list is not saved (the log tells why)'), error=True)

    def create_list(self, name: str, query: str, filters: 'Any') -> bool:
        """
        Create a dynamic list of FanFilm of the search (the text, the filters of the entry: its order, else the popular first) - the address
        of its discovery with all its filters (the ones of the indexer too, e.g. anime); False: not created (the name is taken).
        """
        from ..ff.ownlists import own_db
        from cdefs import ListType
        indexer: Any = self.indexer
        found = indexer.discover_filters(votes=-1, **{'sort_by': 'popularity.desc', **filters})
        if query:
            found['with_text_query'] = query
        try:
            own_db.create_list(name, type=ListType.new(self.type), link=discover_url(self.type, found))
        except Exception as exc:
            fflog(f'Save the search as the own list {name!r} failed: {exc!r}')
            return False
        return True

    @route
    def ext(self, query: Optional[str] = None, *, page: PathArg[int] = 1, year: Optional[int] = None) -> None:
        """External entry point (EPG context menu, other add-ons, skins): the results only, they lead back to the caller."""
        if not self.indexer:
            return no_content('addons')

        # The parent of the results ("..", ParentDir) has no query: back to the caller window, not to the search menu.
        if not query:
            close_busy_dialog()
            if (handle := control.current_call().handle) >= 0:
                control.end_of_directory(handle, succeeded=False)  # Kodi stays on the results first...
            control.execute('Action(PreviousMenu)')  # ...then the media window closes to the caller
            return

        with busy_section():
            options = {'year': int(year)} if year else {}
            if const.indexer.search.ext_history:
                self.search(id=set_search_item(name=self.name, type=self.type, query=query, options=options), page=page)
            else:
                sit = SearchEntry(search_name=self.name, search_type=self.type, query=query, updated_at=0, options=json.dumps(options))
                self._search_items(sit, page=page)

    @route
    def edit(self, id: PathArg[int]) -> None:
        """Edit search item."""
        sit = get_search_item(id, name=self.name)
        if not self.indexer or not sit:
            return no_content('addons')
        # xbmc.Keyboard(text, title)  ...doModal()
        query = Dialog().input(self.label or L(32010, 'Search'), sit.query, type=INPUT_ALPHANUM)
        query = query.strip()
        if query:
            sid = set_search_item(name=sit.search_name, type=sit.search_type, query=query, options=json.loads(sit.options), id=id)
            # route_redirect(self.entry, id=sid)
            # self.search(sid)
            update(str(self.entry_url(sid) or ''))
        else:
            return self.home()

    @route('/')
    def entry(self, id: PathArg[int], *, page: PathArg[int] = 1) -> None:
        """Search entry point (the found items of an indexer which gives them: their folder)."""
        if not self.indexer:
            return no_content('addons')
        if self.found_supported:
            self.found(id=id, page=page)
        else:
            self.search(id, page=page)

    def entry_url(self, id: int) -> Any:
        """Return the URL of the search entry `id`: its folder of the found items if the indexer gives them, else its entry point."""
        return url_for(self.found if self.found_supported else self.entry, id=id)

    @item_folder_route('found', limit=CONST_REF.indexer.add_to_limit)
    @pagination
    def found(self, id: PathArg[int], *, page: PathArg[int] = 1) -> Sequence[FFItem]:
        """The found items of the search entry `id` (a folder: Add to..., the library, the filter of watching)."""
        sit = get_search_item(id, name=self.name)
        indexer: Optional[SearchFoundIndexerProtocol] = self.indexer if self.found_supported else None  # type: ignore[assignment]
        if indexer is None or not sit:
            return ()
        touch_search_item(id)
        query, filters = self._query_options(sit)
        filters.setdefault('sort_by', 'popularity.desc')  # type: ignore[typeddict-item]  # the order of the entry, else the popular first
        return indexer.search_found(query, page=page, type=self.type, **filters)

    def search(self, id: int, *, page: int = 1) -> None:
        """Search for items."""
        sit = get_search_item(id, name=self.name)
        if not self.indexer or not sit:
            return no_content('addons')
        touch_search_item(id)
        return self._search_items(sit, page=page)

    def _search_items(self, sit: 'SearchEntry', *, page: int = 1) -> None:
        """Search for items of the search entry (from the history or not)."""
        query, filters = self._query_options(sit)
        filters.setdefault('sort_by', 'popularity.desc')  # type: ignore[typeddict-item]  # the order of the entry, else the popular first
        return self.indexer.search_items(query, page=page, type=self.type, **filters)

    def _query_options(self, sit: 'SearchEntry', *, colorize: bool = False, memo: 'Optional[dict[str, dict[str, str]]]' = None) -> 'Tuple[str, SearchFilters]':
        """Get query and options for search item."""
        query = sit.query.strip()
        filters: 'SearchFilters' = {}
        try:
            cs = self.indexer.const.search
        except AttributeError:
            pass
        else:
            if cs.year_pattern and (mch := re.search(cs.year_pattern, sit.query)):
                filters['year'] = int(next(iter(v for v in mch.groups() if v)))
                hit = mch.group(0)
                if colorize:
                    query = query.replace(hit, const.indexer.search.query_option_format.format(hit, option=hit))
                else:
                    query = query.replace(hit, '').strip()
        if options := sit.options:
            options = json.loads(options)
            if discover := options.get('discover'):  # the filters of an advanced search (the query of a `tmdb://` address)
                found = filters_from_text(discover)
                filters.update(found)  # type: ignore[typeddict-item]
                if colorize and self.type in ('movie', 'show') and (text := describe(self.type, found, options.get('names'), memo=memo)):
                    query = ' '.join(filter(None, (query, const.indexer.search.query_option_format.format(text, option=text))))
            if year := options.get('year'):
                filters['year'] = year
                if colorize:
                    opt = f'({year})'
                    opt = const.indexer.search.query_option_format.format(opt, option=opt, year=year)
                    query = f'{query} {opt}'
        return query, filters

    @route
    def remove(self, id: PathArg[int]) -> None:
        """Remove history item."""
        remove_search_item(id=id)
        route_redirect(self.home)
        # self.home()
        # refresh()
        update(str(url_for(self.home) or ''))

    @route
    def clear(self) -> None:
        """Clear history (delete all items)."""
        if not const.indexer.search.clear_if_sure or Dialog().yesno(L(30181, 'Delete history'), L(32056, 'Are you sure?')):
            remove_search_history(name=self.name)
        route_redirect(self.home)
        update(str(url_for(self.home) or ''))
