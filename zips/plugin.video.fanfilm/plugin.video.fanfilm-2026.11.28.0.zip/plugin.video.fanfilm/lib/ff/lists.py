"""Common module for all kind of lists."""

from __future__ import annotations
from typing import Sequence, TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired, Literal, TypeAlias, cast
from functools import lru_cache
from attrs import frozen, define, field, evolve
from .item import FFItem
from ..defs import FFRef, RefType
from ..ff.logs import fflog, fflog_exc
from .config.options import AccountSettings, Library
from ..ff import theme
from ..kolang import L, LL
from cdefs import ListType, ListTarget, ListPointer, ListSection, ShowCxtMenu
from const import const
if TYPE_CHECKING:
    from typing import Any, Callable, Iterator, Iterable, ClassVar
    from ..kolang import LazyLabel
    from .config.blocks import Card
    from .accounts import Account, Capability
    from .db.kvstore import KeyValueStore
    from .item import ArtValues
    from xbmcgui import ListItem
    # from ..api.tmdb import UserGeneralListType


# class AddToServices(TypedDict, extra_items=Sequence[ListPointer]):
#     """All services and theirs list settings. Keys are ListService (defined pointers) or any (any pointers)."""
#     local: NotRequired[Sequence[Literal['library', 'own:favorites', 'own:watchlist', 'own:user', 'logs']]]
#     own: NotRequired[Sequence[Literal['own:favorites', 'own:watchlist', 'own:user']]]
#     trakt: NotRequired[Sequence[Literal['trakt:favorites', 'trakt:watchlist', 'trakt:collection', 'trakt:user']]]
#     tmdb: NotRequired[Sequence[Literal['tmdb:favorites', 'tmdb:watchlist', 'tmdb:user']]]
#     library: NotRequired[Sequence[Literal['library']]]
#     logs: NotRequired[Sequence[Literal['logs']]]


AddToServiceDefs: TypeAlias = 'dict[str, Sequence[ListPointer]]'
"""All services and theirs lists pointers. Keys are L() translated service names, values are available pointers for this service."""

AddToServices: TypeAlias = 'dict[str, Sequence[ServiceDescr]]'
"""All services and theirs lists descriptions. Keys are L() translated service names, values are available pointers for this service."""


class ListConvertRules(TypedDict):
    """
    Rules for convert refs. Missing key means 'ignore'.

    Dialog "add to…" can filter out those options by const.dialog.add_to.allowed_conversions.
    """

    show: NotRequired[Literal['ignore', 'season', 'episode']]
    season: NotRequired[Literal['ignore', 'show', 'episode']]
    episode: NotRequired[Literal['ignore', 'show', 'season']]
    collection: NotRequired[Literal['ignore', 'movie']]
    movie: NotRequired[Literal['ignore', 'collection']]


#: All available media conversions. Build from ListConvertRules. Can be filter-out by const.dialog.add_to.allowed_conversions.
AVALIABLE_CONVERSITION: dict[RefType, ListType] = {
    'collection': ListType.MOVIE,
    'movie': ListType.COLLECTION,
    'show': ListType.SEASON | ListType.EPISODE,
    'season': ListType.SHOW | ListType.EPISODE,
    'episode': ListType.SHOW | ListType.SEASON,
}


class AddToListCreateOptions(TypedDict):
    """Options for new list creation."""

    public: NotRequired[bool]


AddToListRemoveOptionsNames = Literal['items', 'lists', 'rename', 'image']


class AddToListRemoveOptions(TypedDict):
    """Options for removing (items and lists) and for renaming lists."""

    items: NotRequired[bool]  # default True
    lists: NotRequired[bool]  # default False
    rename: NotRequired[bool]  # default False
    image: NotRequired[bool]  # default False


def converted_types(types: ListType = ListType.ALL) -> ListType:
    """Return real enabled conversions for `types`."""
    ref_types: set[RefType] = AVALIABLE_CONVERSITION.keys() & const.dialog.add_to.allowed_conversions.keys()
    allowed = ListType.NONE
    for ref_type in ref_types:
        if ListType.from_media_ref(ref_type) & types:
            allowed |= AVALIABLE_CONVERSITION[ref_type] & const.dialog.add_to.allowed_conversions[ref_type]
    return allowed


def convert_refs(refs: Iterable[FFRef], *, allowed: ListType, rules: ListConvertRules | str | None = None) -> Sequence[FFRef]:
    """
    Convert refs to allowed types with `convert` rules.

    Rules could be as string, ex.: 'collection:movie,show:episode'.
    """
    # TODO: split process into steps:
    #       1. scan for conversion and collect all items to need to be expanded
    #       2  get extra needed info from TMDB (in parallel)
    #       3. convert all items in order using collected data

    def convert(it: FFRef) -> Iterator[FFRef]:
        ref = it.ref
        real_type = ref.real_type
        typ = ListType.from_media_ref(real_type)
        if typ & allowed:
            yield it
        elif real_type == 'movie':
            if _rules.get('movie') == 'collection':
                ...  # Oh no! I have no collection here!
        elif real_type == 'show':
            if (rule := _rules.get('show')) == 'season':
                ...  # Oh no! I have no seasons here (no show content)!
            elif rule == 'episode':
                ...  # Oh no! I have no episodes here (no show content)!
        elif real_type == 'season':
            if (rule := _rules.get('season')) == 'show':
                if TYPE_CHECKING:
                    assert ref.show_ref
                yield ref.show_ref
            elif rule == 'episode':
                ...  # Oh no! I have no episodes here (no season content)!
        elif real_type == 'episode':
            if (rule := _rules.get('episode')) == 'show':
                if TYPE_CHECKING:
                    assert ref.show_ref
                yield ref.show_ref
            elif rule == 'season':
                if TYPE_CHECKING:
                    assert ref.season_ref
                yield ref.season_ref
        elif real_type == 'collection':
            if _rules.get('collection') == 'movie':
                ...  # Oh no! I have no movies here (no collection content)!

    # parse rules if string
    _rules: ListConvertRules
    if rules is None:
        _rules = {}
    elif isinstance(rules, str):
        _rules = {k: v for rr in (convert or '').split(',') for k, _, v in (rr.partition(':'),) if k and v}  # type: ignore[reportAssignmentType]
    else:
        _rules = rules

    # filter rules by allowed types, keys and values (except "ignore") are valid ListType type names
    _rules = {k: v for k, v in _rules.items() if ListType.from_media_ref(v) & allowed}  # type: ignore[reportAssignmentType]

    # convert
    return [x for ref in refs for x in convert(ref)]


@frozen
class ServiceDescr:
    """Service description for any list item add, including "add to" dialog."""

    #: Service pointer (name and optional section).
    pointer: ListPointer
    #: Options for new list creation, if supported by this service.
    #: If not None (even empty dict), then this service supports creating new lists.
    new_list_options: AddToListCreateOptions | None = field(default=None, kw_only=True)
    #: Supported list types for this service instance (pointer).
    types: ListType = field(default=ListType.NONE, kw_only=True)
    #: Supported new list types (default settings in new window).
    new_types: ListType = field(default=ListType.NONE, kw_only=True)
    #: Supported new list types, enabled to change.
    edit_types: ListType = field(default=ListType.NONE, kw_only=True)
    #: Supported new list types groups, select choices of set of types.  TODO: add support
    edit_type_choices: dict[str, ListType] = field(factory=dict, kw_only=True)
    #: Group names for all list pointers. Diffrent groups are separated (horizontal line) in Add-to dialog.
    group: str = field(default='', kw_only=True)
    #: When the pointer (service & section) is enabled in Add-to dialog.
    enabled: ShowCxtMenu = field(default=True, kw_only=True)
    #: Remove options (can remove items and/or lists).
    remove_options: AddToListRemoveOptions | None = field(default=None, kw_only=True)

    #: Default list types for this service, used if `types` is not set.
    DEFAULT_TYPES: ClassVar[ListType] = ListType.MAIN
    #: The types of a new list by default, used if `new_types` is not set.
    DEFAULT_NEW_TYPES: ClassVar[ListType] = ListType.MEDIA | ListType.COLLECTION

    def __attrs_post_init__(self) -> None:
        if not self.types:
            object.__setattr__(self, 'types',  self.DEFAULT_TYPES)

    @property
    def new_list_types(self) -> ListType:
        """Return the types of a new list by default (`new_types`, else `DEFAULT_NEW_TYPES`) the service supports."""
        return (self.new_types or self.DEFAULT_NEW_TYPES) & self.types

    def is_enabled(self) -> bool:
        """Return True if this service is enabled in Add-to dialog."""
        from .config import config
        return config.eval(self.enabled)

    def lists(self) -> Sequence[FFItem]:
        """Return list FFItem items for `pointer` to show lists in a dialog."""
        def proc(it: FFItem) -> FFItem:
            if types := it.getProperty('list_type'):
                types = ListType.new(types)
            else:
                types = self.types
                it.setProperty('list_type', str(types))
            for typ in ListType.iter_single_flags():
                it.setProperty(f'type.{typ.attr}', 'true' if typ & types else 'false')
            # if not it.getProperty('service_description'):
            #     it.setProperty('service_description', self.__class__.__name__)
            if not it.getProperty('service'):
                it.setProperty('service', service)
            if not it.getProperty('section'):
                it.setProperty('section', section)
            if not it.getProperty('pointer'):
                it.setProperty('pointer', pointer)
            if not it.getProperty('group'):
                it.setProperty('group', lst.group if lst else '')
            return it

        pointer: ListPointer = self.pointer
        lst = list_pointer(pointer)
        service, _, section = pointer.partition(':')
        return tuple(proc(it) for it in self._lists(pointer))

    def list_label(self, target: ListTarget) -> str:
        """
        Return the label of the list `target` as the Add-to dialog shows it (`lists()`): a fixed section (no list) is its only list,
        a list is found by its ID; else (unknown list, the lists can not be read) the ID or the section.
        """
        fallback = target.list or target.section or target.service
        try:
            lists = self.lists()
        except Exception:
            fflog_exc()
            return fallback
        if not target.list:
            return lists[0].getLabel() if len(lists) == 1 else fallback
        return next((it.getLabel() for it in lists if ListTarget.from_ffitem(it).list == target.list), fallback)

    # Override this method in subclass.
    def _lists(self, pointer: ListPointer) -> Iterable[FFItem]:
        if False:  # force generator
            yield

    def create_enabled(self) -> bool:
        """Return True if this service supports creating new lists."""
        return self.new_list_options is not None

    def create(self, name: str, *, type: ListType = ListType.MEDIA, public: bool = False) -> bool:
        """Create new list in this service."""
        return False

    # Override this method in subclass.
    def items(self, target: ListTarget) -> Iterable[FFRef] | None:
        """Return all items of the target list (library sync, its preview), None if not supported."""
        return None

    # Override this method in subclass.
    def _add_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        return None

    # Override this method in subclass.
    def _remove_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        return None

    # Override this method in subclass.
    def _remove_list(self, target: ListTarget) -> int | None:
        return None

    def _rename_list(self, target: ListTarget, name: str) -> str | None:
        return None

    def _set_list_image(self, target: ListTarget, art: ArtValues) -> bool:
        return False

    def add_items(self, target: ListTarget, items: Iterable[FFRef], *, quiet: bool = True) -> int | None:
        """
        Add items to this service.

        :param  target: target list to add items_str
        :param items: items to add
        :return: number of added items or None if not supported
        """
        return self._add_items(target, items)

    def add_folder_items(self, folder: FFItem, items: Iterable[FFRef]) -> int | None:
        """
        Add items to this service.

        :param  name: list name or location (e.g. 'favorites', 'watchlist')
        :param items: items to add
        :return: number of added items or None if not supported
        """
        return self._add_items(ListTarget.from_ffitem(folder), items)

    def has_remove_option(self, option: AddToListRemoveOptionsNames, target: ListTarget) -> bool:
        """
        Return True if this service supports removing items or lists.

        :param option: 'items' or 'lists'
        :return: True if supported, False otherwise
        """
        # special case, default True
        if option == 'items':
            return self.item_remove_enabled(target)
        # rest options are False by default
        if self.remove_options is None:
            return False
        return self.remove_options.get(option, False)

    def item_remove_enabled(self, target: ListTarget) -> bool:
        """Return True if this service supports removing items."""
        return self.remove_options is None or self.remove_options.get('items', True)
        # return self.remove_options is not None and self.remove_options.get('items', False)

    def remove_items(self, target: ListTarget, items: Iterable[FFRef], *, quiet: bool = True) -> int | None:
        """
        Remove items from this service.

        :param  target: target list to add items_str
        :param items: items to remove
        :return: number of added items or None if not supported
        """
        return self._remove_items(target, items)

    def list_remove_enabled(self, target: ListTarget) -> bool:
        """Return True if this service supports removing lists."""
        return self.remove_options is not None and self.remove_options.get('lists', False)

    def remove_list(self, target: ListTarget, *, quiet: bool = True) -> int | None:
        """
        Remove (delete) list from this service.

        :param  target: target list to remove
        :return: Number of removed lists (typically True), None if not supported
        """
        return self._remove_list(target)

    def rename_list(self, target: ListTarget, name: str) -> str | None:
        """Rename the list of this service, return its ID after it (a list of FanFilm: the new name), None on failure / not supported."""
        return self._rename_list(target, name)

    def set_list_image(self, target: ListTarget, art: ArtValues) -> bool:
        """Set the images of the list of this service (art keys, empty: the default ones), False on failure / not supported."""
        return self._set_list_image(target, art)

    def list_art(self, target: ListTarget) -> ArtValues:
        """Return the images of the list in the service (not the ones set by the user), empty if it has none."""
        return {}


class AccountServiceDescr(ServiceDescr):
    """
    List service of an account: a section of its lists (`AccountClient.LISTS`), read and changed by the vocabulary of its
    client (a fixed section by the method of its name and `set_<section>()`, own lists by `user_lists()`, `list_items()`,
    `set_in_list()`, `create_list()`, `delete_list()`); enabled when the account may change its lists.
    """

    @classmethod
    def from_spec(cls, pointer: ListPointer, spec: ListSection, *, deletable: bool, renamable: bool = False) -> AccountServiceDescr:
        """
        Return the list service of the section of a type (`<type>:<section>`) declared by its client (`deletable`,
        `renamable`: the own lists; an own list has always its image).
        """
        type_name, _, section = pointer.partition(':')
        own = section == 'user'
        return cls(pointer, group=f'{type_name}:{"user" if own else "generic"}', types=spec.types, new_types=spec.new_types,
                   edit_types=spec.edit_types, edit_type_choices=dict(spec.type_choices),
                   new_list_options=cast('AddToListCreateOptions', dict(spec.create)) if own and spec.create is not None else None,
                   remove_options={'lists': deletable, 'rename': renamable, 'image': True} if own else None)

    @property
    def account_id(self) -> str:
        """Return the account ID (the service part of the pointer: the address is the account ID)."""
        return self.pointer.partition(':')[0]

    @property
    def section(self) -> str:
        """Return the section of the pointer (`watchlist`, `favorites`, `collection`, `user`)."""
        return self.pointer.partition(':')[2]

    @property
    def type_name(self) -> str:
        """Return the account type name."""
        return self.account_id.partition('.')[0]

    @property
    def account(self) -> Account | None:
        """Return the account of the pointer."""
        from .accounts import get_account
        return get_account(self.account_id)

    @property
    def client(self) -> Any:
        """Return the API client of the account (the client of the type alias if the account is unknown)."""
        from .accounts import account_client, alias_client
        if (acc := self.account) is not None:
            return account_client(acc)
        return alias_client(self.type_name)

    def label(self, label: str) -> str:
        """Return the label of a list of the account: what tells the account (`account_tag()`) is added if the type has more accounts."""
        from .accounts import only_account
        from .account_admin import account_tag
        acc = self.account
        return label if acc is None or only_account(acc) else f'{label} ({account_tag(acc)})'

    def list_label(self, target: ListTarget) -> str:
        """Return the label of the list `target`; an own list is found among all of them (a read only one too: it can be renamed)."""
        if target.section != 'user' or not target.list:
            return super().list_label(target)
        try:
            lists = self.client.user_lists()
        except Exception:
            fflog_exc()
            return target.list
        return next((it.getLabel() for it in lists if ListTarget.from_ffitem(it).list == target.list), target.list)

    def is_enabled(self) -> bool:
        """Return True if the account may change its lists (Add-to)."""
        from .accounts import account_enabled
        return account_enabled(self.account_id, 'lists', 'write')

    def _lists(self, pointer: ListPointer) -> Iterable[FFItem]:
        """Return the fixed list of the section or the own lists (a read only one too: `list_readonly`, Add-to skips it)."""
        from .accounts import SERVICE_TYPES
        art = {'thumb': theme.art(f'services/{self.type_name}/main.png')}
        section = self.section
        if section != 'user':
            label = L(30657, '{service} {list}').format(service=SERVICE_TYPES[self.type_name].label, list=section_label(section))
            yield FFItem(self.label(label), properties={'list_type': str(self.types), 'list_id': section}, art=art)
            return
        for it in sorted(self.client.user_lists(), key=lambda it: it.label.lower()):
            it.setArt(art)
            yield it

    def create(self, name: str, *, type: ListType = ListType.MAIN, public: bool = False) -> bool:
        """Create an own list (of the chosen media if the user may choose them: choices or editable media)."""
        kwargs = {'list_type': type} if self.edit_type_choices or self.edit_types else {}
        return bool(self.client.create_list(name, public=public, **kwargs))

    def items(self, target: ListTarget) -> Iterable[FFRef] | None:
        """Return all items of the list (library sync, its preview)."""
        client = self.client
        if target.section == 'user':
            return client.list_items(target.list) if target.list else None
        if target.section in client.LISTS:
            return getattr(client, target.section)()
        return None

    def _set_items(self, target: ListTarget, items: Iterable[FFRef], state: bool) -> int | None:
        """Add (`state`) items to the list or remove them, None if not supported."""
        client = self.client
        if target.section == 'user':
            return client.set_in_list(target.list, items, state) if target.list else None
        if target.section in client.LISTS:
            return getattr(client, f'set_{target.section}')(items, state)
        return None

    def _add_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        return self._set_items(target, items, True)

    def _remove_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        return self._set_items(target, items, False)

    def _remove_list(self, target: ListTarget) -> int | None:
        if target.section == 'user' and target.list and (delete := getattr(self.client, 'delete_list', None)) is not None:
            if removed := int(delete(target.list)):
                set_list_image(self.account_id, target.list, {})
            return removed
        return None

    def _rename_list(self, target: ListTarget, name: str) -> str | None:
        """Rename an own list; a list ID changed by it (a list of FanFilm: its name) is changed in the lists picked for the library too."""
        if target.section != 'user' or not target.list or (rename := getattr(self.client, 'rename_list', None)) is None:
            return None
        if (new := rename(target.list, name)) is not None and new != target.list:
            rename_list_token(f'{self.account_id}:user:{target.list}', f'{self.account_id}:user:{new}')
            if art := list_image(self.account_id, target.list):
                set_list_image(self.account_id, target.list, {})
                set_list_image(self.account_id, new, art)
        return new

    def _set_list_image(self, target: ListTarget, art: ArtValues) -> bool:
        """Set the images of an own list."""
        if target.section != 'user' or not target.list:
            return False
        set_list_image(self.account_id, target.list, art)
        return True

    def list_art(self, target: ListTarget) -> ArtValues:
        """Return the images of the own list in the service (its folder from the client, as in the menu of lists)."""
        if target.section != 'user' or not target.list:
            return {}
        return next((it.getArt() for it in self.client.user_lists() if (it.getProperty('list_id') or str(it.ffid)) == target.list), {})



class LibraryServiceDescr(ServiceDescr):

    DEFAULT_TYPES: ClassVar[ListType] = ListType.MAIN

    def _lists(self, pointer: ListPointer) -> Iterable[FFItem]:
        if pointer == 'library':
            yield FFItem(L(32541, 'Library'), properties={'list_type': format(ListType.MAIN), 'service': 'library'})

    def _add_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        from ..service.client import service_client
        allowed = {'movie', 'show', 'season', 'episode'}
        items = tuple(it for it in items if it.ref.real_type in allowed)
        service_client.library_add(items, name=target.list or None, quiet=True)
        return len(items)


class LogsServiceDescr(ServiceDescr):

    DEFAULT_TYPES: ClassVar[ListType] = ListType.ALL

    def _lists(self, pointer: ListPointer) -> Iterable[FFItem]:
        if pointer == 'logs':
            yield FFItem(L(30359, 'Logs'), properties={'list_type': format(ListType.ALL)})

    def _add_items(self, target: ListTarget, items: Iterable[FFRef]) -> int | None:
        def dump_item(ref: FFRef) -> str:
            return f'  {ref}'
        items = tuple(items)
        items_str = '\n'.join(dump_item(it) for it in items)
        fflog.info(f'ADDING TO LOG... {len(items)} item(s):\n{items_str}')
        return len(items)


#: List services without accounts; the services of the account types (the lists of FanFilm too) are declared by their
#: clients (`AccountClient.LISTS`), see `list_pointers()`. Remove options: 'items' is True by default, 'lists' is False
#: by default.
LIST_POINTERS: dict[ListPointer, ServiceDescr] = {srv.pointer: srv for srv in (
    ServiceDescr('local'),  # dummy pointer, empty list, do NOT use it
    LibraryServiceDescr('library',           group='library',    enabled='config.library.enabled',
                        remove_options={'items': False}),
    LogsServiceDescr('logs',                 group='logs',       enabled='const.debug.add_to_logs',
                     remove_options={'items': False}),
)}


@lru_cache(maxsize=None)
def type_list_pointers(type_name: str) -> dict[ListPointer, ServiceDescr]:
    """Return the list services of the account type declared by its client (`AccountClient.LISTS`), none without a client."""
    from .accounts import alias_client
    if (client := alias_client(type_name)) is None:
        return {}
    deletable = callable(getattr(client, 'delete_list', None))
    renamable = callable(getattr(client, 'rename_list', None))
    return {f'{type_name}:{section}': AccountServiceDescr.from_spec(f'{type_name}:{section}', spec, deletable=deletable, renamable=renamable)
            for section, spec in client.LISTS.items()}


def list_pointers() -> dict[ListPointer, ServiceDescr]:
    """Return the list services of types: without accounts, the own lists, then the account types (in order of types)."""
    from .accounts import SERVICE_TYPES
    return {**LIST_POINTERS, **{ptr: srv for name in SERVICE_TYPES for ptr, srv in type_list_pointers(name).items()}}


def section_label(section: str) -> str:
    """Return the label of a fixed section of lists."""
    return {
        'collection': L(32032, 'Collection'),
        'favorites': L(30146, 'Favorites'),
        'watchlist': L(32033, 'Watchlist'),
        'ratings': L(30546, 'Ratings'),
    }.get(section, section)


def list_capability(section: str) -> Capability:
    """Return the capability an account reads a picked list of the section with: the ratings - the ratings, else the lists."""
    return 'ratings' if section == 'ratings' else 'lists'


def list_pointer(pointer: str) -> ServiceDescr | None:
    """
    Return the list service of the pointer `<account ID>:<section>` (the address is the account ID).

    `list_pointers()` are pointers of types, i.e. of the type alias (the first account of the type) and of services
    without accounts (library, logs); a pointer of another account is the pointer of its type bound to the account.
    """
    pointers = list_pointers()
    if (srv := pointers.get(cast(ListPointer, pointer))) is not None:
        return srv
    from .accounts import get_account
    account_id, sep, section = pointer.partition(':')
    if (acc := get_account(account_id)) is None:
        return None
    if (srv := pointers.get(cast(ListPointer, f'{acc.type.name}{sep}{section}'))) is None:
        return None
    return evolve(srv, pointer=pointer)


def account_pointers(pointer: str, *, account: str | None = None) -> list[ServiceDescr]:
    """Return the list services of the type pointer for all accounts of the type (or the `account` only), in order of accounts."""
    if (srv := list_pointers().get(cast(ListPointer, pointer))) is None:
        return []
    if not isinstance(srv, AccountServiceDescr):
        return [srv] if account is None or account == pointer.partition(':')[0] else []
    from .accounts import accounts
    type_name, sep, section = pointer.partition(':')
    return [evolve(srv, pointer=f'{acc.id}{sep}{section}') for acc in accounts()
            if acc.type.name == type_name and (account is None or acc.id == account)]


#: The key of the Add-to group of every account (with lists), the pointers of the account by `{account}`.
ACCOUNT_GROUP: str = '{account}'


def add_to_defs(service: str | None = None) -> AddToServiceDefs:
    """
    Return the Add-to dialog definition of a service (`const.dialog.add_to.lists.services`: a service without an account by
    its name, an account type by its name or the `{account}` template), the default one (`default`) without a service.
    """
    from .accounts import SERVICE_TYPES
    lists = const.dialog.add_to.lists
    if service is None:
        return lists.default
    if (defs := lists.services.get(service)) is not None:
        return defs
    return lists.services.get(ACCOUNT_GROUP, {}) if service in SERVICE_TYPES else {}


def account_group_label(account: Account) -> str:
    """Return the label of the group of an account (Add-to): the type label, what tells the account if the type has more accounts."""
    from .accounts import only_account
    from .account_admin import account_tag
    if only_account(account):
        return account.type.label
    return f'{account.type.label} ({account_tag(account)})'


def expand_pointer(pointer: str, *, account: str | None = None) -> list[ServiceDescr]:
    """
    Return the list services of a pointer of the Add-to definition for the accounts (only `account` if given): a pointer of a
    type, `<type>:*` - all sections of the type, `*:<section>` - the section of all types.
    """
    type_name, _, section = pointer.partition(':')
    if section == '*' or type_name == '*':
        return [srv for ptr in list_pointers() if (ptr.partition(':')[0] == type_name if section == '*' else ptr.partition(':')[2] == section)
                for srv in account_pointers(ptr, account=account)]
    return account_pointers(pointer, account=account)


def add_to_services(defs: AddToServiceDefs | AddToServices, *, account: str | None = None) -> AddToServices:
    """
    Return the enabled services of the Add-to dialog definition (`const.dialog.add_to.lists`) for the accounts.

    Pointers of types are expanded to the accounts of the type (only `account` if given), also `<type>:*` and
    `*:<section>`. The `{account}` group is a group per account with the lists not shown above (`{account}` in its
    pointers is the account). A group of one type with more accounts is split into a group per account, mixed groups
    (e.g. "Favorites") get all accounts.
    """
    from .accounts import accounts, get_account
    services: AddToServices = {}
    shown: set[str] = set()

    def enabled(group: Iterable[ServiceDescr]) -> list[ServiceDescr]:
        return list({srv.pointer: srv for srv in group if srv.is_enabled()}.values())

    for label, pointers in defs.items():
        if label == ACCOUNT_GROUP:
            for acc in accounts():
                if account is None or acc.id == account:
                    group = enabled(srv for ptr in pointers for srv in (expand_pointer(ptr.replace(ACCOUNT_GROUP, acc.type.name), account=acc.id)
                                                                       if isinstance(ptr, str) else [ptr]))
                    if group := [srv for srv in group if srv.pointer not in shown]:
                        services[account_group_label(acc)] = group
                        shown.update(srv.pointer for srv in group)
            continue
        expanded = enabled(srv for ptr in pointers for srv in (expand_pointer(ptr, account=account) if isinstance(ptr, str) else [ptr]))
        shown.update(srv.pointer for srv in expanded)
        account_ids = list(dict.fromkeys(srv.pointer.partition(':')[0] for srv in expanded))
        if len(account_ids) > 1 and all(isinstance(srv, AccountServiceDescr) for srv in expanded) \
                and len({acc.type.name for aid in account_ids if (acc := get_account(aid))}) == 1:
            for aid in account_ids:
                acc = get_account(aid)
                group_label = label if acc is None else account_group_label(acc)
                services[group_label] = [srv for srv in expanded if srv.pointer.partition(':')[0] == aid]
        elif expanded:
            services[label] = expanded
    return services


class PickableListEntry(TypedDict):
    #: `service:section:list` token, matching cdefs.ListTarget - what gets stored/parsed back.
    token: str
    #: Display label, e.g. "Trakt: Watchlist" or "FanFilm: My own list".
    label: str
    #: The label of the group of the account, e.g. "Trakt" or "Trakt (a)" (the tree of the picker).
    group: str
    #: The label of the list in its account, e.g. "Watchlist" or "My own list" (the tree of the picker).
    name: str
    #: Service icon path (thumb art already set by ServiceDescr._lists() on each FFItem).
    icon: str


def pickable_lists() -> list[PickableListEntry]:
    """Return an entry for every enabled list (fixed + custom) across all services.

    Meant for a "pick list(s) to sync to library" multiselect dialog. The lists are of the account list services
    (`list_pointers()`) in order of accounts: every list the account reads (a read only one too, Add-to: the lists it may change).
    """
    from .accounts import account_enabled, accounts, SERVICE_TYPES

    # Every entry is labeled uniformly as "{Service}: {List name}" - no exceptions, so a fixed
    # list (favorites/watchlist/collection) and a custom user list never look inconsistent next
    # to each other. Fixed sections use a generic (service-agnostic) translated word instead of
    # each service's own baked-in label (e.g. "Trakt Watchlist"), since those aren't uniform
    # across services/locales (own: "Lista ulubionych" doesn't even mention the addon).
    service_labels: dict[str, str] = {name: typ.label for name, typ in SERVICE_TYPES.items()}
    pointers: list[ListPointer] = [ptr for ptr, srv in list_pointers().items() if isinstance(srv, AccountServiceDescr)]
    entries: list[PickableListEntry] = []
    for acc in accounts():
        found: list[PickableListEntry] = []
        if account_enabled(acc, 'lists', 'read'):  # every list the account reads
            for ptr in pointers:
                for srv in account_pointers(ptr, account=acc.id):
                    found.extend(_pickable_entries(srv, service_labels))
        if (ratings := _ratings_entry(acc)) is not None:  # after the fixed lists, before the user lists
            at = next((i for i, entry in enumerate(found) if entry['token'].partition(':')[2].startswith('user:')), len(found))
            found.insert(at, ratings)
        entries.extend(found)
    return entries


def _ratings_entry(acc: Account) -> PickableListEntry | None:
    """Return the pickable entry of the ratings of the account (its client rates, it reads them), None if none."""
    from .accounts import account_enabled
    if not account_enabled(acc, 'ratings', 'read'):  # the type rates, the account reads its ratings
        return None
    group = account_group_label(acc)
    label = section_label('ratings')
    icon = theme.art(f'services/{acc.type.name}/main.png')  # the icon of the service, as the other lists of the tree
    return {'token': f'{acc.id}:ratings:', 'label': f'{group}: {label}', 'group': group, 'name': label, 'icon': icon}


def _pickable_entries(srv: ServiceDescr, service_labels: dict[str, str]) -> Iterator[PickableListEntry]:
    """Return the pickable entries of the lists of the service (an account among more accounts of its type: its group label as in Add-to)."""
    from .accounts import get_account
    for it in srv.lists():
        target = ListTarget.from_ffitem(it)
        acc = get_account(target.service)
        type_name = acc.type.name if acc is not None else target.service
        token: str = f'{target.service}:{target.section}:{target.list}'
        service_label: str = account_group_label(acc) if acc is not None else service_labels.get(type_name, target.service)
        list_label: str = it.getLabel() if target.section == 'user' else section_label(target.section)
        yield {
            'token': token,
            'label': f'{service_label}: {list_label}',
            'group': service_label,
            'name': list_label,
            'icon': it.getArt('thumb'),
        }


#: Before pickable_lists() existed, each service had its own fixed auto-sync target with its own
#: on/off + schedule setting (autoXOnStart/schedXTime). Those settings were dropped from
#: settings.xml, but Kodi keeps their values in the user's profile regardless. Maps each pair to
#: the equivalent pointer in the new system, so an upgrading user's active legacy syncs aren't
#: silently dropped just because they never opened the new picker.
_LEGACY_AUTO_SYNC: tuple[tuple[str, str, str, ListPointer], ...] = (
    ('autoTraktOnStart', 'schedTraktTime', 'trakt', 'trakt:collection'),
    ('autoTmdbOnStart', 'schedTmdbTime', 'tmdb', 'tmdb:favorites'),
    ('autoIMdbOnStart', 'schedIMdbTime', 'imdb', 'imdb:watchlist'),
    ('autoMdbListOnStart', 'schedMdbListTime', 'mdblist', 'mdblist:watchlist'),
    ('autoOwnOnStart', 'schedOwnTime', 'own', 'own:favorites'),
)


def _legacy_auto_sync_active(on_start_raw: str, sched_raw: str) -> bool:
    """Return True if an old automatic synchronization was on (at the start or by its schedule), by its old settings."""
    return on_start_raw.lower() == 'true' or (sched_raw.isdigit() and int(sched_raw) > 0)


def legacy_auto_sync_pending() -> bool:
    """
    Return True while an old automatic synchronization which was on (`_LEGACY_AUTO_SYNC`) waits for its move to the picked lists
    (never picked yet: `selected_list_tokens()` moves it at its first read, it asks the services for their lists): its old
    settings are still read, they must stay in the user settings.
    """
    from .settings import settings
    if _stored_list_tokens() is not None:
        return False
    values = settings.user_values()
    return any(_legacy_auto_sync_active(values.get(on_start_setting, ''), values.get(sched_setting, ''))
               for on_start_setting, sched_setting, _service, _pointer in _LEGACY_AUTO_SYNC)


def _migrate_legacy_auto_sync_selection() -> set[str]:
    """Build an initial selection from whichever legacy per-service auto-syncs were both active
    and are still authorized today - see _LEGACY_AUTO_SYNC. Only called when nothing has been
    picked yet, so a user who deliberately never enabled any of them just gets an empty result.
    """
    from .settings import settings
    from .accounts import account_enabled
    entries = pickable_lists()
    tokens: set[str] = set()
    for on_start_setting, sched_setting, service, pointer in _LEGACY_AUTO_SYNC:
        # these settings no longer exist in settings.xml - reading them through the typed
        # getBool()/getInt() raises ("Invalid setting type") since there's no schema entry left.
        # get_string() goes through the old, unvalidated Addon().getSetting() instead, which
        # just returns '' for an id it doesn't know (a brand new user never had these at all).
        on_start_raw: str = settings.get_string(on_start_setting, k19log=False)
        sched_raw: str = settings.get_string(sched_setting, k19log=False)
        was_active: bool = _legacy_auto_sync_active(on_start_raw, sched_raw)
        if not was_active or not account_enabled(service, 'lists', 'read'):
            continue
        prefix: str = f'{pin_token(pointer)}:'
        for entry in entries:
            if entry['token'].startswith(prefix):
                tokens.add(entry['token'])
                break
    return tokens


@frozen(kw_only=True)
class ListChoice:
    """
    A choice of lists of the accounts kept in a setting: its picked list tokens (`<account>:<section>:<list>`, see `pickable_lists()`).
    The tree of the lists only returns a choice (`pick_lists()`), the setting keeps it (`choose_lists()`).
    """

    #: The card of the setting (the page of the card shows its row, `SettingsPage.list_choices()`).
    card: type[Card]
    #: The key of the setting in the card.
    key: str
    #: The heading of the tree of the lists.
    heading: LazyLabel
    #: What an empty choice means (the text of the row of the setting): the library - none, the sync of an opened list - all.
    empty: LazyLabel
    #: The choice of the first read (never chosen yet) kept in the setting, None: an empty one, nothing written by a read (the library:
    #: its old automatic syncs; its tokens are bound to their accounts in the setting too).
    first: Callable[[], set[str]] | None = None

    def config_card(self) -> Card:
        """Return the card of the setting with its values in the configuration (the setting read and written by it)."""
        from .config import config
        return config.cards()[self.card.ROOT]


#: The lists of the library (their media are added to the library).
LIBRARY_LISTS: ListChoice = ListChoice(card=Library, key=Library.lists.key, heading=LL(30646, 'Select lists to sync to library'),
                                       empty=LL(32667, 'none'), first=lambda: _migrate_legacy_auto_sync_selection())  # read at call time
#: The lists synchronized when they are opened (in a folder, by a widget).
OPEN_SYNC_LISTS: ListChoice = ListChoice(card=AccountSettings, key=AccountSettings.sync_on_open_lists.key,
                                         heading=LL(31548, 'Select lists synchronized when opened'), empty=LL(31150, 'all'))
#: The choices of lists in the settings (their tokens follow a removed account, a renamed list).
LIST_CHOICES: tuple[ListChoice, ...] = (LIBRARY_LISTS, OPEN_SYNC_LISTS)


def selected_list_tokens(choice: ListChoice = LIBRARY_LISTS) -> set[str]:
    """
    Return the picked list tokens of the choice (see pickable_lists()), bound to their accounts. Never picked (none stored): its first
    choice once (the library: the legacy per-service auto-syncs, `_LEGACY_AUTO_SYNC`) - an empty selection stored means what the choice
    says (the library: "sync nothing"), not "never touched yet".
    """
    stored = _stored_list_tokens(choice)
    saved = set(stored or ())
    tokens = {pin_token(tok) for tok in saved}
    if choice.first is None:  # read only (e.g. a folder opened): the tokens bound in memory
        return tokens
    if stored is None:
        tokens = choice.first()
    if stored is None or tokens != saved:
        save_selected_list_tokens(tokens, choice)
    return tokens


def _stored_list_tokens(choice: ListChoice = LIBRARY_LISTS) -> list[str] | None:
    """Return the stored picked list tokens of the choice as they are (not bound to accounts), None if never picked."""
    tokens = choice.config_card().get(choice.key)
    return None if tokens is None else [tok for tok in tokens if isinstance(tok, str) and tok]


def remove_account_tokens(account_id: str) -> None:
    """Remove the picked list tokens of the account from every choice (the account is removed)."""
    for choice in LIST_CHOICES:
        tokens = _stored_list_tokens(choice) or []
        if (kept := [tok for tok in tokens if tok.partition(':')[0] != account_id]) != tokens:
            save_selected_list_tokens(kept, choice)


def _list_image_store(account_id: str) -> KeyValueStore:
    """Return the store of the list images: the state of the account (the alias of the type is its account)."""
    from .accounts import get_account
    from .db.accounts import account_data_store
    return account_data_store(acc.id if (acc := get_account(account_id)) is not None else account_id)


def list_image(account_id: str, list_id: str) -> ArtValues:
    """Return the images of the own list of the account set by the user (art keys: paths or links), empty for none."""
    return _list_image_store(account_id).get(f'list_image:{list_id}', {})


def set_list_image(account_id: str, list_id: str, art: ArtValues) -> None:
    """Set the images of the own list of the account (art keys, empty: the default ones)."""
    store = _list_image_store(account_id)
    if art:
        store.set(f'list_image:{list_id}', art, ttl=None)
    else:
        store.delete(f'list_image:{list_id}')


def show_list_image(item: FFItem, account_id: str, list_id: str) -> None:
    """Show the images of the own list set by the user (if any) on its item."""
    if art := list_image(account_id, list_id):
        item.setArt({**item.getArt(), **art})


def rename_list_token(old: str, new: str) -> None:
    """Change the picked list token `old` to `new` in every choice (a renamed list whose ID changed: a list of FanFilm, its name)."""
    for choice in LIST_CHOICES:
        tokens = _stored_list_tokens(choice) or []
        if (renamed := [new if pin_token(tok) == pin_token(old) else tok for tok in tokens]) != tokens:
            save_selected_list_tokens(renamed, choice)


def pin_token(token: str) -> str:
    """
    Return the picked list token bound to its account: a type name (the alias of the first account of the type, the tokens
    of older versions) is replaced by the ID of that account, so the order of accounts does not change the synced list.
    """
    from .accounts import SERVICE_TYPES, get_account
    service, sep, rest = token.partition(':')
    if service in SERVICE_TYPES and (acc := get_account(service)) is not None:
        return f'{acc.id}{sep}{rest}'
    return token


def save_selected_list_tokens(tokens: Iterable[str], choice: ListChoice = LIBRARY_LISTS) -> None:
    """Save the picked list tokens (see pickable_lists()) of the choice (in their order, sorted for a set)."""
    choice.config_card().set(choice.key, sorted(tokens) if isinstance(tokens, (set, frozenset)) else list(tokens))


def chosen_list(choice: ListChoice, pointer: str) -> bool:
    """Return True if the list of the pointer (`<account>:<section>[:<list>]`, an alias of a type too) is in the choice, an empty one: any."""
    if not (tokens := selected_list_tokens(choice)):
        return True
    return token_key(pin_token(pointer)) in {token_key(tok) for tok in tokens}


def token_key(token: str) -> str:
    """Return the key of a picked list token: a fixed section by the section only (older tokens have other list IDs there)."""
    service, _, rest = token.partition(':')
    section = rest.partition(':')[0]
    return token if section == 'user' else f'{service}:{section}'


def pickable_lists_with_preselect(tokens: Iterable[str]) -> tuple[list[PickableListEntry], list[int]]:
    """Return (entries, preselect) - pickable_lists() plus the indexes of the picked `tokens`.

    Meant to directly feed a multiselect dialog's `options`/`preselect` arguments.
    """
    entries = pickable_lists()
    current = {token_key(tok) for tok in tokens}
    preselect = [i for i, entry in enumerate(entries) if token_key(entry['token']) in current]
    return entries, preselect


def pickable_lists_tree(entries: Sequence[PickableListEntry]) -> tuple[list[FFItem], list[FFItem]]:
    """
    Return the tree of the picker (the roots) and its leaves in the order of `entries`: an account, its fixed lists
    (watchlist, favorites, ...) and the node of its user lists with them.
    """
    from .item import FMode

    def node(label: str, icon: str) -> FFItem:
        item = FFItem(label, mode=FMode.Folder)
        item.setArt({'icon': icon, 'thumb': icon})
        item.children_items = []
        return item

    roots: dict[str, FFItem] = {}
    user_nodes: dict[str, FFItem] = {}
    leaves: list[FFItem] = []
    for entry in entries:
        service, _, rest = entry['token'].partition(':')
        if (parent := roots.get(service)) is None:
            parent = roots[service] = node(entry['group'], entry['icon'])
        if rest.partition(':')[0] == 'user':
            if (user := user_nodes.get(service)) is None:
                user = user_nodes[service] = node(L(32941, 'User lists'), entry['icon'])
                cast('list[FFItem]', parent.children_items).append(user)
            parent = user
        leaf = FFItem(entry['name'])
        leaf.setArt({'icon': entry['icon'], 'thumb': entry['icon']})
        cast('list[FFItem]', parent.children_items).append(leaf)
        leaves.append(leaf)
    return list(roots.values()), leaves


def pick_lists_heading(title: str, *, selected: int, total: int) -> str:
    """Build the "pick lists" dialog/info heading, e.g. "... - selected 3 of 17"."""
    if not total:
        return title
    return L(30650, '{title} - selected {selected} of {total}').format(title=title, selected=selected, total=total)


def list_target_items(target: ListTarget) -> Iterable[FFRef] | None:
    """Return an iterable of items for one picked list (any service), or None if unsupported.

    Used both by the actual library sync (lib.service.main sync_lists_lib) and by a "preview"
    (count only, no writing) - a plain read, no library/service dependency either way.
    """
    if target.section == 'ratings':  # the rated movies and shows of the account (not a list service: the ratings window rates)
        from .accounts import account_client, get_account
        if (acc := get_account(target.service)) is None or (client := account_client(acc)) is None or getattr(client, 'RATING', None) is None:
            return None
        return [ref for ref in client.ratings() if ref.real_type in ('movie', 'show')]
    if (srv := list_pointer(target.pointer())) is not None and (items := srv.items(target)) is not None:
        return items
    fflog(f'[LIB] Unsupported list target {target!r}, skipping.')
    return None


def pick_lists(heading: str, tokens: Iterable[str]) -> list[str] | None:
    """
    Show the tree of the lists of the accounts (`tokens` picked) and return the picked list tokens, None if canceled - nothing is saved,
    the caller keeps them (`choose_lists()`; `lib.ff.ui`: Kodi, the web page). Deliberately live/exact: the lists of an account that can
    not read them now are not shown, so their tokens are not returned.
    """
    from .control import busy_section
    from .ui import ui
    from ..windows.tree import tree_select

    with busy_section():
        entries, preselect = pickable_lists_with_preselect(tokens)
    if not entries:
        ui.notify(heading, L(33017, 'No account has lists to choose.'))
        return None
    # a tree: account / its lists / its user lists (the window tells the number of the selected ones)
    roots, leaves = pickable_lists_tree(entries)
    chosen = tree_select(pick_lists_heading(heading, selected=0, total=0), roots, multi=True, preselect=[leaves[i] for i in preselect],
                         left_to_parent=True)
    if chosen is None:
        return None
    index = {id(leaf): i for i, leaf in enumerate(leaves)}
    return [entries[index[id(leaf)]]['token'] for leaf in chosen]


def choose_lists(choice: ListChoice) -> bool:
    """Choose the lists of the choice in the tree of the lists and keep them in its setting; return True if chosen (not canceled)."""
    if (tokens := pick_lists(str(choice.heading), selected_list_tokens(choice))) is None:
        return False
    save_selected_list_tokens(tokens, choice)
    return True


def run_preview_lists_dialog() -> None:
    """Show item counts for the currently picked lists - a dry-run, nothing gets written (`lib.ff.ui`: Kodi, the web page)."""
    from cdefs import ListTarget
    from .accounts import account_enabled
    from .ui import ui

    heading = L(30648, 'Preview selected lists')
    tokens = selected_list_tokens()
    if not tokens:
        ui.notify(heading, L(33018, 'No lists are selected.'))
        return
    labels: dict[str, str] = {token_key(entry['token']): entry['label'] for entry in pickable_lists()}
    lines: list[str] = []
    for tok in sorted(tokens):
        service, _, rest = tok.partition(':')
        section, _, list_id = rest.partition(':')
        label = labels.get(token_key(tok), tok)
        if not account_enabled(service, list_capability(section), 'read'):
            lines.append(f'{label}: {L(30723, "not authorized")}')
            continue
        target = ListTarget(service=service, section=section, list=list_id)  # type: ignore[arg-type]
        try:
            items = list_target_items(target)
        except Exception:
            fflog_exc()
            lines.append(f'{label}: {L(30593, "error")}')
            continue
        if items is None:
            lines.append(f'{label}: {L(30594, "unsupported")}')
            continue
        movies = shows = other = 0
        for it in items:
            if it.type == 'movie':
                movies += 1
            elif it.type == 'show':
                shows += 1
            else:
                other += 1
        parts = [f'{word}: {n}' for n, word in (
            (movies, L(32543, 'Movies')), (shows, L(32544, 'TV Shows')), (other, L(30651, 'other')),
        ) if n]
        lines.append(f'{label}: {", ".join(parts) if parts else 0}')
    ui.show_text(heading, '\n'.join(lines))
