"""
The source facts (`lib.sdk.facts`) for the user: the labels of the fact values (one table, a change is one line) and
the text of the facts in the row of a source.
"""

from __future__ import annotations
from typing import Iterable, Sequence, TYPE_CHECKING
from ...sdk.facts import (Term, VideoCodec, Hdr, AudioCodec, TrackKind, AudioRecording, SubtitleKind, ReleaseSource, Edition, Container)
from ...kolang import L
from const import const
if TYPE_CHECKING:
    from ...sdk.facts import Facts, AudioTrack


#: The labels of the fact values (the languages are shown by their codes).
FACT_LABELS: dict[Term, str] = {
    VideoCodec.H264: 'H264',
    VideoCodec.HEVC: 'HEVC',
    VideoCodec.AV1: 'AV1',
    VideoCodec.VP9: 'VP9',
    VideoCodec.MPEG4: 'XviD',
    VideoCodec.MPEG2: 'MPEG-2',
    VideoCodec.VC1: 'VC-1',
    Hdr.HDR: 'HDR',
    Hdr.HDR10: 'HDR10',
    Hdr.HDR10_PLUS: 'HDR10+',
    Hdr.DOLBY_VISION: 'DV',
    Hdr.HLG: 'HLG',
    AudioCodec.AAC: 'AAC',
    AudioCodec.AC3: 'AC3',
    AudioCodec.EAC3: 'DD+',
    AudioCodec.TRUEHD: 'TrueHD',
    AudioCodec.DTS: 'DTS',
    AudioCodec.DTS_ES: 'DTS-ES',
    AudioCodec.DTS_HD: 'DTS-HD',
    AudioCodec.DTS_HD_MA: 'DTS-HD MA',
    AudioCodec.DTS_X: 'DTS:X',
    AudioCodec.FLAC: 'FLAC',
    AudioCodec.LPCM: 'LPCM',
    AudioCodec.MP3: 'MP3',
    AudioCodec.OPUS: 'Opus',
    TrackKind.ORIGINAL: L(30544, 'original'),
    TrackKind.DUBBING: L(30545, 'dubbing'),
    TrackKind.LEKTOR: L(30592, 'voice-over'),
    TrackKind.AUDIO_DESCRIPTION: L(30630, 'audio description'),
    AudioRecording.MIC: 'MD',
    AudioRecording.LINE: 'LD',
    SubtitleKind.FULL: L(30183, 'subtitles'),
    SubtitleKind.FORCED: L(30635, 'forced subtitles'),
    SubtitleKind.SDH: L(30636, 'SDH subtitles'),
    ReleaseSource.CAM: 'CAM',
    ReleaseSource.TELESYNC: 'TS',
    ReleaseSource.TELECINE: 'TC',
    ReleaseSource.SCREENER: 'SCR',
    ReleaseSource.PPV: 'PPV',
    ReleaseSource.TV: 'TV',
    ReleaseSource.VHS: 'VHS',
    ReleaseSource.DVD: 'DVD',
    ReleaseSource.DVDRIP: 'DVDRip',
    ReleaseSource.HDRIP: 'HDRip',
    ReleaseSource.WEB: 'WEB',
    ReleaseSource.WEBDL: 'WEB-DL',
    ReleaseSource.WEBRIP: 'WEBRip',
    ReleaseSource.BDRIP: 'BDRip',
    ReleaseSource.BLURAY: 'BluRay',
    Edition.EXTENDED: 'Extended',
    Edition.DIRECTORS_CUT: "Director's Cut",
    Edition.THEATRICAL: 'Theatrical',
    Edition.UNCUT: 'Uncut',
    Edition.UNRATED: 'Unrated',
    Edition.REMASTERED: 'Remastered',
    Edition.RESTORED: L(30637, 'Digital restoration'),
    Edition.IMAX: 'IMAX',
    Edition.CRITERION: 'Criterion',
    Container.MKV: 'MKV',
    Container.MP4: 'MP4',
    Container.AVI: 'AVI',
    Container.TS: 'TS',
    Container.MPG: 'MPG',
    Container.WMV: 'WMV',
    Container.MOV: 'MOV',
    Container.WEBM: 'WebM',
    Container.FLV: 'FLV',
}

#: Containers shown in the row of a source: they often do not play well while streamed.
ROW_CONTAINERS: frozenset[Container] = frozenset({Container.AVI, Container.TS, Container.MPG, Container.WMV, Container.FLV})


def label(value: Term) -> str:
    """Return the label of a fact value."""
    return FACT_LABELS.get(value, str(value))


def is_multi(facts: Facts) -> bool:
    """Check if the audio has a track of unknown languages (MULTI, dual audio)."""
    return any('lang' in track and track['lang'] is None for track in facts.get('audio', ()))


def language_order(langs: Sequence[str]) -> list[str]:
    """Return the order of the languages: the preferred one (the first of the languages of the user, `user_languages()`), then `const.sources.language_order`."""
    return list(dict.fromkeys((*langs[:1], *const.sources.language_order)))


def sorted_languages(codes: Iterable[str], langs: Sequence[str]) -> list[str]:
    """Return the language codes (once each) in the order of the languages (`language_order()`), the other ones alphabetically after them."""
    place = {lang: i for i, lang in enumerate(language_order(langs))}
    return sorted(dict.fromkeys(codes), key=lambda code: (place.get(code, len(place)), code))


def audio_language(tracks: Iterable[AudioTrack], langs: Sequence[str]) -> str:
    """
    Return the language of a source from its audio tracks: the preferred language (the first one of `langs`, the languages of the user) if
    a track has it, `multi` if a track has unknown languages, else the first one in the order of the languages, '' if no language is known
    (subtitles do not give it).
    """
    codes = [track['lang'] for track in tracks if 'lang' in track]
    if langs and langs[0] in codes:
        return langs[0]
    if None in codes:
        return 'multi'
    return next(iter(sorted_languages((code for code in codes if code), langs)), '')


#: The words of the track kinds in the language type of a source (`info` of the providers), the first found kind wins.
KIND_WORDS: dict[TrackKind, str] = {
    TrackKind.DUBBING: 'Dubbing',
    TrackKind.LEKTOR: 'Lektor',
}


def language_type(facts: Facts, tracks: Iterable[AudioTrack] | None = None) -> str:
    """
    Return the language type of a source in the words of the providers (`Lektor`, `Dubbing Kino`, `Lektor AI`, `Napisy`,
    `Multi`): the track kind (a cinema dubbing, AI), the subtitles, more audio languages. `tracks`: the audio tracks
    instead of the ones of the facts.
    """
    audio = list(facts.get('audio', ()) if tracks is None else tracks)
    parts: list[str] = []
    if track := next((track for kind in KIND_WORDS for track in audio if track.get('kind') == kind), None):
        cinema = track.get('kind') == TrackKind.DUBBING and (facts.get('release', {}).get('source') == ReleaseSource.CAM
                                                            or any('recording' in other for other in audio))
        parts.append(' '.join(word for word in (KIND_WORDS[track['kind']], 'Kino' if cinema else '', 'AI' if track.get('ai') else '') if word))
    if subtitles := facts.get('subtitles'):
        parts.append('Napisy AI' if any(sub.get('ai') for sub in subtitles) else 'Napisy')
    langs = [track['lang'] for track in audio if 'lang' in track]
    if None in langs or len(set(langs)) > 1:
        parts.append('Multi')
    return ' '.join(parts)


def short_list(labels: Sequence[str], most: int | None = None) -> str:
    """Return the labels joined, more than `most` (None: all of them): the first ones and "+N" (never "+1": the last one instead)."""
    if most is None or len(labels) <= most + 1:
        return ', '.join(labels)
    return f'{", ".join(labels[:most])} +{len(labels) - most}'


def language_texts(facts: Facts, langs: Sequence[str], most: int | None = None) -> tuple[str, ...]:
    """
    Return the texts of the languages of a source in the words of the providers, in the order of the languages (`sorted_languages()`),
    at most `most` of each (None: all of them, `short_list()`): the audio of more languages (`Multi`, also of unknown ones; none known:
    the language of the source says MULTI), the subtitles of known languages (`Napisy`).
    """
    codes = [track['lang'] for track in facts.get('audio', ()) if 'lang' in track]
    audio = sorted_languages((code for code in codes if code), langs)
    subtitles = sorted_languages((sub['lang'] for sub in facts.get('subtitles', ()) if sub.get('lang')), langs)
    texts: list[str] = []
    if audio and (None in codes or len(audio) > 1):
        texts.append(f'Multi: {short_list([code.upper() for code in audio], most)}')
    if subtitles:
        texts.append(f'Napisy: {short_list([code.upper() for code in subtitles], most)}')
    return tuple(texts)


def facts_text(facts: Facts, langs: Sequence[str]) -> str:
    """
    Return the text of the facts in the row of a source: the source, the video, the audio tracks, the languages of the audio and the
    subtitles (`language_texts()`, `const.sources_dialog.languages_shown` of each), `Softsub` (no subtitles burned into the picture),
    3D, the editions, the container. Not the facts the
    providers give in their info (shown as it is): sign language, colorized, DRM.
    """
    video = facts.get('video', {})
    release = facts.get('release', {})
    source = ' '.join(text for text in (label(release['source']) if 'source' in release else '', 'REMUX' if release.get('remux') else '') if text)
    hdr = ' '.join(label(value) for value in video.get('hdr', ()))
    fps = f'{video["fps"]} fps' if 'fps' in video else ''
    audio = ' · '.join(text for track in facts.get('audio', ())
                       if (text := ' '.join(part for part in (label(track['codec']) if 'codec' in track else '', track.get('channels', ''),
                                                               'Atmos' if track.get('atmos') else '',
                                                               label(track['recording']) if 'recording' in track else '') if part)))
    container = release.get('container')
    # subtitles all in their own tracks (not burned into the picture, a provider tells it): they can be turned off
    subtitles = facts.get('subtitles', ())
    softsub = 'Softsub' if subtitles and all(sub.get('burned') is False for sub in subtitles) else ''
    parts = (source, label(video['codec']) if 'codec' in video else '', hdr, fps, audio,
             *language_texts(facts, langs, const.sources_dialog.languages_shown), softsub, '3D' if video.get('three_d') else '',
             *(label(value) for value in release.get('edition', ())), label(container) if container in ROW_CONTAINERS else '')
    return ' | '.join(part for part in parts if part)
