"""
The settings of FanFilm declared once: every card of settings of the configuration window (`Card`: a class with its settings as typed fields
in their groups, in the order of its page) and every branch of the configuration (`ROOTS`). The values are read by the configuration
(`config.media.language`, `config.media.get(key)`, `config('/media/language')`), the pages of the window are made of the cards
(`lib.windows.widgets.settings_page`), the old settings of `settings.xml` (`legacy`, `legacy_value`) are moved by the migrations.

Only declarations here: what builds the options, the scales and the texts of other data is in `lib.ff.config.choices` (a function, called
when used), what reads the old settings in `lib.ff.config.migrations`. The texts are lazy labels (`LL()`): translated when a page shows
them, in the Kodi language of then - nothing of Kodi is called by the import of the declaration.
"""

from __future__ import annotations
from cdefs import When
from .blocks import Card, ConfigRoot, LegacyValue, ProviderSetting, SettingGroup, SettingOption, setting
from .choices import (actor_scale, area_settings, first_role, image_source_options, language_options, local_title_label, months_scale,
                      movie_sort_default, movie_sort_options, premiere_delay_scale, progress_bar_help, quality_options, role_options,
                      search_time_scale, season_folder_options, season_label_options, service_menus_help, show_sort_default, show_sort_options, shown_scale,
                      sync_hours_scale, sync_start_scale, visible_scale, votes_scale, years_scale)
from .migrations import LegacySort, LegacySwitched, legacy_language, legacy_lists, legacy_season_folder, legacy_sync_hours, legacy_sync_start
from ...kolang import LL

#: The add-on of Up Next.
UPNEXT_ADDON: str = 'service.upnext'
#: The add-on which sends the Kodi log.
LOG_UPLOADER: str = 'script.kodi.loguploader'
#: The old folders of the library (`settings.xml`): the defaults.
DEFAULT_MOVIES_FOLDER: str = 'special://userdata/addon_data/plugin.video.fanfilm/Movies'
DEFAULT_SHOWS_FOLDER: str = 'special://userdata/addon_data/plugin.video.fanfilm/TVShows'
#: The forward of the cookies received to the other FanFilm (its list of them, `lib.windows.widgets.web`): the card of the web server and the
#: group of the Cloudflare server show the same row.
FORWARD_COOKIES: ProviderSetting = setting(key='forward', kind='action', label=LL(33035, 'Forward cookies'),
                                           help=LL(31359, 'Other FanFilm of the home (paired with them) get the cookies of the providers this one '
                                                          'receives: of the browser script, of the Cloudflare server.'))
#: The page of the search of the sources: of the groups of the card of the settings of the sources (`SettingGroup.page`, `SettingsPage.PAGE`,
#: the name of its page of the configuration window).
SOURCE_SEARCH_PAGE: str = 'source_search'
#: The settings of ResolveURL (the dependent add-ons, the page of the sources: one declaration).
RESOLVEURL: ProviderSetting = setting(key='resolveurl', kind='action', label=LL(32540, 'ResolveURL settings'),
                                      action='Addon.OpenSettings(script.module.resolveurl)', legacy='sources.resolver_settings')


class General(Card, root='/general'):
    """
    The general settings: the start of Kodi, the playback of the m3u8 links, the widgets, the ratings of the accounts in the lists, the ratings
    after watching, the entries of the context menu, Up Next (its rows need its add-on enabled, the ones after its switch work only with it on).
    """

    #: The add-on the rows of Up Next need.
    _addon = (UPNEXT_ADDON,)
    #: The old setting of the rating of an episode: the ratings of a season and of a show start with its value.
    _old_rate = 'rate_after_watch.show'
    #: The rows working only with Up Next on.
    _on = {'upnext': (True,)}

    _general = SettingGroup(label=LL(32310, 'General'))
    autostart: bool = setting(kind='bool', label=LL(30268, 'Run FanFilm on Kodi startup'), default=False, legacy='ff.autostart',
                              help=LL(31289, 'The main menu of FanFilm opens at the start of Kodi.'))
    isa: bool = setting(kind='bool', label=LL(30326, 'Use InputStream Adaptive to play m3u8 links'), default=False, legacy='isa.enabled',
                        help=LL(31290, 'The m3u8 sources (streams) play by InputStream Adaptive, else by Kodi itself.'))
    widgets_nextpage: bool = setting(kind='bool', label=LL(30535, 'Show next page item in widgets'), default=False, legacy='widgets_nextpage',
                                     help=LL(31291, 'The lists of FanFilm in the widgets of the skin end with "Next page" too.'))
    user_ratings: bool = setting(kind='bool', label=LL(30556, 'Get user ratings'), default=False, legacy='get_user_ratings',
                                 help=LL(31292, 'The lists show the ratings of the accounts (read with every list: slower).'))

    _after_watching = SettingGroup(label=LL(30336, 'After watching'))
    rate_movie: bool = setting(kind='bool', label=LL(30338, 'Rate movie'), default=False, legacy='rate_after_watch.movie',
                               help=LL(31293, 'The rating window opens after a movie is watched.'))
    rate_episode: bool = setting(kind='bool', label=LL(30339, 'Rate episode'), default=False, legacy=_old_rate,
                                 help=LL(31294, 'The rating window opens after an episode is watched.'))
    rate_season: bool = setting(kind='bool', label=LL(31295, 'Rate season'), default=False, legacy=_old_rate,
                                help=LL(31296, ('The rating window of the season opens after its last episode is watched: the season finished '
                                                '(no more episodes of it to come) and watched whole.')))
    rate_show: bool = setting(kind='bool', label=LL(31297, 'Rate show'), default=False, legacy=_old_rate,
                              help=LL(31298, 'The rating window of the show opens after its last episode is watched: the show ended and watched whole.'))

    _context_menu = SettingGroup(label=LL(30176, 'Context menu'), column=1)
    details: bool = setting(kind='bool', label=LL(30228, 'Details'), default=True, legacy='cm.details',
                            help=LL(31299, 'The context menu of the movies and the shows has "Details".'))
    custom_search: bool = setting(kind='bool', label=LL(30233, 'Custom search'), default=True, legacy='cm.custom_search',
                                  help=LL(31300, 'The context menu has "Edit search": the sources searched by another query.'))
    movie_collection: bool = setting(kind='bool', label=LL(30130, 'Movie Collection'), default=False, legacy='cm.movie_collection',
                                     help=LL(31301, 'The context menu of a movie of a collection has "Movie Collection".'))
    similar: bool = setting(kind='bool', label=LL(30132, 'Similar'), default=False, legacy='cm.similar',
                            help=LL(31302, 'The context menu of the movies and the shows has "Similar".'))
    rate: bool = setting(kind='bool', label=LL(30335, 'Set rating'), default=True, legacy='cm.rate',
                         help=LL(31303, 'The context menu has "Rate" (with an account rating the media).'))
    folder_filter: bool = setting(kind='bool', label=LL(31342, 'List filter'), default=False,
                                  help=LL(31344, ('The context menu of the lists (watchlists, the lists of the accounts, popular…) has "Filter...": '
                                                  'the same list with the media not watched yet, in progress, to watch or watched only.')))
    account_sync: bool = setting(kind='bool', label=LL(31540, 'Synchronize account'), default=True,
                                 help=LL(31541, 'The context menu of an account (its folder, its lists, its row of the accounts) has "Synchronize account": '
                                         'the account syncs now.'))
    # the gate of the entries of the features of single services (the switches of the accounts `cm.<id>`, off by default)
    service_menus: bool = setting(kind='bool', label=LL(33001, 'Features of single services'), default=False, help=service_menus_help)

    _upnext = SettingGroup(label=LL(30622, 'Up Next'), column=1)
    upnext_install = setting(kind='action', label=LL(30623, 'Install Up Next add-on'), action=f'InstallAddon({UPNEXT_ADDON})',
                             help=LL(31304, 'Up Next: a notification of the next episode at the end of an episode.'))
    upnext: bool = setting(kind='bool', label=LL(30624, 'Enable Up Next integration'), default=False, legacy='upnext.enabled', requires=_addon,
                           help=LL(31305, 'Up Next gets the next episode of a show of FanFilm.'))
    theintrodb: bool = setting(kind='bool', label=LL(30604, 'Intro, recap and credits times from TheIntroDB and AniSkip (anime)'), default=False,
                               legacy='upnext.theintrodb', requires=_addon, when=_on,
                               help=LL(31306, ('Up Next gets the times of the intro, the recap and the credits of an episode (its skip, its notification '
                                               'at the credits).')))
    upnext_settings = setting(kind='action', label=LL(30625, 'Open Up Next add-on settings'), action=f'Addon.OpenSettings({UPNEXT_ADDON})', when=_on,
                              help=LL(31307, 'The settings of the add-on Up Next.'))


class SourceSettings(Card, root='/sources/settings'):
    """
    The settings of the sources: the view, the colours, the row of a source, the keep of the filter and the sort; the search and the Cloudflare
    server on a page of their own (`page`, their values in the same root).
    """

    #: The help of a row of the selection of the user.
    _selection_help = LL(30947, ('The filter and the sort of the sources with no search: the same ones the list of the sources and the automatic '
                                 'play use.'))

    _view = SettingGroup(label=LL(30983, 'View'))
    filters_simple: bool = setting(kind='bool', label=LL(30957, 'Simple view'), default=True,
                                   help=LL(30958, ('Fewer options: the filter and the sort as a short list of switches, only the progress while searching '
                                                   'and one search time, no priority of episodes.')))

    _colors = SettingGroup(label=LL(32649, 'Highlight color'))
    color_mode: str = setting(kind='select', label=LL(30802, 'Provider color'), default='background',
                              options=(SettingOption(value='background', label=LL(30803, 'Row background')),
                                       SettingOption(value='accent', label=LL(30804, 'Bar and name'))),
                              help=LL(30805, ('Where the colour of the provider of a source shows: the background of its row, or a bar at its left and '
                                              'its name.')))
    auto_colors: bool = setting(kind='bool', label=LL(30809, 'Automatic colours'), default=False,
                                help=LL(30810, 'A provider with no colour of its own (no node of the tree, no rule) gets its own colour of the theme.'))
    default_color: str = setting(kind='color', label=LL(32572, 'Default color'), default='FF008EB2', legacy='default.color.identify2',
                                 help=LL(30790, 'The highlight color of a source no node of the tree of the source providers colors.'))
    premium_color: str = setting(kind='color', label=LL(32588, 'Premium color'), default='', legacy='prem.color.identify2',
                                 help=LL(30791, 'The highlight color of a premium source (none: the default one).'))
    accent_background: str = setting(kind='color', label=LL(30806, 'Item background'), default='', when={'color_mode': ('accent',)},
                                     help=LL(30807, ('The background of a row of a source while the colour of its provider is a bar and its name (none: '
                                                     'the row of the theme).')))
    row_contrast: bool = setting(kind='bool', label=LL(30818, 'Readable row texts'), default=True,
                                 help=LL(30819, 'The texts of a row of a light (dark) colour turn dark (light) when its own ones would be hard to read.'))

    _row = SettingGroup(label=LL(30792, 'Row of a source'), column=1)
    extra_info: bool = setting(kind='bool', label=LL(32587, 'Extra source info'), default=True, legacy='sources.extrainfo',
                               help=LL(30796, 'Show the extra information of a source (its language, its format, its sound) in its row.'))
    file_name: bool = setting(kind='bool', label=LL(32670, 'File name'), default=False, legacy='sources.filename_in_2nd_line',
                              help=LL(30797, 'Show the file name of a source in the second line of its row.'))
    service_icons: bool = setting(kind='bool', label=LL(30255, 'Service icons'), default=True, legacy='icon.external',
                                  help=LL(30798, 'Show the icon of the service of a source in the window of the sources.'))
    premium_tag: str = setting(kind='select', label=LL(30820, 'Premium tag'), default='mixed',
                               options=(SettingOption(value='always', label=LL(32831, 'Always')),
                                        SettingOption(value='mixed', label=LL(30821, 'Mixed providers'))),
                               help=LL(30822, ('When a source opened by the account of its provider shows the tag PREMIUM: always, or only for a provider '
                                               'which finds free sources too (the tag tells its premium ones apart).')))
    filtered_visible: int = setting(kind='scale', label=LL(31066, 'Filtered out visible'), default=75, scale=visible_scale,
                                    help=LL(31067, ('How much is seen of a row the filter cuts (with the filter off) or a step dropped (the debug), % '
                                                    '(100: as the others).')))

    _selection = SettingGroup(label=LL(30951, 'Filters and sort'), column=1)
    filters_persistent: bool = setting(kind='bool', label=LL(30959, 'Keep window changes'), default=False,
                                       help=LL(30960, ('Off: the changes made in the window of the sources last only for that window; they are changed '
                                                       'for good here.')))
    separate_shows: bool = setting(kind='bool', label=LL(30961, 'Separate for shows'), default=False,
                                   help=LL(30962, 'The shows have their own filter and sort, the movies theirs.'))
    selection_movie = setting(kind='action', label=LL(30948, 'Movies…'), help=_selection_help)
    selection_show = setting(kind='action', label=LL(30949, 'Shows…'), shown_when={'separate_shows': (True,)}, help=_selection_help)

    _search = SettingGroup(label=LL(32718, 'Source search'), page=SOURCE_SEARCH_PAGE)
    providers_lang: str = setting(kind='select', label=LL(32360, 'Providers Language'), default='pl,en', legacy='providers.lang',
                                  options=(SettingOption(value='pl', label=LL(32845, 'Polish')),
                                           SettingOption(value='en', label=LL(32846, 'English')),
                                           SettingOption(value='pl,en', label=LL(32847, 'Polish+English'))),
                                  help=LL(30985, ('Only the providers of these languages are searched; '
                                                  'the filter and the sort of the sources follow the info language first, then these.')))
    search_timeout: list[float] = setting(kind='range', label=LL(32312, 'Search time'), default=[5, 30], scale=search_time_scale, legacy='scrapers.timeout.1',
                                          help=LL(30793, ('From - to, seconds. Up to the first time the window of the progress, '
                                                          'then the list of the sources found so far (0: at once). '
                                                          'At the second one the search ends: the debrid services check the torrents.')))
    default_action: int = setting(kind='select', label=LL(32331, 'Action after the search'), default=0, legacy='hosts.mode',
                                  help=LL(30799, 'After the search: the window of the sources, or the first source played at once.'),
                                  options=(SettingOption(value=0, label=LL(32332, 'Sources window')), SettingOption(value=2, label=LL(32334, 'Auto Play'))))
    auto_next: bool = setting(kind='bool', label=LL(32668, 'Auto-select the next item'), default=False, legacy='auto.select.next.item.to.play',
                              help=LL(30800, 'Select the next items of the playback list automatically.'))
    source_cache: bool = setting(kind='bool', label=LL(32720, 'Sources cache'), default=True, legacy='enableSourceCache',
                                 help=LL(30801, 'Keep the found sources for a while: the next search of the same title is quicker.'))
    resolveurl = RESOLVEURL

    #: The rows working only with the Cloudflare server on (`lib.ff.cf_solver`).
    _cf_on = {'cf_solver': (True,)}

    _cf_solver = SettingGroup(label=LL(33021, 'Cloudflare server'), column=1, page=SOURCE_SEARCH_PAGE)
    cf_solver: bool = setting(kind='bool', label=LL(33029, 'Use a Cloudflare server'), default=False,
                              help=LL(33030, ('A server solving the Cloudflare challenge (Byparr - recommended, Trawl, FlareBypasser) gives the cookies '
                                              'to the providers with "Use the Cloudflare server" on.')))
    cf_solver_url: str = setting(kind='text', label=LL(33031, 'Server address'), default='http://localhost:8191', when=_cf_on,
                                 help=LL(33032, 'The address of the Cloudflare server (with its port).'))
    cf_solver_timeout: int = setting(kind='int', label=LL(33033, 'Server time limit'), default=180, minimum=30, maximum=600, when=_cf_on,
                                     help=LL(33034, 'How long the server may solve one site, seconds (a weak computer needs more).'))
    cf_solver_refresh = setting(kind='action', label=LL(31325, 'Refresh now'), when=_cf_on,
                                help=LL(31326, 'The cookies of every provider with the server on are refreshed now (one notification at the end).'))
    forward = FORWARD_COOKIES


class Maintenance(Card, root='/maintenance'):
    """
    The settings of the maintenance: the developer logs and their areas (`const.debug.log_areas`: `extra()`), the debug of the window of the
    sources, the version, the cache of the lists, the dependent add-ons. The groups of the developer tools are shown and work only with them.
    """

    #: With the developer logs on (no annotation: not a field of the card).
    _on = {'fflog': (True,)}

    _logs = SettingGroup(label=LL(30359, 'Logs'))
    fflog: bool = setting(kind='bool', label=LL(32833, 'Show developer logs'), default=False, legacy='dev.fflog',
                          help=LL(31017, 'The logs of FanFilm for its developers in the Kodi log (a report of an error needs them).'))
    log_install = setting(kind='action', label=LL(32779, 'Install Kodi Logfile Uploader'), action=f'InstallAddon({LOG_UPLOADER})')
    log_upload = setting(kind='action', label=LL(31018, 'Send the log'), action=f'RunAddon({LOG_UPLOADER})',
                         help=LL(31047, 'Kodi Logfile Uploader sends the Kodi log and shows its link.'))
    diagnostic = setting(kind='state', label=LL(31117, 'Diagnostic code'), shown_when=_on,
                         help=LL(31118, 'A code from the FanFilm team: more logs for a while after the next start of Kodi (OK: enter it, empty: remove it).'))

    _log_details = SettingGroup(label=LL(31048, 'Log details'), developer=True, when=_on)

    _sources_window = SettingGroup(label=LL(32332, 'Sources window'), developer=True)
    debug_tab: bool = setting(kind='bool', label=LL(31052, 'Debug of the sources'), default=False,
                              help=LL(31053, ('The page Debug of the panel of the window of the sources: what is debugged - the chosen providers, the ones '
                                              'with dropped sources - is set there.')))

    _version = SettingGroup(label=LL(31024, 'Version'), column=1)
    version = setting(kind='state', label=LL(32661, 'Addon version'))
    changelog = setting(kind='action', label=LL(30634, 'Changelog'))
    changelog_on_update: bool = setting(kind='bool', label=LL(30629, 'Show changelog after update'), default=True, legacy='changelog.show_on_update')

    _cache = SettingGroup(label=LL(32781, 'Cache settings'), column=1)
    list_cache: bool = setting(kind='bool', label=LL(32783, 'Cache list'), default=True, legacy='listCache',
                               help=LL(31025, 'Keep the lists of the services for a while (off: every list asked again).'))

    _addons = SettingGroup(label=LL(31026, 'Dependent add-ons'), column=1)
    resolveurl = RESOLVEURL
    isa = setting(kind='action', label=LL(30312, 'InputStreamAdaptive Settings'), action='Addon.OpenSettings(inputstream.adaptive)')
    ish = setting(kind='action', label=LL(30313, 'InputStream Helper Settings'), action='Addon.OpenSettings(script.module.inputstreamhelper)')

    @classmethod
    def extra(cls, group: str) -> tuple[ProviderSetting, ...]:
        """Return the settings of the details of the areas of the developer logs of the group (`const.debug.log_areas`): used with the logs on."""
        return area_settings(group, cls._on)


class AccountSettings(Card, root='/account_settings'):
    """
    The settings of the accounts: the notification of their sync, the own API keys of the services, of their applications (empty: the keys
    of FanFilm), the personal key of fanart.tv. The keys are access data by their names (the log, a backup).
    """

    #: The parts of the helps of the keys.
    _empty = LL(31125, 'Empty: the key of FanFilm.')
    _again = LL(31134, 'Changed: the accounts of the service sign in again.')

    _sync = SettingGroup(label=LL(31126, 'Synchronization'))
    sync_notification: bool = setting(kind='bool', label=LL(30333, 'Show sync notification'), default=False, legacy='trakt.sync_notification',
                                      help=LL(31127, ('A notification while the accounts sync: in the background and when you ask for it '
                                                      '(the changes you make are sent without it).')))
    sync_on_open: bool = setting(kind='bool', label=LL(31542, 'Synchronize a list opened in a folder'), default=False,
                                 help=LL(31543, 'A list of an account opened in a folder (a collection, the own lists, an own list, the ratings...) first asks '
                                         'its service for a change of it and shows after it, fetched again if it changed: a request (TMDB, IMDb, '
                                         'JustWatch, Floppy: a few). Off: the lists follow the sync of the accounts in the background.'))
    sync_on_open_widgets: bool = setting(kind='bool', label=LL(31544, 'Synchronize a list read by a widget'), default=False,
                                         help=LL(31545, 'A list of an account read by a widget first asks its service for a change of it, as in a folder: a '
                                                 'request at each read of the widget (the skin reads it again and again).'))
    sync_on_open_lists: list[str] | None = setting(kind='action', label=LL(31546, 'Synchronized lists'), default=None,
                                                   when=({'sync_on_open': (True,)}, {'sync_on_open_widgets': (True,)}),
                                                   help=LL(31547, 'The lists synchronized when they are opened (in a folder, by a widget): none chosen - '
                                                           'all of them, also a new one. The list of the own lists of an account is always synchronized.'))

    _keys = SettingGroup(label=LL(31128, 'Service API keys'), column=1)
    tmdb_api_key: str = setting(kind='text', label=LL(32656, 'TMDB: API key'), default='', legacy='tmdb.api_key',
                                help=LL(31129, 'The API key of your TMDB application. {empty} A key TMDB rejects: the key of FanFilm.', empty=_empty))
    tmdb_bearer: str = setting(kind='text', label=LL(31135, 'TMDB: access token'), default='',
                               help=LL(31136, ('The API read access token of your TMDB application: the requests without your API key and the sign-in of the '
                                               'TMDB accounts. {empty}'), empty=_empty))
    trakt_client_key: str = setting(kind='text', label=LL(30201, 'Trakt: client ID'), default='', legacy='trakt.client_key',
                                    help=LL(31130, 'The client ID of your Trakt application: every request of Trakt. {empty} {again}',
                                            empty=_empty, again=_again))
    trakt_secret_key: str = setting(kind='text', label=LL(30202, 'Trakt: client secret'), default='', legacy='trakt.secret_key',
                                    help=LL(31131, ('The client secret of your Trakt application (with its client ID): the sign-in of the Trakt '
                                                    'accounts. {empty}'), empty=_empty))
    wetrakr_client_key: str = setting(kind='text', label=LL(31137, 'WeTrakr: API key'), default='',
                                      help=LL(31138, 'The client ID of your WeTrakr application: every request of WeTrakr. {empty} {again}',
                                              empty=_empty, again=_again))
    mdblist_client_key: str = setting(kind='text', label=LL(31139, 'MDBList: API key'), default='',
                                      help=LL(31140, ('The client ID of your MDBList OAuth application: the sign-in of the MDBList accounts (not their '
                                                      'API keys). '
                                                      '{empty} {again}'), empty=_empty, again=_again))
    fanart_client_key: str = setting(kind='text', label=LL(31178, 'Fanart.TV: API key'), default='', legacy='fanart.tv.user',
                                     help=LL(31179, ('Your personal API key of fanart.tv: the newest images sooner (about 2 days after they are added, '
                                                     'else 7). Empty: none.')))


class Media(Card, root='/media'):
    """
    The settings of the movies and the TV shows: the language of the information, the cast, the progress bar, the images, the discovery of
    TMDB (its order, the votes, the hidden ones), the seasons of a show. The options come from what they choose (`lib.ff.config.choices`).
    """

    #: The help of a row of the least number of the votes.
    _votes_help = LL(31151, 'The least number of the votes of a title on TMDB (all: every title).')

    _info = SettingGroup(label=LL(31152, 'Information'))
    language: str = setting(kind='select', label=LL(32316, 'Info Language'), default='pl-PL', options=language_options,
                            legacy_value=LegacyValue(ids=('api.language',), value=legacy_language),
                            help=LL(31153, 'The language of the titles, the descriptions and the images (TMDB, Trakt); the sources in it first.'))
    actor_limit: int = setting(kind='scale', label=LL(30121, 'Actors in the information'), default=10, scale=actor_scale, legacy='actor_count_limit',
                               help=LL(31171, 'The most actors shown in the information of a title (all: every one).'))
    studio_limit: int = setting(kind='scale', label=LL(31262, 'Studios in a folder'), default=1, scale=shown_scale,
                                help=LL(31263, 'The most film studios in a folder and in its information, the details show all.'))
    genre_limit: int = setting(kind='scale', label=LL(31264, 'Genres in a folder'), default=3, scale=shown_scale,
                               help=LL(31265, 'The most genres in a folder and in its information, the details show all.'))
    progress_bar: bool = setting(kind='bool', label=LL(30234, 'Show progressbar in movies and tvshows'), default=True, legacy='show.progressbar',
                                 help=progress_bar_help)

    _images = SettingGroup(label=LL(32703, 'Graphics'))
    image_quality: int = setting(kind='select', label=LL(32704, 'Graphics quality'), default=1, options=quality_options, legacy='image.quality',
                                 help=LL(31155, 'The sizes of the images of TMDB (a poster / a landscape): higher ones look better and load longer.'))
    image_order: int = setting(kind='select', label=LL(32708, 'Graphics depends on'), default=0, legacy='image.sort_by',
                               options=(SettingOption(value=0, label=LL(32709, 'rating')), SettingOption(value=1, label=LL(32710, 'number of votes'))),
                               help=LL(31156, 'Which image of TMDB is chosen first: the best rated one or the one with the most votes.'))
    image_source: str = setting(kind='select', label=LL(31175, 'Source of the images'), default='tmdb', options=image_source_options,
                                help=LL(31176, ('Where the images come from, TMDB always when the other has none. fanart.tv adds clear art, disc art, '
                                                'banners and the logos TMDB has not; the first opening of a folder takes longer.')))
    fanart: bool = setting(kind='bool', label=LL(32318, 'Enable Fanart'), default=True, legacy='fanart',
                           help=LL(31177, 'The background image of a movie or a show, else the one of FanFilm.'))

    _votes = SettingGroup(label=LL(31168, 'Minimum votes on TMDB'))
    movie_votes: int = setting(kind='scale', label=LL(32712, 'Movies'), default=100, scale=votes_scale, legacy='tmdbmovie.vote', help=_votes_help)
    show_votes: int = setting(kind='scale', label=LL(32717, 'TV Shows'), default=100, scale=votes_scale, legacy='tmdbtv.vote', help=_votes_help)
    popular_votes: int = setting(kind='scale', label=LL(32818, 'TV Shows - Popular'), default=300, scale=votes_scale, legacy='tmdbtv.votePopular',
                                 help=LL(31169, '{votes} Only the list of the popular TV shows.', votes=_votes_help))

    _movies = SettingGroup(label=LL(32712, 'Movies'), column=1)
    movie_sort: str = setting(kind='select', label=LL(32713, 'Sort by:'), default=movie_sort_default, options=movie_sort_options,
                              legacy_value=LegacyValue(ids=('movies.sort',), value=LegacySort(media='movies')),
                              help=LL(31157, 'The order of the lists of the movies of TMDB (genres, years, countries…).'))
    hide_cinema_months: int = setting(kind='scale', label=LL(31158, 'Hide in cinema, months'), default=0, scale=months_scale,
                                      legacy_value=LegacyValue(ids=('hidecinema', 'hidecinema.rollback'), value=LegacySwitched(6)),
                                      help=LL(31159, 'The movies of TMDB premiered in the last months are left out of the lists (off: none).'))

    _shows = SettingGroup(label=LL(32717, 'TV Shows'), column=1)
    show_sort: str = setting(kind='select', label=LL(32713, 'Sort by:'), default=show_sort_default, options=show_sort_options,
                             legacy_value=LegacyValue(ids=('tvshows.sort',), value=LegacySort(media='tvshows')),
                             help=LL(31160, 'The order of the lists of the TV shows of TMDB (genres, years, countries…).'))
    season_label: int = setting(kind='select', label=LL(30120, 'Display style for season name'), default=1, options=season_label_options,
                                legacy='tvshow.season_label', help=LL(31161, 'The label of a season with its own title (a season without one: its number).'))
    season_folder: str = setting(kind='select', label=LL(31162, 'Seasons as a folder'), default=When.ALWAYS.value, options=season_folder_options,
                                 legacy_value=LegacyValue(ids=('flatten.tvshows',), value=legacy_season_folder),
                                 help=LL(31163, 'The seasons of a show as folders: never (all the episodes in the show), if there are more seasons, always.'))
    unaired: bool = setting(kind='bool', label=LL(32570, 'Show unaired seasons/episodes'), default=True, legacy='showunaired')

    _popular = SettingGroup(label=LL(32818, 'TV Shows - Popular'), column=1)
    popular_no_anime: bool = setting(kind='bool', label=LL(32819, 'Hide anime in popular'), default=False, legacy='withoutAnime')
    popular_first_years: int = setting(kind='scale', label=LL(31164, 'Older than, years'), default=0, scale=years_scale,
                                       legacy_value=LegacyValue(ids=('hideoldshows', 'hideoldshows.rollback'), value=LegacySwitched(15)),
                                       help=LL(31165, 'The shows which premiered more years ago are left out of the popular ones (off: none).'))
    popular_last_years: int = setting(kind='scale', label=LL(31166, 'Ended before, years'), default=0, scale=years_scale,
                                      legacy_value=LegacyValue(ids=('hideoldshows', 'hideoldshowsepi.rollback'), value=LegacySwitched(3)),
                                      help=LL(31167, 'The shows whose last episode aired more years ago are left out of the popular ones (off: none).'))


class Library(Card, root='/library'):
    """
    The settings of the library of Kodi: its folders, the adding of the media, the episodes written, the lists synchronized into it. Every
    setting but the switch of the library works only with it on.
    """

    #: The rows working only with the switch of the card on.
    _on = {'enabled': (True,)}

    _library = SettingGroup(label=LL(32541, 'Library'))
    enabled: bool = setting(kind='bool', label=LL(30123, 'Enable library'), default=False, legacy='enable_library',
                            help=LL(31188, ('The movies and the shows added to the library of Kodi (STRM files in its folders), '
                                            'the lists synchronized into it.')))
    movies_folder: str = setting(kind='folder', label=LL(32543, 'Movies'), default=DEFAULT_MOVIES_FOLDER, legacy='library.movie', when=_on,
                                 help=LL(31189, 'The folder of the movies of the library (a source of Kodi of the movies).'))
    shows_folder: str = setting(kind='folder', label=LL(32544, 'TV Shows'), default=DEFAULT_SHOWS_FOLDER, legacy='library.tv', when=_on,
                                help=LL(31190, 'The folder of the shows of the library (a source of Kodi of the TV shows).'))
    scan_after_add: bool = setting(kind='bool', label=LL(32547, 'Scan Kodi after adding'), default=True, legacy='library.update', when=_on,
                                   help=LL(31191, 'Kodi scans its library after the media are added (they show in it at once).'))
    no_duplicates: bool = setting(kind='bool', label=LL(32548, 'Avoid duplicates'), default=True, legacy='library.check', when=_on,
                                  help=LL(31192, 'The media in the library of Kodi already (of any add-on) are not added again.'))
    notifications: bool = setting(kind='bool', label=LL(32546, 'Notifications'), default=True, legacy='library.service.notification', when=_on,
                                  help=LL(31193, 'A notification at the start and the end of the adding.'))
    add_downloads: bool = setting(kind='bool', label=LL(31280, 'Add downloads'), default=False, when=_on,
                                  help=LL(31281, ('A finished download adds its movie or its show to the library (as the action "Add to library"). '
                                                  'Removing a download does not touch the library.')))

    _episodes = SettingGroup(label=LL(30303, 'Episodes'))
    unknown_air_date: bool = setting(kind='bool', label=LL(32565, 'Of unknown air date'), default=True, legacy='library.include_unknown', when=_on,
                                     help=LL(31194, 'The episodes with no date of the premiere are added too.'))
    premiere_delay: int = setting(kind='scale', label=LL(32566, 'Days after the premiere'), default=0, legacy='library.days_delay', scale=premiere_delay_scale,
                                  when=_on, help=LL(31196, 'An episode is added so many days after its premiere (a source of it is there by then).'))

    _lists = SettingGroup(label=LL(31197, 'Lists in the library'), column=1)
    lists: list[str] | None = setting(kind='action', label=LL(31198, 'Lists to synchronize'), default=None,
                                      legacy_value=LegacyValue(ids=('library.lists.selected', 'library.lists.migrated'), value=legacy_lists), when=_on,
                                      help=LL(31199, 'The lists of the accounts (watchlists, favourites, ratings, own lists) whose media are added to '
                                                     'the library.'))
    update_shows: bool = setting(kind='bool', label=LL(32545, 'New episodes of the shows'), default=True, legacy='library.service.update', when=_on,
                                 help=LL(31200, 'Every synchronization adds the new episodes of the shows in the library too.'))
    sync_start_delay: int | None = setting(kind='scale', label=LL(32616, 'At the start of Kodi'), default=None, scale=sync_start_scale,
                                           legacy_value=LegacyValue(ids=('autoListsOnStart',), value=legacy_sync_start), when=_on,
                                           help=LL(31201, 'The lists are synchronized so long after the start of Kodi (not after a restart'
                                                          ' of the FanFilm service, e.g. its update).'))
    sync_hours: int = setting(kind='scale', label=LL(32613, 'Every, hours'), default=0, scale=sync_hours_scale,
                              legacy_value=LegacyValue(ids=('schedListsTime',), value=legacy_sync_hours), when=_on,
                              help=LL(31202, 'The lists are synchronized every so many hours (off: only at the start or by hand).'))
    preview = setting(kind='action', label=LL(30648, 'Preview selected lists'), when=_on,
                      help=LL(31203, 'How many media of the chosen lists would be added (nothing is written).'))
    sync_now = setting(kind='action', label=LL(30649, 'Update selected lists'), when=_on,
                       help=LL(31204, 'The chosen lists are synchronized now (in the background).'))


class Downloads(Card, root='/downloads'):
    """
    The settings of the downloads: the switch, the folders, the names of the files, the queue, the additional folder searched by the
    provider of the downloaded files. The settings of the downloading work only with it on.
    """

    #: The rows working only with the switch of the card on.
    _on = {'enabled': (True,)}

    _downloads = SettingGroup(label=LL(32347, 'Downloads'))
    enabled: bool = setting(kind='bool', label=LL(32348, 'Enable downloads'), default=False, legacy='downloads',
                            help=LL(30954, ('The sources can be downloaded to the folders below (the action "Download" of a source), '
                                            'the downloads have their window in the tools.')))
    movies_folder: str = setting(kind='folder', label=LL(32349, 'Movies'), default='', legacy='movie.download.path', when=_on,
                                 help=LL(30963, 'The folder of the downloaded movies.'))
    shows_folder: str = setting(kind='folder', label=LL(32350, 'TV'), default='', legacy='tv.download.path', when=_on,
                                help=LL(30972, 'The folder of the downloaded episodes (a folder of the show, a folder of the season in it).'))
    extra_info: bool = setting(kind='bool', label=LL(30316, 'Add extra info'), default=True, legacy='download.downinfo', when=_on,
                               help=LL(31016, 'The file name gets the language and the quality of the source.'))
    local_title: bool = setting(kind='bool', label=local_title_label, default=False, legacy='download.downlocaltitle', when=_on,
                                help=LL(31019, 'The file name from the title in the language of the information (else the English or the original one).'))

    _queue = SettingGroup(label=LL(31020, 'Queue'), column=1)
    show_manager: bool = setting(kind='bool', label=LL(30612, 'Show downloads automatically'), default=False, legacy='download.show_manager', when=_on,
                                 help=LL(31021, 'The downloads window opens after a download was added.'))
    pause_on_play: bool = setting(kind='bool', label=LL(31023, 'Pause while a video plays'), default=False, when=_on,
                                  help=LL(31027, ('Nothing is downloaded while a video plays (the connection is left to the playback); the downloads go on '
                                                  'after it.')))
    auto_pay: bool = setting(kind='bool', label=LL(31028, 'Buy expired links in the background'), default=False, when=_on,
                             help=LL(31038, ('An expired link of a download is always renewed in the background when the new one is free. On: a new '
                                             'link may also be bought (the transfer used without asking), only by a provider with the automatic use of the '
                                             'transfer on in its own settings. Off: nothing is bought in the background, such a download waits for a click. '
                                             'A renewal by hand always works.')))
    forget_removed: bool = setting(kind='bool', label=LL(31039, 'Forget removed files'), default=True, when=_on,
                                   help=LL(31040, 'A finished download whose file was removed leaves the list of the downloads.'))
    add_downloads: bool = setting(kind='bool', label=LL(31282, 'Add to the library'), default=False, when=_on, link='/library/add_downloads',
                                  help=LL(31283, ('A finished download adds its movie or its show to the library of Kodi: the same setting as the one '
                                                  'of the library (it works with the library on).')))

    _search = SettingGroup(label=LL(30306, 'Downloaded'), column=1)
    other_folder: bool = setting(kind='bool', label=LL(30318, 'Additional folder to search'), default=False, legacy='download.other_folder',
                                 help=LL(31041, 'The provider of the downloaded files searches one more folder (a local one or of the network).'))
    other_folder_path: str = setting(kind='folder', label=LL(32653, 'Location'), default='', legacy='download.other_folder_path',
                                     when={'other_folder': (True,)}, help=LL(31043, 'The additional folder searched for the downloaded files.'))


class Web(Card, root='/web'):
    """
    The settings of the FF web server: the access of this device (off, after pairing, a role without pairing) and of the other devices (the
    network: after pairing, or the server does not listen there; both off: the server does not listen at all), the rows of its actions, the
    forwarding of the received cookies to other FanFilm. The devices, the password and the forwarding targets of the server are data under the
    same root, no settings.
    """

    _access = SettingGroup(label=LL(33036, 'Access'))
    this_device: str = setting(kind='select', label=LL(31219, 'This device'), default=first_role, options=role_options,
                               help=LL(31260, 'A browser of this device at localhost or 127.0.0.1: off (refused, a paired one too), after pairing, or a '
                                              'role without pairing - of ANY program and ANY user of this device. A browser of this device at the '
                                              'address of the network pairs as any other device.'))
    network: bool = setting(kind='bool', label=LL(33037, 'Other devices'), default=True,
                            help=LL(31360, 'On: the devices of the home network after pairing. Off: the web server does not listen in the network '
                                    '(with "This device" off: not at all).'))
    address = setting(kind='action', label=LL(31250, 'Address'),
                      help=LL(31251, 'The address of the web server for a browser; OK: its QR code (allows pairing).'))
    sign_in = setting(kind='action', label=LL(32648, 'Password'),
                      help=LL(31225, ('A password of the web server pairs a browser without Kodi (it never leaves the browser): typed, generated '
                                      '(shown once), or none.')))

    _devices = SettingGroup(label=LL(31217, 'Paired devices'), column=1)
    requests = setting(kind='action', label=LL(31222, 'Requests for the access'),
                       help=LL(31223, ('The devices asking for the access (their button "Pair by a phone or in Kodi"): approve one with its role, or '
                                       'reject it.')))
    paired_devices = setting(kind='action', label=LL(31217, 'Paired devices'),
                             help=LL(31253, 'The paired browsers and browser scripts: change the role of one, remove one, or every one.'))

    _forwarding = SettingGroup(label=LL(33038, 'Forwarding'), column=1)
    forward = FORWARD_COOKIES


#: The cards of pure settings (w/o special widget cards). See `CARDS` in `lib/windows/config_dialog.py`
CARDS: tuple[type[Card], ...] = (General, SourceSettings, Maintenance, AccountSettings, Media, Library, Downloads, Web)

#: Every branch of the configuration (`config.json`): the cards of settings (by their declarations) and the data of the other modules
#: (declared there, only named here).
ROOTS: tuple[ConfigRoot, ...] = (
    *(ConfigRoot(pointer=card.ROOT, note=f'the card of settings `{card.__name__}`') for card in CARDS),
    ConfigRoot(pointer='/version', note='the version of the data of the file (`lib.ff.config.migrations`)'),
    ConfigRoot(pointer='/sources/providers', note='the values of the native providers (`lib.sources.natives`)'),
    ConfigRoot(pointer='/sources/providers_migrated', note='the mark of the moved old settings of the native providers (`lib.sources.natives`)'),
    ConfigRoot(pointer='/sources/addons', note='the provider add-ons (`lib.sources.addons.external`)'),
    ConfigRoot(pointer='/sources/nodes', note='the nodes of the tree of the source providers (`lib.sources.addons.external`)'),
    ConfigRoot(pointer='/sources/xproviders', note='the installed provider add-ons of FanFilm (`lib.ff.xproviders`)'),
    ConfigRoot(pointer='/accounts', note='the accounts (`lib.ff.accounts`)'),
    ConfigRoot(pointer='/lists', note='the lists: services, feeds, folders, places, subscriptions (`lib.ff.lists_config`)'),
    ConfigRoot(pointer='/menus', note='the entries of the menus (`lib.ff.menu_entries`)'),
    ConfigRoot(pointer='/gui/themes', note='the active themes (`lib.ff.theme`)'),
    ConfigRoot(pointer='/gui/theme_variant', note='the variant of the theme (`lib.ff.theme`)'),
    ConfigRoot(pointer='/gui/skin_colors', note='the colours taken of the skin (`lib.ff.theme`)'),
    ConfigRoot(pointer='/gui/tree', note='the memories of the trees of the windows (`lib.windows.tree`)'),
    ConfigRoot(pointer='/web/devices', note='the paired devices of the web server, under the root of its card (`lib.ff.web_settings`)'),
    ConfigRoot(pointer='/web/password', note='the password of the web server, under the root of its card (`lib.ff.web_settings`)'),
    ConfigRoot(pointer='/web/instance', note='the ID of this FanFilm for the web clients, under the root of its card (`lib.ff.web_settings`)'),
    ConfigRoot(pointer='/web/targets', note='the FanFilm the received cookies are forwarded to, under the root of its card (`lib.ff.web_settings`)'),
    ConfigRoot(pointer='/maintenance/developer', note='the choice of the developer tools, under the root of its card (`lib.ff.maintenance`)'),
    ConfigRoot(pointer='/debug', note='the debug of the sources (`lib.ff.source.debug`)'),
)
