# -*- coding: utf-8 -*-
"""
FanFilm - source: Bingr (bingr.one)

Dystrybuowane na licencji MIT <https://mit-license.org>

bingr.one hosts nothing: its watch page frames the embed players
below by the TMDB id. Each of them is asked directly:

- Vidbolt (vidbolt.xyz): /api/resolve?type=movie|tv&id=<tmdb>[&season&episode]&prefer=<server>
  gives plain JSON {"stream": {"server", "sources": [{"url", "quality", "language"}]}}; the API
  wants a Referer of the player page, the streams of Orion its origin.
- Vidly (vidly.pro): the player page carries a token and a sealed JSON (the servers and the streams
  of the default one); /api/sources?kind&provider&t&tmdb[&s&e] answers a sealed JSON too. The seal:
  base64url(nonce[12] + data XOR keystream), the keystream an sfc32 generator seeded by FNV-1a hashes
  of a constant of the player bundle and the nonce (_unseal()).
- Vidrift (embed.vidrift.in): the player page carries embedMeta.orionStreams (relative HLS masters,
  one per audio language); the page and the streams want a Firefox user agent (Cloudflare), the streams the
  Referer of the page.
- Cinezo (player.cinezo.live): plain JSON endpoints per server - Jennifer (punkflix.net, HLS up to
  4K), Scarlet / Zendaya (MovieBox MP4 via proxy.yenime.net), Berlin / Sadie (proxy1.flikhub.net);
  the streams want the Referer and Origin of the player.

The streams are HLS (played by InputStream Adaptive: proxy masters without ".m3u8", fMP4 audio groups), Cinezo
Scarlet / Zendaya MP4 files. The links carry tokens: no refresh, a short SOURCES_TTL.
Not here: Vidy (vidy.st), the fifth player of bingr (the Videasy player, a provider of its own).
Not used: the Vidbolt servers Quantum (dead playlists) and Quasar (answered by Orion).
"""

from __future__ import annotations

import base64
import json
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, ClassVar, TYPE_CHECKING
from urllib.parse import parse_qsl, unquote, urljoin

from cdefs import MINUTE
from lib.ff import requests
from lib.ff.logs import fflog
from lib.ff.source.utils import DEFAULT_UA, append_headers
from lib.sdk.facts.rules import lang
from lib.sdk.protocol.item import quality_of_resolution
from lib.sources import IncompleteResult, Provider, provider_query, skip

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sdk.protocol import ResolveResult
    from lib.sources import SourceItem, SourceSearchOverride

_TIMEOUT: int = 15

_VIDBOLT: str = 'https://vidbolt.xyz'
#: The Vidbolt servers asked (`prefer`), by their labels.
_VIDBOLT_SERVERS: dict[str, str] = {'orion': 'Orion', 'callisto': 'Callisto', 'luna': 'Luna', 'vega': 'Vega'}

_VIDLY: str = 'https://vidly.pro'
#: The constant of the seal of Vidly (its player bundle).
_VIDLY_SECRET: bytes = b'vY7#qL2!mZ9@wK4$'
_RX_VIDLY_TOKEN = re.compile(r'\\"token\\":\\"([^"\\]+)')
_RX_VIDLY_SEALED = re.compile(r'\\"sealed\\":\\"(v1\.[A-Za-z0-9_-]+)')

_VIDRIFT: str = 'https://embed.vidrift.in'
_RX_VIDRIFT_META = re.compile(r'embedMeta\s*=\s*(\{.*?\});', re.S)
#: Vidrift (Cloudflare) answers 403 to the Chrome user agent of FF (not matching its TLS), a Firefox one passes.
_VIDRIFT_UA: str = 'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0'
_RX_MP4 = re.compile(r'\.mp4(?:\?|&|$)')

_CINEZO: str = 'https://player.cinezo.live'
_CINEZO_HEADERS: dict[str, str] = {'Referer': f'{_CINEZO}/', 'Origin': _CINEZO}
#: The Cinezo servers asked, by their labels.
_CINEZO_SERVERS: dict[str, str] = {'jennifer': 'Jennifer', 'scarlet': 'Scarlet', 'zendaya': 'Zendaya',
                                   'berlin': 'Berlin', 'sadie': 'Sadie'}

#: The language names lang() does not know.
_LANGUAGES: dict[str, str] = {'bengali': 'bn', 'bangla': 'bn', 'kannada': 'kn', 'malayalam': 'ml',
                              'latin american spanish': 'es',
                              'esla': 'es', 'indonesian': 'id', 'marathi': 'mr', 'punjabi': 'pa', 'urdu': 'ur'}

_MASK: int = 0xFFFFFFFF


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    LABEL: ClassVar[str] = 'Bingr'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('en',)
    PREMIUM = False
    TMDB_EPISODES = True
    #: The stream links carry tokens (a day or less), keep the list short.
    SOURCES_TTL = 10 * MINUTE

    def __init__(self, *, ffitem: FFItem) -> None:
        super().__init__(ffitem=ffitem)
        self.session: requests.Session = requests.ProviderSession()
        self.session.headers.update({'User-Agent': DEFAULT_UA})

    # ── public api ─────────────────────────────────────────────────────────

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        season, episode = override['season'], override['episode']
        is_episode = season is not None and episode is not None  # a special: the season 0
        item = ffitem.show_item if is_episode else ffitem
        tmdb_id = item.tmdb_id if item is not None else None
        if not tmdb_id:
            fflog(f'no tmdb id: {ffitem}')
            return []
        title = _Title(tmdb=str(tmdb_id), season=season if is_episode else None,
                       episode=episode if is_episode else None,
                       original=next(iter(provider_query(ffitem, override).get('original_languages') or ()), ''))

        players: dict[str, Callable[[_Title], list[SourceItem]]] = {
            'Vidbolt': self._vidbolt, 'Vidly': self._vidly, 'Vidrift': self._vidrift, 'Cinezo': self._cinezo}
        result: list[SourceItem] = []
        failed: list[str] = []
        with ThreadPoolExecutor(max_workers=len(players)) as pool:
            futures = {name: pool.submit(player, title) for name, player in players.items()}
            for name, future in futures.items():
                try:
                    result.extend(future.result())
                except (requests.RequestException, ValueError) as exc:  # unexpected ones go out (README)
                    fflog.warning(f'{name} failed: {exc!r}')
                    failed.append(name)

        seen: set[str] = set()
        unique: list[SourceItem] = []
        for src in result:
            key = src['url'].partition('|')[0]
            if key in seen:
                skip(self, 'duplicate', url=key, hosting=src.get('hosting', ''))
                continue
            seen.add(key)
            unique.append(src)
        fflog(f'sources: {len(unique)} for tmdb={tmdb_id} {season=} {episode=}'
              + (f', failed: {", ".join(failed)}' if failed else ''))
        if failed:
            raise IncompleteResult(unique, f'failed: {", ".join(failed)}')
        return unique

    def resolve(self, url: str, **kwargs) -> str | ResolveResult | None:
        link, _, headers = url.partition('|')
        if _RX_MP4.search(unquote(link)):
            return url
        # HLS through InputStream Adaptive: Kodi's ffmpeg does not know a master without ".m3u8" (a proxy link)
        # nor fMP4 audio groups
        return {'url': link, 'headers': dict(parse_qsl(headers)), 'play': 'isa', 'isa': {'protocol': 'hls'}}

    # ── players ────────────────────────────────────────────────────────────

    def _vidbolt(self, title: _Title) -> list[SourceItem]:
        page = f'{_VIDBOLT}/{title.path("tv/{tmdb}/{season}/{episode}", "movie/{tmdb}")}'
        params: dict[str, Any] = {'type': 'movie', 'id': title.tmdb}
        if title.season is not None:
            params.update(type='tv', season=title.season, episode=title.episode)
        headers = {'Referer': f'{_VIDBOLT}/', 'User-Agent': DEFAULT_UA}

        def server(name: str) -> list[SourceItem]:
            resp = self.session.get(f'{_VIDBOLT}/api/resolve', params={**params, 'prefer': name},
                                    headers={'Referer': page}, timeout=_TIMEOUT)
            resp.raise_for_status()
            stream = resp.json().get('stream') or {}
            if stream.get('server') != name:  # another server answered (its own request gives it)
                fflog.debug(f'Vidbolt {name}: answered by {stream.get("server")}')
                return []
            return [_item('Vidbolt', _VIDBOLT_SERVERS[name], str(src['url']), _quality(src.get('quality')),
                          _language(src.get('language'), title.original), headers)
                    for src in stream.get('sources') or () if src.get('url')]

        return _gather(server, _VIDBOLT_SERVERS)

    def _vidly(self, title: _Title) -> list[SourceItem]:
        page = f'{_VIDLY}/{title.path("tv/{tmdb}/{season}/{episode}", "movie/{tmdb}")}'
        resp = self.session.get(page, headers={'Referer': 'https://bingr.one/'}, timeout=_TIMEOUT)
        resp.raise_for_status()
        token, sealed = _RX_VIDLY_TOKEN.search(resp.text), _RX_VIDLY_SEALED.search(resp.text)
        if not token or not sealed:
            raise ValueError('Vidly: no token in the player page')
        first = _unseal(sealed.group(1))
        default = (first.get('provider') or {}).get('id')
        servers = {str(srv['id']): str(srv.get('label') or srv['id'])
                   for srv in first.get('servers') or () if srv.get('id')}
        params: dict[str, Any] = {'kind': 'tv' if title.season is not None else 'movie', 't': token.group(1),
                                  'tmdb': title.tmdb}
        if title.season is not None:
            params.update(s=title.season, e=title.episode)

        def server(name: str) -> list[SourceItem]:
            if name == default:
                data = first
            else:
                resp = self.session.get(f'{_VIDLY}/api/sources', params={**params, 'provider': name},
                                        headers={'Referer': page},
                                        timeout=_TIMEOUT)
                resp.raise_for_status()
                data = _unseal(resp.text.strip())
            if data.get('error'):
                fflog.debug(f'Vidly {name}: {data["error"]}')
            return [_item('Vidly', servers[name], str(st['url']), _quality(st.get('quality')),
                          _language(st.get('language'), title.original),
                          {'User-Agent': DEFAULT_UA, **(st.get('headers') or {})})
                    for st in data.get('streams') or () if st.get('url')]

        return _gather(server, servers)

    def _vidrift(self, title: _Title) -> list[SourceItem]:
        page = f'{_VIDRIFT}/embed/{title.path("tv/{tmdb}/{season}/{episode}", "movie/{tmdb}")}'
        resp = self.session.get(page, headers={'Referer': 'https://bingr.one/', 'User-Agent': _VIDRIFT_UA},
                                timeout=_TIMEOUT)
        resp.raise_for_status()
        match = _RX_VIDRIFT_META.search(resp.text)
        if not match:
            raise ValueError('Vidrift: no embedMeta in the player page')
        headers = {'Referer': page, 'User-Agent': _VIDRIFT_UA}
        result: list[SourceItem] = []
        for st in json.loads(match.group(1)).get('orionStreams') or ():
            if not st.get('url'):
                continue
            label = str(st.get('name') or '').rpartition('·')[2].strip()  # "Orion · Hindi"
            height = max((int(rung.get('height') or 0) for rung in st.get('rungs') or ()), default=0)
            result.append(_item('Vidrift', str(st.get('provider') or 'Orion'), urljoin(page, str(st['url'])),
                                _quality(f'{height}p' if height else ''), _language(label, title.original), headers))
        return result

    def _cinezo(self, title: _Title) -> list[SourceItem]:
        headers = {**_CINEZO_HEADERS, 'User-Agent': DEFAULT_UA}
        if title.season is not None:
            urls = {'jennifer': f'https://punkflix.net/tv/{title.tmdb}/{title.season}/{title.episode}.json',
                    'scarlet': f'https://proxy.yenime.net/tv?id={title.tmdb}&season={title.season}&episode={title.episode}&mode=json&sources=scarlet',
                    'zendaya': f'https://proxy.yenime.net/tv?id={title.tmdb}&season={title.season}&episode={title.episode}&mode=json&sources=zendaya&hevc=1'}
            urls.update({name: f'https://proxy1.flikhub.net/tv?id={title.tmdb}&season={title.season}&episode={title.episode}&mode=json&sources={name}&hevc=1'
                         for name in ('berlin', 'sadie')})
        else:
            urls = {'jennifer': f'https://punkflix.net/movie/{title.tmdb}.json',
                    'scarlet': f'https://proxy.yenime.net/movie?id={title.tmdb}&mode=json&sources=scarlet',
                    'zendaya': f'https://proxy.yenime.net/movie?id={title.tmdb}&mode=json&sources=zendaya&hevc=1'}
            urls.update({name: f'https://proxy1.flikhub.net/movie?id={title.tmdb}&mode=json&sources={name}&hevc=1'
                         for name in ('berlin', 'sadie')})

        def server(name: str) -> list[SourceItem]:
            resp = self.session.get(urls[name], headers=_CINEZO_HEADERS, timeout=_TIMEOUT)
            if resp.status_code == 404:
                return []  # not on this server
            resp.raise_for_status()
            data = resp.json()
            label = _CINEZO_SERVERS[name]
            if name == 'jennifer':
                stream = data.get('stream') or {}
                url = stream.get('hls') or stream.get('original')
                if not url:
                    return []
                width, _, height = str((data.get('quality') or {}).get('resolution') or '').partition('x')
                audio = next((track for track in data.get('audio') or () if track.get('default')), None) or {}
                quality = (quality_of_resolution(int(width), int(height))
                           if width.isdigit() and height.isdigit() else '')
                return [_item('Cinezo', label, str(url), quality, _language(audio.get('language'), title.original),
                              headers)]
            src = data.get('source') or {}
            language = 'hi' if name == 'sadie' else _language(None, title.original)  # Sadie: the Hindi server
            return [_item('Cinezo', label, link, _quality(quality), language, headers)
                    for quality, link in _cinezo_variants(src)]

        return _gather(server, _CINEZO_SERVERS)


# ─── helpers ─────────────────────────────────────────────────────────────────────

class _Title:
    """The searched movie / episode: the TMDB id (of the show), the numbers of an episode, the original language."""

    def __init__(self, *, tmdb: str, season: int | None, episode: int | None, original: str) -> None:
        self.tmdb = tmdb
        self.season = season
        self.episode = episode
        self.original = original

    def path(self, episode_path: str, movie_path: str) -> str:
        """Return the path of the player page of the episode or of the movie (`{tmdb}`, `{season}`, `{episode}`)."""
        path = episode_path if self.season is not None else movie_path
        return path.format(tmdb=self.tmdb, season=self.season, episode=self.episode)


def _gather(server: Callable[[str], list[SourceItem]], names: dict[str, str]) -> list[SourceItem]:
    """Ask the servers of a player at once, their items in the order of `names`; a failed server is logged, skipped."""
    result: list[SourceItem] = []
    with ThreadPoolExecutor(max_workers=max(1, len(names))) as pool:
        futures = {name: pool.submit(server, name) for name in names}
        for name, future in futures.items():
            try:
                result.extend(future.result())
            except (requests.RequestException, ValueError) as exc:
                fflog.warning(f'server {name} failed: {exc!r}')
    return result


def _cinezo_variants(src: dict) -> list[tuple[str, str]]:
    """
    Return (quality, link) of the files of a Cinezo source: `qualities` {"480": {"url"}}
    or [{"quality": "720P", "url"}], else its `url`.
    """
    qualities = src.get('qualities') or {}
    if isinstance(qualities, dict):
        variants = [(f'{key}p', str(value.get('url') or ''))
                    for key, value in qualities.items() if isinstance(value, dict)]
    else:
        variants = [(str(value.get('quality') or ''), str(value.get('url') or ''))
                    for value in qualities if isinstance(value, dict)]
    variants = [(quality, link) for quality, link in variants if link]
    return variants or ([('', str(src['url']))] if src.get('url') else [])


def _item(player: str, server: str, url: str, quality: str, language: str, headers: dict[str, str]) -> SourceItem:
    """Return the source item of a stream of a player (`headers`: the ones its stream wants)."""
    return {
        'hosting': f'{player} {server}',
        'url': url + append_headers(headers),
        'quality': quality,
        'language': language,
        'direct': True,
        'debridonly': False,
    }


def _quality(value: Any) -> str:
    """Return the quality of a player ("1080p", "720p"), empty if not given ("Auto", "unknown")."""
    text = str(value or '').lower()
    return text if re.fullmatch(r'\d{3,4}p', text) else ''


def _language(name: Any, original: str) -> str:
    """Return the language code of a player's language name ("Hindi", "Latin American Spanish"), else the original."""
    text = str(name or '').strip()
    if not text or text.lower() in ('original', 'default') or text.lower().endswith(' sub'):
        return original
    return lang(text) or _LANGUAGES.get(text.lower()) or original


def _unseal(sealed: str) -> dict:
    """Return the JSON of a sealed text of Vidly ("v1." + base64url of the nonce and the data XOR its keystream)."""
    if not sealed.startswith('v1.'):
        raise ValueError(f'Vidly: not a sealed text: {sealed[:20]!r}')
    raw = base64.urlsafe_b64decode(sealed[3:] + '=' * (-len(sealed[3:]) % 4))
    nonce, data = raw[:12], bytearray(raw[12:])
    state = [_fnv(index, nonce) for index in range(4)]
    word = 0
    for pos in range(len(data)):
        if pos & 3 == 0:
            word, state = _sfc32(state)
        data[pos] ^= (word >> ((pos & 3) * 8)) & 0xFF
    return json.loads(bytes(data).decode())


def _fnv(index: int, nonce: bytes) -> int:
    """Return the FNV-1a hash of the secret and the nonce, its basis of the seed `index`."""
    value = (0x811C9DC5 ^ ((0x9E3779B9 * index) & _MASK)) & _MASK
    for byte in _VIDLY_SECRET + nonce:
        value = ((value ^ byte) * 0x01000193) & _MASK
    return value


def _sfc32(state: list[int]) -> tuple[int, list[int]]:
    """Return the next 32-bit word of the sfc32 generator and its new state (a, b, c, counter)."""
    sa, sb, sc, sd = state
    tmp = (sa + sb) & _MASK
    sa = sb ^ (sb >> 9)
    sb = (sc + (sc << 3)) & _MASK
    sc = ((sc << 21) | (sc >> 11)) & _MASK
    sd = (sd + 1) & _MASK
    tmp = (tmp + sd) & _MASK
    sc = (sc + tmp) & _MASK
    return tmp, [sa, sb, sc, sd]
