# -*- coding: utf-8 -*-
"""
FanFilm - source: Vidy (vidy.st)

Dystrybuowane na licencji MIT <https://mit-license.org>

Vidy (www.vidy.st, a player of bingr.one) is the Videasy player under a new name: the same
API (now api.wecollege.net) and the same encryption of its answers.

- GET /seed?mediaId=<tmdb> gives {"seed", "ttlMs"} (30 s, one seed serves every server).
- GET /<server>/sources?title&mediaType&year&totalSeasons&seasonId&episodeId&tmdbId&imdbId&enc=2&seed
  gives base64url(b'mvm1' + JSON XOR keystream(seed, tmdb)), the JSON {"sources": [{"url",
  "quality"}], "subtitles": [{"url", "lang" | "language"}]} (_decrypt()).
- The servers (cities) and their audio are the list of the player bundle (_SERVERS); Austin and
  Delhi share one backend, their sources labelled by the language in "quality".
- The streams (HLS, Nashville DASH) want the Origin and Referer of the player.
"""

from __future__ import annotations

import base64
import json
from concurrent.futures import ThreadPoolExecutor
from typing import ClassVar, NamedTuple, TYPE_CHECKING
from urllib.parse import parse_qsl, quote

from cdefs import MINUTE
from lib.ff import requests
from lib.ff.logs import fflog
from lib.ff.source.utils import DEFAULT_UA, append_headers
from lib.sdk.facts.rules import lang
from lib.sources import IncompleteResult, Provider, provider_query, skip

if TYPE_CHECKING:
    from lib.ff.item import FFItem
    from lib.sdk.facts.types import SubtitleTrack
    from lib.sdk.protocol import ResolveResult, ResolveSubtitle
    from lib.sources import SourceItem, SourceResolveKwargs, SourceSearchOverride
    from typing_extensions import Unpack

_API: str = 'https://api.wecollege.net'
_PLAYER: str = 'https://www.vidy.st'
_TIMEOUT: int = 10
#: The servers asked at once (the API answers 429 to a burst).
_WORKERS: int = 6
_HEADERS: dict[str, str] = {'User-Agent': DEFAULT_UA, 'Origin': _PLAYER, 'Referer': f'{_PLAYER}/'}


class _Server(NamedTuple):
    #: The label of the player.
    label: str
    #: The audio language, '' the original one.
    language: str = ''
    #: Only the sources of this "quality" (a shared backend of more languages).
    only: str = ''
    #: The original title in `altTitle` too.
    alt_title: bool = False


#: The servers of the player (its bundle) by their API path.
_SERVERS: dict[str, _Server] = {
    'miami': _Server('Miami'),
    'boise': _Server('Boise'),
    'nashville': _Server('Nashville', alt_title=True),
    'chicago': _Server('Chicago', alt_title=True),
    'vegas': _Server('Vegas'),
    'reno': _Server('Reno'),
    'oakland': _Server('Oakland'),
    'seattle': _Server('Seattle'),
    'phoenix': _Server('Phoenix'),
    'atlanta': _Server('Atlanta'),
    'portland': _Server('Portland'),
    'austin': _Server('Austin', only='English'),
    'dallas': _Server('Dallas'),
    'munich': _Server('Munich', 'de'),
    'berlin': _Server('Berlin', 'de'),
    'paris': _Server('Paris', 'fr'),
    'delhi': _Server('Delhi', 'hi', only='Hindi'),
    'cancun': _Server('Cancun', 'es'),
}


# ─── source ──────────────────────────────────────────────────────────────────────

class source(Provider):
    LABEL: ClassVar[str] = 'Vidy'
    PRIORITY: ClassVar[int] = 1
    LANGUAGES = ('en', 'de', 'fr', 'hi', 'es')
    PREMIUM = False
    TMDB_EPISODES = True
    #: The stream links carry tokens, keep the list short.
    SOURCES_TTL = 10 * MINUTE

    def __init__(self, *, ffitem: FFItem) -> None:
        super().__init__(ffitem=ffitem)
        self.session: requests.Session = requests.ProviderSession()
        self.session.headers.update(_HEADERS)

    # ── public api ─────────────────────────────────────────────────────────

    def find(self, *, ffitem: FFItem, override: SourceSearchOverride) -> list[SourceItem]:
        season, episode = override['season'], override['episode']
        is_episode = season is not None and episode is not None  # a special: the season 0
        query = provider_query(ffitem, override)
        tmdb = str(query.get('ids', {}).get('tmdb') or '')
        titles = query.get('title', {})
        title = titles.get('english') or titles.get('original') or titles.get('local') or ''
        if not tmdb or not title:
            fflog(f'no tmdb id or title: {ffitem}')
            return []
        original = titles.get('original') or ''
        params: dict[str, str] = {
            'title': quote(title),  # the player encodes it and its HTTP client again
            'mediaType': 'tv' if is_episode else 'movie',
            'year': str(query.get('year') or ''),
            'totalSeasons': str(query.get('total_seasons') or '') if is_episode else '',
            'episodeId': str(episode if is_episode else 1),
            'seasonId': str(season if is_episode else 1),
            'tmdbId': tmdb,
            'imdbId': query.get('ids', {}).get('imdb') or '',
            'enc': '2',
        }
        resp = self.session.get(f'{_API}/seed', params={'mediaId': tmdb}, timeout=_TIMEOUT)
        resp.raise_for_status()
        params['seed'] = seed = str(resp.json()['seed'])
        alt_title: dict[str, str] = {'altTitle': quote(original)} if original and original != title else {}
        langs = query.get('original_languages') or ()
        original_lang = langs[0] if langs else ''

        def server(name: str) -> list[SourceItem]:
            srv = _SERVERS[name]
            server_params = {**params, **alt_title} if srv.alt_title else params
            resp = self.session.get(f'{_API}/{name}/sources', params=server_params, timeout=_TIMEOUT)
            if resp.status_code in (404, 500):  # no such route, nothing found ("No streams available", "no embed")
                fflog.debug(f'{srv.label}: HTTP {resp.status_code} {resp.text[:100]}')
                return []
            resp.raise_for_status()
            data = _decrypt(resp.text, seed, tmdb)
            subtitles = [sub for sub in data.get('subtitles') or () if sub.get('url')]
            result: list[SourceItem] = []
            for src in data.get('sources') or ():
                if not src.get('url'):
                    continue
                label = str(src.get('quality') or '')
                if srv.only and label != srv.only:
                    skip(self, f'not {srv.only}', url=src['url'], hosting=srv.label, quality=label)
                    continue
                result.append(_item(srv, str(src['url']), label, srv.language or original_lang, subtitles))
            return result

        result: list[SourceItem] = []
        failed: list[str] = []
        with ThreadPoolExecutor(max_workers=_WORKERS) as pool:
            futures = {name: pool.submit(server, name) for name in _SERVERS}
            for name, future in futures.items():
                try:
                    result.extend(future.result())
                except (requests.RequestException, ValueError) as exc:
                    fflog.warning(f'server {_SERVERS[name].label} failed: {exc!r}')
                    response = getattr(exc, 'response', None)
                    if response is not None and response.status_code == 429:
                        failed.append(_SERVERS[name].label)  # the rate limit, not a dead server (a timeout)

        seen: set[str] = set()
        unique: list[SourceItem] = []
        for src in result:
            key = src['url'].partition('|')[0]
            if key in seen:
                skip(self, 'duplicate', url=key, hosting=src.get('hosting', ''))
                continue
            seen.add(key)
            unique.append(src)
        fflog(f'sources: {len(unique)} for tmdb={tmdb} {season=} {episode=}'
              + (f', failed: {", ".join(failed)}' if failed else ''))
        if failed:  # rate limited: not cached, asked again next time
            raise IncompleteResult(unique, f'failed: {", ".join(failed)}')
        return unique

    def resolve(self, url: str, **kwargs: Unpack[SourceResolveKwargs]) -> str | ResolveResult | None:
        link, _, headers = url.partition('|')
        data = kwargs.get('data') or {}
        subtitles: list[ResolveSubtitle] = []
        for sub in data.get('subtitles') or ():
            subtitle: ResolveSubtitle = {'url': str(sub['url'])}
            if sub.get('lang'):
                subtitle['lang'] = str(sub['lang'])
            subtitles.append(subtitle)
        # the links have no extension: HLS (Kodi's ffmpeg does not know it then) or DASH, by the manifest
        resp = self.session.get(link, headers=dict(parse_qsl(headers)), timeout=_TIMEOUT, stream=True)
        if resp.status_code != 200:
            fflog(f'dead link: HTTP {resp.status_code} {link}')
            resp.close()
            return None
        head = next(resp.iter_content(512), b'')
        resp.close()
        dash = b'<MPD' in head or head.lstrip().startswith(b'<?xml')
        return {'url': link, 'headers': dict(parse_qsl(headers)), 'play': 'isa',
                'isa': {'protocol': 'mpd' if dash else 'hls'}, 'subtitles': subtitles}


# ─── helpers ─────────────────────────────────────────────────────────────────────

def _item(srv: _Server, url: str, label: str, language: str, subtitles: list[dict]) -> SourceItem:
    """Return the source item of a stream of a server (`label`: its "quality", `subtitles`: its files)."""
    files = [{'url': str(sub['url']), 'lang': lang(str(sub.get('lang') or sub.get('language') or '')) or ''}
             for sub in subtitles]
    codes = dict.fromkeys(file['lang'] for file in files if file['lang'])
    tracks: list[SubtitleTrack] = [{'lang': code} for code in codes]
    item: SourceItem = {
        'hosting': f'Vidy {srv.label}',
        'url': url + append_headers(_HEADERS),
        'quality': label if label[:-1].isdigit() and label.endswith('p') else '',
        'language': language,
        'info': '',
        'direct': True,
        'debridonly': False,
        'data': {'subtitles': files},
    }
    if tracks:
        # the subtitles alone would hide the language of the provider (source_language())
        item['subtitles'] = tracks
        if language:
            item['audio'] = [{'lang': language}]
    return item


# ─── payload decryption ─────────────────────────────────────────────────────────
# 32-bit port of the player's keystream: base64url(XOR(b'mvm1' + json, keystream(seed, tmdb id))).

_MASK: int = 0xFFFFFFFF
_GOLDEN: int = 0x9E3779B9
_TABLE_SIZE: int = 61
_MAGIC: bytes = b'mvm1'


def _fmix32(value: int) -> int:
    """MurmurHash3 32-bit finalizer."""
    value &= _MASK
    value ^= value >> 16
    value = (value * 0x85EBCA6B) & _MASK
    value ^= value >> 13
    value = (value * 0xC2B2AE35) & _MASK
    return (value ^ (value >> 16)) & _MASK


def _rotl32(value: int, shift: int) -> int:
    """32-bit rotate left."""
    value &= _MASK
    shift &= 31
    return value if not shift else ((value << shift) | (value >> (32 - shift))) & _MASK


def _fnv1a(text: str) -> int:
    """FNV-1a hash of the seed, finalized by _fmix32()."""
    value = 0x811C9DC5
    for char in text:
        value = ((value ^ ord(char)) * 0x01000193) & _MASK
    return _fmix32(value)


def _keystream(seed: str, media_id: str, length: int) -> bytes:
    """Return `length` XOR key bytes of a seed and a TMDB id."""
    # the JS table is a sparse Array(61): a missing slot reads as 0 and switches the AND term off, hence a dict
    table: dict[int, int] = {}
    state = _fmix32(_fnv1a(seed) ^ _fmix32((int(media_id) & _MASK) ^ _GOLDEN))
    for round_no in range(8):
        slot = state % _TABLE_SIZE
        state = _rotl32(state + _GOLDEN, 7 + (round_no & 7))
        table[slot] = state ^ _fmix32(state)
        state = _fmix32(state + slot)
    state = _fmix32(0xA5A5A5A5 ^ state)

    out = bytearray()
    counter = 0
    while len(out) < length:
        slot = state % _TABLE_SIZE
        mixed = table.get(slot, 0) ^ ((_GOLDEN * (counter + 1)) & _MASK)
        word = (state ^ mixed) | ((state & mixed) if slot in table else 0)
        word = _rotl32(word + state, slot) ^ _rotl32(state, slot * 7)
        state = _fmix32(word + _GOLDEN)
        table[slot] = state
        counter += 1
        out += state.to_bytes(4, 'little')
    return bytes(out[:length])


def _decrypt(text: str, seed: str, media_id: str) -> dict:
    """Return the JSON of an answer of a server; ValueError if it does not decrypt (a changed keystream)."""
    text = text.strip()
    raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    plain = bytes(cipher ^ key for cipher, key in zip(raw, _keystream(seed, media_id, len(raw))))
    if not plain.startswith(_MAGIC):
        raise ValueError('not decrypted (a changed keystream?)')
    return json.loads(plain[len(_MAGIC):].decode('utf-8'))
