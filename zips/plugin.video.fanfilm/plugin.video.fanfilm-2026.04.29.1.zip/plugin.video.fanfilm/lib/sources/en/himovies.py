# -*- coding: utf-8 -*-
"""
FanFilm - źródło: himovies.sx
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

Flow:
  search:  GET /search/TITLE → parse href="/movie/slug-ID" with year
  movie:   GET /ajax/episode/list/MEDIA_ID  → server list HTML (data-id)
  tv:      GET /ajax/season/list/TV_ID      → season IDs
           GET /ajax/season/episodes/SID    → episode IDs
           GET /ajax/episode/servers/EID    → server list HTML (data-id)
  sources: GET /ajax/episode/sources/SID   → {"type":"iframe","link":"https://videostr.net/..."}
  resolve: fetch embed page → extract file_id + nonce
           GET /embed-1/v3/e-1/getSources?id=FILE_ID&_k=NONCE
           → decrypt sources → m3u8 URL (via resolve_megacloud)
"""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Dict, List, Optional, ClassVar
from urllib.parse import parse_qs, urljoin, urlencode

from lib.ff import client, cleantitle
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.resolve_utils import resolve_megacloud
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.sources import SourceItem, SourceTitleAlias


_BASE = 'https://himovies.sx'
_AJAX_HEADERS = {
    'User-Agent': DEFAULT_UA,
    'Referer': _BASE + '/',
    'X-Requested-With': 'XMLHttpRequest',
}

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    def __init__(self):
        self.domains = ['himovies.sx']

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        try:
            return urlencode({'title': title, 'year': year, 'imdb': imdb})
        except Exception:
            fflog_exc()
            return None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: list[SourceTitleAlias], year: str) -> Optional[str]:
        try:
            return urlencode({'tvshowtitle': tvshowtitle, 'year': year, 'imdb': imdb})
        except Exception:
            fflog_exc()
            return None

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        try:
            if url is None:
                return None
            data = {k: v[0] for k, v in parse_qs(url).items()}
            data.update({'title': title, 'premiered': premiered,
                         'season': season, 'episode': episode})
            return urlencode(data)
        except Exception:
            fflog_exc()
            return None

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        results = []
        try:
            if not url:
                return results

            data = {k: v[0] for k, v in parse_qs(url).items()}
            is_episode = 'tvshowtitle' in data
            title = data.get('tvshowtitle' if is_episode else 'title', '')
            year = data.get('year', '')
            season = data.get('season', '1')
            episode = data.get('episode', '1')

            media_id, page_url = self._search(title, year, is_tv=is_episode)
            if not media_id:
                fflog(f"himovies: not found — {title!r} ({year})")
                return results

            servers_r = self._get_servers_html(media_id, is_episode, season, episode)
            if not servers_r:
                return results

            for server_id, server_name in self._parse_servers(servers_r):
                try:
                    embed_url = self._get_embed_url(server_id)
                    if not embed_url:
                        continue
                    quality = '4K' if '4k' in server_name.lower() else '1080p'
                    results.append({
                        'source': server_name.lower().replace(' ', ''),
                        'quality': quality,
                        'language': 'en',
                        'url': embed_url,
                        'info': '',
                        'filename': page_url or '',
                        'direct': False,
                        'debridonly': False,
                    })
                    fflog(f"himovies: server {server_name!r} → {embed_url[:60]}")
                except Exception:
                    fflog_exc()

        except Exception:
            fflog_exc()
        fflog(f'sources: {len(results)}')
        return results

    def resolve(self, url: str) -> Optional[str]:
        try:
            resolved = resolve_megacloud(url)
            if not resolved:
                return url
            final_url, _tracks = resolved
            fflog(f"himovies resolve: video → {final_url[:80]}")
            return final_url
        except Exception:
            fflog_exc()
            return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _search(self, title: str, year: str, *, is_tv: bool) -> tuple[str, str] | tuple[None, None]:
        """Return (media_id, page_url) or (None, None)."""
        fflog(f'query: {title!r}')
        slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
        r = client.request(
            urljoin(_BASE, f"/search/{slug}"),
            headers=_AJAX_HEADERS,
        )
        if not r:
            return None, None

        ctype = 'tv' if is_tv else 'movie'
        clean = cleantitle.get(title)

        # href="/movie/some-slug-12345" title="Movie Title"
        pattern = re.compile(
            r'href="/' + ctype + r'/([^"]*?-(\d+))"[^>]*title="([^"]*)"',
            re.IGNORECASE,
        )

        matches = list(pattern.finditer(r))
        fflog(f'search: {len(matches)} results')
        best_id = None
        best_slug = None
        for m in matches:
            item_title = m.group(3)
            full_slug = m.group(1)
            media_id = m.group(2)
            if cleantitle.get(item_title) != clean:
                continue
            if not best_id:
                best_id, best_slug = media_id, full_slug
            nearby = r[max(0, m.start() - 50): m.end() + 400]
            if year and year in nearby:
                page_url = f"{_BASE}/{ctype}/{full_slug}"
                fflog(f"himovies: matched {item_title!r} ({year}) → {page_url}")
                return media_id, page_url

        if best_id:
            page_url = f"{_BASE}/{ctype}/{best_slug}"
            fflog(f"himovies: title-only match for {title!r} → {page_url}")
            return best_id, page_url
        return None, None

    def _get_servers_html(self, media_id: str, is_episode: bool,
                          season: str, episode: str) -> str | None:
        if not is_episode:
            return client.request(
                urljoin(_BASE, f"/ajax/episode/list/{media_id}"),
                headers=_AJAX_HEADERS,
            )

        # TV: season list → season_id → episode list → episode_id → servers
        seasons_r = client.request(
            urljoin(_BASE, f"/ajax/season/list/{media_id}"),
            headers=_AJAX_HEADERS,
        )
        if not seasons_r:
            return None

        season_id = self._pick_id_by_label(seasons_r, 'Season', int(season))
        if not season_id:
            return None

        eps_r = client.request(
            urljoin(_BASE, f"/ajax/season/episodes/{season_id}"),
            headers=_AJAX_HEADERS,
        )
        if not eps_r:
            return None

        episode_id = self._pick_id_by_label(eps_r, 'Eps', int(episode))
        if not episode_id:
            return None

        return client.request(
            urljoin(_BASE, f"/ajax/episode/servers/{episode_id}"),
            headers=_AJAX_HEADERS,
        )

    @staticmethod
    def _pick_id_by_label(html: str, label: str, number: int) -> str | None:
        """
        Find data-id nearest to 'label N' (e.g. 'Season 3' or 'Eps 5').
        Falls back to positional pick by index (number-1).
        """
        # Forward: data-id="ID" ... label N
        m = re.search(
            r'data-id="(\d+)"[^>]*>(?:(?!data-id).){0,200}?' + label + r'\s+' + str(number) + r'\b',
            html, re.IGNORECASE | re.DOTALL,
        )
        if m:
            return m.group(1)

        # Reverse: label N ... data-id="ID"
        m = re.search(
            label + r'\s+' + str(number) + r'\b(?:(?!data-id).){0,200}?data-id="(\d+)"',
            html, re.IGNORECASE | re.DOTALL,
        )
        if m:
            return m.group(1)

        # Positional fallback
        ids = re.findall(r'data-id="(\d+)"', html)
        idx = number - 1
        if 0 <= idx < len(ids):
            fflog(f"himovies: positional fallback for {label} {number} → id={ids[idx]}")
            return ids[idx]

        return None

    _SKIP_SERVERS = {'akcloud'}  # CDN token expires after ~30min, always same static URL

    @classmethod
    def _parse_servers(cls, html: str) -> list[tuple[str, str]]:
        """Return [(server_id, server_name), …] from server list HTML."""
        items = re.findall(r'data-id="(\d+)"[^>]*title="Server ([^"]*)"', html)
        if not items:
            ids = re.findall(r'data-id="(\d+)"', html)
            items = [(sid, f"Server{i + 1}") for i, sid in enumerate(ids)]
        return [(sid, name) for sid, name in items
                if name.lower().replace(' ', '') not in cls._SKIP_SERVERS]

    @staticmethod
    def _get_embed_url(server_id: str) -> str | None:
        """Call /ajax/episode/sources/SERVER_ID → return embed link."""
        r = client.request(
            urljoin(_BASE, f"/ajax/episode/sources/{server_id}"),
            headers=_AJAX_HEADERS,
        )
        if not r:
            return None
        try:
            return json.loads(r).get('link') or None
        except (json.JSONDecodeError, AttributeError):
            return None
