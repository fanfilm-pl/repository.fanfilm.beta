# -*- coding: utf-8 -*-
"""
FanFilm ‑ źródło: animezone
Copyright (C) 2025 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

import re
import unicodedata
from urllib.parse import quote_plus

from lib.ff import requests
from lib.ff import cleantitle, client, control, source_utils
from lib.ff.source_utils import absoluteNumber, DEFAULT_UA
from lib.ff.log_utils import fflog, fflog_exc
from lib.ff.item import FFItem


class source:

    # set in ff/sources.py
    ffitem: FFItem

    def __init__(self):
        self.priority = 1
        self.language = ["pl"]

        self.base_link = "https://www.animezone.pl"
        self.search_link = "https://www.animezone.pl/szukaj?q=%s"
        self.session = requests.Session()
        self.cookies = None
        self.headers = {
            "Host": "www.animezone.pl",
            "User-Agent": DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1"
        }

    def contains_word(self, str_to_check, word):
        if str(word).lower() in str(str_to_check).lower():
            return True
        return False

    def contains_all_words(self, str_to_check, words):
        for word in words:
            if not self.contains_word(str_to_check, word):
                return False
        return True

    @fflog_exc
    def movie(self, imdb, title, localtitle, aliases, year):
        if not source_utils.is_anime(self.ffitem):
            return
        jp_aliases = [alias["title"] for alias in aliases if alias["country"] == "jp"]
        jp_titles_from_aliases = jp_aliases[:1] if jp_aliases else []
        titles = jp_titles_from_aliases + [title]
        fflog(f'Movie search titles: {titles}')
        return self.search_ep_or_movie(titles, None, None, None)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        jp_aliases = [alias["title"] for alias in aliases if alias["country"] == "jp"]
        jp_titles_from_aliases = jp_aliases[:1] if jp_aliases else []
        titles = jp_titles_from_aliases + [tvshowtitle]
        fflog(f'TVShow search titles: {titles}')
        return titles, year

    @fflog_exc
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if self.ffitem.show_item is None:
            return None
        if source_utils.is_anime(self.ffitem):
            return self.search_ep_or_movie(url[0], season, episode, tvdb)  # url = titles & year
        return None

    @fflog_exc
    def search_ep_or_movie(self, titles, season, episode, tvdb):
        # fflog(f'{titles=} {season=} {episode=} {tvdb=}')
        try:
            if season is not None and episode is not None:
                odcinek = absoluteNumber(tvdb, episode, season)
                # fflog(f'{odcinek=}  (TVDb)')
                if odcinek is None:
                    # fflog(f'nie udało się ustalić bezwzględnego numeru odcinka dla podanych  {season=}  {episode=}  {tvdb=}')
                    return
            else:
                odcinek = 1
            titles = list(filter(None, titles))
            titles = [t.lower() for t in titles]
            titles = list(dict.fromkeys(titles))
            # fflog(f'{titles=}')
            for title in titles:
                if not title:
                    continue
                control.sleep(200)
                # Normalize unicode characters (remove diacritics like ū, û)
                title_normalized = unicodedata.normalize('NFD', title)
                title_normalized = ''.join(c for c in title_normalized if unicodedata.category(c) != 'Mn')
                title_normalized = title_normalized.replace("shippuden", "shippuuden") # common misspelling
                title = quote_plus(title_normalized)
                # fflog(f'Title to search {title=}')
                r = self.session.get(self.search_link % title, headers=self.headers)
                if not r:
                    # fflog(f'błąd {r=}')
                    control.sleep(200)
                    continue
                else:
                    r = r.text
                result = client.parseDOM(r, "div", attrs={"class": "description pull-right"}) # list of results
                linki = client.parseDOM(result, "a", ret="href")
                nazwy = client.parseDOM(result, "a")
                for row in zip(linki, nazwy):
                    # fflog(f'{row=}')
                    try:
                        tytul = re.findall("""<mark>(.*)</mark>""", row[1])[0]
                    except Exception:
                        continue
                    tytul = cleantitle.normalize(cleantitle.getsearch(tytul)).replace("  ", " ")
                    words = tytul.split(" ")
                    # fflog(f'{tytul=} {words=}')
                    if self.contains_all_words(title, words):
                        # fflog(f'pasuje {tytul=}')
                        link = (self.base_link + row[0].replace("odcinki", "odcinek").replace("/anime/", "/odcinek/") + "/" + str(odcinek))
                        if season is None:
                            link = [link]
                        return link
            # fflog(f'nic nie znaleziono (pasującego)')
        except Exception:
            fflog_exc()
            return

    @fflog_exc
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if not url:
            return sources
        rodzaj = "serial"
        try:
            # fflog(f'{url=}')
            if isinstance(url, list):
                url = url[0]
                rodzaj = "film"

            # Store cookies from this session for later use in resolve
            content = self.session.get(url, headers=self.headers)
            if not content:
                # fflog(f'błąd {content=}')
                return
            else:
                # Save cookies for resolve method
                self.cookies = content.cookies
                content = content.text

            # Extract host names and data attributes from table rows
            host_data_pairs = []

            # Find table rows with host info - data-XXX can be data-sok, data-pdf, data-uct, etc.
            # Also extract language info from <span class="sprites XX lang">
            table_pattern = (r'<tr[^>]*>.*?<td>([^<]+)</td>.*?<td[^>]*>.*?</td>.*?<td[^>]*>.*?<span class="sprites ([A-Z]{2}) lang">.*?</td>'
                            r'.*?<td[^>]*>.*?data-[a-zA-Z]+="([0-9][^"]*)".*?</td>.*?</tr>')
            matches = re.findall(table_pattern, content, re.DOTALL)

            for host_name, lang_code, data_value in matches:
                host_name = host_name.strip()
                # Clean up host names - remove dots and other problematic characters
                if host_name.startswith('.'):
                    host_name = host_name[1:]  # Remove leading dot (e.g., ".netu" -> "netu")

                if host_name and data_value:
                    host_data_pairs.append((host_name, data_value, lang_code.lower()))

            # fflog(f'Found {len(host_data_pairs)} host-data pairs: {[pair[0] for pair in host_data_pairs]}')

            for index, (host_name, r, language) in enumerate(host_data_pairs):
                try:
                    filename = url.partition("animezone.pl/odcinek/")[-1]
                    if rodzaj == "film":
                        filename = filename.replace("/1", "", 1)

                    # Create placeholder URL with session info - will be resolved in resolve()
                    # Include base session info in placeholder to maintain state
                    placeholder_url = f"{url}#{r}#{host_name}#{language}#{index}"

                    sources.append(
                        {
                         "source": host_name.upper(),
                         "quality": "720p",
                         "language": language,
                         "url": placeholder_url,
                         "info": "",
                         "filename": "",  # filename,
                         "direct": False,
                         "debridonly": False,
                         "premium": False,
                        }
                    )
                except Exception:
                    fflog_exc()
                    continue

            fflog(f'przekazano źródeł: {len(sources)}')
            fflog(f'Znaleziono źródeł: {len(sources)}')
            return sources
        except Exception:
            fflog_exc()
            return sources

    @fflog_exc
    def resolve(self, url):
        try:
            # Check if it's our placeholder URL format
            if "#" in url:
                # Split URL, data, host name, language and index
                base_url, r, host_name, language, index = url.split("#")
                index = int(index)
                # fflog(f'Resolving: {base_url} with data: {r} for host: {host_name}, language: {language}, index: {index}')

                # Get fresh page content using the same session and cookies as sources()
                resolve_headers = self.headers.copy()
                if self.cookies:
                    # Use cookies from sources() method
                    cookie_str = "; ".join([f"{k}={v}" for k, v in self.cookies.items()])
                    resolve_headers["Cookie"] = cookie_str

                content = self.session.get(base_url, headers=resolve_headers)
                if not content:
                    # fflog(f'Failed to get fresh page content')
                    return None

                content = content.text

                # Extract fresh host data pairs from the page
                table_pattern = (r'<tr[^>]*>.*?<td>([^<]+)</td>.*?<td[^>]*>.*?</td>.*?<td[^>]*>.*?<span class="sprites ([A-Z]{2}) lang">.*?</td>'
                                r'.*?<td[^>]*>.*?data-[a-zA-Z]+="([0-9][^"]*)".*?</td>.*?</tr>')
                matches = re.findall(table_pattern, content, re.DOTALL)

                # Match by position/host/language combination
                fresh_r = None

                # First try exact index match
                if index < len(matches):
                    page_host_name, lang_code, data_value = matches[index]
                    page_host_name = page_host_name.strip()
                    if page_host_name.startswith('.'):
                        page_host_name = page_host_name[1:]

                    # Check if host and language match at this index
                    if page_host_name.lower() == host_name.lower() and lang_code.lower() == language.lower():
                        fresh_r = data_value
                        # fflog(f'Found exact index match {index}: {page_host_name} ({lang_code}) -> {fresh_r}')
                    # else:
                        # fflog(f'Index {index} mismatch: expected {host_name}({language}), got {page_host_name}({lang_code})')

                # If index doesn't match, search by host+language
                if not fresh_r:
                    for i, (page_host_name, lang_code, data_value) in enumerate(matches):
                        page_host_name = page_host_name.strip()
                        if page_host_name.startswith('.'):
                            page_host_name = page_host_name[1:]

                        if page_host_name.lower() == host_name.lower() and lang_code.lower() == language.lower():
                            fresh_r = data_value
                            # fflog(f'Found host+lang match at index {i}: {page_host_name} ({lang_code}) -> {fresh_r}')
                            break

                # Use fresh data if found, otherwise keep original
                r = fresh_r or r

                # Use the same POST logic as original working version with maintained session
                verify_headers = {
                    "Accept": "*/*",
                    "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                    "Referer": str(base_url).replace("http://", "https://www."),
                    "Cache-Control": "max-age=0",
                    "Connection": "keep-alive",
                    "Host": "www.animezone.pl",
                    "User-Agent": DEFAULT_UA
                }

                # Add cookies to verify request too
                if self.cookies:
                    cookie_str = "; ".join([f"{k}={v}" for k, v in self.cookies.items()])
                    verify_headers["Cookie"] = cookie_str

                verify = self.session.get("https://www.animezone.pl/images/statistics.gif", headers=verify_headers)
                if not verify:
                    # fflog(f'błąd {verify=}')
                    pass

                post_headers = {
                    "Host": "www.animezone.pl",
                    "User-Agent": DEFAULT_UA,
                    "Accept": "*/*",
                    "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                    "Referer": str(base_url).replace("http://", "https://www."),
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "X-Requested-With": "XMLHttpRequest",
                    "Connection": "keep-alive",
                    "Pragma": "no-cache",
                    "Cache-Control": "no-cache"
                }

                # Add cookies to POST request - this is crucial!
                if self.cookies:
                    cookie_str = "; ".join([f"{k}={v}" for k, v in self.cookies.items()])
                    post_headers["Cookie"] = cookie_str

                data = {"data": r}
                response = self.session.post(base_url, headers=post_headers, data=data)

                if not response:
                    # fflog(f'błąd {response=}')
                    if hasattr(response, 'status_code') and response.status_code == 429:
                        # fflog("Rate limited (429) - adding delay")
                        control.sleep(2000)  # 2 second delay for rate limiting
                    return None
                else:
                    response = response.text

                try:
                    video_links = client.parseDOM(response, "a", ret="href")
                    if video_links:
                        video_link = video_links[0]
                        # fflog(f'Found video link: {video_link}')
                        return video_link
                    else:
                        iframe_links = client.parseDOM(response, "iframe", ret="src")
                        if iframe_links:
                            video_link = iframe_links[0]
                            # fflog(f'Found iframe link: {video_link}')
                            return video_link
                        else:
                            # fflog("No video link found in response")
                            return None
                except Exception:
                    fflog_exc()
                    return None

            # Original resolve logic for non-placeholder URLs
            if "sibnet" not in url:
                url = str(url).replace("//", "/").replace(":/", "://").split("?")[0]
            else:
                # fflog(f'"sibnet" in {url=}')
                pass
            return str(url)

        except Exception:
            fflog_exc()
            return None
