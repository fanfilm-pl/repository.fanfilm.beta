# -*- coding: utf-8 -*-
"""
FanFilm - źródło: flixhq.to
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>


    Flow:
      search flixhq.to → media_id → ajax/episode/sources → embed URL (streameeeeee.site)
      → resolve_megacloud() → isa+ HLS m3u8
"""

import json
import re
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING, ClassVar
from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

from lib.ff import client, cleantitle, control
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.resolve_utils import resolve_megacloud
from lib.ff.log_utils import fflog, fflog_exc
if TYPE_CHECKING:
    from lib.sources import SourceItem


# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    def __init__(self):
        self.domains = ['flixhq.to']
        self.base_link = 'https://flixhq.to'
        self.headers = {'User-Agent': DEFAULT_UA, 'Referer': self.base_link}

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: List[Dict], year: str) -> Optional[str]:
        try:
            return urlencode({'imdb': imdb, 'title': title, 'year': year})
        except Exception:
            fflog_exc()

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str,
               aliases: List[Dict], year: str) -> Optional[str]:
        try:
            tmdb = self.ffitem.show_item.tmdb_id
            return urlencode({'imdb': imdb, 'tmdb': tmdb, 'tvshowtitle': tvshowtitle, 'year': year})
        except Exception:
            fflog_exc()

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str,
                premiered: str, season: str, episode: str) -> Optional[str]:
        try:
            if url is None:
                return
            data = self._qs(url)
            data.update({'title': title, 'premiered': premiered, 'season': season, 'episode': episode})
            return urlencode(data)
        except Exception:
            fflog_exc()

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        result = []
        try:
            if url is None:
                return result

            data = self._qs(url)
            title = data.get('title', '')
            year = data.get('year', '')
            is_tv = 'tvshowtitle' in data

            search_title, year = self._extract_year(title, year)
            clean_title = cleantitle.get(search_title)

            media_id, media_type = self._search(title, clean_title, year, is_tv)
            if not media_id:
                return result

            if is_tv and media_type == 'tv':
                server_ids = self._get_tv_server_ids(
                    media_id, data.get('season', '1'), data.get('episode', '1')
                )
            else:
                server_ids = self._get_movie_server_ids(media_id)

            for server_id, server_name in server_ids:
                entry = self._make_source_entry(server_id, server_name)
                if entry:
                    result.append(entry)

        except Exception:
            fflog_exc()
        fflog(f'sources: {len(result)}')
        return result

    def resolve(self, url: str) -> str:
        try:
            resolved = resolve_megacloud(url)
            if not resolved:
                return url
            final_url, tracks = resolved
            subtitle_urls = [
                t['file'] for t in tracks
                if isinstance(t, dict) and t.get('kind') == 'captions' and t.get('file')
                and not any(x in t.get('label', '').lower() for x in ('northern', 'slovene'))
            ]
            if subtitle_urls:
                try:
                    control.window().setProperty('source.subtitles', json.dumps(subtitle_urls))
                    fflog(f"flixhq resolve: {len(subtitle_urls)} subtitle(s) passed to player")
                except Exception as e:
                    fflog(f"flixhq resolve: subtitles error: {e}")
            return final_url
        except Exception:
            fflog_exc()
            return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _qs(url: str) -> Dict[str, str]:
        return {k: v[0] for k, v in parse_qs(url).items() if v}

    @staticmethod
    def _extract_year(title: str, year: str) -> Tuple[str, str]:
        if not year and title:
            m = re.search(r'\b(19|20)\d{2}\b', title)
            if m:
                year = m.group(0)
                title = re.sub(r'\s{2,}', ' ', (title[:m.start()] + title[m.end():]).strip())
        return title, year

    @staticmethod
    def _parse_search_item(item: str) -> Tuple[Optional[str], Optional[str], str, str]:
        m = re.search(
            r'img[^>]+data-src="[^"]*".*?<a[^>]+href="[^"]*/(tv|movie)/watch-[^"]*-([0-9]+)"[^>]*title="([^"]*)".*?class="fdi-item">([^<]*)</span>',
            item, re.S
        )
        if m:
            return m.group(1), m.group(2), m.group(3), m.group(4)

        lm = re.search(r'<a[^>]+href="[^"]*/(tv|movie)/watch-[^"]*-([0-9]+)"[^>]*title="([^"]*)"', item)
        if lm:
            ym = re.search(r'class="fdi-item">([^<]*)</span>', item)
            return lm.group(1), lm.group(2), lm.group(3), ym.group(1) if ym else ''

        return None, None, '', ''

    @staticmethod
    def _find_episode_id(clean_html: str, episode: str) -> Optional[str]:
        target = int(episode) if str(episode).isdigit() else episode
        items = clean_html.split('class="nav-item"')

        for item in items:
            m = re.search(r'data-id="([0-9]+)"[^>]*title="([^"]*)"', item)
            if not m:
                continue
            num_m = re.search(r'(?:Episode|Ep|E)\s*(\d+)', m.group(2), re.I)
            if num_m and int(num_m.group(1)) == target:
                return m.group(1)
            if str(target) in m.group(2):
                return m.group(1)

        try:
            ep_index = int(episode) - 1
            if 0 <= ep_index < len(items):
                m = re.search(r'data-id="([0-9]+)"', items[ep_index])
                if m:
                    return m.group(1)
        except (ValueError, IndexError):
            pass
        return None

    @staticmethod
    def _parse_vidcloud_servers(clean_html: str) -> List[Tuple[str, str]]:
        server_ids = []
        for item in clean_html.split('class="nav-item"'):
            m = re.search(r'data-id="([0-9]+)"[^>]*title="([^"]*)"', item)
            if m and 'vidcloud' in m.group(2).lower():
                server_ids.append((m.group(1), m.group(2)))
        return server_ids

    def _search(self, title: str, clean_title: str, year: str, is_tv: bool) -> Tuple[Optional[str], Optional[str]]:
        fflog(f'query: {title!r}')
        search_url = urljoin(self.base_link, f"/search/{quote_plus(title.replace(' ', '-'))}")
        html = client.request(search_url, headers=self.headers)
        if not html:
            return None, None

        html = html.replace('\n', '')
        items_raw = html.split('class="flw-item"')[1:]
        fflog(f'search: {len(items_raw)} results')
        media_id = media_type = None

        for item in items_raw:
            item_type, item_id, item_title, item_year = self._parse_search_item(item)
            if not item_id or cleantitle.get(item_title) != clean_title:
                continue

            if year and item_year and year in item_year:
                return item_id, item_type

            if not media_id:
                if not is_tv and item_type == 'movie':
                    return item_id, item_type
                if is_tv and item_type == 'tv' and re.search(r'EP|EPISODE', item_year, re.I):
                    return item_id, item_type
                media_id, media_type = item_id, item_type

        return media_id, media_type

    def _get(self, path: str) -> Optional[str]:
        return client.request(urljoin(self.base_link, path), headers=self.headers)

    def _get_movie_server_ids(self, media_id: str) -> List[Tuple[str, str]]:
        html = self._get(f"/ajax/movie/episodes/{media_id}")
        if not html:
            return []
        server_ids = []
        for href, name in re.findall(r'href="([^"]*)"[^>]*title="([^"]*)"', html):
            if 'vidcloud' not in name.lower():
                continue
            m = re.search(r'-([0-9]+)\.([0-9]+)$', href)
            if m:
                server_ids.append((m.group(2), name))
        return server_ids

    def _get_tv_server_ids(self, media_id: str, season: str, episode: str) -> List[Tuple[str, str]]:
        seasons_html = self._get(f"/ajax/v2/tv/seasons/{media_id}")
        if not seasons_html:
            return []

        season_m = re.search(
            r'href="[^"]*-([0-9]+)">' + re.escape(f'Season {season}') + r'</a>',
            seasons_html
        )
        if not season_m:
            return []

        episodes_html = self._get(f"/ajax/v2/season/episodes/{season_m.group(1)}")
        if not episodes_html:
            return []

        data_id = self._find_episode_id(episodes_html.replace('\n', ''), episode)
        if not data_id:
            return []

        servers_html = self._get(f"/ajax/v2/episode/servers/{data_id}")
        if not servers_html:
            return []

        return self._parse_vidcloud_servers(servers_html.replace('\n', ''))

    def _make_source_entry(self, server_id: str, server_name: str) -> 'Optional[SourceItem]':
        html = self._get(f"/ajax/episode/sources/{server_id}")
        if not html:
            return None
        try:
            embed_link = json.loads(html).get('link', '')
        except json.JSONDecodeError:
            return None
        if not embed_link:
            return None

        quality = '4K' if '4K' in server_name.upper() else ('720p' if '720' in server_name else '1080p')
        return {
            'source': f"flixhq-{server_name.lower().replace(' ', '')}",
            'quality': quality,
            'language': 'en',
            'url': embed_link,
            'info': '',
            'direct': False,
            'debridonly': False,
        }
