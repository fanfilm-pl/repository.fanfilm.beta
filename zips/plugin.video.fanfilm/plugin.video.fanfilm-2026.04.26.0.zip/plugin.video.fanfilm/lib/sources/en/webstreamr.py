# -*- coding: utf-8 -*-
"""
FanFilm - źródło: webstreamr.hayd.uk
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

And if you absolutely must borrow the scraper, remember that it cost us over a month of work...
It would be a good idea to mention this in your version where you are borrowing from,
in accordance with the license.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Dict, List, Optional, ClassVar
from urllib.parse import urlencode, parse_qs

from lib.ff import requests, source_utils

if TYPE_CHECKING:
    from lib.sources import SourceItem
from lib.ff.item import FFItem
from lib.ff.log_utils import fflog, fflog_exc
from lib.ff.source_utils import DEFAULT_UA, append_headers, convert_size, get_host, get_quality
from lib.api import kitsu as kitsu_api


# Public webstreamr instances — add new ones here as they appear
_WEBSTREAMR_INSTANCES = [
    'https://87d6a6ef6b58-webstreamrmbg.baby-beamup.club',
    'https://87d6a6ef6b58-webstreamrmbg-dev.baby-beamup.club',
]
_WEBSTREAMR = _WEBSTREAMR_INSTANCES[0]

_HEADERS = {'User-Agent': DEFAULT_UA, 'Accept': 'application/json'}

_RE_VIDEO = re.compile(r'\.(mkv|mp4|avi|ts|m4v)$', re.IGNORECASE)
_RE_HOSTER = re.compile(r'🔗\s*([^\n\r(]+)')

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en']

    def __init__(self):
        self.domains = ['1corncastle.vercel.app']

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: List[Dict], year: str) -> Optional[str]:
        return urlencode({'imdb': imdb, 'type': 'movie'}) if imdb else None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: List[Dict], year: str) -> Optional[str]:
        return urlencode({'imdb': imdb, 'type': 'tv'}) if imdb else None

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        try:
            if url is None:
                return None
            data = {k: v[0] for k, v in parse_qs(url).items()}

            if source_utils.is_anime(self.ffitem):
                tmdb = self.ffitem.show_item.tmdb_id if self.ffitem.show_item else None
                cours = kitsu_api.get_cour_structure(tmdb) if tmdb else None
                if cours:
                    cour, local_ep = kitsu_api.resolve_cour(cours, self.ffitem)
                    if cour and local_ep:
                        cour_season = cours.index(cour) + 1
                        fflog(
                            f"corncastle: anime {season}x{episode} → kitsu cour={cour['title']} (season={cour_season}) local_ep={local_ep}")
                        season = str(cour_season)
                        episode = str(local_ep)
                    else:
                        fflog(f'corncastle: anime {season}x{episode} – kitsu: no cour, using as-is')
                else:
                    fflog(f'corncastle: anime {season}x{episode} – no kitsu (tmdb={tmdb}), using as-is')

            data.update({'season': season, 'episode': episode})
            return urlencode(data)
        except Exception:
            fflog_exc()
            return None

    def sources(self, url: Optional[str], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        result = []
        try:
            if not url:
                return result

            data = {k: v[0] for k, v in parse_qs(url).items()}
            imdb = data.get('imdb', '')
            if not imdb:
                return result

            if data.get('type') == 'tv':
                path = f"stream/series/{imdb}:{data.get('season', '1')}:{data.get('episode', '1')}.json"
            else:
                path = f"stream/movie/{imdb}.json"

            fflog(f'query: {imdb!r}')
            streams = []
            for instance in _WEBSTREAMR_INSTANCES:
                api_url = f"{instance}/{path}"
                try:
                    resp = requests.get(api_url, headers=_HEADERS, timeout=15)
                    if resp.status_code != 200:
                        fflog(f"HTTP {resp.status_code}, trying next")
                        continue
                    streams = resp.json().get('streams', [])
                    fflog(f'search: {len(streams)} results')
                    break
                except Exception:
                    fflog(f"instance {instance} failed, trying next")

            result = [src for s in streams if (src := self._stream_to_source(s))]

        except Exception:
            fflog_exc()

        fflog(f'sources: {len(result)}')
        return result

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_language(binge_group: str) -> tuple[str, str]:
        # bingeGroup format: "webstreamr-{source}-{hoster}-{lang1}_{lang2}_..."
        # languages are after the last '-', separated by '_'
        try:
            langs = binge_group.rsplit('-', 1)[-1].split('_')
            if 'pl' in langs:
                return 'pl', ''
            if 'ja' in langs:
                return 'en', 'JP'
        except Exception:
            pass
        return 'en', ''

    @staticmethod
    def _parse_hoster(info_line: str, url: str) -> str:
        if 'pixeldrain' in url.lower():
            return 'PixelDrain'
        if '.m3u8' in url:
            return 'VixSrc'
        m = _RE_HOSTER.search(info_line)
        if m:
            return m.group(1).strip().split(' from ')[0].strip()
        return get_host(url)

    @staticmethod
    def _stream_to_source(stream: dict) -> dict | None:
        url = stream.get('url', '')
        if not url:
            return None

        # WebStreamrMBG bug: extract URLs have truncated hostname without .baby-beamup.club
        _host = _WEBSTREAMR.split('://', 1)[1]
        _short = _host.split('.', 1)[0]
        if f'://{_short}/' in url and f'://{_host}/' not in url:
            url = url.replace(f'://{_short}/', f'://{_host}/', 1)

        name = stream.get('name', '')
        title = stream.get('title', '')
        hints = stream.get('behaviorHints', {})

        # title = "Filename.mkv\n💾 14.69 GB 🔗 HubCloud (FSL) from 4KHDHub"
        filename_part, _, info_line = title.partition('\n')
        binge_group = hints.get('bingeGroup', '')
        language, lang_info = source._parse_language(binge_group)
        if language != 'pl':
            filename_part = re.sub(r'\.(?:Multi|MULTI|multi)\.', '.', filename_part)
        filename = filename_part.strip() if _RE_VIDEO.search(filename_part.strip()) else ''

        referer = hints.get('proxyHeaders', {}).get('request', {}).get('Referer')

        # Only append headers for direct file URLs, not for webstreamr extractor URLs
        # (extractor URLs use referer server-side, not in the player)
        is_direct = '/extract/' not in url
        play_url = url + append_headers({'User-Agent': DEFAULT_UA, 'Referer': referer}) \
            if (referer and is_direct) else url

        video_size = hints.get('videoSize')

        return {
            'source': source._parse_hoster(info_line, url),
            'url': play_url,
            'quality': get_quality(name),
            'language': language,
            'info': lang_info,
            'size': convert_size(video_size),
            'filename': filename,
            'direct': True,
            'debridonly': False,
            'premium': False,
        }
