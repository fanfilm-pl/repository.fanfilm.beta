# -*- coding: utf-8 -*-
"""
FanFilm – source: filman.cc
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

from __future__ import annotations
import base64
import codecs
import re
import time
import json
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from lib.sources import SourceItem, ClassVar
from urllib.parse import quote_plus, urlparse
from html import unescape

from lib.ff import requests

from lib.sources import single_call
from lib.ff import source_utils, cleantitle, utils, cache, control
from lib.ff.source_utils import ShowData, show_data_asdict
from lib.ff.client import parseDOM
from lib.ff.settings import settings
from lib.ff.log_utils import fflog, fflog_exc
from lib.ff.item import FFItem

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    has_sort_order: bool = True
    has_color_identify2: bool = True
    use_premium_color: bool = True
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    _LAST_SEARCH_TIME: float = 0

    EMBED_DOMAIN = 'embed.tmp-url.pro'

    HOSTING_MAP = {
        'bigdisk.stream': 'bigdisk',
    }

    # Regex patterns
    RE_HREF = re.compile(r'href="(.*?)"')
    RE_TITLE_ALT = re.compile(r' (?:title|alt)="(.*?)"')
    RE_IFRAME = re.compile(r'data-iframe="([^"]+)"')
    RE_HREF_MP4 = re.compile(r'href="([^"]+)"[^>]*data-mp4="true"')
    RE_TD = re.compile(r'<td[^>]*>(.*?)</td>', re.DOTALL)
    RE_SEASON_EPISODE = re.compile(r'<span>Sezon (\d+)</span>.*?<ul>(.*?)</ul>', re.DOTALL)
    RE_EPISODE_LINK = re.compile(r'<a href="(.*?)">\s*\[s(\d+)e(\d+)\]\s*(.*?)\s*</a>', re.DOTALL)
    RE_YEAR = re.compile(r'<div class="film_year">(\d{4})</div>')

    # Time units
    TIME_UNITS = {
        'bez': 1,
        'minutę': 60,
        'minuty': 60,
        'minut': 60,
        'godzinę': 3600,
        'godziny': 3600,
        'godzin': 3600,
        'dzień': 86400,
        'dni': 86400,
        'tydzień': 604800,
        'tygodnie': 604800,
        'tygodni': 604800,
        'miesiąc': 2592000,
        'miesiące': 2592000,
        'miesięcy': 2592000,
        'rok': 31536000,
        'lata': 31536000,
        'lat': 31536000,
    }

    @single_call
    def init(self):
        self.base_link = 'https://filman.cc'
        self.login_link = self.base_link + '/logowanie'
        self.search_link = self.base_link + '/search?phrase={title}'
        self.username = settings.getString('filman.username')
        self.password = settings.getString('filman.password')
        self.USER_AGENT = 'FilmanKodi/1.0 (compatible; Firefox/146.0)'
        self.HEADERS = {'Host': 'filman.cc', 'User-Agent': self.USER_AGENT}
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self._purge_old_episode_cache()

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: List[Dict], year: str, **kwargs) -> Optional[Tuple]:
        self.init()
        fflog(f"searching: {title!r} ({year}) imdb={imdb!r}")
        logged_in = self.is_logged_in()
        fflog(f"logged in: {logged_in}")
        if not logged_in:
            return None
        alias_titles = source_utils.build_alias_list(title, localtitle, aliases, year)

        for search_title in source_utils.search_queries(title, localtitle):
            now = time.time()
            elapsed = now - source._LAST_SEARCH_TIME
            if 0 < elapsed < 2.0:
                time.sleep(2.0 - elapsed)
            source._LAST_SEARCH_TIME = time.time()

            fflog(f"query: {search_title!r}")
            page = self.session.get(self.search_link.format(title=quote_plus(search_title)), verify=False).text
            result = self._match_results(page, search_title, alias_titles, year, 'movie')
            fflog(f"match: {result}")
            if result:
                return (result[0], result[1], str(imdb) if imdb else '')
        return None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: List[Dict], year: str) -> Dict:
        self.init()
        return show_data_asdict(ShowData(tvshowtitle, localtvshowtitle, aliases, year))

    def episode(self, url: Dict, imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[Tuple]:
        self.init()
        if not self.is_logged_in():
            return None
        tmdb = self.ffitem.show_item.tmdb_id
        data = ShowData(**url)
        episode_number_str = source_utils.format_episode_key(season, episode)
        absolute_episode_number = self.ffitem.absolute_episode_number()

        # 1. Try episode cache by tmdb — skip search entirely if hit
        if tmdb:
            cache_id = f"filman_eps_{tmdb}"
            cached = cache.cache_get(cache_id, control.providercacheFile)
            if cached and 'date' in cached and cache._is_cache_valid(int(cached['date']), 24):
                fflog(f"cache hit: filman_eps_{tmdb}")
                episodes = json.loads(cached['value'])
                result = self._find_in_episodes(episodes, data.title,
                                                episode_number_str, absolute_episode_number or 0)
                if result:
                    return (result[0], result[1], str(imdb) if imdb else '', int(season), int(episode))
                fflog(f"s{season}e{episode}: not found in cache — falling through to search")
            else:
                fflog(f"cache miss: filman_eps_{tmdb}")

        # 2. Search for the show, fetch episodes, cache by tmdb
        alias_titles = source_utils.build_alias_list(
            data.title, data.local_title, data.aliases, data.year)

        for search_title in source_utils.search_queries(data.title, data.local_title):
            now = time.time()
            elapsed = now - source._LAST_SEARCH_TIME
            if 0 < elapsed < 2.0:
                time.sleep(2.0 - elapsed)
            source._LAST_SEARCH_TIME = time.time()

            fflog(f"query: {search_title!r} ({data.year})")
            page = self.session.get(self.search_link.format(title=quote_plus(search_title)), verify=False).text
            result = self._match_results(page, search_title, alias_titles, data.year, 'tvshow')
            fflog(f"match: {result}")

            if result:
                show_match = {'href': result[0], 'title': result[1]}
                episode_match = self._extract_episode_url(
                    show_match, episode_number_str, absolute_episode_number or 0, tmdb)
                fflog(f"s{season}e{episode}: {'found' if episode_match else 'not found'}")
                if episode_match:
                    return (episode_match[0], episode_match[1], str(imdb) if imdb else '', int(season), int(episode))
                return None
        fflog(f"no match: {data.title!r}")
        return None

    def sources(self, url: Optional[Tuple], hostDict: List[str], hostprDict: List[str]) -> List[SourceItem]:
        self.init()
        if not url or not self.is_logged_in():
            return []
        try:
            imdb = url[2] if isinstance(url, tuple) and len(url) > 2 else None
            season = url[3] if isinstance(url, tuple) and len(url) > 3 else None
            episode_num = url[4] if isinstance(url, tuple) and len(url) > 4 else None
            url = url[0] if isinstance(url, tuple) else url

            # Premium path: bigdisk Stremio API (token present = premium user)
            token = self._get_bigdisk_token()
            if token:
                bigdisk_sources = self._sources_from_bigdisk_api(imdb, season, episode_num, token)
                if bigdisk_sources:
                    return bigdisk_sources
                fflog('bigdisk: 0 sources — falling back to HTML scraping')

            # Non-premium path: scrape filman.cc, skip premium-only links
            episode_path = urlparse(url).path
            fflog(f"GET {url}")
            page_html = self.session.get(url, verify=False).text
            table = parseDOM(page_html, 'table', attrs={'id': 'links'})
            if not table:
                fflog(f"no #links table at {url}")
                return []

            rows = table[0].split('<tr')[1:]
            video_info_list = []
            for row_html in rows:
                video_info = self._extract_video_info(row_html, page_html)
                if video_info and not video_info.get('is_premium'):
                    video_info_list.append(video_info)

            fflog(f"sources: {len(video_info_list)}")
            video_info_list.sort(key=lambda x: self._parse_time_string(x.get('ago', '')))

            return [
                {
                    'source': v['host'],
                    'url': v['url'],
                    'quality': v['quality'],
                    'language': v['lang'],
                    'info': v['sound'].strip(),
                    'filename': f"{v['ago']} | {episode_path}",
                    'direct': False,
                    'debridonly': False,
                    'premium': False,
                }
                for v in video_info_list
            ]
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url: str) -> Optional[str]:
        # kod poniższy powstał w uzgodnieniu z filman.cc - proszę nie zapożyczać bez kontaktu z team fanfilm.
        self.init()
        if not url or self.EMBED_DOMAIN not in url:
            return url
        try:
            resp = requests.get(url, verify=False, headers={
                'User-Agent': self.USER_AGENT,
                'Referer': self.base_link + '/',
            })
            e_match = re.search(r"var _e = '([^']+)'", resp.text)
            if not e_match:
                fflog(f'filman resolve: no _e in embed page (len={len(resp.text)})')
                return url
            hoster_url = codecs.encode(base64.b64decode(e_match.group(1)).decode(), 'rot_13')
            fflog(f'filman resolve: {hoster_url[:80]}')
            return hoster_url
        except Exception:
            fflog_exc()
            return url

    # ── helpers ────────────────────────────────────────────────────────────

    def login(self) -> bool:
        if not self.username or not self.password:
            fflog('login: no credentials')
            return False
        try:
            login_data = {
                'login': self.username,
                'password': self.password,
                'remember': 'on',
                'submit': '',
            }
            response = self.session.post(self.login_link, data=login_data, verify=False)
            fflog(
                f"login: POST status={response.status_code} url={response.url} guest_false={'yes' if 'guest: false' in response.text else 'no'}")
            if 'guest: false' in response.text:
                fflog('login: ok')
                return True
            fflog(f"login: failed — response snippet: {response.text[:300]!r}")
        except Exception:
            fflog_exc()
        return False

    def is_logged_in(self) -> bool:
        if getattr(self, '_logged_in', False):
            return True
        self.init()
        try:
            response = self.session.get(self.base_link, verify=False)
            if 'guest: false' in response.text:
                self._logged_in = True
                return True
        except Exception:
            pass
        if self.login():
            self._logged_in = True
            return True
        return False

    def _parse_search_results(self, page_content: str, year: int, media_type: str) -> List[Dict]:
        candidates = []
        blocks = page_content.split('<div class="poster">')[1:]

        for block in blocks:
            try:
                year_match = self.RE_YEAR.search(block)
                if not year_match or abs(int(year_match.group(1)) - int(year)) > 1:
                    continue

                href_match = self.RE_HREF.search(block)
                if not href_match:
                    continue

                href = href_match.group(1)
                if href.startswith('/'):
                    href = self.base_link + href
                if (media_type == 'movie' and '/m/' not in href) or (media_type == 'tvshow' and '/s/' not in href):
                    continue

                title_match = self.RE_TITLE_ALT.search(block)
                if not title_match:
                    continue

                full_title = unescape(utils.decode_title_from_latin1(title_match.group(1)))
                title_parts_clean = [cleantitle.get_simple(p.strip()) for p in full_title.split('/') if p.strip()]

                candidates.append({
                    'href': href,
                    'full_title': full_title,
                    'title_parts_clean': title_parts_clean
                })
            except Exception:
                continue
        return candidates

    def _match_results(self, page_content: str, primary_title: str, aliases: List[str], year: int, media_type: str) -> Optional[Tuple[str, str]]:
        candidates = self._parse_search_results(page_content, year, media_type)
        search_clean = cleantitle.get_simple(primary_title)
        alias_cleans = {cleantitle.get_simple(a) for a in aliases if a and cleantitle.get_simple(a)}

        for c in candidates:
            for part in c['title_parts_clean']:
                if part == search_clean:
                    return (c['href'], c['full_title'])

        for c in candidates:
            for part in c['title_parts_clean']:
                if part in alias_cleans:
                    return (c['href'], c['full_title'])

        for c in candidates:
            for part in c['title_parts_clean']:
                if source_utils._levenshtein(part, search_clean) <= 3:
                    return (c['href'], c['full_title'])

        return None

    def _extract_episode_url(self, show_match: Dict, episode_number_str: str, absolute_episode_number: int = 0, tmdb=None) -> Optional[Tuple[str, str]]:
        try:
            page_html = self.session.get(show_match['href'], verify=False).text
            season_blocks = self.RE_SEASON_EPISODE.findall(page_html)
            fflog(f"season blocks: {len(season_blocks)}, looking for {episode_number_str!r}")
            if not season_blocks:
                snippet = page_html[page_html.find('Sezon')-50:page_html.find('Sezon')+ \
                                                   200] if 'Sezon' in page_html else page_html[:300]
                fflog(f"no season blocks, snippet={snippet!r}")
            episodes = []
            for _, episodes_html in season_blocks:
                for ep_url, season_num, episode_num, _ in self.RE_EPISODE_LINK.findall(episodes_html):
                    if ep_url.startswith('/'):
                        ep_url = self.base_link + ep_url
                    episodes.append((source_utils.format_episode_key(season_num, episode_num), ep_url))

            fflog(f"results: {len(episodes)}")
            if not episodes:
                return None

            if tmdb:
                fflog(f"cache write: filman_eps_{tmdb} ({len(episodes)} episodes)")
                cache.cache_insert(f"filman_eps_{tmdb}", json.dumps(episodes), control.providercacheFile)

            return self._find_in_episodes(episodes, show_match['title'], episode_number_str, absolute_episode_number)

        except Exception:
            fflog_exc()
        return None

    def _find_in_episodes(self, episodes: List, show_title: str, episode_number_str: str, absolute_episode_number: int) -> Optional[Tuple[str, str]]:
        episode_map = dict(episodes)

        # Exact match (show uses proper season/episode keys on filman)
        if episode_number_str in episode_map:
            return (episode_map[episode_number_str], f"{show_title} {episode_number_str}")

        if source_utils.is_anime(self.ffitem):
            # Filman stores anime as a single season (s01eNNN). TMDB assigns
            # arbitrary season numbers. absolute_episode_number() is reliable
            # when continuous_episode_number=True, but position-based indexing
            # on a lexicographically-sorted key list is broken for episode
            # numbers >99 (e.g. s01e999 sorts after s01e1155). Use dict lookup.
            if absolute_episode_number > 0:
                s01_key = source_utils.format_episode_key(1, absolute_episode_number)
                if s01_key in episode_map:
                    return (episode_map[s01_key], f"{show_title} {s01_key}")
            # Not found — cache is stale; return None so caller falls through to re-fetch
            return None

        abs_key = source_utils.format_episode_key(1, absolute_episode_number)
        if absolute_episode_number > 0 and abs_key in episode_map:
            return (episode_map[abs_key], f"{show_title} {abs_key}")

        return None

    def _get_bigdisk_token(self) -> str:
        """Fetch bigdisk Stremio token from filman.cc/android-apk (not cached)."""
        try:
            page = self.session.get(f"{self.base_link}/android-apk", verify=False).text
            match = re.search(r'stremio://stremio\.bigdisk\.stream/([a-f0-9]+)/', page)
            if match:
                return match.group(1)
        except Exception:
            fflog_exc()
        return ''

    def _sources_from_bigdisk_api(self, imdb: str, season=None, episode_num=None, token: str = '') -> List[Dict]:
        """Fetch premium sources via bigdisk Stremio API (requires token)."""
        fflog(f"bigdisk: token={'yes' if token else 'no'} imdb={imdb!r} season={season} ep={episode_num}")
        if not token or not imdb:
            return []
        if season is not None and episode_num is not None:
            endpoint = f"https://stremio.bigdisk.stream/{token}/stream/series/{imdb}:{season}:{episode_num}.json"
        else:
            endpoint = f"https://stremio.bigdisk.stream/{token}/stream/movie/{imdb}.json"
        try:
            # Use a clean session — filman session has Host: filman.cc header which breaks requests to external hosts
            plain = requests.Session()
            plain.headers.update({'User-Agent': self.USER_AGENT})
            resp = plain.get(endpoint, verify=False, timeout=15)
            data = resp.json()
            sources = []
            for stream in data.get('streams', []):
                direct_url = stream.get('url')
                external_url = stream.get('externalUrl')
                stream_url = direct_url or external_url
                if not stream_url:
                    continue
                is_premium = bool(direct_url)
                title = stream.get('title', '')
                name = stream.get('name', '')
                quality_match = re.search(r'(\d+p)', title)
                quality = source_utils.check_sd_url(quality_match.group(1) if quality_match else '')
                audio_type = title.split(' · ')[0].strip()
                if audio_type in ('Napisy', 'ENG'):
                    info, language = audio_type, 'en'
                elif audio_type == 'Napisy Tłum.':
                    info, language = 'Napisy tłumaczone', 'pl'
                else:
                    info, language = audio_type or 'Lektor', 'pl'
                if is_premium:
                    info += ' | Premium'
                host = self._normalize_hosting_name(urlparse(stream_url).hostname or name)
                sources.append({
                    'source': host,
                    'url': stream_url,
                    'quality': quality,
                    'language': language,
                    'info': info,
                    'filename': '',
                    'direct': is_premium,
                    'debridonly': False,
                    'premium': is_premium,
                })
            fflog(f"bigdisk: sources: {len(sources)} ({sum(1 for s in sources if s['premium'])} premium)")
            return sources
        except Exception:
            fflog_exc()
            return []

    def _purge_old_episode_cache(self):
        try:
            cutoff = int(time.time()) - 86400
            cursor = cache._get_connection_cursor_providers()
            cursor.execute("DELETE FROM cache WHERE key LIKE 'filman_eps_%' AND date < ?", (cutoff,))
            deleted = cursor.rowcount
            cursor.connection.commit()
            if deleted:
                fflog(f"cache: purged {deleted} expired filman_eps_* entries")
        except Exception:
            fflog_exc()

    def _process_sound(self, sound_string: str) -> Tuple[str, str]:
        sound_string = sound_string.replace('Napisy_Tansl', 'napisy').replace('_', ' ')
        language_code = 'en' if 'ENG' in sound_string else 'pl'
        return sound_string.replace('PL', '').replace('ENG', '').strip() or ' ', language_code

    def _parse_time_string(self, time_string: str) -> float:
        time_match = re.match(r'(?:\b(\d+)\b\s+)?(\w+)', time_string)
        if not time_match:
            return float('inf')
        numeric_value, time_unit = time_match.groups()
        multiplier = self.TIME_UNITS.get(time_unit)
        return (int(numeric_value) if numeric_value else 1) * multiplier if multiplier else float('inf')

    def _normalize_hosting_name(self, domain: str) -> str:
        for suffix, name in self.HOSTING_MAP.items():
            if suffix in domain:
                return name
        parts = domain.rsplit('.', 2)
        if len(parts) >= 3:
            return f"{parts[-2]}.{parts[-1]}"
        return domain

    def _extract_video_info(self, row_html: str, page_content: str) -> Dict:
        iframe_match = self.RE_IFRAME.findall(row_html)
        mp4_links = self.RE_HREF_MP4.findall(row_html)
        td_cells = self.RE_TD.findall(row_html)
        if len(td_cells) < 3:
            return {}

        is_premium, video_url = False, ''
        if mp4_links:
            video_url = base64.b64decode(mp4_links[0]).decode('utf-8').replace('\\/', '/')
            if not any(video_url.lower().endswith(ext) for ext in ('.m3u8', '.mp4', '.ts')):
                token_match = re.search(r"attr\('href'\)\)\s*\+\s*'([^']+)'", page_content)
                video_url += token_match.group(1) if token_match else ''
            video_url += f"|referer={self.base_link}&user-agent=Mozilla"
            is_premium = True
        elif iframe_match:
            decoded_iframe = base64.b64decode(iframe_match[0]).decode('utf-8').replace('\\/', '/')
            src_match = re.findall(r"src['\"]:['\"](.+?)['\"]", decoded_iframe)
            video_url = src_match[0] if src_match else decoded_iframe

        if not video_url:
            return {}

        sound_info, language_code = self._process_sound(td_cells[1].strip())
        if is_premium:
            host_name = urlparse(video_url).hostname or ''
        else:
            host_m = re.search(r'alt="(.*?)"', td_cells[0])
            host_name = host_m.group(1) if host_m else ''
        ago_m = re.search(r'dodane\s+(.*?temu)', td_cells[0], re.S)

        return {
            'host': self._normalize_hosting_name(host_name or ''),
            'url': video_url,
            'is_premium': is_premium,
            'quality': source_utils.check_sd_url(td_cells[2].strip()),
            'sound': sound_info,
            'lang': language_code,
            'ago': ago_m.group(1).strip() if ago_m else ''
        }
