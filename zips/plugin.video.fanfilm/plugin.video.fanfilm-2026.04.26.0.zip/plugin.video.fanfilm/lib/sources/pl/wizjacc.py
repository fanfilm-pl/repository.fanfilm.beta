# -*- coding: utf-8 -*-
"""
FanFilm - źródło: wizja.cc
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>
"""

import re
from urllib.parse import quote_plus
from html import unescape
from base64 import b64decode
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING, ClassVar, ClassVar, ClassVar

from lib.ff import requests
from lib.ff import cleantitle
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.log_utils import fflog, fflog_exc

if TYPE_CHECKING:
    from lib.sources import SourceItem

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['pl']

    def __init__(self):
        self.domains = ['wizja.cc']
        self.base_link = 'https://wizja.cc'
        self.search_link = self.base_link + '/search_elastic?s={title}'
        self.session = requests.Session()
        self.session.headers.update(
            {
                'User-Agent': DEFAULT_UA,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            }
        )

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: List[Dict], year: str, **kwargs) -> Optional[Tuple[str, str]]:
        titles = [localtitle, title] if localtitle else [title]
        return self._search_movie(titles, year)

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtitle: str, aliases: List[Dict], year: str, **kwargs) -> Optional[Tuple[str, str]]:
        titles = [localtitle, tvshowtitle] if localtitle else [tvshowtitle]
        return self._search_tvshow(titles, year)

    def episode(self, url: Optional[Tuple[str, str]], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str, **kwargs) -> Optional[Tuple[str, str]]:
        try:
            if not url:
                return None

            if isinstance(url, tuple):
                show_page_url, show_title = url
            else:
                show_page_url = url
                show_title = title

            response = self.session.get(show_page_url, verify=False, timeout=30)
            response.raise_for_status()
            html = response.text

            show_slug_match = re.search(r'/shows/details/([^/]+)', show_page_url)
            if not show_slug_match:
                return None
            show_slug = show_slug_match.group(1)

            series_id_match = re.search(r'/details/[^/]+?/(\d+)', show_page_url)
            if not series_id_match:
                return None
            series_id = series_id_match.group(1)

            season_id_match = re.search(rf'<option value="(\d+)">Sezon\s*{season}</option>', html)
            if not season_id_match:
                fflog(f"season ID not found for season {season}")
                return None
            season_id = season_id_match.group(1)

            ajax_url = f"{self.base_link}/shows/{series_id}/seasons/{season_id}/episodes"

            ajax_response = self.session.get(
                ajax_url, headers={'x-requested-with': 'XMLHttpRequest'}, verify=False, timeout=30)
            ajax_response.raise_for_status()
            episodes_data = ajax_response.json()

            if not episodes_data.get('episodes'):
                fflog(f"no episodes in AJAX response for season {season_id}")
                return None

            for item in episodes_data['episodes']:
                ep_slug = item.get('video_slug', '')

                ep_num_match = re.search(r'(\d+)', ep_slug)
                if not ep_num_match:
                    continue

                ep_num = ep_num_match.group(1)

                if int(ep_num) == int(episode):
                    ep_title = item.get('video_title', '')
                    ep_id = item.get('id', '')

                    if not all([ep_title, ep_slug, ep_id]):
                        continue

                    episode_url = f"{self.base_link}/shows/{show_slug}/{ep_slug}/{ep_id}"
                    fflog(f"episode URL constructed: {episode_url}")

                    season_int = int(season)
                    episode_int = int(episode)
                    return (episode_url, f"{show_title} S{season_int:02d}E{episode_int:02d} - {ep_title}")

        except Exception:
            fflog('unexpected error in episode()')
            fflog_exc()

        return None

    def sources(self, url: Optional[Tuple[str, str]], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        sources = []
        try:
            if not url:
                return sources
            if isinstance(url, tuple):
                url, title = url
            else:
                title = ''

            response = self.session.get(url, verify=False, timeout=30)
            response.raise_for_status()
            html = response.text

            # Extract language dynamically
            language_code = 'en'  # Default to English
            lang_match = re.search(r'<li><a href="[^"]+lang_id=\d+" title="([^"]+)">([^<]+)</a></li>', html)
            if lang_match:
                lang_text = lang_match.group(2)  # e.g., "Polski"
                if lang_text.lower() == 'polski':
                    language_code = 'pl'
                # elif lang_text.lower() == 'english': # if other languages appear
                #     language_code = 'en'
                # Add more mappings if needed, 'en' is already default

            matches = re.findall(r'source:\s*atob\("([^"]+)"\)', html)
            if not matches:
                return sources
            encoded_url = matches[0]
            video_url = b64decode(encoded_url).decode('utf-8')
            sources.append(
                {
                    'source': 'wizja',
                    'quality': '1080p',
                    'language': language_code,
                    'info': '',
                    'url': f'ia://{video_url}',
                    'filename': title,
                    'direct': False,
                    'debridonly': False,
                }
            )
        except Exception:
            fflog_exc()
        fflog(f'sources: {len(sources)}')
        return sources

    def resolve(self, url: str) -> Optional[str]:
        return url

    # ── helpers ────────────────────────────────────────────────────────────

    def _search_movie(self, titles, year):
        try:
            for title in titles:
                if not title:
                    continue
                fflog(f'query: {title!r}')
                url = self.search_link.format(title=quote_plus(title))
                try:
                    response = self.session.get(url, verify=False, timeout=30)
                    response.raise_for_status()
                    html = response.text
                except Exception:
                    fflog_exc()
                    continue

                if not html or 'Just a moment' in html:
                    continue

                movies_section_match = re.search(
                    r'<h3>Filmy</h3>.*?<div class="row">(.*)</div>\s*</div>', html, re.DOTALL)
                if not movies_section_match:
                    continue
                html_movies = movies_section_match.group(1)

                blocks = re.findall(
                    r'<div class="single-video">.*?<a href="([^"]+)".*?<span class="video-item-content">([^<]+)</span>', html_movies, re.DOTALL)
                fflog(f'search: {len(blocks)} results')
                title_clean = cleantitle.get_simple(title)

                for href, film_title in blocks:
                    film_title_unescaped = unescape(film_title.strip())
                    film_title_clean = cleantitle.get_simple(film_title_unescaped)

                    if title_clean not in film_title_clean:
                        continue

                    film_year = self._extract_year(href)
                    if film_year and abs(int(year) - int(film_year)) <= 1:
                        full_url = href if href.startswith('http') else f"{self.base_link}{href}"
                        fflog(f'found movie: {film_title_unescaped} ({film_year})')
                        return (full_url, film_title_unescaped)
        except Exception:
            fflog_exc()
        return None

    def _search_tvshow(self, titles, year):
        try:
            for title in titles:
                if not title:
                    continue
                fflog(f'query: {title!r}')
                url = self.search_link.format(title=quote_plus(title))
                try:
                    response = self.session.get(url, verify=False, timeout=30)
                    response.raise_for_status()
                    html = response.text
                except Exception:
                    fflog_exc()
                    continue
                if not html or 'Just a moment' in html:
                    continue
                shows_section_match = re.search(r'<h3>Seriale</h3>.*?<div class="row">(.*?)</div>', html, re.DOTALL)
                if not shows_section_match:
                    continue
                html_shows = shows_section_match.group(1)
                blocks = re.findall(
                    r'<div class="single-video">.*?<a href="([^"]+)".*?<span class="video-item-content">([^<]+)</span>', html_shows, re.DOTALL)
                fflog(f'search: {len(blocks)} results')
                title_clean = cleantitle.get_simple(title)
                for href, show_title_res in blocks:
                    show_title_res = unescape(show_title_res.strip())
                    show_title_clean = cleantitle.get_simple(show_title_res)
                    if title_clean not in show_title_clean:
                        continue
                    full_url = href if href.startswith('http') else f"{self.base_link}{href}"
                    fflog(f'found series: {show_title_res}')
                    return (full_url, show_title_res)
        except Exception:
            fflog_exc()
        return None

    def _extract_year(self, href):
        try:
            full_url = href if href.startswith('http') else f"{self.base_link}{href}"
            response = self.session.get(full_url, verify=False, timeout=30)
            response.raise_for_status()
            html = response.text
            match = re.search(r'<i class="fa fa-calendar-alt"></i>([^<]+)</span>', html)
            if match:
                year_match = re.search(r'(\d{4})', match.group(1))
                if year_match:
                    return year_match.group(1)
        except Exception:
            fflog_exc()
        return None
        return None
