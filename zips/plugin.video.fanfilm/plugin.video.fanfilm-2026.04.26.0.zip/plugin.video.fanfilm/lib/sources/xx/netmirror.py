# -*- coding: utf-8 -*-
"""
FanFilm - źródło NetMirror (Prime Video / Netflix mirror)
Copyright (C) 2026 :)

Dystrybuowane na licencji MIT <https://mit-license.org>

And if you absolutely must borrow the scraper, remember that it cost us over a month of work...
It would be a good idea to mention this in your version where you are borrowing from,
in accordance with the license.

Architecture:
  1. _discover_api()   – auto-detects current domain via config.js (domains rotate)
  2. _get_bypass_cookie() – obtains t_hash_t session cookie via POST /tv/p.php
  3. _search()         – finds content ID from search.php
  4. _find_episode()   – resolves episode ID from post.php + episodes.php
  5. _get_playlist()   – gets HLS URLs from playlist.php (relative → absolute)
  6. _build_proxy_url() – fetches master m3u8, fixes sub-playlists, serves via
                         FanFilm HTTP service (/media/nm_HASH.m3u8)
  7. resolve()         – returns isa+http://127.0.0.1:{service_port}/media/nm_HASH.m3u8

Why the proxy?
  - ISA cannot resolve relative segment URLs (CDN uses e.g. 9846_000.js)
  - Sub-playlists often lack #EXT-X-ENDLIST → ISA treats as live → instant EOF
  - CF TLS fingerprinting blocks ISA but not Python requests
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from html import unescape
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING, ClassVar
from urllib.parse import parse_qs, urlparse, urljoin

from const import const
from lib.ff import requests, cleantitle, cache, control
from lib.ff.item import FFItem
from lib.ff.source_utils import DEFAULT_UA
from lib.ff.resolve_utils import build_isa_url
from lib.ff.log_utils import fflog, fflog_exc
from lib.service.client import service_client

if TYPE_CHECKING:
    from lib.sources import SourceItem


# Quality label mapping (from playlist.php)
_QUALITY_MAP = {
    'Full HD': '1080p',
    'Mid HD': '720p',
    'Low HD': 'SD',
}

# Known domains (newest first; list extended by _discover_api)
_KNOWN_DOMAINS = ['net52.cc', 'net22.cc', 'net2025.cc']

# API path suffixes (loaded from const)
_API_PATHS = const.sources.netmirror.api_paths
_API_PATHS_MOVIES = const.sources.netmirror.api_paths_movies
_API_PATHS_SHOW = const.sources.netmirror.api_paths_show

# Required cookies for the API
_API_COOKIES = {'ott': 'pv', 'hd': 'on'}

# Module-level session cache (lives for one Kodi session / process)
_api_cache: dict = {}

# Disk cache key
_CACHE_KEY_T_HASH = 'nm_t_hash_t'


#
# HLS sub-playlist fixer
#


def _fix_sub_playlist(text: str, base_url: str) -> str:
    """
    Fix CDN HLS sub-playlist so ISA can play it:
      1. Convert relative segment URLs (e.g. 9846_000.js) to absolute.
      2. Insert #EXT-X-PLAYLIST-TYPE:VOD if missing.
      3. Append #EXT-X-ENDLIST if missing (without it ISA treats stream as live).
    """
    lines = text.splitlines()
    fixed = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            # segment line — make absolute if relative
            fixed.append(stripped if stripped.startswith('http') else base_url.rstrip('/') + '/' + stripped.lstrip('/'))
        else:
            fixed.append(line)

    content = '\n'.join(fixed)

    if '#EXT-X-PLAYLIST-TYPE' not in content and '#EXT-X-MEDIA-SEQUENCE' in content:
        content = content.replace(
            '#EXT-X-MEDIA-SEQUENCE',
            '#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE',
            1,
        )

    if '#EXT-X-ENDLIST' not in content:
        content += '\n#EXT-X-ENDLIST\n'

    return content


#
# Source class
#

# ─── source ──────────────────────────────────────────────────────────────────────

class source:
    ffitem: FFItem

    priority: ClassVar[int] = 1
    language: ClassVar[List[str]] = ['en', 'pl']

    def __init__(self):
        self.domains = ['net52.cc', 'net22.cc', 'pcmirror.cc']
        # Session with no cache arg → plain requests.Session (no stale responses)
        self.session = requests.Session()
        self.session.headers.update(
            {
                'User-Agent': DEFAULT_UA,
                'Referer': f"https://net52.cc/{_API_PATHS[0]}/",
            }
        )

    # FanFilm interface

    # ── public api ─────────────────────────────────────────────────────────

    def movie(self, imdb: str, title: str, localtitle: str, aliases: List[Dict], year: str, **kwargs) -> Optional[Dict]:
        try:
            api = _API_PATHS_MOVIES
            return {'title': title, 'year': str(year or ''), 'is_tv': False, 'api_types': api}
        except Exception:
            fflog_exc()
            return None

    def tvshow(self, imdb: str, tvdb: str, tvshowtitle: str, localtvshowtitle: str, aliases: List[Dict], year: str) -> Optional[str]:
        try:
            api_types = _API_PATHS_SHOW
            found_ids = set()
            results = []
            for path in api_types:
                show_id = self._search(path, tvshowtitle, str(year or ''), is_tv=True)
                if not show_id and localtvshowtitle and localtvshowtitle != tvshowtitle:
                    show_id = self._search(path, localtvshowtitle, str(year or ''), is_tv=True)
                if show_id:
                    prefixed_id = f"{path}:{show_id}"
                    if prefixed_id not in found_ids:
                        found_ids.add(prefixed_id)
                        results.append({'api_path': path, 'show_id': show_id})
            return json.dumps(results) if results else None
        except Exception:
            fflog_exc()
            return None

    def episode(self, url: Optional[str], imdb: str, tvdb: str, title: str, premiered: str, season: str, episode: str) -> Optional[str]:
        try:
            if not url:
                return None

            show_data_list = json.loads(url)
            results = []

            for show_data in show_data_list:
                api_path = show_data.get('api_path')
                show_id = show_data.get('show_id')

                episode_id = self._find_episode(api_path, show_id, int(season), int(episode))
                if episode_id:
                    results.append({'api_path': api_path, 'show_id': show_id, 'episode_id': episode_id})

            return json.dumps(results) if results else None
        except Exception:
            fflog_exc()
            return None

    def sources(self, url: Optional[Dict], hostDict: List[str], hostprDict: List[str]) -> 'List[SourceItem]':
        sources_list = []
        try:
            if not url:
                return sources_list

            is_movie = isinstance(url, dict) and 'title' in url

            # Movie: url is a dictionary from movie()
            if is_movie:
                data = url
                api_types_to_use = data.get('api_types') or []
                prefixed_content_ids = []
                for path in api_types_to_use:
                    content_id = self._search(path, data.get('title', ''), data.get('year', ''), is_tv=False)
                    if content_id:
                        prefixed_content_ids.append({'api_path': path, 'show_id': content_id, 'episode_id': None})
            # TV Show: url is JSON from episode()
            else:
                prefixed_content_ids = json.loads(url) if isinstance(url, str) else []

            seen_sources: set[tuple] = set()

            for content_data in prefixed_content_ids:
                api_path_prefix = content_data.get('api_path')
                show_id = content_data.get('show_id')
                content_id = content_data.get('episode_id') or show_id

                api_path = '/' + api_path_prefix
                playlist, tracks = self._get_playlist(api_path, content_id)
                if not playlist:
                    continue

                lang_info = self._get_lang_info(api_path, show_id)  # Use show_id for language data
                source_lang = 'pl' if 'PL' in lang_info else 'en'

                info_parts: list = []
                if 'Multi' in lang_info or 'MULTI' in lang_info:
                    info_parts.append('MULTI')
                if any(t.get('label', '').startswith(tuple(const.sources.netmirror.sub_langs)) for t in tracks):
                    info_parts.append('NAPISY')
                info_str = ' '.join(info_parts)

                fflog(
                    f"source_lang={source_lang!r} info={info_str!r} for {content_id} (show_id={show_id}) on API {api_path_prefix}")

                for src in playlist:
                    label = src.get('label', '')
                    if not src.get('file') or label == 'Auto':
                        continue
                    quality = _QUALITY_MAP.get(label, '720p')

                    # API mobile bug: returns various quality labels for movies, but actually serves one (720p).
                    if is_movie and api_path_prefix == 'mobile':
                        quality = '720p'

                    source_key = (quality, source_lang, info_str)
                    if source_key in seen_sources:
                        continue
                    seen_sources.add(source_key)
                    sources_list.append(
                        {
                            'source': 'netmirror',
                            'quality': quality,
                            'language': source_lang,
                            'url': f"netmirror://{api_path_prefix}:{content_id}?q={label}",
                            'info': info_str,
                            'direct': False,
                            'debridonly': False,
                            'filename': f"API: {api_path_prefix}",
                        }
                    )
        except Exception:
            fflog_exc()
        fflog(f'sources: {len(sources_list)}')
        return sources_list

    def resolve(self, url: str) -> Optional[str]:
        if not url:
            return url

        if url.startswith('netmirror://'):
            parsed = urlparse(url)
            netloc_parts = parsed.netloc.split(':', 1)

            if len(netloc_parts) == 2:
                api_path_prefix, content_id = netloc_parts
            else:
                content_id = parsed.netloc
                api_path_prefix = _API_PATHS[0]

            api_path = '/' + api_path_prefix
            quality_label = parse_qs(parsed.query).get('q', ['Auto'])[0]

            _api, streaming = self._discover_api(api_path)

            # Fetch a fresh playlist so the embedded ?in= token is current
            playlist, tracks = self._get_playlist(api_path, content_id)
            if not playlist:
                fflog(f"resolve: no playlist for {content_id} on API {api_path_prefix}")
                return None

            file_url = None
            for src in playlist:
                if src.get('label') == quality_label and src.get('file'):
                    file_url = src['file']
                    break
            if not file_url:
                for src in playlist:
                    if src.get('label') == 'Auto' and src.get('file'):
                        file_url = src['file']
                        break
            if not file_url:
                return None

            fflog(f"resolve: {content_id} q={quality_label} → {file_url[:80]} on API {api_path_prefix}")

            # Download subtitles in background; player.py picks up 'flixhq.subtitles'
            self._fetch_subs(tracks)

            # Primary path: proxy — ISA plays from localhost
            proxy_url = self._build_proxy_url(api_path, file_url, streaming)
            if proxy_url:
                return build_isa_url(proxy_url, f"{streaming}/")

            # Fallback: give ISA the direct CDN URL with cookies
            cookie = self._cookie_header_str()
            return build_isa_url(file_url, f"{streaming}/", streaming, cookie=cookie)

        # Plain m3u8 URL passed directly (e.g. from resolve() re-entry)
        if '.m3u8' in url:
            _api, streaming = self._discover_api(_API_PATHS[0])
            cookie = self._cookie_header_str()
            return build_isa_url(url, f"{streaming}/", streaming, cookie=cookie)

        return url

    # API discovery

    # ── helpers ────────────────────────────────────────────────────────────

    def _discover_api(self, api_path: str) -> tuple[str, str]:
        """
        Auto-detects current API/streaming domain:
          1. Fetches netmirror.gg/2/en to find redirect / embedded domain links.
          2. For each candidate domain reads /{api_path}/config.js (api + streaming keys).
          3. Verifies the api URL with a ping to search.php.
          4. Falls back to the domain directly if config.js is missing or stale.
        Result cached in _api_cache for 1 hour (domain rotations picked up live).
        Returns (api_base, streaming_base).
        """
        now = time.time()
        if api_path in _api_cache and _api_cache[api_path].get('expires', 0) > now:
            cached = _api_cache[api_path]
            return cached['api'], cached['streaming']

        domains_to_try = list(_KNOWN_DOMAINS)
        try:
            ng_resp = self.session.get(
                'https://netmirror.gg/2/en',
                verify=False,
                timeout=10,
                allow_redirects=True,
            )
            if ng_resp.status_code == 200:
                final_host = urlparse(ng_resp.url).netloc
                if final_host and final_host != 'netmirror.gg' and final_host not in domains_to_try:
                    domains_to_try.insert(0, final_host)
                for m in re.finditer(r"https?://(net\w+\.(?:cc|app|top|io))[/\"']", ng_resp.text):
                    d = m.group(1)
                    if d not in domains_to_try:
                        domains_to_try.insert(0, d)
        except Exception:
            pass

        for domain in domains_to_try:
            try:
                config_resp = self.session.get(
                    f"https://{domain}/{api_path}/config.js",
                    verify=False,
                    timeout=10,
                )
                if config_resp.status_code == 200:
                    api_m = re.search(r"api:\s*'([^']+)'", config_resp.text)
                    strm_m = re.search(r"streaming:\s*'([^']+)'", config_resp.text)
                    if api_m and strm_m:
                        cfg_api = api_m.group(1).rstrip('/')
                        cfg_strm = strm_m.group(1).rstrip('/')
                        self._cache_api(api_path, cfg_api, cfg_strm, now)
                        return cfg_api, cfg_strm

                # config.js missing or its api is dead → try domain directly
                direct_api = f"https://{domain}/{api_path}"
                direct_strm = f"https://{domain}"
                ping_resp = self.session.get(
                    f"{direct_api}/search.php",
                    params={'s': 'a'},
                    verify=False,
                    timeout=8,
                )
                if ping_resp.status_code == 200:
                    self._cache_api(api_path, direct_api, direct_strm, now)
                    return direct_api, direct_strm
            except Exception:
                pass

        return f"https://net52.cc/{api_path}", 'https://net52.cc'

    def _cache_api(self, api_path: str, api: str, streaming: str, now: float) -> None:
        _api_cache[api_path] = {'api': api, 'streaming': streaming, 'expires': now + 3600}
        self.session.headers.update({'Referer': f"{streaming}/{api_path}/"})

    # Session bypass (t_hash_t cookie)

    def _get_bypass_cookie(self) -> str:
        """
        Obtain t_hash_t session cookie (mirrors CloudStream bypass()):
          POST /tv/p.php with ott=pv cookie → repeat until '\"r\":\"n\"' in body
          → read t_hash_t from response cookies.
        Cached in _api_cache for ~15 h and persisted to disk (survives restarts).
        """
        now = time.time()
        if _api_cache.get('cookie_expires', 0) > now:
            t = _api_cache.get('t_hash_t', '')
            if t:
                return t

        row = cache.cache_get(_CACHE_KEY_T_HASH, control.providercacheFile)
        if row:
            val = row.get('value', '')
            if val:
                _api_cache['t_hash_t'], _api_cache['cookie_expires'] = val, now + 54000
                return val

        _api, streaming = self._discover_api(_API_PATHS[0])
        for base_url in [streaming] + [f"https://{d}" for d in _KNOWN_DOMAINS if f"https://{d}" != streaming]:
            try:
                for _ in range(5):
                    resp = self.session.post(
                        f"{base_url}/tv/p.php",
                        cookies={'ott': 'pv', 'hd': 'on'},
                        verify=False,
                        timeout=10,
                    )
                    if resp.status_code == 200 and '"r":"n"' in resp.text:
                        t = resp.cookies.get('t_hash_t', '')
                        if t:
                            _api_cache['t_hash_t'], _api_cache['cookie_expires'] = t, now + 54000
                            cache.cache_insert(_CACHE_KEY_T_HASH, t, control.providercacheFile)
                            return t
                    time.sleep(0.3)
            except Exception:
                pass
        return ''

    def _cookies(self) -> dict:
        """Return cookies dict to send with API requests."""
        cookies = dict(_API_COOKIES)
        t = self._get_bypass_cookie()
        if t:
            cookies['t_hash_t'] = t
        return cookies

    def _cookie_header_str(self) -> str:
        """Return Cookie header string (for ISA header injection)."""
        return '; '.join(f"{k}={v}" for k, v in self._cookies().items())

    # Content lookup

    def _search(self, api_path: str, title: str, year: str, is_tv: bool) -> str | None:
        """
        Search API and return internal content ID, or None.
        Multi-pass: title+type+year → title+year → partial+year → no-year+type → no-year.
        Titles with colons are tried with multiple query variants (API rejects colons).
        """
        try:
            if not title:
                return None
            fflog(f"_search({title!r}, {year}, is_tv={is_tv}) for API: {api_path!r}")
            api_base, _ = self._discover_api(api_path)
            xhr_headers, year_int = {'X-Requested-With': 'XMLHttpRequest'}, int(year) if year and year.isdigit() else 0

            def _looks_like_tv(runtime: str) -> bool:
                return 'Series' in runtime or not re.search(r'\d+h', runtime)

            def _search_api(query: str) -> list:
                search_cookies = self._cookies()
                search_cookies['ott'] = api_path
                resp = self.session.get(
                    f"{api_base}/search.php",
                    params={'s': query, 'tm': int(time.time())},
                    cookies=search_cookies,
                    headers=xhr_headers,
                    verify=False,
                    timeout=15,
                )
                return resp.json().get('searchResult') or [] if resp.status_code == 200 else []

            _queries = [title]
            if ':' in title:
                main_title, subtitle = [p.strip() for p in title.split(':', 1)]
                _queries += [f"{main_title} {subtitle}", subtitle, main_title, f"{main_title} 2"]

            all_results, seen_ids = [], set()
            for q in dict.fromkeys(_queries):
                fflog(f'query: {q!r}')
                for item in _search_api(q):
                    if item.get('id') not in seen_ids:
                        seen_ids.add(item.get('id'))
                        all_results.append(item)

            fflog(f'search: {len(all_results)} results')
            if not all_results:
                return None
            t_clean = cleantitle.get(title)

            # Pass 1: exact title + correct type + year within ±1
            for item in all_results:
                if cleantitle.get(unescape(item.get('t', ''))) != t_clean:
                    continue
                if _looks_like_tv(item.get('r', '')) != is_tv:
                    continue
                iy = item.get('y', '')[:4]
                if year_int and iy.isdigit() and abs(year_int - int(iy)) > 1:
                    continue
                return item.get('id')

            # Pass 2: fallback to any exact title match
            for item in all_results:
                if cleantitle.get(unescape(item.get('t', ''))) == t_clean:
                    return item.get('id')

            return None
        except Exception:
            fflog_exc()
            return None

    def _find_episode(self, api_path: str, show_id: str, season: int, episode: int) -> str | None:
        """Return episode content ID for S{season}E{episode} of given show."""
        try:
            api_base, _ = self._discover_api(api_path)
            resp = self.session.get(
                f"{api_base}/post.php",
                params={'id': show_id, 'tm': int(time.time())},
                cookies=self._cookies(),
                headers={'X-Requested-With': 'XMLHttpRequest'},
                verify=False,
                timeout=15,
            )
            if resp.status_code != 200:
                return None
            s_id = next((s.get('id') for s in resp.json().get('season', [])
                        if str(s.get('s', '')) == str(season)), None)
            if not s_id:
                return None

            resp2 = self.session.get(
                f"{api_base}/episodes.php",
                params={'s': s_id, 'series': show_id, 'page': 1, 'tm': int(time.time())},
                cookies=self._cookies(),
                headers={'X-Requested-With': 'XMLHttpRequest'},
                verify=False,
                timeout=15,
            )
            if resp2.status_code != 200:
                return None
            target_s, target_e = f"S{season}", f"E{episode}"
            for ep in resp2.json().get('episodes') or []:
                if ep.get('s') == target_s and ep.get('ep') == target_e:
                    return ep.get('id')
            return None
        except Exception:
            fflog_exc()
            return None

    def _get_playlist(self, api_path: str, content_id: str) -> tuple[list | None, list]:
        """Return (sources, tracks) from playlist.php (expanded relative URLs)."""
        try:
            api_base, streaming_base = self._discover_api(api_path)
            resp = self.session.get(
                f"{api_base}/playlist.php",
                params={'id': content_id, 'tm': int(time.time())},
                cookies=self._cookies(),
                headers={'X-Requested-With': 'XMLHttpRequest'},
                verify=False,
                timeout=15,
            )
            if resp.status_code != 200:
                return None, []
            data = resp.json()
            if not data or not isinstance(data, list):
                return None, []
            sources = data[0].get('sources') or []
            for src in sources:
                if src.get('file', '').startswith('/'):
                    src['file'] = streaming_base + src['file']
            fflog(f"playlist for {content_id}: {[s.get('label') for s in sources]}")
            tracks = [t for t in (data[0].get('tracks') or []) if t.get('kind') == 'captions' and t.get('file')]
            return sources, tracks
        except Exception:
            fflog_exc()
            return None, []

    # Language info

    def _get_lang_info(self, api_path: str, content_id: str) -> str:
        """
        Call post.php to get audio language list and return an info label.
        Falls back to "EN" on error or if no languages found.
        """
        try:
            api_base, _ = self._discover_api(api_path)
            resp = self.session.get(
                f"{api_base}/post.php",
                params={'id': content_id, 'tm': int(time.time())},
                cookies=self._cookies(),
                headers={'X-Requested-With': 'XMLHttpRequest'},
                verify=False,
                timeout=10,
            )
            if resp.status_code != 200:
                return 'EN'
            data = resp.json()
            fflog(f"available audio language data for {content_id}: {data.get('lang')}")
            if data.get('lang') is None:
                fflog(f"_get_lang_info: content_id={content_id} lang is None. Raw response: {resp.text[:500]!r}")
                return 'EN'

            seen, langs = set(), []
            for lang_entry in data.get('lang') or []:
                lang_code = lang_entry.get('s', '').lower()
                if lang_code and lang_code not in seen:
                    seen.add(lang_code)
                    langs.append(lang_code)

            wanted = set(const.sources.netmirror.audio_langs)
            filtered = [lng for lng in langs if lng in wanted]
            if not filtered:
                return 'EN'

            has_pol = 'pol' in filtered
            if len(filtered) == 1:
                return 'PL' if has_pol else ('EN' if 'eng' in filtered else filtered[0].upper())
            return 'PL | Multi' if has_pol else 'Multi'
        except Exception:
            fflog_exc()
            return 'EN'

    def _fetch_subs(self, tracks: list) -> None:
        """Download SRT subtitle tracks in background."""
        if not tracks:
            return
        try:
            import tempfile, threading as _th

            _W = tuple(const.sources.netmirror.sub_langs)
            tracks = [t for t in tracks if t.get('label', '').startswith(_W)]
            if not tracks:
                return
            temp_dir = tempfile.mkdtemp(prefix='nm_subs_')
            results, lock = [], _th.Lock()

            def _dl(track: dict):
                url = track['file']
                if url.startswith('//'):
                    url = 'https:' + url
                label = re.sub(r'[^\w\-]', '_', track.get('label', 'sub'))
                path = os.path.join(temp_dir, f"{label}.srt")
                try:
                    resp = self.session.get(url, verify=False, timeout=8)
                    if resp.status_code == 200 and resp.text.strip():
                        with open(path, 'w', encoding='utf-8') as fh:
                            fh.write(resp.text)
                        with lock:
                            results.append(path)
                except Exception:
                    pass

            threads = [_th.Thread(target=_dl, args=(t,), daemon=True) for t in tracks]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=12)
            if results:
                control.window().setProperty('flixhq.subtitles', json.dumps(results))
        except Exception:
            fflog_exc()

    # HLS proxy

    def _build_proxy_url(self, api_path: str, manifest_url: str, streaming_base: str) -> str | None:
        """Build a proxied master m3u8 manifest with absolute segment URLs."""
        try:
            cookies, proxy_map = self._cookies(), {}
            proxy_base = urljoin(service_client.url, '/media')
            resp = self.session.get(manifest_url, cookies=cookies, verify=False, timeout=15)
            if resp.status_code == 403:
                resp = self.session.get(manifest_url, verify=False, timeout=15)
            if resp.status_code != 200:
                return None

            master_text = resp.text
            master_params = parse_qs(urlparse(manifest_url).query)
            needs_hd_on = 'hd' in master_params and master_params['hd'][0] == 'on'
            lines, new_lines, i = master_text.splitlines(), [], 0

            while i < len(lines):
                line = lines[i]
                if line.startswith('#EXT-X-MEDIA') and 'URI=' in line:
                    lang_m = re.search(r'LANGUAGE="([^"]+)"', line)
                    if lang_m and lang_m.group(1) not in const.sources.netmirror.audio_langs:
                        i += 1
                        continue
                    uri_m = re.search(r'URI="([^"]+)"', line)
                    if uri_m:
                        sub_url = uri_m.group(1)
                        if needs_hd_on and 'hd=' not in urlparse(sub_url).query:
                            sub_url += ('&' if '?' in sub_url else '?') + 'hd=on'
                        sub_path = self._collect_sub_playlist(sub_url, cookies, proxy_map)
                        if sub_path:
                            line = line.replace(f'URI="{uri_m.group(1)}"', f'URI="{proxy_base}{sub_path}"')
                    new_lines.append(line)
                    i += 1
                    continue

                if line.startswith('#EXT-X-STREAM-INF'):
                    new_lines.append(line)
                    i += 1
                    if i < len(lines):
                        sub_url = lines[i].strip()
                        if sub_url.startswith('http'):
                            if needs_hd_on and 'hd=' not in urlparse(sub_url).query:
                                sub_url += ('&' if '?' in sub_url else '?') + 'hd=on'
                            sub_path = self._collect_sub_playlist(sub_url, cookies, proxy_map)
                            new_lines.append(f"{proxy_base}{sub_path}" if sub_path else sub_url)
                        else:
                            new_lines.append(lines[i])
                        i += 1
                    continue
                new_lines.append(line)
                i += 1

            new_master = '\n'.join(new_lines)
            master_hash = hashlib.md5(manifest_url.encode()).hexdigest()[:12]
            master_path = f"/nm_{master_hash}.m3u8"
            proxy_map[master_path] = new_master
            service_client.set_media_files(proxy_map)
            return f"{proxy_base}{master_path}"
        except Exception:
            fflog_exc()
            return None

    def _collect_sub_playlist(self, sub_url: str, cookies: dict, proxy_map: dict) -> str | None:
        """Fetch and fix an HLS sub-playlist."""
        try:
            resp = self.session.get(sub_url, cookies=cookies, verify=False, timeout=10)
            if resp.status_code != 200 or not resp.text.strip().startswith('#EXTM3U'):
                return None
            base_url = sub_url.split('?')[0].rsplit('/', 1)[0] + '/'
            fixed = _fix_sub_playlist(resp.text, base_url)
            sub_hash = hashlib.md5(sub_url.encode()).hexdigest()[:12]
            sub_path = f"/nm_sub_{sub_hash}.m3u8"
            proxy_map[sub_path] = fixed
            return sub_path
        except Exception:
            fflog_exc()
            return None
