"""
The settings of the sources (the page "Sources" of the configuration window, `lib.windows.widgets.source_settings`): declared once in
their groups (`SOURCE_SETTINGS`, `ProviderSetting` as the settings of the native providers), the values in the configuration
(`SOURCE_SETTINGS_CONFIG`: only the changed ones), the old settings of `settings.xml` (`legacy`) moved there once by the migration of
the configuration (`lib.ff.config`).
"""

from __future__ import annotations
from typing import Any, Mapping, Sequence
from attrs import evolve, frozen
from .natives import CatalogSetting, ProviderSetting, SettingOption, catalog_setting
from ..kolang import L
from ..windows.scale import Scale

#: The settings of the sources in the configuration (`config.json`): `{<key>: <value>}`, only the changed ones (a default: removed).
SOURCE_SETTINGS_CONFIG: str = '/sources/settings'


@frozen(kw_only=True)
class SettingGroup:
    """A group of the settings of the sources (a frame of the page)."""

    #: The key (the name of its widget).
    key: str
    #: The title.
    label: str
    #: The settings in their order.
    settings: tuple[CatalogSetting, ...]
    #: The column of the page (0 the left one).
    column: int = 0


#: The two times of the search (`search_limits()`): one axis of round steps of about the same ratio (as the size of a source), the end not under 5 s.
SEARCH_TIME_SCALE: Scale = Scale(values=(0, 1, 1.5, 2, 3, 5, 7, 10, 15, 20, 30, 50, 70, 100, 150, 200), format='{:g} s', tick_format='{:g}', knob_max_least=5)


@frozen(kw_only=True)
class SearchLimits:
    """The times of a search of the sources (seconds, from its start; the setting `search_timeout`)."""

    #: The progress window up to it, then the list of the sources found so far (0: the list at once).
    list_after: float
    #: The end of the search.
    end: float


#: The settings of the sources in their groups, in the order of the page (a group in its column, `SettingGroup.column`).
#: The settings of the sources of the filter and the sort: the simple view, the keep of the changes of the sources window, the shows of their own.
SIMPLE_SETTING: str = 'filters_simple'
PERSISTENT_SETTING: str = 'filters_persistent'
SEPARATE_SETTING: str = 'separate_shows'
#: The languages of the providers (the codes joined by ",").
PROVIDERS_LANG_SETTING: str = 'providers_lang'
#: The help of a row of the selection of the user.
SELECTION_HELP: str = L(30947, 'The filter and the sort of the sources with no search: the same ones the list of the sources and the automatic play use.')


SOURCE_SETTINGS: tuple[SettingGroup, ...] = (
    # how much the sources show: the filter and the sort, the search, the priority of the episodes (`simple_view()`)
    SettingGroup(key='view', label=L(30983, 'View'), settings=tuple(catalog_setting(setting) for setting in (
        ProviderSetting(key=SIMPLE_SETTING, kind='bool', label=L(30957, 'Simple view'), default=True,
                        help=L(30958, 'Fewer options: the filter and the sort as a short list of switches, only the progress while searching '
                                      'and one search time, no priority of episodes.')),
    ))),
    SettingGroup(key='colors', label=L(32649, 'Highlight color'), settings=tuple(catalog_setting(setting) for setting in (
        ProviderSetting(key='color_mode', kind='select', label=L(30802, 'Provider color'), default='background',
                        options=(SettingOption(value='background', label=L(30803, 'Row background')), SettingOption(value='accent', label=L(30804, 'Bar and name'))),
                        help=L(30805, 'Where the colour of the provider of a source shows: the background of its row, or a bar at its left and its name.')),
        ProviderSetting(key='auto_colors', kind='bool', label=L(30809, 'Automatic colours'), default=False,
                        help=L(30810, 'A provider with no colour of its own (no node of the tree, no rule) gets its own colour of the theme.')),
        ProviderSetting(key='default_color', kind='color', label=L(32572, 'Default color'), default='FF008EB2',
                        legacy='default.color.identify2',
                        help=L(30790, 'The highlight color of a source no node of the tree of the source providers colors.')),
        ProviderSetting(key='premium_color', kind='color', label=L(32588, 'Premium color'), default='',
                        legacy='prem.color.identify2', help=L(30791, 'The highlight color of a premium source (none: the default one).')),
        ProviderSetting(key='accent_background', kind='color', label=L(30806, 'Item background'), default='',
                        when={'color_mode': ('accent',)},
                        help=L(30807, 'The background of a row of a source while the colour of its provider is a bar and its name (none: the row of the theme).')),
        ProviderSetting(key='row_contrast', kind='bool', label=L(30818, 'Readable row texts'), default=True,
                        help=L(30819, 'The texts of a row of a light (dark) colour turn dark (light) when its own ones would be hard to read.')),
    ))),
    # the keep of the changes of the filter and the sort, the window of them (OK: the key `selection_<media>`; the first row: of the movies, with no shows of their own of all)
    SettingGroup(key='selection', label=L(30951, 'Filters and sort'), settings=tuple(catalog_setting(setting) for setting in (
        ProviderSetting(key=PERSISTENT_SETTING, kind='bool', label=L(30959, 'Keep window changes'), default=False,
                        help=L(30960, 'Off: the changes made in the window of the sources last only for that window; they are changed for good here.')),
        ProviderSetting(key=SEPARATE_SETTING, kind='bool', label=L(30961, 'Separate for shows'), default=False,
                        help=L(30962, 'The shows have their own filter and sort, the movies theirs.')),
        ProviderSetting(key='selection_movie', kind='action', label=L(30948, 'Movies…'), help=SELECTION_HELP),
        ProviderSetting(key='selection_show', kind='action', label=L(30949, 'Shows…'), help=SELECTION_HELP),
    ))),
    SettingGroup(key='row', label=L(30792, 'Row of a source'), settings=tuple(catalog_setting(setting) for setting in (
        ProviderSetting(key='extra_info', kind='bool', label=L(32587, 'Extra source info'), default=True, legacy='sources.extrainfo',
                        help=L(30796, 'Show the extra information of a source (its language, its format, its sound) in its row.')),
        ProviderSetting(key='file_name', kind='bool', label=L(32670, 'File name'), default=False, legacy='sources.filename_in_2nd_line',
                        help=L(30797, 'Show the file name of a source in the second line of its row.')),
        ProviderSetting(key='service_icons', kind='bool', label=L(30255, 'Service icons'), default=True, legacy='icon.external',
                        help=L(30798, 'Show the icon of the service of a source in the window of the sources.')),
        ProviderSetting(key='premium_tag', kind='select', label=L(30820, 'Premium tag'), default='mixed',
                        options=(SettingOption(value='always', label=L(32831, 'Always')),
                                 SettingOption(value='mixed', label=L(30821, 'Mixed providers'))),
                        help=L(30822, 'When a source opened by the account of its provider shows the tag PREMIUM: always, or only for a provider '
                               'which finds free sources too (the tag tells its premium ones apart).')),
        ProviderSetting(key='filtered_dim', kind='int', label=L(30921, 'Filtered out dimmed'), default=65, minimum=0, maximum=90,
                        help=L(30922, 'With the filter off the sources it cuts stay in the list, dimmed this much, % (0-90; 0: not dimmed).')),
    )), column=1),
    SettingGroup(key='search', label=L(32718, 'Source search'), settings=tuple(catalog_setting(setting) for setting in (
        ProviderSetting(key=PROVIDERS_LANG_SETTING, kind='select', label=L(32360, 'Providers Language'), default='pl,en', legacy='providers.lang',
                        options=(SettingOption(value='pl', label=L(32845, 'Polish')), SettingOption(value='en', label=L(32846, 'English')),
                                 SettingOption(value='pl,en', label=L(32847, 'Polish+English'))),
                        help=L(30985, 'Only the providers of these languages are searched; the filter and the sort of the sources follow them.')),
        ProviderSetting(key='search_timeout', kind='range', label=L(32312, 'Search time'), default=[5, 30], scale=SEARCH_TIME_SCALE,
                        legacy='scrapers.timeout.1',
                        help=L(30793, 'From - to, seconds. Up to the first time the window of the progress, '
                               'then the list of the sources found so far (0: at once). '
                               'At the second one the search ends: the debrid services check the torrents.')),
        ProviderSetting(key='default_action', kind='select', label=L(32331, 'Action after the search'), default=0, legacy='hosts.mode',
                        help=L(30799, 'After the search: the window of the sources, or the first source played at once.'),
                        options=(SettingOption(value=0, label=L(32332, 'Sources window')), SettingOption(value=2, label=L(32334, 'Auto Play')))),
        ProviderSetting(key='auto_next', kind='bool', label=L(32668, 'Auto-select the next item'), default=False,
                        legacy='auto.select.next.item.to.play', help=L(30800, 'Select the next items of the playback list automatically.')),
        ProviderSetting(key='source_cache', kind='bool', label=L(32720, 'Sources cache'), default=True, legacy='enableSourceCache',
                        help=L(30801, 'Keep the found sources for a while: the next search of the same title is quicker.')),
        ProviderSetting(key='resolveurl', kind='action', label=L(32540, 'ResolveURL settings'), action='Addon.OpenSettings(script.module.resolveurl)',
                        legacy='sources.resolver_settings'),
    )), column=1),
)

#: The declared settings by their keys.
SETTINGS: dict[str, CatalogSetting] = {setting['key']: setting for group in SOURCE_SETTINGS for setting in group.settings}
#: The ID of the old setting of `settings.xml` of a setting of none (`ProviderSetting.legacy`: of a native provider).
NO_LEGACY: str = '{name}.{key}'


def source_setting(key: str) -> Any:
    """
    Return a setting of the sources: its value in the configuration, else its declared default (a colour of '' too: the default one of the
    colour picker, `ColorPlace`).
    """
    from ..ff.config import config, escape_key
    from ..ff.tricks import MISSING
    value = config.get(f'{SOURCE_SETTINGS_CONFIG}/{escape_key(key)}', MISSING)
    setting = SETTINGS[key]
    if value is MISSING or value == '' and setting['kind'] == 'color':
        return setting['default']
    if setting['kind'] == 'range' and not isinstance(value, (list, tuple)):  # stored as one number by an older version: the maximum
        return [setting['default'][0], value]
    return value


#: The row of the time of the search of the simple view (no list while searching: one time, the end; written with `search_timeout` by its page).
SEARCH_END_SETTING: CatalogSetting = {**SETTINGS['search_timeout'], 'key': 'search_end', 'kind': 'scale', 'default': SETTINGS['search_timeout']['default'][1],
                                      'scale': evolve(SEARCH_TIME_SCALE, values=tuple(value for value in SEARCH_TIME_SCALE.values
                                                                                      if value >= SEARCH_TIME_SCALE.knob_max_least)),
                                      'help': L(30984, 'The time of the search, seconds. At its end the debrid services check the torrents.')}


def search_limits() -> SearchLimits:
    """Return the times of a search of the sources."""
    list_after, end = source_setting('search_timeout')
    return SearchLimits(list_after=list_after, end=end)


def setting_reason(setting: CatalogSetting) -> str:
    """Return why a setting of the sources is not usable now ('' it is): its `when` - every key of it has one of its values."""
    when: Mapping[str, Sequence[Any]] = setting.get('when', {})
    if all(source_setting(key) in values for key, values in when.items()):
        return ''
    return L(30808, 'Used with the colour of the provider: {mode}.').format(mode=', '.join(
        next((opt['label'] for opt in SETTINGS[key].get('options', ()) if opt['value'] == value), str(value)) for key, values in when.items() for value in values))


def set_source_setting(key: str, value: Any) -> None:
    """Set a setting of the sources (its declared default - a colour of '' too, the default one of the colour picker -: removed, only the
    changes are stored)."""
    from ..ff.config import config, escape_key
    setting = SETTINGS[key]
    if value == '' and setting['kind'] == 'color':
        value = setting['default']
    config.set(f'{SOURCE_SETTINGS_CONFIG}/{escape_key(key)}', value, default=setting['default'])


def migrate_legacy(data: dict[str, Any], old: dict[str, str]) -> list[str]:
    """
    Move the old settings of `settings.xml` (`old`: the values of the user file by their IDs) into the data of the configuration (a value
    written already is kept), return the moved IDs (to remove from the user file).
    """
    from .natives import old_value
    from ..ff.tricks import MISSING
    moved: list[str] = []
    values: dict[str, Any] = {}
    for setting in SETTINGS.values():
        if (sid := setting['legacy']) == NO_LEGACY:  # no old setting
            continue
        moved.append(sid)
        value = old_value(setting, old.get(sid, ''))
        if value is not MISSING and value != setting['default']:
            values[setting['key']] = value
    if values:
        sources = data.setdefault('sources', {})
        current = sources.get('settings') if isinstance(sources.get('settings'), dict) else {}
        sources['settings'] = {**values, **current}
    return moved
