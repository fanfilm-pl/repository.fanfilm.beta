# -*- coding: utf-8 -*-
"""
FanFilm - źródło: archive.org (Public Domain / Creative Commons)
"""

import re
import time
import requests
from datetime import datetime
from urllib.parse import quote
from lib.ff import cleantitle
from lib.ff.log_utils import fflog, fflog_exc


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]  # głównie angielskie
        self.base_link = "https://archive.org"
        self.search_api = f"{self.base_link}/advancedsearch.php"
        self.session = requests.Session()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Kodi FanFilm)",
            "Accept": "application/json,text/html",
        }

    def _get_video_files(self, identifier):
        """Pobierz metadane i zwróć listę plików wideo z rozmiarami."""
        try:
            metadata_url = f"{self.base_link}/metadata/{identifier}"
            r = self.session.get(metadata_url, headers=self.headers, timeout=30)

            if r.status_code != 200:
                return []

            metadata = r.json()
            files = metadata.get("files", [])

            video_files = []
            for file in files:
                name = file.get("name", "")
                fmt = file.get("format", "")
                size = int(file.get("size", 0))

                if (name.endswith(".mp4") or "MPEG4" in fmt or
                    name.endswith(".webm") or "WebM" in fmt or
                    name.endswith(".mkv") or "Matroska" in fmt):
                    video_files.append({
                        'name': name,
                        'format': fmt,
                        'size': size
                    })

            return video_files
        except Exception:
            return []

    def movie(self, imdb, title, localtitle, aliases, year):
        current_year = datetime.now().year
        if year and str(year).isdigit():
            if current_year - int(year) < 70:
                return None  # film zbyt młody, pomijamy
        return self.search_movie(title, localtitle, year)

    def tvshow(self, *args, **kwargs):
        return None  # tylko filmy

    def episode(self, *args, **kwargs):
        return None

    def search_movie(self, title, localtitle, year):
        try:
            if not title:
                return None

            # PRIORYTET: oryginalny tytuł angielski (lepsze rezultaty w archive.org)
            url = self.search(title, year)
            if url:
                return url

            # fallback: lokalny tytuł
            if localtitle and localtitle.lower() != title.lower():
                return self.search(localtitle, year)

            return None
        except Exception:
            fflog_exc()
            return None

    def search(self, title, year=None):
        try:
            if not title:
                return None

            search_title_clean = cleantitle.get(title)
            current_year = time.localtime().tm_year
            oldest_year = current_year - 70  # tylko filmy starsze niż 70 lat

            fflog(f"[archive.org] search: {title!r}, year={year}, oldest_year={oldest_year}")

            # query do API archive.org
            q = f'mediatype:movies AND title:("{title}")'
            params = {
                "q": q,
                "fl[]": ["identifier", "title", "year"],
                "rows": 50,
                "output": "json"
            }

            r = self.session.get(self.search_api, params=params, headers=self.headers, timeout=30)
            if r.status_code != 200:
                # fflog(f"HTTP {r.status_code} while fetching archive.org")
                return None

            data = r.json()
            docs = data.get("response", {}).get("docs", [])

            # Znajdź wszystkie pasujące filmy i wybierz największy
            candidates = []
            for d in docs:
                identifier = d.get("identifier")
                item_title = d.get("title", "")
                item_year = d.get("year")

                if not identifier or not item_title:
                    continue

                # sprawdzenie wieku tylko jeśli rok jest liczbowy
                if item_year and str(item_year).isdigit():
                    if int(item_year) > oldest_year:
                        continue

                item_title_clean = cleantitle.get(item_title)
                # Sprawdź dopasowanie - dokładne lub częściowe
                exact_match = search_title_clean == item_title_clean
                partial_match = (search_title_clean in item_title_clean or
                               item_title_clean in search_title_clean) and len(search_title_clean) >= 3

                if not (exact_match or partial_match):
                    continue

                candidates.append({
                    'identifier': identifier,
                    'title': item_title,
                    'year': item_year,
                    'exact': exact_match
                })

            if not candidates:
                fflog("[archive.org] No matching titles found")
                return None

            # Sprawdź rozmiary plików dla wszystkich kandydatów
            best_candidate = None
            max_size = 0

            for candidate in candidates:
                video_files = self._get_video_files(candidate['identifier'])
                if not video_files:
                    continue

                # Znajdź największy plik wideo
                max_video_size = max(f['size'] for f in video_files)

                # Preferuj dokładne dopasowania, ale bierz największy plik
                score = max_video_size
                if candidate['exact']:
                    score *= 10  # bonus za dokładne dopasowanie

                if score > max_size:
                    max_size = score
                    best_candidate = candidate

            if not best_candidate:
                # fflog("[archive.org] No candidates with video files found")
                return None

            url = f"{self.base_link}/details/{best_candidate['identifier']}"
            # fflog(f"[archive.org] Found best match: {best_candidate['title']} ({best_candidate['year']})")
            return url

        except Exception:
            fflog_exc()
            return None

    def sources(self, url, hostDict, hostprDict):
        try:
            if not url:
                return []

            # URL do details - pobierz metadane i znajdź pliki wideo
            m = re.search(r'/details/([^/]+)', url)
            if not m:
                return []

            identifier = m.group(1)
            # fflog(f"[archive.org] Getting sources for: {identifier}")

            # Pobierz pliki wideo
            video_files = self._get_video_files(identifier)
            if not video_files:
                fflog("[archive.org] No video files found")
                return []

            # Znajdź największy plik wideo
            best_file = max(video_files, key=lambda f: f['size'])

            # Zakoduj nazwę pliku do URLa (polskie znaki, spacje itp.)
            encoded_filename = quote(best_file['name'], safe='')
            mp4_url = f"{self.base_link}/download/{identifier}/{encoded_filename}"

            # Określ rozmiar - jeśli za mały, nie pokazuj
            size_gb = best_file['size'] / (1024 * 1024 * 1024)
            min_size_gb = 0.01
            size_display = f"{size_gb:.1f}GB" if size_gb >= min_size_gb else ""

            # Sprawdź czy format zawiera "IA" i zamień na "DRM"
            info_format = best_file['format']
            if "IA" in info_format:
                info_format = info_format.replace("IA", "DRM")
                size_display = ""  # Dla IA/DRM nie pokazuj rozmiaru

            quality = "720p"

            source = {
                "source": "",
                "quality": quality,
                "language": "en",
                "url": mp4_url,
                "info": info_format,
                "size": size_display,
                "direct": True,
                "debridonly": False,
                "premium": False,
            }

            return [source]
        except Exception:
            fflog_exc()
            return []

    def resolve(self, url):
        # Bezpośrednie URLe nie wymagają resolving
        return url
