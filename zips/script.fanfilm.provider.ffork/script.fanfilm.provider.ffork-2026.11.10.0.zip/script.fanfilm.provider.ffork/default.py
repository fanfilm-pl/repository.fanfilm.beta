"""The entry of the provider add-on in Program add-ons: opens FanFilm » Tools » External add-ons."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'lib'), str(ROOT / 'lib' / '3rd')]

from ffsdk.worker import show_addon  # noqa: E402

show_addon(ROOT)
