"""The worker script of the provider add-on: started by FanFilm (its service), serves the scrapers of the FanFilm forks."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'lib'), str(ROOT / 'lib' / '3rd')]

from ffsdk.worker import main  # noqa: E402

main(ROOT)
