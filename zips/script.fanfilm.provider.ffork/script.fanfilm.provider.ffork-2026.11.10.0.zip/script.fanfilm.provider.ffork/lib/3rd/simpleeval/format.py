"""
Some safe string and format tools.

Author: rysson
"""

from __future__ import annotations
from typing import Any, Iterable, Sequence, Mapping, Callable, Type, overload, TYPE_CHECKING
from typing_extensions import Protocol, Literal, LiteralString, TypeGuard
import re
import string
from collections import UserDict
from inspect import isclass
from logging import getLogger
from simpleeval import InvalidExpression, EvalWithCompoundTypes, SimpleEval, simple_eval
if TYPE_CHECKING:
    import ast

logger = getLogger(__name__)


class MISSING:
    pass


class Evaluator(Protocol):
    def __init__(self,
                 operators: Mapping[type['ast.operator'], Callable] | None = None,
                 functions: Mapping[str, Callable] | None = None,
                 names: Mapping[str, Any] | None = None) -> None: ...

    def eval(self, expr: str, previously_parsed: ast.Expr | None = None) -> Any: ...

    # def __init__(self, operators=None, functions=None, names=None) -> None: ...
    # def eval(self, expr, previously_parsed=None) -> Any: ...


class EvaluatorFactory(Protocol):
    def __call__(self,
                 operators: Mapping[type['ast.operator'], Callable] | None = None,
                 functions: Mapping[str, Callable] | None = None,
                 names: Mapping[str, Any] | None = None) -> Evaluator: ...


class FormatProtocol(Protocol):
    def __call__(self, format_string: str, /, *args, **kwargs) -> str: ...


EvaluatorClass = Type[Evaluator]


#: Regex type
regex = type(re.compile(''))


#: RegEx for UUID
re_uuid = re.compile(r'[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}')


re_quote = re.compile(r'''(?:"""(?:\\.|.)*?""")|(?:"(?:\\.|.)*?")'''
                      r"""|(?:'''(?:\\.|.)*?''')|(?:'(?:\\.|.)*?')""")


def fparser(s: str) -> Iterable[tuple[str, str | None, str | None, str | None]]:
    """
    Like _string.formatter_parser() returns (literal_text, field_name, format_spec, conversion).
    Supports "{}" inside field_name, can work with simple_eval.
    Ex. f-string inside {} inside join with list comprehension):
    >>> fmt('out: {", ".join(f"({x})" for x in hosts)}...', hosts=("a", "bb", "ccc"))
    >>> # 'out: (a), (bb), (ccc)'
    """
    i, lvl = 0, 0
    # literal_text, field_name, format_spec, conversion
    oi, vec = 0, ['', None, None, None]
    while i < len(s):
        c = s[i]
        nc = s[i+1:i+2]
        # if c in '{}' and c == nc:
        if c in '{}' and c == nc and (lvl < 2 or c == '{'):
            vec[oi] += c
            i += 1
        elif c == '{':
            if lvl == 0:
                oi = 1
                vec[1] = vec[2] = ''
            else:
                vec[oi] += c
            lvl += 1
        elif c == '}':
            lvl -= 1
            if lvl < 0:
                raise ValueError("Single '}' encountered in format string")
            if lvl == 0:
                yield vec
                oi, vec = 0, ['', None, None, None]
            else:
                vec[oi] += c
        elif lvl == 1 and c == '!' and oi == 1:
            oi = 3
            vec[oi] = ''
        elif lvl == 1 and c == ':' and oi in (1, 3):
            oi = 2
            vec[oi] = ''
        else:
            if lvl > 0:
                rx = re_quote.match(s, i) if c in ('"', "'") else None
                if rx:
                    a, b = rx.span()
                    vec[oi] += s[a:b]
                    i += b - a - 1
                elif c == '[':
                    lvl += 1
                    vec[oi] += c
                elif c == ']':
                    lvl -= 1
                    vec[oi] += c
                else:
                    vec[oi] += c
            else:
                vec[oi] += c
        i += 1
    if lvl:
        raise ValueError("Single '{' encountered in format string")
    if vec[0] or vec[1] is not None:
        yield vec


def _is_evaluator_object(obj: Any) -> TypeGuard[Evaluator]:
    return not isclass(obj) and bool((meth := getattr(obj, 'eval', None)) and callable(meth))


if TYPE_CHECKING:
    _MultiDictBase = UserDict[str, Any]
else:
    _MultiDictBase = UserDict  # py3.8


class MultiDict(_MultiDictBase):
    """Dict wrapper to support callable `names` in Evaluator."""

    def __init__(self, *sources: Mapping[str, Any] | Callable[[str], Any]) -> None:
        super().__init__()
        self._sources = sources

    def get(self, key: str, default: Any = None) -> Any:
        for source in reversed(self._sources):
            try:
                if callable(source):
                    return source(key)
                return source[key]
            except Exception:
                pass
        return default

    def __getitem__(self, key: str) -> Any:
        for source in reversed(self._sources):
            try:
                if callable(source):
                    return source(key)
                return source[key]
            except Exception:
                pass
        raise KeyError(key)


class SafeFormatter(string.Formatter):
    r"""
    Safe string formatter.

    Leave unknown arguments, or use default value or evaluate expr:
    ("{a:!!def} {999}") -> "def {999}"
    ("{a + 2}", a=42)   -> "44"
    """

    _escape_trans = {
        '\\': '\\\\',
        '\'': '\\\'',
        '\"': '\\\"',
        '\a': '\\a',
        '\b': '\\b',
        '\f': '\\f',
        '\n': '\\n',
        '\r': '\\r',
        '\t': '\\t',
        '\v': '\\v',
        '\000': '\\000',
    }

    _RX_SHOW_EXPR = re.compile(r'^(.*?)(\s*=\s*)$')

    def __init__(self, *,
                 evaluate: bool | Literal['simple', 'complex'] | Evaluator | EvaluatorClass | EvaluatorFactory = True,
                 escape: bool = True,
                 extended: bool | None = None,
                 evaluate_first: bool = False,
                 names: Mapping[str, Any] | Callable[[str], Any] | None = None,
                 functions: Mapping[str, Callable] | None = None,
                 operators: Mapping[type[ast.operator], Callable[[Any, Any], Any] | Callable[[Any], Any]] | None = None,
                 subformat: bool | string.Formatter | type[string.Formatter] | FormatProtocol = False,
                 raise_field_exceptions: bool = False,
                 ) -> None:
        super().__init__()
        #: Evaluator instance.
        self.evaluator: Evaluator | None = evaluate if _is_evaluator_object(evaluate) else None
        #: Evaluator class.
        self.evaluator_class: EvaluatorFactory | None = None
        if isclass(evaluate):
            self.evaluator_class = evaluate
        elif simple_eval and evaluate:
            if evaluate == 'simple':
                self.evaluator_class = SimpleEval
            elif callable(evaluate):
                self.evaluator_class = evaluate
            else:
                self.evaluator_class = EvalWithCompoundTypes
        #: Evaluator built-in names (kwargs). If no evaluator `names` are merged with `kwargs`.
        self.evaluator_names: Mapping[str, Any] | Callable[[str], Any] | None = names
        #: Evaluator built-in functions.
        self.evaluator_functions: Mapping[str, Callable] | None = functions
        #: Evaluator built-in operators.
        self.evaluator_operators = operators
        #: Try to evaluate field_name before get_field() if evaluator is set.
        self.evaluate_first: bool = evaluate_first
        #: Enable escape conversion `!e`.
        self.escape: bool = escape
        #: Raise exceptions in get_field() instead of returning missing value.
        self.raise_field_exceptions: bool = raise_field_exceptions
        #: Extended (and slower) format parser (allows use advanced expressions).
        self.extended: bool | None = extended
        #: Sub-formatter for nested format calls.
        self.subformater: FormatProtocol | None
        if subformat is True:
            self.subformater = self.format
        elif subformat is False or subformat is None:
            self.subformater = None
        elif isinstance(subformat, type):
            self.subformater = subformat().format
        elif callable(getattr(subformat, 'format', None)):
            if TYPE_CHECKING:
                assert isinstance(subformat, string.Formatter)
            self.subformater = subformat.format
        else:
            if TYPE_CHECKING:
                assert not isinstance(subformat, string.Formatter)
            self.subformater = subformat

    def parse(self, format_string: str) -> Iterable[tuple[str, str | None, str | None, str | None]]:
        """Loop over the format_string and return an iterable of tuples."""
        if self.extended:
            return fparser(format_string)
        if self.extended is False:
            return super().parse(format_string)

        def gen() -> Iterable[tuple[str, str | None, str | None, str | None]]:
            try:
                yield from super().parse(format_string)
            except Exception:
                # fallback to extended parser if default parser fails
                yield from fparser(format_string)

        return gen()

    def make_eval(self, *args, **kwargs) -> Evaluator:
        """Prepare the actual work of formatting."""
        if callable(self.evaluator_names):
            names = MultiDict(self.evaluator_names, kwargs)
        elif self.evaluator_names:
            names = {**self.evaluator_names, **kwargs}
        else:
            names = kwargs
        if self.evaluator_class:
            return self.evaluator_class(names=names, functions=self.evaluator_functions, operators=self.evaluator_operators)
        return SimpleEval(names=names, functions=self.evaluator_functions)

    @overload
    def vformat(self, format_string: LiteralString, args: Sequence[LiteralString], kwargs: Mapping[LiteralString, LiteralString]) -> LiteralString: ...

    @overload
    def vformat(self, format_string: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> str: ...

    def vformat(self, format_string, args, kwargs):
        """Do the actual work of formatting."""
        if callable(self.evaluator_names):
            names = MultiDict(self.evaluator_names, kwargs)
        elif self.evaluator_names:
            names = {**self.evaluator_names, **kwargs}
        else:
            names = kwargs
        if self.evaluator_class is not None or self.evaluator is not None:
            if self.evaluator_class is not None:
                self.evaluator = self.evaluator_class(names=names, functions=self.evaluator_functions, operators=self.evaluator_operators)
            return super().vformat(format_string, args, kwargs)
        return super().vformat(format_string, args, names)

    def convert_field(self, value: Any, conversion: str | None) -> Any:
        """Converts the value (returned by get_field()) given a conversion type."""
        if self.escape and conversion == 'e':
            esc = self._escape_trans
            return ''.join(esc.get(c, c) for c in str(value))
        return super().convert_field(value, conversion)

    def get_field(self, field_name: str, args: Sequence[Any], kwargs: Mapping[str, Any]) -> tuple[Any, str]:
        """Convert field_name as returned by parse() to an object to be formatted."""
        if self.evaluate_first and self.evaluator is not None:
            try:
                # evaluate expression in {...}
                value = self.evaluator.eval(field_name)
                return value, field_name
            except Exception:
                pass
        try:
            return super().get_field(field_name, args, kwargs)
        except Exception:
            pass
        value = MISSING
        suffix = ''
        if '=' in field_name:
            # support for f'{var=}'
            if (mch := self._RX_SHOW_EXPR.match(field_name)) is not None:
                field_name, suffix = mch.groups()
        if field_name.isdecimal():
            # missing positional argument
            try:
                value, new_field_name = self.missing_field(field_name, args, kwargs)
            except Exception:
                pass
        if value is MISSING and self.evaluator:
            try:
                # evaluate expression in {...}
                value = self.evaluator.eval(field_name)
            except (InvalidExpression, SyntaxError):
                # if valied try to expand field_name with format(), to support nested variables like a{b}
                if self.subformater is not None and ('{' in field_name and '}' in field_name):
                    try:
                        ex_field_name = self.subformater(field_name, *args, **kwargs)
                        value = self.evaluator.eval(ex_field_name)
                        field_name = ex_field_name
                    except (InvalidExpression, SyntaxError):
                        pass
            except Exception:
                if self.raise_field_exceptions:
                    raise
        if value is MISSING:
            value, new_field_name = self.missing_field(field_name, args, kwargs)
            if new_field_name:
                field_name = new_field_name
        if suffix:
            value = f'{field_name}{suffix}{value}'
        # return value, ()
        return value, field_name

    def missing_field(self, field_name: str, args, kwargs) -> tuple[Any, str]:
        """Return missing files, by default keep format string."""
        return '{%s}' % field_name, ''
        # return '{%s}' % field_name, field_name

    def format_field(self, value: Any, format_spec: str) -> str:
        """Call the global format() built-in, support for default values."""
        format_spec, sep, val = format_spec.partition('!!')
        unknown = isinstance(value, str) and value[:1] == '{' and value[-1:] == '}'
        if sep and unknown:
            try:
                if '::' in val:
                    value, sep, format_spec = val.partition('::')
                elif format_spec[-1:] in 'bcdoxX':
                    value = int(val)
                elif format_spec[-1:] in 'eEfFgG':
                    value = float(val)
                else:
                    value = val
            except ValueError:
                # format_spec = format_spec[:-1] + 's'
                format_spec = 's'
                value = val
        try:
            return super().format_field(value, format_spec)
        except ValueError:
            logger.warning(f'Field formating failed: value={value!r}, spec={format_spec!r}')
            if format_spec:
                if value[:1] == '{' and value[-1:] == '}':
                    return f'{value[:-1]}:{format_spec}}}'
                return f'{value}:{format_spec}'
            return f'{value}'

    def add_name(self, name: str, value: Any) -> None:
        """Register `name` in easy-eval names."""
        if self.evaluator_names is None:
            self.evaluator_names = {}
        if callable(self.evaluator_names):
            raise KeyError(f'Cannot add name to callable {self.__class__.__name__}.evaluator_names')
        self.evaluator_names[name] = value


safe_format = SafeFormatter().format
safe_xformat = SafeFormatter(extended=True).format

# fmt = SafeFormatter(extended=True, evaluate=SimpleEval, names=lambda k: 9, evaluate_first=True).format
# print(fmt('{1}', 1234))
# print(fmt('{a}.{b}.{c} / {x+1}', a=1, b=2, c=3, y=11))
