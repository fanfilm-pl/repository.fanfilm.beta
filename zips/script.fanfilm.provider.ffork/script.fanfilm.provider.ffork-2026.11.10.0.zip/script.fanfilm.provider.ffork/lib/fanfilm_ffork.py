"""
The provider add-on of the FanFilm fork scrapers (FanFilm 2 / 3 forks, e.g. `plugin.video.fanfilm.tele`, Kadr+): the
`ffork` handler of the FanFilm SDK; every installed add-on of the FanFilm fork structure is served.
"""

from ffsdk.xprovider import FforkXProvider


class FanFilmForks(FforkXProvider):
    """The FanFilm fork scrapers."""
