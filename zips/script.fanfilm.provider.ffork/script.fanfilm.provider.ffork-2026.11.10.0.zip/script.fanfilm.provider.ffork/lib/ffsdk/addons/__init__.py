"""
External Kodi add-ons: their import paths, their import namespaces (the add-on modules without clashes in one
interpreter), their scrapers found by the dialects.
"""
