"""
An add-on Kodi does not give (`xbmcaddon.Addon(id)` only of an enabled one): its info, settings and texts read from its
files, so the scrapers of an add-on disabled in Kodi (its service off) still work when the host searches them.

- `getAddonInfo()` from its `addon.xml`;
- the settings: the user values (`addon_data/<id>/settings.xml`, the format 2 and the old one) over the defaults of
  `resources/settings.xml`; a change is written at once (atomically: Kodi does not hold the file of a disabled add-on);
- `getLocalizedString()` from `strings.po` of the Kodi language (else English).
"""

from __future__ import annotations
import os
import re
from pathlib import Path
from threading import Lock
from typing import Any, Callable, ClassVar
from xml.etree import ElementTree as ET

#: The info keys from the root of `addon.xml` (Kodi key -> attribute).
ROOT_INFO: dict[str, str] = {'id': 'id', 'name': 'name', 'version': 'version', 'author': 'provider-name'}
#: The info keys from the metadata of `addon.xml` (Kodi key -> its tag).
METADATA_INFO: dict[str, str] = {'summary': 'summary', 'description': 'description', 'disclaimer': 'disclaimer', 'changelog': 'news'}
#: The `msgctxt "#<id>"` line of `strings.po`.
RX_PO_ID = re.compile(r'msgctxt\s+"#(\d+)"')
#: The `msgid` / `msgstr` line of `strings.po`.
RX_PO_TEXT = re.compile(r'(msgid|msgstr)\s+"(.*)"')


def _translate(path: str) -> str:
    """Return the real path of a `special://` path."""
    from xbmcvfs import translatePath
    return translatePath(path)


def _language() -> str:
    """Return the Kodi language folder suffix (`pl_pl`), English if unknown."""
    try:
        from xbmc import getLanguage, ISO_639_1
        code = getLanguage(ISO_639_1, True)  # e.g. `pl-PL`
    except Exception:  # no Kodi
        code = ''
    return code.lower().replace('-', '_') or 'en_gb'


class OfflineAddon:
    """The add-on object of an add-on Kodi does not give (disabled), from its files (see the module)."""

    def __init__(self, path: Path) -> None:
        """Read the add-on of the folder."""
        #: The add-on folder.
        self.path: Path = path
        #: The root of its `addon.xml`.
        self.xml: ET.Element = ET.parse(path / 'addon.xml').getroot()
        #: The add-on ID.
        self.id: str = self.xml.get('id', path.name)
        #: The profile (`special://profile/addon_data/<id>/`, as Kodi gives it).
        self.profile: str = f'special://profile/addon_data/{self.id}/'
        #: The user values of the settings (read once, written at once).
        self._values: dict[str, str] | None = None
        #: The defaults of the settings.
        self._defaults: dict[str, str] | None = None
        #: The texts by their IDs.
        self._texts: dict[int, str] | None = None
        #: Serializes the reads and the writes of the settings of the threads.
        self._lock = Lock()

    # --- info ---

    def getAddonInfo(self, id: str) -> str:  # noqa: A002  (the Kodi name)
        """Return an info of the add-on (`id`, `name`, `version`, `path`, `profile`, `icon`, `summary`...)."""
        key = id.lower()
        if key in ROOT_INFO:
            return self.xml.get(ROOT_INFO[key], '')
        if key == 'path':
            return str(self.path)
        if key == 'profile':
            return self.profile
        metadata = self.xml.find("./extension[@point='xbmc.addon.metadata']")
        if metadata is None:
            return ''
        if key in ('icon', 'fanart'):
            asset = metadata.find(f'./assets/{key}')
            return str(self.path / asset.text) if asset is not None and asset.text else ''
        if (tag := METADATA_INFO.get(key)) is not None:
            nodes = metadata.findall(f'./{tag}')
            lang = _language()
            node = next((node for node in nodes if node.get('lang', '').lower() == lang), None)
            if node is None:  # not `or`: an element without children is false
                node = next((node for node in nodes if node.get('lang', 'en_GB').lower() in ('en_gb', 'en')), None)
            return (node.text or '') if node is not None else ''
        return ''

    def getLocalizedString(self, id: int) -> str:  # noqa: A002  (the Kodi name)
        """Return the text of the add-on (its language, else English, else '')."""
        if self._texts is None:
            self._texts = self._read_texts()
        return self._texts.get(id, '')

    def _read_texts(self) -> dict[int, str]:
        """Return the texts of `strings.po` (the Kodi language, else English)."""
        for lang in (_language(), 'en_gb', 'en_us'):
            path = self.path / 'resources' / 'language' / f'resource.language.{lang}' / 'strings.po'
            if path.is_file():
                break
        else:
            return {}
        texts: dict[int, str] = {}
        tid, source = 0, ''
        for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
            if mch := RX_PO_ID.match(line):
                tid, source = int(mch[1]), ''
            elif tid and (mch := RX_PO_TEXT.match(line)):
                if mch[1] == 'msgid':
                    source = mch[2]
                else:
                    texts[tid] = mch[2] or source
                    tid = 0
        return texts

    # --- settings ---

    @property
    def settings_path(self) -> Path:
        """Return the file of the user settings."""
        return Path(_translate(self.profile)) / 'settings.xml'

    def _read_values(self) -> dict[str, str]:
        """Return the user values of the settings (the format 2: the text, the old one: `value`)."""
        try:
            root = ET.parse(self.settings_path).getroot()
        except (OSError, ET.ParseError):
            return {}
        return {node.get('id', ''): (node.text or '') if node.get('value') is None else node.get('value', '')
                for node in root.iter('setting') if node.get('id')}

    def _read_defaults(self) -> dict[str, str]:
        """Return the defaults of the settings of `resources/settings.xml` (`<default>` of the format 2, `default` of the old one)."""
        try:
            root = ET.parse(self.path / 'resources' / 'settings.xml').getroot()
        except (OSError, ET.ParseError):
            return {}
        defaults: dict[str, str] = {}
        for node in root.iter('setting'):
            if not (sid := node.get('id')):
                continue
            default = node.find('./default')
            defaults[sid] = (default.text or '') if default is not None else node.get('default', '')
        return defaults

    def getSetting(self, id: str) -> str:  # noqa: A002  (the Kodi name)
        """Return the value of the setting as a text ('' if unknown)."""
        with self._lock:
            if self._values is None:
                self._values = self._read_values()
            if id in self._values:
                return self._values[id]
            if self._defaults is None:
                self._defaults = self._read_defaults()
            return self._defaults.get(id, '')

    def getSettingBool(self, id: str) -> bool:  # noqa: A002  (the Kodi name)
        """Return the value of a boolean setting."""
        return self.getSetting(id).lower() in ('true', '1')

    def getSettingInt(self, id: str) -> int:  # noqa: A002  (the Kodi name)
        """Return the value of an integer setting (0 if not a number)."""
        return _number(int, self.getSetting(id))

    def getSettingNumber(self, id: str) -> float:  # noqa: A002  (the Kodi name)
        """Return the value of a number setting (0.0 if not a number)."""
        return _number(float, self.getSetting(id))

    def getSettingString(self, id: str) -> str:  # noqa: A002  (the Kodi name)
        """Return the value of a text setting."""
        return self.getSetting(id)

    def setSetting(self, id: str, value: str) -> None:  # noqa: A002  (the Kodi name)
        """Set the setting and write the user settings at once (atomically)."""
        with self._lock:
            if self._values is None:
                self._values = self._read_values()
            self._values[id] = str(value)
            self._write(self._values)

    def setSettingBool(self, id: str, value: bool) -> bool:  # noqa: A002  (the Kodi name)
        """Set a boolean setting."""
        self.setSetting(id, 'true' if value else 'false')
        return True

    def setSettingInt(self, id: str, value: int) -> bool:  # noqa: A002  (the Kodi name)
        """Set an integer setting."""
        self.setSetting(id, str(int(value)))
        return True

    def setSettingNumber(self, id: str, value: float) -> bool:  # noqa: A002  (the Kodi name)
        """Set a number setting."""
        self.setSetting(id, str(float(value)))
        return True

    def setSettingString(self, id: str, value: str) -> bool:  # noqa: A002  (the Kodi name)
        """Set a text setting."""
        self.setSetting(id, value)
        return True

    def getSettings(self) -> OfflineSettings:
        """Return the settings object (`xbmcaddon.Settings` of Kodi 20+)."""
        return OfflineSettings(self)

    def _write(self, values: dict[str, str]) -> None:
        """Write the user settings (the format 2) atomically."""
        root = ET.Element('settings', version='2')
        for sid, value in values.items():
            ET.SubElement(root, 'setting', id=sid).text = value
        path = self.settings_path
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
        ET.ElementTree(root).write(tmp, encoding='utf-8', xml_declaration=False)
        os.replace(tmp, path)


class OfflineSettings:
    """The settings object of an `OfflineAddon` (`xbmcaddon.Settings` of Kodi 20+: typed getters and setters, lists by `|`)."""

    #: The separator of the values of a list setting.
    LIST_SEPARATOR: ClassVar[str] = '|'

    def __init__(self, addon: OfflineAddon) -> None:
        """Bind the settings of the add-on."""
        #: The add-on.
        self.addon: OfflineAddon = addon

    def getBool(self, id: str) -> bool:  # noqa: A002  (the Kodi name)
        """Return a boolean setting."""
        return self.addon.getSettingBool(id)

    def getInt(self, id: str) -> int:  # noqa: A002  (the Kodi name)
        """Return an integer setting."""
        return self.addon.getSettingInt(id)

    def getNumber(self, id: str) -> float:  # noqa: A002  (the Kodi name)
        """Return a number setting."""
        return self.addon.getSettingNumber(id)

    def getString(self, id: str) -> str:  # noqa: A002  (the Kodi name)
        """Return a text setting."""
        return self.addon.getSetting(id)

    def getStringList(self, id: str) -> list[str]:  # noqa: A002  (the Kodi name)
        """Return a list setting of texts."""
        return [value for value in self.addon.getSetting(id).split(self.LIST_SEPARATOR) if value]

    def getBoolList(self, id: str) -> list[bool]:  # noqa: A002  (the Kodi name)
        """Return a list setting of booleans."""
        return [value.lower() in ('true', '1') for value in self.getStringList(id)]

    def getIntList(self, id: str) -> list[int]:  # noqa: A002  (the Kodi name)
        """Return a list setting of integers."""
        return [_number(int, value) for value in self.getStringList(id)]

    def getNumberList(self, id: str) -> list[float]:  # noqa: A002  (the Kodi name)
        """Return a list setting of numbers."""
        return [_number(float, value) for value in self.getStringList(id)]

    def setBool(self, id: str, value: bool) -> None:  # noqa: A002  (the Kodi name)
        """Set a boolean setting."""
        self.addon.setSettingBool(id, value)

    def setInt(self, id: str, value: int) -> None:  # noqa: A002  (the Kodi name)
        """Set an integer setting."""
        self.addon.setSettingInt(id, value)

    def setNumber(self, id: str, value: float) -> None:  # noqa: A002  (the Kodi name)
        """Set a number setting."""
        self.addon.setSettingNumber(id, value)

    def setString(self, id: str, value: str) -> None:  # noqa: A002  (the Kodi name)
        """Set a text setting."""
        self.addon.setSetting(id, value)

    def setStringList(self, id: str, values: list[str]) -> None:  # noqa: A002  (the Kodi name)
        """Set a list setting of texts."""
        self.addon.setSetting(id, self.LIST_SEPARATOR.join(values))

    def setBoolList(self, id: str, values: list[bool]) -> None:  # noqa: A002  (the Kodi name)
        """Set a list setting of booleans."""
        self.setStringList(id, ['true' if value else 'false' for value in values])

    def setIntList(self, id: str, values: list[int]) -> None:  # noqa: A002  (the Kodi name)
        """Set a list setting of integers."""
        self.setStringList(id, [str(int(value)) for value in values])

    def setNumberList(self, id: str, values: list[float]) -> None:  # noqa: A002  (the Kodi name)
        """Set a list setting of numbers."""
        self.setStringList(id, [str(float(value)) for value in values])


def _number(cast: Callable[[str], Any], text: str) -> Any:
    """Return the text as a number, zero if it is not one."""
    try:
        return cast(text)
    except ValueError:
        return cast('0')


def kodi_addon(addon_id: str, path: Path) -> Any:
    """Return the add-on object: of Kodi (an enabled add-on), else from its files (`OfflineAddon`)."""
    from xbmcaddon import Addon
    try:
        return Addon(addon_id)
    except RuntimeError:  # an unknown add-on: disabled in Kodi (or not known to Kodi yet)
        return OfflineAddon(path)
