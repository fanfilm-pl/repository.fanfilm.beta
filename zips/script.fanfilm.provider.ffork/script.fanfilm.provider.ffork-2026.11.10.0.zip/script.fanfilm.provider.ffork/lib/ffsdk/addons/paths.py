"""
The import paths of a Kodi add-on: its own (the root, the `xbmc.python.module` libraries of `addon.xml`) and of the
add-ons it requires.
"""

from __future__ import annotations
from pathlib import Path
from xbmcvfs import translatePath
from ..log import log


def read_addon_xml(addon_path: Path) -> tuple[list[Path], list[tuple[str, bool]]]:
    """Return the `xbmc.python.module` libraries and the required add-ons (ID, optional) of the add-on (an error raised)."""
    from xml.etree import ElementTree as ET
    libs: list[Path] = []
    requires: list[tuple[str, bool]] = []
    for node in ET.parse(addon_path / 'addon.xml').getroot():
        if node.tag == 'extension' and node.attrib.get('point') == 'xbmc.python.module' and (lib := node.attrib.get('library')):
            libs.append(addon_path / lib)
        elif node.tag == 'requires':
            requires += [(sub, req.attrib.get('optional', 'false').lower() == 'true')
                         for req in node if req.tag == 'import' and (sub := req.attrib.get('addon'))]
    return libs, requires


def addon_paths(addon_id: str, *, path: Path | None = None) -> tuple[list[Path], list[Path]]:
    """Return the import paths of an add-on: its own (root, `xbmc.python.module` libraries) and of its required imports."""

    def read_xml(addon_path: Path, opt: bool) -> tuple[list[Path], list[tuple[str, bool]]]:
        """Return the libraries and the required add-ons (id, optional) of the add-on."""
        try:
            return read_addon_xml(addon_path)
        except Exception as e:
            if not opt:
                log.warning(f'{addon_id}: Error reading addon.xml from {addon_path / "addon.xml"}: {e}')
        return [], []

    def own(addon_path: Path, opt: bool) -> tuple[list[Path], list[tuple[str, bool]]]:
        """Return the own paths (root first, so `resources.lib...` resolves) and the required add-ons."""
        if not addon_path.is_dir():
            return [], []  # not installed (eg. kodi builtin like `xbmc.python`) — nothing to import
        libs, requires = read_xml(addon_path, opt)
        return [addon_path, *libs], requires

    if path is None:
        path = Path(translatePath(f'special://home/addons/{addon_id}'))
    addons_path = Path(translatePath('special://home/addons'))
    paths, requires = own(path, False)
    dependencies: list[Path] = []
    seen: set[str] = {addon_id}
    while requires:
        sub, opt = requires.pop(0)
        if sub in seen:
            continue
        seen.add(sub)
        sub_paths, sub_requires = own(addons_path / sub, opt)
        dependencies += sub_paths
        requires += sub_requires
    return paths, dependencies


def kodi_import_paths(addon_path: Path) -> list[Path]:
    """
    Return the paths Kodi puts on `sys.path` of a script importing the add-on: the `xbmc.python.module` libraries of
    the add-ons it requires (recursively, optional too, the installed ones; not its own).
    """
    addons_path = addon_path.parent
    paths: list[Path] = []
    seen: set[str] = {addon_path.name}
    try:
        _, requires = read_addon_xml(addon_path)
    except Exception:
        return []
    while requires:
        sub, _ = requires.pop(0)
        if sub in seen:
            continue
        seen.add(sub)
        try:
            libs, sub_requires = read_addon_xml(addons_path / sub)
        except Exception:  # not installed (e.g. Kodi builtin `xbmc.python`), broken
            continue
        paths += libs
        requires += sub_requires
    return paths
