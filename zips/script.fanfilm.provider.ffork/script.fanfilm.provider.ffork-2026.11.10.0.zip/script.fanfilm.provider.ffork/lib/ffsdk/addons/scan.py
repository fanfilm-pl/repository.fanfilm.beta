"""
The scrapers of an external add-on found by the dialects: the scraper folders, the entry of their package and the
methods a scraper file defines (a heuristic of the file text, no import), the classes a module registers (`register()`,
its syntax tree, no import); the scrapers searched by default (a setting of the add-on); a scraper module loaded in the
namespace of its add-on.
"""

from __future__ import annotations
import ast
import io
import re
import tokenize
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Iterator
from attrs import frozen
from .namespace import addon_namespace
from .paths import addon_paths


@frozen(kw_only=True)
class Dialect:
    """A scraper API of external add-ons: where its scrapers are, how a scraper file is known."""

    #: The dialect ID (`ffork`, `fenom`), the handler of its provider add-on.
    id: str
    #: The scraper folders (a group: `pl`, `torrents`...; or a package of scrapers itself), globs relative to the add-on root.
    paths: tuple[str, ...]
    #: Method sets: a scraper file defines all methods of one of them.
    methods: tuple[tuple[str, ...], ...]
    #: The text of the entry of the scraper package (`__init__.py` of a folder of `paths` or of its parent), '' - none.
    entry: str = ''
    #: The setting of the add-on which switches a scraper off (`{name}`: the scraper name; off only if 'false'), '' - none (all searched).
    setting: str = ''


#: Scraper dialects, the first matching one wins.
DIALECTS: tuple[Dialect, ...] = (
    # the FanFilm forks: FanFilm 2 (`resources/lib`) and FanFilm 3 forks (`lib`), the old API or the new `find` API
    # (a scraper on unless `provider.<name>` is off: FanFilm `settings.get('provider.<name>', default=True)`)
    Dialect(id='ffork', paths=('resources/lib/sources/[!_.]*', 'lib/sources/[!_.]*'),
            methods=(('find', 'resolve'), ('movie', 'sources', 'resolve'), ('episode', 'sources', 'resolve')), setting='provider.{name}'),
    # the Fenom family modules `<package>.sources()`: the groups `lib/<package>/sources_<package>/<group>` (CocoScrapers,
    # Fenom, Classy) or the package itself (POV); a scraper on by `provider.<name>` (their `enabledCheck()`)
    Dialect(id='fenom', paths=('lib/[!_.]*/sources_*/[!_.]*', 'lib/[!_.]*'), methods=(('sources',),), entry='\ndef sources(',
            setting='provider.{name}'),
)

#: The class of a scraper file (`class source:`, `class source(SourceRegistry):`).
RX_SOURCE_CLASS = re.compile(r'^class source\b\s*[:(]', re.MULTILINE)
#: The function of a module registering its scraper classes (FanFilm 3: `register(sources, group)`).
RX_REGISTER = re.compile(r'^def register\(', re.MULTILINE)


@frozen(kw_only=True)
class Scraper:
    """A scraper found in an add-on: its file, its class (a module may register several) and its name."""

    #: The add-on folder.
    addon: Path
    #: The scraper file.
    path: Path
    #: The dialect.
    dialect: Dialect
    #: The scraper class of the module.
    cls: str = 'source'
    #: The scraper name: the file name, of a registered class its `PROVIDER`.
    name: str = ''

    @property
    def provider(self) -> str:
        """Return the scraper name (the file name if not given)."""
        return self.name or self.path.stem

    @property
    def key(self) -> str:
        """Return the key of the scraper: `<group>/<name>` (the group: its folder, e.g. `pl`; a package of scrapers: its name)."""
        return f'{self.path.parent.name}/{self.provider}'

    def create(self) -> Any:
        """Return a new instance of the scraper (its module loaded in the namespace of its add-on, `load_scraper()`)."""
        return getattr(load_scraper(self.addon, self.path), self.cls)()


def registered_classes(text: str) -> dict[str, str]:
    """
    Return the scraper classes a module registers (`register()`): the classes with their own `PROVIDER` text named in
    its body, class -> `PROVIDER` in the order of `register()`; its conditions (settings) are not evaluated.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return {}
    providers: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for item in node.body:
                target = item.targets[0] if isinstance(item, ast.Assign) and len(item.targets) == 1 else getattr(item, 'target', None)
                value = getattr(item, 'value', None)
                if (isinstance(target, ast.Name) and target.id == 'PROVIDER' and isinstance(value, ast.Constant)
                        and isinstance(value.value, str) and value.value):
                    providers[node.name] = value.value
    register = next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'register'), None)
    if register is None:
        return {}
    names = (node.id for node in ast.walk(register) if isinstance(node, ast.Name) and node.id in providers)
    return {name: providers[name] for name in dict.fromkeys(names)}


def source_text(path: Path) -> str:
    """Return the text of a Python file in its declared encoding (PEP 263, else UTF-8; a bad byte replaced), '' if it can not be read."""
    try:
        data = path.read_bytes()
    except OSError:
        return ''
    try:
        encoding = tokenize.detect_encoding(io.BytesIO(data).readline)[0]
    except SyntaxError:  # an unknown encoding in the cookie
        encoding = 'utf-8'
    return data.decode(encoding, errors='replace')


def file_scrapers(addon_path: Path, path: Path, dialect: Dialect) -> list[Scraper]:
    """
    Return the scrapers of the file of the dialect (heuristically: the methods of the dialect in its text): the classes
    it registers (`register()`), else its `class source`; none if it is not a scraper file.
    """
    data = source_text(path)
    if not any(all(f'def {method}(self,' in data for method in methods) for methods in dialect.methods):
        return []
    if RX_REGISTER.search(data):
        return [Scraper(addon=addon_path, path=path, dialect=dialect, cls=cls, name=name) for cls, name in registered_classes(data).items()]
    if RX_SOURCE_CLASS.search(data) and 'def __init__(self)' in data:
        return [Scraper(addon=addon_path, path=path, dialect=dialect)]
    return []


def _has_entry(folder: Path, dialect: Dialect, addon_path: Path) -> bool:
    """Check if the scraper folder is in a package with the entry of the dialect (the folder or its parent up to the add-on)."""
    if not dialect.entry:
        return True
    for path in (folder, *folder.parents):
        if path == addon_path:
            return False
        if dialect.entry in source_text(path / '__init__.py'):
            return True
    return False


def scan_scrapers(addon_path: Path) -> Iterator[Scraper]:
    """
    Yield the scrapers found in the add-on with their dialect (`DIALECTS`); a registered class takes the key of a
    scraper file of the same name in its folder.
    """
    for dialect in DIALECTS:
        for folder in (path for pattern in dialect.paths for path in addon_path.glob(pattern)):
            if folder.is_dir() and _has_entry(folder, dialect, addon_path):
                found: dict[str, Scraper] = {}
                for path in sorted(folder.glob('[!_.]*.py')):
                    for scraper in file_scrapers(addon_path, path, dialect):
                        if scraper.name or scraper.key not in found:
                            found[scraper.key] = scraper
                yield from found.values()


def default_scrapers(addon_path: Path, scrapers: Iterable[Scraper]) -> frozenset[str]:
    """
    Return the keys of the scrapers searched by default: all but those off by the setting of their dialect in the
    add-on (its current value; of its files if it is disabled in Kodi; a scraper without the setting is on); all if the
    settings can not be read.
    """
    scrapers = list(scrapers)
    keys = frozenset(scraper.key for scraper in scrapers)
    if not any(scraper.dialect.setting for scraper in scrapers):
        return keys
    try:
        from .offline import kodi_addon
        get = kodi_addon(addon_path.name, addon_path).getSetting
        return frozenset(scraper.key for scraper in scrapers
                         if not scraper.dialect.setting or get(scraper.dialect.setting.format(name=scraper.provider)) != 'false')
    except Exception:  # no Kodi, a broken add-on
        return keys


def load_scraper(addon_path: Path, scraper_path: Path) -> ModuleType:
    """
    Return the scraper module loaded in the import namespace of its add-on, named from its library (e.g.
    `cocoscrapers.…` of `lib`), so it is not loaded twice. An import error is raised.
    """
    own, dependencies = addon_paths(addon_path.name, path=addon_path)
    base = max((path for path in own if path in scraper_path.parents), key=lambda path: len(path.parts), default=addon_path)
    module = scraper_path.relative_to(base).with_suffix('').as_posix().replace('/', '.')
    return addon_namespace(addon_path.name, own, dependencies).load(module)
