"""
Import namespace of an external add-on: its modules are loaded in FanFilm's interpreter without clashes.

Kodi runs scripts in sub-interpreters, `multiprocessing` can not be used there (see notes/external-providers.md),
so scrapers of other add-ons run in FanFilm threads like the native providers. Many such add-ons (FanFilm forks) use
the same top-level names (`resources`, `ptw`, ...), so each add-on gets its own namespace:

- its modules live under `_ffaddon_<addon_id>.<name>`, `sys.path` is not changed (entries the add-on code adds move
  to the namespace);
- every module of the namespace has its own `__import__` (module `__builtins__`), which redirects the add-on names
  to the namespace (absolute `from ptw.libraries import x`, `import ptw.x as y`; relative imports work as usual);
- Kodi modules (`xbmc`, `xbmcgui`, ...) are copies of the add-on: its patches (e.g. `xbmc.log = log` of FanFilm forks)
  stay in the add-on; `xbmcaddon.Addon()` without an id is the add-on itself, not FanFilm; Kodi does not give a disabled
  add-on, then the add-on itself is read from its files (`OfflineAddon`);
- names importable without the add-on (e.g. `six`, `requests` of FanFilm's dependencies) stay shared;
- `runpy` is a copy of the add-on too: the code it runs (e.g. `local.py` of a FanFilm fork) imports from the namespace.

The namespace modules are removed at the interpreter end (left `xbmcaddon.Addon` objects can hang Kodi on exit). The
namespace clears the modules it has loaded, not the ones found in `sys.modules`: Kodi 22 clears `sys.modules` before
`Py_EndInterpreter` (where `atexit` runs) and checks the left Kodi objects after it, while the modules can still be held
(e.g. `xbmc.log` of the add-on copy patched by the add-on holds its logger module and all it imports).
"""

from __future__ import annotations

import atexit
import builtins
import gc
import importlib.abc
import importlib.machinery
import importlib.util
import os
import sys
from pathlib import Path
from threading import Lock
from types import FunctionType, ModuleType
from typing import Any, Iterable, Sequence, TYPE_CHECKING

if TYPE_CHECKING:
    from importlib.machinery import ModuleSpec

#: Kodi modules an add-on gets as its own copies (`AddonNamespace.kodi_modules`).
KODI_MODULES: tuple[str, ...] = ('xbmc', 'xbmcaddon', 'xbmcdrm', 'xbmcgui', 'xbmcplugin', 'xbmcvfs')
#: The modules an add-on gets as its own copies: the Kodi ones and `runpy` (the code it runs imports from the namespace).
COPIED_MODULES: tuple[str, ...] = (*KODI_MODULES, 'runpy')

#: All add-on namespaces of the interpreter, by the add-on id.
_namespaces: dict[str, AddonNamespace] = {}
_lock = Lock()


def _module_names(paths: Iterable[Path]) -> set[str]:
    """Return top-level module and package names found in `paths`."""
    names: set[str] = set()
    for path in paths:
        try:
            entries = list(path.iterdir())
        except OSError:
            continue
        for entry in entries:
            if entry.is_dir() and entry.name.isidentifier():
                names.add(entry.name)                    # a package or a namespace package
            elif entry.suffix == '.py' and entry.stem.isidentifier():
                names.add(entry.stem)
    return names


class _NamespaceLoader(importlib.abc.Loader):
    """Loader of a namespace module: the module gets the namespace builtins before it is executed."""

    def __init__(self, loader: importlib.abc.Loader, namespace: AddonNamespace) -> None:
        self.loader = loader
        self.namespace = namespace

    def __getattr__(self, name: str) -> Any:
        """Other methods of the wrapped loader (`get_data`, `get_source`, `is_package`, `get_resource_reader`...)."""
        if name == 'loader':  # not set yet (e.g. a copy), no recursion
            raise AttributeError(name)
        return getattr(self.loader, name)

    def create_module(self, spec: ModuleSpec) -> ModuleType | None:
        """Create the module by the wrapped loader (e.g. a C extension module), None: the default creation."""
        return self.loader.create_module(spec)

    def exec_module(self, module: ModuleType) -> None:
        """Execute the module with the namespace `__import__`; `sys.path` entries it adds move to the namespace."""
        module.__builtins__ = self.namespace.builtins
        self.namespace.modules.append(module)
        try:
            self.loader.exec_module(module)  # type: ignore[attr-defined]
        finally:
            self.namespace.adopt_paths()


class AddonNamespace(importlib.abc.MetaPathFinder):
    """Import namespace of one external add-on."""

    def __init__(self, addon_id: str, paths: Sequence[Path], dependency_paths: Sequence[Path] = ()) -> None:
        #: Add-on id (`xbmcaddon.Addon()` default).
        self.addon_id: str = addon_id
        #: Module prefix of the add-on.
        self.prefix: str = '_ffaddon_' + ''.join(c if c.isalnum() else '_' for c in addon_id)
        #: Add-on paths (its root and libraries), then libraries of its dependencies.
        self.paths: list[Path] = [*paths, *dependency_paths]
        #: The add-on object from its files when Kodi does not give it (disabled), made once.
        self._offline: Any = None
        #: Folders of the add-on (with a separator): `sys.path` entries there are adopted; not of its dependencies, Kodi
        #: puts the shared ones (e.g. `script.module.requests`) in FanFilm's `sys.path`.
        self._roots: tuple[str, ...] = tuple(os.path.join(str(path), '') for path in paths)
        #: Top-level names redirected to the namespace: all of the add-on, of its dependencies only those not
        #: importable without the add-on (e.g. FanFilm's own `requests`, `six` stay shared).
        self.names: frozenset[str] = frozenset(
            (_module_names(paths) | {name for name in _module_names(dependency_paths) if not self._importable(name)})
            - set(COPIED_MODULES))
        package = ModuleType(self.prefix)
        package.__path__ = [str(path) for path in self.paths]
        package.__package__ = self.prefix
        sys.modules[self.prefix] = package
        #: Kodi modules of the add-on, by the name: created at once, two threads of the add-on never get two copies.
        self.kodi_modules: dict[str, ModuleType] = {name: self._kodi_module(name) for name in COPIED_MODULES}
        #: Modules loaded by the namespace (cleared by `close()`, even if they are no longer in `sys.modules`).
        self.modules: list[ModuleType] = []
        #: Builtins of the namespace modules.
        self.builtins: dict[str, Any] = {**vars(builtins), '__import__': self._import}

    def __repr__(self) -> str:
        return f'AddonNamespace({self.addon_id!r})'

    @staticmethod
    def _importable(name: str) -> bool:
        """Check if a top-level name is importable without the add-on (FanFilm, its dependencies, stdlib)."""
        if name in sys.modules or name in sys.builtin_module_names:
            return True
        try:
            return importlib.machinery.PathFinder.find_spec(name) is not None
        except (ImportError, ValueError):
            return False

    def _kodi_module(self, name: str) -> ModuleType:
        """
        Return a copy of the module for the add-on: `xbmcaddon.Addon()` without an id is the add-on, `runpy` runs the code
        with the namespace imports.
        """
        kodi = importlib.import_module(name)
        module = ModuleType(name)
        module.__dict__.update(vars(kodi))
        if name == 'runpy':

            def run_path(path_name: str, init_globals: dict[str, Any] | None = None, run_name: str | None = None) -> dict[str, Any]:
                """`runpy.run_path()` with the namespace imports (the builtins of the namespace in its globals)."""
                return kodi.run_path(path_name, {**(init_globals or {}), '__builtins__': self.builtins}, run_name)

            module.run_path = run_path  # type: ignore[attr-defined]
            return module
        if name != 'xbmcaddon':
            return module
        addon_id = self.addon_id

        def Addon(id: str | None = None) -> Any:
            """
            Return the add-on object, the namespace add-on by default (from its files if Kodi does not give it: disabled;
            Kodi is not asked again, its refusal is an error line in its log).
            """
            if self._offline is not None and id in (None, addon_id):
                return self._offline
            try:
                return kodi.Addon(id or addon_id)
            except RuntimeError:  # an unknown add-on
                if id not in (None, addon_id) or not self.paths:
                    raise
                if self._offline is None:
                    from .offline import OfflineAddon
                    self._offline = OfflineAddon(self.paths[0])
                return self._offline

        module.Addon = Addon  # type: ignore[attr-defined]
        return module

    def _import(self, name: str, globals: Any = None, locals: Any = None, fromlist: Sequence[str] = (), level: int = 0) -> Any:
        """`__import__` of the namespace modules: the add-on names are imported from the namespace."""
        if level == 0:
            self.adopt_paths()  # the module may have just added a path and import from it
            top = name.partition('.')[0]
            if top in self.kodi_modules:
                return self.kodi_modules[top]
            if top in self.names:
                module = builtins.__import__(f'{self.prefix}.{name}', globals, locals, fromlist, 0)
                return module if fromlist else sys.modules[f'{self.prefix}.{top}']
        return builtins.__import__(name, globals, locals, fromlist, level)

    def find_spec(self, fullname: str, path: Sequence[str] | None = None, target: ModuleType | None = None) -> ModuleSpec | None:
        """Find a namespace module in the add-on paths."""
        if not fullname.startswith(self.prefix + '.'):
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is not None and spec.loader is not None:   # a namespace package (no __init__.py) has no loader
            spec.loader = _NamespaceLoader(spec.loader, self)
        return spec

    def adopt_paths(self) -> None:
        """
        Move `sys.path` entries in the add-on folders (e.g. FanFilm 3 forks add their `lib/3rd`) to the namespace, as
        the dependency paths: else they would shadow FanFilm's own modules.
        """
        # ponytail: two threads may adopt the same entry (a duplicate in `__path__`, harmless), a lock if it matters
        if not (paths := [path for path in sys.path if isinstance(path, str) and (path + os.sep).startswith(self._roots)]):
            return
        sys.path[:] = [path for path in sys.path if path not in paths]
        new = [path for path in paths if Path(path) not in self.paths]
        self.paths.extend(Path(path) for path in new)
        sys.modules[self.prefix].__path__.extend(new)
        self.names |= {name for name in _module_names(Path(path) for path in new) if not self._importable(name)}

    def load(self, module: str) -> ModuleType:
        """Import a module of the add-on (e.g. `resources.lib.sources.pl.cda`)."""
        return importlib.import_module(f'{self.prefix}.{module}')

    def close(self) -> None:
        """Remove the namespace: its finder and modules (their globals are cleared)."""
        if self in sys.meta_path:
            sys.meta_path.remove(self)
        for name in [name for name in sys.modules if name == self.prefix or name.startswith(self.prefix + '.')]:
            sys.modules.pop(name, None)
        modules, self.modules = self.modules, []
        for module in modules:
            module.__dict__.clear()


def addon_namespace(addon_id: str, paths: Sequence[Path], dependency_paths: Sequence[Path] = ()) -> AddonNamespace:
    """Return the import namespace of the add-on (one per interpreter), see `AddonNamespace`."""
    with _lock:
        namespace = _namespaces.get(addon_id)
        if namespace is None:
            namespace = _namespaces[addon_id] = AddonNamespace(addon_id, paths, dependency_paths)
            sys.meta_path.insert(0, namespace)
        return namespace


@atexit.register
def close_namespaces() -> None:
    """
    Remove all add-on namespaces (at the interpreter end): clear the globals of the add-on functions too (copies of
    module globals, e.g. methods generated by attrs), collect the add-on objects left in cycles.
    """
    with _lock:
        prefixes = tuple(namespace.prefix + '.' for namespace in _namespaces.values())
        for namespace in _namespaces.values():
            namespace.close()
        _namespaces.clear()
    if prefixes:
        for obj in gc.get_objects():
            if isinstance(obj, FunctionType) and isinstance(module := obj.__module__, str) and module.startswith(prefixes):
                obj.__globals__.clear()
        gc.collect()  # the cycles: Kodi 22 checks the left Kodi objects before a later GC frees them (live: 3 x Addon left)
