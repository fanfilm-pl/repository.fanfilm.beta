"""
The network of the SDK: the HTTPS connections of `requests` share the TLS contexts of the interpreter.

`requests` 2.31 (Kodi) gives urllib3 no TLS context: urllib3 makes one for every HTTPS connection and loads the CA
bundle into it (the system store when not verified), ~0.25-1 MB of native memory each, so a search with tens of providers
at once keeps a peak of tens of MB in the process. `requests` 2.32 has one context loaded once, in pools of their own
(the context is a key of the pool); `share_tls_contexts()` does the same for the older `requests`, for the verified
connections and the not verified ones (a context of each mode: urllib3 sets its mode on the context of a connection).

`drop_cut_connections()`: a pooled connection whose socket `cut_sockets()` closed (Windows) is dropped, not reused.
"""

from __future__ import annotations
from threading import local
from typing import Any, TYPE_CHECKING
if TYPE_CHECKING:
    from ssl import SSLContext
    from requests import PreparedRequest, Response
    from requests.adapters import HTTPAdapter
    from urllib3 import HTTPConnectionPool
    from urllib3.connection import HTTPConnection

#: The TLS mode of the current `HTTPAdapter.send()` of the thread (`verify`, `cert`).
_request = local()
#: The shared TLS contexts of the interpreter by `verify` (True: the default CA bundle, False: not verified), made at the first use.
_contexts: dict[bool, SSLContext] = {}


def tls_context(verify: bool) -> SSLContext:
    """Return the TLS context of the interpreter for the HTTPS connections verified with the default CA bundle or not verified."""
    if (context := _contexts.get(verify)) is None:
        from ssl import CERT_NONE, CERT_REQUIRED
        from urllib3.util.ssl_ import create_urllib3_context
        context = create_urllib3_context(cert_reqs=CERT_REQUIRED if verify else CERT_NONE)  # the settings of the urllib3 own ones
        if verify:
            from requests.utils import DEFAULT_CA_BUNDLE_PATH, extract_zipped_paths
            context.load_verify_locations(extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH))
        context = _contexts.setdefault(verify, context)  # two threads at once: one context kept
    return context


def _shared_context(adapter: HTTPAdapter, url: str, proxies: dict[str, str] | None) -> SSLContext | None:
    """Return the shared TLS context of the connection of the current `send()`, None if it keeps its own one."""
    from requests.utils import select_proxy
    verify, cert = getattr(_request, 'verify', None), getattr(_request, 'cert', None)
    if (verify is not True and verify is not False) or cert or not url.lower().startswith('https:'):
        return None  # no send(), an own CA bundle, a client certificate, no TLS
    if select_proxy(url, proxies) or adapter.poolmanager.connection_pool_kw.get('ssl_context'):
        return None  # a proxy, the own context of the adapter
    return tls_context(verify)


def share_tls_contexts() -> None:
    """
    Make the HTTPS connections of `requests` in this interpreter share its TLS contexts (`tls_context()`), see the module.

    Replaces `send`, `get_connection` and `cert_verify` of `requests.adapters.HTTPAdapter` (the class of this interpreter),
    once. Nothing with `requests` 2.32+ (its own shared context) or without `requests`. A connection with an own CA bundle,
    a client certificate or a proxy keeps its own context as before.
    """
    try:
        from requests.adapters import HTTPAdapter
    except ImportError:
        return
    if (getattr(HTTPAdapter, '_ff_shared_tls', False) or hasattr(HTTPAdapter, 'get_connection_with_tls_context')
            or not hasattr(HTTPAdapter, 'get_connection')):
        return
    orig_send, orig_get_connection, orig_cert_verify = HTTPAdapter.send, HTTPAdapter.get_connection, HTTPAdapter.cert_verify

    def send(self: HTTPAdapter, request: PreparedRequest, stream: bool = False, timeout: Any = None, verify: bool | str = True,
             cert: Any = None, proxies: dict[str, str] | None = None) -> Response:
        """Send the request, its TLS mode known to `get_connection()` meanwhile."""
        prev_verify, prev_cert = getattr(_request, 'verify', None), getattr(_request, 'cert', None)
        _request.verify, _request.cert = verify, cert
        try:
            return orig_send(self, request, stream=stream, timeout=timeout, verify=verify, cert=cert, proxies=proxies)
        finally:
            _request.verify, _request.cert = prev_verify, prev_cert

    def get_connection(self: HTTPAdapter, url: str, proxies: dict[str, str] | None = None) -> HTTPConnectionPool:
        """Return the pool of the shared TLS context of the request (a pool of its own), else the pool as before."""
        if (context := _shared_context(self, url, proxies)) is not None:
            return self.poolmanager.connection_from_url(url, pool_kwargs={'ssl_context': context})
        return orig_get_connection(self, url, proxies)

    def cert_verify(self: HTTPAdapter, conn: HTTPConnectionPool, url: str, verify: bool | str, cert: Any) -> None:
        """Set the verification of the pool: a pool of a shared context has one mode and no CA bundle to load again."""
        context = getattr(conn, 'conn_kw', {}).get('ssl_context')
        shared = next((mode for mode, ctx in _contexts.items() if ctx is context), None) if context is not None else None
        if shared is None:
            orig_cert_verify(self, conn, url, verify, cert)
            return
        conn.cert_reqs = 'CERT_REQUIRED' if shared else 'CERT_NONE'  # type: ignore[attr-defined]
        conn.ca_certs = conn.ca_cert_dir = conn.cert_file = conn.key_file = None  # type: ignore[attr-defined]

    HTTPAdapter.send = send  # type: ignore[method-assign]
    HTTPAdapter.get_connection = get_connection  # type: ignore[method-assign]
    HTTPAdapter.cert_verify = cert_verify  # type: ignore[method-assign]
    HTTPAdapter._ff_shared_tls = True  # type: ignore[attr-defined]


def drop_cut_connections() -> None:
    """
    Make the urllib3 pools of this interpreter drop a connection with a closed socket handle, not reuse it.

    `cut_sockets()` on Windows closes the handle of a socket (also of an idle pooled connection of a stopped thread),
    its `fileno()` is -1 and the dropped connection check of the pool (poll / select) raises ValueError, which is not
    a network error of `requests`: the next request of the pool failed. Replaces `is_connection_dropped` of
    `urllib3.connectionpool` (urllib3 1.26 and 2.x look it up there at every reuse); again is the same, the original one
    is read from `urllib3.util.connection`. Nothing without urllib3.
    """
    try:
        from urllib3 import connectionpool
        from urllib3.util.connection import is_connection_dropped as orig_is_connection_dropped
    except ImportError:
        return

    def is_connection_dropped(conn: HTTPConnection) -> bool:
        """Return True if the connection is dropped (also its socket handle closed) and must not be reused."""
        sock = getattr(conn, 'sock', None)
        return (sock is not None and sock.fileno() < 0) or orig_is_connection_dropped(conn)

    connectionpool.is_connection_dropped = is_connection_dropped  # type: ignore[attr-defined]
