"""
The search query: what is searched (a movie or an episode), built once by the host for all providers.

The movie / show part (`ids`, `title`, `aliases`, `year`) is of the movie or of the show of the episode; the episode part
(`season`, `episode`, `episode_ids`, `episode_title`...) only for an episode. A missing key is unknown.
"""

from __future__ import annotations
from typing import Literal
from typing_extensions import TypedDict, TypeAlias


#: What is searched.
QueryType: TypeAlias = Literal['movie', 'episode']


class QueryIds(TypedDict, total=False):
    """External IDs."""

    #: IMDb (`tt…`).
    imdb: str
    #: TMDB.
    tmdb: int
    #: TVDB.
    tvdb: int
    #: Trakt.
    trakt: int


class QueryTitle(TypedDict, total=False):
    """The titles of the movie / show."""

    #: In the language of the query (`Query.lang`).
    local: str
    #: In English.
    english: str
    #: The original one.
    original: str


class QueryAlias(TypedDict):
    """A title alias: the original title (`country`: `original`) and the titles of the countries."""

    #: The title.
    title: str
    #: The country (ISO 3166-1) or `original`.
    country: str


class AnimeCour(TypedDict, total=False):
    """An anime cour (a Kitsu season): IDs of the anime sites, its title and episodes."""

    #: Kitsu.
    kitsu_id: int
    #: MyAnimeList.
    mal_id: int | None
    #: AniList.
    anilist_id: int | None
    #: The romanized title (`en_jp`).
    title: str
    #: Episodes (0: a movie).
    ep_count: int
    #: The first air date (ISO).
    start_date: str | None
    #: The last air date (ISO).
    end_date: str | None
    #: `TV`, `OVA`, `movie`...
    subtype: str


class QueryAnime(TypedDict, total=False):
    """Anime data (Kitsu)."""

    #: The cours in order (a movie: the first one).
    cours: list[AnimeCour]


class Query(TypedDict, total=False):
    """The search query."""

    #: What is searched.
    type: QueryType
    #: IDs of the movie / show.
    ids: QueryIds
    #: IDs of the episode.
    episode_ids: QueryIds
    #: The titles of the movie / show.
    title: QueryTitle
    #: The language of the local title (ISO 639-1).
    lang: str
    #: Title aliases, the original title first.
    aliases: list[QueryAlias]
    #: The year of the movie / show.
    year: int
    #: The release date of the movie / the first air date of the show (also for an episode) (ISO).
    premiered: str | None
    #: The air date of the episode (ISO).
    episode_aired: str
    #: The season number.
    season: int
    #: The episode number.
    episode: int
    #: The episode title.
    episode_title: str
    #: The number of the seasons of the show.
    total_seasons: int
    #: The episode number counted over the seasons.
    absolute_episode: int
    #: The number of the episodes of the season.
    season_episodes: int
    #: Production countries (ISO 3166-1).
    countries: list[str]
    #: Original languages (ISO 639-1).
    original_languages: list[str]
    #: Duration in seconds.
    duration: int
    #: Anime data.
    anime: QueryAnime
