"""
The protocol data: JSON dicts. A missing key is unknown (the host takes its default), never "no".
"""

from __future__ import annotations
from typing import Any, Literal, Union
from typing_extensions import TypedDict, TypeAlias, NotRequired


#: How to play the stream: the host decides (auto), as it is (direct), by InputStream Adaptive (isa).
PlayMode: TypeAlias = Literal['auto', 'direct', 'isa']
#: Why the link does not open: dead (removed), no transfer left, an account problem, another error.
ResolveErrorKind: TypeAlias = Literal['dead', 'no_transfer', 'account', 'error']
#: Why a provider has no complete result: out of time, canceled, not run, its add-on still starting, an exception.
DoneErrorKind: TypeAlias = Literal['timeout', 'canceled', 'skipped', 'starting', 'exception']


class ResolveIsa(TypedDict, total=False):
    """How InputStream Adaptive opens the stream."""

    #: The manifest type: `hls`, `mpd`.
    protocol: str
    #: The mime type of the manifest (`application/dash+xml`...).
    mimetype: str
    #: The headers of the manifest requests (the stream headers are `ResolveResult.headers`).
    manifest_headers: dict[str, str]
    #: The `inputstream.adaptive.config` property (JSON text).
    config: str


class ResolveDrm(TypedDict, total=False):
    """The DRM license of the stream (InputStream Adaptive)."""

    #: The key system (`com.widevine.alpha`).
    type: str
    #: The license server.
    licence_url: str
    #: The headers of the license request.
    licence_header: dict[str, str]
    #: The license request body (`R{SSM}`...).
    post_data: str
    #: The license response format.
    response_data: str


class ResolveSubtitle(TypedDict, total=False):
    """An external subtitle file."""

    #: A URL or a local path.
    url: str
    #: Language (ISO 639-1), if known.
    lang: str


class ResolveError(TypedDict, total=False):
    """The link does not open."""

    #: Why.
    kind: ResolveErrorKind
    #: A text for the user (in the user's language), the host has its own for the kind.
    message: str


class ResolveResult(TypedDict, total=False):
    """The result of `resolve()`: the stream to play, or the error."""

    #: The link: a stream (`final`) or a link the host opens by its ways (a hosting, a magnet).
    url: str
    #: Parts of a multi-part file (instead of `url`), each like `url`.
    parts: list[str]
    #: The stream itself (the host opens no hosting, no debrid), default: the source is `direct`.
    final: bool
    #: HTTP headers of the stream requests.
    headers: dict[str, str]
    #: How to play it (a hint).
    play: PlayMode
    #: InputStream Adaptive.
    isa: ResolveIsa
    #: DRM (with `isa`).
    drm: ResolveDrm
    #: External subtitles.
    subtitles: list[ResolveSubtitle]
    #: The link does not open (the other keys are ignored).
    error: ResolveError


class DoneError(TypedDict, total=False):
    """Why a provider has no complete result (its items so far are given)."""

    #: Why.
    kind: DoneErrorKind
    #: A short text for the log (the traceback is only in the log of the provider add-on).
    message: str


class DoneStats(TypedDict, total=False):
    """Statistics of a provider search (an open dict, more keys later)."""

    #: Seconds.
    elapsed: float
    #: Items given.
    count: int


class ItemsEvent(TypedDict):
    """Found items of a provider (0..n times for a provider)."""

    #: `items`.
    event: Literal['items']
    #: The provider ID.
    provider: str
    #: The source items.
    items: list[Any]


class DoneEvent(TypedDict):
    """The end of a provider search (exactly once for every provider of the request)."""

    #: `done`.
    event: Literal['done']
    #: The provider ID.
    provider: str
    #: Why its result is not complete (no key: complete).
    error: NotRequired[DoneError]
    #: Statistics.
    stats: NotRequired[DoneStats]
    #: Lifetime of the cached result of the provider (seconds, 0: not cached), none: the catalog / the host default.
    sources_ttl: NotRequired[int]


#: An event of the `find` stream.
FindEvent: TypeAlias = Union[ItemsEvent, DoneEvent]


class CacheTtl(TypedDict, total=False):
    """Lifetimes of the caches of the provider add-on (seconds, 0: not cached)."""

    #: The show level of an episode search (e.g. the show token: the page of the show).
    show: int
    #: An empty result (shorter: it can be a temporary failure).
    empty: int


class ContextCache(TypedDict, total=False):
    """The cache policy of the host for the caches of the provider add-on."""

    #: The user asked a fresh search: the caches of the provider add-on are not read (a fresh value replaces them).
    refresh: bool
    #: Lifetimes, none: the defaults of the provider add-on.
    ttl: CacheTtl


class Context(TypedDict, total=False):
    """The host context of a request (not a part of the query)."""

    #: The providers of the request (IDs of the catalog).
    providers: list[str]
    #: The hostings the host opens (the old `hostDict` of the scrapers).
    hosts: list[str]
    #: The premium hostings the host opens.
    premium_hosts: list[str]
    #: Kinds of the torrent packs to search with an episode.
    packs: list[str]
    #: The time limit of a provider (seconds).
    timeout: float
    #: The request ID (for the logs of both sides).
    request_id: str
    #: The protocol version of the host.
    protocol: str
    #: Objects of the host, only in its process (`ffitem` of FanFilm).
    extras: dict[str, Any]
    #: The cache policy of the host, none: the defaults of the provider add-on.
    cache: ContextCache
