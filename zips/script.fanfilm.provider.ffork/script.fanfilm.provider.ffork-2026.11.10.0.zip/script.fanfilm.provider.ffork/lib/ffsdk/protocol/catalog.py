"""
The catalog of a provider add-on (xdostawca): its handlers, the add-ons it serves and their providers. The host keeps
it and asks again when the add-ons change (the host computes the stamp from the add-on files).
"""

from __future__ import annotations
from typing import Literal
from typing_extensions import TypedDict, TypeAlias, NotRequired


#: How an add-on was matched by its handler, the most specific first: its ID, its folder structure, a file heuristic.
MatchKind: TypeAlias = Literal['id', 'structure', 'heuristic']
#: The match kinds in their order (the more specific one wins).
MATCH_ORDER: tuple[MatchKind, ...] = ('id', 'structure', 'heuristic')


class CatalogHandler(TypedDict):
    """A handler (a dialect code): the same ID in every add-on that carries it, the newer version wins."""

    #: The handler ID (`fenom`, `ff`).
    id: str
    #: Its version (`major.minor.patch`).
    version: str


class CatalogProvider(TypedDict):
    """A provider of an add-on."""

    #: The ID in the add-on (opaque: `<group>/<name>`, a flat one `<name>`).
    id: str
    #: Its group (a folder: `pl`, `torrents`), may be empty.
    group: str
    #: Its name.
    name: str
    #: Searched media (`movie`, `show`), none: all.
    media: NotRequired[list[str]]
    #: Languages of its sources, none: all.
    languages: NotRequired[list[str]]
    #: Priority, lower first.
    priority: NotRequired[int]
    #: Kinds of the torrent packs it searches.
    packs: NotRequired[list[str]]
    #: Enabled without a choice of the user.
    default_enabled: NotRequired[bool]
    #: Lifetime of its cached result (seconds), none: the host default.
    sources_ttl: NotRequired[int]
    #: It has an account step: its items carry the account state (`dynamic`), the host asks `dynamic` with the cached items.
    dynamic: NotRequired[bool]


class CatalogAddon(TypedDict):
    """An add-on served by the provider add-on (a scraper add-on, or the provider add-on itself)."""

    #: The Kodi add-on ID.
    id: str
    #: The add-on name.
    name: str
    #: The add-on version.
    version: str
    #: The handler ID.
    handler: str
    #: How the handler matched it.
    match: MatchKind
    #: The dialect of its scrapers (information).
    dialect: NotRequired[str]
    #: Its providers.
    providers: list[CatalogProvider]


class Catalog(TypedDict):
    """The catalog of a provider add-on."""

    #: The protocol version.
    protocol: str
    #: The SDK version (information).
    sdk: str
    #: The handlers.
    handlers: list[CatalogHandler]
    #: The served add-ons.
    addons: list[CatalogAddon]
    #: Optional calls it supports.
    capabilities: NotRequired[list[str]]
