"""
A source item of the protocol (one link a provider found) and the old item forms of the scrapers mapped to it.

Every fact has its own key (closed vocabularies of `sdk.facts`, the quality `QUALITIES`), the texts are for the display:
`info` is a comment; a text the protocol does not carry (`info2` of the old items) is parsed here into the facts, the
texts it carries (the file name, `info`) are parsed by the host, completing the given facts.
"""

from __future__ import annotations
import re
from base64 import b32decode
from typing import Any, Literal, Mapping
from typing_extensions import TypedDict, TypeAlias, NotRequired
from ..facts import Facts, parse, complete, Container
from ..facts.types import VideoFacts, AudioTrack, SubtitleTrack, ReleaseFacts


#: Kind of a torrent pack: a whole season, a whole show (the file of the episode is chosen when it is opened).
PackKind: TypeAlias = Literal['season', 'show']

#: The quality of an item (a closed vocabulary) with its aliases in the old items (lower case; a frame height, e.g.
#: `1440p`, `360`, is the quality of the height, `quality_of_resolution()`); `CAM`, `SCR`: the release kinds the old
#: hosts read as a quality.
QUALITIES: dict[str, tuple[str, ...]] = {
    '4K': ('8k', 'uhd'),
    '1080p': ('2k', 'fhd'),
    '720p': ('hd',),
    'SD': (),
    'CAM': (),
    'SCR': (),
}
#: The quality of an alias (lower case).
QUALITY_OF_ALIAS: dict[str, str] = {alias: label for label, aliases in QUALITIES.items() for alias in (label.lower(), *aliases)}
#: A frame height as a quality text (`1440p`, `1080i`, `360`).
RX_HEIGHT = re.compile(r'(\d{3,4})[pi]?')
#: A size text of the old items (`7.2 GB`, `700MB`).
RX_SIZE = re.compile(r'([\d,.]+)\s*([KMGT]?)i?B', re.IGNORECASE)
#: The info hash of a magnet (hex or base32).
RX_BTIH = re.compile(r'xt=urn:btih:([0-9a-z]{40}|[a-z2-7]{32})(?:&|$)', re.IGNORECASE)


class ItemDynamic(TypedDict, total=False):
    """The account state of an item (DYNAMIC: applied on every search, never cached)."""

    #: The file is on the user's account.
    on_account: bool
    #: The link of the file on the account.
    on_account_link: str
    #: When the file expires on the account.
    on_account_expires: str
    #: Not enough transfer to open it.
    no_transfer: bool


#: The account state keys (`ItemDynamic`; flat in the old items).
DYNAMIC_KEYS: frozenset[str] = frozenset(ItemDynamic.__annotations__)
#: The fact groups of an item (`Facts`).
FACT_GROUPS: tuple[str, ...] = tuple(Facts.__annotations__)


class Item(TypedDict):
    """A source item."""

    #: The link (the provider's `resolve()` gets the item back).
    url: str
    #: The hosting (a domain name, `torrent`, `direct`...).
    hosting: NotRequired[str]
    #: The quality (`QUALITIES`: `4K`, `1080p`, `720p`, `SD`).
    quality: NotRequired[str]
    #: The language of the item (ISO 639-1), `multi`.
    language: NotRequired[str]
    #: A comment for the display.
    info: NotRequired[str]
    #: The file name.
    filename: NotRequired[str]
    #: An icon (URL or path).
    icon: NotRequired[str]
    #: Only a debrid opens it.
    debridonly: NotRequired[bool]
    #: The link is the stream (no host resolver).
    direct: NotRequired[bool]
    #: A local file.
    local: NotRequired[bool]
    #: A premium hosting.
    premium: NotRequired[bool]
    #: The size of the played file (bytes).
    filesize: NotRequired[int]
    #: A torrent pack.
    pack: NotRequired[PackKind]
    #: The size of the whole pack (bytes).
    pack_size: NotRequired[int]
    #: The torrent info hash (hex, lower case).
    hash: NotRequired[str]
    #: Torrent seeders.
    seeders: NotRequired[int]
    #: Private data of the provider (JSON), back in `resolve()`.
    data: NotRequired[Any]
    #: The account state.
    dynamic: NotRequired[ItemDynamic]
    #: Facts: the video stream.
    video: NotRequired[VideoFacts]
    #: Facts: the audio tracks.
    audio: NotRequired[list[AudioTrack]]
    #: Facts: the subtitle tracks.
    subtitles: NotRequired[list[SubtitleTrack]]
    #: Facts: the release.
    release: NotRequired[ReleaseFacts]


def size_bytes(text: str) -> int | None:
    """Return the bytes of a size text (`7.2 GB`, `700MB`, `1,5 GB`), None if it is not one."""
    if not (match := RX_SIZE.fullmatch(text.strip())):
        return None
    try:
        num = float(match[1].replace(',', '.'))
    except ValueError:
        return None
    return int(num * 1024 ** ('KMGT'.find(match[2].upper()) + 1)) if match[2] else int(num)


def quality_of_resolution(width: int = 0, height: int = 0) -> str:
    """Return the quality of the frame size (the width, the height or both; `SD` if unknown)."""
    if width >= 3840 or height >= 2160:
        return '4K'
    if width >= 1920 or height >= 1080:
        return '1080p'
    if width >= 1280 or height >= 720:
        return '720p'
    return 'SD'


def quality_label(text: str) -> str | None:
    """Return the quality (`QUALITIES`) of a quality text of a provider (an alias, a frame height), None if unknown."""
    text = text.strip().lower()
    if label := QUALITY_OF_ALIAS.get(text):
        return label
    if match := RX_HEIGHT.fullmatch(text):
        return quality_of_resolution(height=int(match[1]))
    return None


def magnet_hash(url: str) -> str | None:
    """Return the info hash of a magnet link (hex, lower case), None if it is not one."""
    if not url.startswith('magnet:') or not (match := RX_BTIH.search(url)):
        return None
    btih = match[1]
    if len(btih) == 32:
        btih = b32decode(btih.upper()).hex()
    return btih.lower()


def item_from_legacy(item: Mapping[str, Any]) -> Item:
    """
    Return the protocol item of an old scraper item: `source` -> `hosting`, the size text -> `filesize`, the flat account
    state -> `dynamic`, the hash of a magnet; `info2` -> the facts (and the file name, if it is one); the quality of the
    vocabulary (an alias, unknown: of the frame height of the facts if known, else none); the keys unknown to the
    protocol are dropped.
    """
    result: dict[str, Any] = {key: val for key, val in item.items() if key in Item.__annotations__ and val is not None}
    if 'hosting' not in result and (source := item.get('source')):
        result['hosting'] = source
    if 'filesize' not in result and isinstance(size := item.get('size'), str) and (count := size_bytes(size)) is not None:
        result['filesize'] = count
    if dynamic := {key: item[key] for key in DYNAMIC_KEYS if item.get(key) is not None}:
        result['dynamic'] = dynamic
    if isinstance(btih := result.get('hash'), str):
        result['hash'] = btih.lower()
    elif btih := magnet_hash(str(item.get('url', ''))):
        result['hash'] = btih
    if isinstance(info2 := item.get('info2'), str) and info2.strip():
        if 'filename' not in result and '.' in info2 and Container.find(info2.rpartition('.')[2].strip()):
            result['filename'] = info2.strip()
        given: Facts = {group: result[group] for group in FACT_GROUPS if group in result}  # type: ignore[misc]
        facts = complete(given, parse(info2, language=(item.get('language') or '').lower() or None))
        result.update(facts)
    if quality := quality_label(str(result.get('quality') or '')):
        result['quality'] = quality
    elif height := (result.get('video') or {}).get('height'):
        result['quality'] = quality_of_resolution(height=height)
    else:
        result.pop('quality', None)
    return result  # type: ignore[return-value]
