"""
The result of `resolve()`: a dict, or a text of the old forms (Kodi `url|headers`, prefixes, `DRMFF|{…}`) parsed to it;
the links of a stream (`url`, `parts`) are valid URLs: a character not allowed in a URL (a space of a file name, a
non-ASCII one) is encoded (Kodi refuses such a URL), as `requests` does for its requests.
"""

from __future__ import annotations
from ast import literal_eval
from typing import Any, Mapping, cast
from urllib.parse import parse_qsl, quote, urlencode
from .types import ResolveResult, ResolveIsa, ResolveDrm


#: Old prefixes of a stream played by InputStream Adaptive (`direct+`: no host resolver, played by ISA).
ISA_PREFIXES: tuple[str, ...] = ('ia://', 'isa+', 'direct+')
#: Old prefix of a multi-part file (parts joined by `STACK_SEPARATOR`).
STACK_PREFIX = 'stack://'
#: Old separator of the parts of a multi-part file.
STACK_SEPARATOR = ' , '
#: Keys of the old DRM dict (`DRMFF|{…}`) moved to `ResolveDrm` as they are.
DRM_KEYS: tuple[str, ...] = ('licence_url', 'post_data', 'response_data')
#: The characters kept in a stream link: the reserved and unreserved ones of a URL and `%` (the escapes), as
#: `requests.utils.requote_uri()`.
URL_SAFE = "!#$%&'()*+,/:;=?@[]~"


def resolve_result(value: str | Mapping[str, Any] | None) -> ResolveResult:
    """
    Return the result of a provider `resolve()`: a dict as it is, a text of the old forms parsed, None is a dead link;
    its stream links valid (`stream_url()`).
    """
    if value is None:
        return {'error': {'kind': 'dead'}}
    result = cast(ResolveResult, dict(value)) if isinstance(value, Mapping) else _parse_text(str(value))
    if isinstance(url := result.get('url'), str):
        result['url'] = stream_url(url)
    if parts := result.get('parts'):
        result['parts'] = [stream_url(part) for part in parts]
    return result


def stream_url(url: str) -> str:
    """
    Return the stream link as a valid URL: an `http(s)` link with its characters not allowed in a URL encoded
    (`URL_SAFE`), its Kodi headers (`|…`, a part of a stack) as they are; others as they are.
    """
    if not url.startswith(('http://', 'https://')):
        return url
    link, sep, headers = url.partition('|')
    return quote(link, safe=URL_SAFE) + sep + headers


def headers_dict(text: str) -> dict[str, str]:
    """Return the headers of a Kodi URL suffix (`Key=value&...`, values URL-encoded or not, empty values kept)."""
    return dict(parse_qsl(text, keep_blank_values=True))


def headers_text(headers: Mapping[str, str]) -> str:
    """Return the headers as a Kodi URL suffix text (`Key=value&...`, values URL-encoded), the inverse of `headers_dict()`."""
    return urlencode(headers)


def kodi_url(result: ResolveResult) -> str:
    """Return the Kodi path of the stream: the URL with its headers (`url|headers`), the `stack://` path of the parts."""
    if parts := result.get('parts'):
        return STACK_PREFIX + STACK_SEPARATOR.join(parts)
    url = result.get('url', '')
    if headers := result.get('headers'):
        return f'{url}|{headers_text(headers)}'
    return url


def _parse_text(text: str) -> ResolveResult:
    """Return the result of the old text forms."""
    if text.startswith('DRM') and (drm := _parse_drm(text)) is not None:
        return drm
    result: ResolveResult = {}
    for prefix in ISA_PREFIXES:
        if text.startswith(prefix) and (prefix == 'ia://' or '://' in text):
            text = text[len(prefix):]
            result.update(final=True, play='isa')
            break
    if text.startswith(STACK_PREFIX):
        result['parts'] = text[len(STACK_PREFIX):].split(STACK_SEPARATOR)
        return result
    if text.startswith('plugin://'):  # a Kodi path, no headers
        result['url'] = text
        return result
    url, _, rest = text.partition('|')
    result['url'] = url
    if rest:
        headers, _, config = rest.partition('|')
        if headers := headers_dict(headers):
            result['headers'] = headers
        if config:
            result['isa'] = {'config': config}
    return result


def _parse_drm(text: str) -> ResolveResult | None:
    """Return the result of `DRM…|{dict}` (a Python dict literal of the stream and its license), None if it is not one."""
    try:
        data = literal_eval(text.partition('|')[2])
    except (ValueError, SyntaxError):
        return None
    if not isinstance(data, dict) or not data.get('manifest'):
        return None
    isa: ResolveIsa = {key: data[key] for key in ('protocol', 'mimetype') if data.get(key)}  # type: ignore[assignment]
    drm: ResolveDrm = {key: data[key] for key in DRM_KEYS if key in data}  # type: ignore[assignment]
    if data.get('licence_type'):
        drm['type'] = data['licence_type']
    if isinstance(header := data.get('licence_header'), str):
        drm['licence_header'] = headers_dict(header)
    return {'url': data['manifest'], 'final': True, 'play': 'isa', 'isa': isa, 'drm': drm}
