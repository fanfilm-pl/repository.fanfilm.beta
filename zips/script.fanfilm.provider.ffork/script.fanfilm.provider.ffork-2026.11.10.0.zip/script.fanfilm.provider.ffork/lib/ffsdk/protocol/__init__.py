"""
The protocol between a host (FanFilm) and the add-ons that provide sources to it: JSON data only, so the same
messages go through a call in the process and through HTTP.

The protocol version is `major.minor`: a host and a provider talk when the majors are equal, unknown keys are ignored
(a newer minor only adds keys).
"""

from .types import PlayMode, ResolveResult, ResolveIsa, ResolveDrm, ResolveSubtitle, ResolveError, ResolveErrorKind
from .types import FindEvent, ItemsEvent, DoneEvent, DoneError, DoneErrorKind, DoneStats, Context, ContextCache, CacheTtl
from .item import Item, ItemDynamic, PackKind, item_from_legacy
from .resolve import resolve_result, kodi_url, headers_dict, headers_text

#: The protocol version (`major.minor`), not the SDK version.
PROTOCOL_VERSION = '1.2'

__all__ = [
    'PROTOCOL_VERSION',
    'PlayMode', 'ResolveResult', 'ResolveIsa', 'ResolveDrm', 'ResolveSubtitle', 'ResolveError', 'ResolveErrorKind',
    'FindEvent', 'ItemsEvent', 'DoneEvent', 'DoneError', 'DoneErrorKind', 'DoneStats', 'Context', 'ContextCache', 'CacheTtl',
    'Item', 'ItemDynamic', 'PackKind', 'item_from_legacy',
    'resolve_result', 'kodi_url', 'headers_dict', 'headers_text',
]
