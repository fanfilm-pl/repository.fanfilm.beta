"""
A provider add-on (xdostawca): its catalog, the search of its providers (the `find` stream), the resolve.

The host calls it in its own process (an import of the manifest `entry`) or through the worker script of the add-on
(HTTP), with the same JSON data. The `entry` is a factory called once an interpreter with the host info.

    class MyProviders(XProvider):
        def catalog(self) -> Catalog: ...
        def search(self, provider: str, query: Query, context: Context) -> list[Item]: ...
"""

from __future__ import annotations
from functools import partial
from pathlib import Path
from typing import Any, Callable, ClassVar, Iterable, Iterator, Mapping, TYPE_CHECKING
from typing_extensions import TypedDict, NotRequired, Literal, TypeAlias
from . import __version__, HOST_ID
from .protocol import PROTOCOL_VERSION
from .runner import Found, Task, run
if TYPE_CHECKING:
    from .protocol import FindEvent, Context, Item, ResolveResult
    from .protocol.query import Query
    from .protocol.catalog import Catalog, CatalogAddon, CatalogHandler
    from .addons.scan import Scraper


#: The run mode of a provider add-on (see `HostInfo.mode`).
RunMode: TypeAlias = Literal['service', 'import']

#: The time limit of a provider when the host gives none (seconds).
DEFAULT_TIMEOUT = 30.0


class HostInfo(TypedDict):
    """What the host tells the provider add-on when it creates it."""

    #: The protocol version of the host.
    protocol: str
    #: The folder of the Kodi add-ons (the default: `special://home/addons`).
    addons_path: NotRequired[str]
    #: The folder of this provider add-on (its `addon.xml`).
    path: NotRequired[str]
    #: The run mode of this interpreter: `service` - the worker script of the provider add-on, `import` - the host process.
    mode: NotRequired[RunMode]


def provider_key(addon: str, provider: str) -> str:
    """Return the provider key of a request: `<add-on ID>:<provider ID in the add-on>`."""
    return f'{addon}:{provider}'


def split_provider_key(key: str) -> tuple[str, str]:
    """Return the add-on ID and the provider ID of a provider key."""
    addon, _, provider = key.partition(':')
    return addon, provider


def addon_info(path: Path) -> tuple[str, str]:
    """Return the name and the version of a Kodi add-on (its `addon.xml`), the folder name and '' if unknown."""
    try:
        from xml.etree import ElementTree as ET
        root = ET.parse(path / 'addon.xml').getroot()
        return root.attrib.get('name') or path.name, root.attrib.get('version') or ''
    except Exception:
        return path.name, ''


class XProvider:
    """The base of a provider add-on: `find()` runs `search()` of every provider of the request together."""

    #: The handlers of this provider add-on.
    HANDLERS: ClassVar[tuple[CatalogHandler, ...]] = ()

    def __init__(self, host: HostInfo | None = None) -> None:
        """Create the provider add-on for the host."""
        #: What the host told.
        self.host: HostInfo = host or {'protocol': PROTOCOL_VERSION}

    @property
    def addons_path(self) -> Path:
        """Return the folder of the Kodi add-ons."""
        if path := self.host.get('addons_path'):
            return Path(path)
        from xbmcvfs import translatePath
        return Path(translatePath('special://home/addons'))

    def catalog(self) -> Catalog:
        """Return the catalog: the handlers, the served add-ons and their providers."""
        return {'protocol': PROTOCOL_VERSION, 'sdk': __version__, 'handlers': list(self.HANDLERS), 'addons': self.catalog_addons()}

    def catalog_addons(self) -> list[CatalogAddon]:
        """Return the served add-ons with their providers."""
        raise NotImplementedError

    def search(self, provider: str, query: Query, context: Context) -> Iterable[Item] | Found | None:
        """
        Search with one provider (its key `<add-on>:<provider>`), return its items (a list or an iterable), or `Found`
        with what the host should know about the result (its cache lifetime).
        """
        raise NotImplementedError

    def find(self, query: Query, context: Context, *, canceled: Callable[[], bool] | None = None) -> Iterator[FindEvent]:
        """Search with the providers of the request together: the `find` stream (`items`, `done` once a provider)."""
        tasks = [Task(key, partial(self.search, key, query, context)) for key in context.get('providers', ())]
        return run(tasks, timeout=context.get('timeout', DEFAULT_TIMEOUT), canceled=canceled)

    def resolve(self, provider: str, item: Mapping[str, Any], options: Mapping[str, Any] | None = None) -> ResolveResult | str | None:
        """Return the stream of an item (default: its link, opened by the ways of the host)."""
        return item.get('url')

    def dynamic(self, provider: str, query: Query, context: Context, items: list[Item]) -> list[Item]:
        """
        Return the items of a cached result of a provider with the account state now (`dynamic` of its catalog entry: the
        host asks it with the items it cached, without their account state; default: the items as they are).
        """
        return items

    def clear(self) -> None:
        """
        Remove the data of the providers (sessions, tokens...: `providers.db` in the data folder of the add-on, see
        `ffsdk.db.providers.ProviderStore`), the user asked for it.
        """
        from .db import providers
        providers.clear()

    def warm_up(self) -> None:
        """Prepare the first search (the worker calls it in the background after its start): e.g. import the scrapers."""

    def close(self) -> None:
        """Release the resources (the end of the interpreter)."""


class DialectXProvider(XProvider):
    """
    The provider add-on of a scraper dialect (`DIALECT`, see `addons.scan.DIALECTS`): every installed add-on with its
    structure (enabled in Kodi or not: the host decides which ones it searches), the scrapers imported in the namespace
    of their add-on. In its worker the libraries of the add-ons they require are put on `sys.path`, as Kodi does for an
    import of a script (the host process has its own).
    """

    #: The dialect ID (its handler too).
    DIALECT: ClassVar[str] = ''

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Derive the handler of the dialect."""
        super().__init_subclass__(**kwargs)
        if cls.DIALECT:
            cls.HANDLERS = ({'id': cls.DIALECT, 'version': __version__},)

    def __init__(self, host: HostInfo | None = None) -> None:
        """Create the provider add-on for the host."""
        super().__init__(host)
        #: The scrapers by the provider key (from the last catalog).
        self._scrapers: dict[str, Scraper] = {}

    @property
    def own_path(self) -> Path | None:
        """Return the folder of this provider add-on (None if the host did not tell)."""
        return Path(own) if (own := self.host.get('path')) else None

    def _addon_paths(self) -> Iterator[Path]:
        """Yield the folders of the installed add-ons (not this provider add-on, not the host: its providers are its own)."""
        own = self.own_path
        for path in sorted(self.addons_path.iterdir()):
            if path.is_dir() and path != own and path.name != HOST_ID:
                yield path

    def catalog_addons(self) -> list[CatalogAddon]:
        """
        Return the add-ons with scrapers of the dialect and their providers (the scraper files, no import; on by default:
        the setting of the add-on, `default_scrapers()`).
        """
        from .addons.scan import scan_scrapers, default_scrapers
        addons: list[CatalogAddon] = []
        scrapers: dict[str, Scraper] = {}
        for path in self._addon_paths():
            found = [scraper for scraper in scan_scrapers(path) if scraper.dialect.id == self.DIALECT]
            defaults = default_scrapers(path, found) if found else frozenset()
            providers = []
            for scraper in found:
                scrapers[provider_key(path.name, scraper.key)] = scraper
                providers.append({'id': scraper.key, 'group': scraper.path.parent.name, 'name': scraper.provider,
                                  'default_enabled': scraper.key in defaults})
            if providers:
                name, version = addon_info(path)
                addons.append({'id': path.name, 'name': name, 'version': version, 'handler': self.DIALECT, 'match': 'structure',
                               'dialect': self.DIALECT, 'providers': providers})  # type: ignore[typeddict-item]
        self._scrapers = scrapers
        if self.host.get('mode') == 'service':
            self._import_paths(scraper.addon for scraper in scrapers.values())
        return addons

    def _import_paths(self, addons: Iterable[Path]) -> None:
        """
        Put the libraries the add-ons require on `sys.path` (after the entries of this provider add-on), as Kodi for an import.

        The network patches of `requests` / urllib3 again: the worker installed them before its start, when a library of
        the add-ons (`script.module.urllib3`) was not importable yet, so nothing was installed (Windows: a pooled connection
        cut at the end of a search failed the next one).
        """
        import sys
        from .addons.paths import kodi_import_paths
        from .net import drop_cut_connections, share_tls_contexts
        known = set(sys.path)
        new = [str(path) for addon in dict.fromkeys(addons) for path in kodi_import_paths(addon) if str(path) not in known]
        if not new:
            return
        own = str(self.own_path or '')
        pos = next((i for i, entry in enumerate(sys.path) if not (own and str(entry).startswith(own))), len(sys.path))
        sys.path[pos:pos] = list(dict.fromkeys(new))
        drop_cut_connections()
        share_tls_contexts()

    def warm_up(self) -> None:
        """Import the scrapers of the served add-ons (the first search then only searches)."""
        from .addons.scan import load_scraper
        from .log import fflog_exc
        self.catalog_addons()
        for scraper in list(self._scrapers.values()):
            try:
                load_scraper(scraper.addon, scraper.path)
            except Exception:
                fflog_exc()

    def search(self, provider: str, query: Query, context: Context) -> Iterable[Item] | Found | None:
        """Search with one scraper of the dialect (`find_scraper()`)."""
        return self.find_scraper(provider, self.scraper(provider), query, context)

    def scraper(self, provider: str) -> Scraper:
        """Return the scraper of the provider (the catalog read again if it is not known)."""
        if provider not in self._scrapers:
            self.catalog_addons()
        return self._scrapers[provider]

    def find_scraper(self, provider: str, scraper: Scraper, query: Query, context: Context) -> Iterable[Item] | Found | None:
        """Search with the scraper of the add-on (the dialect API)."""
        raise NotImplementedError


class FenomXProvider(DialectXProvider):
    """The provider add-on of the Fenom family scrapers (CocoScrapers, Fenom, Classy, POV and others of the Fenom structure)."""

    #: The Fenom dialect.
    DIALECT = 'fenom'

    def find_scraper(self, provider: str, scraper: Scraper, query: Query, context: Context) -> Iterable[Item] | Found | None:
        """Search with one scraper: a new instance of it a request (its class state cleared around)."""
        from .dialects.fenom import fenom_find
        return fenom_find(scraper.create(), query, context)


class FforkXProvider(DialectXProvider):
    """
    The provider add-on of the FanFilm fork scrapers (FanFilm 2 / 3 forks: their old API or the new `find`), searched
    outside FanFilm (`dialects.ffork.ffork_find()`: a stand-in of the FanFilm item, the show token in the provider data);
    a scraper with an account step (`apply_dynamic`, the old hook) is `dynamic` in the catalog.
    """

    #: The dialect of the FanFilm forks.
    DIALECT = 'ffork'

    def __init__(self, host: HostInfo | None = None) -> None:
        """Create the provider add-on for the host."""
        super().__init__(host)
        #: The scraper instance of the last search of a provider (its `resolve()` may need its state).
        self._last: dict[str, Any] = {}
        #: The providers with an account step (`dynamic` of the catalog).
        self._dynamic: set[str] = set()

    def catalog_addons(self) -> list[CatalogAddon]:
        """Return the add-ons and their providers, a provider with an account step (the text of its file) `dynamic`."""
        from .dialects.ffork import has_account_step
        addons = super().catalog_addons()
        self._dynamic = {key for key, scraper in self._scrapers.items() if has_account_step(scraper.path)}
        for addon in addons:
            for prov in addon['providers']:
                if provider_key(addon['id'], prov['id']) in self._dynamic:
                    prov['dynamic'] = True
        return addons

    def _scraper(self, provider: str) -> Any:
        """Return a new instance of the scraper of the provider."""
        return self.scraper(provider).create()

    def find_scraper(self, provider: str, scraper: Scraper, query: Query, context: Context) -> Iterable[Item] | Found | None:
        """Search with one scraper: a new instance a request (kept for the resolve of its items)."""
        from .dialects.ffork import ffork_find
        instance = self._last[provider] = scraper.create()
        return ffork_find(provider, instance, query, context, dynamic=provider in self._dynamic)

    def dynamic(self, provider: str, query: Query, context: Context, items: list[Item]) -> list[Item]:
        """Return the cached items with the account state now: the account step of the scraper (the instance of its last search)."""
        from .dialects.ffork import ffork_dynamic
        if (scraper := self._last.get(provider)) is None:
            scraper = self._last[provider] = self._scraper(provider)
        return ffork_dynamic(provider, scraper, query, items)

    def resolve(self, provider: str, item: Mapping[str, Any], options: Mapping[str, Any] | None = None) -> ResolveResult | str | None:
        """Return the stream of an item: the `resolve()` of the scraper (the instance of its search), its link if it has none."""
        if (scraper := self._last.get(provider)) is None:
            scraper = self._last[provider] = self._scraper(provider)
        if callable(resolve := getattr(scraper, 'resolve', None)):
            return resolve(item.get('url'))  # type: ignore[no-any-return]  # the scraper gives a link
        return item.get('url')
