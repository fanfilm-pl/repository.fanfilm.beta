"""
Threads of the SDK: a thread keeps its result and has a stop scope (`CancelScope`); a stopped scope stops its child
scopes, its plain threads (pool workers) and cuts their sockets (a blocked read ends at once).

The host binds it with `options` (the Kodi monitor of the waits, the wait step, the exception log).
"""

from __future__ import annotations
from sys import version_info as PY
from time import monotonic
from threading import Thread as _Thread, local as _local, Event as _Event
from threading import Lock, RLock, Condition, current_thread   # noqa: F401  (simulate threading import)
import queue
from contextlib import contextmanager
from weakref import WeakKeyDictionary, WeakSet
from typing import Optional, Any, Set, Iterable, Iterator, Mapping, Callable, ClassVar, TypeVar, TYPE_CHECKING
from typing_extensions import Self, TypeAlias, Generic
if PY >= (3, 13):
    from queue import ShutDown  # since python 3.13
else:
    class ShutDown(Exception):
        '''Raised when put/get with shut-down queue.'''

if TYPE_CHECKING:
    from socket import socket as Socket
    from xbmc import Monitor

T = TypeVar('T')
#: A scope class (`CancelScope.find()`).
S = TypeVar('S', bound='CancelScope')

ThreadOnFinished: TypeAlias = Callable[[], None]

# Safe future timestamp (signed 32-bit minus more then one day).
MAX_TIMESTAMP = 2**31 - 100000


def _new_monitor() -> Monitor:
    """Return a new Kodi monitor (the default without the host binding)."""
    from xbmc import Monitor
    return Monitor()


def _event_step() -> float:
    """Return the default wait step (seconds)."""
    return .1


def _log_exception() -> bool:
    """Return the default of the exception log switch."""
    return True


class ThreadOptions:
    """The bindings of the host."""

    def __init__(self) -> None:
        #: The monitor a wait watches for the Kodi exit (one that exists: a monitor created after the exit never sees it).
        self.monitor: Callable[[], Monitor] = _new_monitor
        #: The step of a wait (seconds): the Kodi exit is checked so often.
        self.event_step: Callable[[], float] = _event_step
        #: Log the exception of a thread with its traceback.
        self.log_exception: Callable[[], bool] = _log_exception


#: The bindings of the host.
options = ThreadOptions()


class ThreadCanceled(BaseException):
    """Thread method should be canceled. BaseException to avoid `except Exception:` everywhere."""


class local(_local):
    """threading.local wrapper."""


class ThreadSingleLocal(local):
    """Thread wide threading.local data, singleton per thread."""

    _instances: ClassVar[WeakKeyDictionary[_Thread, ThreadSingleLocal]] = WeakKeyDictionary()
    _lock: ClassVar[Lock] = Lock()

    def __new__(cls: type[Self]) -> ThreadSingleLocal:
        """Create a new instance of ThreadLocal, singleton per thread."""
        with ThreadSingleLocal._lock:
            th = current_thread()
            data = cls._instances.get(th)
            if data is None:
                data = super().__new__(cls)
                cls._instances[th] = data
        return data


class Event(_Event):
    """threading.Event wrapper. Honore Kodi exit."""

    def wait(self, timeout: Optional[float] = None, *, monitor: Optional[Monitor] = None) -> bool:
        """Block until the internal flag is true. Return False on timeout or Kodi exit. See: threading.Event."""
        if monitor is None:
            monitor = options.monitor()
        end = MAX_TIMESTAMP if timeout is None else monotonic() + timeout
        while (delta := end - monotonic()) > 0 and not getattr(monitor, 'aborting', False) and not monitor.abortRequested():
            if super().wait(min(delta, options.event_step())):
                return True
        return False
        # while not self.is_set() and (delta := end - monotonic()) > 0:
        #     xsleep(delta, cancel_event=self)
        # return self.is_set()


class CancelScope(Event):
    """
    Stop scope: threads and their sockets stopped together by `set()`.

    A FF thread has its own scope (`Thread.stop_event`) under a given group (`scope=`) or the scope of the creating
    thread. A plain thread (e.g. a pool worker, see `inherit_thread_scopes()`) shares the scope of the thread
    which creates it. `set()` stops the scope and all its child scopes: `check_thread_cancel()` raises there and their
    sockets are cut (a blocked read ends at once, a new socket is refused, see `cut_sockets()`).
    A scope may have a deadline (`monotonic()` time) by which its work is not used any more (e.g. the end of a search),
    its child scopes have the same one unless they get their own.

    >>> search = CancelScope(parent=current_scope(), deadline=monotonic() + timeout)
    >>> Thread(target=find, scope=search).start()
    >>> search.set()  # stop all the threads of the search
    """

    #: Guards the child sets: a scope is created (added to its parent) in one thread and set in another.
    _tree_lock: ClassVar[Lock] = Lock()

    def __init__(self, parent: CancelScope | None = None, *, deadline: float | None = None) -> None:
        super().__init__()
        #: The scope this one is a child of (`find()` walks up to it).
        self.parent: CancelScope | None = parent
        self._children: WeakSet[CancelScope] = WeakSet()
        #: The `monotonic()` time the work of the scope is not used after, None: no deadline.
        self.deadline: float | None = parent.deadline if deadline is None and parent is not None else deadline
        if parent is not None:
            with CancelScope._tree_lock:
                parent._children.add(self)
            if parent.is_set():
                super().set()

    def set(self) -> None:
        """Stop the scope and its child scopes, cut their sockets."""
        self._set_tree()
        cut_sockets()

    def find(self, cls: type[S]) -> S | None:
        """Return the nearest scope of the class `cls`: this one or a parent one (e.g. the plugin call of a pool worker)."""
        scope: CancelScope | None = self
        while scope is not None:
            if isinstance(scope, cls):
                return scope
            scope = scope.parent
        return None

    def _set_tree(self) -> None:
        """Set the scope and its child scopes."""
        super().set()
        with CancelScope._tree_lock:
            children = list(self._children)
        for child in children:
            child._set_tree()


def current_scope() -> CancelScope | None:
    """Return the stop scope of the current thread (None for the main thread or a thread without scope)."""
    scope = getattr(current_thread(), 'stop_event', None)
    return scope if isinstance(scope, CancelScope) else None


class PriorityQueue(queue.PriorityQueue, Generic[T]):
    """threading.PriorityQueue wrapper, allows preview first item (peek)."""

    def peek(self) -> T | None:
        """Return the first item in the queue without removing it."""
        with self.mutex:
            if self.queue:
                return self.queue[0]

    def remove(self, item: T, /) -> bool:
        """Remove item."""
        with self.mutex:
            try:
                self.queue.remove(item)
            except ValueError:
                return False
        self.task_done()
        return True

    def __contains__(self, item: T, /) -> bool:
        """Return True if item in the queue."""
        with self.mutex:
            return item in self.queue


class Thread(_Thread, Generic[T]):
    """threading.Thread wrapper. Keeps result."""

    if TYPE_CHECKING:
        _target: Callable[..., T] | None
        _args: tuple[Any, ...]
        _kwargs: dict[str, Any]

    def __init_subclass__(cls, /, **kwargs) -> None:
        """Override __init_subclass__ to ensure that run() is overridden."""
        # force override run() to catch return value
        def run(self: Self) -> None:
            try:
                self.result = cls_run(self)
            except Exception:
                from .log import log_exc
                log_exc(internal=True)
            for cb in self.on_finished:
                cb()

        super().__init_subclass__(**kwargs)
        cls_run = cls.run
        cls.run = run  # type: ignore[method-assign]

    def __init__(self,
                 group: None = None,
                 target: Optional[Callable[..., Any]] = None,
                 name: Optional[str] = None,
                 args: Iterable[Any] = (),
                 kwargs: Mapping[str, Any] | None = None,
                 *,
                 daemon: Optional[bool] = None,
                 on_finished: Optional[ThreadOnFinished] = None,
                 scope: CancelScope | None = None,
                 ) -> None:
        if scope is None:
            scope = current_scope()
        super().__init__(group=group, target=target, name=name, args=args, kwargs=kwargs, daemon=daemon)
        if PY < (3, 10):
            if name is None and callable(target):
                self._name = f'{self._name} ({target.__name__})'
        self._local: Optional[local] = None
        #: Own stop scope, a child of `scope` (a group) or of the scope of the creating thread.
        self.stop_event = CancelScope(parent=scope)
        self.result: T | None = None
        self.exception: BaseException | None = None
        self.on_finished: Set[ThreadOnFinished] = set()
        if on_finished is not None:
            self.on_finished.add(on_finished)

    # taken from PY (3.8-3.12)
    def run(self) -> T:  # type: ignore[override]
        """
        Method representing the thread's activity.

        You may override this method in a subclass. The standard run() method
        invokes the callable object passed to the object's constructor as the
        target argument, if any, with sequential and keyword arguments taken
        from the args and kwargs arguments, respectively.
        """
        try:
            if self.stop_event.is_set():
                raise ThreadCanceled()
            if self._target is not None:
                return self._target(*self._args, **self._kwargs)
        except ThreadCanceled:
            from .log import fflog
            fflog(f'Thread {self.name} graceful canceled', internal=True)
        except SystemExit:
            from .log import fflog
            fflog(f'Thread {self.name} system exit', internal=True)
        except Exception as exc:
            from .log import fflog, fflog_exc
            fflog(f'Thread {self.name} raises an exception: {exc}', internal=True)
            self.exception = exc
            if options.log_exception():
                fflog_exc(internal=True)
            raise
        finally:
            # Avoid a refcycle if the thread is running a function with
            # an argument that has a member that points to the thread.
            del self._target, self._args, self._kwargs

    @property
    def local(self) -> local:
        """Returns threading.local() variables as class local instance."""
        if self._local is None:
            self._local = local()
        return self._local

    def stop(self):
        """
        Stop the thread scope: check_thread_cancel() raises (e.g. ff.requests, ff.cache), its sockets are cut.

        Threads created by it (e.g. pool workers) are stopped too, see CancelScope.
        """
        self.stop_event.set()

    @property
    def is_canceled(self) -> bool:
        """Return True if the thread is canceled."""
        return self.stop_event.is_set()


class WeakThread(Thread):
    """Helper thread, abort on script exit, do not count in standard threads."""


def check_thread_cancel() -> None:
    """Check if the current thread should be canceled. Raise ThreadCanceled if so."""
    if (event := getattr(current_thread(), 'stop_event', None)) is not None and event.is_set():
        raise ThreadCanceled()


if PY < (3, 9):
    # Fake typing for queue.Queue in python < 3.9
    queue.Queue.__class_getitem__ = classmethod(lambda cls, item: cls)  # type: ignore[reportAttributeAccessIssue]


# Backport from Python 3.13 + clear() + custom shutdown exception.
# See: https://stackoverflow.com/a/31892187/9935708
class Queue(queue.Queue[T], Generic[T]):
    '''Create a queue object with a given maximum size, provides a :meth:`clear` method and support KodiExit.

    If maxsize is <= 0, the queue size is infinite.
    '''

    WAITING_QUEUES: ClassVar[dict[Queue[Any], int]] = {}
    WAITING_LOCK: ClassVar[Lock] = Lock()

    def __init__(self, maxsize: int = 0) -> None:
        super().__init__(maxsize)
        if PY < (3, 13):
            self.is_shutdown = False
        self._shutdown_exception: type[BaseException] = ShutDown

    @contextmanager
    def waiting_queue(self) -> Iterator[None]:
        """Context manager to track waiting threads on this queue."""
        cls = self.__class__
        with cls.WAITING_LOCK:
            cls.WAITING_QUEUES[self] = cls.WAITING_QUEUES.get(self, 0) + 1
        try:
            yield
        finally:
            with cls.WAITING_LOCK:
                wait_counter = cls.WAITING_QUEUES.get(self, 0)
                if wait_counter > 1:
                    cls.WAITING_QUEUES[self] = wait_counter - 1
                else:
                    cls.WAITING_QUEUES.pop(self, None)

    # taken from py3.13
    def put(self, item: T, block: bool = True, timeout: float | None = None) -> None:
        '''Put an item into the queue.

        If optional args 'block' is true and 'timeout' is None (the default),
        block if necessary until a free slot is available. If 'timeout' is
        a non-negative number, it blocks at most 'timeout' seconds and raises
        the Full exception if no free slot was available within that time.
        Otherwise ('block' is false), put an item on the queue if a free slot
        is immediately available, else raise the Full exception ('timeout'
        is ignored in that case).

        Raises ShutDown if the queue has been shut down.
        '''
        with self.not_full:
            if self.is_shutdown:
                raise self._shutdown_exception
            if self.maxsize > 0:
                if not block:
                    if self._qsize() >= self.maxsize:
                        raise queue.Full
                elif timeout is None:
                    while self._qsize() >= self.maxsize:
                        with self.waiting_queue():
                            self.not_full.wait()
                        if self.is_shutdown:
                            raise self._shutdown_exception
                elif timeout < 0:
                    raise ValueError("'timeout' must be a non-negative number")
                else:
                    endtime = monotonic() + timeout
                    while self._qsize() >= self.maxsize:
                        remaining = endtime - monotonic()
                        if remaining <= 0.0:
                            raise queue.Full
                        with self.waiting_queue():
                            self.not_full.wait(remaining)
                        if self.is_shutdown:
                            raise self._shutdown_exception
            self._put(item)
            self.unfinished_tasks += 1
            self.not_empty.notify()

    # taken from py3.13
    def get(self, block: bool = True, timeout: float | None = None) -> T:
        '''Remove and return an item from the queue.

        If optional args 'block' is true and 'timeout' is None (the default),
        block if necessary until an item is available. If 'timeout' is
        a non-negative number, it blocks at most 'timeout' seconds and raises
        the Empty exception if no item was available within that time.
        Otherwise ('block' is false), return an item if one is immediately
        available, else raise the Empty exception ('timeout' is ignored
        in that case).

        Raises ShutDown if the queue has been shut down and is empty,
        or if the queue has been shut down immediately.
        '''
        with self.not_empty:
            if self.is_shutdown and not self._qsize():
                raise self._shutdown_exception
            if not block:
                if not self._qsize():
                    raise queue.Empty
            elif timeout is None:
                while not self._qsize():
                    with self.waiting_queue():
                        self.not_empty.wait()
                    if self.is_shutdown and not self._qsize():
                        raise self._shutdown_exception
            elif timeout < 0:
                raise ValueError("'timeout' must be a non-negative number")
            else:
                endtime = monotonic() + timeout
                while not self._qsize():
                    remaining = endtime - monotonic()
                    if remaining <= 0.0:
                        raise queue.Empty
                    with self.waiting_queue():
                        self.not_empty.wait(remaining)
                    if self.is_shutdown and not self._qsize():
                        raise self._shutdown_exception
            item = self._get()
            self.not_full.notify()
            return item

    # taken from py3.13
    def shutdown(self, immediate: bool = False, *, exception: type[BaseException] | None = None) -> None:
        '''Shut-down the queue, making queue gets and puts raise ShutDown.

        By default, gets will only raise once the queue is empty. Set
        'immediate' to True to make gets raise immediately instead.

        All blocked callers of put() and get() will be unblocked.

        If 'immediate', the queue is drained and unfinished tasks
        is reduced by the number of drained tasks.  If unfinished tasks
        is reduced to zero, callers of Queue.join are unblocked.
        '''
        with self.mutex:
            if exception is not None:
                self._shutdown_exception = exception
            self.is_shutdown = True
            if immediate:
                while self._qsize():
                    self._get()
                    if self.unfinished_tasks > 0:
                        self.unfinished_tasks -= 1
                # release all blocked threads in `join()`
                self.all_tasks_done.notify_all()
            # All getters need to re-check queue-empty to raise ShutDown
            self.not_empty.notify_all()
            self.not_full.notify_all()

    def clear(self):
        """Clears all items from the queue."""
        with self.mutex:
            unfinished = self.unfinished_tasks - len(self.queue)
            if unfinished <= 0:
                if unfinished < 0:
                    raise ValueError('task_done() called too many times')
                self.all_tasks_done.notify_all()
            self.unfinished_tasks = unfinished
            self.queue.clear()
            self.not_full.notify_all()


#: Sockets of the interpreter with the stop scope of the thread which created it (see watch_sockets()),
#: None if not watched (e.g. the FanFilm service).
_sockets: WeakKeyDictionary[Socket, Event | None] | None = None
#: Lock of `_sockets`.
_sockets_lock: Lock | None = None
#: Kodi aborted the current plugin call and its network is cut, a new socket is refused (see abort_network()).
network_aborted: bool = False


def _thread_scope() -> Event | None:
    """Return the stop scope (`stop_event`) of the current thread, see `CancelScope`."""
    import threading
    # not current_thread(): in a foreign thread it creates a _DummyThread, i.e. Thread.__init__() again (recursion)
    thread = threading._active.get(threading.get_ident())  # type: ignore[attr-defined]
    return getattr(thread, 'stop_event', None)


def inherit_thread_scopes() -> None:
    """
    A new plain thread (e.g. a ThreadPoolExecutor worker) shares the stop scope of the thread which creates it.

    Replaces `threading.Thread.__init__` of this interpreter. Stopping a provider thread stops its pool workers too
    (check_thread_cancel(), the socket cut), the provider code knows nothing about it. A FF thread has its own scope.
    """
    import threading
    orig_init = threading.Thread.__dict__.get('_ff_orig_init') or threading.Thread.__init__

    def init(self: threading.Thread, *args: Any, **kwargs: Any) -> None:
        """Create a thread in the stop scope of the current thread."""
        orig_init(self, *args, **kwargs)
        if (scope := _thread_scope()) is not None:
            self.stop_event = scope  # type: ignore[attr-defined]

    threading.Thread._ff_orig_init = orig_init  # type: ignore[attr-defined]  # the original one, on re-import of this module
    threading.Thread.__init__ = init  # type: ignore[method-assign]


def watch_sockets() -> None:
    """
    Register every socket of this interpreter with the stop scope of the current thread, see cut_sockets().

    Replaces `socket.socket.__init__` (SSL sockets too). The class belongs to this interpreter, Kodi and other
    add-ons (and the FF service) are not affected. The network of a new plugin call is enabled again.
    The urllib3 pools drop the connections of the cut sockets (`drop_cut_connections()`).
    """
    global _sockets, _sockets_lock, network_aborted
    import socket
    from threading import Lock
    from weakref import WeakKeyDictionary
    from .net import drop_cut_connections
    network_aborted = False
    if _sockets is None or _sockets_lock is None:
        _sockets, _sockets_lock = WeakKeyDictionary(), Lock()
    sockets, lock = _sockets, _sockets_lock
    orig_init = socket.socket.__dict__.get('_ff_orig_init') or socket.socket.__init__

    def init(self: socket.socket, *args: Any, **kwargs: Any) -> None:
        """
        Create a socket and register it, refuse a new one if the network is cut. A socket of a descriptor (`fileno`: the
        connection `accept()` of a server took, `fromfd()`) is no new connection: refused, its descriptor would leak open and
        its peer would wait for ever (a plugin call to the service at Kodi exit).
        """
        scope = _thread_scope()
        if kwargs.get('fileno', args[3] if len(args) > 3 else None) is None:
            if network_aborted:
                raise ConnectionAbortedError('FanFilm network is cut (Kodi aborted the plugin call)')
            if scope is not None and scope.is_set():
                raise ConnectionAbortedError('FanFilm network is cut (the thread is stopped)')
        orig_init(self, *args, **kwargs)
        with lock:
            sockets[self] = scope

    socket.socket._ff_orig_init = orig_init  # type: ignore[attr-defined]  # the original one, on re-import of this module
    socket.socket.__init__ = init  # type: ignore[method-assign]
    drop_cut_connections()  # a pooled connection whose socket is cut (closed on Windows) is not reused


def cut_sockets() -> None:
    """
    Shut down the sockets of the stopped scopes (all after abort_network()), a blocked read ends at once.

    A thread blocked in a socket read ignores any FF stop request (and Kodi kills a script which does not end
    in 5 s after its abort). The request fails as on a network error. A socket still connecting is not cut,
    call it again while the threads are finishing. No-op if the sockets are not watched.

    Windows: `shutdown()` does not wake a blocked read (Winsock), closing the handle does, so the socket is closed too
    (`notes/tools/winsock_abort_probe.py`); its OS handle directly, `socket.close()` keeps it while a `makefile()`
    (http.client) is open. Linux: `shutdown()` wakes it, `close()` from another thread does not.

    A listening socket is not cut: it blocks no read, its server polls it (`serve_forever()`) and stops by `shutdown()`.
    The service servers keep working until the service stop, Windows `select()` failed on the closed handle (WinError 10038).
    An idle pooled connection of urllib3 with the closed handle is dropped at its next use (`drop_cut_connections()`).
    """
    if _sockets is None or _sockets_lock is None:
        return
    import socket
    import sys
    from _socket import socket as os_socket
    close = sys.platform == 'win32'
    with _sockets_lock:
        items = list(_sockets.items())
    for sock, scope in items:
        if network_aborted or (scope is not None and scope.is_set()):
            try:
                if sock.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN):
                    continue
            except OSError:  # already closed or detached (wrapped by SSL)
                continue
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:  # not connected (yet), already closed or detached (wrapped by SSL)
                pass
            if close:
                try:
                    os_socket.close(sock)  # the handle, also with open makefile() streams; a later close() does nothing
                except OSError:
                    pass


def abort_network() -> None:
    """Cut the whole network of the plugin interpreter (Kodi aborts the call): all sockets, refuse new ones."""
    global network_aborted
    if _sockets is None:
        return
    network_aborted = True
    cut_sockets()
