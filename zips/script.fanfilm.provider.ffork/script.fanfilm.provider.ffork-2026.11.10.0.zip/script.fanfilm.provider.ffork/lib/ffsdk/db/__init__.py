"""The DB core of the SDK: the sqlite3 manager (`db`), the declarative ORM (`orm`) and the key-value store (`kvstore`)."""
