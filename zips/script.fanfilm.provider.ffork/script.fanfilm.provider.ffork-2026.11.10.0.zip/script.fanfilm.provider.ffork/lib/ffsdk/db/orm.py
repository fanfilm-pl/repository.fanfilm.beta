"""Small declarative ORM over sqlite3 (the DB layer of the SDK).

Tables are ``attrs``-style classes (:class:`DbTable`); columns are plain annotated fields, structured
sub-objects flatten into ``a::b`` columns, and queries are built fluently with :func:`select` /
:class:`Statement`. The layer is deliberately "dumb" — it persists rows and runs queries; cache
policy / object<->row mapping lives in the consumer (dependency direction ``db -> FFItem``).

Defining tables
---------------
::

    from typing import Optional

    class Show(DbTable):
        __tablename__ = 'show'
        __table_args__ = ('UNIQUE("tmdb")',)       # raw CREATE-TABLE constraints
        __table_indexes__ = ('tmdb',)              # secondary (non-unique) indexes
        id: PrimaryKey = None                      # auto INTEGER PRIMARY KEY
        title: str = ''                            # NOT NULL column
        tmdb: Optional[int] = None                 # nullable column
        episodes: 'list[Episode]' = relationship(back_populates='show')   # one-to-many

    class Episode(DbTable):
        __tablename__ = 'episode'
        id: PrimaryKey = None
        show_id: Optional[int] = field(foreign_key='show.id')
        show: Optional[Show] = relationship()      # many-to-one (FK ``show_id`` -> ``show.id``)
        number: int = 0

A structured field flattens into prefixed columns (``ref::type``, ``ref::ffid``, ...); ``field()``
adds ORM extras: ``converter=`` / ``default=`` (attrs), ``db_column=`` (override the SQL column leaf
name), ``foreign_key=``, ``on_update=`` + ``auto_generated=`` (server-set columns), ``dump``/``load``.

Connecting, create, write
-------------------------
::

    db = OrmDatabase('media', Show, Episode, version=1)   # tables created/migrated on first connect
    with db.cursor() as cur:
        cur.add(Show(title='Foo', tmdb=42))               # INSERT (no PK) or UPDATE (PK present)
        cur.exec(update(Show).set(title='Bar').where(Show.id == 1))
        cur.exec(delete(Episode).where(Episode.show_id == 1))

Querying
--------
::

    select(Show).where(Show.tmdb == 42).order_by(Show.title)        # Show.col build WHERE/ORDER exprs
    select(Episode).join(Show).where(Show.tmdb == 42)               # INNER JOIN, ON inferred from rel
    select(Episode).join(Show, Episode.show_id == Show.id, outer=True)   # explicit LEFT JOIN
    select(Episode).joinedload('show')                              # eager scalar rel in ONE query (LEFT JOIN)
    select(Show).prefetch('episodes')                               # eager collection (selectin, anti-N+1)

    with db.cursor() as cur:
        rows = cur.exec(select(Show).where(Show.tmdb == 42)).all()  # .all() / .first() / .iter()

Key pieces
----------
* :class:`DbTable` — table/row model (``__tablename__``, ``__table_args__``, ``__table_indexes__``).
* :func:`field` / :data:`PrimaryKey` / :func:`relationship` — column / PK / related-object declarations.
* :func:`select` / :func:`update` / :func:`delete` -> :class:`Statement` — fluent query builder
  (``where`` / ``order_by`` / ``join`` / ``outerjoin`` / ``prefetch`` / ``joinedload`` / ``set``).
* :class:`Expr` — a SQL fragment + bound params; comparison operators bind values safely (column vs
  column renders inline). :class:`Result` — turns rows into objects/tuples.
* :class:`OrmDatabase` — named DB with create/migrate-on-connect; ``DbCursor`` (``.add``/``.exec``).
"""

from typing import (
    Optional, Union, Any, Tuple, List, Dict, Set,
    Mapping, Sequence, Iterable, Iterator, Generator, Callable,
    Type, TypeVar, ClassVar,
    overload,
    NamedTuple,
    TYPE_CHECKING,
)
from typing_extensions import (
    Annotated, Protocol,
    dataclass_transform, get_origin, get_args, cast,
    Self, Generic, TypeAlias, Literal,
)
import typing_extensions as tp
import sys
from threading import RLock
from types import MappingProxyType
from enum import Enum
from weakref import ref
import attrs
import attr
import dataclasses as dc
from itertools import zip_longest, chain
from contextlib import contextmanager, nullcontext
from sqlite3 import DatabaseError, InterfaceError, ProgrammingError, Error as DbError
from functools import wraps
from time import time
from simpleeval import simple_eval
from .db import (sqlite3_column_type, sql_dump, render_column_type, PrimaryKey, Db, DbCursor, SQL,
                 update_db_version, Lock, db_manager, known_types_by_name, options)
from ..types import (is_optional, remove_optional, eval_annotations, ReferenceType, TypeForm, ann_type,
                     find_arg_descr, ArgDescr, get_type_hints, PY38_TYPES)
from ..log import fflog, fflog_exc
from ..tricks import MISSING, is_namedtuple_class, namedtuple_attrs, singleton, dataclass_attrs, super_get_attr
if TYPE_CHECKING:
    from pathlib import Path
    from attr import _ReprArgType, _OnSetAttrArgType, _ValidatorArgType, _ConverterType


def deep_get_attr(obj: object, key: str, *, safe: bool = False) -> Any:
    """Deep get attribute like super_get_attr() but separated with '::'."""
    if '::' not in key:
        return getattr(obj, key)
    for k in key.split('::'):
        if safe and obj is None:
            return None
        obj = getattr(obj, k)
    return obj


def quote(s: Optional[str]) -> str:
    """Return a SQL-quoted identifier (embedded double-quotes doubled, per SQL — not backslash)."""
    s = (s or '').replace('"', '""')
    return f'"{s}"'


RowData: TypeAlias = Union['DbTable', Mapping[str, Any]]
T = TypeVar('T')
V = TypeVar('V')
R = TypeVar('R')
TI = TypeVar('TI', bound='DbTable')
TABLE = TypeVar('TABLE', bound=Type['DbTable'])
# StatementType = TypeVar('StatementType', bound=Union[TABLE, Any])


class _FactoryProtocol:
    factory: Callable[..., Any]
    takes_self: bool


Factory = cast(Type[_FactoryProtocol], attr.Factory)

DbFieldDump: TypeAlias = Callable[..., Any]
DbFieldLoad: TypeAlias = Callable[..., Any]


@singleton
class SkipColumnType:
    """General type of singleton SKIP_COLUMN, this column should not be modified."""

    def __repr__(self) -> str:
        return 'SKIP_COLUMN'


@singleton
class AutoColumnType:
    """General type of singleton AUTO, this column is automaticly modfied."""

    def __repr__(self) -> str:
        return 'AUTO'


#: General skip column singleton object.
SKIP_COLUMN = SkipColumnType()

#: General auto column singleton object.
AUTO = AutoColumnType()


class AutoGenerated(Enum):
    """AutoGenerated mode, how to get column values."""
    NO = 'no'
    YES = 'yes'
    ONLY = 'only'
    IF_VALUES = 'if_values'


def is_dbtable(obj: Any) -> bool:
    """Return True if `obj` is DbTable class (not instance)."""
    return isinstance(obj, DbTableMeta) and issubclass(obj, DbTable)


@attrs.frozen
class AttrsFieldExtension:
    """Helper. ORM-specific extras attached to an attrs field via its metadata.

    Carries the ORM options passed to `field()` (dump/load/on_update/auto_generated/
    foreign_key/db_column) from class definition time to `create_field()`, which copies
    them onto the resolved `DbField`.
    """
    #: Key under which this object is stored in the attrs field metadata mapping.
    METADATA: ClassVar[str] = '_FF_AttributeExtra'
    #: Custom value serializer (Python -> DB). None -> use the type's default conversion.
    dump: Optional[DbFieldDump] = None
    #: Custom value deserializer (DB -> Python). None -> use the type's default conversion.
    load: Optional[DbFieldLoad] = None
    #: Value (or callable applied to the current value) written on every UPDATE/INSERT;
    #: MISSING -> the column is not auto-touched. SKIP_COLUMN -> never written.
    on_update: Any = MISSING
    #: True -> value is produced by the DB/by `on_update`, not taken from the object on plain writes.
    auto_generated: bool = False
    #: Referenced table/column for a foreign-key constraint (advisory; raw SQL is code-controlled).
    foreign_key: Optional[str] = None
    #: Override the SQL column (leaf) name; the Python attribute keeps `field`'s own name.
    #: When the field is nested, only this leaf component is replaced in the flattened path.
    db_column: Optional[str] = None


class DbField(NamedTuple):
    """Helper. Resolved info for one DB table field (a leaf column or a structured group)."""
    #: Leaf Python-attribute name of this field (never overridden; e.g. 'user_id').
    name: str
    #: Flattened SQL column path (override-aware): components are `db_column or name`, joined by '::'.
    column: str
    #: Resolved (unwrapped) value type: Optional/Annotated markers stripped (see `optional`/`meta`).
    type: TypeForm[Any]
    #: True if the annotation was Optional (the column accepts NULL).
    optional: bool = False
    #: Extra annotation markers split off the type (the Annotated metadata tuple).
    meta: Sequence[str] = ()
    #: Default value (MISSING -> no default; drives DDL DEFAULT and object construction).
    default: Any = MISSING
    #: Flattened parent-prefix on the ATTRIBUTE side (field names, '::'-joined, trailing '::').
    #: Mostly vestigial after the flat `_from_row`; kept for introspection.
    prefix: str = ''
    #: Flattened Python-attribute path (always field names, never overridden), joined by '::'.
    #: Used to read/write the value on the object; `column` is the SQL side, `attr` is the Python side.
    attr: str = ''
    #: Custom value serializer (Python -> DB); see `field(dump=...)`.
    dump: Optional[DbFieldDump] = None
    #: Custom value deserializer (DB -> Python); see `field(load=...)`.
    load: Optional[DbFieldLoad] = None
    #: Auto-write value/callable on UPDATE/INSERT; MISSING -> none, SKIP_COLUMN -> never write.
    on_update: Any = MISSING
    #: True -> value comes from the DB/`on_update`, not from the object on plain writes.
    auto_generated: bool = False
    #: Referenced table/column for a foreign-key constraint (advisory).
    foreign_key: Optional[str] = None
    #: Whether the attrs field appears in ``__init__`` (mirrors ``field(init=...)``). When False (e.g.
    #: an ``auto_generated`` column), ``_from_row`` sets it AFTER construction instead of passing it.
    init: bool = True
    #: Type-conversion descriptor resolved once from the (full) annotation; used to load/dump
    #: the column value. None when the type has no registered Annotated/ArgDescr conversion.
    arg: Optional[ArgDescr] = None
    #: For a structured field: its sub-fields keyed by attribute name; None for a leaf column.
    fields: Optional[Mapping[str, 'DbField']] = None


# @with_function_typing(attr.field)
def field(*,  # type: ignore  ("xfield" is marked as overload, but no implementation is provided )
          default: Optional[T] = attrs.NOTHING,
          validator: Optional['_ValidatorArgType[T]'] = None,
          repr: '_ReprArgType' = True,
          hash: Optional[bool] = None,
          init: bool = True,
          metadata: Optional[Mapping[Any, Any]] = None,
          converter: Optional['_ConverterType'] = None,
          factory: Optional[Callable[[], T]] = None,
          kw_only: bool = False,
          eq: Optional[bool] = None,
          order: Optional[bool] = None,
          on_setattr: Optional['_OnSetAttrArgType'] = None,
          alias: Optional[str] = None,
          type: Optional[type] = None,
          # -- ORM extra --
          dump: Optional[DbFieldDump] = None,
          load: Optional[DbFieldLoad] = None,
          on_update: Any = MISSING,
          auto_generated: bool = False,
          foreign_key: Optional[str] = None,
          db_column: Optional[str] = None,
          **kwargs):
    """Return an attrs field carrying ORM extras. See attrs.field() for the standard arguments.

    ORM-specific arguments (stored as `AttrsFieldExtension` metadata, copied onto `DbField`):
        dump: Custom value serializer Python -> DB. None uses the type's default conversion.
        load: Custom value deserializer DB -> Python. None uses the type's default conversion.
        on_update: Value (or callable applied to the current value) written on every UPDATE/INSERT;
            MISSING means the column is not auto-touched, SKIP_COLUMN means it is never written.
            Passing `on_update` with no `default` makes the column also auto-filled on INSERT.
        auto_generated: True if the value is produced by the DB / by `on_update` rather than taken
            from the object on plain writes.
        foreign_key: Referenced table/column for a foreign-key constraint (advisory).
        db_column: Override the SQL column (leaf) name while the Python attribute keeps this field's
            own name. For a nested field only this leaf component is replaced in the flattened
            '::'-path (e.g. mid-path override yields ``a::override_b::c``); the attribute path
            stays ``a::b::c``.
    """
    if not TYPE_CHECKING:
        if default is attrs.NOTHING and on_update is not MISSING:
            default = MISSING  # type: ignore[reportAssignmentType]  # use on_update() on INSERT too
    if metadata is None:
        meta = {}
    else:
        meta = dict(metadata)
    meta[AttrsFieldExtension.METADATA] = AttrsFieldExtension(dump=dump, load=load, on_update=on_update,
                                                             auto_generated=auto_generated, foreign_key=foreign_key,
                                                             db_column=db_column)
    return attrs.field(default=default, validator=validator, repr=repr, hash=hash, init=init, metadata=meta,
                       type=type, converter=converter, factory=factory, kw_only=kw_only, eq=eq, order=order,
                       on_setattr=on_setattr, alias=alias, **kwargs)


class Relationship(Generic[TI, V]):
    """Relationship descriptor."""

    def __init__(self, *,
                 back_populates: Optional[str] = None,
                 on: Optional[str] = None,
                 when: Optional[str] = None,
                 ) -> None:
        self.name: str = ''
        self.ann: Optional[Type] = None
        self.is_table: bool = False
        self.back_populates: Optional[str] = back_populates
        self._on: Optional[str] = on
        self.when = when

    def __repr__(self) -> str:
        return f'Relationship(name={self.name!r}, back_populates={self.back_populates!r}, on={self._on!r}, when={self.when!r}, is_table={self.is_table!r}, ann={self.ann!r})'

    @property
    def on(self) -> str:
        if self._on is None:
            self._on = f'{self.name}_id'
        return self._on

    def __set_name__(self, objtype: Type[TI], name: str) -> None:
        ann = getattr(objtype, '__annotations__', {})
        self.name: str = name
        self.ann = ann.get(name)
        self.is_table = is_dbtable(self.ann)
        # if not self.on:
        #     iname = f'{name}_id'
        #     breakpoint()
        #     if (iann := ann.get(iname)) and (ival := getattr(objtype, iname, None)):# and isinstance(ival, attrs.Field):
        #         ...

    @overload
    def __get__(self, obj: None, objtype: Type[TI]) -> Self: ...

    @overload
    def __get__(self, obj: TI, objtype: None) -> V: ...

    def __get__(self, obj: Optional[TI], objtype: Optional[Type[TI]] = None) -> Any:
        if objtype is None:
            return self
        if obj and (val := obj._rel_values.get(self.name, MISSING)) is not MISSING:
            return val
        if obj and (key := obj.__primary_index__) and (oid := getattr(obj, key, None)):
            with obj._db_cursor() as cur:
                if cur:
                    if isinstance(self.ann, str):
                        try:
                            # Resolve the lazy forward-ref annotation; needs the owner module's
                            # namespace (localns) to see a sibling table class by name.
                            self.ann = eval_annotations(self.ann, localns=sys.modules[obj.__class__.__module__].__dict__)
                        except Exception:
                            self.ann = None
                            fflog(f'Can not evaluate annotations for type {obj.__class__.__name__}')
                            return None
                    ann = None if self.ann is None else remove_optional(self.ann)
                    if isinstance(ann, type) and issubclass(ann, DbTable) and (fid := super_get_attr(obj, self.on, None)) is not None:
                        if self.when and not simple_eval(self.when, names=lambda node: getattr(obj, node.id)):
                            return None
                        # Cache the loaded object (like the collection branch below) so repeated
                        # access does not re-query the DB.
                        obj._rel_values[self.name] = val = cur.get(ann, fid)
                        return val
                    origin, args = get_origin(ann), get_args(ann)
                    if origin is Annotated:
                        origin, args = get_origin(args[0]), get_args(args[0])
                    # if is_union:
                    if isinstance(origin, type) and issubclass(origin, Sequence):
                        if not any(issubclass(origin, t) for t in (tuple, list, set)):
                            origin = tuple
                        typ = args[0]
                        if isinstance(typ, type) and issubclass(typ, DbTable) and self.back_populates:
                            # stmt = select(typ).where(getattr(typ, self.on) == oid)
                            stmt = select(typ).where(getattr(typ, f'{self.back_populates}_id') == oid)
                            val = origin(cur.exec(stmt).iter())
                            obj._rel_values[self.name] = val
                            return val
        # relationship in where()
        if obj is None and objtype._fields_info and (field := objtype._fields_info.get(self.on)):
            foreign_key = field.foreign_key
            if not foreign_key and self.on and self.on.endswith('_id'):
                foreign_key = f'{self.on[:-3]}.{objtype.__primary_index__ or "id"}'
            return TableColumnExpr(table=objtype, field=field, on=foreign_key)
        return None

    def __set__(self, obj: TI, value: Any) -> None:
        """Assign the related object(s) directly, overriding the lazy DB load (cached in `_rel_values`)."""
        obj._rel_values[self.name] = value

    def __delete__(self, obj: TI) -> None:
        """Drop the assigned/cached value so the next read lazily loads from the DB again."""
        obj._rel_values.pop(self.name, None)


def relationship(*,
                 init: Literal[False] = False,
                 back_populates: Optional[str] = None,
                 on: Optional[str] = None,
                 when: Optional[str] = None,
                 ) -> Any:
    return Relationship(back_populates=back_populates, on=on, when=when)


def _drop_relationships(cls: type, fields: List[attr.Attribute]) -> List[attr.Attribute]:
    """Attrs field transformer: a `Relationship` stays a class descriptor (lazy load, column expr), not an attrs field."""
    return [f for f in fields if not isinstance(f.default, Relationship)]


def _relationships(root: Type['DbTable']) -> Dict[str, 'Relationship']:
    """Relationship descriptors of `root` by name (the class and its bases, a subclass wins)."""
    return {name: rel for kls in reversed(root.__mro__) for name, rel in vars(kls).items() if isinstance(rel, Relationship)}


def _resolve_relationship(root: Type['DbTable'], name: str) -> 'Relationship':
    """Find the Relationship named `name` on `root`."""
    rel = _relationships(root).get(name)
    if rel is None:
        raise ValueError(f'{root.__tablename__} has no relationship {name!r}')
    return rel


def _resolve_rel_target(rel: 'Relationship', module: str) -> Tuple[Any, bool]:
    """Return ``(target_table, is_collection)`` for `rel`; resolves a forward-ref annotation."""
    ann = rel.ann
    if isinstance(ann, str):
        try:
            ann = eval_annotations(ann, localns=sys.modules[module].__dict__)
        except Exception:
            return None, False
    if ann is None:
        return None, False
    ann = remove_optional(ann)
    origin, args = get_origin(ann), get_args(ann)
    if origin is Annotated and args:
        ann = args[0]
        origin, args = get_origin(ann), get_args(ann)
    if isinstance(origin, type) and issubclass(origin, Sequence) and args:
        return args[0], True
    return ann, False


class ValueProperty:

    def __init__(self, field: DbField) -> None:
        self.field: DbField = field

    @overload
    def __get__(self, instance: None, objtype: TABLE) -> 'TableColumnExpr[TABLE]': ...

    @overload
    def __get__(self, instance: 'TI', objtype: Type['DbTable']) -> TI: ...

    def __get__(self, instance: Optional[TI], objtype: TABLE) -> Union[TI, 'TableColumnExpr[TABLE]']:
        # print(f'__get__({bool(instance)}, {objtype})  !!!!!!!!!!!!!!!!!')
        # if instance:
        #     return instance.__dict__[self.field.name]
        assert instance is None
        return TableColumnExpr(table=objtype, field=self.field)

    # def __set__(self, instance: str, value: Any) -> None:
    #     print(f'__set__(instance, {value=})  !!!!!!!!!!!!!!!!!')
    #     object.__setattr__(instance, self.field.name, value)
    #     # setattr(instance, self.field.name, value)
    #     # instance.__dict__[self.field.name] = value

    # def __set_name__(self, owner, name: str) -> None:
    #     print(f'__set_name__({owner=}, {name=}) !!!!!')


@dataclass_transform(kw_only_default=True, field_specifiers=(attr.attrib, attr.field, field, relationship, Relationship, DbField))
class DbTableMeta(type):

    def __new__(cls, name, bases: Tuple[Type[Any], ...], dct: Dict[str, Any], *, table: bool = True, _base_orm_class: bool = False):
        table_name = dct.get('__tablename__', MISSING)
        if table_name is MISSING:
            table_name = dct['__tablename__'] = name.lower()
        if table and (not table_name or not isinstance(table_name, str)):
            raise TypeError(f'Missing __tablename__ in DbTable {name!r}')
        kls: Type[DbTable] = super().__new__(cls, name, bases, dct)
        # print(f' > meta.__new__({name=}, {bases=}, {dct=}): {kls=}')
        if '__attrs_attrs__' in dct:
            return kls  # already modfied by attrs (avoid recursion in slots class recreate)
        kls = attrs.define(kw_only=True, slots=False, field_transformer=_drop_relationships)(kls)
        # NOTE: fields are NOT forced here on purpose — possible forward references would not yet
        # be resolvable; `_fields` is computed lazily on first use.
        return kls

    # def __setattr__(cls, name: str, value: Any) -> None:
    #     ...

    # def __init_subclass__(cls, **kwargs) -> None:
    #     super().__init_subclass__(**kwargs)
    #     # print(f' > meta.__init_subclass__({cls=}, {kwargs=})')

    @property
    def _fields(self) -> Dict[str, DbField]:
        """Get fields."""
        def create_field(field: attr.Attribute, ann: Dict[str, TypeForm[Any]], *, optional: bool = False, prefix: str = '',
                         db_prefix: str = '', used: Optional[Set[TypeForm[Any]]] = None, default: Any = MISSING) -> DbField:
            if used is None:
                used = set()
            typ: TypeForm[Any] = ann[field.name]
            # Resolve the type-conversion descriptor ONCE from the FULL annotation (before it is split),
            # so Annotated/Optional/Union markers are honoured (find_arg_descr searches the annotation,
            # not the already-split meta). Used later by _from_row / _dump_column_value.
            arg, _ = find_arg_descr(typ, quiet=True)
            optional = optional or is_optional(typ)
            fields = None
            typ, meta = ann_type(typ)
            if is_optional(typ):
                optional = True
                typ = remove_optional(typ)

            if isinstance(field.default, Factory):
                default = field.default.factory()
            elif field.default is not attrs.NOTHING and field.default is not dc.MISSING:
                default = field.default
            # elif isinstance(field, DcFieldExtension) and field.on_update is not MISSING:
            #     default = field.on_update
            if default is attrs.NOTHING or default is dc.MISSING:
                default = MISSING
            elif default is AUTO:
                if optional:
                    default = None
                else:
                    default = MISSING

            metadata: Optional[AttrsFieldExtension] = (field.metadata or {}).get(AttrsFieldExtension.METADATA)
            if metadata:
                kwargs = {
                    'dump': metadata.dump,
                    'load': metadata.load,
                    'on_update': metadata.on_update,
                    'auto_generated': metadata.auto_generated,
                    'foreign_key': metadata.foreign_key,
                }
            else:
                kwargs = {}
            # Effective SQL leaf: db_column override (this component only) or the field name.
            # The attribute path always uses the field name; only the SQL column path may differ.
            db_column: Optional[str] = metadata.db_column if metadata else None
            eff = db_column or field.name

            if attrs.has(typ) or dc.is_dataclass(typ) or is_namedtuple_class(typ):
                if typ in used:
                    raise TypeError(f'DB Table type recursion {self.__name__}.{prefix}{field.name}: {typ.__name__}')
                used.add(typ)
                try:
                    pre = f'{prefix}{field.name}::'
                    db_pre = f'{db_prefix}{eff}::'
                    sub_ann = get_type_hints(typ, include_extras=True)
                    if attrs.has(typ):
                        sub_fields = attrs.fields(typ)
                    elif is_namedtuple_class(typ):
                        sub_fields = namedtuple_attrs(typ)
                    elif dc.is_dataclass(typ):
                        sub_fields = dataclass_attrs(typ)
                    else:
                        sub_fields = ()
                    if default is MISSING or default is attrs.NOTHING:
                        sub_def = ()
                    elif optional and default is None:
                        sub_def = ()
                    else:
                        if not isinstance(default, typ):
                            raise TypeError(f'DB Table type of default mismatch {self.__name__}.{prefix}{field.name}: {typ.__name__} is not ({type(default)}')
                        sub_def = tuple(getattr(default, f.name) for f in sub_fields if not f.name.startswith('_'))
                    assert len(sub_fields) >= len(sub_def)
                    fields = {f.name: create_field(f, sub_ann, optional=optional, prefix=pre, db_prefix=db_pre, used=used, default=d)
                              for f, d in zip_longest(sub_fields, sub_def, fillvalue=default)}  # `sub_fields` could NOT be shorter then `sub_def`
                finally:
                    used.discard(typ)

            return DbField(name=field.name, column=f'{db_prefix}{eff}', type=typ, optional=optional, meta=meta, default=default,
                           prefix=prefix, attr=f'{prefix}{field.name}', init=getattr(field, 'init', True),
                           arg=arg, fields=fields, **kwargs)

        tab = cast(Type[DbTable], self)
        if tab._fields_info is None:
            try:
                ann = get_type_hints(self, include_extras=True)
            except Exception:
                ann = get_type_hints(self, {**tp.__dict__, **PY38_TYPES, **globals()}, sys.modules[tab.__module__].__dict__, include_extras=True)
            if attrs.has(self):
                fields = attrs.fields(self)
            elif is_namedtuple_class(self):
                fields = namedtuple_attrs(self)
            elif dc.is_dataclass(self):
                fields = dataclass_attrs(self)
            else:
                fields = ()
            tab._fields_info = {f.name: create_field(f, ann) for f in fields if not f.name.startswith('_')}
            # ???
            for f in tab._fields_info.values():
                setattr(self, f.name, ValueProperty(f))
                if 'PRIMARY KEY' in f.meta:
                    tab.__primary_index__ = f.name
                    tab.__skip_fileds__ = (*tab.__skip_fileds__, f.name)
        return tab._fields_info


class DbTable(metaclass=DbTableMeta, table=False, _base_orm_class=True):

    #: SQL table name (also ``__table_args__`` may add raw CREATE-TABLE constraints, e.g. UNIQUE).
    __tablename__: ClassVar[str] = ''
    #: Secondary (non-unique) index declarations. Each entry is a column name or a tuple of column
    #: names (UNIQUE constraints belong in ``__table_args__``). See ``_create_indexes_query``.
    __table_indexes__: ClassVar[Sequence[Union[str, Sequence[str]]]] = ()
    #: Field names skipped on writes (e.g. the auto primary key); maintained by ``model_init``.
    __skip_fileds__: ClassVar[Sequence[str]] = ()
    #: Name of the primary-key field (``id`` by default), or None if the table has no PK.
    __primary_index__: ClassVar[Optional[str]] = None
    # --- private fields ---
    #: Resolved field map (name -> DbField), computed lazily on first use; the schema source of truth.
    _fields_info: ClassVar[Optional[Dict[str, DbField]]] = None
    #: Owning DB/repo bound on load or add (used to lazily open a cursor for relationship loads).
    _db: 'Union[Db, OrmDatabase, None]' = attrs.field(init=False, repr=False, default=None)
    #: Weakref to the cursor this instance was loaded with (for lazy relationship queries).
    _db_cur: Optional[ReferenceType[DbCursor]] = attrs.field(init=False, repr=False, default=None)
    #: Column values as last read from / written to the DB (the persisted snapshot of this row).
    _db_values: Dict[str, Any] = attrs.field(init=False, repr=False, factory=dict)
    #: Cached related objects per relationship name (set by lazy load or eager prefetch/joinedload).
    _rel_values: Dict[str, Any] = attrs.field(init=False, repr=False, factory=dict)

    def __new__(cls, **kwargs) -> Self:
        """Create object."""
        obj = super().__new__(cls)
        obj._db = None
        obj._db_cur = None
        obj._db_values = {}
        # Also seed `_rel_values`: a custom __init__ (e.g. MediaPlayInfo) bypasses the attrs-generated
        # __init__ that would otherwise create it, and relationship access reads it unconditionally.
        obj._rel_values = {}
        return obj

    @classmethod
    def model_init(cls) -> None:
        """Initialize model (force fields initialization)."""
        cls._fields  # force fields initialization

    def model_dump(self, *, exclude: Optional[Iterable[str]] = None) -> Mapping[str, Any]:
        """Dump data as dict (values)."""
        exclude = set(exclude or ())
        # `self.__class__._fields` forces field resolution; reading the cached `_fields_info`
        # directly would silently yield {} when it has not been computed yet.
        return {k: getattr(self, k) for k in self.__class__._fields if k not in exclude}

    def model_serialize(self, *, exclude: Optional[Iterable[str]] = None) -> Mapping[str, Any]:
        """Dump data as dict (serialization)."""

        def dump(obj: object, fields: Iterable[DbField], *, exclude: Optional[Iterable]) -> Iterator[Tuple[str, Any]]:
            for field in fields:
                if exclude and field.name in exclude:
                    continue
                if field.dump is not None:
                    yield field.name, field.dump(self)
                elif field.fields is None:
                    yield field.name, getattr(obj, field.name)
                else:
                    subobj = getattr(obj, field.name)
                    if subobj is None:
                        yield field.name, None
                    else:
                        yield field.name, dict(dump(getattr(obj, field.name), field.fields.values(), exclude=None))

        if exclude:
            exclude = set(exclude)
        return dict(dump(self, self.__class__._fields.values(), exclude=exclude))

    def _update_db(self, db: 'Union[Db, OrmDatabase, None]', cur: Optional[DbCursor]) -> None:
        """Update current DB reference."""
        if self._db is None:
            self._db = db
            if cur is not None:
                self._db_cur = ref(cur)

    @contextmanager
    def _db_cursor(self) -> Generator[Optional[DbCursor], None, None]:
        """Statement with DB cursor (if avaliable)."""
        cur: Optional[DbCursor] = None if self._db_cur is None else self._db_cur()
        if cur is not None and not cur.closed:
            # current opened cursor, we should NOT close it
            yield cur
        elif self._db is not None:
            # no cursor but we have DB, create new cursor
            with self._db.cursor() as cur:
                yield cur
        else:
            # no DB
            yield None

    @classmethod
    def _create_columns_query(cls) -> str:
        """Return sqlite3 create table columns part of query."""

        def get_col(field: DbField, *, optional: bool = False) -> Iterator[Tuple[str, str]]:
            if field.fields is None:
                if isinstance(field.type, str):  # impossible at this moment, get_type_hints() raises NameError()
                    sql_type = field.type
                else:
                    sql_type = sqlite3_column_type.get(field.type, 'TEXT')
                if field.default is attrs.NOTHING:
                    if options.tty():
                        import sty
                        fflog(f'{sty.bg.red}ERROR:{sty.rs.all} NOTHING as default in {cls.__name__}.{field.name}: {field}')
                    else:
                        fflog(f'ERROR: NOTHING as default in {cls.__name__}.{field.name}: {field}')
                yield field.column, render_column_type(sql_type, meta=field.meta,
                                                       optional=optional or field.optional, default=field.default)
            else:
                for sub in field.fields.values():
                    yield from get_col(sub, optional=optional)

        query = ', '.join((f'{quote(name)} {ftype}') for f in cls._fields.values() for name, ftype in get_col(f))
        return query

    @classmethod
    def _create_table_query(cls, *, if_not_exists: bool = True) -> str:
        """Return sqlite3 create table query."""
        tab_def = [cls._create_columns_query()]
        tab_args = getattr(cls, '__table_args__', None)
        if tab_args:
            for arg in tab_args:
                if isinstance(arg, str):
                    tab_def.append(arg)
        todo = ['CREATE TABLE']
        if if_not_exists:
            todo.append('IF NOT EXISTS')
        cmd = ' '.join(todo)
        return f'{cmd} {quote(cls.__tablename__)} ({", ".join(tab_def)})'

    @classmethod
    def _create_indexes_query(cls) -> List[str]:
        """Return ``CREATE INDEX IF NOT EXISTS`` statements declared in ``__table_indexes__``.

        Each entry is a single column name or a tuple of column names (a flattened ``a::b`` column
        path is fine). The index name is derived as ``<table>__<col_col...>`` ('::' -> '_'). UNIQUE
        indexes are NOT produced here -- declare uniqueness in ``__table_args__``.
        """
        queries: List[str] = []
        for spec in getattr(cls, '__table_indexes__', None) or ():
            cols = (spec,) if isinstance(spec, str) else tuple(spec)
            name = f'{cls.__tablename__}__' + '_'.join(c.replace('::', '_') for c in cols)
            col_sql = ', '.join(quote(c) for c in cols)
            queries.append(f'CREATE INDEX IF NOT EXISTS {quote(name)} ON {quote(cls.__tablename__)} ({col_sql})')
        return queries

    @classmethod
    def _column_fields(cls, *, primary_index: bool = True, column: Optional[str] = None, updates: bool = True) -> Mapping[str, DbField]:
        """Return sqlite3 column for query."""
        def get(field: DbField) -> Iterator[Tuple[str, DbField]]:
            if updates or field.on_update is MISSING:
                if field.fields is None:
                    yield field.column, field
                else:
                    for sub in field.fields.values():
                        yield from get(sub)

        fields = cls._fields.values()
        if column:
            return {c: g for f in fields if f.name == column for c, g in get(f)}
        if primary_index or not cls.__primary_index__:
            forbidden = ''
        else:
            forbidden = cls.__primary_index__
        return {c: g for f in fields if f.name != forbidden for c, g in get(f)}

    @classmethod
    def _from_row(cls, row: Mapping[str, Any]) -> Self:
        """Create new object from a flat row dict keyed by the SQL column path.

        Each leaf value is fetched by the field's absolute `column` (no progressive prefix
        stripping), so arbitrarily deep nesting and `db_column` overrides both work; nested
        objects are then assembled by their Python attribute `name`.
        """

        def build(fields: Mapping[str, DbField]) -> Iterator[Tuple[str, object]]:
            for name, f in fields.items():
                if name.startswith('_'):
                    continue
                if f.fields:
                    values = dict(build(f.fields))
                    if f.optional and all(v is None for v in values.values()):
                        yield name, None
                    else:
                        try:
                            yield name, f.type(**values)
                        except Exception:
                            fflog(f'>>>>> {f.type=}, {row=}, {values=}')
                            raise
                elif (value := row.get(f.column, MISSING)) is not MISSING:
                    if value is not None:
                        try:
                            pure_type = f.type if isinstance(f.type, type) else None
                            if f.arg is not None:
                                value = f.arg.load(str(value), f.type, f.meta)
                            elif pure_type and (conv := known_types_by_name.get(pure_type.__name__)):
                                value = conv(value)
                            elif pure_type and issubclass(pure_type, Enum):
                                if isinstance(value, str) and value.isdecimal():
                                    value = pure_type(int(value))
                                else:
                                    value = pure_type(value)
                            elif pure_type:
                                value = pure_type(value)
                        except Exception as exc:
                            # Lenient load: keep the raw value, but surface the failed conversion
                            # (usually bad/drifted data or a schema mismatch) instead of hiding it.
                            type_name = getattr(f.type, '__name__', f.type)
                            fflog(f'[DB] {cls.__name__}.{f.column}: cannot convert {value!r} to {type_name} ({exc}); using raw value')
                    yield name, value

        # `init=False` columns (e.g. auto_generated) are still SELECTed, but the generated __init__
        # does not accept them -> set them after construction (ValueProperty has no __set__, so the
        # value lands in the instance __dict__).
        fields_info = cls._fields_info or {}
        init_kwargs: Dict[str, Any] = {}
        post_set: Dict[str, Any] = {}
        for name, value in build(fields_info):
            if fields_info[name].init:
                init_kwargs[name] = value
            else:
                post_set[name] = value
        obj = cls(**init_kwargs)
        for name, value in post_set.items():
            try:
                setattr(obj, name, value)
            except (attrs.exceptions.FrozenInstanceError, dc.FrozenInstanceError):
                # Frozen attrs/dataclass: set the value by force (bypassing the frozen protection) so we can load auto-generated fields.
                object.__setattr__(obj, name, value)
        obj._db_values = row  # type: ignore  # `_db_values` is hidden instance attribute
        return obj

    @classmethod
    def _select(cls) -> 'Statement':  # TODO: remove?
        """Execute sqlite3 select query."""
        return Statement(cls, statement='SELECT')

    @classmethod
    def _get(cls, cur: DbCursor, id: int) -> Optional[Self]:
        """Return query for get()."""
        if not cls.__primary_index__:
            return None
        stmt = Statement(cls).where(Expr(f'{quote(cls.__primary_index__)} = ?', [id]))
        result = cur.exec(stmt)
        return result.first()

    def _asdict(self, *, columns: Optional[Iterable[str]] = None, primary_index: bool = True) -> Dict[str, Any]:
        if columns is None:
            primary = self.__primary_index__
            return {f.name: getattr(self, f.name)
                    for f in attrs.fields(self.__class__) if primary_index or f.name != primary}
        else:
            return {name: getattr(self, name) for name in columns}

    @staticmethod
    def _dump_column_value(val: Any, field: DbField) -> Any:
        """Encode a single value for SQL (enum -> Annotated dumper or its raw value)."""
        if isinstance(val, Enum):
            if field.arg is not None:
                return field.arg.dump(val, field.type, field.meta)
            return val.value
        return val

    def _values_for(self, columns: Mapping[str, DbField]) -> Dict[str, Any]:
        """Flattened (``a::b``) and dumped values for `columns` (``{column: value}``).

        The single write-path value extractor: used by both the object path
        (:meth:`_prepare_insert` via :meth:`_column_values`) and the :class:`Statement` path,
        so a nested sub-object is always spread to its flat columns and can be stored in SQL.
        """
        out: Dict[str, Any] = {}
        for col, f in columns.items():
            v = self._get_value(f)
            if v is MISSING or v is SKIP_COLUMN:
                v = None
            out[col] = self._dump_column_value(v, f)
        return out

    def _column_values(self, *, primary_index: bool = True, column: Optional[str] = None, updates: bool = True,
                       auto_generated: AutoGenerated = AutoGenerated.YES) -> Dict[str, Any]:
        columns = self._column_fields(primary_index=False)
        values: Dict[str, Tuple[Any, DbField]] = {}
        if auto_generated in (AutoGenerated.NO, AutoGenerated.YES, AutoGenerated.IF_VALUES):
            values.update((f.column, (v, f)) for f in columns.values()
                          if not f.auto_generated and (v := self._get_value(f)) is not MISSING and v is not SKIP_COLUMN and v != self._db_values.get(f.column, MISSING))
        if auto_generated in (AutoGenerated.YES, AutoGenerated.ONLY) or (auto_generated is AutoGenerated.IF_VALUES and values):
            values.update((f.column, (v, f)) for f in columns.values() if f.auto_generated and (v := self._get_value(f)) is not MISSING and v is not SKIP_COLUMN)
        return {k: self._dump_column_value(v, f) for k, (v, f) in values.items()}

    def _set_row_id(self, id: int) -> None:
        if self.__primary_index__:
            name: str = self.__primary_index__
            if getattr(self, name) is None:
                setattr(self, name, id)

    def _has_primary_index(self) -> bool:
        """Return True if primary index is set."""
        return bool(self.__primary_index__ and getattr(self, self.__primary_index__) is not None)

    def _get_value(self, field: DbField) -> Any:
        """Get single column value from given field."""
        if field.on_update is MISSING:
            return deep_get_attr(self, field.attr, safe=True)
        if field.on_update is SKIP_COLUMN:
            return MISSING
        if callable(field.on_update):
            return field.on_update(deep_get_attr(self, field.attr, safe=True))
        # if isinstance(field.on_update, sql):
        #     return MISSING
        return field.on_update

    def _insert(self, cur: DbCursor) -> bool:
        """Execute INSERT query."""
        # values = self._column_values(primary_index=False, auto_generated=AutoGenerated.NO)
        # auto_values = self._column_values(primary_index=False, auto_generated=AutoGenerated.ONLY)
        # names = ', '.join(quote(a) for a in chain(values, auto_values))
        # refs = ', '.join(f':{a}' for a in values)
        # if auto_values:
        #     refs = ', '.join((refs, ', '.join(sql_dump(v) for v in auto_values.values())))
        # query = f'INSERT INTO {quote(self.__tablename__)} ({names}) VALUES ({refs})'
        query, values = self._prepare_insert()
        cur.execute(query, values)
        self._set_row_id(cur.lastrowid)
        self._db_values = values  # type: ignore  # `_db_values` is hidden instance attribute
        return True

    def _prepare_insert(self) -> Tuple[str, Mapping[str, Any]]:
        """Prepare data for INSERT many objects."""
        values = self._column_values(primary_index=False, auto_generated=AutoGenerated.NO)
        auto_values = self._column_values(primary_index=False, auto_generated=AutoGenerated.ONLY)
        names = ', '.join(quote(a) for a in chain(values, auto_values))
        refs = ', '.join(f':{a}' for a in values)
        if auto_values:
            refs = ', '.join((refs, ', '.join(sql_dump(v) for v in auto_values.values())))
        query = f'INSERT INTO {quote(self.__tablename__)} ({names}) VALUES ({refs})'
        return query, values

    # @classmethod
    # def _insert_many(cls, cur: DbCursor, query: str, values: Iterable[Mapping[str, Any]]) -> bool:
    #     """Execute INSERT query on many objects."""
    #     cur.execute(query, values)
    #     return True

    def _update(self, cur: DbCursor) -> bool:
        """Execute UPDATE query."""
        if self.__primary_index__:
            index = self.__primary_index__
            values = self._column_values(primary_index=False, auto_generated=AutoGenerated.NO)
            auto_values = self._column_values(primary_index=False, auto_generated=AutoGenerated.ONLY)
            if values and index:
                names = ', '.join(f'{quote(a)}=:{a}' for a in values)
                if auto_values:
                    names = ', '.join((names, ', '.join(f'{quote(a)}={sql_dump(v)}' for a, v in auto_values.items())))
                values[index] = deep_get_attr(self, index)
                query = f'UPDATE {quote(self.__tablename__)} SET {names} WHERE {quote(index)} = :{index}'
                cur.execute(query, values)
                return True
        return False


class Expr:
    """A SQL boolean/value fragment that carries its bound parameters.

    `text` is a SQL fragment that may contain ``?`` placeholders; `params` are the values bound to
    them, in order. Comparison/boolean operators build new Exprs that APPEND the compared value as a
    parameter instead of inlining it — so user values never enter the SQL text and can not break or
    inject it. `on` carries the relationship FK key (see :meth:`_rel`).
    """

    def __init__(self, text: str = '', params: Iterable[Any] = (), *, on: Optional[str] = None) -> None:
        #: SQL fragment with ``?`` placeholders for parameters (e.g. ``"age > ? AND name = ?"``)
        self.text: str = text
        #: values bound to the ``?`` placeholders in `text`, in order (e.g. ``[18, "Alice"]``)
        self.params: List[Any] = list(params)
        #: what to extract from the compared value (for relationships)
        self.on: Optional[str] = on

    def __repr__(self) -> str:
        return f'Expr({self.text!r}, params={self.params!r})'

    def __str__(self) -> str:
        # NB: contains ``?`` placeholders, not the literal values (those live in .params).
        return self.text

    def _rel(self, other: Any) -> Any:
        """Get relationship value."""
        if isinstance(other, DbTable):
            if self.on and other._fields_info:
                table, _, key = self.on.partition('.')
                if other.__tablename__ == table and (field := other._fields_info.get(key)):
                    return getattr(other, field.name)
        return other

    def _cmp(self, op: str, other: Any) -> 'Expr':
        """Build ``<self> <op> ?`` binding `other` as a parameter.

        When `other` is itself an Expr (a column, e.g. a JOIN ``ON A.col = B.col``) it is rendered
        INLINE (its own text + params) instead of bound as a value — so column-to-column comparisons
        work and a column never gets bound as a parameter.
        """
        if self.on:
            other = self._rel(other)
        if isinstance(other, Expr):
            return Expr(f'{self.text} {op} {other.text}', [*self.params, *other.params])
        return Expr(f'{self.text} {op} ?', [*self.params, other])

    def __eq__(self, other: Any) -> 'Expr':  # type: ignore[override]
        if other is None:
            return Expr(f'{self.text} IS NULL', self.params)
        return self._cmp('=', other)

    def __ne__(self, other: Any) -> 'Expr':  # type: ignore[override]
        if other is None:
            return Expr(f'{self.text} IS NOT NULL', self.params)
        return self._cmp('!=', other)

    def __lt__(self, other: Any) -> 'Expr':
        return self._cmp('<', other)

    def __le__(self, other: Any) -> 'Expr':
        return self._cmp('<=', other)

    def __gt__(self, other: Any) -> 'Expr':
        return self._cmp('>', other)

    def __ge__(self, other: Any) -> 'Expr':
        return self._cmp('>=', other)

    # TODO: add more operators, like +, -, *, ...

    def __invert__(self) -> 'Expr':
        return NOT(self)

    def __and__(self, other: Any) -> 'Expr':
        return AND(self, other)

    def __or__(self, other: Any) -> 'Expr':
        return OR(self, other)

    def __matmul__(self, other: Union[Iterable[Any], 'Statement']) -> 'Expr':
        return IN(self, other)

    # -- ORDER BY terms (no params: ORDER BY can not be parametrized) --
    def asc(self) -> 'Expr':
        """ORDER BY this column ascending."""
        return Expr(f'{self.text} ASC', self.params)

    def desc(self) -> 'Expr':
        """ORDER BY this column descending."""
        return Expr(f'{self.text} DESC', self.params)

    def nulls_first(self) -> 'Expr':
        """ORDER BY ... NULLS FIRST."""
        return Expr(f'{self.text} NULLS FIRST', self.params)

    def nulls_last(self) -> 'Expr':
        """ORDER BY ... NULLS LAST."""
        return Expr(f'{self.text} NULLS LAST', self.params)


class TableColumnExpr(Expr, Generic[TABLE]):
    """Simple start of SQL WHERE statement (only table column)."""

    def __init__(self, *, table: TABLE, field: DbField, on: Optional[str] = None) -> None:
        self.table: Type[DbTable] = table
        self.field: DbField = field
        if field.fields is None:
            super().__init__(f'{quote(self.table.__tablename__)}.{quote(self.field.column)}', on=on)
        else:
            values = ', '.join(f'{quote(self.table.__tablename__)}.{quote(column)}' for column in table._column_fields(column=field.name))
            super().__init__(f'({values})', on=on)

    def _cmp(self, op: str, other: Any) -> 'Expr':
        if self.field.fields is not None:
            # Row-value comparison of a structured column: the value (a controlled ref/tuple, never
            # user text) is flattened and inlined to `(c1, ...) <op> (v1, ...)` (can't bind a tuple
            # to a single placeholder). sql_dump escapes its parts as proper SQL literals.
            if self.on:
                other = self._rel(other)
            return Expr(f'{self.text} {op} {sql_dump(other)}')
        return super()._cmp(op, other)

    def __hash__(self) -> int:
        return hash(id(self.table)) ^ hash(self.field)

    def __getattr__(self, name: str) -> 'TableColumnExpr':
        """Return sub-object column."""
        fields = self.field.fields
        if fields is not None and name in fields:
            return TableColumnExpr(table=self.table, field=fields[name])
        raise AttributeError(name)


def _as_expr(value: Any) -> Expr:
    """Convert a value to Expr if it's not already an Expr (e.g. a string or a TableColumnExpr)."""
    return value if isinstance(value, Expr) else Expr(str(value))


def AND(where: Any, *others: Any) -> Expr:
    """Combine multiple expressions with AND."""
    exprs = [_as_expr(e) for e in (where, *others)]
    text = ' AND '.join(f'({e.text})' for e in exprs)
    return Expr(text, [p for e in exprs for p in e.params])


def OR(where: Any, *others: Any) -> Expr:
    """Combine multiple expressions with OR."""
    exprs = [_as_expr(e) for e in (where, *others)]
    text = ' OR '.join(f'({e.text})' for e in exprs)
    return Expr(text, [p for e in exprs for p in e.params])


def NOT(value: Any) -> Expr:
    """Negate an expression with NOT."""
    expr = _as_expr(value)
    return Expr(f'NOT ({expr.text})', expr.params)


@overload
def IN(where: Expr, values: Union[Iterable[Any], 'Statement']) -> Expr: ...


@overload
def IN(where: Iterable[TableColumnExpr], values: Iterable[Sequence[Any]]) -> Expr: ...


@overload
def IN(where: Any, values: Iterable[Any]) -> Expr: ...


def IN(where: Union[Expr, Iterable[TableColumnExpr]], values: Union[Iterable[Any], 'Statement']) -> Expr:
    """Build an IN expression: `where IN (values)`."""
    if isinstance(values, Statement):
        sub_text, sub_params = values._sql()
        base = _as_expr(where)
        return Expr(f'{base.text} IN ({sub_text})', [*base.params, *sub_params])
    if isinstance(where, Expr):
        vals = list(values)
        if where.on:
            vals = [where._rel(v) for v in vals]
        placeholders = ', '.join('?' for _ in vals)
        return Expr(f'{where.text} IN ({placeholders})', [*where.params, *vals])
    # multi-column IN: `where` is an iterable of column exprs, `values` an iterable of rows
    cols = list(where)
    rows = [list(row) for row in values]
    col_text = ', '.join(c.text for c in cols)
    rows_text = ', '.join(f'({", ".join("?" for _ in row)})' for row in rows)
    return Expr(f'({col_text}) IN (VALUES {rows_text})', [v for row in rows for v in row])


def IS(where: Any, other: Any) -> Expr:
    """Build an IS expression: `where IS other` (e.g. for NULL checks)."""
    left = where if isinstance(where, Expr) else Expr('?', [where])
    return Expr(f'{left.text} IS ?', [*left.params, other])


class Statement(Generic[R]):
    """Select class to operate on SELECT and so on."""

    @overload
    def __init__(self, *tables: Type[DbTable], statement: Optional[str] = None) -> None: ...

    @overload
    def __init__(self, table: TableColumnExpr, /, *, statement: Optional[Literal['SELECT']] = None) -> None: ...

    @overload
    def __init__(self, table: Any, /, *, statement: Optional[Literal['SELECT']] = None) -> None: ...

    def __init__(self, *tables: Union[Type[DbTable], Any], statement: Optional[str] = None) -> None:
        #: SELECT targets: tables (their columns are read) and/or column exprs; result shape follows
        #: this — a single table yields its objects, several yield tuples. ``_tables[0]`` is the
        #: FROM root for joins/inference. For INSERT/UPDATE/DELETE it holds the single target table.
        self._tables = tuple(tables)
        #: WHERE condition (an ``Expr``); ``where()`` ANDs successive calls. None = no WHERE.
        self._where: Optional[Expr] = None
        #: Explicit JOINs: ``(target_table, on_expr, outer)`` in chain order. FROM = root + these.
        self._joins: List[Tuple[Type['DbTable'], 'Expr', bool]] = []
        #: Relationship names to eager-load (selectin) when the result is materialized (anti-N+1).
        self._prefetch: List[str] = []
        #: Scalar relationships eager-loaded via LEFT JOIN in the SAME query: ``(rel_name, target)``.
        self._joinedloads: List[Tuple[str, Type['DbTable']]] = []
        #: ORDER BY terms (column exprs or raw ``SQL(...)``); empty = unordered.
        self._order: Sequence[Union[Expr, SQL]] = ()
        #: SQL verb: ``SELECT`` / ``INSERT`` / ``UPDATE`` / ``DELETE``.
        self._statement: str = statement or 'SELECT'
        #: Flattened columns to bind for INSERT/UPDATE (filled while building the query); keyed by column.
        self._columns: Mapping[str, DbField] = {}
        #: Row data for INSERT/UPDATE (objects or column mappings); set via ``set()`` / ``exec(data=...)``.
        self._data: Sequence[RowData] = []

    def __str__(self) -> str:
        return self.get()

    def where(self, where: Union[Expr, Any]) -> Self:
        where = _as_expr(where)
        if self._where is None:
            self._where = where
        else:
            self._where = AND(self._where, where)
        return self

    def order_by(self, *order: Union[Expr, SQL]) -> Self:
        """Set ORDER BY terms.

        Each term is a column expression (``T.col`` for ascending, or ``T.col.desc()`` / ``.asc()`` /
        ``.nulls_last()``) or an explicit raw ``SQL('...')`` fragment (for functions/COLLATE/etc.).
        A plain ``str`` is rejected: ORDER BY can not be parametrized, so terms must be real table
        columns (quoted, validated) or be opted into as raw SQL.
        """
        for term in order:
            if not isinstance(term, (Expr, SQL)):
                raise TypeError(f"order_by() term must be a column expr or SQL('...'), got {term!r}")
        self._order = order
        return self

    def prefetch(self, *names: str) -> Self:
        """Eager-load the named relationship(s) to avoid N+1 (SQLAlchemy ``selectinload`` strategy).

        Each name is a relationship attribute on the root (first) select table. When the result is
        materialized (``all()``/``first()``/iterating), one extra query per relationship loads the
        related rows by key (``IN (...)``) and populates them (no lazy per-access query, no row
        multiplication). Works for both scalar (many-to-one) and collection (one-to-many via
        ``back_populates``) relationships.
        """
        self._prefetch = [*self._prefetch, *names]
        return self

    def joinedload(self, *names: str) -> Self:
        """Eager-load scalar (many-to-one) relationship(s) in the SAME query (SQLAlchemy ``joinedload``).

        Adds a ``LEFT JOIN`` to the related table and selects its columns too, so the related object
        is built from the same row — one query, no N+1 and no second round-trip. Scalar only; use
        :meth:`prefetch` (selectin) for collections (joined-loading a collection multiplies rows).
        """
        root: Type['DbTable'] = self._tables[0]
        root._fields
        for name in names:
            rel = _resolve_relationship(root, name)
            target, is_collection = _resolve_rel_target(rel, root.__module__)
            if not (isinstance(target, type) and issubclass(target, DbTable)):
                raise ValueError(f'joinedload({name!r}): could not resolve the related table')
            if is_collection:
                raise ValueError(f'joinedload({name!r}) is for scalar relationships; use prefetch() for collections')
            target._fields
            on = getattr(root, rel.on) == getattr(target, target.__primary_index__ or 'id')
            self._joins.append((target, on, True))        # LEFT JOIN (keep rows without a related match)
            self._joinedloads.append((name, target))
        return self

    def join(self, target: Type['DbTable'], on: Union['Expr', None] = None, *, outer: bool = False) -> Self:
        """Add an explicit ``JOIN target ON ...`` (``LEFT JOIN`` when `outer`).

        `on` is a column-to-column expression (e.g. ``A.fk == B.id``). When omitted, the condition is
        inferred from a relationship between the root table and `target` (FK column == target PK, or
        the back-populates FK for a one-to-many). The joined table is part of the FROM only; to also
        SELECT its columns, include it in ``select(A, target)``.
        """
        self._joins.append((target, _as_expr(on) if on is not None else self._infer_join_on(target), outer))
        return self

    def outerjoin(self, target: Type['DbTable'], on: Union['Expr', None] = None) -> Self:
        """``LEFT OUTER JOIN`` shorthand for :meth:`join` with ``outer=True``."""
        return self.join(target, on, outer=True)

    def _infer_join_on(self, target: Type['DbTable']) -> 'Expr':
        """Infer the ON condition from a relationship between the root table and `target`.

        Relationships are the class descriptors (see `_relationships`).
        """
        root: Type['DbTable'] = self._tables[0]
        root._fields            # force field resolution (ValueProperty descriptors, FK columns)
        target._fields
        for rel in _relationships(root).values():
            if _resolve_rel_target(rel, root.__module__)[0] is not target:
                continue
            tpk = target.__primary_index__ or 'id'
            if root._fields_info and rel.on in root._fields_info:         # many-to-one: FK on root
                return getattr(root, rel.on) == getattr(target, tpk)
            if rel.back_populates:                                        # one-to-many: FK on target
                rpk = root.__primary_index__ or 'id'
                return getattr(root, rpk) == getattr(target, f'{rel.back_populates}_id')
        raise ValueError(f'Cannot infer JOIN ON: no relationship from {root.__tablename__} to {target.__tablename__}')

    def _join_params(self) -> List[Any]:
        """ON parameters of all joins, in chain order (precede WHERE params in the SQL)."""
        return [p for _, on, _ in self._joins for p in on.params]

    def _where_query(self) -> str:
        return f' WHERE {self._where.text}' if self._where is not None else ''

    def _where_params(self) -> List[Any]:
        return list(self._where.params) if self._where is not None else []

    def _sql(self) -> Tuple[str, List[Any]]:
        """Return ``(sql_text, params)`` — used when this statement is embedded (IN subquery).

        Params follow SQL clause order: JOIN ON params first, then WHERE params.
        """
        return self.get(), [*self._join_params(), *self._where_params()]

    @staticmethod
    def _order_term(term: Union[Expr, SQL]) -> str:
        return term.text if isinstance(term, Expr) else str(term)  # Expr fragment, or raw SQL(...)

    def _order_query(self) -> str:
        if not self._order:
            return ''
        return f' ORDER BY {", ".join(self._order_term(t) for t in self._order)}'

    def _select(self) -> str:
        def get_tab(val: Any) -> Iterator[str]:
            if is_dbtable(val):
                yield quote(val.__tablename__)
            elif isinstance(val, TableColumnExpr):
                yield quote(val.table.__tablename__)

        def get_col(val: Any, *, i: int) -> Iterator[str]:
            if is_dbtable(val):
                tab: Type[DbTable] = val
                for col in tab._column_fields(primary_index=True):
                    yield f'{quote(tab.__tablename__)}.{quote(col)} AS "{tab.__tablename__}.{col}"'
            elif isinstance(val, TableColumnExpr):
                tab: Type[DbTable] = val.table
                for col in tab._column_fields(primary_index=False, column=val.field.name):
                    yield f'{quote(tab.__tablename__)}.{quote(col)} AS "{tab.__tablename__}.{col}"'
            else:
                yield f'{sql_dump(val)} AS out_{i}'

        if self._joins:
            # Explicit topology: FROM <root> [LEFT] JOIN <t> ON <...> ... (root = first select table).
            root: Type[DbTable] = self._tables[0]
            tables = quote(root.__tablename__)
            for tgt, on, outer in self._joins:
                tables = f'{tables} {"LEFT JOIN" if outer else "JOIN"} {quote(tgt.__tablename__)} ON {on.text}'
            tables = f' FROM {tables}'
        else:
            # No explicit joins: comma-list (implicit cross join; constrained by WHERE) -- back-compat.
            tables = ', '.join(f for t in self._tables for f in get_tab(t))
            if tables:
                tables = f' FROM {tables}'
        # SELECT the result tables AND the joinedload targets (their cols feed the eager-loaded rel).
        cols_tables = (*self._tables, *(t for _, t in self._joinedloads))
        cols = ', '.join(c for i, t in enumerate(cols_tables, 1) for c in get_col(t, i=i))
        return f'{self._statement} {cols}{tables}{self._where_query()}{self._order_query()}'

    def _insert(self) -> str:
        if len(self._tables) != 1:
            raise ValueError(f'Can NOT insert to many tables ({len(self._tables)})')
        tab = self._tables[0]
        self._columns = tab._column_fields(primary_index=False, updates=False)
        # Positional placeholders; `exec()` binds the column values (in this order) as a list.
        cols = ', '.join(map(quote, self._columns))
        refs = ', '.join('?' for _ in self._columns)
        return f'{self._statement} INTO {quote(tab.__tablename__)} ({cols}) VALUES ({refs})'

    def _update(self) -> str:
        if len(self._tables) != 1:
            raise ValueError(f'Can NOT update many tables ({len(self._tables)})')
        tab = self._tables[0]
        if not self._data:
            raise ValueError(f'Can NOT update unknown data for {tab.__name__} ({tab.__class__.__name__})')
        tab_data = self._data[0]
        if isinstance(tab_data, DbTable):
            if type(tab_data) is not tab:
                raise ValueError(f'Data ({type(tab_data).__name__}) does NOT match table {tab.__name__} ({tab.__class__.__name__})')
            # A whole row: update every (flattened) non-primary column.
            self._columns = dict(tab._column_fields(primary_index=False))
        else:
            # A partial dict keyed by column or field name.
            self._columns = {c: f for c, f in tab._column_fields(primary_index=False).items()
                             if c in tab_data or f.name in tab_data}
        # Positional SET placeholders; `exec()` binds SET values (column order) THEN the WHERE params.
        names = ', '.join(f'{quote(c)}=?' for c in self._columns)
        return f'{self._statement} {quote(tab.__tablename__)} SET {names}{self._where_query()}'

    def _delete(self) -> str:
        if len(self._tables) != 1:
            raise ValueError(f'Can NOT delete from many tables ({len(self._tables)})')
        tab = self._tables[0]
        return f'{self._statement} FROM {quote(tab.__tablename__)}{self._where_query()}'

    def get(self) -> str:
        if self._statement == 'SELECT':
            return self._select()
        if self._statement in ('INSERT', 'INSERT OR IGNORE', 'INSERT OR REPLACE'):
            return self._insert()
        if self._statement in ('UPDATE', 'UPDATE OR IGNORE'):
            return self._update()
        if self._statement in ('DELETE',):
            return self._delete()
        return ''

    def set(self, **values: Any) -> Self:
        if self._tables and is_dbtable(self._tables[0]):
            tab = self._tables[0]
            unknown = values.keys() - set(tab._fields)
            if unknown:
                vv = ', '.join(sorted(unknown))
                raise TypeError(f'Unknown column(s) for {tab.__name__}: {vv}')
        self._data = [values]
        return self

    def exec(self, cur: DbCursor, data: Union[None, RowData, Iterable[RowData]] = None) -> 'Result[R]':
        if data is None:
            data = self._data
        elif not self._data:
            # `exec(data=...)` without a prior `.set()`: let UPDATE derive its columns from a
            # representative row (a single row, or a materialized sequence — not a one-shot iterator).
            if isinstance(data, (DbTable, Mapping)):
                self._data = [data]
            elif isinstance(data, (list, tuple)):
                self._data = list(data)
                data = self._data

        # Build the SQL first: INSERT/UPDATE populate `self._columns` (the flattened columns to bind).
        query = self.get()
        where_params = self._where_params()

        def row_params(d: RowData) -> List[Any]:
            if isinstance(d, DbTable):
                d._update_db(cur.db, cur)
                vals: Mapping[str, Any] = d._values_for(self._columns)
            else:
                # Mapping keyed by column (`a::b`) or field name -> dump per matching column field.
                out: Dict[str, Any] = {}
                for col, f in self._columns.items():
                    if col in d:
                        out[col] = DbTable._dump_column_value(d[col], f)
                    elif f.name in d:
                        out[col] = DbTable._dump_column_value(d[f.name], f)
                vals = out
            # SET values (column order) precede the WHERE params in the SQL text.
            return [*(vals.get(col) for col in self._columns), *where_params]

        try:
            if self._columns and data:   # INSERT / UPDATE carrying row data
                if isinstance(data, (DbTable, Mapping)):
                    cur.execute(query, row_params(data))
                else:
                    cur.executemany(query, [row_params(obj) for obj in data])
            else:                        # SELECT / DELETE: JOIN ON params precede WHERE params
                cur.execute(query, [*self._join_params(), *where_params])
        except DatabaseError as exc:
            fflog(f'DB ERROR ({exc}) on {query!r}')
            raise
        return Result(cursor=cur, statement=self)


@attrs.define(kw_only=True)
class Result(Generic[T]):

    cursor: DbCursor
    statement: Statement

    def new(self, tab: Type[DbTable], row: Mapping[str, Any], *, i: int = 1) -> Any:
        # NOTE: `_select()` always aliases columns as "<tablename>.<col>", so a single-table
        # query is qualified just like a multi-table one (the old bare-column fast path, where
        # prefix was '', is gone). Keep the prefix unconditional.
        if is_dbtable(tab):
            prefix = f'{tab.__tablename__}.'
            instance = tab._from_row({k[len(prefix):]: v for k, v in row.items() if k.startswith(prefix)})
            instance._update_db(self.cursor.db, self.cursor)
            return instance
        if isinstance(tab, TableColumnExpr):
            prefix = f'{tab.table.__tablename__}.'
            return row[f'{prefix}{tab.field.column}']
        return row[f'out_{i}']

    def __iter__(self) -> Iterator[T]:
        return iter(self.iter())

    def _build(self, row: Mapping[str, Any]) -> Any:
        """Build one result (object or tuple) and attach any joined-loaded scalar relationships."""
        tabs = self.statement._tables
        if len(tabs) == 1:
            obj = self.new(tabs[0], row)
        else:
            obj = tuple(self.new(t, row, i=i) for i, t in enumerate(tabs, 1))
        if self.statement._joinedloads:
            self._attach_joinedloads(row, obj)
        return obj

    def _attach_joinedloads(self, row: Mapping[str, Any], obj: Any) -> None:
        """Populate joined-loaded scalar rels from the same row (LEFT JOIN -> None when unmatched)."""
        root_obj = obj[0] if isinstance(obj, tuple) else obj
        if not isinstance(root_obj, DbTable):
            return
        for name, target in self.statement._joinedloads:
            pk_key = f'{target.__tablename__}.{target.__primary_index__ or "id"}'
            related = self.new(target, row) if row.get(pk_key) is not None else None
            setattr(root_obj, name, related)

    def _materialize(self) -> List[T]:
        return [self._build(row) for row in self.cursor]

    def iter(self) -> Iterator[T]:
        if self.statement._prefetch:
            # selectin needs every parent first: drain the main result, eager-load, then yield.
            rows = self._materialize()
            self._apply_prefetch(rows)
            yield from rows
            return
        for row in self.cursor:
            yield self._build(row)

    def _apply_prefetch(self, rows: List[Any]) -> None:
        """Eager-load the statement's `prefetch` relationships into the materialized parent rows."""
        if not rows or not self.statement._tables:
            return
        root: Type[DbTable] = self.statement._tables[0]
        if not is_dbtable(root):
            return
        parents = rows if len(self.statement._tables) == 1 else [r[0] for r in rows]
        parents = [p for p in parents if isinstance(p, DbTable)]
        for name in self.statement._prefetch:
            self._selectin(root, _resolve_relationship(root, name), parents)

    def _selectin(self, root: Type['DbTable'], rel: 'Relationship', parents: List[Any]) -> None:
        """Load `rel` for all `parents` in one query (IN on the key) and assign the result."""
        target, is_collection = _resolve_rel_target(rel, root.__module__)
        if not (isinstance(target, type) and issubclass(target, DbTable)):
            return
        target._fields  # force field resolution (column exprs)
        if is_collection:                                  # one-to-many: FK on target = back_populates+_id
            fk, rpk = f'{rel.back_populates}_id', (root.__primary_index__ or 'id')
            keys = {k for p in parents if (k := getattr(p, rpk, None)) is not None}
            grouped: Dict[Any, List[Any]] = {}
            if keys:
                for child in self.cursor.exec(select(target).where(IN(getattr(target, fk), list(keys)))).iter():
                    grouped.setdefault(getattr(child, fk, None), []).append(child)
            for p in parents:
                setattr(p, rel.name, grouped.get(getattr(p, rpk, None), []))
        else:                                              # many-to-one: FK on root (rel.on) -> target PK
            fk, tpk = rel.on, (target.__primary_index__ or 'id')
            keys = {k for p in parents if (k := getattr(p, fk, None)) is not None}
            by_pk: Dict[Any, Any] = {}
            if keys:
                for child in self.cursor.exec(select(target).where(IN(getattr(target, tpk), list(keys)))).iter():
                    by_pk[getattr(child, tpk, None)] = child
            for p in parents:
                setattr(p, rel.name, by_pk.get(getattr(p, fk, None)))

    def all(self) -> Sequence[T]:
        return list(self.iter())

    def first(self) -> Union[None, T]:
        for result in self.iter():
            return result
        return None

    def one(self) -> T:
        it = iter(self)
        try:
            result = next(it)
        except StopIteration:
            raise KeyError('No row was found when one was required') from None
        try:
            result = next(it)  # second
        except StopIteration:
            return result
        raise KeyError('Multiple rows were found when exactly one was required')


@overload
def select(table: Type[TI], /) -> Statement[TI]: ...


@overload
def select(table: TableColumnExpr[Type[TI]], /) -> Statement[TI]: ...


@overload
def select(tab1: Type[DbTable], tab2: Type[DbTable], /, *tables: Type[DbTable]) -> Statement[Tuple[DbTable, ...]]: ...


@overload
def select(*tables: Any) -> Statement[Any]: ...


def select(*tables: Union[Type[DbTable], Any]) -> Statement:
    return Statement(*tables)


def update(table: Type[DbTable]) -> Statement:
    return Statement(table, statement='UPDATE')


def update_or_ignore(table: Type[DbTable]) -> Statement:
    return Statement(table, statement='UPDATE OR IGNORE')


def delete(table: Type[DbTable]) -> Statement:
    return Statement(table, statement='DELETE')


def insert_or_replace(table: Type[DbTable]) -> Statement:
    """INSERT OR REPLACE statement: a row with the same UNIQUE key is replaced (upsert of a disposable row)."""
    return Statement(table, statement='INSERT OR REPLACE')


def dump_fields(kls: Type[DbTable]) -> str:
    """Dump DbTable files to string."""
    def dump(fields: Iterable[DbField], lvl: int) -> Iterator[str]:
        indent = '    ' * lvl or ' '
        for i, f in enumerate(fields):
            sep = f'\n{indent}' if i else f'\n{indent}' if lvl else '{'
            vv = ', '.join(f'{k}={getattr(f, k)!r}' for k in ff if k != 'fields')
            yield f'{sep}{f.name!r}: DbFieldInfo({vv}, fields='
            if f.fields:
                yield from dump(f.fields.values(), lvl + 1)
            else:
                yield repr(f.fields)
            yield ')'
        yield '}'

    ff = DbField._fields
    return ''.join(dump(kls._fields.values(), 0))


class OrmDatabase:
    """Simple access (with updates to database with ORM tables."""

    def __init__(self,
                 name: str,
                 *classes: Type[DbTable],
                 version: int,
                 on_connect: Optional[Callable[[DbCursor], None]] = None,
                 on_create: Optional[Callable[[DbCursor], None]] = None,
                 on_update: Optional[Callable[[DbCursor], None]] = None,
                 ) -> None:
        self.name = name
        self.classes = classes
        self.version = version
        self.on_connect = on_connect
        self.on_create = on_create
        self.on_update = on_update
        #: The database is broken (corrupted, see `best_effort()`), it is off until the interpreter restarts.
        self.broken: bool = False
        #: The version the database was migrated from on the first connect (None: fresh or not migrated), for `on_update`.
        self.old_version: Optional[int] = None
        #: Guards the one-time per-connection init only (NOT the whole operation) -- RLock so a
        #: re-entrant connect (e.g. an `on_connect` hook opening another cursor) does not deadlock.
        self.lock = RLock()
        #: Serializes the writes of the threads of this process (see `cursor(write=True)`), RLock: a nested write cursor.
        self.write_lock = RLock()

    def _create_tables(self, cur: DbCursor) -> Optional[int]:
        """Create all missing tables in the DB. Return old version."""
        # Handle DB migration.
        old_ver = update_db_version(cur, self.version)
        cur.create_tables(*self.classes)
        return old_ver

    @staticmethod
    def _peek_version(cur: DbCursor) -> Optional[int]:
        """Read ``db.version`` with no side effects; None if the ``db`` table does not exist yet."""
        try:
            cur.execute('SELECT version FROM db')
        except DatabaseError:
            return None
        row = cur.fetchone()
        if not row:
            return None
        return row['version'] if isinstance(row, Mapping) else row[0]

    def _on_connect(self, cur: DbCursor) -> None:
        """Schema setup + migration on first connect.

        The migration (version bump + ``create_tables`` + ``on_create``/``on_update``) runs under ONE
        cross-process EXCLUSIVE transaction — but ONLY when a schema change is actually due (a fresh
        DB or a version upgrade). In the STEADY STATE (DB already at the current version) NO exclusive
        lock is taken: ``create_tables`` is idempotent (``CREATE ... IF NOT EXISTS``). This matters in
        reuse mode (plugin re-invoked + widgets + service running concurrently): an ordinary connect
        must NOT grab an EXCLUSIVE lock and block behind a long-lived writer. ``on_connect`` runs
        afterwards, outside the migration transaction.
        """
        pre_ver = self._peek_version(cur)                       # None -> no `db` table (fresh DB)
        migrating = pre_ver is None or pre_ver < self.version   # fresh or upgrade -> needs the lock
        own_tx = migrating and not cur.connection.in_transaction
        if own_tx:
            cur.commit()                  # drop any stale snapshot before locking
            cur.execute('BEGIN EXCLUSIVE')
        try:
            old_ver = self._create_tables(cur)
            if old_ver is None and callable(self.on_create):
                self.on_create(cur)
            elif old_ver != self.version and callable(self.on_update):
                self.old_version = old_ver
                self.on_update(cur)
            if own_tx:
                cur.commit()
        except Exception:
            if own_tx:
                cur.rollback()
            raise
        if callable(self.on_connect):
            self.on_connect(cur)

    @contextmanager
    def cursor(self, *, orm: bool = True, write: bool = False) -> Generator[DbCursor, None, None]:
        """Get ORM cursor in `with` statement.

        The per-OrmDatabase lock guards ONLY the one-time `_on_connect` init -- it is NOT held across
        the operation (the `yield`). So concurrent/re-entrant cursors on the same DB no longer
        serialize on it or deadlock (per-thread connections + WAL handle concurrency). The callbacks
        run ORM ops, so the init cursor sets `orm` first.

        A `write` cursor holds the write lock of the database in this process and the SQLite write lock
        (BEGIN IMMEDIATE) until its commit: the threads of a process wait in the queue of the Python lock,
        not in the SQLite busy handler (it polls, it is not fair and it gives up after the connection
        timeout, e.g. under many provider threads), only other processes are left to the busy handler.
        """
        db = db_manager[self.name]
        if not db.initialized:
            with self.lock:                              # serialize the one-time init only
                if not db.initialized:                   # re-check under the lock
                    with db.cursor(initialize=False) as cur:
                        cur.orm = orm
                        self._on_connect(cur)
                    db.initialized = True
        # the operation: NO orm-lock held (the init above is done before the write lock, its hooks may write)
        with (self.write_lock if write else nullcontext()), db.cursor(initialize=False) as cur:
            cur.orm = orm
            if write and not cur.connection.in_transaction:
                cur.execute('BEGIN IMMEDIATE')
            yield cur


FUNC = TypeVar('FUNC', bound=Callable[..., Any])


def best_effort(default: Callable[[], Any], *, db: Callable[[], OrmDatabase]) -> Callable[[FUNC], FUNC]:
    """
    Decorate a cache operation: the cache is optional, a DB error must not break the caller.

    On any SQLite error the operation logs it and returns `default()` (an empty read, a skipped write).
    A corrupted database (bare `DatabaseError`: "malformed", "not a database") is removed, the database is then
    off in this interpreter (other threads / processes can still hold the old file). A locked or busy
    database (`OperationalError`) is a temporary state of another writer, it is never removed.
    `db` returns the database at call time (a module can replace its database, e.g. in its CLI).
    """
    def decorator(func: FUNC) -> FUNC:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            database = db()
            if database.broken:
                return default()
            try:
                return func(*args, **kwargs)
            except DbError as exc:
                label = database.name.upper()
                if isinstance(exc, (ProgrammingError, InterfaceError)) and 'closed database' not in str(exc):
                    fflog_exc(f'[{label}] cache {func.__name__}() failed')  # an error of the code (SQL, parameters): the stack
                else:
                    fflog(f'[{label}] cache {func.__name__}() failed: {exc!r}')
                if type(exc) is DatabaseError:
                    database.broken = True
                    removed = db_manager.remove_db(database.name)
                    fflog(f'[{label}] broken cache database {"removed" if removed else "can NOT be removed"}, cache is off')
                return default()
        return wrapper  # type: ignore[return-value]  # the same signature
    return decorator


def delete_expired(db: OrmDatabase, table: Type[DbTable], *, grace: int = 0, now: Optional[int] = None) -> int:
    """Remove rows of `table` (it has an `expires_at` column) expired more than `grace` seconds ago. Return the count."""
    if now is None:
        now = int(time())
    with db.cursor(write=True) as cur:
        cur.exec(delete(table).where(getattr(table, 'expires_at') < now - grace))
        return cur.rowcount
