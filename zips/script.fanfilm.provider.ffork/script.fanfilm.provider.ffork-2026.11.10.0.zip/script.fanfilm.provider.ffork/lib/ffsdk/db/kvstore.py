"""
Key-value data with a lifetime in a DB table (the "dumb" side): data of providers, data of accounts.

A value is JSON in a namespace (a provider name, an account ID), with the store time (`updated_at`, a soft freshness
`max_age` on read) and an optional hard deadline (`expires_at`, NULL = never; expired rows are removed by the
service). Every operation is "best effort": a DB error never reaches the caller.
"""

from __future__ import annotations
from typing import Any, Callable, Optional
from functools import cached_property
from time import time
import json as json_mod
from .db import PrimaryKey
from .orm import DbTable, OrmDatabase, select, delete, insert_or_replace, AND, OR, best_effort, delete_expired
from ..log import fflog, log
from ..tricks import JsonEncoder


class KeyValueRow(DbTable, table=False):
    """Key-value row (a base of the concrete tables): a JSON value of a key in a namespace."""

    __table_args__ = ('UNIQUE("namespace", "key")',)

    #: The primary DB key.
    id: PrimaryKey = None
    #: Namespace: a provider name, a shared namespace, an account ID.
    namespace: str = ''
    #: Key in the namespace.
    key: str = ''
    #: The value as JSON.
    json_string: str = 'null'
    #: Store time (unix seconds).
    updated_at: int = 0
    #: Hard deadline (unix seconds), None = never expires.
    expires_at: Optional[int] = None

    @cached_property
    def data(self) -> Any:
        """Return the decoded value, any JSON (decoded once, a value can be big, e.g. an index)."""
        return json_mod.loads(self.json_string)


def _now() -> int:
    """Return current unix timestamp (seconds)."""
    return int(time())


class KeyValueStore:
    """
    Data of one namespace in a key-value table.

    The lifetime is given on every write (`ttl`, None = never expires); expired data is removed by the service
    (`cleanup()`). `max_age` on read is a soft freshness: older data is skipped, but kept (e.g. a stale fallback).
    """

    def __init__(self, namespace: str, *, table: type[KeyValueRow], db: Callable[[], OrmDatabase]) -> None:
        #: The namespace (provider name, account ID, ...).
        self.namespace: str = namespace
        #: The key-value table.
        self.table: type[KeyValueRow] = table
        #: The database (returned at call time, a module can replace its database, e.g. in its CLI).
        self.db: Callable[[], OrmDatabase] = db

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}({self.namespace!r})'

    def _safe(self, default: Callable[[], Any], func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Call the DB operation `func` "best effort" (see `orm.best_effort()`)."""
        return best_effort(default, db=self.db)(func)(*args, **kwargs)

    def row(self, key: str, *, max_age: float | None = None) -> KeyValueRow | None:
        """Return the data row (the value in `data`, the store time in `updated_at`), if not expired and young enough."""
        def get() -> KeyValueRow | None:
            now = _now()
            table = self.table
            with self.db().cursor() as cur:
                stmt = select(table).where(AND(
                    table.namespace == self.namespace, table.key == key,
                    OR(table.expires_at == None, table.expires_at > now)))  # type: ignore  # SQL NULL
                if max_age is not None:
                    stmt = stmt.where(table.updated_at > now - max_age)
                return cur.exec(stmt).first()

        row = self._safe(lambda: None, get)
        if row is not None:
            try:
                row.data  # decoded now (kept): a broken value is a missing one, not an error of the caller
            except ValueError:
                fflog(f'[{self.db().name.upper()}] broken data {self.namespace}/{key}, skipped')
                return None
        return row

    def get(self, key: str, default: Any = None, *, max_age: float | None = None) -> Any:
        """Return the value, any JSON (not expired and younger than `max_age`, if given), or `default`."""
        row = self.row(key, max_age=max_age)
        if row is None:
            return default
        log.format.tune(key, row.data)
        return row.data

    def set(self, key: str, value: Any, *, ttl: float | None) -> None:
        """Store (replace) the value (any JSON), it expires after `ttl` seconds, None = never."""
        log.format.tune(key, value)
        def put() -> None:
            now = _now()
            row = self.table(namespace=self.namespace, key=key, json_string=json_mod.dumps(value, cls=JsonEncoder), updated_at=now,
                             expires_at=None if ttl is None else now + int(ttl))
            with self.db().cursor(write=True) as cur:
                insert_or_replace(self.table).exec(cur, row)

        self._safe(lambda: None, put)

    def keys(self) -> list[str]:
        """Return the keys of the namespace (expired ones too: the cleanup removes them)."""
        def get() -> list[str]:
            table = self.table
            with self.db().cursor() as cur:
                return [row.key for row in cur.exec(select(table).where(table.namespace == self.namespace))]

        return self._safe(list, get)

    def delete(self, key: str) -> None:
        """Remove the value."""
        def remove() -> None:
            table = self.table
            with self.db().cursor(write=True) as cur:
                cur.exec(delete(table).where(AND(table.namespace == self.namespace, table.key == key)))

        self._safe(lambda: None, remove)

    def clear(self) -> None:
        """Remove all values of the namespace."""
        def remove() -> None:
            table = self.table
            with self.db().cursor(write=True) as cur:
                cur.exec(delete(table).where(table.namespace == self.namespace))

        self._safe(lambda: None, remove)


def cleanup_expired(db: OrmDatabase, table: type[KeyValueRow]) -> int:
    """Remove expired rows of the key-value `table` (run by the service). Return the count."""
    return best_effort(int, db=lambda: db)(delete_expired)(db, table)
