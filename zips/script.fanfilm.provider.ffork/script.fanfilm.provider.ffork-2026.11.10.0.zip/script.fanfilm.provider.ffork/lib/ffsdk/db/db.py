"""
Sqlite3 DB manager and base utilities of the SDK.

The host binds it with `options` (the folder of the databases, the connection timeout, the synchronous mode, the
migration files...) and registers its value types (`register_type()`).
"""

from sys import version_info as PY
from pathlib import Path
from enum import Enum
import json
import pickle
from datetime import datetime, date as dt_date, time as dt_time
from sqlite3 import (connect as db_connect, complete_statement, Connection as SqlConnection, Cursor as SqlCursor,
                     Error as DbError, DatabaseError)
from dataclasses import is_dataclass, fields as dc_fields
from contextlib import contextmanager
from functools import partial
from threading import Lock, RLock, local as thread_local, current_thread
from time import monotonic
import atexit
from typing import Optional, Union, Any, Tuple, List, Dict, Set, Generator, Iterator, Iterable, Sequence, Mapping, Type, TypeVar, Callable, TYPE_CHECKING
from typing_extensions import Self, Literal, TypeAlias, Annotated, get_origin, get_args, cast
import attrs

from ..types import is_optional, remove_optional, is_datetime_instance
from ..tricks import singleton, is_namedtuple, MISSING, JsonEncoder, literal_eval  # literal_eval thread-safe (py3.11 gh-106905)
from ..dates import fromisoformat
from ..log import fflog, fflog_exc, log, LOGERROR
if TYPE_CHECKING:
    from .orm import DbTable, Statement, Result


def addon_data_path(addon_id: str) -> Path:
    """Return the data folder of an add-on (`special://profile/addon_data/<id>`)."""
    from xbmcvfs import translatePath
    return Path(translatePath(f'special://profile/addon_data/{addon_id}'))


def _addon_data_path() -> Path:
    """Return the data folder of the add-on the SDK is in (the default)."""
    return addon_data_path(Path(__file__).resolve().parents[3].name)


def _connection_timeout() -> float:
    """Return the default connection timeout (seconds)."""
    return 3.0


def _synchronous(name: str) -> str:
    """Return the default `PRAGMA synchronous` of a database in the WAL mode."""
    return 'NORMAL'


def _no_migrate_path() -> Optional[Path]:
    """Return no folder of the migration files (the default)."""
    return None


def _false() -> bool:
    """Return False (the default of a switch)."""
    return False


class DbOptions:
    """The bindings of the host."""

    def __init__(self) -> None:
        #: The folder of the databases (`<name>.db`).
        self.path: Callable[[], Path] = _addon_data_path
        #: The connection timeout (seconds): the busy handler of SQLite waits so long for a lock.
        self.connection_timeout: Callable[[], float] = _connection_timeout
        #: `PRAGMA synchronous` of a database by its name (the WAL mode).
        self.synchronous: Callable[[str], str] = _synchronous
        #: The folder of the migration files (`<name>.<version>.sql`), None: no files.
        self.migrate_path: Callable[[], Optional[Path]] = _no_migrate_path
        #: Make a backup of a database before its migration.
        self.backup: Callable[[], bool] = _false
        #: Echo the queries (debug).
        self.echo: Callable[[], bool] = _false
        #: The log is a terminal (colors).
        self.tty: Callable[[], bool] = _false


#: The bindings of the host.
options = DbOptions()


T = TypeVar('T')
R = TypeVar('R')
TableType = TypeVar('TableType', bound='DbTable')

PrimaryKey: TypeAlias = Annotated[Optional[int], 'PRIMARY KEY']
Unique: TypeAlias = Annotated[T, 'UNIQUE']
ColumnName = str
ColumnConstraint = Literal['PRIMARY KEY', 'UNIQUE', 'NOT NULL', 'CHECK']
ColumnConstraints = Dict[ColumnName, ColumnConstraint]  # TODO: remove it
ExecuteParameters: TypeAlias = Union[Sequence[Any], Mapping[str, Any]]


class SQL(str):
    """Just str but without quoting."""
    def __repr__(self) -> str:
        return f'SQL({str.__repr__(self)})'


class DbCursor(SqlCursor):
    """SQLite cursor with the DB it belongs to and the ORM helpers (created by the cursor factory of `Db.cursor()`)."""

    def __init__(self, connection: SqlConnection, *, db: 'Db', orm: Optional[bool] = None) -> None:
        super().__init__(connection)
        self._db: Db = db
        self._orm: Optional[bool] = None
        self._closed: bool = False
        if orm is not None:
            self.orm = orm

    @property
    def db(self) -> 'Db':
        return self._db

    def __repr__(self) -> str:
        return f'DbCursor(db={self.db})'

    @property
    def orm(self) -> bool:
        """True is ORM (row as dict)."""
        if self._orm is None:
            return self._db.orm
        return self._orm

    @orm.setter
    def orm(self, orm: bool) -> None:
        # set row factory for this cursor only
        self._orm = bool(orm)
        if self._orm:
            # Dict row factory.
            self.row_factory = dict_factory
        else:
            # Tuple row factory (default).
            self.row_factory = None

    def create_tables(self, *tables: Type['DbTable']) -> None:
        for tab in tables:
            self.execute(tab._create_table_query())
            for index_query in tab._create_indexes_query():
                self.execute(index_query)

    def commit(self) -> None:
        self.connection.commit()

    def rollback(self) -> None:
        self.connection.rollback()

    def execute(self, sql: str, parameters: Any = ()) -> Self:
        try:
            super().execute(sql, parameters)
        except DatabaseError as exc:
            fflog(f'DB ERROR ({exc}) on {sql!r}')
            raise
        return self

    def executemany(self, sql: str, parameters: Iterable[Any] = ()) -> Self:
        try:
            super().executemany(sql, parameters)
        except DatabaseError as exc:
            fflog(f'DB ERROR ({exc}) on {sql!r}')
            raise
        return self

    def executescript(self, sql_script: str) -> Self:
        try:
            super().executescript(sql_script)
        except DatabaseError as exc:
            fflog(f'DB ERROR ({exc}) on {sql_script!r}')
            raise
        return self

    def exec(self, statement: 'Statement[R]', data: Union[None, 'DbTable', Iterable['DbTable']] = None) -> 'Result[R]':
        return statement.exec(self, data)

    def add(self, *objs: 'DbTable') -> bool:
        """Adds objects (insert or update). Returns True if DB changed."""
        changed = False
        # # check for instert many
        # if objs:
        #     typ = type(objs[0])
        #     if all(type(o) is typ and not o._has_primary_index() for o in objs):
        #         ...
        # insert or update one by one
        for obj in objs:
            obj._update_db(self.db, self)
            if obj._has_primary_index():
                changed |= obj._update(self)
            else:
                changed |= obj._insert(self)
        return changed

    def insert_many(self, *objs: 'DbTable') -> None:
        """
        Adds objects (insert only).
        All objects must be the same type.
        This method does NOT update objects ID.
        """
        # check for instert many
        if not objs:
            return
        for obj in objs:
            obj._update_db(self.db, self)
        typ = type(objs[0])
        if not all(type(o) is typ for o in objs):
            raise TypeError(f'not the same type {typ.__name__}')
        if any(o._has_primary_index() for o in objs):
            raise TypeError('has ID, can not insert')
        queries, values = zip(*(o._prepare_insert() for o in objs))
        query = queries[0]
        self.executemany(query, values)

    def get(self, table: Type[TableType], id: int) -> Optional[TableType]:
        obj = table._get(self, id)
        if obj is not None:
            obj._update_db(self.db, self)
        return obj

    @property
    def closed(self) -> bool:
        """True if cursor is closed."""
        return self._closed

    def close(self) -> None:
        """Close the cursor."""
        self._closed = True
        super().close()


DbMigrateCallback: TypeAlias = Callable[
    [DbCursor,  # - DB cursor
     int,       # - old db version
     int],      # - new db version
    bool]       # return: true if success

NamedTupleType = Type


class TypeMode(Enum):
    """How to dump SQL value."""
    Auto = 'auto'
    Json = 'json'
    Ast = 'ast'
    Pickle = 'pickle'


# def pickle_load(Union[bytes, str]) -> Any:
#     if isinstance(data, str):


# Helpers for store and restore value types.
known_types: Set[Type] = {
    str, int, bool, float, datetime, dt_date, dt_time,
}
known_types_by_name: Dict[str, Union[Type, Callable]] = {typ.__name__: typ for typ in known_types}
known_types_by_name['datetime'] = fromisoformat
known_types_by_name['date'] = dt_date.fromisoformat
known_types_by_name['time'] = dt_time.fromisoformat
known_types_by_name['json'] = json.loads
known_types_by_name['pickle'] = pickle.loads
known_types_by_name['ast'] = literal_eval


def _json_loader(cls: Type) -> Callable[[Any], Any]:
    """Build a loader for a registered type dumped as JSON text: parse the JSON, then ``__from_json__``."""
    def load(value: Any) -> Any:
        if isinstance(value, (str, bytes, bytearray)):
            value = json.loads(value)
        return cls.__from_json__(value)
    return load


def register_type(cls: Type) -> None:
    """
    Register a value type of the host (with `__to_json__` / `__from_json__`): it is dumped as JSON text (see
    `dump_value_and_type`) and restored by `__from_json__`.
    """
    known_types.add(cls)
    known_types_by_name[cls.__name__] = _json_loader(cls)

#: sqlite3 column type by python type.
sqlite3_column_type: Dict[Type, str] = {
    str: 'TEXT',
    int: 'INTEGER',
    float: 'REAL',
    datetime: 'TEXT',
}


def sql_dump(v: Any, *, _inner: bool = False) -> str:
    """Dump SQL value."""
    from .orm import Expr, Statement
    if v is None:
        return 'NULL'
    if type(v) is bool:
        return str(int(v))
    if type(v) in (int, float):
        return str(v)
    if isinstance(v, (Expr, Statement)):
        return str(v)
    if attrs.has(type(v)):
        vv = ', '.join(sql_dump(getattr(v, f.name), _inner=True) for f in attrs.fields(type(v)))
        if _inner:
            return vv
        return f'({vv})'
    if is_dataclass(v):
        vv = ', '.join(sql_dump(getattr(v, f.name), _inner=True) for f in dc_fields(v))
        if _inner:
            return vv
        return f'({vv})'
    if is_namedtuple(v) or isinstance(v, (tuple, list)):
        vv = ', '.join(sql_dump(f, _inner=True) for f in v)
        if _inner:
            return vv
        return f'({vv})'
    if isinstance(v, Enum):
        return sql_dump(v.value, _inner=_inner)
    if isinstance(v, SQL):
        return v
    if isinstance(v, (bytes, bytearray)):
        return f"X'{bytes(v).hex()}'"  # SQLite blob literal
    if isinstance(v, (dt_date, dt_time)) or is_datetime_instance(v):
        v = str(v)
    # Proper SQL string literal: single-quoted with embedded quotes doubled (NOT Python repr).
    return "'" + str(v).replace("'", "''") + "'"


def render_column_type(sql_type: str, *, meta: Iterable[Any] = (), optional: bool = False, default: Any = MISSING) -> str:
    """Render a single column definition body: ``<TYPE> [constraints] [NOT NULL] [DEFAULT ...]``.

    Shared by the DB layer (:func:`db_create_columns`) and the ORM
    (:meth:`orm.DbTable._create_columns_query`) so both render PRIMARY KEY / UNIQUE /
    NOT NULL / DEFAULT identically. `meta` holds the extra SQL constraint words taken from
    the field's ``Annotated`` metadata (e.g. ``'PRIMARY KEY'``, ``'UNIQUE'``); non-str meta
    is ignored. The column name itself is added (and quoted) by the caller.

    :param sql_type: the rendered SQL column type (e.g. ``'INTEGER'``).
    :param meta: extra constraint words to place right after the type.
    :param optional: when False (and no explicit ``NOT NULL`` in `meta`) a ``NOT NULL`` is added.
    :param default: column default; ``MISSING``/``attrs.NOTHING`` means "no DEFAULT clause".
    """
    constraints: List[str] = [sql_type]
    constraints.extend(m for m in meta if isinstance(m, str))
    if not optional and 'NOT NULL' not in constraints:
        constraints.append('NOT NULL')
    if default is not MISSING and default is not attrs.NOTHING:
        constraints.append(f'DEFAULT {sql_dump(default)}')
    return ' '.join(constraints)


def db_create_columns(named_tuple: NamedTupleType, *, primary: bool = True,
                      constraints: Optional[ColumnConstraints] = None) -> str:
    """Return sqlite3 create table columns from NamedTuple for query.

    Shares column rendering with the ORM via :func:`render_column_type`; the PRIMARY KEY is
    marked with ``Annotated[..., 'PRIMARY KEY']`` (see :data:`PrimaryKey`), the same convention
    the ORM uses. Tables without an explicit PRIMARY KEY field still get a synthetic
    ``id INTEGER PRIMARY KEY`` prefix (``primary=True``).
    """
    if constraints is None:
        constraints = {}
    defaults: Dict[str, Any] = getattr(named_tuple, '_field_defaults', {})

    def get_col(name: str, typ: Any) -> str:
        nonlocal primary
        meta: Tuple[Any, ...] = ()
        if get_origin(typ) is Annotated:
            args = get_args(typ)
            typ, meta = args[0], args[1:]
            if 'PRIMARY KEY' in meta:
                primary = False
        if isinstance(typ, str):
            sql_type, optional = typ, False
        else:
            optional = is_optional(typ)
            sql_type = sqlite3_column_type.get(remove_optional(typ), 'TEXT')
        extra = constraints.get(name)
        col_meta = (*meta, extra) if extra else meta
        body = render_column_type(sql_type, meta=col_meta, optional=optional, default=defaults.get(name, MISSING))
        return f'{name} {body}'

    query = ', '.join(get_col(name, typ) for name, typ in named_tuple.__annotations__.items())
    if primary:
        query = f'id INTEGER PRIMARY KEY, {query}'
    return query


def db_list_columns(named_tuple: NamedTupleType) -> str:
    """Return list of NamedTuple columns names."""
    return ', '.join(named_tuple.__annotations__)


def load_value(value: Any, type: Optional[str] = None) -> Any:
    """Load (parse) SQL value."""
    if value is not None:
        value = known_types_by_name.get(type or '', str)(value)
    return value


def strict_dump_value(mode: TypeMode, value: Any) -> Union[str, bytes]:
    """Dump (encode) SQL value in given mode. Return value as str or bytes."""
    if mode == TypeMode.Auto:
        mode = TypeMode.Json
    if mode == TypeMode.Json:
        return json.dumps(value, cls=JsonEncoder)
    if mode == TypeMode.Pickle:
        return pickle.dumps(value)
    if mode == TypeMode.Ast:
        # NOTE: it could be incorrect, not all __repr__ prints AST form.
        return repr(value)
    raise ValueError(f'Unknow SQL value type {mode!r}')


def dump_value_and_type(value: Any, *, mode: Optional[Union[TypeMode, str]] = None, force_str: bool = False) -> Tuple[Any, str]:
    """Dump (encode) a SQL value. Return ``(value, type_name)``.

    The returned `value` is always sqlite-bindable AND JSON-serializable (str / number / None,
    or bytes for the pickle mode) so the same pair round-trips through the local sqlite store and
    the in-memory / REST service state alike. `load_value` is the matching decoder. Non-JSON modes
    (pickle/ast) apply only to dict/list/tuple; note pickle yields bytes, which the REST/JSON path
    can NOT carry.
    """
    type_name = None
    if type(value) in known_types:
        type_name = value.__class__.__name__
        if getattr(value, '__to_json__', None) or attrs.has(value):
            # e.g. MediaRef: __to_json__ returns a dict -> must be JSON text to bind/transport.
            value = json.dumps(value, cls=JsonEncoder)
        elif isinstance(value, (dt_date, dt_time)):  # datetime is a dt_date subclass
            value = value.isoformat()
        # str/int/bool/float are natively bindable -> leave as-is.
    elif getattr(value, '__to_json__', None) or attrs.has(value):
        type_name, value = TypeMode.Json.value, json.dumps(value, cls=JsonEncoder)
    elif isinstance(value, (dict, list, tuple)):
        if mode is None:
            mode = TypeMode.Json
        elif isinstance(mode, str):
            mode = TypeMode(mode)
        type_name, value = mode.value, strict_dump_value(mode, value)
    if force_str:
        value = str(value)
    return value, type_name or ''


def _split_sql(script: str) -> List[str]:
    """Split a (BEGIN/COMMIT-free) SQL script into individual statements.

    The whole migration runs inside ONE outer transaction (held by ``update_db_version`` /
    ``OrmDatabase``), so ``executescript`` can NOT be used -- it force-commits any pending
    transaction, which would release the migration's EXCLUSIVE lock between steps. Statements are
    accumulated line-by-line until SQLite reports a complete statement, then executed individually.
    """
    statements: List[str] = []
    buf = ''
    for line in script.splitlines(keepends=True):
        buf += line
        if complete_statement(buf):
            statements.append(buf)
            buf = ''
    if buf.strip():  # trailing fragment (e.g. last statement without a final newline)
        statements.append(buf)
    # drop chunks that carry no actual SQL (blank / comment-only)
    return [s for s in statements
            if any(ln.strip() and not ln.strip().startswith('--') for ln in s.splitlines())]


def auto_migrate(cur: DbCursor, old_ver: int, ver: int) -> bool:
    """Apply ``<options.migrate_path()>/<name>.<step>.sql`` for each step in ``(old_ver, ver]`` (no folder: no files).

    The version is bumped by CODE after each applied step — migration ``.sql`` files do NOT need
    to (and should not) update ``db.version`` themselves. The ``.sql`` MUST NOT contain
    ``BEGIN``/``COMMIT``: the whole migration runs in ONE transaction owned by the caller
    (``update_db_version``), so it is atomic and holds a single cross-process EXCLUSIVE lock. A
    failing statement raises, and the caller rolls back the entire migration (all steps).
    """
    path = options.migrate_path()
    if path is None:
        return True
    for i in range(old_ver + 1, ver + 1):
        patch = path / f'{cur.db.name}.{i}.sql'
        if not patch.exists():
            continue
        try:
            for statement in _split_sql(patch.read_text()):
                cur.execute(statement)
        except (IOError, DbError) as exc:
            log.error(f'DB {cur.db.name} migrate FAILED on step {i}: {exc}')
            raise  # caller rolls back the whole (single-transaction) migration
        cur.execute('UPDATE db SET version=?', (i,))  # code owns the version, not the .sql
    return True


def update_db_version(cur: DbCursor,
                      version: int,
                      *,
                      migrate: Optional[DbMigrateCallback] = auto_migrate,
                      backup: Optional[bool] = None,
                      ) -> Optional[int]:
    """Update DB version and return the old version (or None if there was no ``db`` table).

    The migration runs as ONE atomic transaction holding a cross-process EXCLUSIVE lock on the MAIN
    db (no sidecar file). If the caller already holds a transaction (e.g. ``OrmDatabase._on_connect``
    wrapping ``create_tables`` + ``on_update`` in the same lock), this nests: it neither begins nor
    commits, leaving transaction control to the caller. When it owns the transaction and a step
    fails, it rolls back the whole migration and returns the unchanged version (retry next run).
    """
    def read_version() -> Union[None, int]:
        cur.execute('SELECT version from db')
        row: Union[None, Dict[str, int], Tuple[int]] = cur.fetchone()
        if not row:
            return None
        return row['version'] if isinstance(row, Mapping) else row[0]

    def do_backup(at_ver: int) -> None:
        from shutil import copy2
        if cur.db.path is None:
            log.warning(f'Can NOT create DB backup of {cur.db.name} at version {at_ver}: no file path')
            return
        if PY >= (3, 9):
            dst = cur.db.path.with_stem(f'{cur.db.path.stem}.{at_ver}')
        else:
            dst = cur.db.path.with_name(f'{cur.db.path.stem}.{at_ver}{cur.db.path.suffix}')
        try:
            copy2(cur.db.path, dst)
        except OSError as exc:
            fflog.warning(f'Can NOT create DB backup of {cur.db.path} as {dst}: {exc}')

    cur.execute('CREATE TABLE IF NOT EXISTS db (version INTEGER)')
    old_ver = read_version()
    if old_ver is None:
        cur.execute('INSERT INTO db (version) VALUES (?)', (version,))
        return None
    if old_ver > version:
        # DB is newer than this code (e.g. the add-on was downgraded). Do NOT migrate down or lower
        # the stored version — leave the newer schema intact so a later re-upgrade sees the right
        # state instead of re-running already-applied migrations.
        log.warning(f'DB {cur.db.name} is newer (v{old_ver}) than code (v{version}); not migrating')
        return old_ver
    if old_ver < version:
        # Cross-process mutex = an EXCLUSIVE transaction on the MAIN db. Own it only if the caller
        # has not already started one (then they own the whole migration lock). BEGIN EXCLUSIVE also
        # gives atomicity for path-less / in-memory DBs (no file lock, but rollback still works).
        own_tx = not cur.connection.in_transaction
        if own_tx:
            cur.commit()                  # drop any stale read snapshot before locking
            cur.execute('BEGIN EXCLUSIVE')
        try:
            old_ver = read_version()      # RE-READ under the lock; another process may have migrated
            if old_ver is not None and old_ver < version:
                if backup is None:
                    backup = options.backup()
                if backup and cur.db.path:
                    do_backup(old_ver)    # safe: only SELECTs so far, on-disk file is pre-migration
                if not callable(migrate) or migrate(cur, old_ver, version):
                    cur.execute('UPDATE db SET version=?', (version,))
            if own_tx:
                cur.commit()
        except (IOError, DbError) as exc:
            if not own_tx:
                raise                     # caller owns the transaction -> let it roll back
            cur.rollback()                # atomic: undo every step; version stays unchanged
            log.error(f'DB {cur.db.name} migration failed, rolled back (version kept at {old_ver}): {exc}')
        return old_ver
    return old_ver


def dict_factory(cursor, row):
    fields = [column[0] for column in cursor.description]
    return {key: value for key, value in zip(fields, row)}


class DbMode(Enum):
    """DB mode - how all DBs work."""
    # DB connections are separated: every process/interpreter and every thread has its own
    # connection pool, separate from other threads. Forces WAL (concurrent readers + 1 writer).
    SEPARATED = 'separated'
    # One shared connection; the manager serializes cursor access with a lock to avoid corruption.
    MULTI_THREAD = 'multi_thread'


class Db:
    """Proxy to database."""

    def __init__(self, *, name: str, conn: Optional[SqlConnection] = None, path: Optional[Path] = None,
                 echo: bool = False, orm: Optional[bool] = None, mode: DbMode = DbMode.SEPARATED) -> None:
        if conn is None:
            conn = DbManager()[name]._conn
        #: Mode.
        self.mode: DbMode = mode
        #: DB Connection.
        self._conn: SqlConnection = conn
        #: Thread-safe locker. Reentrant: a cursor may lazily open a nested cursor
        #: on the same Db (e.g. relationship load) while this lock is held.
        self.lock = RLock()
        #: Database name.
        self.name: str = name
        #: Database path.
        self.path: Optional[Path] = path
        #: Use ORM (row as dict). If None, then autodetect.
        self._orm: Optional[bool] = orm
        #: Debug echo queries.
        self._echo: bool = not echo  # Force change echo detection.
        #: True if is initialized.
        self.initialized: bool = False
        # Set echo.
        self.echo = echo
        # Dict row factory.
        if self._orm:
            self._conn.row_factory = dict_factory

    def __repr__(self) -> str:
        return f'Db({self.name!r}, path={self.path!r})'

    @property
    def orm(self) -> bool:
        """True is ORM (row as dict)."""
        return self._orm or False

    @orm.setter
    def orm(self, orm: bool) -> None:
        self._orm = bool(orm)
        if self._orm:
            # Dict row factory.
            self._conn.row_factory = dict_factory
        else:
            # Tuple row factory (default).
            self._conn.row_factory = None

    @property
    def echo(self) -> bool:
        """Echo queries (debug)."""
        return self._echo

    @echo.setter
    def echo(self, echo: bool) -> None:
        """Echo queries (debug)."""
        echo = bool(echo)
        if self._echo != echo:
            self._echo = echo
            if self._echo:
                self._conn.set_trace_callback(self._log_statement)
            else:
                self._conn.set_trace_callback(None)

    def _log_statement(self, stmt: str):
        """Echo SQL statement."""
        fflog(f'(DB:{self.name}) \033[38;5;244m {stmt!r} \033[0m', stack_depth=2)

    @contextmanager
    def cursor(self, *, initialize: bool = True) -> Generator[DbCursor, None, None]:
        with self.lock:
            cur = self._conn.cursor(partial(DbCursor, db=self))
            try:
                if initialize and not self.initialized:
                    self._create_tables(cur)
                    self.initialized = True
                yield cur
            except BaseException:
                # Do NOT persist partial work: roll back the (connection-level) transaction, then re-raise.
                try:
                    cur.rollback()
                finally:
                    cur.close()
                raise
            else:
                try:
                    cur.commit()
                finally:
                    cur.close()

    def _create_tables(self, cur: DbCursor) -> None:
        """Create tables. To override by custom classes."""


@attrs.define
class DbLocal:
    ff_db_manager_connections: Dict[Path, Db] = attrs.Factory(dict)


@singleton
class DbManager:
    """Manager for all databases."""

    def __init__(self, path: Optional[Path] = None, *, echo: Optional[bool] = None, mode: DbMode = DbMode.SEPARATED):
        # [[ Note, it's singleton, this __init__ is called only once. ]]
        #: Mode.
        self._mode: DbMode = mode
        #: All connections if mode is NOT "separated".
        self._local: Optional[DbLocal] = None
        #: Lack for multithread access.
        self.lock = Lock()
        #: Base path (None: `options.path`).
        self._path: Optional[Path] = path
        #: Debug echo queries (None: `options.echo`).
        self._echo: Optional[bool] = None if echo is None else bool(echo)
        # Register cleanup on interpreter exit.
        atexit.register(self.clear)

    @property
    def echo(self) -> bool:
        """Return True if the queries are echoed (debug)."""
        return options.echo() if self._echo is None else self._echo

    @echo.setter
    def echo(self, echo: bool) -> None:
        """Set the echo of the queries (debug)."""
        self._echo = bool(echo)

    @property
    def path(self) -> Path:
        """Return the base path of the databases."""
        return options.path() if self._path is None else self._path

    @path.setter
    def path(self, path: Path) -> None:
        """Set the base path of the databases."""
        self._path = path

    @path.deleter
    def path(self) -> None:
        """Take the base path of the databases from `options.path` again."""
        self._path = None

    @property
    def mode(self) -> DbMode:
        """Reads DB access mode."""
        return self._mode

    @property
    def connections(self) -> Dict[Path, Db]:
        """DB connections pool (per-thread in SEPARATED mode).

        No explicit per-thread close hook: when a thread ends, CPython tears down its
        ``threading.local`` storage, which drops this pool and finalizes the :class:`Db` objects
        (and their sqlite connections) deterministically. The pool persists across operations on
        the same thread (the intended pooling) and is closed at thread termination.

        The pool of the script thread is closed by ``atexit`` (:meth:`clear`) instead: that thread lives until
        ``Py_EndInterpreter``, where Python 3.8 clears the thread states under the runtime lock and a sqlite
        statement finalizer, which releases the GIL, deadlocks with another interpreter starting or ending
        (cpython#102126, fixed in 3.9).
        """
        if self._local is None:
            if self._mode is DbMode.SEPARATED:
                self._local = cast(DbLocal, thread_local())
            else:
                self._local = DbLocal()
        if self._mode is DbMode.SEPARATED:
            # threading.local has no attributes for a freshly-seen thread — seed the per-thread pool.
            return self._local.__dict__.setdefault('ff_db_manager_connections', {})
        return self._local.ff_db_manager_connections

    def clear(self) -> None:
        """Clear manager, close all DB connections."""
        with self.lock:
            connections = self.connections
            for db in connections.values():
                db._conn.close()
            connections.clear()

    def _create_connection(self, name: str, path: Path, mode: DbMode) -> Db:
        """Create new connection. User have to handle concurrency (locks)."""
        timestamp = monotonic()
        if self._mode is DbMode.SEPARATED:
            log_suffix = f' @ thread({current_thread().name})'
        else:
            log_suffix = ''
        try:
            fflog.debug(f'[DB] new connection {name!r} to {path}{log_suffix}')
            path.parent.mkdir(parents=True, exist_ok=True)
            timeout = options.connection_timeout()
            conn = db_connect(path, check_same_thread=False, timeout=timeout)
            fflog(f'[DB] connected {name!r}{log_suffix}')  # the path and the connection: debug (above)
        except Exception:
            log(f'[DB] Connection to DB {path}{log_suffix} fails.', LOGERROR)
            raise
        connection_time = monotonic() - timestamp
        if connection_time > 1.0:
            fflog(f'[WARNING] Connection to DB {path}{log_suffix} took {connection_time:.1f} seconds')
        # force WAL for separated access
        if self._mode is DbMode.SEPARATED:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute(f'PRAGMA synchronous={options.synchronous(name)}')
        # DB wrapper
        db = Db(name=name, conn=conn, path=path, echo=self.echo, mode=mode)
        return db

    def path_for_db(self, name: str) -> Path:
        """Return path to DB."""
        return self.path / f'{name}.db'

    def remove_db(self, name: str) -> bool:
        """Remove database (with its WAL / journal files, a stale WAL next to a new DB could corrupt it)."""
        path = self.path_for_db(name)
        with self.lock:
            connections = self.connections
            if db := connections.pop(path, None):
                db._conn.close()
            if path.exists():
                try:
                    path.unlink()
                    for suffix in ('-wal', '-shm', '-journal'):
                        path.with_name(f'{path.name}{suffix}').unlink(missing_ok=True)
                    return True
                except OSError:
                    fflog_exc()
        return False

    def _get(self, name: str) -> Db:
        """Get or open the pooled DB connection for `name` (kept per-thread until the thread ends)."""
        path = self.path_for_db(name)
        with self.lock:
            connections = self.connections
            db = connections.get(path)
            if db is None:
                db = self._create_connection(name, path, mode=self._mode)
                connections[path] = db
            return db

    def __getitem__(self, name: str) -> Db:
        """Get or open DB connection."""
        return self._get(name)

    def __delitem__(self, name: str) -> None:
        """Close connection."""
        path = self.path_for_db(name)
        with self.lock:
            db = self.connections.pop(path, None)
            if db is not None:
                db._conn.close()

    def maintain(self, name: str, *, vacuum: bool = True, checkpoint: bool = True) -> bool:
        """Reclaim space on the named DB: WAL checkpoint (TRUNCATE) then VACUUM.

        Runs on a dedicated autocommit connection because VACUUM can NOT run inside a transaction.
        Best-effort: returns False (doing nothing harmful) when the DB file is missing or is
        locked/busy by another connection — so a periodic maintenance task can simply retry later.
        Intended to be called occasionally (e.g. by the service) on long-lived DBs.
        """
        path = self.path_for_db(name)
        if not path.exists():
            return False
        try:
            conn = db_connect(path, timeout=options.connection_timeout(), isolation_level=None)
        except DbError as exc:
            fflog(f'[DB] maintain({name!r}) connect failed: {exc}')
            return False
        try:
            if checkpoint:
                conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            if vacuum:
                conn.execute('VACUUM')
            return True
        except DatabaseError as exc:
            # `database is locked`/`busy` (OperationalError) or any op error -> skip this round.
            fflog(f'[DB] maintain({name!r}) skipped: {exc}')
            return False
        finally:
            conn.close()


@contextmanager
def get_cursor(name: str) -> Generator[DbCursor, None, None]:
    """Get a cursor on the named DB.

    The connection is pooled per-thread (reused across calls, closed when the thread ends) — the
    same pattern as the state/media cursors; there is no per-call open/close churn.
    """
    with DbManager()[name].cursor() as cur:
        yield cur


#: Global manager. Alternately you can use just DbManager(), it's a singleton.
db_manager = DbManager()


if __name__ == '__main__':
    ...
