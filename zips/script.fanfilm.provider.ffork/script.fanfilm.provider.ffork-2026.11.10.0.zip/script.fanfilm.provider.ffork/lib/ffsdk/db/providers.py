"""
The data of the providers (sessions, tokens, indexes...): the key-value table `provider_data` and the store of a
provider add-on, `providers.db` in the data folder of the add-on (`options.path`).

A namespace is the provider key (`<add-on>:<provider>`) or a shared one of the provider add-on (`<add-on ID>/<name>`).
The expired data is removed lazily: at the first connection of an interpreter, at most once a day (no service needed).
"""

from __future__ import annotations
from hashlib import sha256
from pathlib import Path
from time import time
from typing import Callable
from sqlite3 import connect as db_connect, Error as DbError
from .db import addon_data_path, options
from .kvstore import KeyValueRow, KeyValueStore
from .orm import OrmDatabase, DbCursor, select, delete, insert_or_replace, AND, best_effort
from ..log import fflog

#: The namespace of the marker of the last cleanup (no provider has an empty one).
CLEANUP_NAMESPACE = ''
#: The key of the marker of the last cleanup.
CLEANUP_KEY = 'cleanup'
#: The cleanup period (seconds): the lifetime of its marker.
CLEANUP_PERIOD = 24 * 3600


class ProviderDataRow(KeyValueRow):
    """Key-value data of a provider (or of a shared helper, see the namespace)."""

    __tablename__ = 'provider_data'


def cleanup(cur: DbCursor) -> int:
    """Remove the expired rows, if the last cleanup is older than `CLEANUP_PERIOD`. Return the count."""
    now = int(time())
    table = ProviderDataRow
    marker = cur.exec(select(table).where(AND(table.namespace == CLEANUP_NAMESPACE, table.key == CLEANUP_KEY,
                                              table.expires_at > now))).first()  # type: ignore[reportOptionalOperand]  # a column
    if marker is not None:
        return 0
    cur.exec(delete(table).where(table.expires_at < now))  # type: ignore[reportOptionalOperand]  # a column
    count = cur.rowcount
    insert_or_replace(table).exec(cur, table(namespace=CLEANUP_NAMESPACE, key=CLEANUP_KEY, json_string='true', updated_at=now,
                                             expires_at=now + CLEANUP_PERIOD))
    return count


def _on_connect(cur: DbCursor) -> None:
    """Clean the database up lazily (an error is logged only: the data is still usable)."""
    try:
        if count := cleanup(cur):
            fflog(f'[PROVIDERS] {count} expired rows removed')
    except DbError as exc:
        fflog(f'[PROVIDERS] cleanup failed: {exc!r}')


#: The database of the provider data of the provider add-on.
db = OrmDatabase('providers', ProviderDataRow, version=1, on_connect=_on_connect)


def _db() -> OrmDatabase:
    """Return the database of the provider data (at call time: a test can replace it)."""
    return db


class ProviderStore(KeyValueStore):
    """
    Data of a provider (sessions, tokens, ...) or of a shared helper, in its own namespace.

    The lifetime is given on every write (`ttl`, None = never expires). `max_age` on read is a soft freshness: older
    data is skipped, but kept (e.g. a stale fallback).
    """

    def __init__(self, namespace: str, *, database: Callable[[], OrmDatabase] = _db) -> None:
        """Create the store of the namespace (in `providers.db`, the host gives its own database)."""
        super().__init__(namespace, table=ProviderDataRow, db=database)

    def login_refused(self, user: str, password: str) -> bool:
        """Return True if a login of these credentials failed lately (`refuse_login()`): no new try until it expires or they change."""
        return self.get(_login_key(user, password)) is not None

    def refuse_login(self, user: str, password: str, *, ttl: float) -> None:
        """Remember a failed login of these credentials for `ttl` seconds: a service locks an account after repeated failures."""
        self.set(_login_key(user, password), True, ttl=ttl)


def _login_key(user: str, password: str) -> str:
    """Return the key of a failed login of the credentials (their hash: no secret in the key)."""
    digest = sha256('\0'.join((user, password)).encode('utf-8')).hexdigest()
    return f'login_failed_{digest[:16]}'


@best_effort(lambda: None, db=_db)
def clear() -> None:
    """Remove all data of the providers."""
    with db.cursor(write=True) as cur:
        cur.exec(delete(ProviderDataRow))


def database_path(addon_id: str) -> Path:
    """Return the database file of the provider data of a provider add-on."""
    return addon_data_path(addon_id) / f'{db.name}.db'


def clear_file(path: Path) -> bool:
    """
    Remove all data of the providers in the database file of another provider add-on (its worker does not run, nothing
    of it is loaded here), the database is not opened by the manager. Return True if the data was removed.
    """
    if not path.exists():
        return False
    try:
        conn = db_connect(path, timeout=options.connection_timeout())
        try:
            with conn:
                conn.execute(f'DELETE FROM {ProviderDataRow.__tablename__}')
        finally:
            conn.close()
    except DbError as exc:
        fflog(f'[PROVIDERS] {path}: not cleared: {exc!r}')
        return False
    return True
