"""
The manifest of a provider add-on (xdostawca): `ff.providers.json` in the add-on folder, read by the host before any
import (a wrong protocol major: the add-on is skipped without running its code).

    {"protocol": "1.0", "entry": "<module>:<object>", "modes": ["service", "import"], "short_name": "Fenom"}

`short_name` (optional): the name of the add-on where FanFilm has little room (over the provider of its source).
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Literal
from attrs import frozen
from typing_extensions import TypeAlias
from .protocol import PROTOCOL_VERSION


#: The manifest file name.
MANIFEST = 'ff.providers.json'
#: How the host runs a provider add-on: its worker script, an import into the host process.
RunMode: TypeAlias = Literal['service', 'import']
#: All run modes, the preferred first.
RUN_MODES: tuple[RunMode, ...] = ('service', 'import')


@frozen(kw_only=True)
class Manifest:
    """The manifest of a provider add-on."""

    #: The add-on folder.
    path: Path
    #: The protocol version of the add-on.
    protocol: str
    #: The factory of the provider object: `<module>:<object>` (the module relative to the add-on libraries).
    entry: str
    #: The run modes it allows, the preferred first.
    modes: tuple[RunMode, ...] = RUN_MODES
    #: The short name of the add-on (over the provider of its source in the source list), '' none: derived from its name.
    short_name: str = ''

    @property
    def id(self) -> str:
        """Return the add-on ID."""
        return self.path.name


def stamp(path: Path) -> str:
    """Return the stamp of an add-on: its version files changed (the times of `addon.xml` and the manifest)."""
    parts = []
    for name in ('addon.xml', MANIFEST):
        try:
            parts.append(str((path / name).stat().st_mtime_ns))
        except OSError:
            parts.append('-')
    return ':'.join(parts)


def compatible(version: str, host: str = PROTOCOL_VERSION) -> bool:
    """Check if the protocol `version` talks with the `host` one: the same major (unknown keys are ignored both ways)."""
    return version.partition('.')[0] == host.partition('.')[0]


def read_manifest(path: Path) -> Manifest | None:
    """Return the manifest of the add-on folder, None if it has none, it is broken or its protocol is not compatible."""
    try:
        data = json.loads((path / MANIFEST).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or not isinstance(entry := data.get('entry'), str) or ':' not in entry:
        return None
    if not compatible(str(data.get('protocol', ''))):
        return None
    modes: tuple[RunMode, ...] = tuple(mode for mode in data.get('modes') or RUN_MODES if mode in RUN_MODES) or RUN_MODES  # type: ignore[assignment]
    short_name = data.get('short_name')
    return Manifest(path=path, protocol=str(data['protocol']), entry=entry, modes=modes, short_name=short_name if isinstance(short_name, str) else '')
