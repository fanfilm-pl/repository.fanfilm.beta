"""
Dates of the SDK: the python `datetime` class (an add-on may patch the module class), a `strptime` safe in a Kodi
interpreter and the ISO 8601 parser of all Python versions.

Import it before an add-on patches `datetime.datetime`: FanFilm does it first in `lib/__init__.py`, the worker script of
a provider add-on imports the SDK before the scrapers.
"""

from __future__ import annotations
from sys import version_info
import re
import time
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing_extensions import TypeIs

#: The python datetime class (taken at the import, before a patch of the module class).
python_datetime = datetime
#: Python has datetime.fromisoformat with timezone support.
HAS_ISO = version_info >= (3, 11)

#: The parts of an ISO 8601 date and time (the zone separately).
_rx_fmt = re.compile(r'(?P<dt>[-W\d]+)(?:(?P<sep>[ T])(?P<tm>[:\d]+)(?P<f>\.\d+)?)?(?P<tz>[+-]\d{2}:?\d{2}|Z)?')


def is_datetime_instance(obj: object, /) -> TypeIs[datetime]:
    """
    Return True if object is a datetime: of the python class or of a patched one (its subclass). Not the module class:
    an add-on patches it in the FanFilm interpreter too (`plugin.video.fanfilm.tele` strptime fix, on any python).
    """
    return isinstance(obj, python_datetime)


def time_strptime(date_string: str, format: str) -> datetime:  # noqa: A002
    """`datetime.strptime()` by `time.strptime()` (the fallback of `strptime()`), keeps the zone of `%z` (no fraction)."""
    parsed = time.strptime(date_string, format)
    zone = None if parsed.tm_gmtoff is None else timezone(timedelta(seconds=parsed.tm_gmtoff))
    return python_datetime(*parsed[0:6], tzinfo=zone)


def strptime(date_string: str, format: str) -> datetime:  # noqa: A002
    """
    Return `datetime.strptime()`; a Kodi interpreter of Python < 3.13 can fail it (TypeError, see
    https://bugs.python.org/issue27400), then `time_strptime()`.
    """
    try:
        return python_datetime.strptime(date_string, format)
    except TypeError:
        return time_strptime(date_string, format)


def _fromisoformat_compat(date_string: str, /) -> datetime:
    """
    Return a datetime corresponding to a date_string in any valid ISO 8601 format (Python < 3.11). The zone is taken from
    the string, not by `strptime('%z')`: the fallback of `strptime()` loses it.
    """
    if date_string.endswith(' UTC'):
        date_string = f'{date_string[:-4]}Z'
    mch = _rx_fmt.fullmatch(date_string)
    if not mch:
        return python_datetime.fromisoformat(date_string)
    fmt = ''
    if 'W' in mch['dt']:
        fmt += '%G-W%V-%u'
    elif '-' in mch['dt']:
        fmt += '%Y-%m-%d'
    else:
        fmt += '%Y%m%d'
    if mch['sep']:
        fmt += mch['sep']
    if mch['tm']:
        fmt += '%H:%M:%S' if ':' in mch['tm'] else '%H%M%S'
    if mch['f']:
        fmt += '.%f'
    value = strptime(date_string[:mch.start('tz')] if mch['tz'] else date_string, fmt)
    if not (zone := mch['tz']):
        return value
    if zone == 'Z':
        return value.replace(tzinfo=timezone.utc)
    sign = -1 if zone[0] == '-' else 1
    hours, minutes = int(zone[1:3]), int(zone[-2:])
    return value.replace(tzinfo=timezone(sign * timedelta(hours=hours, minutes=minutes)))


if HAS_ISO:
    def fromisoformat(date_string: str, /) -> datetime:
        """Return a datetime corresponding to a date_string in any valid ISO 8601 format (also `… UTC`)."""
        if date_string.endswith(' UTC'):
            date_string = f'{date_string[:-4]}Z'
        return python_datetime.fromisoformat(date_string)
else:
    fromisoformat = _fromisoformat_compat
