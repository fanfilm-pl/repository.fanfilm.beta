"""
The providers of one request run together: a thread per provider (no pool limit: all at once), the `find` stream of
the protocol (`items` 0..n times, `done` exactly once for every provider), a time limit and a cancel of the request.

A request has its own stop scope and its own event queue: a thread of an earlier request (still blocked) writes only to
its own queue, it never mixes with a later request. The stopped scope cuts the sockets of the left threads.
"""

from __future__ import annotations
import queue
from time import monotonic
from typing import Any, Callable, Iterable, Iterator, Sequence
from attrs import frozen
from .threads import Thread, CancelScope, ThreadCanceled, current_scope, check_thread_cancel
from .protocol.types import FindEvent, DoneEvent, DoneErrorKind


#: How often (seconds) the request checks its cancel while it waits for the events.
POLL_STEP = .1


@frozen
class Found:
    """The result of a provider search with what the host should know about it (the items alone: a list, an iterable)."""

    #: The items (a list, an iterable of them, None).
    items: Iterable[Any] | None
    #: Lifetime of the cached result (seconds, 0: not cached), None: the catalog / the host default.
    sources_ttl: int | None = None


@frozen
class Task:
    """A provider of the request: its ID and its search (it returns the items: a list, an iterable of them, None, `Found`)."""

    #: The provider ID.
    provider: str
    #: The search of the provider.
    find: Callable[[], Iterable[Any] | Found | None]


def _done(provider: str, start: float, count: int, kind: DoneErrorKind | None = None, message: str = '', *,
          sources_ttl: int | None = None) -> DoneEvent:
    """Return the `done` event of a provider."""
    done: DoneEvent = {'event': 'done', 'provider': provider, 'stats': {'elapsed': round(monotonic() - start, 3), 'count': count}}
    if kind is not None:
        done['error'] = {'kind': kind, 'message': message} if message else {'kind': kind}
    if sources_ttl is not None:
        done['sources_ttl'] = sources_ttl
    return done


def run(tasks: Sequence[Task], *, timeout: float, canceled: Callable[[], bool] | None = None) -> Iterator[FindEvent]:
    """
    Run the providers, yield their events as they come: a list result is one `items` event, an iterable gives an
    event for every item (the items so far are kept on a timeout); `done` after the last items of a provider. On the
    time limit / the cancel the providers not done get `done` with the error `timeout` / `canceled` and are stopped.
    """
    start = monotonic()
    scope = CancelScope(parent=current_scope())
    events: queue.Queue[FindEvent] = queue.Queue()

    def work(task: Task) -> None:
        """Search with one provider, put its events."""
        count = 0
        kind: DoneErrorKind | None = None
        message = ''
        sources_ttl: int | None = None
        try:
            found = task.find()
            if isinstance(found, Found):
                found, sources_ttl = found.items, found.sources_ttl
            if isinstance(found, (list, tuple)):
                if found:
                    events.put({'event': 'items', 'provider': task.provider, 'items': list(found)})
                    count = len(found)
            elif found is not None:
                for item in found:
                    check_thread_cancel()
                    events.put({'event': 'items', 'provider': task.provider, 'items': [item]})
                    count += 1
        except ThreadCanceled:
            kind = 'canceled'
        except Exception as exc:
            from .log import fflog_exc
            fflog_exc()
            kind, message = 'exception', repr(exc)
        events.put(_done(task.provider, start, count, kind, message, sources_ttl=sources_ttl))

    pending = {task.provider: 0 for task in tasks}
    for task in tasks:
        Thread(target=work, args=(task,), name=f'{task.provider} find', scope=scope).start()
    end = start + timeout
    reason: DoneErrorKind = 'timeout'
    try:
        while pending:
            if canceled is not None and canceled():
                reason = 'canceled'
                break
            if (remaining := end - monotonic()) <= 0:
                break
            try:
                event = events.get(timeout=min(remaining, POLL_STEP))
            except queue.Empty:
                continue
            provider = event['provider']
            if provider not in pending:  # an unknown provider (never), the request does not mix
                continue
            if event['event'] == 'done':
                del pending[provider]
            else:
                pending[provider] += len(event['items'])
            yield event
        for provider, count in list(pending.items()):
            del pending[provider]
            yield _done(provider, start, count, reason)
    finally:
        scope.set()  # the left providers, their pools and sockets (also when the caller stops reading)
