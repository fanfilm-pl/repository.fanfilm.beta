"""
FanFilm SDK: the shared code of FanFilm and the add-ons that provide sources to it.

The SDK never imports FanFilm (`lib.ff`, `const`...): its modules import each other relatively, other libraries
(`attrs`, `typing_extensions`) absolutely from the environment. FanFilm uses it directly, an add-on gets a copy.

MIT License

Copyright (c) 2026 FanFilm

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

#: The SDK version (semver), not the protocol version.
__version__ = '0.1.0'
#: The host add-on (FanFilm): its own providers are not served by a provider add-on.
HOST_ID = 'plugin.video.fanfilm'
