"""Common types of the SDK: annotations (also PEP 585 / 604 on Python 3.8), optional and union helpers, typed arguments."""

from __future__ import annotations
import sys
from sys import version_info
import ast
import re
from weakref import ReferenceType  # type: ignore[import]
from typing import Union, Any, ForwardRef, TypeVar, Type, overload, TYPE_CHECKING
from typing import _SpecialForm, _GenericAlias  # type: ignore[import]
from typing_extensions import Literal, Annotated, TypeForm, Protocol, Self, TypeAlias, get_origin, get_args
from typing_extensions import get_type_hints as _te_get_type_hints
from functools import reduce
from operator import or_
from enum import Enum, IntEnum, Flag, IntFlag
from pathlib import Path, PurePosixPath as UPath
from urllib.parse import SplitResult, urlunsplit
from attrs import frozen, field
from .dates import is_datetime_instance  # noqa: F401  (the types of the SDK)

if TYPE_CHECKING:
    from datetime import timezone, tzinfo, date as dt_date, time as dt_time
    from typing import Sequence, Mapping, Iterator, Callable
    from typing_extensions import TypeIs

if version_info >= (3, 10) or TYPE_CHECKING:
    from types import UnionType, EllipsisType, NoneType
    _UnionType = UnionType
else:
    _UnionType = _GenericAlias  # pyright hack
    UnionType = Union
    EllipsisType = type(...)
    NoneType = type(None)


T = TypeVar('T')
T_co = TypeVar('T_co', covariant=True)
C = TypeVar('C', bound=Type)
E = TypeVar('E', bound=Enum)

SpecialType: TypeAlias = '_SpecialForm | _GenericAlias | _UnionType'


#: Any JSON data object.
JsonData: TypeAlias = 'dict[str, Any]'
#: Any JSON data object (read-only).
RoJsonData: TypeAlias = 'Mapping[str, Any]'
#: Any JSON data.
JsonResult: TypeAlias = 'JsonData | Sequence[JsonData]'

#: Keyword arguements.
Args: TypeAlias = 'tuple[Any, ...]'
#: Keyword arguements.
KwArgs: TypeAlias = 'dict[str, Any]'

#: Any parameters.
Params: TypeAlias = 'dict[str, Any]'
#: Web headers.
Headers: TypeAlias = 'dict[str, str]'


ArgType: TypeAlias = 'type[Any] | Callable[[Any], Any]'
AnnMeta: TypeAlias = 'Sequence[Any]'

TRUE_VALUES = {'true', 'on', '1', 'hi', 'high', 'up', 'enable', 'enabled'}
FALSE_VALUES = {'false', 'off', '0', 'lo', 'low', 'down', 'disable', 'disabled'}


# allow subscripted built-in collection types in Python 3.8 and earlier in type annotations with get_type_hints()
if version_info >= (3, 9):
    PY38_TYPES = {}
else:
    from typing import Tuple, List, Set, Dict, FrozenSet, Type
    PY38_TYPES = {'tuple': Tuple, 'list': List, 'set': Set, 'dict': Dict, 'frozenset': FrozenSet, 'type': Type}


#: Private namespace name injected to back-port PEP 604 unions (`A | B`) on Python < 3.10.
_FF_UNION = '__ff_union__'


class _Pep604Transformer(ast.NodeTransformer):
    """Rewrite `A | B` annotations into `Union[A, B]` so PEP 604 unions evaluate on Python < 3.10."""

    def visit_BinOp(self, node: ast.BinOp) -> ast.AST:
        """Replace bit-or between annotation operands with a Union subscription."""
        self.generic_visit(node)
        if isinstance(node.op, ast.BitOr):
            args: ast.expr = ast.Tuple(elts=[node.left, node.right], ctx=ast.Load())
            if version_info < (3, 9):
                args = ast.Index(args)  # type: ignore[attr-defined]  # required slice wrapper on py 3.8
            return ast.copy_location(ast.Subscript(value=ast.Name(id=_FF_UNION, ctx=ast.Load()), slice=args, ctx=ast.Load()), node)
        return node


def _eval_type_str(value: str, globalns: Params | None, localns: Params | None) -> Any:
    """Evaluate an annotation string, back-porting PEP 585 (`list[str]`) and PEP 604 (`str | None`) to Python < 3.10."""
    namespace = dict(globalns) if globalns else {}
    namespace.update(PY38_TYPES)  # empty on >= 3.9; maps `list` -> `List` etc. on 3.8 for subscripted builtins
    namespace.setdefault(_FF_UNION, Union)
    try:
        return eval(value, namespace, localns)
    except TypeError:
        # `A | B` is unsupported for types on < 3.10 -> rewrite to `Union[A, B]` and retry.
        tree = _Pep604Transformer().visit(ast.parse(value, mode='eval'))
        ast.fix_missing_locations(tree)
        return eval(compile(tree, '<annotation>', 'eval'), namespace, localns)


if version_info >= (3, 11):
    from .types_optional import is_union, is_optional, remove_optional
else:

    def is_union(ann: TypeForm) -> bool:
        """Return True if type is Union."""
        origin = get_origin(ann)
        return origin is Union or origin is UnionType

    def is_optional(ann: TypeForm, *, deannotate: bool = False) -> bool:
        """Return True if `ann` is optional. Optional[X] is equivalent to Union[X, None]."""
        if deannotate:
            origin = get_origin(ann)
            if origin is Annotated and (args := get_args(ann)):
                ann = args[0]
        args = get_args(ann)
        # return is_union(ann) and len(args) == 2 and args[1] is type(None)
        return is_union(ann) and any(a is NoneType for a in args)

    def remove_optional(ann: TypeForm[T]) -> TypeForm[T]:
        """Remove Optional[X] (if exists) and returns X."""
        args = get_args(ann)
        # if is_union(ann) and len(args) == 2 and args[1] is type(None):
        if is_union(ann):
            if len(args) == 2 and args[1] is NoneType:
                return args[0]
            # old union
            return Union.__getitem__(tuple(a for a in args if a is not NoneType))  # type: ignore[attr-defined] # since py 3.10
            # return Union[*(a for a in args if a is not NoneType)]  # since py 3.11
        return ann


def is_union_none(ann: TypeForm) -> bool:
    """Return True if `ann` could be None. Union[None, ...] or Optional[X]."""
    args = get_args(ann)
    origin = get_origin(ann)
    return origin in (Union, UnionType) and any(a is type(None) or a is None for a in args)


if version_info >= (3, 10):
    from inspect import get_annotations
else:
    import types
    import functools

    def get_annotations(obj: Any, *, globals: Params | None = None, locals: Params | None = None, eval_str: bool = False) -> Params:
        """Compute the annotations dict for an object. See inspect.get_annotations() from py 3.13."""

        if isinstance(obj, type):
            # class
            obj_dict = getattr(obj, '__dict__', None)
            if obj_dict and hasattr(obj_dict, 'get'):
                ann = obj_dict.get('__annotations__', None)
                if isinstance(ann, types.GetSetDescriptorType):
                    ann = None
            else:
                ann = None

            obj_globals = None
            module_name = getattr(obj, '__module__', None)
            if module_name:
                module = sys.modules.get(module_name, None)
                if module:
                    obj_globals = getattr(module, '__dict__', None)
            obj_locals = dict(vars(obj))
            unwrap = obj
        elif isinstance(obj, types.ModuleType):
            # module
            ann = getattr(obj, '__annotations__', None)
            obj_globals = getattr(obj, '__dict__')
            obj_locals = None
            unwrap = None
        elif callable(obj):
            # this includes types.Function, types.BuiltinFunctionType,
            # types.BuiltinMethodType, functools.partial, functools.singledispatch,
            # "class funclike" from Lib/test/test_inspect... on and on it goes.
            ann = getattr(obj, '__annotations__', None)
            obj_globals = getattr(obj, '__globals__', None)
            obj_locals = None
            unwrap = obj
        else:
            raise TypeError(f"{obj!r} is not a module, class, or callable.")

        if ann is None:
            return {}

        if not isinstance(ann, dict):
            raise ValueError(f"{obj!r}.__annotations__ is neither a dict nor None")

        if not ann:
            return {}

        if not eval_str:
            return dict(ann)

        if unwrap is not None:
            while True:
                if hasattr(unwrap, '__wrapped__'):
                    unwrap = unwrap.__wrapped__  # type: ignore[attr-defined]
                    continue
                if isinstance(unwrap, functools.partial):
                    unwrap = unwrap.func
                    continue
                break
            if hasattr(unwrap, "__globals__"):
                obj_globals = unwrap.__globals__

        if globals is None:
            globals = obj_globals
        if locals is None:
            locals = obj_locals or {}

        # "Inject" type parameters into the local namespace
        # (unless they are shadowed by assignments *in* the local namespace),
        # as a way of emulating annotation scopes when calling `eval()`
        if type_params := getattr(obj, "__type_params__", ()):
            locals = {param.__name__: param for param in type_params} | locals

        return_value = {key:
                        value if not isinstance(value, str) else _eval_type_str(value, globals, locals)
                        for key, value in ann.items() }
        return return_value


def eval_annotations(ann: TypeForm | str, *, globalns: Params | None = None, localns: Params | None = None) -> TypeForm:
    """Evaluate a single annotation, resolving string forward references.

    :param ann: the annotation (a resolved type or a forward-ref string).
    :param globalns: global namespace for evaluation; defaults to typing_extensions' namespace.
    :param localns: local namespace (e.g. the owner module's ``__dict__``) needed to resolve
        module-local forward references (a class name defined next to the annotation).
    """
    import typing_extensions
    if globalns is None:
        globalns = typing_extensions.__dict__
    class X: pass
    X.__annotations__ = {'x': ann}
    return get_annotations(X, globals=globalns, locals=localns, eval_str=True)['x']


if version_info >= (3, 10):

    def get_type_hints(obj: Any, globalns: Params | None = None, localns: Params | None = None, *, include_extras: bool = False) -> Params:
        """Return resolved type hints for `obj`. On Python >= 3.10 PEP 585/604 evaluate natively."""
        return _te_get_type_hints(obj, globalns, localns, include_extras=include_extras)

else:

    def get_type_hints(obj: Any, globalns: Params | None = None, localns: Params | None = None, *, include_extras: bool = False) -> Params:
        """Return resolved type hints for `obj`, back-porting PEP 585 (`list[str]`) and PEP 604 (`str | None`) on Python < 3.10.

        Mirrors typing.get_type_hints(): string forward references are evaluated, base classes are merged for classes,
        and Annotated metadata is dropped unless `include_extras` is True. Evaluation goes through `_eval_type_str`,
        stripping and `include_extras` handling are delegated to typing_extensions on the already resolved types. A forward reference
        (`ForwardRef`: a TypedDict of typing_extensions keeps its string annotations so) is evaluated as its string.
        """
        resolved: dict[str, Any] = {}
        merged_ns: dict[str, Any] = {}
        if isinstance(obj, type):
            for base in reversed(obj.__mro__):
                base_ann = base.__dict__.get('__annotations__')
                if not base_ann:
                    continue
                base_globals = globalns if globalns is not None else getattr(sys.modules.get(base.__module__, None), '__dict__', {})
                base_locals = localns if localns is not None else dict(vars(base))
                merged_ns.update(base_globals)
                for name, value in base_ann.items():
                    if isinstance(value, ForwardRef):
                        value = value.__forward_arg__
                    resolved[name] = _eval_type_str(value, base_globals, base_locals) if isinstance(value, str) else value
        else:
            if globalns is None:
                globalns = getattr(obj, '__globals__', None)
                if globalns is None:
                    module = sys.modules.get(getattr(obj, '__module__', ''), None)
                    globalns = getattr(module, '__dict__', None) or getattr(obj, '__dict__', {})
            merged_ns.update(globalns)  # type: ignore[union-attr]
            for name, value in get_annotations(obj).items():
                if isinstance(value, ForwardRef):
                    value = value.__forward_arg__
                resolved[name] = _eval_type_str(value, globalns, localns) if isinstance(value, str) else value
        # Types are resolved now (no strings left); reuse typing_extensions for MRO-less strip / include_extras handling.
        holder = type('_TypeHintsHolder', (), {'__annotations__': resolved})
        return _te_get_type_hints(holder, merged_ns, localns, include_extras=include_extras)


if version_info < (3, 9):
    class ReferenceType(ReferenceType):  # type: ignore[no-redef]
        def __class_getitem__(cls, typ):
            return Annotated[typ, ReferenceType]


def is_literal(obj: object, cls: Type[T]) -> TypeIs[T]:
    """Return True if `obj` in in Literal type `cls`."""
    return obj in get_args(cls)


# @runtime_checkable
class DateTime(Protocol):
    """Simplified py datetime class."""

    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int
    microsecond: int

    @classmethod
    def today(cls) -> Self: ...

    @classmethod
    def now(cls, tz: timezone | None = None) -> Self: ...

    @classmethod
    def fromtimestamp(cls, timestamp: float, tz: tzinfo | None = None) -> Self: ...

    @classmethod
    def combine(cls, date: 'dt_date', time: 'dt_time', tzinfo: tzinfo | None = None) -> Self: ...

    def isoformat(self) -> str: ...

    def date(self) -> dt_date: ...

    def time(self) -> dt_time: ...


def sequence_cast(seq: SequenceProto[T_co], /) -> Sequence[T_co]:
    """Cast SequenceProto to Sequence. Only for type checking, at runtime returns the same object."""
    return seq  # type: ignore[return-value]


class SequenceProto(Protocol[T_co]):
    """Structural protocol equivalent to Sequence — for duck-typed inputs."""

    @overload
    def __getitem__(self, index: int, /) -> T_co: ...
    @overload
    def __getitem__(self, index: slice, /) -> Sequence[T_co]: ...

    def __len__(self) -> int: ...
    def __contains__(self, x: object, /) -> bool: ...
    def __iter__(self) -> Iterator[T_co]: ...
    def __reversed__(self) -> Iterator[T_co]: ...
    def index(self, value: Any, start: int = ..., stop: int = ..., /) -> int: ...
    def count(self, value: Any, /) -> int: ...


class PagedItems(SequenceProto[T_co], Protocol[T_co]):
    """Protocol for a paged sequence — extends SequenceProto with pagination metadata."""

    @property
    def page(self) -> int: ...
    @property
    def page_size(self) -> int: ...
    @property
    def total_pages(self) -> int: ...
    @property
    def total_results(self) -> int: ...
    def next_page(self) -> int | None: ...


if version_info >= (3, 11):
    from enum import StrEnum  # type: ignore[import]
else:
    from enum import Enum
    class StrEnum(str, Enum):
        """Enum where members are also (and must be) strings."""

        def __new__(cls, *values):
            "values must already be of type `str`"
            if len(values) > 3:
                raise TypeError('too many arguments for str(): %r' % (values, ))
            if len(values) == 1:
                # it must be a string
                if not isinstance(values[0], str):
                    raise TypeError('%r is not a string' % (values[0], ))
            if len(values) >= 2:
                # check that encoding argument is a string
                if not isinstance(values[1], str):
                    raise TypeError('encoding must be a string, not %r' % (values[1], ))
            if len(values) == 3:
                # check that errors argument is a string
                if not isinstance(values[2], str):
                    raise TypeError('errors must be a string, not %r' % (values[2]))
            value = str(*values)
            member = str.__new__(cls, value)
            member._value_ = value
            return member

        @staticmethod
        def _generate_next_value_(name, start, count, last_values):
            """Return the lower-cased version of the member name."""
            return name.lower()


# --- argument descriptions ---


def ann_type(ann: Annotated, cls: TypeForm[T] = None) -> tuple[TypeForm[T], AnnMeta]:
    """Check and return type and annotated details (meta)."""
    ann = remove_optional(ann)
    origin = get_origin(ann)
    if origin is not Annotated:
        return ann, ()
    args = get_args(ann)
    typ, meta = args[0], args[1:]
    if cls is None or cls in meta:
        return typ, meta
    return typ, ()


class _Unsigned:
    """Unsigned[int] argument pseudo-type for annotations."""


class _Positive:
    """Positive[int] argument pseudo-type for annotations."""


Unsigned: TypeAlias = Annotated[T, _Unsigned]
Positive: TypeAlias = Annotated[T, _Positive]


def mk_none(v: str) -> None:
    """Make bool."""
    if v:
        raise ValueError(f'Non-empty none {v!r}')
    return None


def mk_bool(v: str) -> bool:
    """Make bool."""
    if isinstance(v, str):
        v = v.lower()
        if v in TRUE_VALUES:
            return True
        if v in FALSE_VALUES:
            return False
        raise ValueError(f'Unknown bool format {v!r}')
    return bool(v)


def uint(v: str) -> int:
    """Make unsigned int."""
    val = int(v)
    if val < 0:
        raise ValueError(f'Negative uint {v!r}')
    return val


def pint(v: str) -> int:
    """Make positive int."""
    val = int(v)
    if val <= 0:
        raise ValueError(f'Non-positive int {v!r}')
    return val


def ufloat(v: str) -> float:
    """Make unsigned float."""
    val = float(v)
    if val < 0:
        raise ValueError(f'Negative ufloat {v!r}')
    return val


def mk_path(v: str) -> Path:
    """Make Path()."""
    if v.startswith('./'):
        return Path(v[2:])
    if not v.startswith('/'):
        v = f'/{v}'
    return Path(v)


def mk_upath(v: str) -> UPath:
    """Make Path()."""
    if v.startswith('./'):
        return UPath(v[2:])
    if not v.startswith('/'):
        v = f'/{v}'
    return UPath(v)


@frozen
class EnumDumper:
    transform: Callable[[Any], Any] = str
    attr: Literal['enum', 'fullname', 'name', 'value'] = 'name'  # name or value

    def __repr__(self) -> str:
        return f'EnumDumper({self.transform.__qualname__}, {self.attr!r})'


# EnumFullName: TypeAlias = Annotated[E, EnumDumper(lambda e: str(e).lower(), 'enum')]
EnumEnum: TypeAlias = Annotated[E, EnumDumper(format, 'enum')]
EnumFullName: TypeAlias = Annotated[E, EnumDumper(str, 'fullname')]
EnumName: TypeAlias = Annotated[E, EnumDumper(str.lower)]
EnumValue: TypeAlias = Annotated[E, EnumDumper(str, 'value')]


@frozen
class ArgDescr:
    """Type conversion  description."""
    #: Argument type.
    type: ArgType = str
    #: Regex pattern to argument parse.
    pattern: Union[str, Callable[[TypeForm[Any], AnnMeta], str]] = r'.*'
    #: If True, regex is passed to `type`. If False, the string value.  TODO: check if is used.
    rx: bool = field(default=False, kw_only=True)
    #: Dump value to url argument.
    dumper: Callable[[Any, AnnMeta], str] | None = field(default=None, kw_only=True)
    #: Load value from url argument.
    loader: Callable[[str, TypeForm[Any], AnnMeta], Any] | None = field(default=None, kw_only=True)

    def pat(self, cls: TypeForm[Any], meta: AnnMeta = ()) -> str:
        if callable(self.pattern):
            return self.pattern(cls, meta)
        return self.pattern

    def dump(self, val: Any, cls: TypeForm, meta: AnnMeta = ()) -> str:
        if self.dumper:
            return self.dumper(val, meta)
        if val is None:
            return ''
        if isinstance(val, bool):
            return 'true' if val else 'false'
        if isinstance(val, (Path, UPath)):
            from .tricks import str_removeprefix
            return str_removeprefix(str(val), '/')
        if isinstance(val, SplitResult):
            from .tricks import str_removeprefix
            return str_removeprefix(urlunsplit(val), '/')
        # if isinstance(val, SafeUrl):
        #     return quote_plus(val)
        # if isinstance(val, tuple):
        #     return ','.join(self.dump(v) for v in val)
        return f'{val}'

    @staticmethod
    def _prepare(typ: TypeForm[T], meta: AnnMeta | None) -> tuple[TypeForm[T], AnnMeta]:
        # The result depends on arguments only and it is called for every loaded value (e.g. every DB column
        # of every row), typing introspection is slow, so keep results.
        try:
            return _prepared_types[typ, meta]
        except KeyError:
            hashable = True
        except TypeError:
            hashable = False  # e.g. meta as a list
        key = (typ, meta)
        typ = remove_optional(typ)
        if meta is None:
            meta = ()
        if get_origin(typ) is Annotated:
            args = get_args(typ)
            typ = remove_optional(args[0])
            meta = (*args[1:], *meta)
        if hashable:
            _prepared_types[key] = typ, meta
        return typ, meta

    def load(self, val: str, cls: TypeForm, meta: AnnMeta | None = None) -> Any:
        cls, meta = self._prepare(cls, meta)
        if self.loader:
            return self.loader(val, cls, meta)
        if cls is None or cls is NoneType:
            return mk_none(val)
        if callable(self.type):
            return self.type(val)
        return str(val)


#: Cache of ArgDescr._prepare().
_prepared_types: dict[tuple[Any, Any], tuple[Any, Any]] = {}


@frozen
class LiteralArg(ArgDescr):

    def pat(self, cls: TypeForm[Any], meta: AnnMeta = ()) -> str:
        """Return regex pattern for literal."""
        def literal_to_rx(val) -> str:
            if val is None:
                return ''  # TODO: Add Literal[None] support
            if val is True:
                return 'true|1'
            if val is False:
                return 'false|0'
            typ = type(val)
            if typ is int or typ is float:
                val = str(val)
            if issubclass(typ, Enum):
                at, _ = find_arg_descr(typ)
                if at:
                    return at.pat(typ, meta)
            return re.escape(str(val))
        cls, meta = self._prepare(cls, meta)
        type_args = get_args(cls)
        if type_args:
            apat = '|'.join(literal_to_rx(a) for a in type_args)
            return f'(?:{apat})'
        return ANN_TYPES[str].pat(cls, meta)

    def dump(self, val: Any, cls: TypeForm, meta: AnnMeta = ()) -> str:
        if isinstance(val, Enum):
            at, _ = find_arg_descr(type(val))
            if at:
                return at.dump(val, cls, meta)
        return super().dump(val, cls, meta)

    def load(self, val: str, cls: TypeForm, meta: AnnMeta | None = None) -> Any:
        cls, meta = self._prepare(cls, meta)
        if get_origin(cls) is Literal:
            aargs = get_args(cls)
            # TODO: Add Literal[Enum] support
            for a in aargs:
                if a is None and val == '':
                    return None
                if a is True and val in ('true', '1'):  # simplified values
                    return True
                if a is False and val in ('false', '0'):  # simplified values
                    return False
                if isinstance(a, Enum):
                    at, _ = find_arg_descr(type(a))
                    if at:
                        return at.load(val, type(a), meta)
                if val == str(a):
                    return type(a)(val)
        raise ValueError(f'Value {val!r} does NOT match to literal {cls}')


@frozen
class EnumArg(ArgDescr):

    default: EnumDumper = field(kw_only=True)

    EMPTY_FLAG_FORMAT = '{value.__class__.__name__}(0)'
    # EMPTY_FLAG_FORMAT = '{value.__class__.__name__}.0'

    def _get_ed(self, meta: AnnMeta) -> EnumDumper:
        return next(iter(mt for mt in meta if isinstance(mt, EnumDumper)), self.default)

    def pat(self, cls: TypeForm[Enum], meta: AnnMeta = ()) -> str:
        cls, meta = self._prepare(cls, meta)
        if not isinstance(cls, type):
            return super().pat(cls, meta)
        ed = self._get_ed(meta)
        if issubclass(cls, IntFlag) and ed.attr == 'value':
            return r'\d+'
        if ed.attr in ('enum', 'fullname'):
            pat = ''
        else:
            pat = '|'.join(ed.transform(str(v)) for e in cls.__members__.values() if (v := getattr(e, ed.attr)) is not None)
        if issubclass(cls, Flag):
            # class name and Flag names and values are save, omit re.escape()
            av = '|'.join(e.name for e in cls.__members__.values() if e.name)
            epat = fr'{cls.__name__}\.(?:{av})(?:\|(?:{av}))*'
            if issubclass(cls, IntFlag):
                pat = fr'{pat}|\d+' if pat else r'\d+'
            if pat:
                pat = fr'(?:{pat})(?:,(?:{pat}))*|{epat}'
            else:
                pat = epat
            if ed.attr == 'value':
                pat = fr'{pat}|\d+'
        return f'(?:{pat})'

    def dump(self, val: Any, cls: TypeForm, meta: AnnMeta = ()) -> str:
        def bits(val: Flag) -> Sequence[str]:
            if version_info >= (3, 10):
                flags = sorted(type(val).__members__.values(), key=lambda e: e.value.bit_count(), reverse=True)
            else:
                flags = sorted(type(val).__members__.values(), key=lambda e: bin(e.value).count('1'), reverse=True)
            mask = val.value
            hit = []
            for e in flags:
                v = e.value
                if v & mask == v:
                    hit.append(e)
                    mask &= ~v
                if not mask:
                    break
            names = sorted(str(ed.transform(e.name)) for e in hit)
            if isinstance(val, IntFlag) and mask:
                names.append(str(mask))
            return names

        if not isinstance(val, Enum):
            # raise TypeError(type(val))
            return super().dump(val, cls, meta)
        ed = self._get_ed(meta)
        if ed.attr == 'fullname':
            if isinstance(val, Flag):
                if not val:
                    return self.EMPTY_FLAG_FORMAT.format(value=val)
                vals = '|'.join(bits(val))
                return f'{val.__class__.__name__}.{vals}'
            return f'{val.__class__.__name__}.{ed.transform(val.name)}'
        if ed.attr == 'enum':
            if not val and isinstance(val, Flag):
                return self.EMPTY_FLAG_FORMAT.format(value=val)
            if version_info < (3, 11) and isinstance(val, Flag) and not isinstance(val, IntFlag):
                if val.name is not None:
                    return ed.transform(f'{val.__class__.__name__}.{val.name}')
                bb = []
                for e in val.__class__:
                    if e & val and bin(e.value).count('1') == 1:
                        bb += [ed.transform(e.name)]
                result = '|'.join(bb)
                result = f'{val.__class__.__name__}.{result}'
            else:
                result = str(ed.transform(val))
            return result
        if (x := getattr(val, ed.attr)) is not None and (ed.attr != 'name' or '|' not in x):
            return str(ed.transform(x))
        if ed.attr == 'name' and isinstance(val, Flag):
            if not val:
                return ''
            return ','.join(bits(val))
        return super().dump(val, cls, meta)

    def load(self, val: str, cls: TypeForm, meta: AnnMeta | None = None) -> Any:
        cls, meta = self._prepare(cls, meta)
        ed = self._get_ed(meta)
        if isinstance(cls, type) and issubclass(cls, Enum):
            # Flags with `|` or `,` has more flags, there is no sense to compare with defined value
            if ('|' not in val and ',' not in val) or not issubclass(cls, Flag):
                if not val and ed.attr == 'name':
                    return cls(0)
                if val == '0' or ('0' in val and (val == f'{cls.__name__}.0' or val == f'{cls.__name__}(0)')):
                    return cls(0)
                for e in cls.__members__.values():
                    if ed.attr == 'enum':
                        if val == str(ed.transform(e)):
                            return e
                    elif ed.attr == 'fullname':
                        if val == f'{cls.__name__}.{ed.transform(e.name)}':
                            return e
                    elif val == str(ed.transform(getattr(e, ed.attr))):
                        return e
                for e in cls.__members__.values():
                    if val == str(e.value):
                        return e
            if issubclass(cls, Flag):
                def flag_to_int(val: str, flg: str) -> int:
                    if val.isdecimal():
                        return int(val)
                    for e in cls.__members__.values():
                        if ed.attr == 'enum':
                            tr = e
                        elif ed.attr == 'fullname':
                            tr = f'{cls.__name__}.{e.name}'
                        else:
                            tr = getattr(e, ed.attr)
                        if str(ed.transform(tr)) == flg:
                            return e.value
                    return 0
                if val.isdecimal():
                    return cls(int(val))
                # int_flag = issubclass(cls, IntFlag):
                if ',' in val:
                    return cls(reduce(or_, (flag_to_int(s, s) for s in val.split(','))))
                elif '|' in val and '.' in val and ed.attr in ('enum', 'fullname'):
                # elif '.' in val and ed.attr == 'enum':
                    return cls(reduce(or_, (flag_to_int(s, f'{cls.__name__}.{s}') for s in val.partition('.')[2].split('|'))))

        raise ValueError(f'Value {val!r} does NOT match to enum/flag {cls}')


none_arg = ArgDescr(mk_none, r'(?:)')

#: Annotated typed, used on path (see _RE_PATH_ARG) and with PathArg[...].
ANN_TYPES: dict[TypeForm[Any], ArgDescr] = {
    Literal:             LiteralArg(),
    Enum:                EnumArg(Enum,            default=EnumDumper(str.lower, 'name')),
    IntEnum:             EnumArg(IntEnum,         default=EnumDumper(str, 'value')),
    StrEnum:             EnumArg(StrEnum,         default=EnumDumper(str, 'value')),
    Flag:                EnumArg(Flag,            default=EnumDumper(str.lower, 'name')),
    IntFlag:             EnumArg(IntFlag,         default=EnumDumper(str, 'value')),
    str:                 ArgDescr(str,            r'[^/]+'),
    UPath:               ArgDescr(mk_upath,       r'.+'),
    Path:                ArgDescr(mk_path,        r'.+'),
    # SafeUrl:             ArgDescr(mk_safe_url,    r'[^/]+'),
    int:                 ArgDescr(int,            r'[+-]?\d+'),
    Unsigned[int]:       ArgDescr(uint,           r'\d+'),
    Positive[int]:       ArgDescr(pint,           r'[1-9]\d*'),
    Positive:            ArgDescr(pint,           r'[1-9]\d*'),
    float:               ArgDescr(float,          r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(:?[eE][+-]?\d+)?'),
    Unsigned[float]:     ArgDescr(float,          r'(?:\d+(?:\.\d*)?|\.\d+)(:?[eE][+-]?\d+)?'),
    bool:                ArgDescr(mk_bool,        r'true|false|0|1'),
    # None:                none_arg,
    Any:                 ArgDescr(),
}


def find_arg_descr(ann: TypeForm,
                   *,
                   meta: AnnMeta = (),
                   annotations: dict[TypeForm[Any], ArgDescr] = ANN_TYPES,
                   quiet: bool = False,
                   ) -> tuple[ArgDescr | None, AnnMeta]:
    """Find description type."""
    if at := annotations.get(ann):
        return at, meta
    # Strip Optional/None first, before Annotated and Union handling (so `Annotated[T] | None` and `T | X | None` resolve).
    ann = remove_optional(ann)
    if at := annotations.get(ann):
        return at, meta
    otype = get_origin(ann)
    if otype is Annotated:
        typ, *more = get_args(ann)
        meta = (*more, *meta)  # merge annotated meta with caller meta (do not overwrite)
        typ = remove_optional(typ)
        if at := annotations.get(typ):
            return at, meta
        otype = get_origin(typ)
    else:
        typ = ann
    if at := annotations.get(otype):  # type: ignore[reportArgumentType]
        return at, meta
    if otype is Union or otype is UnionType:
        # Real multi-member union (None already removed): take the first matching member.
        for sub in get_args(typ):
            if sub is NoneType:
                continue
            at, sub_meta = find_arg_descr(sub, meta=meta, annotations=annotations, quiet=True)
            if at:
                return at, sub_meta
    for base_type in getattr(typ, '__mro__', (typ,)):
        if at := annotations.get(base_type):
            return at, meta
    from .log import fflog
    if not quiet:
        fflog.error(f'Unsupported argument type: {ann!r}')
    return None, meta
    # return ArgDescr(), meta


def flag_names(flag: Flag) -> str:
    """"Dump flag to comma-separated list of flag names."""
    return ANN_TYPES[Flag].dump(flag, Flag)
