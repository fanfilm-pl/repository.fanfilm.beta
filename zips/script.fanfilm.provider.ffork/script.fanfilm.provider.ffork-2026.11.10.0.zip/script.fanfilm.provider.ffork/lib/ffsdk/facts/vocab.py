"""
Closed vocabularies of the source facts: every value is a formal name (the JSON value, the filter value) with the
aliases it is written as in file names and texts of the providers.

An alias is plain text: a space, dot, dash or underscore in it means an optional separator (`h 264` is `h264`,
`h.264`, `H-264`), other characters are literal. A text out of a vocabulary is not a value (unknown, not an error).
The labels shown to the user are not here (the host translates them).
"""

from __future__ import annotations
import re
from enum import Enum
from functools import lru_cache
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from typing_extensions import Self


#: Separators of the chunks of an alias (optional in a text).
SEPARATORS = r'[ ._-]'


def alias_key(text: str) -> str:
    """Return the lookup key of an alias or a matched text (lower case, no separators)."""
    return re.sub(SEPARATORS, '', text.lower())


def alias_pattern(alias: str) -> str:
    """Return the regular expression of an alias: its chunks with optional separators between them."""
    return f'{SEPARATORS}?'.join(re.escape(chunk) for chunk in re.split(f'{SEPARATORS}+', alias.lower()))


class Term(str, Enum):
    """A value of a closed vocabulary: the formal name and the aliases (`NAME = 'value', 'alias', ...`)."""

    #: Aliases of the value (as written in texts).
    aliases: tuple[str, ...]

    def __new__(cls, value: str, *aliases: str) -> Self:
        """Create a value with its aliases."""
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.aliases = aliases
        return obj

    def __str__(self) -> str:
        """Return the formal name (`str()` of a mixed-in enum would be its class and member name)."""
        return self.value

    @classmethod
    def find(cls, text: str) -> Self | None:
        """Return the value of an alias text (any case and separators), None if the text is out of the vocabulary."""
        return _alias_map(cls).get(alias_key(text))

    @classmethod
    def pattern(cls, *, min_length: int = 0, max_length: int = 99) -> str:
        """Return the regular expression of the aliases (the longest first: `web dl` before `web`), of a key length in the range."""
        return _alias_pattern(cls, min_length, max_length)


@lru_cache(maxsize=None)
def _alias_map(cls: type[Term]) -> dict[str, Term]:
    """Return the lookup map of the vocabulary: alias key (and the formal name) -> value."""
    return {alias_key(text): member for member in cls for text in (member.value, *member.aliases)}


@lru_cache(maxsize=None)
def _alias_pattern(cls: type[Term], min_length: int, max_length: int) -> str:
    """Return the regular expression of the aliases of the vocabulary of a key length in the range (the longest first)."""
    aliases = sorted({alias for member in cls for alias in member.aliases if min_length <= len(alias_key(alias)) <= max_length},
                     key=lambda alias: len(alias_key(alias)), reverse=True)
    return '|'.join(alias_pattern(alias) for alias in aliases)


class VideoCodec(Term):
    """Video codec (the names of ffmpeg)."""

    H264 = 'h264', 'h 264', 'x264', 'avc'
    HEVC = 'hevc', 'h 265', 'x265', 'hevc'
    AV1 = 'av1', 'av1'
    VP9 = 'vp9', 'vp9'
    MPEG4 = 'mpeg4', 'mpeg 4', 'xvid', 'divx'
    MPEG2 = 'mpeg2', 'mpeg 2'
    VC1 = 'vc1', 'vc 1'


class Hdr(Term):
    """High dynamic range format (`hdr`: HDR of an unknown format)."""

    HDR = 'hdr', 'hdr'
    HDR10 = 'hdr10', 'hdr10'
    HDR10_PLUS = 'hdr10plus', 'hdr10 plus', 'hdr10+', 'hdr+'
    DOLBY_VISION = 'dolby_vision', 'dolby vision', 'dovi', 'dv'
    HLG = 'hlg', 'hlg'


class AudioCodec(Term):
    """Audio codec (the names of ffmpeg, DTS profiles separately)."""

    AAC = 'aac', 'aac', 'he aac'
    AC3 = 'ac3', 'ac 3', 'dd', 'dolby digital'
    EAC3 = 'eac3', 'e ac 3', 'eac 3', 'ddp', 'ddpa', 'dd+', 'dolby digital plus'
    TRUEHD = 'truehd', 'true hd'
    DTS = 'dts', 'dts'
    DTS_ES = 'dts_es', 'dts es'
    DTS_HD = 'dts_hd', 'dts hd', 'dts hd hra'
    DTS_HD_MA = 'dts_hd_ma', 'dts hd ma', 'dts ma'
    DTS_X = 'dts_x', 'dts x', 'dts:x'
    FLAC = 'flac', 'flac'
    LPCM = 'lpcm', 'lpcm', 'pcm'
    MP3 = 'mp3', 'mp3'
    OPUS = 'opus', 'opus'


class TrackKind(Term):
    """How an audio track gives its language: the original, a dubbing, a voice-over (Polish lektor), an audio description."""

    ORIGINAL = 'original'
    DUBBING = 'dubbing'
    LEKTOR = 'lektor'
    AUDIO_DESCRIPTION = 'audio_description'


class AudioRecording(Term):
    """How the audio of a cinema copy was recorded: a microphone in the hall (MD), the line of the cinema (LD)."""

    MIC = 'mic', 'md', 'mic dub', 'mic dubbed'
    LINE = 'line', 'ld', 'line dub', 'line dubbed', 'line audio'


class SubtitleKind(Term):
    """Subtitle track kind: full, forced (only foreign parts), SDH (for the deaf and hard of hearing)."""

    FULL = 'full'
    FORCED = 'forced', 'forced'
    SDH = 'sdh', 'sdh'


class ReleaseSource(Term):
    """The source of a release."""

    CAM = 'cam', 'cam', 'camrip', 'cam rip', 'hdcam', 'hd cam', 'cam hd', 'hqcam', 's print', 'kino'
    TELESYNC = 'telesync', 'telesync', 'telesynch', 'ts', 'hdts', 'hd ts', 'tsrip', 'ts rip', 'hdtsrip', 'ts screener'
    TELECINE = 'telecine', 'telecine', 'tc', 'hdtc', 'tcrip', 'hdtcrip'
    SCREENER = ('screener', 'screener', 'scr', 'dvdscr', 'dvd scr', 'dvd screener', 'bdscr', 'br screener', 'bd screener', 'r5',
                'predvd', 'pre dvd', 'pdvd', 'pdvdrip')
    PPV = 'ppv', 'ppv', 'ppvrip', 'ppv rip'
    TV = 'tv', 'hdtv', 'pdtv', 'tvrip', 'tv rip', 'hdtvrip', 'satrip', 'sat rip', 'dsr', 'dsrip', 'dvb', 'dvbrip', 'dvb rip'
    DVD = 'dvd', 'dvd', 'dvdr'
    VHS = 'vhs', 'vhs', 'vhsrip'
    DVDRIP = 'dvdrip', 'dvdrip', 'dvd rip', 'hd dvd rip', 'hq dvd rip'
    HDRIP = 'hdrip', 'hdrip', 'hd rip'
    WEB = 'web', 'web'
    WEBDL = 'webdl', 'web dl', 'web dlrip'
    WEBRIP = 'webrip', 'web rip'
    BDRIP = 'bdrip', 'bdrip', 'bd', 'bd rip', 'brrip', 'br rip', 'blu ray rip', 'bluray rip', 'uhdrip', 'uhd rip'
    BLURAY = 'bluray', 'blu ray', 'bd25', 'bd50', 'bd66', 'bd100', 'bdmv', 'uhd bluray', 'uhd blu ray'


class Edition(Term):
    """An edition of a release."""

    EXTENDED = 'extended', 'extended', 'extended cut', 'extended edition', 'wersja rozszerzona'
    DIRECTORS_CUT = 'directors_cut', 'directors cut', "director's cut", 'dir cut', 'wersja reżyserska', 'wersja rezyserska'
    THEATRICAL = 'theatrical', 'theatrical', 'theatrical cut'
    UNCUT = 'uncut', 'uncut'
    UNRATED = 'unrated', 'unrated', 'uncensored'
    REMASTERED = 'remastered', 'remastered', 'remaster'
    RESTORED = 'restored', 'restored', 'rekonstrukcja', 'rekonstrukcja cyfrowa'
    IMAX = 'imax', 'imax'
    CRITERION = 'criterion', 'criterion'


class Container(Term):
    """The container of a file (from its extension)."""

    MKV = 'mkv', 'mkv'
    MP4 = 'mp4', 'mp4', 'm4v'
    AVI = 'avi', 'avi'
    TS = 'ts', 'ts', 'm2ts', 'mts'
    MPG = 'mpg', 'mpg', 'mpeg', 'vob'
    WMV = 'wmv', 'wmv'
    MOV = 'mov', 'mov'
    WEBM = 'webm', 'webm'
    FLV = 'flv', 'flv'


class Lang(Term):
    """A language (ISO 639-1 code) with its codes (two-letter: also of a country) and names."""

    PL = 'pl', 'pl', 'polish', 'polski', 'pol'
    EN = 'en', 'en', 'english', 'eng', 'ingles', 'inglés', 'inglês', 'englis'
    DE = 'de', 'de', 'german', 'deutsch', 'ger', 'deu'
    FR = 'fr', 'fr', 'french', 'truefrench', 'francais', 'français', 'fre', 'fra', 'vff', 'vfi', 'vfq'
    ES = 'es', 'es', 'spanish', 'espanol', 'español', 'española', 'castellano', 'latino', 'spa', 'esp', 'lat'
    IT = 'it', 'it', 'italian', 'italiano', 'ita'
    PT = 'pt', 'pt', 'br', 'portuguese', 'portugues', 'português', 'portuguesa', 'por', 'pt br', 'port br'
    RU = 'ru', 'ru', 'russian', 'rus'
    UK = 'uk', 'ua', 'ukrainian', 'ukr'
    CS = 'cs', 'cs', 'cz', 'czech', 'cze', 'ces'
    SK = 'sk', 'slovak', 'slovakian'
    HU = 'hu', 'hu', 'hungarian', 'hun'
    NL = 'nl', 'nl', 'dutch', 'flemish', 'nld', 'dut'
    SV = 'sv', 'sv', 'se', 'swedish', 'svensk', 'swe'
    DA = 'da', 'dk', 'danish', 'danska', 'dansk'
    NO = 'no', 'norwegian', 'norsk'
    FI = 'fi', 'finnish', 'finsk'
    JA = 'ja', 'jp', 'japanese', 'jpn'
    KO = 'ko', 'kr', 'korean', 'kor'
    ZH = 'zh', 'cn', 'chinese', 'mandarin', 'cantonese'
    HI = 'hi', 'hi', 'hindi', 'hin'
    TA = 'ta', 'tamil'
    TE = 'te', 'telugu'
    AR = 'ar', 'arabic', 'ara'
    TR = 'tr', 'turkish', 'tur'
    EL = 'el', 'gr', 'greek'
    HE = 'he', 'hebrew'
    RO = 'ro', 'romanian'
    TH = 'th', 'thai'
    VI = 'vi', 'vietnamese'
    ID = 'id', 'indonesian'
    MS = 'ms', 'malay'
    LT = 'lt', 'lithuanian'
    HR = 'hr', 'croatian'
    SR = 'sr', 'serbian'
    BG = 'bg', 'bulgarian'


#: Polish release groups and uploaders (case sensitive, as they write it): their releases are Polish.
POLISH_GROUPS: tuple[str, ...] = (
    '4TL', 'A4O', 'ABM', 'AdL', 'AFO', 'AL3X', 'alE13', 'Alusia', 'AMOK', 'ANONiM', 'APPGRoup', 'AS76', 'azjatycki', 'AZQ', 'B2RPL',
    'B89', 'BEBLU', 'BiDA', 'BIGBBS', 'BiRD', 'blake', 'BODZiO', 'BP007', 'BRX', 'BRY', 'CAMBiO', 'CHOPiN', 'ChrisVPS', 'CiNEMAET',
    'CinemaPolish', 'CODER', 'CoLO', 'CRU', 'CX', 'CZRG', 'd11', 'd666', 'DarK', 'DeiX', 'DEMAND', 'DENDA', 'devil-bad', 'dok.torrek',
    'DReaM', 'DSiTE', 'DVDSEED', 'DYZIO', 'DZiDEK', 'eend', 'elladajarek', 'EMiS', 'EnTeR1973', 'Esperanza', 'ETeam', 'FARNA', 'Feld',
    'FileTracker', 'FLAME', 'Flipu', 'FOX', 'FPL', 'FT', 'Gamer158', 'GameToonHD', 'GarRipzone', 'GhN', 'GHW', 'GLiMMER', 'GR4PE',
    'GUN', 'H3Q', 'HDBEE', 'HEN', 'HMDb', 'HT', 'inTGrity', 'Izyk', 'J25', 'J60', 'Japhson', 'JASKIER', 'joanna668', 'K041', 'K12',
    'K37', 'K8', 'K83', 'Kamil11124', 'kamil445', 'Kbuso', 'KDE', 'KIFR', 'KiKO', 'KilKr', 'KiT', 'KLiO', 'KPFR', 'KRT', 'KSQ', 'LEX',
    'LiMiT', 'LLA', 'LLO', 'LTN', 'LTS', 'lufen', 'Lysol1', 'M56', 'M80', 'maksim80', 'marjos83', 'MAXiM', 'MAXX', 'MiNS', 'Mixio',
    'MK', 'MORS', 'MR', 'MR1', 'N0B0DY', 'N0L4', 'NINE', 'NitroTeam', 'NN', 'NoNaNo', 'NoQ', 'ODiSON', 'OldT', 'OXYGEN', 'OzW',
    'pasha', 'pcela', 'PdlG', 'PIO', 'PiratesZone', 'PIXELPOLICE', 'PIXI', 'PLHD', 'potroks', 'presa', 'ProPLTV', 'PSiG', 'PSOTNIK',
    'PTRG', 'PTTrG', 'R22', 'R2D2', 'R68', 'Ralf', 'raven', 'RAVoD', 'Retro-Ekipa', 'RobSil', 'RX', 'S56', 'sav', 'SK13', 'SLH', 'SLiM',
    'SnOoP', 'spajk85', 'Spedboy', 'Speedboy', 'StarLord', 'StarLordX', 'sy5ka', 'SYRIX', 'SZAFQU', 'taboon1', 'tamir', 'TFSH',
    'TiTaNiUM', 'tokar86a', 'ToP2P', 'TV4TG', 'vase', 'wasik', 'WEB4TG', 'WiZARDS', 'wosiu', 'wzrtyk', 'xmatr1x', 'XTE', 'XuploaD',
    'Zet', 'ZLOCiUTKi', 'ZT', 'zyl', 'zyvela',
)
