"""
Facts of a source (video, audio and subtitle tracks, the release) from its file name or texts, in closed vocabularies.

    from sdk.facts import parse
    parse('Movie.2020.PLDUB.1080p.WEB-DL.DDP5.1.Atmos.H.265-GRP.mkv')
    # {'video': {'height': 1080, 'codec': 'hevc'}, 'release': {'source': 'webdl', 'container': 'mkv'},
    #  'audio': [{'lang': 'pl', 'kind': 'dubbing', 'codec': 'eac3', 'channels': '5.1', 'atmos': True}]}
"""

from .parse import parse, complete
from .types import Facts, VideoFacts, AudioTrack, SubtitleTrack, ReleaseFacts
from .vocab import Term, VideoCodec, Hdr, AudioCodec, TrackKind, AudioRecording, SubtitleKind, ReleaseSource, Edition, Container, Lang

__all__ = [
    'parse', 'complete',
    'Facts', 'VideoFacts', 'AudioTrack', 'SubtitleTrack', 'ReleaseFacts',
    'Term', 'VideoCodec', 'Hdr', 'AudioCodec', 'TrackKind', 'AudioRecording', 'SubtitleKind', 'ReleaseSource', 'Edition', 'Container', 'Lang',
]
