"""
The source facts: JSON data in groups. A missing key is unknown, never "no" (99% of sources say nothing).

Values of the vocabularies (`vocab`) are `str` enums: in JSON they are their formal names.
"""

from __future__ import annotations
from typing_extensions import TypedDict
from .vocab import VideoCodec, Hdr, AudioCodec, TrackKind, AudioRecording, SubtitleKind, ReleaseSource, Edition, Container


class VideoFacts(TypedDict, total=False):
    """The video stream."""

    #: The codec.
    codec: VideoCodec
    #: HDR formats (a file can have more, e.g. DV with an HDR10 fallback).
    hdr: list[Hdr]
    #: Bits per color (8, 10, 12).
    bit_depth: int
    #: Stereoscopic 3D.
    three_d: bool
    #: Frame height in pixels (2160, 1080, 720...).
    height: int
    #: Frames per second.
    fps: int
    #: A sign language interpreter in the picture (PJM).
    sign_language: bool
    #: Colorized (a black and white film).
    colorized: bool
    #: Processed by AI (colorized, upscaled).
    ai: bool


class AudioTrack(TypedDict, total=False):
    """
    An audio track. `lang` None: a track of an unknown language is signaled (MULTI: more languages, not listed);
    no `lang` key: the text says nothing about the language of the track (e.g. only its codec).
    """

    #: Language (ISO 639-1).
    lang: str | None
    #: How the language is given.
    kind: TrackKind
    #: The codec.
    codec: AudioCodec
    #: Channels: '2.0', '5.1', '7.1'...
    channels: str
    #: Dolby Atmos.
    atmos: bool
    #: Recorded in a cinema (a microphone, the line).
    recording: AudioRecording
    #: Synthesized (AI voice-over / dubbing); None: unknown.
    ai: bool | None


class SubtitleTrack(TypedDict, total=False):
    """A subtitle track. `lang` None: subtitles of an unknown language (or languages)."""

    #: Language (ISO 639-1).
    lang: str | None
    #: The kind.
    kind: SubtitleKind
    #: Burned into the picture (hardcoded).
    burned: bool
    #: Machine-made (AI); None: unknown.
    ai: bool | None


class ReleaseFacts(TypedDict, total=False):
    """The release."""

    #: The source.
    source: ReleaseSource
    #: A remux (the streams of the disc, not re-encoded).
    remux: bool
    #: Editions.
    edition: list[Edition]
    #: The container (the file extension).
    container: Container
    #: A fixed re-release (PROPER).
    proper: bool
    #: A re-release of the same group (REPACK).
    repack: bool
    #: Protected by DRM (needs a DRM module, e.g. Widevine).
    drm: bool


class Facts(TypedDict, total=False):
    """The facts of a source, in groups."""

    #: The video.
    video: VideoFacts
    #: Audio tracks.
    audio: list[AudioTrack]
    #: Subtitle tracks.
    subtitles: list[SubtitleTrack]
    #: The release.
    release: ReleaseFacts
