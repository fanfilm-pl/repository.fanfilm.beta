"""
The facts of a source from a text: a file name, a release name or an info text of a provider (`parse()`), and the
facts given by a provider completed with the parsed ones (`complete()`).
"""

from __future__ import annotations
import re
from functools import lru_cache
from typing import Any, Iterator, Mapping, cast
from attrs import frozen
from .rules import RULES, TITLE_END, TECH, HEAD, BRACKETS, lang
from .types import Facts, VideoFacts, ReleaseFacts


#: Text between facts: separators, brackets, used up text.
SEPARATORS = re.compile(r'[\s._\-+,/|\[\]()\x00]*')

#: The groups of single facts (the others, `audio` and `subtitles`, are lists of tracks).
GROUPS: dict[str, type] = {'video': VideoFacts, 'release': ReleaseFacts}


@frozen
class Hit:
    """A fact found in the text."""

    #: The key (`group.name`).
    key: str
    #: The value.
    value: Any
    #: The position in the text.
    start: int


@frozen
class Candidate:
    """A match of a `tail` rule in the title: a fact if only facts follow it up to the anchor."""

    #: The start of the match.
    start: int
    #: The end of the match.
    end: int
    #: The facts of the match.
    hits: tuple[Hit, ...]


def hits(text: str) -> Iterator[Hit]:
    """
    Yield the facts of the rules (`RULES`) found in the text, every matched text used up. A match of a `tail` rule before
    the anchor (in the title) is a fact only if the anchor is a technical word (not a year) and just separators and other
    facts are between them (`Movie.FRENCH.CAMHD.H264`, but `Johnny English 2003`); never the first word (`Cam.2018`).
    """
    head = mch.end() if (mch := HEAD.match(text)) else 0
    title_end = next((mch.start() for mch in TITLE_END.finditer(text) if mch.start() > head), len(text))
    tech = next((mch.start() for mch in TECH.finditer(text) if mch.start() > head), len(text))
    anchor = min(title_end, tech)
    if anchor == len(text):  # no title end known: no title protection
        anchor = 0
    brackets = [mch.span() for mch in BRACKETS.finditer(text)]
    candidates: list[Candidate] = []
    masked = text
    lower = text.lower()
    for rule in RULES:
        if rule.words and not any(word in lower for word in rule.words):
            continue
        spans: list[tuple[int, int]] = []
        for mch in rule.rx.finditer(masked):
            value = rule.fact(mch)
            if value is None or value == {}:  # nothing known: the text is not used up
                continue
            start = mch.start() + len(text) * rule.fallback  # a fallback after all the others
            found = (Hit(rule.key, value, start), *(Hit(key, also, start) for key, also in rule.also.items()))
            if rule.tail and head <= mch.start() < anchor and not any(start < mch.start() < end for start, end in brackets):
                candidates.append(Candidate(mch.start(), mch.end(), found))
                continue
            yield from found
            if rule.use_up:
                spans.append(mch.span())
        masked = mask(masked, spans)
    if tech >= title_end:
        return
    end = anchor
    for cand in sorted(candidates, key=lambda cand: cand.start, reverse=True):
        if cand.start > head and cand.end <= end and SEPARATORS.fullmatch(masked[cand.end:end]) and chr(0) not in masked[cand.start:cand.end]:
            yield from cand.hits
            masked = mask(masked, [(cand.start, cand.end)])
            end = cand.start


def mask(text: str, spans: list[tuple[int, int]]) -> str:
    """Return the text with the spans used up (no rule matches them, they separate words)."""
    for start, end in spans:
        text = f'{text[:start]}{chr(0) * (end - start)}{text[end:]}'
    return text


def is_list(group: str, name: str) -> bool:
    """Check if the fact is a list (from its type in the group, e.g. `VideoFacts.hdr: list[Hdr]`)."""
    annotation = GROUPS[group].__annotations__.get(name, '')
    return str(getattr(annotation, '__forward_arg__', annotation)).startswith('list[')


def merge(tracks: list[dict[str, Any]], part: Mapping[str, Any], *, fill: bool = False) -> None:
    """
    Merge a track part into the first track it does not contradict (no other value of a key), or add it. `fill`: first
    into a track without its keys (`AC3 5.1-Castellano-AC3 5.1 Ingles`: a codec to each language).
    """
    if fill and (track := next((track for track in tracks if not any(key in track for key in part)), None)) is not None:
        track.update(part)
        return
    for track in tracks:
        if all(track[key] == value for key, value in part.items() if key in track):
            track.update(part)
            return
    tracks.append(dict(part))


def assemble(found: Iterator[Hit], *, language: str | None = None) -> Facts:
    """
    Return the facts of the hits (in the order of the text). The audio tracks: the languages, then the codecs merged into
    the first track they do not contradict (a name does not say whose codec it is). `language` (of the provider) is the
    language of the audio, if the text has no other: a dubbing without a language is in it, Polish subtitles of a Polish
    provider do not make its audio Polish. A hint (a Polish release group, Polish letters) is such a language too, before
    the one of the provider.
    """
    facts: dict[str, Any] = {}
    audio: list[dict[str, Any]] = []
    specs: list[dict[str, Any]] = []
    hints: list[dict[str, Any]] = []
    subtitles: list[dict[str, Any]] = []
    for hit in sorted(found, key=lambda hit: hit.start):
        group, _, name = hit.key.partition('.')
        parts = hit.value if isinstance(hit.value, list) else [hit.value]
        if group == 'audio':
            (specs if name == 'spec' else hints if name == 'hint' else audio).extend(parts)
        elif group == 'subtitles':
            subtitles.extend(parts)
        elif group:
            values = facts.setdefault(group, {})
            if not is_list(group, name):
                values.setdefault(name, hit.value)
            elif hit.value not in (items := values.setdefault(name, [])):
                items.append(hit.value)
    tracks: list[dict[str, Any]] = []
    for part in audio:
        merge(tracks, part)
    for part in specs:
        merge(tracks, part, fill=True)
    subs: list[dict[str, Any]] = []
    for part in subtitles:
        merge(subs, part)
    if hints and not any(track.get('lang') for track in tracks) and not any(sub.get('lang') == hints[0]['lang'] for sub in subs):
        merge(tracks, hints[0])
    if language == 'multi':
        if not tracks:
            tracks.append({'lang': None})
    elif code := lang(language):
        for track in tracks:
            if 'kind' in track and 'lang' not in track:
                track['lang'] = code
        if not any(track.get('lang') for track in tracks) and not any(sub.get('lang') == code for sub in subs):
            merge(tracks, {'lang': code})
    if tracks:
        facts['audio'] = tracks
    if subs:
        facts['subtitles'] = subs
    return cast(Facts, facts)


@lru_cache(maxsize=4096)
def parse(text: str, *, language: str | None = None) -> Facts:
    """
    Return the facts of a text: a file / release name, an info text of a provider or both (`name | info`). `language` is
    the language of the provider item (`pl`, `en`, `multi`). The result is shared (cached): do not change it.
    """
    return assemble(hits(text), language=language)


def complete(facts: Facts, extra: Facts) -> Facts:
    """Return the facts completed with the extra ones (e.g. given by a provider + parsed): the given values win, the tracks too."""
    result: dict[str, Any] = {group: dict(values) if isinstance(values, dict) else list(values) for group, values in facts.items()}
    for group, values in extra.items():
        if group not in result:
            result[group] = dict(values) if isinstance(values, dict) else list(values)
        elif isinstance(values, dict):
            for name, value in values.items():
                result[group].setdefault(name, value)
    return cast(Facts, result)
