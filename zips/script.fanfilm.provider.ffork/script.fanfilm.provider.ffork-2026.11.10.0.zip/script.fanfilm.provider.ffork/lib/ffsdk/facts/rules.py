"""
The rules of the source facts: one table (`RULES`), applied in its order to a file name or a text of a provider.

A rule gives one fact (`key`: `video.codec`, `audio.track`...; also `also`) from a match of its regular expression
(case insensitive). The matched text is used up, the next rules do not see it: `5.1` of the audio is not a version,
`DTS-HD` is not `DTS` and `HD`. A `tail` rule does not match in the title: before the anchor (`TITLE_END`: a year, an
episode; `TECH`: a technical word), the title can have such words (`The.Cam`, `Johnny English`); see `parse.hits()`.
`words` of a rule are a fast check: a rule is not tried on a text without them.

Patterns are written for `re` of the standard library only (no `regex`: Kodi on Android / ARM). Some patterns follow
parse-torrent-title (Clément Escolano, TheBeastLT; MIT), rewritten (no variable-length look-behind, no `\\p{L}`).
"""

from __future__ import annotations
import re
from typing import Any, Callable, Mapping, TYPE_CHECKING
from typing_extensions import TypeAlias
from attrs import frozen, field
from .vocab import Term, VideoCodec, Hdr, AudioCodec, TrackKind, AudioRecording, SubtitleKind, ReleaseSource, Edition, Container, Lang, POLISH_GROUPS
if TYPE_CHECKING:
    from typing_extensions import Pattern, Match


#: Not after a letter or a digit (the start of a word; `_` separates words in file names).
LEFT = r'(?<![^\W_])'
#: Not before a letter or a digit (the end of a word).
RIGHT = r'(?![^\W_])'
#: The end of an audio codec: a digit can follow (`DDP5.1`, `AAC2.0`), but not a video codec (`DTS.x264`).
RIGHT_AUDIO = r'(?![^\W\d_])(?!26[45])'
#: An optional separator.
SEP = r'[ ._-]?'
#: Language names and three-letter codes.
LANG_NAME = Lang.pattern(min_length=3)
#: Two-letter language codes (only next to a word of a track: `PL.DUB`, `SUB.EN`).
LANG_CODE = Lang.pattern(max_length=2)
#: Polish adjectives of languages by their stems (`polskim lektorem`, `napisy angielskie`); more languages can be added here.
LANG_ADJECTIVES: dict[str, str] = {'polsk': 'pl', 'angielsk': 'en'}
#: A language adjective in any form (Polish letters, not `\w`: `_` separates words in file names).
LANG_ADJ = f'(?:{"|".join(LANG_ADJECTIVES)})[a-ząćęłńóśźż]*'
#: Any language of a track word.
LANG_ANY = f'{LANG_ADJ}|{LANG_NAME}|{LANG_CODE}'
#: A voice-over (Polish lektor) in its forms (`z lektorem`, `bez lektora`).
LEKTOR = 'lektor(?:a|em|ze)?'
#: A dubbing in its forms (`DUBBED`, `z dubbingiem`).
DUBBING = 'dub(?:bing(?:u|iem)?|bed|b|lado|s)?'
#: Polish subtitles in their forms (`z napisami`, `bez napisów`).
NAPISY = 'napis(?:y|ami|ów|ach)'
#: Words of a track (the negated ones: `bez lektora i napisów`, `no PL dub`, `without polish audio`).
TRACK_WORD = f'(?:{LEKTOR}|{DUBBING}|{NAPISY}|sub(?:s|bed|titles?)?|audio|d[zź]wi[eę]k[a-ząę]*)'
#: A negated track: a track word, its language before or after it.
NEGATED_TRACK = f'(?:(?:{LANG_ANY}){SEP})?{TRACK_WORD}(?:{SEP}(?:{LANG_ANY}))?(?:{SEP}ai)?'
#: A Polish release group: after a dash or in brackets, before the end of a word (`-FLAME.mkv`, `[Alusia]`).
POLISH_GROUP = (f'(?:(?<=-)|(?<=\\[))(?-i:{"|".join(re.escape(group) for group in sorted(POLISH_GROUPS, key=len, reverse=True))})'
                r'(?=[]).\s|\x00]|$)')
#: Polish letters (not `ó`: other languages have it too).
POLISH_LETTERS = '[ąćęłńśźż]'
#: Not a size (`5.1 GB` is not 5.1 channels).
NOT_SIZE = r'(?!\s*[kmgt]i?b\b)'
#: Channels: `5.1`, `7.1.4`, `6ch`.
CHANNELS = f'(?P<ch>[1-9]\\.[0-2](?:\\.[24])?{NOT_SIZE}|[1-8]ch)'
#: Channels after a codec, also `5 1` (`DTS-HD MA 5 1`).
CODEC_CHANNELS = f'(?P<ch>[1-9][ .][0-2](?:\\.[24])?{NOT_SIZE}|[1-8]ch)'

#: The value of a rule: a constant, or a function of the match.
RuleValue: TypeAlias = 'Any | Callable[[Match[str]], Any]'


def lang(text: str | None) -> str | None:
    """Return the language code (ISO 639-1) of a code, a name or a language adjective (`LANG_ADJECTIVES`), None if unknown."""
    if not text:
        return None
    if value := Lang.find(text):
        return value.value
    return next((code for stem, code in LANG_ADJECTIVES.items() if text.lower().startswith(stem)), None)


#: Channels of a channel count (`6ch` is `5.1`).
CHANNEL_COUNTS: dict[str, str] = {'1': '1.0', '2': '2.0', '3': '2.1', '6': '5.1', '7': '6.1', '8': '7.1'}


def channels(text: str) -> str:
    """Return channels as `N.M` (`5 1` -> `5.1`, `6ch` -> `5.1`, `7.1.4` -> `7.1`)."""
    text = text.lower()
    if text.endswith('ch'):
        return CHANNEL_COUNTS.get(text[:-2], f'{text[:-2]}.0')
    return '.'.join(re.split(r'[ .]', text)[:2])


#: Standard frame heights (the nominal one of a frame size: 1920x800 is 1080).
HEIGHTS: tuple[int, ...] = (4320, 2160, 1440, 1080, 720, 576, 480, 360, 240)


def frame_height(mch: Match[str]) -> int | None:
    """Return the nominal height of a frame size `WxH` (from its width: wide films are lower) or of `Np`."""
    if width := mch.groupdict().get('w'):
        height = int(width) * 9 // 16
    else:
        height = int(mch.group('h'))
    if height > HEIGHTS[0] * 1.1:
        return None
    return min(HEIGHTS, key=lambda standard: abs(standard - height)) if mch.groupdict().get('w') else height


def audio_spec(mch: Match[str]) -> dict[str, Any]:
    """Return the audio track part of a codec / channels / Atmos match."""
    spec: dict[str, Any] = {}
    if (codec := mch.groupdict().get('t')) and (value := AudioCodec.find(codec)):
        spec['codec'] = value
    if ch := mch.groupdict().get('ch'):
        spec['channels'] = channels(ch)
    if mch.groupdict().get('atmos'):
        spec['atmos'] = True
    return spec


def tracks(mch: Match[str]) -> list[dict[str, Any]]:
    """Return the audio tracks of a list of language codes (`CZ/EN`, `DK.EN.ES`)."""
    return [{'lang': code} for code in (lang(text) for text in re.findall(r'[A-Z]{2}', mch.group(0))) if code]


def track(kind: TrackKind | SubtitleKind | None = None, *, default_lang: str | None = None, unknown_lang: bool = False,
          extra: Mapping[str, Any] | None = None) -> Callable[[Match[str]], dict[str, Any]]:
    """
    Return a value function of a track: its language from the groups `l1` / `l2` (or the default; `unknown_lang`: a track
    of no language given is one of an unknown language, `subbed`), kind, `ai`.
    """
    def value(mch: Match[str]) -> dict[str, Any]:
        groups = mch.groupdict()
        result: dict[str, Any] = {}
        if code := lang(groups.get('l1')) or lang(groups.get('l2')) or default_lang:
            result['lang'] = code
        elif unknown_lang:
            result['lang'] = None
        if kind is not None:
            result['kind'] = kind
        if groups.get('ai'):
            result['ai'] = True
        if extra:
            result.update(extra)
        return result
    return value


#: Compiled patterns of the rules (by the rule identity; the rules live as long as the module).
_COMPILED: dict[int, Pattern[str]] = {}


@frozen(kw_only=True)
class Rule:
    """A rule of a fact: the pattern and the value of a match."""

    #: The key of the fact (`group.name`, see `parse.assemble()`); empty: the text is only used up.
    key: str
    #: The regular expression; `{terms}` is the pattern of the vocabulary (`terms`), its group `t`.
    pattern: str = '{terms}'
    #: The vocabulary of the value (the value is its member of the group `t`).
    terms: type[Term] | None = None
    #: The value (a constant or a function of the match); None: the vocabulary member.
    value: RuleValue = None
    #: Other facts of the match (`BDRemux` is also a Blu-ray).
    also: Mapping[str, Any] = field(factory=dict)
    #: The start of the match.
    left: str = LEFT
    #: The end of the match.
    right: str = RIGHT
    #: Only after the anchor (not in the title).
    tail: bool = True
    #: Words of the pattern (lower case): the rule is tried only if the text has one of them (a fast check).
    words: tuple[str, ...] = ()
    #: The fact only if the text has no other value of it (`DVD5` is the size of the encode in `DVD5.720p.BluRay`).
    fallback: bool = False
    #: The matched text is used up (a hint of the whole text keeps it: a Polish letter of a title).
    use_up: bool = True

    @property
    def rx(self) -> Pattern[str]:
        """Return the compiled pattern with its vocabulary and bounds (compiled on the first use: the import stays cheap)."""
        if (rx := _COMPILED.get(id(self))) is None:
            pattern = self.pattern
            if self.terms is not None:
                pattern = pattern.replace('{terms}', f'(?P<t>{self.terms.pattern()})')
            rx = _COMPILED[id(self)] = re.compile(f'{self.left}(?:{pattern}){self.right}', re.IGNORECASE)
        return rx

    def fact(self, mch: Match[str]) -> Any:
        """Return the value of a match (None: no fact)."""
        if callable(self.value):
            return self.value(mch)
        if self.value is None and self.terms is not None:
            return self.terms.find(mch.group('t'))
        return self.value


#: The end of the title: a year, an episode (the words before it are the title, `Johnny English 2003`).
TITLE_END = re.compile(f'{LEFT}(?:(?:19|20)\\d\\d|s\\d{{1,2}}(?:e\\d{{1,3}})?|e\\d{{2,3}}|\\d{{1,2}}x\\d{{2,3}}|sezon{SEP}\\d+){RIGHT}',
                       re.IGNORECASE)
#: Technical words that the titles do not have: a resolution, a video codec, a clear source (the facts just before them are
#: facts too: `Movie.FRENCH.CAMHD.H264`).
TECH = re.compile(f'{LEFT}(?:\\d{{3,4}}[pi]|[48]k|uhd|{VideoCodec.pattern()}|bdrip|brrip|web{SEP}dl|webrip|blu{SEP}ray|hdtv|dvdrip|remux){RIGHT}',
                  re.IGNORECASE)
#: The brackets at the start of a text (`[Group]`, `[BluRay Rip 720p]`): not the title.
HEAD = re.compile(r'^(?:\s*\[[^]]*\])+')
#: Brackets: their content is not the title (`Movie (Uncut) 1978`, `Title [English Dub]`).
BRACKETS = re.compile(r'\[[^][]*\]|\([^()]*\)')


def hdr_part(version: str | None) -> Hdr:
    """Return the HDR format of the version after `hdr` (`10`, `10+`, `10plus`, none) of a glued DV name (`HDR10withDV`)."""
    if not version:
        return Hdr.HDR
    return Hdr.HDR10 if version == '10' else Hdr.HDR10_PLUS


#: The rules in the order they are applied.
RULES: tuple[Rule, ...] = (
    # --- the file ---
    Rule(key='release.container', pattern=r'\.{terms}$', terms=Container, left='', right='', tail=False),
    Rule(key='release.container', pattern=f'(?P<t>{Container.pattern(min_length=3)})', terms=Container),
    # --- the video ---
    Rule(key='video.height', pattern=r'(?P<w>\d{3,4})x(?P<h>\d{3,4})', value=frame_height, tail=False),
    Rule(key='video.height', pattern=r'(?P<h>\d{3,4})[pi]', value=frame_height, tail=False),
    Rule(key='video.height', pattern=r'4k|uhd|2160', value=2160, tail=False),
    Rule(key='video.height', pattern=r'8k', value=4320, tail=False),
    Rule(key='video.height', pattern=r'fhd', value=1080),
    Rule(key='video.bit_depth', pattern=r'(?P<b>8|10|12)[ .-]?bits?', value=lambda m: int(m.group('b')), left=r'(?<!\d)'),
    Rule(key='video.bit_depth', pattern=r'hi10p?', value=10, also={'video.codec': VideoCodec.H264}),
    Rule(key='video.fps', pattern=r'(?P<f>\d{2,3})[ .-]?fps', value=lambda m: int(m.group('f'))),
    Rule(key='video.three_d', pattern=r'3d', value=True),
    Rule(key='video.three_d', pattern=r'(?:half[ .-]?|h[ .-]?)?(?:sbs|ou|side[ .-]?by[ .-]?side|over[ .-]?under)|bd3d', value=True, tail=False),
    # DV glued to HDR (HDR10withDV, DVwithHDR10, HDRDV, withDV): both formats
    Rule(key='video.hdr', pattern=f'hdr(?P<p>10(?:\\+|plus)?)?{SEP}(?:with|w|and)?{SEP}(?:dv|dovi)', value=lambda m: hdr_part(m.group('p')),
         also={'video.hdr': Hdr.DOLBY_VISION}),
    Rule(key='video.hdr', pattern=f'(?:dv|dovi){SEP}(?:with|w|and){SEP}hdr(?P<p>10(?:\\+|plus)?)?', value=lambda m: hdr_part(m.group('p')),
         also={'video.hdr': Hdr.DOLBY_VISION}),
    Rule(key='video.hdr', pattern=f'w(?:ith)?{SEP}(?:dv|dovi)', value=Hdr.DOLBY_VISION),
    Rule(key='video.hdr', terms=Hdr),
    Rule(key='video.codec', terms=VideoCodec, tail=False),
    Rule(key='video.sign_language', pattern=f'pjm|j[eę]zyk(?:iem)?{SEP}migow\\w+|sign{SEP}language', value=True),
    Rule(key='video.colorized', pattern=f'colori[sz]ed{SEP}(?:by{SEP})?ai|ai{SEP}colori[sz]ed', value=True, also={'video.ai': True}),
    Rule(key='video.colorized', pattern=r'colori[sz]ed|koloryzowany|koloryzacja', value=True),
    Rule(key='video.ai', pattern=f'(?:ai{SEP})?upscal(?:ed|ing|e)(?:{SEP}(?:by{SEP})?ai)?', value=True),
    # --- the audio: codec + channels + Atmos, then the parts alone ---
    Rule(key='audio.spec', pattern=f'{{terms}}(?:{SEP}{CODEC_CHANNELS})?(?:{SEP}(?P<atmos>atmos))?', terms=AudioCodec,
         value=audio_spec, right=RIGHT_AUDIO, tail=False),
    Rule(key='audio.spec', pattern=CHANNELS, value=audio_spec, left=r'(?<!\d)(?<!\d\.)', right=r'(?![\d])'),
    Rule(key='audio.spec', pattern=r'(?P<atmos>atmos)', value=audio_spec),
    Rule(key='audio.spec', terms=AudioRecording, value=lambda m: {'recording': AudioRecording.find(m.group('t'))}),
    # --- the release ---
    Rule(key='release.remux', pattern=r'(?:4k)?(?:bd|uhd)[ .-]?remux', value=True, also={'release.source': ReleaseSource.BLURAY}),
    Rule(key='release.remux', pattern=r'remux', value=True),
    Rule(key='release.source', terms=ReleaseSource),
    Rule(key='release.source', pattern=r'dvd[59]', value=ReleaseSource.DVD, fallback=True),
    Rule(key='release.edition', terms=Edition, tail=False),
    Rule(key='release.edition', pattern=f'wersja{SEP}kinowa', value=Edition.THEATRICAL),  # not in the title: Fistaszki Wersja Kinowa
    Rule(key='release.proper', pattern=r'proper', value=True),
    Rule(key='release.repack', pattern=r'repack|rerip', value=True),
    Rule(key='release.drm', pattern=r'drm', value=True),
    # --- no track: a negated track is used up, it is no fact (`ENG bez lektora i napisów`, `no PL dub`; `no` only before a track word) ---
    Rule(key='', pattern=f'(?:bez|brak|without|no){SEP}{NEGATED_TRACK}(?:{SEP}(?:i|ani|oraz|and|or|nor|&){SEP}{NEGATED_TRACK})*', value=True,
         words=('bez', 'brak', 'without', 'no')),
    # --- the subtitles (before the audio languages: `ENG.SUB` is subtitles) ---
    Rule(key='subtitles.track', pattern=f'(?:wtopion[a-z]*|wgran[a-z]*|hardcoded){SEP}{NAPISY}',
         value=track(default_lang='pl', extra={'burned': True}), words=('napis',)),
    Rule(key='subtitles.track', pattern=f'(?:multi|dual){SEP}sub(?:s|bed|titles?)?|msubs?', value=track(extra={'lang': None}), words=('sub',)),
    Rule(key='subtitles.track', pattern=r'esubs?', value=track(default_lang='en'), words=('sub',)),
    Rule(key='subtitles.track', pattern=f'(?:(?P<l1>{LANG_ANY}){SEP})?{NAPISY}(?:{SEP}(?P<l2>{LANG_ANY}))?(?:{SEP}(?P<ai>ai))?',
         value=track(default_lang='pl'), words=('napis',)),
    Rule(key='subtitles.track', pattern=f'nap{SEP}pl', value=track(default_lang='pl'), words=('nap',)),
    Rule(key='subtitles.track', pattern=f'(?:(?P<l1>{LANG_ANY}){SEP})?(?:sub(?:s|bed|titles?|title)?|sub{SEP}titles?)'
                                        f'(?:{SEP}(?P<l2>{LANG_ANY}))?(?:{SEP}(?P<ai>ai))?', value=track(unknown_lang=True), words=('sub',)),
    Rule(key='subtitles.track', pattern=f'(?:legendad[oa]s?|legendas?|leg)(?:{SEP}(?P<l2>{LANG_ANY}))?', value=track(default_lang='pt'), words=('leg',)),
    Rule(key='subtitles.track', pattern=r'sdh', value=track(SubtitleKind.SDH)),
    Rule(key='subtitles.track', pattern=f'hc|hard{SEP}sub(?:s|bed)?|hardcoded', value=track(extra={'burned': True})),
    # --- the audio languages ---
    Rule(key='audio.track', pattern=f'audio{SEP}deskrypcj[ai]', value=track(TrackKind.AUDIO_DESCRIPTION, default_lang='pl'), words=('deskrypc',)),
    Rule(key='audio.track', pattern=f'audio{SEP}description', value=track(TrackKind.AUDIO_DESCRIPTION), words=('description',)),
    Rule(key='audio.track', pattern=f'(?P<l1>{LANG_ADJ}){SEP}(?:audio|d[zź]wi[eę]k[a-ząę]*|[sś]cie[zż]k[a-ząę]*)', value=track(),
         words=tuple(LANG_ADJECTIVES)),
    # a dubbing of a language before a lektor (`dubbing pl lektor pl`: the `pl` of the dubbing is not the one of the lektor)
    Rule(key='audio.track', pattern=f'(?P<l1>{LANG_ANY}){SEP}{DUBBING}(?:{SEP}(?P<ai>ai))?', value=track(TrackKind.DUBBING), words=('dub',)),
    Rule(key='audio.track', pattern=f'{DUBBING}{SEP}(?P<l2>{LANG_ANY})(?:{SEP}(?P<ai>ai))?', value=track(TrackKind.DUBBING), words=('dub',)),
    Rule(key='audio.track', pattern=f'ai{SEP}{LEKTOR}(?:{SEP}(?P<l2>{LANG_ANY}))?', value=track(TrackKind.LEKTOR, default_lang='pl', extra={'ai': True}),
         words=('lektor',)),
    Rule(key='audio.track', pattern=f'(?:(?P<l1>{LANG_ADJ}|{LANG_CODE}){SEP})?{LEKTOR}(?:{SEP}(?P<l2>{LANG_ANY}))?(?:{SEP}(?P<ai>ai))?',
         value=track(TrackKind.LEKTOR, default_lang='pl'), words=('lektor',)),
    Rule(key='audio.track', pattern=f'pl{SEP}lek', value=track(TrackKind.LEKTOR, default_lang='pl'), words=('lek',)),
    Rule(key='audio.track', pattern=f'pl{SEP}ai|ai{SEP}pl', value=track(TrackKind.LEKTOR, default_lang='pl', extra={'ai': True}), words=('ai',)),
    Rule(key='audio.track', pattern=f'multi{SEP}dub(?:bed|s)?|multi(?:{SEP}(?:audio|lang(?:uage)?s?))?|dual(?:{SEP}audio)?|2{SEP}audio',
         value=track(extra={'lang': None}), words=('multi', 'dual', 'audio')),
    Rule(key='audio.track', pattern=f'{DUBBING}(?:{SEP}(?P<ai>ai))?', value=track(TrackKind.DUBBING), words=('dub',)),
    Rule(key='audio.track', pattern=f'(?-i:{LANG_CODE.upper()})(?:[ ./+,-]+(?-i:{LANG_CODE.upper()}))+', value=tracks),
    Rule(key='audio.track', pattern=r'(?-i:(?P<l1>PL))', value=track()),
    Rule(key='audio.track', pattern=f'(?P<l1>{LANG_NAME})', value=track()),
    # --- hints of the audio language: Polish, if the text gives no other (see `parse.assemble()`) ---
    Rule(key='audio.hint', pattern=POLISH_GROUP, value=track(default_lang='pl'), left='', right='', tail=False),
    Rule(key='audio.hint', pattern=POLISH_LETTERS, value=track(default_lang='pl'), left='', right='', tail=False, use_up=False),
)
