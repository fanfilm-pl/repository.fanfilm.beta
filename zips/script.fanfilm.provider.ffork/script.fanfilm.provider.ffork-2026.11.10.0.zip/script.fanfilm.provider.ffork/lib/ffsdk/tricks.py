"""Small helpers of the SDK."""

from __future__ import annotations
from sys import version_info
import json
import dataclasses as dc
from ast import literal_eval as _ast_literal_eval
from dataclasses import Field, is_dataclass
from datetime import date as dt_date, time as dt_time
from functools import wraps
from threading import Lock
from typing import Any, Callable, ClassVar, Iterable, TypeVar
from typing_extensions import Protocol, TypeIs, cast, overload
import attrs
from attrs import Attribute
from .dates import is_datetime_instance
from .types import get_type_hints

#: Any type.
T = TypeVar('T')


class MissingType:
    """General type of singleton MISSING: one object, also after a copy or a pickle."""

    #: The only instance.
    _instance: ClassVar[MissingType | None] = None

    def __new__(cls) -> MissingType:
        """Return the only instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        """Return the name."""
        return 'MISSING'

    def __bool__(self) -> bool:
        """Return False (nothing is there)."""
        return False


#: General missing singleton object (a value not given, None is a value).
MISSING = MissingType()


if version_info >= (3, 9):
    str_removeprefix = str.removeprefix
else:
    def str_removeprefix(s: str, __prefix: str, /):
        """
        If the string starts with the prefix string, return string[len(prefix):].
        Otherwise, return a copy of the original string.
        """
        if s.startswith(__prefix):
            return s[len(__prefix):]
        return s


#: CPython 3.11 < 3.11.5 (e.g. Kodi 21 on Android) has a thread-unsafe AST parser (gh-106905):
#: concurrent compile()/literal_eval() raise SystemError "AST constructor recursion depth mismatch".
#: One process-wide lock, because the race is between ANY two parses running at once.
_literal_eval_lock = Lock()


def literal_eval(text: Any) -> Any:
    """Thread-safe ast.literal_eval() - provider threads read cached data concurrently."""
    with _literal_eval_lock:
        return _ast_literal_eval(text)


class DataClass(Protocol):
    __dict__: dict[str, Any]
    __doc__: str | None
    # if using `@dataclass(slots=True)`
    __slots__: str | Iterable[str]
    __annotations__: dict[str, str | type]
    __dataclass_fields__: dict[str, Field]
    # the actual class definition is marked as private, and here I define
    # it as a forward reference, as I don't want to encourage
    # importing private or "unexported" members.
    # __dataclass_params__: '_DataclassParams'
    # __post_init__: Callable | None


class _SingletonClassProto(Protocol):
    __new__: Callable[..., Any]
    __singleton_init__: Callable[..., Any] | None
    def __mro__(self) -> tuple[type]: ...
    def mro(self) -> list[type]: ...


def singleton(klass: type[T], /) -> type[T]:
    """Singleton class decorator. Only one instance of the class is created."""
    orig_new: Callable = klass.__new__
    instance: Any = None

    @wraps(klass.__new__)
    def __new__(cls, *args, **kwargs):
        nonlocal instance
        if instance is None:
            # object.__new__ takes only one argument
            if orig_new is object.__new__:
                instance = object.__new__(cls)
            else:
                instance = orig_new(cls, *args, **kwargs)
            if cls.__singleton_init__:
                cls.__singleton_init__(instance, *args, **kwargs)
        return instance

    orig_cls = cast(_SingletonClassProto, klass)
    # override __new__
    orig_cls.__new__ = __new__
    # remove __init__ to keep call it once
    orig_cls.__singleton_init__ = getattr(orig_cls, '__init__', None)
    if orig_cls.__singleton_init__ is not None and orig_cls.__singleton_init__ is not object.__init__:
        if not any(orig_cls.__init__ is c.__init__ for c in orig_cls.mro()[1:]):
            del orig_cls.__init__
    return klass


def is_namedtuple(obj: object) -> TypeIs[tuple]:
    """Retrun true if object is a namedtuple (NamedTuple)."""
    return isinstance(obj, tuple) and hasattr(type(obj), '_fields')


def is_namedtuple_class(cls: Any) -> TypeIs[type[tuple]]:
    """Retrun true if class inheris from namedtuple (NamedTuple)."""
    return isinstance(cls, type) and issubclass(cls, tuple) and hasattr(cls, '_fields')


def namedtuple_attrs(cls: type[tuple]) -> tuple[Attribute, ...]:
    """Return attrs.fields for namedtuple."""
    def make_field(name: str) -> Attribute:
        if name in defaults:
            default = defaults[name]
        else:
            default = attrs.NOTHING
        return Attribute(name=name, default=default, validator=None, repr=True, cmp=False, hash=None, init=True,  # type: ignore[reportUnknownArgument]
                         inherited=False, type=ann[name])  # type: ignore[reportUnknownArgument]

    if not is_namedtuple(cls) and not is_namedtuple_class(cls):
        raise TypeError('must be called with a namedtuple type or instance') from None

    defaults: dict[str, Any] = cls._field_defaults  # type: ignore[reportUnknownMember]
    ann = get_type_hints(cls)
    return tuple(make_field(f) for f in cls._fields)  # type: ignore[reportUnknownMember]


def dataclass_attrs(cls: type[DataClass]) -> tuple[Attribute, ...]:
    """Return attrs.fields from dataclass."""

    def make_field(f: Field) -> Attribute:
        if f.default is dc.MISSING:
            default = attrs.NOTHING
        elif f.default_factory is not dc.MISSING:
            default = attrs.Factory(f.default_factory)
        else:
            default = f.default
        return Attribute(name=f.name, default=default, validator=None, repr=f.repr, cmp=f.compare, hash=f.hash,  # type: ignore[reportUnknownMember]
                         init=f.init, inherited=False, type=f.type)  # type: ignore[reportUnknownMember]

    if not is_dataclass(cls):
        raise TypeError('must be called with a dataclass type or instance') from None

    # ann = get_type_hints(cls)
    return tuple(make_field(f) for f in dc.fields(cls))


@overload
def super_get_attr(obj: Any, key: str, /) -> Any: ...


@overload
def super_get_attr(obj: Any, key: str, default: T, /) -> Any | T: ...


def super_get_attr(obj: Any, key: str, /, *default) -> Any:
    """Like getattr() with sub.obj.support."""
    if '.' in key:
        keys = key.split('.')
        for key in keys[:-1]:
            obj = getattr(obj, key)
        key = keys[-1]
    return getattr(obj, key, *default)


class JsonEncoder(json.JSONEncoder):
    def default(self, o):
        if serialize := getattr(o, '__to_json__', None):
            return serialize()
        if getattr(type(o), '__attrs_attrs__', None) is not None:  # define / frozen
            return attrs.asdict(o)
        if isinstance(o, (dt_date, dt_time)) or is_datetime_instance(o):
            return str(o)
        return super().default(o)
