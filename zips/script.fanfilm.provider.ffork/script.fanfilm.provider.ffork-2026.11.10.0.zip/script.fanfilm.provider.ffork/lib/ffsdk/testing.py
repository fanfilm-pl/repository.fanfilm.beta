"""
The protocol conformance of a provider add-on: the rules of the `find` stream checked on its events.
"""

from __future__ import annotations
import json
from typing import Any, Iterable, Sequence


def find_problems(events: Iterable[Any], providers: Sequence[str]) -> list[str]:
    """
    Return the protocol problems of a `find` stream of the request `providers` (empty: none): `done` exactly once for
    every provider, no items after its `done`, only the providers of the request, JSON data.
    """
    problems: list[str] = []
    done: set[str] = set()
    for event in events:
        try:
            json.dumps(event)
        except (TypeError, ValueError) as exc:
            problems.append(f'not JSON data: {exc}')
        kind, provider = event.get('event'), event.get('provider')
        if provider not in providers:
            problems.append(f'{kind} of a provider not in the request: {provider!r}')
        elif kind == 'items':
            if provider in done:
                problems.append(f'items after done: {provider!r}')
            if not isinstance(event.get('items'), list):
                problems.append(f'items not a list: {provider!r}')
        elif kind == 'done':
            if provider in done:
                problems.append(f'done twice: {provider!r}')
            done.add(provider)
        else:
            problems.append(f'unknown event {kind!r}')
    problems.extend(f'no done: {provider!r}' for provider in providers if provider not in done)
    return problems
