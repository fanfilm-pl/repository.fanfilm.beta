"""
The Fenom family scrapers (CocoScrapers, Fenom, Classy, POV): `sources(data, hostDict)`, `sources_packs(...)`, the search
data as Fen gives it (`title` of an episode is the episode title, `year` of the show).
"""

from __future__ import annotations
import re
from typing import Any, Mapping, TYPE_CHECKING
from .ff import old_ids, old_aliases, old_str
from ..protocol.item import Item, item_from_legacy
if TYPE_CHECKING:
    from ..protocol.query import Query
    from ..protocol.types import Context

#: A size in GB of an info text of a scraper (`7.2 GB`, `7.20 GB`).
RX_INFO_SIZE = re.compile(r'(\d+(?:\.\d+)?) GB')
#: Bytes of a GB (the scrapers give the size in GB).
GB = 1024 ** 3


def fenom_data(query: Query, context: Context | None = None) -> dict[str, Any]:
    """Return the search data of a Fenom scraper (`timeout`: the time limit of the host, else the one of the scraper)."""
    imdb, _ = old_ids(query)
    title = query.get('title', {})
    data: dict[str, Any] = {'imdb': imdb, 'aliases': old_aliases(query), 'year': old_str(query.get('year'))}
    if context and (timeout := context.get('timeout')):
        data['timeout'] = timeout
    if query.get('type') == 'movie':
        data['title'] = title.get('english', '')
    else:
        data.update(tvshowtitle=title.get('english', ''), title=query.get('episode_title', ''),
                    season=old_str(query.get('season')), episode=old_str(query.get('episode')))
    return data


def pack_has(item: Mapping[str, Any], query: Query) -> bool:
    """Check if a pack item has the episode: a part of a season (`episode_start`, `episode_end`), the seasons of a show (`last_season`)."""
    season, episode = query.get('season'), query.get('episode')
    start, end, last = item.get('episode_start'), item.get('episode_end'), item.get('last_season')
    if start and end and episode is not None and not int(start) <= episode <= int(end):
        return False
    return not (last and season is not None and season > int(last))


def fenom_item(item: Mapping[str, Any]) -> Item:
    """
    Return the protocol item of a scraper item: `size` (GB, of the pack for a pack, of the played file with `true_size`)
    -> `filesize` / `pack_size`, not repeated in `info`; `name` -> `filename`, `package` -> `pack`; the rest as an old item
    (`source` -> `hosting`...).
    """
    legacy = {key: val for key, val in item.items() if key not in ('size', 'true_size', 'name', 'package', 'info')}
    if (package := item.get('package')) in ('season', 'show'):
        legacy['pack'] = package
    if name := item.get('name'):
        legacy.setdefault('filename', name)
    info = item.get('info')
    size = item.get('size')
    if isinstance(size, (int, float)) and not isinstance(size, bool) and size:
        legacy['pack_size' if 'pack' in legacy and not item.get('true_size') else 'filesize'] = int(size * GB)
        # the same size in `info`, also as the scraper wrote it ('7.2 GB' of `convert_size()`)
        if isinstance(info, str):
            first, _, rest = info.partition(' | ')
            if (num := RX_INFO_SIZE.fullmatch(first)) and f'{float(num[1]):.2f}' == f'{size:.2f}':
                info = rest
    if isinstance(info, str) and info:
        legacy['info'] = info
    return item_from_legacy(legacy)


def clear_class_state(scraper: Any, data: Mapping[str, Any]) -> None:
    """
    Take the results a scraper left for its packs, else they grow in a warm interpreter and a later request could take
    the results of an earlier one: `_queue` of the class (CocoScrapers: torrentio, comet...; filled by every `sources()`,
    emptied only by `sources_packs()`), the future of this request in `_cache` of the class (POV `SourceRegistry`:
    `_cache[str(data)]` under `_lock`; only this one, another request may run).
    """
    cls = type(scraper)
    if callable(get := getattr(getattr(cls, '_queue', None), 'get_nowait', None)):
        try:
            while True:
                get()
        except Exception:  # queue.Empty
            pass
    if isinstance(cache := getattr(cls, '_cache', None), dict) and (lock := getattr(cls, '_lock', None)) is not None:
        with lock:
            cache.pop(str(data), None)


def fenom_find(scraper: Any, query: Query, context: Context) -> list[Item]:
    """
    Search with a Fenom scraper: `sources(data, hostDict)`, with an episode also `sources_packs()` of the pack kinds of
    the context (a pack without the episode dropped); the class state of the scraper cleared before and after.
    """
    movie = query.get('type') == 'movie'
    if not getattr(scraper, 'hasMovies' if movie else 'hasEpisodes', True):
        return []
    data = fenom_data(query, context)
    hosts = list(context.get('hosts', ()))
    clear_class_state(scraper, data)
    try:
        items = [fenom_item(item) for item in scraper.sources(data, hosts) or ()]
        if not movie and getattr(scraper, 'pack_capable', False):
            for kind in context.get('packs', ()):
                series = kind == 'show'
                packs = scraper.sources_packs(data, hosts, search_series=series, total_seasons=query.get('total_seasons') if series else None) or ()
                items.extend(fenom_item(item) for item in packs if pack_has(item, query))
    finally:
        clear_class_state(scraper, data)
    return items
