"""
A stand-in of the FanFilm item (`FFItem`) for the scrapers of FanFilm forks searched outside FanFilm: read only, built
from the protocol query, the shape the scrapers read (`ffitem.tmdb_id`, `ffitem.show_item`, `ffitem.vtag.getCountryCodes()`,
`ffitem.absolute_episode_number()`...). Unknown data is empty (None, '', []), as of an FFItem without it.

FanFilm refs: a movie `movie`, an episode `show` with its season and episode (`real_type` `episode`), a show `show`.
"""

from __future__ import annotations
from datetime import date as dt_date
from typing import Any, Sequence, TYPE_CHECKING
from attrs import frozen
if TYPE_CHECKING:
    from ..protocol.query import Query, QueryIds


#: The TMDB keyword of an anime (`FFItem.keywords`: name -> ID), the query has anime data only for one.
ANIME_KEYWORD: dict[str, int] = {'anime': 210024}


def _date(text: str | None) -> dt_date | None:
    """Return the date of an ISO text (None if none or not a date)."""
    try:
        return dt_date.fromisoformat(text[:10]) if text else None
    except ValueError:
        return None


@frozen
class QueryAlias:
    """A title alias (`FFItem.aliases_info`)."""

    #: The title.
    title: str
    #: The country (ISO 3166-1) or `original`.
    country: str


@frozen(kw_only=True)
class QueryRef:
    """The media reference (`FFItem.ref`)."""

    #: `movie` or `show` (an episode too).
    type: str
    #: `movie`, `show` or `episode`.
    real_type: str
    #: The TMDB ID of the movie / the show (None: unknown).
    tmdb_id: int | None = None
    #: The season number (an episode).
    season: int | None = None
    #: The episode number (an episode).
    episode: int | None = None

    @property
    def is_movie(self) -> bool:
        """Return True for a movie."""
        return self.real_type == 'movie'

    @property
    def is_show(self) -> bool:
        """Return True for a show."""
        return self.real_type == 'show'

    @property
    def is_episode(self) -> bool:
        """Return True for an episode."""
        return self.real_type == 'episode'


@frozen(kw_only=True)
class QueryVideoTag:
    """The video tag (`FFItem.vtag`): the getters the scrapers read."""

    #: The title (of the episode for an episode).
    title: str = ''
    #: The English title (of the movie / show).
    english_title: str = ''
    #: The original title (of the movie / show).
    original_title: str = ''
    #: The year.
    year: int | None = None
    #: Duration in seconds.
    duration: int = 0
    #: The release date of the movie / the first air date of the show (ISO).
    premiered: str = ''
    #: The air date (of the episode for an episode, ISO).
    first_aired: str = ''
    #: Production countries.
    countries: Sequence[str] = ()
    #: Original languages.
    languages: Sequence[str] = ()
    #: External IDs.
    ids: QueryIds | None = None

    def getTitle(self) -> str:
        """Return the title."""
        return self.title

    def getEnglishTitle(self) -> str:
        """Return the English title."""
        return self.english_title

    def getOriginalTitle(self) -> str:
        """Return the original title."""
        return self.original_title

    def getYear(self) -> int:
        """Return the year (0: unknown, as Kodi)."""
        return self.year or 0

    def getDuration(self) -> int:
        """Return the duration in seconds."""
        return self.duration

    def getCountryCodes(self) -> list[str]:
        """Return the production countries."""
        return list(self.countries)

    def getLanguageCodes(self) -> list[str]:
        """Return the original languages."""
        return list(self.languages)

    def getPremieredAsW3C(self) -> str:
        """Return the release date (ISO, '' if unknown)."""
        return self.premiered

    def getFirstAiredAsW3C(self) -> str:
        """Return the air date (ISO, '' if unknown)."""
        return self.first_aired

    def getUniqueID(self, key: str) -> str:
        """Return an external ID as a text ('' if unknown)."""
        value = (self.ids or {}).get(key)  # type: ignore[call-overload]  # any ID key
        return '' if value is None else str(value)

    def getUniqueIDs(self) -> dict[str, str]:
        """Return the external IDs as texts."""
        return {key: str(value) for key, value in (self.ids or {}).items() if value is not None}


@frozen(kw_only=True)
class QueryItem:
    """The stand-in of the FanFilm item of the query (see the module)."""

    #: The media reference.
    ref: QueryRef
    #: The video tag.
    vtag: QueryVideoTag
    #: The show of an episode (None for a movie, a show).
    show_item: QueryItem | None = None
    #: The episode number over the seasons (an episode).
    absolute_episode: int | None = None
    #: The number of the episodes of the season of the episode.
    season_episodes: int | None = None
    #: The title aliases (of the movie / show).
    aliases_info: Sequence[QueryAlias] = ()
    #: It is an anime (the query has anime data).
    anime: bool = False

    @property
    def title(self) -> str:
        """Return the title."""
        return self.vtag.title

    @property
    def year(self) -> int | None:
        """Return the year."""
        return self.vtag.year

    @property
    def duration(self) -> int | None:
        """Return the duration in seconds or None."""
        return self.vtag.duration or None

    @property
    def date(self) -> dt_date | None:
        """Return the air date (an episode) / the release date."""
        return _date(self.vtag.first_aired) or _date(self.vtag.premiered)

    @property
    def ids(self) -> dict[str, Any]:
        """Return the known external IDs."""
        return {key: value for key, value in (self.vtag.ids or {}).items() if value}

    @property
    def tmdb_id(self) -> int | None:
        """Return the TMDB ID."""
        return (self.vtag.ids or {}).get('tmdb')

    @property
    def keywords(self) -> dict[str, int]:
        """Return the TMDB keywords known from the query (name -> ID): only `anime`."""
        return dict(ANIME_KEYWORD) if self.anime else {}

    @property
    def aliases(self) -> Sequence[str]:
        """Return the title aliases."""
        return tuple(alias.title for alias in self.aliases_info)

    def absolute_episode_number(self) -> int | None:
        """Return the episode number over the seasons (an episode, if known)."""
        return self.absolute_episode if self.ref.is_episode else None

    def season_episode_count(self, season: int | None, **kwargs: Any) -> int:
        """Return the number of the episodes of the season (known only for the season of the episode)."""
        return (self.season_episodes or 0) if self.ref.type == 'show' and season is not None and season == self.ref.season else 0

    def get_season_item(self, season: int) -> None:
        """Return the season item: unknown here (the query has no seasons)."""
        return None

    def __str__(self) -> str:
        """Return the item for a log."""
        ref = self.ref
        return f'{ref.real_type}:{ref.tmdb_id}' + (f' S{ref.season:02d}E{ref.episode:02d}' if ref.is_episode and ref.season is not None and ref.episode is not None else '')


def query_item(query: Query) -> QueryItem:
    """Return the stand-in of the FanFilm item of the query (a movie, an episode with its show)."""
    title = query.get('title', {})
    ids = query.get('ids', {})
    aliases = tuple(QueryAlias(alias['title'], alias['country']) for alias in query.get('aliases', ()))
    common = dict(english_title=title.get('english', ''), original_title=title.get('original', ''),
                  countries=tuple(query.get('countries', ())), languages=tuple(query.get('original_languages', ())))
    premiered = query.get('premiered') or ''
    anime = bool(query.get('anime', {}).get('cours'))
    if query.get('type') != 'episode':
        return QueryItem(ref=QueryRef(type='movie', real_type='movie', tmdb_id=ids.get('tmdb')),
                         vtag=QueryVideoTag(title=title.get('local', ''), year=query.get('year'), duration=query.get('duration', 0),
                                            premiered=premiered, ids=ids, **common),  # type: ignore[arg-type]
                         aliases_info=aliases, anime=anime)
    show = QueryItem(ref=QueryRef(type='show', real_type='show', tmdb_id=ids.get('tmdb')),
                     vtag=QueryVideoTag(title=title.get('local', ''), year=query.get('year'), premiered=premiered, first_aired=premiered,
                                        ids=ids, **common),  # type: ignore[arg-type]
                     aliases_info=aliases, anime=anime)
    aired = query.get('episode_aired', '')
    aired_date = _date(aired)
    return QueryItem(ref=QueryRef(type='show', real_type='episode', tmdb_id=ids.get('tmdb'), season=query.get('season'), episode=query.get('episode')),
                     vtag=QueryVideoTag(title=query.get('episode_title', ''), year=aired_date.year if aired_date else query.get('year'),
                                        duration=query.get('duration', 0), premiered=premiered, first_aired=aired,
                                        ids=query.get('episode_ids', {}), **common),  # type: ignore[arg-type]
                     show_item=show, absolute_episode=query.get('absolute_episode'), season_episodes=query.get('season_episodes'),
                     aliases_info=aliases, anime=anime)


def query_override(query: Query) -> dict[str, Any]:
    """Return the search data of the new FanFilm API (`find(ffitem=…, override=…)`) of the query."""
    title = query.get('title', {})
    return {'local_title': title.get('local', ''), 'english_title': title.get('english', ''), 'original_title': title.get('original', ''),
            'year': query.get('year'), 'premiered': _date(query.get('premiered')), 'season': query.get('season'),
            'episode': query.get('episode'), 'aliases': [dict(alias) for alias in query.get('aliases', ())]}
