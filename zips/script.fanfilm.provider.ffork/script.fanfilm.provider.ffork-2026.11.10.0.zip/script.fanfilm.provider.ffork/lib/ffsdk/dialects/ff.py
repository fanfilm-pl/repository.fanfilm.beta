"""
The old API of FanFilm providers (FanFilm 2 / 3, their forks: `dialects.ffork`): `movie()`, `tvshow()` + `episode()`,
then `sources()`, called with the texts the old API expects (IDs and the year as texts, `title` of an episode is the show
title).
"""

from __future__ import annotations
from typing import Any, Sequence, TYPE_CHECKING
from ..tricks import MISSING
if TYPE_CHECKING:
    from ..protocol.query import Query, QueryAlias


def old_str(value: object) -> str:
    """Return a value as the old API text (None: empty)."""
    return '' if value is None else str(value)


def old_ids(query: Query) -> tuple[str, str]:
    """Return `imdb` and `tvdb` of the movie or of the show (also for an episode, as the old API expects)."""
    ids = query.get('ids', {})
    return old_str(ids.get('imdb')), old_str(ids.get('tvdb'))


def old_aliases(query: Query) -> list[QueryAlias]:
    """Return the title aliases (a copy, a provider can change it)."""
    return list(query.get('aliases', ()))


def old_api_find_show(provider: Any, query: Query, *, aliases: Sequence[Any] | None = None) -> Any:
    """Return the show token of an old API provider (its `tvshow()` result); `aliases` of the provider (default: `old_aliases()`)."""
    imdb, tvdb = old_ids(query)
    title = query.get('title', {})
    return provider.tvshow(imdb, tvdb, title.get('english', ''), title.get('local', ''), list(old_aliases(query) if aliases is None else aliases),
                           old_str(query.get('year')))


def old_api_find(provider: Any, query: Query, *, hosts: Sequence[str], premium_hosts: Sequence[str], show: Any = MISSING,
                 aliases: Sequence[Any] | None = None) -> Sequence[dict[str, Any]]:
    """
    Search sources with an old API provider: `movie()` or [`tvshow()`] + `episode()`, then `sources(found, hosts, premium_hosts)`.

    `show` is the show token (cached by the host); without it `tvshow()` is called here. `aliases` of the provider
    (default: `old_aliases()`).
    """
    found: Any = None
    imdb, tvdb = old_ids(query)
    title = query.get('title', {})
    if query.get('type') == 'movie':
        if callable(getattr(provider, 'movie', None)):
            found = provider.movie(imdb, title.get('english', ''), title.get('local', ''), list(old_aliases(query) if aliases is None else aliases),
                                   old_str(query.get('year')))
    elif callable(getattr(provider, 'episode', None)):
        if show is MISSING:
            show = old_api_find_show(provider, query, aliases=aliases) if callable(getattr(provider, 'tvshow', None)) else None
        found = provider.episode(show, imdb, tvdb, title.get('english', ''), old_str(query.get('premiered')),
                                 old_str(query.get('season')), old_str(query.get('episode')))
    if found is None:
        return ()
    return provider.sources(found, list(hosts), list(premium_hosts)) or ()
