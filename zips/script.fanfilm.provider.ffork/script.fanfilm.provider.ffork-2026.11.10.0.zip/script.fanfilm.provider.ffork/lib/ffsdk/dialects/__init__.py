"""
Dialects: the APIs of the scraper families (FanFilm, Fenom) called with the search query of the protocol.
"""
