"""
The dialect of the FanFilm forks (`ffork`: FanFilm 2 / 3 forks with their scrapers, `lib/sources/<group>`): the search of
a fork scraper outside FanFilm (`ffork_find()`): its `ffitem` a stand-in of the query (`dialects.ffitem`), the new API
(`find()`, `find_show()`) or the old one (`dialects.ff`), the show token kept in the provider data (`db.providers`), the
lifetime of the result (an account state in it: not cached, the protocol has no dynamic layer).
"""

from __future__ import annotations
import json
from hashlib import sha1
from pathlib import Path
from typing import Any, Mapping, TYPE_CHECKING
from ..tricks import MISSING
from .ff import old_api_find, old_api_find_show
if TYPE_CHECKING:
    from ..protocol import Context, Item
    from ..protocol.query import Query
    from ..runner import Found

#: The lifetime of the show token when the host gives none (seconds).
SHOW_TTL = 24 * 3600
#: The lifetime of an empty show token when the host gives none (seconds).
EMPTY_TTL = 5 * 60


def fork_aliases(query: Query) -> list[dict[str, Any]]:
    """Return the title aliases of the old API of FanFilm forks: with `originalname` (the original title)."""
    return [{**alias, 'originalname': alias['title'] if alias['country'] == 'original' else ''} for alias in query.get('aliases', ())]


def show_fingerprint(query: Query) -> str:
    """Return the key of the show part of the query (the show token is shared by the episodes of the same show query)."""
    part = {key: query.get(key) for key in ('ids', 'title', 'year', 'aliases', 'lang')}
    return sha1(json.dumps(part, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:16]


def _json_safe(data: Any) -> bool:
    """Check if `data` survives JSON unchanged (e.g. a tuple does not: it comes back as a list)."""
    try:
        return json.loads(json.dumps(data)) == data
    except (TypeError, ValueError):
        return False


def show_token(provider: str, scraper: Any, query: Query, context: Context) -> Any:
    """
    Return the show token of the scraper for an episode search (its `find_show()` or the old `tvshow()`), kept in the
    provider data: the lifetime of the scraper (`SHOW_TTL`), else of the host (`context.cache.ttl.show`), else a day;
    `context.cache.refresh` searches it again. MISSING if the scraper has no show level.
    """
    from .ffitem import query_item, query_override
    new = callable(getattr(scraper, 'find_show', None))
    if not new and not callable(getattr(scraper, 'tvshow', None)):
        return MISSING
    cache = context.get('cache', {})
    ttl = getattr(scraper, 'SHOW_TTL', None)
    if ttl is None:
        ttl = cache.get('ttl', {}).get('show', SHOW_TTL)
    store = key = None
    if ttl > 0:
        from ..db.providers import ProviderStore
        store, key = ProviderStore(provider), f'show:{show_fingerprint(query)}'
        if not cache.get('refresh') and (row := store.row(key)) is not None:
            return row.data
    token = (scraper.find_show(ffitem=query_item(query), override=query_override(query)) if new
             else old_api_find_show(scraper, query, aliases=fork_aliases(query)))
    if store is not None and key is not None and _json_safe(token):
        store.set(key, token, ttl=ttl if token is not None else min(ttl, cache.get('ttl', {}).get('empty', EMPTY_TTL)))
    return token


#: The account step of a scraper: `apply_dynamic()` (of FanFilm 3: after every search) or the old hook (on a cached result only).
ACCOUNT_STEPS: tuple[str, ...] = ('apply_dynamic', 'check_and_add_on_account_sources')


def account_step(scraper: Any) -> str:
    """Return the account step of the scraper object (`ACCOUNT_STEPS`), '' if none."""
    return next((name for name in ACCOUNT_STEPS if callable(getattr(scraper, name, None))), '')


def has_account_step(path: Path) -> bool:
    """Check (the text of the file, no import) if the scraper defines an account step (`ACCOUNT_STEPS`)."""
    from ..addons.scan import source_text
    text = source_text(path)
    return any(f'def {name}(' in text for name in ACCOUNT_STEPS)


def sources_ttl(scraper: Any, *, dynamic: bool) -> int | None:
    """
    Return the lifetime of the result of the scraper: its `SOURCES_TTL`; with an account step the catalog does not know
    (`dynamic`: e.g. a hook of a base class) none (the account state is in the result, the host can not refresh it).
    """
    if account_step(scraper) and not dynamic:
        return 0
    return getattr(scraper, 'SOURCES_TTL', None)


class ForkSource:
    """
    A source of a fork scraper for its account step (the FanFilm `Source` as the forks read and change it: `url`,
    `provider`, `hosting`, `ffitem`, `meta`, the dict-like access to `meta`), made of a protocol item.
    """

    def __init__(self, item: Mapping[str, Any], *, provider: str, ffitem: Any) -> None:
        """Make the source of the item (the account state flat, the size also as the text the forks parse)."""
        #: The link.
        self.url: str = item.get('url', '')
        #: The provider.
        self.provider: str = provider
        #: The hosting.
        self.hosting: str = item.get('hosting', '')
        #: The item of the search.
        self.ffitem: Any = ffitem
        meta = {key: val for key, val in item.items() if key not in ('url', 'hosting', 'dynamic')}
        meta.update(item.get('dynamic') or {})
        if (size := item.get('filesize')) and 'size' not in meta:
            meta['size'] = f'{size / 1024 ** 3:.2f} GB'
            meta['filesize_bytes'] = size
        #: The other data (the account state flat).
        self.meta: dict[str, Any] = meta

    def __contains__(self, key: Any) -> bool:
        """Check if the meta has the key."""
        return key in self.meta

    def __getitem__(self, key: str) -> Any:
        """Return a field (`url`, `provider`, `hosting`, else of the meta)."""
        if key in ('url', 'provider', 'hosting'):
            return getattr(self, key)
        return self.meta[key]

    def __setitem__(self, key: str, value: Any) -> None:
        """Set a field of the meta."""
        self.meta[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Return a field or `default`."""
        if key in ('url', 'provider', 'hosting'):
            return getattr(self, key)
        return self.meta.get(key, default)

    def update(self, data: Mapping[str, Any], /) -> None:
        """Update the fields (`url` too: a fork changes its link)."""
        data = dict(data)
        if 'url' in data:
            self.url = data.pop('url')
        self.meta.update(data)

    def keys(self) -> Any:
        """Return the keys of the meta."""
        return self.meta.keys()

    def values(self) -> Any:
        """Return the values of the meta."""
        return self.meta.values()

    def items(self) -> Any:
        """Return the items of the meta."""
        return self.meta.items()

    def legacy(self) -> dict[str, Any]:
        """Return the source as an old scraper item (`source`: the hosting)."""
        return {**self.meta, 'url': self.url, 'source': self.hosting}


def _legacy(source: Any) -> dict[str, Any] | None:
    """Return an old scraper item of a source of an account step (a `ForkSource` or a dict it added), None if neither."""
    if isinstance(source, ForkSource):
        return source.legacy()
    return source if isinstance(source, dict) else None


def apply_account_step(scraper: Any, provider: str, query: Query, sources: list[ForkSource]) -> list[dict[str, Any]]:
    """Run the account step of the scraper on the sources, return them as old scraper items (`apply_dynamic` may add more)."""
    from .ffitem import query_item, query_override
    step = account_step(scraper)
    if step == 'apply_dynamic':
        result = scraper.apply_dynamic(ffitem=query_item(query), override=query_override(query), sources=sources) or sources
    elif step:
        scraper.check_and_add_on_account_sources(sources, query_item(query), provider.partition(':')[2])
        result = sources
    else:
        result = sources
    return [item for source in result if (item := _legacy(source)) is not None]


def ffork_find(provider: str, scraper: Any, query: Query, context: Context, *, dynamic: bool = False) -> Found:
    """
    Search with a FanFilm fork scraper (see the module): its items as protocol items (with the account state: the step of
    `apply_dynamic` after the search, an old hook marks them in the search), the lifetime of the result.
    """
    from ..protocol.item import item_from_legacy
    from ..runner import Found
    from .ffitem import query_item, query_override
    item = query_item(query)
    scraper.ffitem = item
    scraper.canceled = False
    show = show_token(provider, scraper, query, context) if query.get('type') == 'episode' else MISSING
    found: Any
    if callable(find := getattr(scraper, 'find', None)):
        if show is not MISSING and callable(getattr(scraper, 'find_show', None)):
            found = find(ffitem=item, override=query_override(query), show=show)
        else:
            found = find(ffitem=item, override=query_override(query))
    else:
        found = old_api_find(scraper, query, hosts=context.get('hosts', ()), premium_hosts=context.get('premium_hosts', ()), show=show,
                             aliases=fork_aliases(query))
    legacy = [it for it in found or () if isinstance(it, dict)]
    if account_step(scraper) == 'apply_dynamic':
        legacy = apply_account_step(scraper, provider, query, [ForkSource(item_from_legacy(it), provider=provider, ffitem=item) for it in legacy])
    items: list[Item] = [item_from_legacy(it) for it in legacy]
    return Found(items, sources_ttl=sources_ttl(scraper, dynamic=dynamic))


def ffork_dynamic(provider: str, scraper: Any, query: Query, items: list[Item]) -> list[Item]:
    """Return the cached items of a fork scraper with the account state now (its account step)."""
    from ..protocol.item import item_from_legacy
    from .ffitem import query_item
    ffitem = query_item(query)
    scraper.ffitem = ffitem
    sources = [ForkSource(it, provider=provider, ffitem=ffitem) for it in items]
    return [item_from_legacy(it) for it in apply_account_step(scraper, provider, query, sources)]
