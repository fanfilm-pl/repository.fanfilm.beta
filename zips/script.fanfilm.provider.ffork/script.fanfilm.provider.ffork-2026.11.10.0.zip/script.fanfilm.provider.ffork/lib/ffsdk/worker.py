"""
The worker script of a provider add-on (the run mode `service`): its own interpreter started by `RunScript` (by the
supervisor of the host, at the Kodi start or on demand), the provider object served over HTTP on `127.0.0.1` until the
Kodi exit or a change of the add-on (the supervisor starts it again: a clean reload of all its modules).

- the state file (port, token, the instance ID) is written atomically and removed only by its own instance;
- one worker an add-on: Kodi starts a second script while the first runs, the second exits when the first answers;
- `/find` is a stream of JSON lines (the `find` events), a closed connection cancels the request.

The add-on is listed in Program add-ons by its plugin entry (`xbmc.python.pluginsource`, `show_addon()`); the worker
script is `xbmc.python.library` (listed nowhere, `RunScript(<add-on>)` runs it): a listed script is run or stopped by a click.

The worker script of an add-on (the plugin entry the same with `show_addon(ROOT)`):

    import sys
    from pathlib import Path
    ROOT = Path(__file__).resolve().parent
    sys.path[:0] = [str(ROOT / 'lib'), str(ROOT / 'lib' / '3rd')]
    from ffsdk.worker import main
    main(ROOT)
"""

from __future__ import annotations
import atexit
import json
import os
import secrets
import select
import socket
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import import_module
from pathlib import Path
from time import time
from typing import Any, Callable, Iterator, Mapping, TYPE_CHECKING
from . import __version__, HOST_ID
from .log import log
from .manifest import read_manifest, stamp
from .protocol import PROTOCOL_VERSION
if TYPE_CHECKING:
    from .protocol import FindEvent, Context, Item, ResolveResult
    from .protocol.query import Query
    from .protocol.catalog import Catalog
    from .xprovider import XProvider


#: The state file name in the data folder of the add-on.
STATE_FILE = 'ffsdk-worker.json'
#: The header of the token.
TOKEN_HEADER = 'X-FF-Token'
#: How long a status question waits (seconds).
PING_TIMEOUT = 1.0
#: How often the worker checks the Kodi exit and its add-on change (seconds).
WATCH_STEP = .5
#: The page of the provider add-ons in the host (opened by the plugin entry of an add-on).
HOST_PAGE = f'plugin://{HOST_ID}/tools/external_addons'


def state_path(addon_id: str) -> Path:
    """Return the state file of the worker of the add-on (in its data folder)."""
    from xbmcvfs import translatePath
    return Path(translatePath(f'special://profile/addon_data/{addon_id}')) / STATE_FILE


def read_state(path: Path) -> dict[str, Any] | None:
    """Return the worker state, None if there is none (or broken)."""
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) and isinstance(data.get('port'), int) and data.get('token') else None


def _write_state(path: Path, state: Mapping[str, Any]) -> None:
    """Write the state atomically (a reader never sees a part of it)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'{path.name}.{state["iid"]}.tmp')
    tmp.write_text(json.dumps(state), encoding='utf-8')
    os.replace(tmp, path)


def _remove_state(path: Path, iid: str) -> None:
    """Remove the state if it is of the instance (a newer worker keeps its own)."""
    if (state := read_state(path)) is not None and state.get('iid') == iid:
        try:
            path.unlink()
        except OSError:
            pass


class WorkerClient:
    """The host side of a worker: the provider add-on API over HTTP (the same data as in the process)."""

    def __init__(self, state: Mapping[str, Any]) -> None:
        """Create the client of the worker of the state."""
        self.port: int = state['port']
        self.token: str = state['token']
        self.iid: str = state.get('iid', '')

    def _request(self, path: str, data: Any = None, *, timeout: float | None = None) -> Any:
        """POST the JSON data, return the JSON answer."""
        conn = HTTPConnection('127.0.0.1', self.port, timeout=timeout)
        try:
            conn.request('POST', path, json.dumps(data).encode('utf-8'), {TOKEN_HEADER: self.token, 'Content-Type': 'application/json'})
            resp = conn.getresponse()
            body = resp.read()
            if resp.status != 200:
                raise ConnectionError(f'worker {path}: HTTP {resp.status}')
            return json.loads(body)
        finally:
            conn.close()

    def status(self) -> dict[str, Any] | None:
        """Return the status of the worker, None if it does not answer."""
        try:
            return self._request('/status', timeout=PING_TIMEOUT)
        except (OSError, ValueError):
            return None

    def catalog(self) -> Catalog:
        """Return the catalog of the provider add-on."""
        return self._request('/catalog')

    def find(self, query: Query, context: Context, *, canceled: Callable[[], bool] | None = None) -> Iterator[FindEvent]:
        """Yield the `find` events of the request as they come (closing the connection cancels it)."""
        context = {key: val for key, val in context.items() if key != 'extras'}  # type: ignore[assignment]  # objects of the host process only
        conn = HTTPConnection('127.0.0.1', self.port, timeout=None)  # until the stream ends (no default socket timeout): a cancel cuts it
        try:
            conn.request('POST', '/find', json.dumps({'query': query, 'context': context}).encode('utf-8'),
                         {TOKEN_HEADER: self.token, 'Content-Type': 'application/json'})
            resp = conn.getresponse()
            if resp.status != 200:
                raise ConnectionError(f'worker /find: HTTP {resp.status}')
            for line in resp:
                if canceled is not None and canceled():
                    return
                if line.strip():
                    yield json.loads(line)
        finally:
            conn.close()

    def resolve(self, provider: str, item: Mapping[str, Any], options: Mapping[str, Any] | None = None) -> ResolveResult | str | None:
        """Return the stream of an item."""
        return self._request('/resolve', {'provider': provider, 'item': dict(item), 'options': dict(options or {})}).get('result')

    def dynamic(self, provider: str, query: Query, context: Context, items: list[Item]) -> list[Item]:
        """Return the items of a cached result with the account state now."""
        context = {key: val for key, val in context.items() if key != 'extras'}  # type: ignore[assignment]  # objects of the host process only
        return self._request('/dynamic', {'provider': provider, 'query': query, 'context': context, 'items': items}).get('items') or []

    def clear(self) -> None:
        """Remove the data of the providers of the provider add-on."""
        self._request('/clear')

    def exit(self) -> None:
        """Ask the worker to end."""
        try:
            self._request('/exit', timeout=PING_TIMEOUT)
        except (OSError, ValueError):
            pass


def alive(addon_id: str) -> WorkerClient | None:
    """Return the client of the running worker of the add-on, None if none answers."""
    if (state := read_state(state_path(addon_id))) is None:
        return None
    client = WorkerClient(state)
    return client if client.status() is not None else None


def _client_gone(sock: socket.socket) -> bool:
    """Return True if the client closed the connection (the request is canceled)."""
    try:
        readable, _, _ = select.select([sock], [], [], 0)
        return bool(readable) and not sock.recv(1, socket.MSG_PEEK)
    except (OSError, ValueError):
        return True


class _Handler(BaseHTTPRequestHandler):
    """The HTTP requests of the host."""

    server: _Server  # type: ignore[assignment]
    protocol_version = 'HTTP/1.0'

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002  (the name of the base class)
        """Do not write the requests to stderr."""

    def _json(self, data: Any, status: int = 200) -> None:
        """Answer the JSON data."""
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        """Serve a call of the protocol."""
        if self.headers.get(TOKEN_HEADER) != self.server.token:
            self._json({'error': 'token'}, 403)
            return
        try:
            data = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'null') or {}
        except ValueError:
            self._json({'error': 'json'}, 400)
            return
        xp = self.server.xprovider
        if self.path == '/status':
            self._json(self.server.status())
        elif self.path == '/catalog':
            self._json(xp.catalog())
        elif self.path == '/resolve':
            self._json({'result': xp.resolve(data['provider'], data['item'], data.get('options'))})
        elif self.path == '/dynamic':
            self._json({'items': xp.dynamic(data['provider'], data['query'], data['context'], data['items'])})
        elif self.path == '/find':
            self.send_response(200)
            self.send_header('Content-Type', 'application/x-ndjson')
            self.end_headers()
            sock = self.connection
            events = xp.find(data['query'], data['context'], canceled=lambda: _client_gone(sock))
            try:
                for event in events:
                    self.wfile.write(json.dumps(event).encode('utf-8') + b'\n')
                    self.wfile.flush()
            except OSError:  # the host closed the connection: the request canceled
                pass
            finally:
                close = getattr(events, 'close', None)
                if callable(close):
                    close()  # the left providers stopped
        elif self.path == '/clear':
            xp.clear()
            self._json({'clear': True})
        elif self.path == '/exit':
            self._json({'exit': True})
            self.server.exit_requested = True
        else:
            self._json({'error': 'path'}, 404)


class _Server(ThreadingHTTPServer):
    """The HTTP server of the worker."""

    daemon_threads = True

    def __init__(self, xprovider: XProvider, addon_id: str) -> None:
        """Listen on a free port of 127.0.0.1."""
        super().__init__(('127.0.0.1', 0), _Handler)
        self.xprovider = xprovider
        self.addon_id = addon_id
        self.token = secrets.token_hex(16)
        self.iid = secrets.token_hex(4)
        self.started = time()
        self.exit_requested = False

    def status(self) -> dict[str, Any]:
        """Return the status of the worker."""
        return {'addon': self.addon_id, 'iid': self.iid, 'pid': os.getpid(), 'sdk': __version__, 'protocol': PROTOCOL_VERSION,
                'uptime': round(time() - self.started, 1)}


def _warm_up(xprovider: XProvider, addon_id: str) -> None:
    """Prepare the first search of the provider add-on, log the time."""
    from time import monotonic
    start = monotonic()
    try:
        xprovider.warm_up()
    except Exception as exc:
        log(f'[ffsdk:{addon_id}] warm-up failed: {exc!r}')
        return
    log(f'[ffsdk:{addon_id}] warmed up in {monotonic() - start:.2f} s')


def serve(xprovider: XProvider, *, addon_path: Path, path: Path | None = None) -> None:
    """Serve the provider add-on until the Kodi exit, an exit request or a change of the add-on (`stamp()`)."""
    from threading import Thread
    from xbmc import Monitor
    addon_id = addon_path.name
    path = path or state_path(addon_id)
    if (state := read_state(path)) is not None and WorkerClient(state).status() is not None:
        log(f'[ffsdk:{addon_id}] the worker {state.get("iid")} runs, this one ends')
        return
    server = _Server(xprovider, addon_id)
    start_stamp = stamp(addon_path)
    _write_state(path, {'iid': server.iid, 'port': server.server_address[1], 'token': server.token, 'pid': os.getpid(), 'stamp': start_stamp})
    Thread(target=server.serve_forever, name=f'ffsdk worker {addon_id}', daemon=True).start()
    log(f'[ffsdk:{addon_id}] worker {server.iid} serving on port {server.server_address[1]}')
    Thread(target=_warm_up, args=(xprovider, addon_id), name=f'ffsdk warm-up {addon_id}', daemon=True).start()
    monitor = Monitor()
    reason = 'Kodi exit'
    try:
        while not monitor.waitForAbort(WATCH_STEP):
            if server.exit_requested:
                reason = 'exit request'
                break
            if stamp(addon_path) != start_stamp:
                reason = 'the add-on changed'
                break
    finally:
        server.shutdown()
        server.server_close()
        _remove_state(path, server.iid)
        xprovider.close()
        log(f'[ffsdk:{addon_id}] worker {server.iid} ended: {reason}')


def show_addon(addon_path: Path) -> None:
    """
    The plugin entry of the add-on (Program add-ons): no folder, the page of the provider add-ons of the host opened
    (without the host: the add-on description).
    """
    import sys
    from xbmc import executebuiltin, getCondVisibility
    from xbmcplugin import endOfDirectory
    endOfDirectory(int(sys.argv[1]), succeeded=False)
    if getCondVisibility(f'System.AddonIsEnabled({HOST_ID})'):
        executebuiltin(f'RunPlugin({HOST_PAGE})')
        return
    from xbmcaddon import Addon
    from xbmcgui import Dialog
    addon = Addon(addon_path.name)
    Dialog().textviewer(addon.getAddonInfo('name'), addon.getAddonInfo('description'))


def main(addon_path: Path) -> None:
    """Run the worker of the add-on: its manifest `entry` created with the host info and served."""
    from .net import share_tls_contexts
    from .threads import inherit_thread_scopes, watch_sockets
    from .xprovider import HostInfo
    if (manifest := read_manifest(addon_path)) is None:
        log(f'[ffsdk:{addon_path.name}] no compatible manifest, the worker ends')
        return
    inherit_thread_scopes()
    watch_sockets()
    share_tls_contexts()  # the scrapers use requests: one TLS context of the worker, not one for every connection
    module, _, name = manifest.entry.partition(':')
    host: HostInfo = {'protocol': PROTOCOL_VERSION, 'path': str(addon_path), 'mode': 'service'}
    try:
        serve(getattr(import_module(module), name)(host), addon_path=addon_path)
    finally:
        # the exit callbacks now, the modules still there: Kodi 22 clears `sys.modules` before `Py_EndInterpreter` runs them,
        # an import of one fails there (e.g. the DB pool and the monitor of a FanFilm fork in a namespace); run once, then cleared
        atexit._run_exitfuncs()  # type: ignore[attr-defined]  # (a private name, there since Python 3.0)
